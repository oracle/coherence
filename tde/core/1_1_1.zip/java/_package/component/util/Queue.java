/* Class
*     _package.component.util.Queue
*/

package _package.component.util;

import com.tangosol.util.SafeLinkedList;
import com.tangosol.util.WrapperException;
import java.util.List;

/**
* The MessageQueue provides a means to efficiently (and in a thread-safe
* manner) queue received messages and messages to be sent.
*/
public class Queue
        extends    _package.component.Util
    {
    // Fields declarations
    
    /**
    * Property ElementList
    *
    */
    private java.util.List __m_ElementList;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Iterator", Queue$Iterator.get_CLASS());
        }
    
    // Default constructor
    public Queue()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Queue(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Queue();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/Queue".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    /**
    * Appends the specified element to the end of this queue.
    * 
    * Queues may place limitations on what elements may be added to this Queue.
    *  In particular, some Queues will impose restrictions on the type of
    * elements that may be added. Queue implementations should clearly specify
    * in their documentation any restrictions on what elements may be added.
    * 
    * @param oElement element to be appended to this Queue
    * 
    * @return true (as per the general contract of the Collection.add method)
    * 
    * @throws ClassCastException if the class of the specified element prevents
    * it from being added to this Queue
    */
    public synchronized boolean add(Object oElement)
        {
        getElementList().add(oElement);
        notifyAll();
        return true;
        }
    
    // Accessor for the property "ElementList"
    /**
    * Getter for property ElementList.<p>
    */
    protected java.util.List getElementList()
        {
        return __m_ElementList;
        }
    
    /**
    * Determine the number of elements in this Queue. The size of the Queue may
    * change after the size is returned from this method, unless the Queue is
    * synchronized on before calling size() and the monitor is held until the
    * operation based on this size result is complete.
    * 
    * @return the number of elements in this Queue
    */
    public boolean isEmpty()
        {
        return getElementList().isEmpty();
        }
    
    /**
    * Provides an iterator over the elements in this Queue. The iterator is a
    * point-in-time snapshot, and the contents of the Queue may change after
    * the iterator is returned, unless the Queue is synchronized on before
    * calling iterator() and until the iterator is exhausted.
    * 
    * @return an iterator of the elements in this Queue
    */
    public java.util.Iterator iterator()
        {
        $Iterator iter = ($Iterator) _newChild("Iterator");
        iter.setList(getElementList());
        return iter;
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import com.tangosol.util.SafeLinkedList;
        
        super.onInit();
        
        setElementList(new SafeLinkedList());
        }
    
    /**
    * Waits for and removes the first element from the front of this Queue.
    * 
    * If the Queue is empty, this method will block until an element is in the
    * Queue. The unblocking equivalent of this method is "removeNoWait".
    * 
    * @return the first element in the front of this Queue
    * 
    * @see #removeNoWait
    */
    public synchronized Object remove()
        {
        // import com.tangosol.util.WrapperException;
        // import java.util.List;
        
        List list = getElementList();
        while(list.isEmpty())
            {
            try
                {
                wait();
                }
            catch (InterruptedException e)
                {
                throw new WrapperException(e);
                }
            }
        
        return list.remove(0);
        }
    
    /**
    * Removes and returns the first element from the front of this Queue. If
    * the Queue is empty, no element is returned.
    * 
    * The blocking equivalent of this method is "remove".
    * 
    * @return the first element in the front of this Queue or null if the Queue
    * is empty
    * 
    * @see #remove
    */
    public synchronized Object removeNoWait()
        {
        // import java.util.List;
        
        List list = getElementList();
        if (list.isEmpty())
            {
            return null;
            }
        else
            {
            return list.remove(0);
            }

        }
    
    // Accessor for the property "ElementList"
    /**
    * Setter for property ElementList.<p>
    */
    protected void setElementList(java.util.List list)
        {
        __m_ElementList = list;
        }
    
    /**
    * Determine the number of elements in this Queue. The size of the Queue may
    * change after the size is returned from this method, unless the Queue is
    * synchronized on before calling size() and the monitor is held until the
    * operation based on this size result is complete.
    * 
    * @return the number of elements in this Queue
    */
    public int size()
        {
        return getElementList().size();
        }
    }
