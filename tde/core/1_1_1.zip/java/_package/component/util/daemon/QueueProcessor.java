/* Class
*     _package.component.util.daemon.QueueProcessor
*/

package _package.component.util.daemon;

public class QueueProcessor
        extends    _package.component.util.Daemon
    {
    // Fields declarations
    
    /**
    * Property Queue
    *
    */
    private QueueProcessor$Queue __m_Queue;
    
    // Default constructor
    public QueueProcessor()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public QueueProcessor(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        _addChild(new QueueProcessor$Queue("Queue", this, true), "Queue");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new QueueProcessor();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/daemon/QueueProcessor".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "Queue"
    /**
    * Getter for property Queue.<p>
    */
    public QueueProcessor$Queue getQueue()
        {
        $Queue queue = __m_Queue;
        
        if (queue == null)
            {
            queue = ($Queue) _findChild("Queue");
            setQueue(queue);
            }
        
        return queue;
        }
    
    // Declared at the super level
    /**
    * Getter for property Notification.<p>
    * Specifes whether there is work for the daemon to do; if there is work,
    * Notification must evaluate to true, and if there is no work (implying
    * that the daemon should wait for work) then Notification must evaluate to
    * false.
    * 
    * To verify that a wait is necessary, the monitor on the Lock property is
    * first obtained and then Notification is evaluated; only if Notification
    * evaluates to false will the daemon go into a wait state on the Lock
    * property.
    * 
    * To unblock (notify) the daemon, another thread should set Notification to
    * true.
    * 
    * @see #onWait
    */
    public boolean isNotification()
        {
        return !getQueue().isEmpty();
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        super.onInit();
        setLock(getQueue());
        }
    
    // Accessor for the property "Queue"
    /**
    * Setter for property Queue.<p>
    */
    private void setQueue(QueueProcessor$Queue queue)
        {
        __m_Queue = queue;
        }
    }
