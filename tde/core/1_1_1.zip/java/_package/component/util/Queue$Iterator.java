/* Class
*     _package.component.util.Queue$Iterator
*/

package _package.component.util;

import java.util.ConcurrentModificationException;
import java.util.List;

public class Queue$Iterator
        extends    Iterator
    {
    // Fields declarations
    
    /**
    * Property List
    *
    */
    private java.util.List __m_List;
    
    /**
    * Property RemoveCount
    *
    */
    private int __m_RemoveCount;
    
    // Default constructor
    public Queue$Iterator()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Queue$Iterator(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Queue$Iterator();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/Queue$Iterator".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Accessor for the property "List"
    /**
    * Getter for property List.<p>
    */
    protected java.util.List getList()
        {
        return __m_List;
        }
    
    // Accessor for the property "RemoveCount"
    /**
    * Getter for property RemoveCount.<p>
    */
    protected int getRemoveCount()
        {
        return __m_RemoveCount;
        }
    
    // Declared at the super level
    public void remove()
        {
        // import java.util.List;
        // import java.util.ConcurrentModificationException;
        
        if (isCanRemove())
            {
            setCanRemove(false);
        
            int    cRemoved = getRemoveCount();
            int    iIndex   = getNextIndex() - 1;
            Object oElement = getItem(iIndex);
            int    iGuess   = iIndex - cRemoved;
            List   list     = getList();
            synchronized (get_Parent())
                {
                if (list.get(iGuess) == oElement)
                    {
                    list.remove(iGuess);
                    }
                else
                    {
                    if (!list.remove(oElement))
                        {
                        throw new ConcurrentModificationException();
                        }
                    }
                }
            setRemoveCount(cRemoved + 1);
            }
        else
            {
            throw new IllegalStateException();
            }

        }
    
    // Accessor for the property "List"
    /**
    * Setter for property List.<p>
    */
    public void setList(java.util.List list)
        {
        _assert(list != null);
        _assert(getList() == null);
        
        __m_List = (list);
        
        synchronized (get_Parent())
            {
            setItem(list.toArray());
            }
        }
    
    // Accessor for the property "RemoveCount"
    /**
    * Setter for property RemoveCount.<p>
    */
    protected void setRemoveCount(int pRemoveCount)
        {
        __m_RemoveCount = pRemoveCount;
        }
    }
