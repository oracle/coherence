/* Class
*     _package.component.util.Daemon
*/

package _package.component.util;

import com.tangosol.run.component.EventDeathException;
import com.tangosol.util.WrapperException;

public class Daemon
        extends    _package.component.Util
        implements java.lang.Runnable
    {
    // Fields declarations
    
    /**
    * Property AutoStart
    *
    * Specifies whether this Daemon component should start automatically at the
    * initialization time.
    * 
    * @see #onInit
    */
    private boolean __m_AutoStart;
    
    /**
    * Property Exiting
    *
    * Set to true when the daemon is instructed to stop.
    */
    private transient boolean __m_Exiting;
    
    /**
    * Property Lock
    *
    * An object that serves as a mutex for this Daemon synchronization. When
    * idle, the Daemon is waiting for a notification on the Lock object.
    * 
    * By default the Lock object is the Daemon itself.
    * 
    * @see #onNotify
    * @see #onWait
    */
    private transient Object __m_Lock;
    
    /**
    * Property Notification
    *
    * Specifes whether there is work for the daemon to do; if there is work,
    * Notification must evaluate to true, and if there is no work (implying
    * that the daemon should wait for work) then Notification must evaluate to
    * false.
    * 
    * To verify that a wait is necessary, the monitor on the Lock property is
    * first obtained and then Notification is evaluated; only if Notification
    * evaluates to false will the daemon go into a wait state on the Lock
    * property.
    * 
    * To unblock (notify) the daemon, another thread should set Notification to
    * true.
    * 
    * @see #onWait
    */
    private boolean __m_Notification;
    
    /**
    * Property Priority
    *
    * A non-zero value specifies the priority of the daemon's thread. A zero
    * value implies the Thread default priority.
    * 
    * Priority must be set before the Daemon is started (by the start method)
    * in order to have effect.
    */
    private int __m_Priority;
    
    /**
    * Property Started
    *
    * (Calculated) Specifies whether the daemon has been started.
    */
    
    /**
    * Property StartException
    *
    * The exception (if any) that prevented the daemon from starting
    * successfully.
    */
    private Throwable __m_StartException;
    
    /**
    * Property Thread
    *
    * The daemon thread if it is running, or null before the daemon starts and
    * after the daemon stops.
    */
    private Thread __m_Thread;
    
    /**
    * Property ThreadGroup
    *
    * Specifies the ThreadGroup within which the daemon thread will be created.
    * If not specified, the current Thread's ThreadGroup will be used.
    * 
    * This property can only be set at runtime, and must be configured before
    * start() is invoked to cause the daemon thread to be created within the
    * specified ThreadGroup.
    * 
    * @see java.lang.Thread
    * @see java.lang.ThreadGroup
    */
    private ThreadGroup __m_ThreadGroup;
    
    /**
    * Property ThreadName
    *
    * Specifies the name of the daemon thread. If not specified, the component
    * name will be used.
    * 
    * This property can be set at design time or runtime. If set at runtime,
    * this property must be configured before start() is invoked to cause the
    * daemon thread to have the specified name.
    */
    private String __m_ThreadName;
    
    /**
    * Property WaitMillis
    *
    * The number of milliseconds that the daemon will wait for notification.
    * Zero means to wait indefinitely.
    * 
    * @see onWait
    */
    private long __m_WaitMillis;
    
    // Default constructor
    public Daemon()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Daemon(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Daemon();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/Daemon".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    protected void finalize()
            throws java.lang.Throwable
        {
        try
            {
            stop();
            }
        catch (Throwable e)
            {
            }
        
        super.finalize();
        }
    
    // Accessor for the property "Lock"
    /**
    * Getter for property Lock.<p>
    * An object that serves as a mutex for this Daemon synchronization. When
    * idle, the Daemon is waiting for a notification on the Lock object.
    * 
    * By default the Lock object is the Daemon itself.
    * 
    * @see #onNotify
    * @see #onWait
    */
    public Object getLock()
        {
        Object oLock = __m_Lock;
        return oLock == null ? this : oLock;
        }
    
    // Accessor for the property "Priority"
    /**
    * Getter for property Priority.<p>
    * A non-zero value specifies the priority of the daemon's thread. A zero
    * value implies the Thread default priority.
    * 
    * Priority must be set before the Daemon is started (by the start method)
    * in order to have effect.
    */
    public int getPriority()
        {
        return __m_Priority;
        }
    
    // Accessor for the property "StartException"
    /**
    * Getter for property StartException.<p>
    * The exception (if any) that prevented the daemon from starting
    * successfully.
    */
    public Throwable getStartException()
        {
        return __m_StartException;
        }
    
    // Accessor for the property "Thread"
    /**
    * Getter for property Thread.<p>
    * The daemon thread if it is running, or null before the daemon starts and
    * after the daemon stops.
    */
    public Thread getThread()
        {
        return __m_Thread;
        }
    
    // Accessor for the property "ThreadGroup"
    /**
    * Getter for property ThreadGroup.<p>
    * Specifies the ThreadGroup within which the daemon thread will be created.
    * If not specified, the current Thread's ThreadGroup will be used.
    * 
    * This property can only be set at runtime, and must be configured before
    * start() is invoked to cause the daemon thread to be created within the
    * specified ThreadGroup.
    * 
    * @see java.lang.Thread
    * @see java.lang.ThreadGroup
    */
    public ThreadGroup getThreadGroup()
        {
        return __m_ThreadGroup;
        }
    
    // Accessor for the property "ThreadName"
    /**
    * Getter for property ThreadName.<p>
    * Specifies the name of the daemon thread. If not specified, the component
    * name will be used.
    * 
    * This property can be set at design time or runtime. If set at runtime,
    * this property must be configured before start() is invoked to cause the
    * daemon thread to have the specified name.
    */
    public String getThreadName()
        {
        String sName = __m_ThreadName;
        
        return sName == null ? get_Name() : sName;
        }
    
    // Accessor for the property "WaitMillis"
    /**
    * Getter for property WaitMillis.<p>
    * The number of milliseconds that the daemon will wait for notification.
    * Zero means to wait indefinitely.
    * 
    * @see onWait
    */
    public long getWaitMillis()
        {
        return __m_WaitMillis;
        }
    
    // Accessor for the property "AutoStart"
    /**
    * Getter for property AutoStart.<p>
    * Specifies whether this Daemon component should start automatically at the
    * initialization time.
    * 
    * @see #onInit
    */
    public boolean isAutoStart()
        {
        return __m_AutoStart;
        }
    
    // Accessor for the property "Exiting"
    /**
    * Getter for property Exiting.<p>
    * Set to true when the daemon is instructed to stop.
    */
    public boolean isExiting()
        {
        return __m_Exiting;
        }
    
    // Accessor for the property "Notification"
    /**
    * Getter for property Notification.<p>
    * Specifes whether there is work for the daemon to do; if there is work,
    * Notification must evaluate to true, and if there is no work (implying
    * that the daemon should wait for work) then Notification must evaluate to
    * false.
    * 
    * To verify that a wait is necessary, the monitor on the Lock property is
    * first obtained and then Notification is evaluated; only if Notification
    * evaluates to false will the daemon go into a wait state on the Lock
    * property.
    * 
    * To unblock (notify) the daemon, another thread should set Notification to
    * true.
    * 
    * @see #onWait
    */
    public boolean isNotification()
        {
        return __m_Notification;
        }
    
    // Accessor for the property "Started"
    /**
    * Getter for property Started.<p>
    * (Calculated) Specifies whether the daemon has been started.
    */
    public boolean isStarted()
        {
        return getThread() != null;
        }
    
    /**
    * Event notification called once the daemon's thread starts and before the
    * daemon thread goes into the "wait - perform" loop. Unlike the
    * <code>onInit()</code> event, this method executes on the daemon's thread.
    * 
    * Note1: this method is called while the caller's thread is still waiting
    * for a notification to  "unblock" itself.
    * Note2: any exception thrown by this method will terminate the thread
    * immediately
    */
    public void onEnter()
        {
        }
    
    /**
    * This event occurs when an exception is thrown from onEnter, onWait,
    * onNotify and onExit.
    * 
    * If the exception should terminate the daemon, call stop(). The default
    * implementation prints debugging information and terminates the daemon.
    * 
    * @param e  the Throwable object (a RuntimeException or an Error)
    * 
    * @throws RuntimeException may be thrown; will terminate the daemon
    * @throws Error may be thrown; will terminate the daemon
    */
    public void onException(Throwable e)
        {
        _trace("Terminating " + get_Name() + " due to unhandled exception:", 1);
        _trace(e);
        stop();
        }
    
    /**
    * Event notification called right before the daemon thread terminates. This
    * method is guranteed to be called only once and on the daemon's thread.
    */
    public void onExit()
        {
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        super.onInit();
        
        if (isAutoStart())
            {
            start();
            }
        }
    
    /**
    * Event notification called if the daemon's thread get interrupted.
    * 
    * @see #stop
    */
    public void onInterrupt()
        {
        }
    
    /**
    * Event notification to perform a regular daemon activity. To get it
    * called, another thread has to set Notification to true:
    * <code>daemon.setNotification(true);</code>
    * 
    * @see #onWait
    */
    public void onNotify()
        {
        }
    
    /**
    * Event notification called when  the daemon's Thread is waiting for work.
    * 
    * @see #run
    */
    public void onWait()
            throws java.lang.InterruptedException
        {
        Object o = getLock();
        synchronized (o)
            {
            if (!isNotification())
                {
                o.wait(getWaitMillis());
                }
            setNotification(false);
            }
        }
    
    // From interface: java.lang.Runnable
    /**
    * This method is called by the JVM right after this daemon's thread starts.
    * It must not be called directly.
    */
    public void run()
        {
        // import com.tangosol.run.component.EventDeathException;
        
        // run() must only be invoked on the daemon thread
        _assert(getThread() == Thread.currentThread(),
            "run() invoked on a different thread: " + Thread.currentThread());
        
        try
            {
            // any exception onEnter kills the thread
            try
                {
                onEnter();
                }
            catch (Throwable e)
                {
                setStartException(e);
                onException(e);
                }
        
            synchronized (this)
                {
                // the starting thread is waiting for this thread
                // (see start())
                notifyAll();
                }
        
            while (!isExiting())
                {
                try
                    {
                    onWait();
                    if (!isExiting())
                        {
                        onNotify();
                        }
                    }
                catch (EventDeathException e)
                    {
                    // a "normal" exception to "get out of" an event
                    }
                catch (InterruptedException e)
                    {
                    onInterrupt();
                    }
                catch (Throwable e)
                    {
                    onException(e);
                    }
                }
            }
        finally
            {
            synchronized (this)
                {
                try
                    {
                    onExit();
                    }
                catch (Throwable e)
                    {
                    onException(e);
                    }
                finally
                    {
                    setThread(null);
                    setExiting(false);
        
                    // just in case anyone is still waiting on this
                    // (in the case that onEnter threw an exception
                    // and then onException threw an exception, the
                    // thread that called start() will still be waiting)
                    notifyAll();
                    }
                }
            }
        // the thread terminates right here
        }
    
    // Accessor for the property "AutoStart"
    /**
    * Setter for property AutoStart.<p>
    * Specifies whether this Daemon component should start automatically at the
    * initialization time.
    * 
    * @see #onInit
    */
    public void setAutoStart(boolean fAutoStart)
        {
        __m_AutoStart = fAutoStart;
        }
    
    // Accessor for the property "Exiting"
    /**
    * Setter for property Exiting.<p>
    * Set to true when the daemon is instructed to stop.
    */
    protected void setExiting(boolean fExiting)
        {
        __m_Exiting = fExiting;
        }
    
    // Accessor for the property "Lock"
    /**
    * Setter for property Lock.<p>
    * An object that serves as a mutex for this Daemon synchronization. When
    * idle, the Daemon is waiting for a notification on the Lock object.
    * 
    * By default the Lock object is the Daemon itself.
    * 
    * @see #onNotify
    * @see #onWait
    */
    public void setLock(Object oLock)
        {
        __m_Lock = oLock;
        }
    
    // Accessor for the property "Notification"
    /**
    * Setter for property Notification.<p>
    * Specifes whether there is work for the daemon to do; if there is work,
    * Notification must evaluate to true, and if there is no work (implying
    * that the daemon should wait for work) then Notification must evaluate to
    * false.
    * 
    * To verify that a wait is necessary, the monitor on the Lock property is
    * first obtained and then Notification is evaluated; only if Notification
    * evaluates to false will the daemon go into a wait state on the Lock
    * property.
    * 
    * To unblock (notify) the daemon, another thread should set Notification to
    * true.
    * 
    * @see #onWait
    */
    public void setNotification(boolean fNotify)
        {
        if (is_Constructed())
            {
            Object oLock = getLock();
            synchronized (oLock)
                {
                __m_Notification = (fNotify);
        
                if (fNotify)
                    {
                    Thread thread = getThread();
                    if (thread != null && thread != Thread.currentThread())
                        {
                        oLock.notifyAll();
                        }
                    }
                }
            }
        else
            {
            __m_Notification = (fNotify);
            }
        }
    
    // Accessor for the property "Priority"
    /**
    * Setter for property Priority.<p>
    * A non-zero value specifies the priority of the daemon's thread. A zero
    * value implies the Thread default priority.
    * 
    * Priority must be set before the Daemon is started (by the start method)
    * in order to have effect.
    */
    public void setPriority(int nPriority)
        {
        __m_Priority = nPriority;
        }
    
    // Accessor for the property "StartException"
    /**
    * Setter for property StartException.<p>
    * The exception (if any) that prevented the daemon from starting
    * successfully.
    */
    public void setStartException(Throwable e)
        {
        __m_StartException = e;
        }
    
    // Accessor for the property "Thread"
    /**
    * Setter for property Thread.<p>
    * The daemon thread if it is running, or null before the daemon starts and
    * after the daemon stops.
    */
    protected void setThread(Thread thread)
        {
        __m_Thread = thread;
        }
    
    // Accessor for the property "ThreadGroup"
    /**
    * Setter for property ThreadGroup.<p>
    * Specifies the ThreadGroup within which the daemon thread will be created.
    * If not specified, the current Thread's ThreadGroup will be used.
    * 
    * This property can only be set at runtime, and must be configured before
    * start() is invoked to cause the daemon thread to be created within the
    * specified ThreadGroup.
    * 
    * @see java.lang.Thread
    * @see java.lang.ThreadGroup
    */
    public void setThreadGroup(ThreadGroup group)
        {
        __m_ThreadGroup = group;
        }
    
    // Accessor for the property "ThreadName"
    /**
    * Setter for property ThreadName.<p>
    * Specifies the name of the daemon thread. If not specified, the component
    * name will be used.
    * 
    * This property can be set at design time or runtime. If set at runtime,
    * this property must be configured before start() is invoked to cause the
    * daemon thread to have the specified name.
    */
    public void setThreadName(String sName)
        {
        __m_ThreadName = sName;
        }
    
    // Accessor for the property "WaitMillis"
    /**
    * Setter for property WaitMillis.<p>
    * The number of milliseconds that the daemon will wait for notification.
    * Zero means to wait indefinitely.
    * 
    * @see onWait
    */
    public void setWaitMillis(long cMillis)
        {
        __m_WaitMillis = cMillis;
        }
    
    /**
    * Starts the daemon thread associated with this component. If the thread is
    * already starting or has started, invoking this method has no effect.
    * 
    * Synchronization is used here to verify that the start of the thread
    * occurs; the lock is obtained before the thread is started, and the daemon
    * thread notifies back that it has started from the run() method.
    */
    public synchronized void start()
        {
        // import com.tangosol.util.WrapperException;
        
        if (isStarted())
            {
            return;
            }
        
        Thread thread = new Thread(getThreadGroup(), this, getThreadName());
        thread.setDaemon(true);
        int nPriority = getPriority();
        if (nPriority != 0)
            {
            thread.setPriority(nPriority);
            }
        setThread(thread);
        
        // start the thread
        setStartException(null);
        thread.start();
        
        // wait for the thread to enter its "wait for notification" section
        try
            {
            wait();
            }
        catch (InterruptedException e)
            {
            }
        
        Throwable e = getStartException();
        if (e != null)
            {
            setStartException(null);
        
            // throw a WrapperException so that the exception comes
            // from the current thread -- the one that called start() --
            // but still displays the information about what killed
            // the daemon thread
            throw new WrapperException(e);
            }
        }
    
    /**
    * Stops the daemon thread associated with this component.
    */
    public synchronized void stop()
        {
        if (isStarted())
            {
            setExiting(true);
        
            Thread thread = getThread();
            if (thread != null && thread != Thread.currentThread())
                {
                try
                    {
                    thread.interrupt();
                    }
                catch (Throwable e)
                    {
                    }
                }
            }
        }
    }
