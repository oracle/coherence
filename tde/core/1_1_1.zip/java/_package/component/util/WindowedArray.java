/* Class
*     _package.component.util.WindowedArray
*/

package _package.component.util;

/**
* A WindowedArray is an object that has attributes of a queue and a dynamically
* resizing array.
* 
* The "window" is the active, or visible, portion of the virtual array. Only
* elements within the window may be accessed or removed.
* 
* As elements are added, they are added to the "end" or "top" of the array,
* dynamically resizing if necessary, and adjusting the window so that it
* includes the new elements.
* 
* As items are removed, if they are removed from the "start" or "bottom" of the
* array, the window adjusts such that those elements are no longer visible.
*/
public class WindowedArray
        extends    _package.component.Util
    {
    // Fields declarations
    
    /**
    * Property Capacity
    *
    */
    
    /**
    * Property FirstIndex
    *
    */
    private long __m_FirstIndex;
    
    /**
    * Property InitialCapacity
    *
    */
    
    /**
    * Property LastIndex
    *
    */
    
    /**
    * Property MaximumCapacity
    *
    */
    
    /**
    * Property REMOVED
    *
    */
    protected static final Object REMOVED;
    
    /**
    * Property Size
    *
    */
    
    /**
    * Property Store
    *
    */
    private Object[] __m_Store;
    
    /**
    * Property WindowIndex
    *
    */
    private int __m_WindowIndex;
    
    /**
    * Property WindowSize
    *
    */
    private int __m_WindowSize;
    
    // Static initializer
    static
        {
        try
            {
            REMOVED = new java.lang.Object();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public WindowedArray()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public WindowedArray(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant InitialCapacity
    public int getInitialCapacity()
        {
        return 32;
        }
    
    // Getter for virtual constant MaximumCapacity
    public int getMaximumCapacity()
        {
        return 16777216;
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new WindowedArray();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/WindowedArray".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    public long add(Object o)
        {
        long iVirtual = getSize();
        int  iActual  = ensureIndex(iVirtual);
        getStore()[iActual] = o;
        return iVirtual;
        }
    
    protected int ensureIndex(long i)
        {
        long iFirst = getFirstIndex();
        if (i < iFirst)
            {
            // the virtual array cannot grow the window backwards
            throw new IndexOutOfBoundsException("window cannot grow backwards (index=" + i + ", window first index=" + iFirst + ")");
            }
        
        long iLast = getLastIndex();
        if (i > iLast)
            {
            // the index is out of bounds of the window; start by
            // making sure it is in bounds of the actual Store
            int cCurrentCapacity = getCapacity();
            int cNewElements     = ((int) (i - iFirst)) + 1;
            if (cNewElements > cCurrentCapacity)
                {
                int cNewCapacity = cCurrentCapacity * 2;
                int cMaxCapacity = getMaximumCapacity();
                if (cNewCapacity > cMaxCapacity)
                    {
                    if (cCurrentCapacity == cMaxCapacity)
                        {
                        throw new IndexOutOfBoundsException("max capacity exceeded (index=" + i + ", max capacity=" + cMaxCapacity + ")");
                        }
                    cNewCapacity = cMaxCapacity;
                    }
        
                Object[] aoOld = getStore();
                Object[] aoNew = new Object[cNewCapacity];
        
                int iStart    = getWindowIndex();
                int cElements = getWindowSize();
                int iEnd      = iStart + cElements - 1;
                if (iEnd >= cCurrentCapacity)
                    {
                    // the virtual array is "wrapped" around the end
                    // of the real array
                    int cPrewrapElements  = cCurrentCapacity - iStart;
                    int cPostwrapElements = iEnd - cCurrentCapacity + 1;
                    System.arraycopy(aoOld, iStart, aoNew, 0, cPrewrapElements);
                    System.arraycopy(aoOld, 0, aoNew, cPrewrapElements, cPostwrapElements);
                    }
                else
                    {
                    System.arraycopy(aoOld, iStart, aoNew, 0, cElements);
                    }
        
                setStore(aoNew);
                setWindowIndex(0);
                }
        
            // resize the window to include the new index
            setWindowSize(cNewElements);
            }
        
        return translateIndex(i);
        }
    
    public Object get(long i)
        {
        if (i < 0L)
            {
            throw new IndexOutOfBoundsException("negative index is illegal: " + i);
            }
        
        // if the index is out of the range of the window, then the
        // value is null (there is no exception)
        if (i < getFirstIndex() || i > getLastIndex())
            {
            return null;
            }
        
        Object o = getStore()[translateIndex(i)];
        return o == REMOVED ? null : o;
        }
    
    // Accessor for the property "Capacity"
    /**
    * Getter for property Capacity.<p>
    */
    public int getCapacity()
        {
        return getStore().length;
        }
    
    // Accessor for the property "FirstIndex"
    /**
    * Getter for property FirstIndex.<p>
    */
    public long getFirstIndex()
        {
        return __m_FirstIndex;
        }
    
    // Accessor for the property "LastIndex"
    /**
    * Getter for property LastIndex.<p>
    */
    public long getLastIndex()
        {
        return getSize() - 1;
        }
    
    // Accessor for the property "Size"
    /**
    * Getter for property Size.<p>
    */
    public long getSize()
        {
        return getFirstIndex() + getWindowSize();
        }
    
    // Accessor for the property "Store"
    /**
    * Getter for property Store.<p>
    */
    protected Object[] getStore()
        {
        return __m_Store;
        }
    
    // Accessor for the property "WindowIndex"
    /**
    * Getter for property WindowIndex.<p>
    */
    protected int getWindowIndex()
        {
        return __m_WindowIndex;
        }
    
    // Accessor for the property "WindowSize"
    /**
    * Getter for property WindowSize.<p>
    */
    public int getWindowSize()
        {
        return __m_WindowSize;
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        super.onInit();
        
        setStore(new Object[getInitialCapacity()]);
        }
    
    public Object remove(long i)
        {
        if (i < 0L)
            {
            throw new IndexOutOfBoundsException("negative index is illegal: " + i);
            }
        
        long iFirst = getFirstIndex();
        if (i < iFirst)
            {
            // already removed
            return null;
            }
        
        long iLast = getLastIndex();
        if (i > iLast)
            {
            // not added yet
            throw new IndexOutOfBoundsException("cannot remove beyond window (index=" + i + ", window last index=" + iLast + ")");
            }
        
        // remove the stored value
        Object[] aoElement = getStore();
        int      iActual   = translateIndex(i);
        Object   oOrig     = aoElement[iActual];
        aoElement[iActual] = REMOVED;
        
        if (i == iFirst)
            {
            // _assert(iActual == getWindowIndex());
        
            // remove all contiguous REMOVED elements
            int iWindowIndex    = iActual;
            int cWindowElements = getWindowSize();
            while (cWindowElements > 0)
                {
                iActual = iWindowIndex;
                if (aoElement[iActual] != REMOVED)
                    {
                    break;
                    }
        
                // drop this element from the window
                aoElement[iActual] = null;
        
                // update the window index/location/extent
                ++iFirst;
                iWindowIndex = translateIndex(iFirst);
                --cWindowElements;
                }
        
            // store the new window location / extent
            setFirstIndex(iFirst);
            setWindowIndex(iWindowIndex);
            setWindowSize(cWindowElements);
            }
        
        return oOrig == REMOVED ? null : oOrig;
        }
    
    public Object set(long i, Object o)
        {
        if (i < 0L)
            {
            throw new IndexOutOfBoundsException("negative index is illegal: " + i);
            }
        
        int iActual = ensureIndex(i);
        Object[] ao = getStore();
        Object oOrig = ao[iActual];
        ao[iActual] = o;
        return oOrig == REMOVED ? null : oOrig;
        }
    
    // Accessor for the property "FirstIndex"
    /**
    * Setter for property FirstIndex.<p>
    */
    protected void setFirstIndex(long i)
        {
        __m_FirstIndex = i;
        }
    
    // Accessor for the property "Store"
    /**
    * Setter for property Store.<p>
    */
    protected void setStore(Object[] ao)
        {
        __m_Store = ao;
        }
    
    // Accessor for the property "WindowIndex"
    /**
    * Setter for property WindowIndex.<p>
    */
    protected void setWindowIndex(int i)
        {
        __m_WindowIndex = i;
        }
    
    // Accessor for the property "WindowSize"
    /**
    * Setter for property WindowSize.<p>
    */
    protected void setWindowSize(int c)
        {
        __m_WindowSize = c;
        }
    
    // Declared at the super level
    public String toString()
        {
        StringBuffer sb = new StringBuffer();
        
        sb.append("WindowedArray[capacity=")
          .append(getCapacity())
          .append(", size=")
          .append(getSize())
          .append(", windowindex=")
          .append(getWindowIndex())
          .append(", windowsize=")
          .append(getWindowSize())
          .append(", firstindex=")
          .append(getFirstIndex())
          .append(", lastindex=")
          .append(getLastIndex())
          .append(']');
          
        long iFirst = getFirstIndex();
        long iLast  = getLastIndex();
        for (long i = iFirst; i <= iLast; ++i)
            {
            sb.append("\n[")
              .append(i)
              .append("]=\"")
              .append(get(i))
              .append('\"');
            }
        
        return sb.toString();
        }
    
    protected int translateIndex(long i)
        {
        // WindowIndex is the index of the 0th element in the window,
        // which is the location of the FirstIndex element of the
        // virtual array; the virtual array may "wrap" around the end
        // of the Store array
        return (getWindowIndex() + ((int) (i - getFirstIndex()))) % getCapacity();
        }
    }
