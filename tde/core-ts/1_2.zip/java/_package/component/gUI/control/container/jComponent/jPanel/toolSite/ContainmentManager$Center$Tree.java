/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.toolSite.ContainmentManager$Center$Tree
*/

package _package.component.gUI.control.container.jComponent.jPanel.toolSite;

import _package.component.gUI.Font;
import _package.component.gUI.TreeNode;
import _package.component.gUI.image.Icon;
import _package.component.gUI.treeNode.SimpleNode;
import _package.component.gUI.treeNode.cDTraitNode.CDComponentNode;
import com.tangosol.dev.component.Component;
import java.awt.Font; // as _Font
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DragSource;
import java.awt.event.KeyEvent;
import java.beans.PropertyVetoException;
import javax.swing.tree.DefaultTreeCellRenderer;

public class ContainmentManager$Center$Tree
        extends    _package.component.gUI.control.container.jComponent.JTree
    {
    // Fields declarations
    
    /**
    * Property DraggingNode
    *
    * (Privately used) Specifies a child node that is being dragged (moved or
    * copied).
    */
    private transient _package.component.gUI.TreeNode __m_DraggingNode;
    
    /**
    * Property IconAbstract
    *
    * A holder for an "abstract component" icon used by onCellRendering
    */
    private _package.component.gUI.image.Icon __m_IconAbstract;
    
    /**
    * Property IconCategory
    *
    * A holder for an "category" icon used by onCellRendering
    */
    private _package.component.gUI.image.Icon __m_IconCategory;
    
    /**
    * Property IconPublicDeclared
    *
    * A holder for a "public declared at this level component" icon used by
    * onCellRendering
    */
    private _package.component.gUI.image.Icon __m_IconPublicDeclared;
    
    /**
    * Property IconPublicInherited
    *
    * A holder for a "public inherited child" icon used by onCellRendering
    */
    private _package.component.gUI.image.Icon __m_IconPublicInherited;
    
    /**
    * Property IconPublicStatic
    *
    * A holder for a "public static child" icon used by onCellRendering
    */
    private _package.component.gUI.image.Icon __m_IconPublicStatic;
    
    /**
    * Property IconRemote
    *
    * A holder for a "remote component" icon used by onCellRendering
    */
    private _package.component.gUI.image.Icon __m_IconRemote;
    
    /**
    * Property IconRemoved
    *
    * A holder for a "removed child" icon used by onCellRendering
    */
    private _package.component.gUI.image.Icon __m_IconRemoved;
    
    // Default constructor
    public ContainmentManager$Center$Tree()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ContainmentManager$Center$Tree(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAutoscrolls(true);
            setClosedIcon(null);
            setDropActions(2);
            setDropAllowed(true);
            setEditable(true);
            setFocusable(true);
            setInvokePopup(1);
            setInvokesStopCellEditing(false);
            setLargeModel(false);
            setLeafIcon(null);
            setOpenIcon(null);
            setRedraw(true);
            setRootVisible(false);
            setRowHeight(16);
            setScrollable(true);
            setScrollsOnExpand(true);
            setSelectionMode(1);
            setSeparator('$');
            setShowsRootHandles(true);
            setSorted(true);
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new ContainmentManager$Center$Tree$Context("Context", this, true), "Context");
        _addChild(new _package.component.gUI.control.container.jComponent.JTree$KeyCollapse("KeyCollapse", this, true), "KeyCollapse");
        _addChild(new ContainmentManager$Center$Tree$KeyDelete("KeyDelete", this, true), "KeyDelete");
        _addChild(new _package.component.gUI.control.container.jComponent.JTree$KeyExpand("KeyExpand", this, true), "KeyExpand");
        _addChild(new _package.component.gUI.control.container.jComponent.JTree$KeyExpandAll("KeyExpandAll", this, true), "KeyExpandAll");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ContainmentManager$Center$Tree();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/toolSite/ContainmentManager$Center$Tree".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent();
        }
    
    // Declared at the super level
    public void dragExit(java.awt.dnd.DropTargetEvent dte)
        {
        // import com.tangosol.dev.component.Component;
        
        Component cd = (($Module) get_Module()).getComponent();
        if (cd != null)
            {
            setSelectionNode(findNode(cd));
            }
        
        super.dragExit(dte);
        }
    
    // Accessor for the property "DraggingNode"
    /**
    * Getter for property DraggingNode.<p>
    * (Privately used) Specifies a child node that is being dragged (moved or
    * copied).
    */
    private _package.component.gUI.TreeNode getDraggingNode()
        {
        return __m_DraggingNode;
        }
    
    // Accessor for the property "IconAbstract"
    /**
    * Getter for property IconAbstract.<p>
    * A holder for an "abstract component" icon used by onCellRendering
    */
    public _package.component.gUI.image.Icon getIconAbstract()
        {
        return __m_IconAbstract;
        }
    
    // Accessor for the property "IconCategory"
    /**
    * Getter for property IconCategory.<p>
    * A holder for an "category" icon used by onCellRendering
    */
    public _package.component.gUI.image.Icon getIconCategory()
        {
        return __m_IconCategory;
        }
    
    // Accessor for the property "IconPublicDeclared"
    /**
    * Getter for property IconPublicDeclared.<p>
    * A holder for a "public declared at this level component" icon used by
    * onCellRendering
    */
    public _package.component.gUI.image.Icon getIconPublicDeclared()
        {
        return __m_IconPublicDeclared;
        }
    
    // Accessor for the property "IconPublicInherited"
    /**
    * Getter for property IconPublicInherited.<p>
    * A holder for a "public inherited child" icon used by onCellRendering
    */
    public _package.component.gUI.image.Icon getIconPublicInherited()
        {
        return __m_IconPublicInherited;
        }
    
    // Accessor for the property "IconPublicStatic"
    /**
    * Getter for property IconPublicStatic.<p>
    * A holder for a "public static child" icon used by onCellRendering
    */
    public _package.component.gUI.image.Icon getIconPublicStatic()
        {
        return __m_IconPublicStatic;
        }
    
    // Accessor for the property "IconRemote"
    /**
    * Getter for property IconRemote.<p>
    * A holder for a "remote component" icon used by onCellRendering
    */
    public _package.component.gUI.image.Icon getIconRemote()
        {
        return __m_IconRemote;
        }
    
    // Accessor for the property "IconRemoved"
    /**
    * Getter for property IconRemoved.<p>
    * A holder for a "removed child" icon used by onCellRendering
    */
    public _package.component.gUI.image.Icon getIconRemoved()
        {
        return __m_IconRemoved;
        }
    
    // Accessor for the property "DropAllowed"
    /**
    * Getter for property DropAllowed.<p>
    * Specifies whether this component allows "Dropping" into (i.e. being a
    * DropTarget)
    */
    private boolean isDropAllowed(_package.component.gUI.TreeNode nodeOrg, _package.component.gUI.TreeNode nodeDst, boolean fCopy)
        {
        // import Component.GUI.TreeNode.CDTraitNode.CDComponentNode;
        // import com.tangosol.dev.component.Component;
        
        if (nodeOrg instanceof CDComponentNode &&
            nodeDst instanceof CDComponentNode &&
            nodeOrg != nodeDst)
            {
            Component cdOrg = ((CDComponentNode) nodeOrg).getComponent();
            Component cdDst = ((CDComponentNode) nodeDst).getComponent();
        
            // "move" is only allowed at the declaration level
            if (!cdOrg.isGlobal())
                {
                return fCopy
                       || cdOrg.isDeclaredAtThisLevel()
                          && cdOrg.getParent() != cdDst;
                }
            }
        
        return false;
        }
    
    // Declared at the super level
    public void onCellRendering(java.awt.Component compRenderer, _package.component.gUI.TreeNode node, boolean hasFocus)
        {
        // import Component.GUI.Font;
        // import Component.GUI.Image.Icon;
        // import Component.GUI.TreeNode.CDTraitNode.CDComponentNode;
        // import Component.GUI.TreeNode.SimpleNode;
        // import com.tangosol.dev.component.Component;
        // import java.awt.Font as _Font;
        // import javax.swing.tree.DefaultTreeCellRenderer;
        
        super.onCellRendering(compRenderer, node, hasFocus);
        
        boolean fBold   = false;
        boolean fItalic = false;
        boolean fIcon   = (($Module) get_Module()).isShowIcons();
        Icon    icon    = null;
        
        if (node instanceof CDComponentNode)
            {
            CDComponentNode nodeCD = (CDComponentNode) node;
            Component       cd     = nodeCD.getComponent();
            
            fBold   = !nodeCD.isDiscardable();
        
            if (fIcon)
                {
                if (cd.isResultAbstract())
                    {
                    icon = getIconAbstract();
                    }
                else if (cd.isRemote())
                    {
                    icon = getIconRemote();
                    }
                else if (cd.isStatic())
                    {
                    icon = getIconPublicStatic();
                    }
                else
                    {
                    icon = cd.isGlobal() ? null :
                           cd.isDeclaredAtThisLevel() ?
                                getIconPublicDeclared() : getIconPublicInherited();
        
                    /*
                    boolean fDecl = cd.isDeclaredAtThisLevel();
        
                    switch (cd.getAccess())
                        {
                        default:
                        case Constants.ACCESS_PUBLIC:
                            icon = fDecl ? getIconPublicDeclared() : getIconPublicInherited();
                            break;
                        case Constants.ACCESS_PROTECTED:
                            icon = fDecl ? getIconProtectedDeclared() : getIconProtectedInherited();
                            break;
                        case Constants.ACCESS_PRIVATE:
                            icon = getIconPrivate();
                            break;
                        }
                    */
                    }
                }
            }
        else if (node instanceof SimpleNode)
            {
            boolean fCategory = ((SimpleNode) node).getReference() != null;
        
            if (fIcon)
                {
                icon = fCategory ? getIconCategory() : getIconRemoved();
                }
            fItalic = fCategory;
            }
        
        _Font _font = compRenderer.getFont();
        if (_font == null || _font.isBold() != fBold || _font.isItalic() != fItalic)
            {
            Font font = getFont();
            font.setBold(fBold);
            font.setItalic(fItalic);
            compRenderer.setFont(font.get_Font());
            }
        
        if (node.isLeaf())
            {
            ((DefaultTreeCellRenderer) compRenderer).setLeafIcon(icon);
            }
        else if (node.isExpanded())
            {
            ((DefaultTreeCellRenderer) compRenderer).setOpenIcon(icon);
            }
        else
            {
            ((DefaultTreeCellRenderer) compRenderer).setClosedIcon(icon);
            }    
        }
    
    // Declared at the super level
    /**
    * Notification message called when editing process gets ended for the
    * specified node.
    * 
    * Derived classes are responsible for pulling the new value out of
    * "node.getUserObject()" and setting the corresponding values of derived
    * TreeNode(s). Otherwise the new value will be lost.
    * 
    * @see #editingStoped
    */
    public void onEditingStopped(_package.component.gUI.TreeNode node, Object oNewValue)
        {
        // import Component.GUI.TreeNode.CDTraitNode.CDComponentNode;
        // import com.tangosol.dev.component.Component;
        // import java.beans.PropertyVetoException;
        
        super.onEditingStopped(node, oNewValue);
        
        _assert (node instanceof CDComponentNode);
        
        Component cd = ((CDComponentNode) node).getComponent();
        try
            {
            cd.setName((String) oNewValue);
            }
        catch (PropertyVetoException e)
            {
            _beep();
            }
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import Component.GUI.Image.Icon;
        
        super.onInit();
        
        // TODO: remove after the composite properties are implemented
        setIconAbstract          (new Icon.Abstract());
        setIconCategory          (new Icon.Category());
        setIconRemoved           (new Icon.Removed());
        setIconPublicDeclared    (new Icon.PublicD());
        setIconPublicInherited   (new Icon.PublicI());
        setIconPublicStatic      (new Icon.PublicS());
        setIconRemote            (new Icon.Remote());
        }
    
    // Declared at the super level
    public void onKeyPressed(char keyChar, int keyCode, int modifiers)
        {
        // import java.awt.dnd.DragSource;
        // import java.awt.event.KeyEvent;
        
        super.onKeyPressed(keyChar, keyCode, modifiers);
        
        if (keyCode == KeyEvent.VK_CONTROL &&
            get_Cursor() == DragSource.DefaultMoveDrop)
            {
            set_Cursor(DragSource.DefaultCopyDrop);
            }

        }
    
    // Declared at the super level
    public void onKeyReleased(char keyChar, int keyCode, int modifiers)
        {
        // import java.awt.dnd.DragSource;
        // import java.awt.event.KeyEvent;
        
        super.onKeyReleased(keyChar, keyCode, modifiers);
        
        if (keyCode == KeyEvent.VK_CONTROL &&
            get_Cursor() == DragSource.DefaultCopyDrop)
            {
            set_Cursor(DragSource.DefaultMoveDrop);
            }
        }
    
    // Declared at the super level
    public void onMouseClicked(_package.component.gUI.Point point, int modifiers, int clickCount)
        {
        super.onMouseClicked(point, modifiers, clickCount);
        
        if (clickCount == 2)
            {
            $East East = ($East) _findName("East");
            East.setVisible(!East.isVisible());
            East.adjustFrame();
            }
        }
    
    // Declared at the super level
    public void onMouseDragged(_package.component.gUI.Point point, int modifiers)
        {
        // import Component.GUI.TreeNode;
        // import java.awt.dnd.DragSource;
        
        super.onMouseDragged(point, modifiers);
        
        if (isEditable())
            {
            // see onMousePressed
            return;
            }
        
        TreeNode nodeOrg = getDraggingNode();
        TreeNode nodeDst = getNodeForLocation(point);
        boolean  fCopy   = (modifiers & java.awt.Event.CTRL_MASK) != 0;
        
        if (nodeOrg == null)
            {
            nodeOrg = getSelectionNode();
            setDraggingNode(nodeOrg);
            }
        
        if (isDropAllowed(nodeOrg, nodeDst, fCopy))
            {
            // TODO: draw intension
            set_Cursor(fCopy ?
                DragSource.DefaultCopyDrop : DragSource.DefaultMoveDrop);    
            }
        else
            {
            set_Cursor(fCopy ?
                DragSource.DefaultCopyNoDrop : DragSource.DefaultMoveNoDrop);
            }
        }
    
    // Declared at the super level
    public void onMousePressed(_package.component.gUI.Point point, int modifiers, int clickCount, boolean popupTrigger)
        {
        // prevent entering "edit" mode during the drag by making the
        // entire tree non-editable
        if (!popupTrigger)
            {
            setEditable(false);
            }
        
        super.onMousePressed(point, modifiers, clickCount, popupTrigger);

        }
    
    // Declared at the super level
    public void onMouseReleased(_package.component.gUI.Point point, int modifiers, int clickCount, boolean popupTrigger)
        {
        // import Component.GUI.TreeNode;
        // import Component.GUI.TreeNode.CDTraitNode.CDComponentNode;
        // import com.tangosol.dev.component.Component;
        
        setEditable(true);
        
        super.onMouseReleased(point, modifiers, clickCount, popupTrigger);
        
        set_Cursor(java.awt.Cursor.getDefaultCursor());
        
        TreeNode nodeOrg = getDraggingNode();
        TreeNode nodeDst = getNodeForLocation(point);
        boolean  fCopy   = (modifiers & java.awt.Event.CTRL_MASK) != 0;
        
        setDraggingNode(null);
        
        if (isDropAllowed(nodeOrg, nodeDst, fCopy))
            {
            Component cdChild  = ((CDComponentNode) nodeOrg).getComponent();
            Component cdParent = ((CDComponentNode) nodeDst).getComponent();
        
            Component cdCopy   = (($Module) get_Module()).getContainmentTool().
                    copyComponent(cdParent, cdChild, fCopy);
            if (cdCopy != null)
                {
                (($Module) get_Module()).setComponent(cdCopy);
                }
            else
                {
                _beep();
                }   
            }
        }
    
    // Declared at the super level
    public void onSelected(_package.component.gUI.TreeNode node)
        {
        // import Component.GUI.TreeNode.CDTraitNode.CDComponentNode;
        // import com.tangosol.dev.component.Component;
        
        super.onSelected(node);
        
        if (isDnDDroppingActive())
            {
            return;
            }
        
        Component cd = null;
        
        if (node instanceof CDComponentNode)
            {
            cd = ((CDComponentNode) node).getComponent();
            (($Module) get_Module()).getContainmentTool().setLocalCD(cd);
            }
        
        (($Module) get_Module()).setComponent(cd);

        }
    
    // Declared at the super level
    /**
    * Prepares to transfer something at the specified location for the
    * specified action
    * 
    * @return true if transfer is going to be accepted; false otherwise
    * 
    * @see dragOver()
    */
    protected boolean prepareTransferAtLocation(_package.component.gUI.Point point, int iAction, java.util.List listFlavors)
        {
        // import Component.GUI.TreeNode;
        // import Component.GUI.TreeNode.CDTraitNode.CDComponentNode;
        
        $Module Manager = ($Module) get_Module();
        
        if (!super.prepareTransferAtLocation(point, iAction, listFlavors))
            {
            return false;
            }
        // TODO: check listFlavors for either "Component Name" or "Behavior"
        
        if (!Manager.getTool().isActive())
            {
            Manager.moveToFront();
            }
        
        TreeNode node = getNodeForLocation(point);
        if (!(node instanceof CDComponentNode))
            {
            return false;
            }
        
        return ((CDComponentNode) node).getComponent().isModifiable();
        }
    
    // Declared at the super level
    /**
    * Puts (drops) the specified Transferable object at the specified location
    * for the specified action
    * 
    * @return true if transfer is accepted; false otherwise
    * 
    * @see drop()
    */
    protected boolean putTransferAtLocation(java.awt.datatransfer.Transferable transfer, _package.component.gUI.Point point, int iAction)
        {
        // import Component.GUI.TreeNode;
        // import Component.GUI.TreeNode.CDTraitNode.CDComponentNode;
        // import com.tangosol.dev.component.Component;
        // import java.awt.datatransfer.DataFlavor;
        
        TreeNode node = getNodeForLocation(point);
        if (!(node instanceof CDComponentNode))
            {
            return false;
            }
        
        setSelectionNode(node); // in turn calls "onSelected()"
        
        String sSuper = null;
        try
            {
            if (transfer.isDataFlavorSupported(DataFlavor.stringFlavor))
                {    
                sSuper = (String) transfer.getTransferData(DataFlavor.stringFlavor);
                }
            }
        // UnsupportedFlavorException, IOException
        catch (Exception e)
            {
            _trace("transfer failed " + e, 1);
            return false;
            }
        
        if (sSuper != null)
            {
            (($Module) get_Module()).insertComponent(sSuper);
            }
        return true;
        }
    
    // Accessor for the property "DraggingNode"
    /**
    * Setter for property DraggingNode.<p>
    * (Privately used) Specifies a child node that is being dragged (moved or
    * copied).
    */
    private void setDraggingNode(_package.component.gUI.TreeNode pDraggingNode)
        {
        __m_DraggingNode = pDraggingNode;
        }
    
    // Accessor for the property "IconAbstract"
    /**
    * Setter for property IconAbstract.<p>
    * A holder for an "abstract component" icon used by onCellRendering
    */
    public void setIconAbstract(_package.component.gUI.image.Icon pIconAbstract)
        {
        __m_IconAbstract = pIconAbstract;
        }
    
    // Accessor for the property "IconCategory"
    /**
    * Setter for property IconCategory.<p>
    * A holder for an "category" icon used by onCellRendering
    */
    public void setIconCategory(_package.component.gUI.image.Icon pIconCategory)
        {
        __m_IconCategory = pIconCategory;
        }
    
    // Accessor for the property "IconPublicDeclared"
    /**
    * Setter for property IconPublicDeclared.<p>
    * A holder for a "public declared at this level component" icon used by
    * onCellRendering
    */
    public void setIconPublicDeclared(_package.component.gUI.image.Icon pIconPublicDeclared)
        {
        __m_IconPublicDeclared = pIconPublicDeclared;
        }
    
    // Accessor for the property "IconPublicInherited"
    /**
    * Setter for property IconPublicInherited.<p>
    * A holder for a "public inherited child" icon used by onCellRendering
    */
    public void setIconPublicInherited(_package.component.gUI.image.Icon pIconPublicInherited)
        {
        __m_IconPublicInherited = pIconPublicInherited;
        }
    
    // Accessor for the property "IconPublicStatic"
    /**
    * Setter for property IconPublicStatic.<p>
    * A holder for a "public static child" icon used by onCellRendering
    */
    public void setIconPublicStatic(_package.component.gUI.image.Icon pIconPublicStatic)
        {
        __m_IconPublicStatic = pIconPublicStatic;
        }
    
    // Accessor for the property "IconRemote"
    /**
    * Setter for property IconRemote.<p>
    * A holder for a "remote component" icon used by onCellRendering
    */
    public void setIconRemote(_package.component.gUI.image.Icon pIconRemote)
        {
        __m_IconRemote = pIconRemote;
        }
    
    // Accessor for the property "IconRemoved"
    /**
    * Setter for property IconRemoved.<p>
    * A holder for a "removed child" icon used by onCellRendering
    */
    public void setIconRemoved(_package.component.gUI.image.Icon pIconRemoved)
        {
        __m_IconRemoved = pIconRemoved;
        }
    }
