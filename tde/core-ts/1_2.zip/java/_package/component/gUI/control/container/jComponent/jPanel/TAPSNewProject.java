/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.TAPSNewProject
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.dev.project.ProjectInfo$Target; // as Target
import _package.component.dev.project.ProjectInfo;
import _package.component.dev.project.StorageFactory;
import com.tangosol.util.Base;
import java.util.Date;

public class TAPSNewProject
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    // Default constructor
    public TAPSNewProject()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPSNewProject(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(false);
            setTBounds("0,0,415,205");
            setTConstraints("Center");
            setTIcon("TAPS");
            setTitle("New Project");
            setTLayout(null);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new TAPSNewProject$CB_Cancel("CB_Cancel", this, true), "CB_Cancel");
        _addChild(new TAPSNewProject$CB_OK("CB_OK", this, true), "CB_OK");
        _addChild(new TAPSNewProject$CBX_BasePrj("CBX_BasePrj", this, true), "CBX_BasePrj");
        _addChild(new TAPSNewProject$LBL_BasePrj("LBL_BasePrj", this, true), "LBL_BasePrj");
        _addChild(new TAPSNewProject$LBL_BaseVer("LBL_BaseVer", this, true), "LBL_BaseVer");
        _addChild(new TAPSNewProject$LBL_Description("LBL_Description", this, true), "LBL_Description");
        _addChild(new TAPSNewProject$LBL_Name("LBL_Name", this, true), "LBL_Name");
        _addChild(new TAPSNewProject$TXT_BaseVer("TXT_BaseVer", this, true), "TXT_BaseVer");
        _addChild(new TAPSNewProject$TXT_Descr("TXT_Descr", this, true), "TXT_Descr");
        _addChild(new TAPSNewProject$TXT_Name("TXT_Name", this, true), "TXT_Name");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new TAPSNewProject();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/TAPSNewProject".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Ends a dialog, setting the specified result of the DailogBox. The
    * conventions for the result value are:
    * Value of null means the canceled action. Value of Boolean.TRUE means the
    * default action and then the DialogBox result value is set as follows:
    * if the panel implements XmlSerializable then the result is set to the
    * appropriate XML value; otherwise the result value is set to the Config
    * object.
    * 
    * @param oResult the result value of the dialiog box with this main panel
    * 
    * @see DialogParam property
    * @see JButton.DefaultButton#onAction
    * @see JButton.EscapeButton#onAction
    */
    public void endDialog(Object oResult)
        {
        // import Component.Dev.Project.ProjectInfo;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Project.StorageFactory;
        // import com.tangosol.util.Base;
        
        import javax.swing.JOptionPane;
        
        Object[] aoParam = (Object[]) getDialogParam();
        if (aoParam != null && oResult == Boolean.TRUE)
            {
            StorageFactory factory = (StorageFactory) aoParam[0];
        
            $TXT_Name    TXT_Name    = ($TXT_Name)    _findName("TXT_Name");
            $TXT_Descr   TXT_Descr   = ($TXT_Descr)   _findName("TXT_Descr");
            $CBX_BasePrj CBX_BasePrj = ($CBX_BasePrj) _findName("CBX_BasePrj");
            $TXT_BaseVer TXT_BaseVer = ($TXT_BaseVer) _findName("TXT_BaseVer");
            
            String sName    = TXT_Name   .getText();
            String sDescr   = TXT_Descr  .getText();
            String sBasePrj = CBX_BasePrj.getText();
            String sBaseVer = TXT_BaseVer.getText();
        
            if (sName.length() == 0 || sBasePrj.length() == 0 || sBaseVer.length() == 0)
                {
                _beep();
                return;
                }
        
            try
                {
                ProjectInfo info = factory.createProject(sName, sBaseVer);
                info.setDescription(sDescr);
                info.getDefaultTarget().setBaseTargets(
                    Base.parseDelimitedString(sBasePrj, ','));
        
                factory.storeProjectInfo(info);
                }
            catch (Exception e)
                {
                String sMsg = e.getMessage();
                if (sMsg == null)
                    {
                    sMsg = e.toString();
                    }
                msg("Message", new Object[]
                    {
                    sMsg,
                    getTitle(),
                    new Integer(JOptionPane.ERROR_MESSAGE),
                    });
                return;
                }
            
            oResult = sName;
            }
        
        super.endDialog(oResult);
        }
    
    // Declared at the super level
    /**
    * The "component has been added to a containing component"
    * method-notification.
    * 
    * Note: this notification is not sent during the component's state
    * initialization (deserialization)
    * 
    * @see _addChild
    */
    public void onAdd()
        {
        // import Component.Dev.Project.StorageFactory;
        // import java.util.Date;
        
        super.onAdd();
        
        Object[] aoParam = (Object[]) getDialogParam();
        if (aoParam == null)
            {
            return;
            }
        
        StorageFactory factory  = (StorageFactory) aoParam[0];
        String         sBasePrj = (String) aoParam[1];
        
        String[] asProjects = factory.getProjects();
        
        (($TXT_Descr)   _findName("TXT_Descr"))  .setText("Created on " + new Date());
        (($CBX_BasePrj) _findName("CBX_BasePrj")).setList(asProjects);
        (($CBX_BasePrj) _findName("CBX_BasePrj")).setText(sBasePrj);

        }
    
    public void validateInput()
        {
        String sName    = (($TXT_Name)    _findName("TXT_Name"))   .getText();
        String sBasePrj = (($CBX_BasePrj) _findName("CBX_BasePrj")).getText();
        String sBaseVer = (($TXT_BaseVer) _findName("TXT_BaseVer")).getText();
        
        (($CB_OK) _findName("CB_OK")).setEnabled(
            sName.length() > 0 && sBasePrj.length() > 0 && sBaseVer.length() > 0);
        }
    }
