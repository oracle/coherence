/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDPropertySheet
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel;

import _package.component.gUI.control.container.jComponent.jPanel.ToolSite;
import _package.component.gUI.tableCell.cDTraitCell.CDPropertyCell;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.Property;
import javax.swing.JOptionPane;

public abstract class CDPropertySheet
        extends    _package.component.gUI.control.container.jComponent.jPanel.TabbedPanel
    {
    // Fields declarations
    
    /**
    * Property PropertyTool
    *
    * We need this property to get to the helper function implemented on the
    * PropertyTool. This property is supplied by the PropertyDesigner component.
    */
    
    // Initializing constructor
    public CDPropertySheet(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/CDPropertySheet".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "PropertyTool"
    public _package.component.dev.tool.host.cDTool.PropertyTool getPropertyTool()
        {
        return null;
        }
    
    public void removeCurrentProperty()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite;
        // import Component.GUI.TableCell.CDTraitCell.CDPropertyCell;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Property;
        // import javax.swing.JOptionPane;
        
        $Table Table = ($Table) _findName("Table");
        
        int iRow = Table.getSelectedRow();
        if (iRow < 0)
            {
            _beep();
            return;
            }
        
        Property  prop  = ((CDPropertyCell) Table.getValueAt(iRow, 0)).getProperty();
        Component cd    = prop.getComponent();
        String    sProp = prop.getName();
        if (!cd.isPropertyRemovable(sProp))
            {
            _beep();
            return;
            }
        
        // TODO: if accessors are integrated -- bring up the message
        
        Behavior[] abhvr     = prop.getAccessors();
        boolean    fScripted = false;
        for (int iAccess = Property.PA_FIRST; iAccess <= Property.PA_LAST; iAccess++)
            {
            Behavior bhvr = abhvr[iAccess];
            if (bhvr != null && bhvr.getModifiableImplementationCount() > 0)
                {
                fScripted = true;
                break;
                }
            }
        
        if (fScripted)
            {
            Integer intAns = (Integer) msg("Confirm", new Object[]
                {
                "Property \"" + sProp + "\" has a scripted accessor.\n" + 
                "Are you sure you want to delete it?",
                ToolSite.MSG_TITLE,
                new Integer(JOptionPane.YES_NO_OPTION),
                });
        
            if (intAns.intValue() != JOptionPane.YES_OPTION)
                {
                return;
                }
            }
        
        try
            {
            cd.removeProperty(sProp);
            }
        catch (java.beans.PropertyVetoException e)
            {
            _assert(false, "Cannot remove property");
            }
        }
    }
