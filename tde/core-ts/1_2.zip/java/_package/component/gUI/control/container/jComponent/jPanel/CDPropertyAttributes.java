/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.CDPropertyAttributes
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.gUI.Control;
import _package.component.gUI.control.container.jComponent.abstractButton.JToggleButton;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Constants;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Parameter;
import com.tangosol.dev.component.Property;
import java.beans.PropertyVetoException;

public abstract class CDPropertyAttributes
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property CDTool
    *
    * CDTool component is needed to get to the storage and helper functions. It
    * has to be supplied by the PropertyDesigner.
    */
    
    /**
    * Property Property
    *
    */
    private com.tangosol.dev.component.Property __m_Property;
    
    // Initializing constructor
    public CDPropertyAttributes(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/CDPropertyAttributes".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    public void apply()
        {
        // import Component.GUI.Control;
        // import Component.GUI.Control.Container.JComponent.AbstractButton.JToggleButton;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Constants;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Parameter;
        // import com.tangosol.dev.component.Property;
        // import java.beans.PropertyVetoException;
        
        Property prop = getProperty();
        if (prop == null)
            {
            return;
            }
        
        $RG_Access              RG_Access      = ($RG_Access)             _findName("RG_Access");
        $RG_Access$RB_Public    RB_Public      = ($RG_Access$RB_Public)   _findName("RG_Access$RB_Public");
        $RG_Access$RB_Protected RB_Protected   = ($RG_Access$RB_Protected)_findName("RG_Access$RB_Protected");
        $RG_Access$RB_Private   RB_Private     = ($RG_Access$RB_Private)  _findName("RG_Access$RB_Private");
        $RG_Indexed             RG_Indexed     = ($RG_Indexed)            _findName("RG_Indexed");
        $RG_Indexed$RB_Single   RB_Single      = ($RG_Indexed$RB_Single)  _findName("RG_Indexed$RB_Single");
        $RG_Indexed$RB_Indexed  RB_Indexed     = ($RG_Indexed$RB_Indexed) _findName("RG_Indexed$RB_Indexed");
        $RG_Indexed$RB_IxOnly   RB_IxOnly      = ($RG_Indexed$RB_IxOnly)  _findName("RG_Indexed$RB_IxOnly");
        $CHK_Static             CHK_Static     = ($CHK_Static)            _findName("CHK_Static");
        $CHK_Persistent         CHK_Persistent = ($CHK_Persistent)        _findName("CHK_Persistent");
        $CHK_Gettable           CHK_Gettable   = ($CHK_Gettable)          _findName("CHK_Gettable");
        $CHK_Settable           CHK_Settable   = ($CHK_Settable)          _findName("CHK_Settable");
        $TXT_Name               TXT_Name       = ($TXT_Name)              _findName("TXT_Name");
        $CMB_Type               CMB_Type       = ($CMB_Type)              _findName("CMB_Type");
        $RG_Visible             RG_Visible     = ($RG_Visible)            _findName("RG_Visible");
        $RG_Visible$RB_Visible  RB_Visible     = ($RG_Visible$RB_Visible) _findName("RG_Visible$RB_Visible");
        $RG_Visible$RB_Advanced RB_Advanced    = ($RG_Visible$RB_Advanced)_findName("RG_Visible$RB_Advanced");
        $RG_Visible$RB_Hidden   RB_Hidden      = ($RG_Visible$RB_Hidden)  _findName("RG_Visible$RB_Hidden");
        $RG_Visible$RB_System   RB_System      = ($RG_Visible$RB_System)  _findName("RG_Visible$RB_System");
        
        // some change could be not allowed until another change is made
        // (e.g. we cannot change the name before the return type is changed because
        // of the collision with an integrated behavior)
        // that is why we will try to make changes in a couple of passes
        // until all or none of the changes are successful
        boolean fChanged;
        String  sErrMsg;
        Control ctrlErr;
        do
            {
            fChanged = false;
            sErrMsg  = null;
            ctrlErr  = null;
        
            String sNameNew = TXT_Name.getText();
            String sNameOld = prop.getName();
            if (!sNameOld.equals(sNameNew))
                {
                try
                    {
                    prop.setName(sNameNew);
                    fChanged = true;
        
                    // if there are no scripts yet, rename accessors parameters as well
                    int[] aiAccessor = new int[]
                        {
                        Property.PA_SET_SINGLE, Property.PA_SET_ARRAY, Property.PA_SET_INDEX
                        };
                    int[] aiParamNo = new int[] {0, 0, 1};
        
                    for (int i = 0; i < 3; i++)
                        {
                        Behavior  bhvr  = prop.getApplicableAccessor(aiAccessor[i]);
        
                        // change the parameter name if it has been neither used nor changed yet
                        if (bhvr != null && bhvr.getModifiableImplementationCount() == 0)
                            {
                            Parameter param = bhvr.getParameter(aiParamNo[i]);
                            try
                                {
                                if (param.getName().equals("p" + sNameOld))
                                    {
                                    param.setName("p" + sNameNew);
                                    }
                                }
                            catch (PropertyVetoException e) {}
                            }
                        }
                    }
                catch (PropertyVetoException e)
                    {
                    ctrlErr = TXT_Name;
                    sErrMsg = e.toString();
                    }
                }
        
            DataType dt = getCDTool().getDataType(CMB_Type.getText());
            if (!prop.getDataType().equals(dt))
                {
                try
                    {
                    prop.setDataType(dt);
                    fChanged = true;
                    }
                catch (PropertyVetoException e)
                    {
                    ctrlErr = CMB_Type;
                    sErrMsg = e.toString();
                    }
                }
        
            JToggleButton rb = RG_Access.getSelection();
            int nAccess = rb == RB_Public    ? Constants.ACCESS_PUBLIC    :
                          rb == RB_Protected ? Constants.ACCESS_PROTECTED :
                                               Constants.ACCESS_PRIVATE   ;
        
            if (prop.getAccess() != nAccess)
                {
                try
                    {
                    prop.setAccess(nAccess);
                    fChanged = true;
                    }
                catch (PropertyVetoException e)
                    {
                    nAccess = prop.getAccess();
                    switch(nAccess)
                        {
                        case Constants.ACCESS_PUBLIC:
                            rb = RB_Public;
                            break;
                        case Constants.ACCESS_PROTECTED:
                            rb = RB_Protected;
                            break;
                        case Constants.ACCESS_PRIVATE:
                        default:
                            rb = RB_Private;
                            break;
                        }
        
                    rb.setSelected(true);
        
                    ctrlErr = rb;
                    sErrMsg = e.toString();
                    }
                }
        
            rb = RG_Indexed.getSelection();
            int nIndexed = rb == RB_IxOnly  ? Constants.PROP_INDEXEDONLY :
                           rb == RB_Indexed ? Constants.PROP_INDEXED     :
                                              Constants.PROP_SINGLE      ;
            if (prop.getIndexed() != nIndexed)
                {
                try
                    {
                    prop.setIndexed(nIndexed);
                    fChanged = true;
                    }
                catch (PropertyVetoException e)
                    {
                    nIndexed = prop.getIndexed();
                    switch(nIndexed)
                        {
                        case Constants.PROP_INDEXEDONLY:
                            rb = RB_IxOnly;
                            break;
                        case Constants.PROP_INDEXED:
                            rb = RB_Indexed;
                            break;
                        case Constants.PROP_SINGLE:
                        default:
                            rb = RB_Single;
                            break;
                        }
        
                    rb.setSelected(true);
        
                    ctrlErr = rb;
                    sErrMsg = e.toString();
                    }
                }
        
            int nDirection = (CHK_Gettable.isSelected() ? Constants.DIR_OUT : 0)
                           + (CHK_Settable.isSelected() ? Constants.DIR_IN  : 0);
        
            if (prop.getDirection() != nDirection)
                {
                try
                    {
                    prop.setDirection(nDirection);
                    fChanged = true;
                    }
                catch (PropertyVetoException e)
                    {
                    if (prop.isGettable() && !CHK_Gettable.isSelected())
                        {
                        CHK_Gettable.setSelected(prop.isGettable());
                        ctrlErr = CHK_Gettable;
                        }
                    else
                        {
                        CHK_Settable.setSelected(prop.isSettable());
                        ctrlErr = CHK_Settable;
                        }
                    sErrMsg = e.toString();
                    }
                }
        
            boolean fStatic = CHK_Static.isSelected();
            if (prop.isStatic() != fStatic)
                {
                try
                    {
                    prop.setStatic(fStatic);
                    fChanged = true;
                    }
                catch (PropertyVetoException e)
                    {
                    CHK_Static.setSelected(prop.isStatic());
                    ctrlErr = CHK_Static;
                    sErrMsg = e.toString();
                    }
                }
        
            boolean fPersistent = CHK_Persistent.isSelected();
            if (prop.isPersistent() != fPersistent)
                {
                try
                    {
                    prop.setPersistent(fPersistent);
                    fChanged = true;
                    }
                catch (PropertyVetoException e)
                    {
                    CHK_Persistent.setSelected(prop.isPersistent());
                    ctrlErr = CHK_Persistent;
                    sErrMsg = e.toString();
                    }
                }
        
            rb = RG_Visible.getSelection();
            int nVisible = rb == RB_Visible  ? Constants.VIS_VISIBLE  :
                           rb == RB_Advanced ? Constants.VIS_ADVANCED :
                           rb == RB_Hidden   ? Constants.VIS_HIDDEN   :
                                               Constants.VIS_SYSTEM   ;
            if (prop.getVisible() != nVisible)
                {
                try
                    {
                    prop.setVisible(nVisible);
                    fChanged = true;
                    }
                catch (PropertyVetoException e)
                    {
                    nVisible = prop.getVisible();
                    switch(nVisible)
                        {
                        default:
                        case Constants.VIS_VISIBLE:
                            rb = RB_Visible;
                            break;
                        case Constants.VIS_ADVANCED:
                            rb = RB_Advanced;
                            break;
                        case Constants.VIS_HIDDEN:
                            rb = RB_Hidden;
                            break;
                        case Constants.VIS_SYSTEM:
                            rb = RB_System;
                            break;
                        }
                    rb.setSelected(true);
                    ctrlErr = rb;
                    sErrMsg = e.toString();
                    }
        
                // change the accessors visibility accordingly
                int nAccessorVisibile = prop.getVisible();
                Behavior[] abhvr      = prop.getAccessors();
                for (int i = 0, c = abhvr.length; i < c; i++)
                    {
                    Behavior bhvr = abhvr[i];
                    if (bhvr != null)
                        {
                        try
                            {
                            bhvr.setVisible(nAccessorVisibile);
                            }
                        catch (PropertyVetoException e) {}
                        }
                    }
                }
            } while (sErrMsg != null && fChanged);
        
        if (sErrMsg != null)
            {
            onError(ctrlErr, sErrMsg);
            }
        
        update();
        }
    
    // Accessor for the property "CDTool"
    /**
    * Getter for property CDTool.<p>
    * CDTool component is needed to get to the storage and helper functions. It
    * has to be supplied by the PropertyDesigner.
    */
    public _package.component.dev.tool.host.CDTool getCDTool()
        {
        return null;
        }
    
    // Accessor for the property "Property"
    /**
    * Getter for property Property.<p>
    */
    public com.tangosol.dev.component.Property getProperty()
        {
        return __m_Property;
        }
    
    private void onError(_package.component.gUI.Control ctrl, String sErr)
        {
        if (ctrl != null)
            {
            ctrl.requestFocus();
            }
        _trace(sErr);
        _beep();
        }
    
    // Accessor for the property "Property"
    /**
    * Setter for property Property.<p>
    */
    public void setProperty(com.tangosol.dev.component.Property pProperty)
        {
        if (getProperty() != null)
            {
            // we could check whether anything has been changed and aply the changes
            // apply();
            }
        
        __m_Property = (pProperty);
        
        if (pProperty != null)
            {
            setVisible(true);
            update();
            }
        else
            {
            setVisible(false);
            }
        }
    
    public void update()
        {
        // import com.tangosol.dev.component.Constants;
        // import com.tangosol.dev.component.Property;
        
        Property prop = getProperty();
        
        $RG_Access              RG_Access      = ($RG_Access)             _findName("RG_Access");
        $RG_Access$RB_Public    RB_Public      = ($RG_Access$RB_Public)   _findName("RG_Access$RB_Public");
        $RG_Access$RB_Protected RB_Protected   = ($RG_Access$RB_Protected)_findName("RG_Access$RB_Protected");
        $RG_Access$RB_Private   RB_Private     = ($RG_Access$RB_Private)  _findName("RG_Access$RB_Private");
        $RG_Indexed             RG_Indexed     = ($RG_Indexed)            _findName("RG_Indexed");
        $RG_Indexed$RB_Single   RB_Single      = ($RG_Indexed$RB_Single)  _findName("RG_Indexed$RB_Single");
        $RG_Indexed$RB_Indexed  RB_Indexed     = ($RG_Indexed$RB_Indexed) _findName("RG_Indexed$RB_Indexed");
        $RG_Indexed$RB_IxOnly   RB_IxOnly      = ($RG_Indexed$RB_IxOnly)  _findName("RG_Indexed$RB_IxOnly");
        $CHK_Static             CHK_Static     = ($CHK_Static)            _findName("CHK_Static");
        $CHK_Persistent         CHK_Persistent = ($CHK_Persistent)        _findName("CHK_Persistent");
        $CHK_Gettable           CHK_Gettable   = ($CHK_Gettable)          _findName("CHK_Gettable");
        $CHK_Settable           CHK_Settable   = ($CHK_Settable)          _findName("CHK_Settable");
        $TXT_Name               TXT_Name       = ($TXT_Name)              _findName("TXT_Name");
        $CMB_Type               CMB_Type       = ($CMB_Type)              _findName("CMB_Type");
        $RG_Visible             RG_Visible     = ($RG_Visible)            _findName("RG_Visible");
        $RG_Visible$RB_Visible  RB_Visible     = ($RG_Visible$RB_Visible) _findName("RG_Visible$RB_Visible");
        $RG_Visible$RB_Advanced RB_Advanced    = ($RG_Visible$RB_Advanced)_findName("RG_Visible$RB_Advanced");
        $RG_Visible$RB_Hidden   RB_Hidden      = ($RG_Visible$RB_Hidden)  _findName("RG_Visible$RB_Hidden");
        $RG_Visible$RB_System   RB_System      = ($RG_Visible$RB_System)  _findName("RG_Visible$RB_System");
        
        TXT_Name.setText(prop.getName());
        TXT_Name.setEditable(prop.isNameSettable());
        
        String sType = getCDTool().getDisplayValue(prop.getDataType());
        CMB_Type.setText(sType);
        CMB_Type.setEnabled(prop.isDataTypeSettable());
        
        switch (prop.getAccess())
            {
            case Constants.ACCESS_PUBLIC:
                RB_Public.setSelected(true);
                break;
            case Constants.ACCESS_PROTECTED:
                RB_Protected.setSelected(true);
                break;
            default:
            case Constants.ACCESS_PRIVATE:
                RB_Private.setSelected(true);
                break;
            }
        RG_Access.setEnabled(prop.isAccessSettable());
        if  (prop.isVirtualConstant())
            {
            // private virtual constant makes no sense
            RB_Private.setEnabled(false);
            }
        
        switch (prop.getIndexed())
            {
            case Constants.PROP_SINGLE:
                RB_Single.setSelected(true);
                break;
            case Constants.PROP_INDEXED:
                RB_Indexed.setSelected(true);
                break;
            default:
            case Constants.PROP_INDEXEDONLY:
                RB_IxOnly.setSelected(true);
                break;
            }
        RG_Indexed.setEnabled(prop.isIndexedSettable());
        
        CHK_Gettable.setSelected(prop.isGettable());
        CHK_Gettable.setEnabled(prop.isDirectionSettable());
        
        CHK_Settable.setSelected(prop.isSettable());
        CHK_Settable.setEnabled(prop.isDirectionSettable());
        
        CHK_Static.setSelected(prop.isStatic());
        CHK_Static.setEnabled (prop.isStaticSettable());
        
        CHK_Persistent.setSelected(prop.isPersistent());
        CHK_Persistent.setEnabled (prop.isPersistentSettable());
        
        switch (prop.getVisible())
            {
            case Constants.VIS_VISIBLE:
                RB_Visible.setSelected(true);
                break;
            case Constants.VIS_ADVANCED:
                RB_Advanced.setSelected(true);
                break;
            case Constants.VIS_HIDDEN:
                RB_Hidden.setSelected(true);
                break;
            default:
            case Constants.VIS_SYSTEM:
                RB_System.setSelected(true);
                break;
            }
        RG_Visible.setEnabled(prop.isVisibleSettable());
        
        String sStyle = 
            prop.isJavaConstant()       ? "Java Constant"       :
            prop.isVirtualConstant()    ? "Virtual Constant"    :
            prop.isCalculatedProperty() ? "Calculated Property" :
            prop.isFunctionalProperty() ? "Functional Property" : 
                                          "Standard Property"   ;
        setTitle(sStyle);
        }
    }
