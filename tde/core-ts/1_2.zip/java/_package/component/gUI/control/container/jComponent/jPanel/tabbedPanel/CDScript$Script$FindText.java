/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDScript$Script$FindText
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel;

public class CDScript$Script$FindText
        extends    _package.component.gUI.control.container.jComponent.jPanel.FindText
    {
    // Fields declarations
    
    // Default constructor
    public CDScript$Script$FindText()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDScript$Script$FindText(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(false);
            setTBounds("0,0,395,115");
            setTConstraints("Center");
            setTitle("Find");
            setTLayout(null);
            setVisible(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$BG_Direction("BG_Direction", this, true), "BG_Direction");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$BTN_Cancel("BTN_Cancel", this, true), "BTN_Cancel");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$BTN_Next("BTN_Next", this, true), "BTN_Next");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$CBX_Find("CBX_Find", this, true), "CBX_Find");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$CHK_Case("CHK_Case", this, true), "CHK_Case");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$CHK_Reg("CHK_Reg", this, true), "CHK_Reg");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$CHK_Word("CHK_Word", this, true), "CHK_Word");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$KeyFind("KeyFind", this, true), "KeyFind");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$KeyFindNext("KeyFindNext", this, true), "KeyFindNext");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$KeyFindPrev("KeyFindPrev", this, true), "KeyFindPrev");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$KeyFindSelection("KeyFindSelection", this, true), "KeyFindSelection");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$LBL_Find("LBL_Find", this, true), "LBL_Find");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CDScript$Script$FindText();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/CDScript$Script$FindText".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent();
        }
    }
