/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.TAPSNewProject$CB_OK
*/

package _package.component.gUI.control.container.jComponent.jPanel;

public class TAPSNewProject$CB_OK
        extends    _package.component.gUI.control.container.jComponent.abstractButton.jButton.DefaultButton
    {
    // Fields declarations
    
    // Default constructor
    public TAPSNewProject$CB_OK()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPSNewProject$CB_OK(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(4.0F);
            setEnabled(false);
            setFocusable(true);
            setTBorder("BevelSimple");
            setTBounds("335,12,75,22");
            setText("OK");
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new _package.component.gUI.control.container.jComponent.abstractButton.jButton.DefaultButton$KeyEnter("KeyEnter", this, true), "KeyEnter");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new TAPSNewProject$CB_OK();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/TAPSNewProject$CB_OK".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    }
