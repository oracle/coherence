/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.TAPSLibrary
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.dev.project.ProjectInfo$Target$Library; // as Library
import _package.component.dev.project.ProjectInfo$Target; // as Target
import _package.component.dev.project.ProjectInfo; // as Project
import _package.component.dev.storage.TAPSStorage;
import _package.component.util.FileHelper;
import com.tangosol.dev.component.Constants;
import com.tangosol.util.ListMap;
import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class TAPSLibrary
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    // Default constructor
    public TAPSLibrary()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPSLibrary(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(false);
            setTBounds("0,0,705,205");
            setTConstraints("Center");
            setTIcon("TAPS");
            setTitle("Manage Libraries");
            setTLayout(null);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new TAPSLibrary$CB_Cancel("CB_Cancel", this, true), "CB_Cancel");
        _addChild(new TAPSLibrary$CB_OK("CB_OK", this, true), "CB_OK");
        _addChild(new TAPSLibrary$FileChooser("FileChooser", this, true), "FileChooser");
        _addChild(new TAPSLibrary$TBL_Lib("TBL_Lib", this, true), "TBL_Lib");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new TAPSLibrary();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/TAPSLibrary".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Add an array of library files to the current list
    */
    public void addLibrary(java.io.File[] afile)
        {
        // import Component.Dev.Storage.TAPSStorage;
        // import Component.Dev.Project.ProjectInfo as Project;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Util.FileHelper;
        // import java.io.File;
        // import java.io.IOException;
        // import java.util.Enumeration;
        // import java.util.jar.JarFile;
        // import java.util.jar.JarEntry;
        
        Object[]    aoParam = (Object[]) getDialogParam();
        TAPSStorage storage = (TAPSStorage) aoParam[0];
        Target      target  = storage.getTarget();
        
        $TBL_Lib TBL_Lib = ($TBL_Lib) _findName("TBL_Lib");
        
        NextLibrary:
        for (int i = 0, c = afile.length; i < c; i++)
            {
            File    file  = afile[i];
        
            String  sName = file.getName();
            String  sLoc  = file.getAbsolutePath();
            String  sDesc = "";
            String  sVis  = "standard";
            Boolean bCust = Boolean.TRUE;
        
            // TODO: Collect UseCopy flag?
            sLoc = FileHelper.getRelativePath(sLoc, target.getProjectInfo().
                getStorageInfo().getSafeElement("Location").getString());
        
            try
                {
                if (sName.toLowerCase().endsWith(".ear"))
                    {
                    JarFile ear  = new JarFile(file);
                    for (Enumeration enum = ear.entries(); enum.hasMoreElements();)
                        {
                        JarEntry entry = (JarEntry) enum.nextElement();
        
                        String sPath = entry.getName();
                        if (sPath.toLowerCase().endsWith(".jar") ||
                            sPath.toLowerCase().endsWith(".war"))
                            {
                            sName = sPath.substring(sPath.lastIndexOf('/') + 1); 
                            TBL_Lib.getTable().addRow(new Object[]
                                {sName, sLoc + "!/" + sPath, sVis, bCust, sDesc});
                            }
                        }
                    }
                else
                    {
                    TBL_Lib.getTable().addRow(new Object[]
                        {sName, sLoc, sVis, bCust, sDesc});
                    }
                }
            catch (IOException e) {}
            }
        }
    
    // Declared at the super level
    /**
    * Ends a dialog, setting the specified result of the DailogBox. The
    * conventions for the result value are:
    * Value of null means the canceled action. Value of Boolean.TRUE means the
    * default action and then the DialogBox result value is set as follows:
    * if the panel implements XmlSerializable then the result is set to the
    * appropriate XML value; otherwise the result value is set to the Config
    * object.
    * 
    * @param oResult the result value of the dialiog box with this main panel
    * 
    * @see DialogParam property
    * @see JButton.DefaultButton#onAction
    * @see JButton.EscapeButton#onAction
    */
    public void endDialog(Object oResult)
        {
        // import Component.Dev.Storage.TAPSStorage;
        // import Component.Dev.Project.ProjectInfo as Project;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Project.ProjectInfo$Target$Library as Library;
        // import com.tangosol.dev.component.Constants;
        // import com.tangosol.util.ListMap;
        // import java.util.Iterator;
        
        Object[] aoParam = (Object[]) getDialogParam();
        if (aoParam != null && oResult == Boolean.TRUE)
            {
            TAPSStorage storage = (TAPSStorage) aoParam[0];
            Target      target  = storage.getTarget();
        
            try
                {
                // check for new or removed libraries
                $Table Table       = ($Table) _findName("TBL_Lib$Table");
                ListMap listLib    = target.getLibraryList();
                ListMap listLibTmp = new ListMap();
        
                listLibTmp.putAll(listLib);
                listLib.clear();
                for (int iRow = 0, cRows = Table.getRowCount(); iRow < cRows; iRow++)
                    {
                    String  sName = (String)  Table.getValueAt(iRow, 0);
                    String  sLoc  = (String)  Table.getValueAt(iRow, 1);
                    String  sVis  = (String)  Table.getValueAt(iRow, 2);
                    Boolean bCust = (Boolean) Table.getValueAt(iRow, 3);
                    String  sDesc = (String)  Table.getValueAt(iRow, 4);
        
                    Library lib  = (Library) listLibTmp.get(sName);
                    if (lib == null)
                        {
                        lib = (Library) target._newChild("Library");
                        lib.setName(sName);
                        }
        
                    lib.setVisibility(Library.convertVisibility(sVis));
                    lib.setCustomizable(bCust.booleanValue());
                    lib.setDescription(sDesc);
                    lib.getStorageInfo().ensureElement("Location").setString(sLoc);
        
                    if (sLoc.toLowerCase().indexOf(".ear") > 0 ||
                        sLoc.toLowerCase().indexOf(".war") > 0)
                        {
                        lib.getStorageInfo().ensureElement("UseCopy").setBoolean(true);
                        }
                    listLib.put(sName, lib);
                    }
        
                // save the project descriptor
                storage.getProjectFactory().storeProjectInfo(target.getProjectInfo());
                
                oResult = target;
                }
            catch (Exception e)
                {
                String sMsg = e.getMessage();
                if (sMsg == null)
                    {
                    sMsg = e.toString();
                    }
                msg("Message", new Object[]
                    {
                    sMsg,
                    getTitle(),
                    new Integer(javax.swing.JOptionPane.ERROR_MESSAGE),
                    });
                return;
                }
            }
        
        super.endDialog(oResult);
        }
    
    // Declared at the super level
    /**
    * The "component has been added to a containing component"
    * method-notification.
    * 
    * Note: this notification is not sent during the component's state
    * initialization (deserialization)
    * 
    * @see _addChild
    */
    public void onAdd()
        {
        // import Component.Dev.Project.ProjectInfo as Project;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Project.ProjectInfo$Target$Library as Library;
        // import Component.Dev.Storage.TAPSStorage;
        // import com.tangosol.dev.component.Constants;
        // import com.tangosol.util.ListMap;
        // import java.io.File;
        // import java.util.Iterator;
        
        super.onAdd();
        
        Object[] aoParam = (Object[]) getDialogParam();
        if (aoParam == null)
            {
            return;
            }
        
        $TBL_Lib$Table Table = ($TBL_Lib$Table) _findName("TBL_Lib$Table");
        
        TAPSStorage storage = (TAPSStorage) aoParam[0];
        File[]      aLib    = (File[])      aoParam[1];
        Target      target  = storage.getTarget();
        
        ListMap listLib = target.getLibraryList();
        
        for (Iterator iter = listLib.values().iterator(); iter.hasNext();)
            {
            Library lib = (Library) iter.next();
        
            String  sName = lib.getName();
            String  sLoc  = lib.getStorageInfo().getSafeElement("Location").getString();
            String  sDesc = lib.getDescription();
            String  sVis  = Library.convertVisibility(lib.getVisibility());
            Boolean bCust = new Boolean(lib.isCustomizable());
            
            Table.addRow(new Object[] {sName, sLoc, sVis, bCust, sDesc});
            }
        
        if (aLib != null)
            {
            addLibrary(aLib);
            }
        
        if (Table.getRowCount() > 0)
            {
            Table.requestFocus();
            Table.setSelectedRow(0);
            }
        }
    }
