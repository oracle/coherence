/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDPropertySheet$Table$Name
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel;

public class CDPropertySheet$Table$Name
        extends    _package.component.gUI.TableColumn
    {
    // Fields declarations
    
    // Default constructor
    public CDPropertySheet$Table$Name()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDPropertySheet$Table$Name(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(1.0F);
            setCellHorizontalAlignment(2);
            setHorizontalAlignment(0);
            setIndex(-1);
            setResizable(true);
            setSorted(true);
            setTitle("Name");
            setWidth(50);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new CDPropertySheet$Table$Name();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/CDPropertySheet$Table$Name".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent();
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        super.onInit();
        
        // use the same collator as used by the Component Definition
        setCollator(com.tangosol.dev.component.Constants.INSENS);
        }
    }
