/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDPropertySheet$Tip
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel;

import _package.component.gUI.tableCell.cDTraitCell.CDPropertyCell;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Property;

public class CDPropertySheet$Tip
        extends    _package.component.gUI.control.container.jComponent.jTextComponent.JTextArea
    {
    // Fields declarations
    
    // Default constructor
    public CDPropertySheet$Tip()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDPropertySheet$Tip(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setEnabled(false);
            setFocusable(true);
            setScrollable(false);
            setTabAllowed(false);
            setTabSize(4);
            setTBorder("EtchedSimple");
            setTBounds("0,360,100,40");
            setTConstraints("South");
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new _package.component.gUI.control.container.jComponent.JTextComponent$KeyRedo("KeyRedo", this, true), "KeyRedo");
        _addChild(new _package.component.gUI.control.container.jComponent.JTextComponent$KeyUndo("KeyUndo", this, true), "KeyUndo");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new CDPropertySheet$Tip();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/CDPropertySheet$Tip".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    public void update()
        {
        // import Component.GUI.TableCell.CDTraitCell.CDPropertyCell;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Property;
        
        $Table Table = ($Table) _findName("Table");
        
        int iRow = Table.getSelectedRow();
        if (iRow == Table.ITEM_NOT_FOUND)
            {
            setText("");
            return;
            }
        
        CDPropertyCell cell = (CDPropertyCell) Table.getValueAt(iRow, 0);
        Property       prop = cell.getProperty();
        
        String sLine1;
        
        if (prop.isFromSuper())
            {
            sLine1 = "Inherited: ";
            }
        else if (prop.isFromBase())
            {
            sLine1 = "Overlaid: ";
            }
        else if (prop.isFromIntegration())
            {
            sLine1 = "Integrated: ";
            }
        else
            {
            Behavior bhvrGetter = prop.getAccessor(Property.PA_GET_SINGLE);
            Behavior bhvrSetter = prop.getAccessor(Property.PA_SET_SINGLE);
            if (bhvrGetter != null && bhvrGetter.isFromIntegration()
             || bhvrSetter != null && bhvrSetter.isFromIntegration())
                {
                sLine1 = "Integrated: ";
                }
            else
                {
                sLine1 = "Declared: ";
                }
            }
        
        sLine1 += prop.getName();
        
        String sLine2 = prop.getTip();
        
        setText(sLine1 + '\n' + sLine2);
        }
    }
