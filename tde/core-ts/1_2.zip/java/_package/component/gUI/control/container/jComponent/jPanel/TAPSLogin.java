/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.TAPSLogin
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.dev.storage.TAPSStorage;

public class TAPSLogin
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    // Default constructor
    public TAPSLogin()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPSLogin(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(false);
            setTBounds("0,0,415,145");
            setTConstraints("Center");
            setTIcon("TAPS");
            setTitle("Select Project Home");
            setTLayout(null);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new TAPSLogin$CB_Cancel("CB_Cancel", this, true), "CB_Cancel");
        _addChild(new TAPSLogin$CB_OK("CB_OK", this, true), "CB_OK");
        _addChild(new TAPSLogin$CBX_Address("CBX_Address", this, true), "CBX_Address");
        _addChild(new TAPSLogin$CHK_SavePwd("CHK_SavePwd", this, true), "CHK_SavePwd");
        _addChild(new TAPSLogin$LBL_Address("LBL_Address", this, true), "LBL_Address");
        _addChild(new TAPSLogin$LBL_Password("LBL_Password", this, true), "LBL_Password");
        _addChild(new TAPSLogin$LBL_User("LBL_User", this, true), "LBL_User");
        _addChild(new TAPSLogin$TXT_Password("TXT_Password", this, true), "TXT_Password");
        _addChild(new TAPSLogin$TXT_User("TXT_User", this, true), "TXT_User");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new TAPSLogin();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/TAPSLogin".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Ends a dialog, setting the specified result of the DailogBox. The
    * conventions for the result value are:
    * Value of null means the canceled action. Value of Boolean.TRUE means the
    * default action and then the DialogBox result value is set as follows:
    * if the panel implements XmlSerializable then the result is set to the
    * appropriate XML value; otherwise the result value is set to the Config
    * object.
    * 
    * @param oResult the result value of the dialiog box with this main panel
    * 
    * @see DialogParam property
    * @see JButton.DefaultButton#onAction
    * @see JButton.EscapeButton#onAction
    */
    public void endDialog(Object oResult)
        {
        // import Component.Dev.Storage.TAPSStorage;
        
        TAPSStorage store = (TAPSStorage) getDialogParam();
        
        if (store != null && oResult == Boolean.TRUE)
            {
            String  sAddress   = (($CBX_Address)  _findName("CBX_Address")) .getText();
            String  sUser      = (($TXT_User)     _findName("TXT_User"))    .getText();
            char[]  acPassword = (($TXT_Password) _findName("TXT_Password")).getPassword();
            boolean fSavePwd   = (($CHK_SavePwd)  _findName("CHK_SavePwd")) .isSelected();
        
            if (sAddress.length() == 0 || sUser.length() == 0)
                {
                _beep();
                return;
                }
        
            store.setServerUri(sAddress);
            store.setUser(sUser);
            store.setPassword(acPassword);
            store.setSavePassword(fSavePwd);
        
            if (store.getProjectFactory() == null)
                {
                _beep();
                return;
                }
        
            // update the address history
            $CBX_Address CBX_Address = ($CBX_Address) _findName("CBX_Address");
        
            final int MAX_ADDRESS_CNT = 10;
            CBX_Address.updateMRUList(sAddress, MAX_ADDRESS_CNT);    
            store.setHistory(CBX_Address.getList());
        
            oResult = store;
            }
        
        super.endDialog(oResult);
        }
    
    // Declared at the super level
    /**
    * The "component has been added to a containing component"
    * method-notification.
    * 
    * Note: this notification is not sent during the component's state
    * initialization (deserialization)
    * 
    * @see _addChild
    */
    public void onAdd()
        {
        // import Component.Dev.Storage.TAPSStorage;
        
        super.onAdd();
        
        TAPSStorage store = (TAPSStorage) getDialogParam();
        
        if (store == null)
            {
            return;
            }
        
        String   sAddress  = store.getServerUri();
        String   sUser     = store.getUser();
        boolean  fSavePwd  = store.isSavePassword();
        String[] asHistory = store.getHistory();
        
        (($TXT_User)     _findName("TXT_User"))    .setText(sUser);
        (($CHK_SavePwd)  _findName("CHK_SavePwd")) .setSelected(fSavePwd);
        (($CBX_Address)  _findName("CBX_Address")) .setList(asHistory);
        (($CBX_Address)  _findName("CBX_Address")) .setText(sAddress);

        }
    }
