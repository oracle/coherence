/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDScript$Status$Navigate
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel;

import com.tangosol.dev.component.Behavior;

public class CDScript$Status$Navigate
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    // Default constructor
    public CDScript$Status$Navigate()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDScript$Status$Navigate(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(true);
            setTBounds("0,0,32,16");
            setTConstraints("West");
            setTLayout(null);
            setVisible(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new CDScript$Status$Navigate$Next("Next", this, true), "Next");
        _addChild(new CDScript$Status$Navigate$Prev("Prev", this, true), "Prev");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new CDScript$Status$Navigate();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/CDScript$Status$Navigate".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent();
        }
    
    public void update()
        {
        // import com.tangosol.dev.component.Behavior;
        
        $Next Next = ($Next) _findName("Next");
        $Prev Prev = ($Prev) _findName("Prev");
        
        boolean fVisible = false;
        
        $Module  module = ($Module) get_Module();
        Behavior bhvr   = module.getBehavior();
        
        if (bhvr != null)
            {
            int iScript  = module.getScriptPos();
            int cScripts = module.getScriptCount();
            
            if (cScripts > 1)
                {
                fVisible = true;
                
                Next.setEnabled(iScript < cScripts - 1);
                Prev.setEnabled(iScript > 0);
                }
            }
        
        setVisible(fVisible);
        }
    }
