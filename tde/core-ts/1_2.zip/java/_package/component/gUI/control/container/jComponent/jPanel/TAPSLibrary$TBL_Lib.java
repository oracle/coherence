/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.TAPSLibrary$TBL_Lib
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.io.File;
import java.util.List;
import javax.swing.JOptionPane;

public class TAPSLibrary$TBL_Lib
        extends    _package.component.gUI.control.container.jComponent.jPanel.tcTable.TcOrderedTable
    {
    // Fields declarations
    
    // Default constructor
    public TAPSLibrary$TBL_Lib()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPSLibrary$TBL_Lib(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setDropActions(2);
            setDropAllowed(true);
            setFocusable(true);
            setResizable(true);
            setTBounds("10,10,600,180");
            setTConstraints("Center");
            setTLayout("BorderLayout");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new TAPSLibrary$TBL_Lib$Header("Header", this, true), "Header");
        _addChild(new TAPSLibrary$TBL_Lib$Table("Table", this, true), "Table");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new TAPSLibrary$TBL_Lib();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/TAPSLibrary$TBL_Lib".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    /**
    * Add a new row to the table.
    */
    public void addRow()
        {
        // import java.io.File;
        
        $FileChooser chooser = ($FileChooser) _findName("FileChooser");
        
        int iAnswer = chooser.showDialog(this);
        
        if (iAnswer == $FileChooser.APPROVE_OPTION)
            {
            File[] aFile = chooser.getSelectedFiles();
            if (aFile.length == 0)
                {
                File file = chooser.getSelectedFile();
                if (file != null)
                    {
                    aFile = new File[] {file};
                    }
                }
        
            (($Module) get_Module()).addLibrary(aFile);
            }
        
        // don't call super!
        }
    
    // Declared at the super level
    /**
    * Prepares to transfer something at the specified location for the
    * specified action
    * 
    * @return true if transfer is going to be accepted; false otherwise
    * 
    * @see dragOver()
    */
    public boolean prepareTransferAtLocation(_package.component.gUI.Point point, int iAction, java.util.List listFlavors)
        {
        // import java.awt.datatransfer.DataFlavor;
        return listFlavors.contains(DataFlavor.javaFileListFlavor);
        }
    
    // Declared at the super level
    /**
    * Puts (drops) the specified Transferable object at the specified location
    * for the specified action
    * 
    * @return true if transfer is accepted; false otherwise
    * 
    * @see drop()
    */
    public boolean putTransferAtLocation(java.awt.datatransfer.Transferable transfer, _package.component.gUI.Point point, int iAction)
        {
        // import java.awt.datatransfer.DataFlavor;
        // import java.awt.datatransfer.Transferable;
        // import java.io.File;
        // import java.util.List;
        
        List listFiles = null;
        try
            {
            if (transfer.isDataFlavorSupported(DataFlavor.javaFileListFlavor))
                {    
                listFiles = (List) transfer.getTransferData(DataFlavor.javaFileListFlavor);
                }
            }
        // UnsupportedFlavorException, IOException
        catch (Exception e)
            {
            _trace("TODO: transfer failed " + e, 1);
            return false;
            }
        
        if (listFiles != null)
            {
            File[] afile = (File[]) listFiles.toArray(new File[listFiles.size()]);
            }
        return true;
        }
    
    // Declared at the super level
    /**
    * Remove a selected row from the table.
    */
    public void removeRow()
        {
        // import javax.swing.JOptionPane;
        
        if (getTable().getSelectedRow() >= 0)
            {
            Integer intAns = (Integer) msg("Confirm", new Object[]
                {
                "Removing the library will invalidate all the components\n" +
                "that customize or refer to classes from this library.\n\n"  +
                "Are you sure you wish to proceed?",
                "Remove Library",
                new Integer(JOptionPane.YES_NO_OPTION),
                });
        
            if (intAns.intValue() != JOptionPane.YES_OPTION)
                {
                return;
                }
            }
        super.removeRow();
        }
    }
