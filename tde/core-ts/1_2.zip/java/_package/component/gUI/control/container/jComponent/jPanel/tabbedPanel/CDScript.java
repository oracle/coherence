/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDScript
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel;

import _package.component.dev.tool.host.CDTool;
import _package.component.util.Config;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Constants;
import com.tangosol.dev.component.Parameter;

public abstract class CDScript
        extends    _package.component.gUI.control.container.jComponent.jPanel.TabbedPanel
    {
    // Fields declarations
    
    /**
    * Property Behavior
    *
    */
    private com.tangosol.dev.component.Behavior __m_Behavior;
    
    /**
    * Property CDTool
    *
    * CDTool component is needed to get to the storage and helper functions. It
    * has to be supplied by the ScriptEditor.
    */
    
    /**
    * Property Config
    *
    * Privately used property holding the configuration info.
    */
    private transient _package.component.util.Config __m_Config;
    
    /**
    * Property NeedUpdate
    *
    */
    private boolean __m_NeedUpdate;
    
    /**
    * Property ScriptCount
    *
    * Total number of scripts to show.
    */
    
    /**
    * Property ScriptPos
    *
    * Current script position.
    */
    private int __m_ScriptPos;
    
    // Initializing constructor
    public CDScript(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/CDScript".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Apply script changes to the Component Definition.
    */
    public void apply()
        {
        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        setConfig(config.getConfig(sPrefix + '.'));
        
        // to apply the Script configuration for many behaviors
        // we collect many of these at applyScriptConfig
        // However, the FindText dialog doesn't have to be configured
        // individually for each behavior, so we call the super as well...
        
        super.applyConfig(config, sPrefix);

        }
    
    protected void applyScriptConfig(com.tangosol.dev.component.Implementation impl)
        {
        if (impl != null)
            {
            $Script Script = ($Script) _findName("Script");
        
            Script.applyConfig(getConfig(), makeConfigId(impl));
            }
        }
    
    // Accessor for the property "Behavior"
    /**
    * Getter for property Behavior.<p>
    */
    public com.tangosol.dev.component.Behavior getBehavior()
        {
        return __m_Behavior;
        }
    
    // Accessor for the property "CDTool"
    /**
    * Getter for property CDTool.<p>
    * CDTool component is needed to get to the storage and helper functions. It
    * has to be supplied by the ScriptEditor.
    */
    public _package.component.dev.tool.host.CDTool getCDTool()
        {
        return null;
        }
    
    // Accessor for the property "Config"
    /**
    * Getter for property Config.<p>
    * Privately used property holding the configuration info.
    */
    protected _package.component.util.Config getConfig()
        {
        // import Component.Util.Config;
        
        Config cfg = __m_Config;
        if (cfg == null)
            {
            setConfig(cfg = new Config());
            }
        return cfg;
        }
    
    protected String getHeader(com.tangosol.dev.component.Behavior bhvr)
        {
        // import Component.Dev.Tool.Host.CDTool;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Constants;
        // import com.tangosol.dev.component.Parameter;
        
        if (bhvr == null)
            {
            return "";
            }
        
        CDTool tool = getCDTool();
        
        StringBuffer sb = new StringBuffer();
        switch (bhvr.getAccess())
            {
            case Constants.ACCESS_PUBLIC:
                sb.append("public ");
                break;
            case Constants.ACCESS_PROTECTED:
                sb.append("protected ");
                break;
            case Constants.ACCESS_PRIVATE:
                sb.append("private ");
                break;
            }
        
        if (bhvr.isAbstract())
            {
            sb.append("abstract ");
            }
        
        if (bhvr.isStatic())
            {
            sb.append("static ");
            }
        
        if (bhvr.isFinal())
            {
            sb.append("final ");
            }
        
        if (bhvr.isSynchronized())
            {
            sb.append("synchronized ");
            }
        
        String sType = tool.getDisplayValue(bhvr.getReturnValue().getDataType());
        
        sb.append(sType.substring(sType.lastIndexOf('.') + 1))
          .append(' ')
          .append(bhvr.getName())
          .append('(');
        
        int c = bhvr.getParameterCount();
        for (int i = 0; i < c; i++)
            {
            if (i > 0)
                {
                sb.append(", ");
                }
            Parameter prm = bhvr.getParameter(i);
            
            sType = tool.getDisplayValue(prm.getDataType());
        
            sb.append(sType.substring(sType.lastIndexOf('.') + 1) + " " + prm.getName());
            }
        
        sb.append(')');
        
        String[] asException = bhvr.getExceptionNames();
        boolean  fThrows     = false;
        for (int i = 0; i < asException.length; i++)
            {
            String sExcept = asException[i];
            if (bhvr.getException(sExcept) != null)
                {
                if (!fThrows)
                    {
                    sb.append("\n    throws ");
                    fThrows = true;
                    }
                else
                    {
                    sb.append(", ");
                    }
                sb.append(sExcept.substring(sExcept.lastIndexOf('.') + 1));
                }
            }
        
        return sb.toString();
        }
    
    // Accessor for the property "ScriptCount"
    /**
    * Getter for property ScriptCount.<p>
    * Total number of scripts to show.
    */
    public int getScriptCount()
        {
        return 0;
        }
    
    // Accessor for the property "ScriptPos"
    /**
    * Getter for property ScriptPos.<p>
    * Current script position.
    */
    public int getScriptPos()
        {
        return __m_ScriptPos;
        }
    
    // Accessor for the property "NeedUpdate"
    /**
    * Getter for property NeedUpdate.<p>
    */
    protected boolean isNeedUpdate()
        {
        return __m_NeedUpdate;
        }
    
    private static String makeConfigId(com.tangosol.dev.component.Implementation impl)
        {
        return String.valueOf(impl.getUID());
        }
    
    // Declared at the super level
    /**
    * This event is called by the parent JTabbedPane when the tab gets
    * selected.
    * 
    * @see JTabbedPane#onSelectionChanged
    */
    public void onSelected()
        {
        super.onSelected();
        
        if (isNeedUpdate())
            {
            update();
            }
        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        config.putConfig(sPrefix + '.', getConfig());
        
        // to save the Script configuration for many behaviors
        // we collect many of these at saveScriptConfig
        // However, the FindText dialog doesn't have to be configured
        // individually for each behavior, so we call the super as well...
        
        super.saveConfig(config, sPrefix);

        }
    
    protected void saveScriptConfig(com.tangosol.dev.component.Implementation impl)
        {
        if (impl != null)
            {
            $Script Script = ($Script) _findName("Script");
        
            Script.saveConfig(getConfig(), makeConfigId(impl));
            }
        }
    
    // Accessor for the property "Behavior"
    /**
    * Setter for property Behavior.<p>
    */
    public void setBehavior(com.tangosol.dev.component.Behavior pBehavior)
        {
        __m_Behavior = (pBehavior);
        
        if (isVisible())
            {
            update();
            }
        else
            {
            setNeedUpdate(true);
            }
        }
    
    // Accessor for the property "Config"
    /**
    * Setter for property Config.<p>
    * Privately used property holding the configuration info.
    */
    private void setConfig(_package.component.util.Config pConfig)
        {
        __m_Config = pConfig;
        }
    
    // Accessor for the property "NeedUpdate"
    /**
    * Setter for property NeedUpdate.<p>
    */
    protected void setNeedUpdate(boolean pNeedUpdate)
        {
        __m_NeedUpdate = pNeedUpdate;
        }
    
    // Accessor for the property "ScriptPos"
    /**
    * Setter for property ScriptPos.<p>
    * Current script position.
    */
    public void setScriptPos(int pScriptPos)
        {
        __m_ScriptPos = (pScriptPos);
        
        $Navigate Navigate = ($Navigate) _findName("Navigate");
        Navigate.update();
        }
    
    /**
    * Update the UI according to the Component Definition data.
    */
    protected void update()
        {
        setScriptPos(getScriptCount() > 0 ? 0 : -1);
        
        setNeedUpdate(false);
        }
    }
