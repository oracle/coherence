/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.TAPSNewDimension
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.dev.project.PointInfo;
import _package.component.dev.project.ProjectInfo$Target; // as Target
import _package.component.dev.project.ProjectInfo;
import _package.component.dev.project.StorageFactory;
import com.tangosol.util.Base;
import com.tangosol.util.ListMap;
import java.util.Date;
import javax.swing.JOptionPane;

public class TAPSNewDimension
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property BaseRequired
    *
    * Specifies that the base dimension must be selected
    */
    private transient boolean __m_BaseRequired;
    
    // Default constructor
    public TAPSNewDimension()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPSNewDimension(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(false);
            setTBounds("0,0,415,180");
            setTConstraints("Center");
            setTIcon("TAPS");
            setTitle("New {Dimension}");
            setTLayout(null);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new TAPSNewDimension$CB_Cancel("CB_Cancel", this, true), "CB_Cancel");
        _addChild(new TAPSNewDimension$CB_OK("CB_OK", this, true), "CB_OK");
        _addChild(new TAPSNewDimension$CBX_Base("CBX_Base", this, true), "CBX_Base");
        _addChild(new TAPSNewDimension$LBL_Base("LBL_Base", this, true), "LBL_Base");
        _addChild(new TAPSNewDimension$LBL_Desc("LBL_Desc", this, true), "LBL_Desc");
        _addChild(new TAPSNewDimension$LBL_Name("LBL_Name", this, true), "LBL_Name");
        _addChild(new TAPSNewDimension$TXT_Desc("TXT_Desc", this, true), "TXT_Desc");
        _addChild(new TAPSNewDimension$TXT_Name("TXT_Name", this, true), "TXT_Name");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new TAPSNewDimension();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/TAPSNewDimension".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Ends a dialog, setting the specified result of the DailogBox. The
    * conventions for the result value are:
    * Value of null means the canceled action. Value of Boolean.TRUE means the
    * default action and then the DialogBox result value is set as follows:
    * if the panel implements XmlSerializable then the result is set to the
    * appropriate XML value; otherwise the result value is set to the Config
    * object.
    * 
    * @param oResult the result value of the dialiog box with this main panel
    * 
    * @see DialogParam property
    * @see JButton.DefaultButton#onAction
    * @see JButton.EscapeButton#onAction
    */
    public void endDialog(Object oResult)
        {
        // import Component.Dev.Project.PointInfo;
        // import Component.Dev.Project.ProjectInfo;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Project.StorageFactory;
        // import com.tangosol.util.Base;
        // import javax.swing.JOptionPane;
        
        Object[] aoParam = (Object[]) getDialogParam();
        if (aoParam != null && oResult == Boolean.TRUE)
            {
            StorageFactory factory    = (StorageFactory) aoParam[0];
            Target         target     = (Target) aoParam[1];
            String         sDimension = (String) aoParam[2];
            ProjectInfo    project    = target.getProjectInfo();
        
            $CBX_Base CBX_Base  = ($CBX_Base) _findName("CBX_Base");
            $TXT_Name TXT_Name  = ($TXT_Name) _findName("TXT_Name");
            $TXT_Desc TXT_Desc  = ($TXT_Desc) _findName("TXT_Desc");
        
            String sBase = CBX_Base.getText();
            String sName = TXT_Name.getText();
        
            if (sName.length() == 0 ||
                (isBaseRequired() && sBase.length() == 0))
                {
                _beep();
                return;
                }
        
            PointInfo info;
            try
                {
                if (sDimension.equals("Version"))
                    {
                    info = project.addVersion(sName, sBase);
                    }
                else if
                   (sDimension.equals("Customization"))
                    {
                    info = project.addCustomization(sName, sBase);
                    }
                else if
                   (sDimension.equals("Localization"))
                    {
                    info = project.addLocalization(sName, sBase);
                    }
                else
                    {
                    throw new IllegalStateException("Illegal dimension: " + sDimension);
                    }
                info.setDescription(TXT_Desc.getText());
                }
            catch (Exception e)
                {
                String sMsg = e.getMessage();
                if (sMsg == null)
                    {
                    sMsg = e.toString();
                    }
                msg("Message", new Object[]
                    {
                    sMsg,
                    getTitle(),
                    new Integer(JOptionPane.ERROR_MESSAGE),
                    });
                return;
                }
        
            oResult = info;
            }
        
        super.endDialog(oResult);
        }
    
    // Accessor for the property "BaseRequired"
    /**
    * Getter for property BaseRequired.<p>
    * Specifies that the base dimension must be selected
    */
    public boolean isBaseRequired()
        {
        return __m_BaseRequired;
        }
    
    // Declared at the super level
    /**
    * The "component has been added to a containing component"
    * method-notification.
    * 
    * Note: this notification is not sent during the component's state
    * initialization (deserialization)
    * 
    * @see _addChild
    */
    public void onAdd()
        {
        // import Component.Dev.Project.ProjectInfo;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Project.StorageFactory;
        // import com.tangosol.util.Base;
        // import com.tangosol.util.ListMap;
        // import java.util.Date;
        
        super.onAdd();
        
        Object[] aoParam = (Object[]) getDialogParam();
        if (aoParam == null)
            {
            return;
            }
        
        StorageFactory factory    = (StorageFactory) aoParam[0];
        Target         target     = (Target) aoParam[1];
        String         sDimension = (String) aoParam[2];
        ProjectInfo    project    = target.getProjectInfo();
        
        $CBX_Base CBX_Base  = ($CBX_Base) _findName("CBX_Base");
        $LBL_Name LBL_Name  = ($LBL_Name) _findName("LBL_Name");
        $LBL_Base LBL_Base  = ($LBL_Base) _findName("LBL_Base");
        $TXT_Desc TXT_Desc  = ($TXT_Desc) _findName("TXT_Desc");
        
        this.setTitle(
            Base.replace(this.getTitle(),    "{Dimension}", sDimension));
        LBL_Name.setText(
            Base.replace(LBL_Name.getText(), "{Dimension}", sDimension));
        LBL_Base.setText(
            Base.replace(LBL_Base.getText(), "{Dimension}", sDimension));
        TXT_Desc.setText(
            Base.replace(TXT_Desc.getText(), "{Date}", new Date().toString()));
        
        ListMap list;
        String  sBase;
        if (sDimension.equals("Version"))
            {
            list  = project.getVersionList();
            sBase = target.getVersion();
            setBaseRequired(true);
            }
        else if
           (sDimension.equals("Customization"))
            {
            list = project.getCustomizationList();
            sBase = target.getCustomization();
            }
        else if
           (sDimension.equals("Localization"))
            {
            list = project.getLocalizationList();
            sBase = target.getLocalization();
            }
        else
            {
            throw new IllegalStateException("Illegal dimension: " + sDimension);
            }
        
        String[] asList = (String[]) list.keySet().toArray(new String[list.size()]);
        
        CBX_Base.setList(asList);
        CBX_Base.setText(sBase);

        }
    
    // Accessor for the property "BaseRequired"
    /**
    * Setter for property BaseRequired.<p>
    * Specifies that the base dimension must be selected
    */
    public void setBaseRequired(boolean pBaseRequired)
        {
        __m_BaseRequired = pBaseRequired;
        }
    
    public void validateInput()
        {
        String sName = (($TXT_Name) _findName("TXT_Name")).getText();
        String sBase = (($CBX_Base) _findName("CBX_Base")).getText();
        
        (($CB_OK) _findName("CB_OK")).setEnabled(
            sName.length() > 0 &&
            (!isBaseRequired() || sBase.length() > 0));
        }
    }
