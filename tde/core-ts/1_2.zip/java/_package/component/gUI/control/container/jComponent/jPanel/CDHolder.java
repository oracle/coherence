/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.CDHolder
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.dev.Design;
import _package.component.gUI.Control;
import _package.component.gUI.Dimension;
import _package.component.gUI.Point;
import _package.component.gUI.Rectangle;
import _package.component.gUI.control.container.JComponent;
import _package.component.gUI.control.container.jComponent.jPanel.toolSite.LayoutDesigner;
import _package.component.gUI.image.Cursor;
import com.tangosol.dev.component.Component;
import com.tangosol.util.ClassFilter;
import com.tangosol.util.FilterEnumerator;
import java.awt.Container;
import java.awt.Graphics;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

/**
* Visual component that represents a Component Definition at design time. It
* knows how to behave within a layout tool (how to select and be selected) and
* holds on the corresponding Component Definition.
*/
public class CDHolder
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property BAND
    *
    */
    public static final int BAND = 6;
    
    /**
    * Property Component
    *
    * Component Definition repesented by this holder.
    */
    private com.tangosol.dev.component.Component __m_Component;
    
    /**
    * Property DefaultChildSize
    *
    * A default hodler size for a child of the Component Definition held by
    * this CDHolder. It is used as "the best suggestion" in situations when the
    * type of a child is not yet known.
    */
    
    /**
    * Property Designer
    *
    * The LayoutDesigner [module] component.
    */
    private transient _package.component.gUI.control.container.jComponent.jPanel.toolSite.LayoutDesigner __m_Designer;
    
    /**
    * Property DesignInfo
    *
    * Cached design info.
    */
    private transient _package.component.dev.design.Component __m_DesignInfo;
    
    /**
    * Property Renderer
    *
    * Visual component used to visualize the designee [Component Definition]
    */
    private _package.component.gUI.Control __m_Renderer;
    
    /**
    * Property Root
    *
    * (Calculated) Specifies whether this holder is a root holder (holding the
    * global Component Definition)
    */
    
    /**
    * Property RootHolder
    *
    * (Calculated) Specifies the root holder (the one holding the global
    * Component Definition)
    */
    
    /**
    * Property Selected
    *
    * (Calculated) Specifies whether this holder component is currenly selected
    * (highlighted)
    */
    
    // Default constructor
    public CDHolder()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDHolder(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(true);
            setTLayout(null);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new CDHolder();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/CDHolder".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Paint this component. Default implementation calls the paint method of
    * the UI delegate.
    */
    private void _backup_paintComponent(java.awt.Graphics g)
        {
        // import Component.GUI.Control;
        
        // super.paintComponent(g); // does nothing!
        
        // draw the renderer
        Control renderer = getRenderer();
        
        if (renderer == null || renderer.get_Parent() != null)
            {
            return;
            }
        _beep();
        _trace("who is that?");
        java.awt.Component _r = (java.awt.Component) renderer.get_Feed();
        
        // Some renderers (like JComboBox) have children components
        // that have to be explicitly directed to draw since the renderer
        // is not a child and therefor was not neither validated (validate(), doLayout())
        // nor created a [lightweight] peer (addNotify()).
        
        // There are two ways to do that:
        // a) use CellRendererPane approach (see javax.swing.SwingUtilities.paintComponent)
        //    (which doesn't always paint correctly)
        // b) borrow the logic from javax.swing.JComponent#paintChildren(Graphics g)
        
        if (false)
            {
            if (_r instanceof java.awt.Container)
                {
                ((java.awt.Container) _r).doLayout();
                }
            javax.swing.SwingUtilities.paintComponent(g, _r,
                (java.awt.Container) get_Feed(), 0, 0, get_Bounds().width, get_Bounds().height);
            }
        else
            {
            // if (_r.getParent() != get_Feed())
            //    {
            //    ((java.awt.Container) get_Feed()).add(_r);
            //    }
            _r.paint(g);
        
            if (_r instanceof java.awt.Container)
                {
                java.awt.Container _c = (java.awt.Container) _r;
                
                if (_c.getComponentCount() > 0)
                    {
                    _backup_paintRendererChildren(g, _c);
                    }
                }
            }
        
        if (isRoot() && getDesigner().isShowGrid())
            {
            paintGrid(g);
            }
        }
    
    private void _backup_paintRendererChildren(java.awt.Graphics g, java.awt.Container _container)
        {
        // import java.awt.Component;
        // import java.awt.Container;
        // import java.awt.Graphics;
        // import java.awt.Rectangle;
        
        _container.doLayout();
        
        int cChildren = _container.getComponentCount();
        
        for (int i = 0; i < cChildren; i++)
            {
            Component _c = _container.getComponent(i);
            if (_c != null && _c.isVisible())
                {
                Rectangle cr = _c.getBounds();
                if (g.hitClip(cr.x, cr.y, cr.width, cr.height))
                    {
                    Graphics cg = g.create(cr.x, cr.y, cr.width, cr.height);
                    try
                        {
                        _c.paint(cg);
        
                        if (_c instanceof Container)
                            {
                            _backup_paintRendererChildren(cg, (Container) _c);
                            }
                        }
                    finally
                        {
                        cg.dispose();
                        }
                    }
                }
            }
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control;
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.LayoutDesigner;
        

        }
    
    // Declared at the super level
    public void doLayout()
        {
        // import Component.GUI.Rectangle;
        
        Control renderer = getRenderer();
        if (renderer != null)
            {
            Rectangle r = new Rectangle();
            r.setSize(getSize());
            
            renderer.setBounds(r);
            }
        
        super.doLayout();

        }
    
    /**
    * Enumerates children CDHolders.
    */
    public java.util.Enumeration enumHolders()
        {
        // import com.tangosol.util.ClassFilter;
        // import com.tangosol.util.FilterEnumerator;
        
        ClassFilter filter = new ClassFilter(CDHolder.class);
        
        return new FilterEnumerator(_enumChildren(), filter);

        }
    
    /**
    * Find a child holder at the specified point (in this holder coordinates).
    * 
    * @param point  coordinates to look a child holder at
    * @param fExpand  if true, the child's bounds get expanded (according to
    * the selection band width) before the "contains" test is performed.
    * @param fShallow if true, only immediate children of this holder get
    * tested; otherwise the entire hierarchy gets traversed and the "deepest"
    * one that fits is returned.
    * 
    * @return a child holder or "this" if none of the children qualifies and
    * modifies the point parameter is such a way that it becomes relative to
    * the returned child and the hit code could be queried right away with
    * child.getHitCode(point)
    */
    public CDHolder findChildAt(_package.component.gUI.Point point, boolean fExpand, boolean fShallow)
        {
        // import Component.GUI.Point;
        // import Component.GUI.Rectangle;
        // import java.util.Enumeration;
        
        for (Enumeration enum = enumHolders(); enum.hasMoreElements();)
            {
            CDHolder child = (CDHolder) enum.nextElement();
            if (!child.isVisible())
                {
                continue;
                }
        
            Rectangle rect   = child.getBounds();
            boolean   fHitIn = rect.contains(point);
            boolean   fHit   = fHitIn;
                
            if (!fHit && fExpand)
                {
                rect.grow(BAND, BAND);
                fHit = rect.contains(point);
                }
        
            if (fHit)
                {
                point.sub(child.getLocation());
        
                if (fShallow || !fHitIn)
                    {
                    return child;
                    }
        
                return child.findChildAt(point, fExpand, fShallow);
                }
            }
        
        return this;
        }
    
    /**
    * Gets a child holder for the specified component definition.
    */
    public CDHolder findHolder(com.tangosol.dev.component.Component cd)
        {
        // import java.util.Enumeration;
        
        if (getComponent() == cd)
            {
            return this;
            }
        
        for (Enumeration enum = enumHolders(); enum.hasMoreElements();)
            {
            CDHolder child = ((CDHolder) enum.nextElement()).findHolder(cd);
        
            if (child != null)
                {
                return child;
                }
            }
        
        return null;
        }
    
    /**
    * Returns a list of children holders that fit into the specified rectangle.
    * The rectangle coordinates are assumed to be relative to "this" holder.
    */
    public java.util.List findIntersection(_package.component.gUI.Rectangle rect)
        {
        // import Component.GUI.Point;
        // import Component.GUI.Rectangle;
        // import java.util.Enumeration;
        // import java.util.LinkedList;
        // import java.util.List;
        
        List list = new LinkedList();
        
        for (Enumeration enum = enumHolders(); enum.hasMoreElements();)
            {
            CDHolder holder = (CDHolder) enum.nextElement();
            
            if (rect.contains(holder.getBounds()))
                {
                list.add(holder);
                }
            }
        
        if (list.isEmpty())
            {
            // at this level we could not find any;
            // lets go down to the children's children
            
            for (Enumeration enum = enumHolders(); enum.hasMoreElements();)
                {
                CDHolder holder = (CDHolder) enum.nextElement();
        
                Rectangle rectIntersection = rect.intersection(holder.getBounds());
                if (!rectIntersection.isEmpty())
                    {
                    Point locHolder = holder.getLocation();
                    locHolder.neg();
                    rectIntersection.translate(locHolder);
                    
                    list = holder.findIntersection(rectIntersection);
                    if (!list.isEmpty())
                        {
                        break;
                        }
                    }
                }
            }
        
        return list;
        }
    
    // Accessor for the property "Component"
    public com.tangosol.dev.component.Component getComponent()
        {
        return __m_Component;
        }
    
    // Accessor for the property "DefaultChildSize"
    public _package.component.gUI.Dimension getDefaultChildSize()
        {
        // import Component.GUI.Dimension;
        
        return Dimension.instantiate(70, 30);
        }
    
    // Accessor for the property "Designer"
    public _package.component.gUI.control.container.jComponent.jPanel.toolSite.LayoutDesigner getDesigner()
        {
        LayoutDesigner designer = __m_Designer;
        if (designer == null)
            {
            designer = (LayoutDesigner) _findAncestor(LayoutDesigner.class);
            setDesigner(designer);
            }
        return designer;
        }
    
    // Accessor for the property "DesignInfo"
    public _package.component.dev.design.Component getDesignInfo()
        {
        return __m_DesignInfo;
        }
    
    // Declared at the super level
    /**
    * Returns a cursors for Drag and Drop actions. Index represents a Drag&Drop
    * action.
    * 
    * @see #DragCursor property
    */
    public _package.component.gUI.image.Cursor getDragCursor(int pIndex)
        {
        // import Component.GUI.Image.Cursor;
        
        Cursor cursor = super.getDragCursor(pIndex);
        cursor.set_Cursor(java.awt.Cursor.getPredefinedCursor(
                java.awt.Cursor.MOVE_CURSOR));
        _trace("providing cursor " + cursor.get_Cursor());
        return cursor;
        }
    
    /**
    * Returns a hit code for the specified point (in coordinates relative to
    * this holder).
    * 
    * @param point  coordinates to get a hit code for
    * 
    * @return one of the following codes:
    * 
    * -1 -- Outside
    * 0  -- North West 
    * 1  -- North
    * 2  -- North East
    * 3  -- West
    * 4  -- Inside or at the band but not the handle
    * 5  -- East
    * 6  -- South West
    * 7  -- South
    * 8  -- South East
    * 
    * @see #isHandleSizeable
    * @see LayoutDesigner#ResizeOp
    */
    public int getHitCode(_package.component.gUI.Point point)
        {
        // import Component.GUI.Dimension;
        // import Component.GUI.Point;
        // import Component.GUI.Rectangle;
        
        Dimension size = getSize();
        Rectangle rect = new Rectangle();
        
        rect.setSize(size);
        if (rect.contains(point))
            {
            return 4; // Inside
            }
        
        rect.grow(BAND, BAND);
        
        if (!rect.contains(point))
            {
            return -1; // Outside
            }
        
        int x = point.getX();
        int y = point.getY();
        int w = size.getWidth();
        int h = size.getHeight();
        
        if (y <= 0)
            {
            if (x <= 0)
                {
                return 0; // North West
                }
            else if (x >= w/2 - BAND/2 && x <= w/2 + BAND/2)
                {
                return 1; // North
                }
            else if (x >= w)
                {
                return 2; // North East
                }
            }
        else if (y >= h)
            {
            if (x <= 0)
                {
                return 6; // South West
                }
            else if (x >= w/2 - BAND/2 && x <= w/2 + BAND/2)
                {
                return 7; // South
                }
            else if (x >= w)
                {
                return 8; // South East
                }
            }
        else if (y >= h/2 - BAND/2 && y <= h/2 + BAND/2)
            {
            if (x <= 0)
                {
                return 3; // West
                }
            else if (x >= w)
                {
                return 5; // East
                }
            }
        
        return 4;
        }
    
    // Accessor for the property "Renderer"
    public _package.component.gUI.Control getRenderer()
        {
        return __m_Renderer;
        }
    
    // Accessor for the property "RootHolder"
    public CDHolder getRootHolder()
        {
        CDHolder holder = this;
        
        while (!holder.isRoot())
            {
            holder = (CDHolder) holder.get_Parent();
            }
        
        return holder;
        }
    
    /**
    * Instantiates a renderer corresponding to the designee [Component
    * Definition]. Default implementation gets the renderer out of design info.
    * Subclasses should overwrite this method (usually NOT calling the super
    * implementation).
    * 
    * @see #Renderer
    * @see #updateRenderer
    * @see Component.Dev.Design.Component#instantiateComponentRenderer
    * @see #setComponent
    */
    protected _package.component.gUI.Control instantiateRenderer(com.tangosol.dev.component.Component cd)
        {
        return getDesignInfo().instantiateComponentRenderer(cd);
        }
    
    /**
    * Returns true is the specified handle of this holder allows resize
    * operation. The codes of the handles are:
    * 0 - (0, 0) -- North West 
    * 1 - (1, 0) -- North
    * 2 - (2, 0) -- North East
    * 3 - (0, 1) -- West
    * 4 - (1, 1) -- Not Applicable
    * 5 - (2, 1) -- East
    * 6 - (0, 2) -- South West
    * 7 - (1, 2) -- South
    * 8 - (2, 2) -- South East
    * 
    * @see #getHitCode
    */
    public boolean isHandleSizeable(int iCode)
        {
        // TODO: ask the DesignInfo
        
        if (iCode < 0 || iCode == 4)
            {
            return false;
            }
        
        int ix = iCode % 3;
        int iy = iCode / 3;
        
        return isRoot() ? ix > 0 && iy > 0 : true;
        }
    
    // Accessor for the property "Root"
    public boolean isRoot()
        {
        return getComponent().isGlobal();
        }
    
    // Accessor for the property "Selected"
    public boolean isSelected()
        {
        return getDesigner().getSelection().contains(this);
        }
    
    /**
    * Instantiates a new CDHolder component for the specifed Designee [Componen
    * Definition]
    * 
    * @return a newly instantiated component holder or null if specified
    * Component Definition is not visualizable.
    */
    public static CDHolder makeComponentHolder(com.tangosol.dev.component.Component cd)
        {
        // import Component.Dev.Design;
        
        Design.Component info   = Design.getDesignInfo(cd);
        CDHolder         holder = new CDHolder();
        
        holder.setDesignInfo(info);
        holder.setComponent(cd); // in turn makes children holders
        
        return holder;
        }
    
    // Declared at the super level
    /**
    * Paint this component. Default implementation calls the paint method of
    * the UI delegate.
    */
    public void paintComponent(java.awt.Graphics g)
        {
        if (getRenderer() == null)
            {
            // use the CDHolder's panel as the renderer
            super.paintComponent(g);
            }
        
        if (isRoot() && getDesigner().isShowGrid())
            {
            paintGrid(g);
            }
        }
    
    /**
    * Paint the grid (on the root holder).
    */
    private void paintGrid(java.awt.Graphics g)
        {
        // import Component.GUI.Dimension;
        
        Dimension dim = getRootHolder().getSize();
        
        int dx = getDesigner().getGridWidth();
        int dy = getDesigner().getGridHeight();
        
        int x0 = dx; // don't do the "0" column
        int y0 = dy; // don't do the "0" row
        int x1 = dim.getWidth();
        int y1 = dim.getHeight();
        
        g.setColor(java.awt.Color.black);
        for (int x = x0; x <= x1; x += dx)
            {
            for (int y = y0; y <= y1; y += dy)
                {
                g.drawLine(x, y, x, y);
                }
            }
        }
    
    /**
    * Reloads all children
    */
    public void reloadChildren()
        {
        // import Component.Dev.Design;
        // import com.tangosol.dev.component.Component;
        // import java.util.ListIterator;
        // import java.util.List;
        
        LayoutDesigner Designer  = getDesigner();
        List           selection = null;
        
        if (Designer != null && _isAncestorOf(Designer.getSelectionAnchor()))
            {
            selection = Designer.getSelection();
            }
        
        removeAllHolders();
        
        Component cd = getComponent();
        
        String[] asChildren = cd.getChildren();
        for (int i = 0; i < asChildren.length; i++)
            {
            String    sChild  = asChildren[i];
            Component cdChild = cd.getChild(sChild);
        
            if (cdChild != null)
                {
                CDHolder holderChild = makeComponentHolder(cdChild);
                if (holderChild != null)
                    {
                    _addChild(holderChild, cdChild.getUID().toString());
                    }
                else
                    {
                    // component is not visualizable
                    }
                }
            else
                {
                // component is removed
                }
            }
        
        if (selection != null)
            {
            // children holders were replaced -- update the selection list
            
            for (ListIterator iter = selection.listIterator(); iter.hasNext();)
                {
                CDHolder holderOld = (CDHolder) iter.next();
                CDHolder holderNew = findHolder(holderOld.getComponent());
                if (holderNew == null)
                    {
                    // quite unlikely to happen
                    iter.remove();
                    }
                else
                    {
                    iter.set(holderNew);
                    }
                }
            }
        }
    
    private void removeAllHolders()
        {
        // import com.tangosol.util.ClassFilter;
        // import com.tangosol.util.FilterEnumerator;
        // import java.util.Enumeration;
        
        Enumeration enum = new FilterEnumerator(_enumChildren(), new ClassFilter(CDHolder.class));
        while (enum.hasMoreElements())
            {
            _removeChild((CDHolder) enum.nextElement());
            }
        }
    
    // Accessor for the property "Component"
    protected void setComponent(com.tangosol.dev.component.Component pComponent)
        {
        _assert(getComponent() == null || getRenderer() == null);
        
        __m_Component = (pComponent);
        
        Control renderer = instantiateRenderer(pComponent);
        
        if (renderer == null)
            {
            setVisible(false);
            }
        else
            {
            _addChild(renderer, "_renderer");
            setRenderer(renderer);
            }
        
        update();
        
        reloadChildren();

        }
    
    // Accessor for the property "Designer"
    private void setDesigner(_package.component.gUI.control.container.jComponent.jPanel.toolSite.LayoutDesigner pDesigner)
        {
        __m_Designer = pDesigner;
        }
    
    // Accessor for the property "DesignInfo"
    protected void setDesignInfo(_package.component.dev.design.Component pDesignInfo)
        {
        __m_DesignInfo = pDesignInfo;
        }
    
    // Accessor for the property "Renderer"
    public void setRenderer(_package.component.gUI.Control pRenderer)
        {
        __m_Renderer = pRenderer;
        }
    
    // Declared at the super level
    public String toString()
        {
        return "CDHolder " + getComponent().getName();
        }
    
    /**
    * Update the visual attributes of the component holder according to the
    * underlying Component Definition. Subclasses should overwrite this method
    * providing the most suitable visual representation.
    */
    public void update()
        {
        updateRenderer();
        
        set_PreferredSize(get_Size()); // some LayoutManagers need this
        
        if (getDesigner() != null) // are we already plugged in?
            {
            revalidate();
            if (isSelected())
                {
                getDesigner().repaint();
                }
            else
                {
                repaint();
                }
            }

        }
    
    /**
    * Updates attributes of the renderer component for this holder. Subclasses
    * could overwrite this method extracting and applying values of relevant
    * properties to the rendering component.
    * 
    * @see Component.Dev.Design.Component#updateComponentHolder
    */
    protected void updateRenderer()
        {
        getDesignInfo().updateComponentHolder(this);
        }
    
    // Declared at the super level
    public void updateUI()
        {
        // import Component.GUI.Control.Container.JComponent;
        
        super.updateUI();
        
        Control renderer = getRenderer();
        if (renderer instanceof JComponent)
            {
            ((JComponent) renderer).updateUI();
            }
        }
    }
