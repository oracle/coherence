/* Class
*     _package.component.gUI.control.container.jComponent.jInternalFrame.CDToolFrame
*/

package _package.component.gUI.control.container.jComponent.jInternalFrame;

import _package.component.gUI.Point;
import _package.component.gUI.control.container.jComponent.JPopupMenu;
import _package.component.gUI.control.container.jComponent.jPanel.ToolSite;
import javax.swing.JComponent; // as _JComponent
import javax.swing.JPopupMenu; // as _JPopupMenu
import javax.swing.MenuElement;
import javax.swing.MenuSelectionManager;

/**
* This is an extension of the JInternalFrame that is used by the some ToolSite
* components that want to appear inside of the ComponentDesigner host.
* 
* The reasons we use this instead of the JInternalFrame are: making the frame
* invisible instead of closing it on the "internalFrameClosing" event and the
* "System menu" emulation.
*/
public class CDToolFrame
        extends    _package.component.gUI.control.container.jComponent.JInternalFrame
    {
    // Fields declarations
    
    // Default constructor
    public CDToolFrame()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDToolFrame(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAllowClosing(false);
            setClosable(true);
            setFocusable(true);
            setIconifiable(true);
            setMaximizable(true);
            setResizable(true);
            setVisible(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new CDToolFrame$KeyMenu("KeyMenu", this, true), "KeyMenu");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new CDToolFrame();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jInternalFrame/CDToolFrame".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    public void invokePopupMenu()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite;
        // import Component.GUI.Control.Container.JComponent.JPopupMenu;
        // import Component.GUI.Point;
        // import javax.swing.JComponent as _JComponent;
        // import javax.swing.MenuSelectionManager;
        // import javax.swing.MenuElement;
        // import javax.swing.JPopupMenu as _JPopupMenu;
        
        ToolSite   site    = (ToolSite) _findChild(MAIN_PANEL);
        JPopupMenu context = site.getContextMenu();
        
        if (context != null && !context.isVisible())
            {
            _JComponent _pane = get_TitlePane();
            context.setInvoker(this);
            context.setLocation(Point.instantiate(_pane.getX(), _pane.getHeight()));
            context.setVisible(true);
            }
        }
    
    // Declared at the super level
    /**
    * Method notification invoked when an internal frame is activated.
    */
    public void onInternalFrameActivated()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite;
        
        super.onInternalFrameActivated();
        
        // work around a swing bug -- wrong internal frame's menu gets activated
        // TODO: remove when fixed
        (($KeyMenu) _findName("KeyMenu")).bind();
        
        ToolSite site = (ToolSite) _findChild(MAIN_PANEL);
        site.onActivated();

        }
    
    // Declared at the super level
    /**
    * Method notification invoked when an internal frame is in the process of
    * being closed.
    * 
    * @see comments to setClosed()
    */
    public void onInternalFrameClosing()
        {
        super.onInternalFrameClosing();
        
        setVisible(false);
        
        /* if we wanted to actually close the tool, the code would look like:
        
            // we must be careful here -- JInternalFrame sends this event many times
            ToolSite toolSite = (ToolSite) _findChild(MAIN_PANEL);
            toolSite.getTool().setOpen(false);
        */
        }
    
    // Declared at the super level
    /**
    * Method notification invoked when an internal frame is de-activated
    */
    public void onInternalFrameDeactivated()
        {
        super.onInternalFrameDeactivated();
        
        // work around a swing bug -- wrong internal frame's menu gets activated
        // TODO: remove when fixed
        (($KeyMenu) _findName("KeyMenu")).unbind();
        }
    
    // Declared at the super level
    public void onTitleMouseClicked(int x, int y, int modifiers, int clickCount)
        {
        super.onTitleMouseClicked(x, y, modifiers, clickCount);
        
        // the reason we do the system menu emulation on mouse click
        // rather then on mouse pressed is that moving the mouse
        // would move the frame causing the menu to float "unattached"
        
        if (x <= 24)
            {
            // the system icon bounds hardcoded in BasicInternalFrameTitlePane
            // as (2, 1, 16, 16), but we allow some "missed" clicks
            invokePopupMenu();
            }
        

        }
    }
