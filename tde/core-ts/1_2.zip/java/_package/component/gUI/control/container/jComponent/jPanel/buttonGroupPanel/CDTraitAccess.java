/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.buttonGroupPanel.CDTraitAccess
*/

package _package.component.gUI.control.container.jComponent.jPanel.buttonGroupPanel;

public class CDTraitAccess
        extends    _package.component.gUI.control.container.jComponent.jPanel.ButtonGroupPanel
    {
    // Fields declarations
    
    // Default constructor
    public CDTraitAccess()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDTraitAccess(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setLayout(null);
            setOpaque(false);
            setResizable(false);
            setTBounds("0,0,80,51");
            setTConstraints("Center");
            setTitle("Accessibility");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new CDTraitAccess$RB_Private("RB_Private", this, true), "RB_Private");
        _addChild(new CDTraitAccess$RB_Protected("RB_Protected", this, true), "RB_Protected");
        _addChild(new CDTraitAccess$RB_Public("RB_Public", this, true), "RB_Public");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new CDTraitAccess();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/buttonGroupPanel/CDTraitAccess".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    }
