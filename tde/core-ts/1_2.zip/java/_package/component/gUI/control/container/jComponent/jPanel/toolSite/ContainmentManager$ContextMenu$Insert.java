/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.toolSite.ContainmentManager$ContextMenu$Insert
*/

package _package.component.gUI.control.container.jComponent.jPanel.toolSite;

public class ContainmentManager$ContextMenu$Insert
        extends    _package.component.gUI.control.container.jComponent.abstractButton.JMenuItem
    {
    // Fields declarations
    
    // Default constructor
    public ContainmentManager$ContextMenu$Insert()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ContainmentManager$ContextMenu$Insert(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(1.0F);
            setFocusable(true);
            setMnemonic('I');
            setText("Insert Component");
            setTFont("DefaultMenu");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ContainmentManager$ContextMenu$Insert();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/toolSite/ContainmentManager$ContextMenu$Insert".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent();
        }
    
    // Declared at the super level
    /**
    * This notification (called by actionPerformed) is sent when an armed item
    * (Armed == true) gets unpressed (Pressed == false). This also could be a
    * result of an "accelerator key" action.
    * 
    * Note: setting the Selected property to true (calling setSelected(true))
    * does not trigger an Action event. However, calling doClick() does.
    * 
    * @param action  content of this component's ActionComand property
    * @param modifiers  the key modifier that was selected, and is used to
    * determine the state of the selected key
    * @param param  currently not used (intended for for event-logging and for
    * debugging)
    * 
    * @see #onItemStateChanged
    * @see #onStateChanged
    * @see javax.swing.DefaultButtonModel#setPressed
    */
    public void onAction(String action, int modifiers, String param)
        {
        super.onAction(action, modifiers, param);
        
        (($Module) get_Module()).insertComponent(null);
        }
    }
