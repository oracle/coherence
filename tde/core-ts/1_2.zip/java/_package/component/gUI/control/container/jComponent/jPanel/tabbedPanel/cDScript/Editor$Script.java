/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.cDScript.Editor$Script
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.cDScript;

import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Implementation;
import java.awt.Event;
import java.awt.event.KeyEvent;

public class Editor$Script
        extends    _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDScript$Script
    {
    // Fields declarations
    
    // Default constructor
    public Editor$Script()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Editor$Script(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAutoIndent(true);
            setDropActions(2);
            setDropAllowed(true);
            setEditable(false);
            setFocusable(true);
            setScrollable(true);
            setTabAllowed(false);
            setTabSize(4);
            setTConstraints("Center");
            setTFont("TAPS.Scripts");
            setUndoLimit(100);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new Editor$Script$FindText("FindText", this, true), "FindText");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDScript$Script$GotoLine("GotoLine", this, true), "GotoLine");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDScript$Script$KeyGotoMatchBrace("KeyGotoMatchBrace", this, true), "KeyGotoMatchBrace");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDScript$Script$KeyGotoMatchBraceExtend("KeyGotoMatchBraceExtend", this, true), "KeyGotoMatchBraceExtend");
        _addChild(new _package.component.gUI.control.container.jComponent.JTextComponent$KeyRedo("KeyRedo", this, true), "KeyRedo");
        _addChild(new _package.component.gUI.control.container.jComponent.JTextComponent$KeyUndo("KeyUndo", this, true), "KeyUndo");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Editor$Script();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/cDScript/Editor$Script".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    public void onKeyReleased(char keyChar, int keyCode, int modifiers)
        {
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Implementation;
        
        super.onKeyReleased(keyChar, keyCode, modifiers);
        
        $Module Editor = ($Module) get_Module();
        
        Behavior       bhvr  = Editor.getBehavior();
        Implementation impl  = Editor.getImplementation();
        
        if (bhvr != null)
            {
            if (impl == null ^ getText().trim().length() == 0)
                {
                Editor.apply();
                }
            }

        }
    
    // Declared at the super level
    /**
    * JTextComponents almost never gets the keyTyped event (except BackSpace,
    * Enter...) !!!
    * 
    * @see http://developer.java.sun.com/developer/bugParade/bugs/4197167.html
    */
    public void onKeyTyped(char keyChar, int modifiers)
        {
        // import java.awt.Event;
        // import java.awt.event.KeyEvent;
        
        super.onKeyTyped(keyChar, modifiers);
        
        // de-indent after the '}'
        if (keyChar == KeyEvent.VK_ENTER                            &&
            (modifiers & (Event.CTRL_MASK | Event.SHIFT_MASK)) == 0 &&
            isAutoIndent())
            {
        	// Note: we are processing after the call to super.onKeyTyped()
            int ofPos = getCaretPosition();
            int iLine = getLineOfOffset(ofPos);
        
            if (iLine > 0)
                {
                int ofEndPrev = getLineEndOffset(iLine - 1);
                String sText  = getText();
        
                // un-indent after '}'
                if (ofEndPrev >= 2 && sText.charAt(ofEndPrev - 2) == '}')
                    {
                    int ofStart = getLineStartOffset(iLine);
                    int nTab    = getTabSize();
                    
                    if (ofPos - ofStart > 0)
                        {
                        replaceRange("", Math.max(ofPos - nTab, ofStart), ofPos);
                        }
                    }
                }
            }
        }
    
    // Declared at the super level
    /**
    * Prepares to transfer something at the specified location for the
    * specified action
    * 
    * @return true if transfer is going to be accepted; false otherwise
    * 
    * @see dragOver()
    */
    protected boolean prepareTransferAtLocation(_package.component.gUI.Point point, int iAction, java.util.List listFlavors)
        {
        $Module Module = ($Module) get_Module();
        
        if (!Module.getCDTool().isActive())
            {
            Module.moveToFront();
            }
        
        return super.prepareTransferAtLocation(point, iAction, listFlavors);
        }
    }
