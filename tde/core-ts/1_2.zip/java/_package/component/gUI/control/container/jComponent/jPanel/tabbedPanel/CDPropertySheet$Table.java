/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDPropertySheet$Table
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel;

import _package.component.dev.Design;
import _package.component.dev.tool.host.cDTool.PropertyTool;
import _package.component.gUI.Color;
import _package.component.gUI.Font;
import _package.component.gUI.control.container.jComponent.JComboBox;
import _package.component.gUI.tableCell.cDTraitCell.CDPropertyCell;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Property;
import java.awt.Color; // as _Color
import java.awt.Component; // as _Control
import java.awt.Font; // as _Font
import java.beans.PropertyVetoException;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox; // as _JComboBox

public class CDPropertySheet$Table
        extends    _package.component.gUI.control.container.jComponent.JTable
    {
    // Fields declarations
    
    /**
    * Property Updating
    *
    * Privately used property that is set to true when and only when the value
    * of a property getting set (which could send an PropertyChange event
    * causing, in turn, the value be set again)
    * 
    * @see #setValueAt
    */
    private transient boolean __m_Updating;
    
    // Default constructor
    public CDPropertySheet$Table()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDPropertySheet$Table(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAutoResizeMode(2);
            setAutoscrolls(true);
            setCellSelectionEnabled(true);
            setColumnMargin(2);
            setColumnSelectionAllowed(false);
            setDropActions(3);
            setDropAllowed(true);
            setFocusable(true);
            setHorizontalScrollBarPolicy(30);
            setLastColumnSelected(-1);
            setLastRowSelected(-1);
            setReorderingAllowed(false);
            setResizingAllowed(true);
            setRowHeight(17);
            setRowMargin(1);
            setRowSelectionAllowed(true);
            setScrollable(true);
            setSelectionMode(0);
            setShowGrid(true);
            setShowHorizontalLines(true);
            setShowVerticalLines(true);
            setTBorder("EtchedSimple");
            setTConstraints("Center");
            setTFont("DefaultProportional");
            setVerticalScrollBarPolicy(20);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new CDPropertySheet$Table$Name("Name", this, true), "Name");
        _addChild(new CDPropertySheet$Table$Value("Value", this, true), "Value");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new CDPropertySheet$Table();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/CDPropertySheet$Table".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    /**
    * Find a row with a specified property; -1 if not found
    */
    public int findPropertyRow(com.tangosol.dev.component.Property prop)
        {
        return findPropertyRow(prop.getName());
        }
    
    /**
    * Find a row with a specified property; -1 if not found
    */
    public int findPropertyRow(String sName)
        {
        return getColumn("Name").findItem(sName);
        }
    
    // Declared at the super level
    public javax.swing.table.TableCellEditor getCellEditor(int iRow, int iColumn)
        {
        // import Component.Dev.Design;
        // import Component.Dev.Tool.Host.CDTool.PropertyTool;
        // import Component.GUI.Control.Container.JComponent.JComboBox;
        // import Component.GUI.TableCell.CDTraitCell.CDPropertyCell;
        // import com.tangosol.dev.component.Property;
        // import javax.swing.JComboBox as _JComboBox;
        // import javax.swing.DefaultCellEditor;
        
        _assert(iColumn == 1);
        
        CDPropertyCell cell = (CDPropertyCell) getValueAt(iRow, 0);
        Property       prop = cell.getProperty();
        Design         info = Design.getDesignInfo(prop);
        
        if (info.isChoice())
            {
            JComboBox combo = new JComboBox();
        
            combo.setEditable(true);
            combo.setItems(info.getTextChoices());
            return new DefaultCellEditor((_JComboBox) combo.get_Feed());
            }
        else
            {
            return super.getCellEditor(iRow, iColumn);
            }
        }
    
    // Declared at the super level
    public boolean isCellEditable(int iRow, int iColumn)
        {
        // import Component.GUI.TableCell.CDTraitCell.CDPropertyCell;
        // import com.tangosol.dev.component.Property;
        
        if (!super.isCellEditable(iRow, iColumn))
            {
            return false;
            }
        
        CDPropertyCell cell = (CDPropertyCell) getValueAt(iRow, 0);
        Property       prop = cell.getProperty();
        
        return prop.isValueSettable();
        }
    
    // Accessor for the property "Updating"
    private boolean isUpdating()
        {
        return __m_Updating;
        }
    
    // Declared at the super level
    public void onKeyReleased(char keyChar, int keyCode, int modifiers)
        {
        super.onKeyReleased(keyChar, keyCode, modifiers);
        
        if (keyCode == java.awt.event.KeyEvent.VK_DELETE && getSelectedColumn() == 0)
            {
            (($Module) get_Module()).removeCurrentProperty();
            }
        }
    
    // Declared at the super level
    /**
    * Event notification sent when the current selection changes. This method
    * could be called twice -- once for row selection change and once for
    * column selection change. Properties LastColumnSelected and
    * LastRowSelected could be used to filter this out.
    * 
    * @see #valueChanged
    */
    public void onSelected(int iRow, int iColumn)
        {
        super.onSelected(iRow, iColumn);
        
        (($Tip) _findName("Tip")).update();
        }
    
    // Declared at the super level
    public java.awt.Component prepareRenderer(javax.swing.table.TableCellRenderer renderer, int iRow, int iColumn)
        {
        // import Component.GUI.Color;
        // import Component.GUI.Font;
        // import Component.GUI.TableCell.CDTraitCell.CDPropertyCell;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Property;
        // import java.awt.Component as _Control;
        // import java.awt.Color as _Color;
        // import java.awt.Font as _Font;
        
        _Control _renderer;
        try
            {
            _renderer = super.prepareRenderer(renderer, iRow, iColumn);
            }
        catch (Exception e)
            {
            // JDK bug #4209280: exception on unknown HTML tag
            // TODO: remove when fixed
            String HTML   = "<html>";
            String sValue = (String) getValueAt(iRow, iColumn);
            if (sValue.startsWith(HTML))
                {
                setValueAt(sValue.substring(HTML.length()), iRow, iColumn);
                }
            else
                {
                setValueAt("?", iRow, iColumn);
                }
            _renderer = super.prepareRenderer(renderer, iRow, iColumn);
            }
        
        boolean fItalic = false;
        _Color  _color  = null;
        
        if (isRowSelected(iRow))
            {
            // selected row -- retain the selection color
            }
        else
            {
            CDPropertyCell cell = (CDPropertyCell) getValueAt(iRow, 0);
            Property       prop = cell.getProperty();
            Color          color;
        
            if (iColumn == 1 && !prop.isValueDiscardable())
                {
                color = (Color) Color.TAPS.Declared.get_Instance();
                }
            else if (!prop.isDeclaredAtThisLevel())
                {
                fItalic = iColumn == 1 && prop.isFromBase();
                color   = (Color) Color.TAPS.Inherited.get_Instance();
                }
            else if (prop.isFromIntegration())
                {
                color = (Color) Color.TAPS.Integrated.get_Instance();
                }
            else
                {
                Behavior bhvrGetter = prop.getAccessor(Property.PA_GET_SINGLE);
                Behavior bhvrSetter = prop.getAccessor(Property.PA_SET_SINGLE);
        
                if (bhvrGetter != null && bhvrGetter.isFromIntegration()
                 || bhvrSetter != null && bhvrSetter.isFromIntegration())
                    {
                    color = (Color) Color.TAPS.Integrated.get_Instance();
                    }
                else
                    {
                    color = (Color) Color.TAPS.Declared.get_Instance();
                    }
                }
            _color = color.get_Color();
            }
        
        _Font _font = _renderer.getFont();
        if (_font == null || _font.isItalic() != fItalic)
            {
            Font font = getFont();
            font.setItalic(fItalic);
            _renderer.setFont(font.get_Font());
            }
        if (_color != null && !_color.equals(_renderer.getBackground()))
            {
            _renderer.setBackground(_color);
            }
        return _renderer;
        }
    
    // Declared at the super level
    /**
    * Prepares to transfer something at the specified location for the
    * specified action
    * 
    * @return true if transfer is going to be accepted; false otherwise
    * 
    * @see dragOver()
    */
    protected boolean prepareTransferAtLocation(_package.component.gUI.Point point, int iAction, java.util.List listFlavors)
        {
        $Module Module = ($Module) get_Module();
        
        if (!Module.getPropertyTool().isActive())
            {
            Module.moveToFront();
            }
        
        return super.prepareTransferAtLocation(point, iAction, listFlavors);
        }
    
    // Declared at the super level
    public void removeRow(int iRow)
        {
        super.removeRow(iRow);
        
        if (getRowCount() == 0)
            {
            // everything has been removed
            (($Tip) _findName("Tip")).setText("");
            }
        }
    
    // Accessor for the property "Updating"
    private void setUpdating(boolean pUpdating)
        {
        __m_Updating = pUpdating;
        }
    
    // Declared at the super level
    public void setValueAt(Object oValue, int iRow, int iCol)
        {
        // import Component.Dev.Tool.Host.CDTool.PropertyTool;
        // import Component.GUI.TableCell.CDTraitCell.CDPropertyCell;
        // import com.tangosol.dev.component.Property;
        // import java.beans.PropertyVetoException;
        
        if (iCol == 1)
            {
            if (isUpdating())
                {
                return;
                }
        
            PropertyTool   tool = (($Module) get_Module()).getPropertyTool();
            CDPropertyCell cell = (CDPropertyCell) getValueAt(iRow, 0);
            Property       prop = cell.getProperty();
        
            if (prop.isValueSettable())
                {
                try
                    {
                    String sValue = (String) oValue;
        
                    oValue = sValue.equals("?") ?
                        prop.getDefaultValue() : tool.getPropertyValue(sValue, prop);
                    
                    setUpdating(true);
                    prop.setValue(oValue);
                    }
                // IllegalArgumentException, PropertyVetoException
                catch (Exception e)
                    {
                    _trace(e.getMessage(), 1);
                    }
                finally
                    {
                    setUpdating(false);
                    }
                oValue = tool.getDisplayValue(prop);
                }
            }
        
        super.setValueAt(oValue, iRow, iCol);
        }
    }
