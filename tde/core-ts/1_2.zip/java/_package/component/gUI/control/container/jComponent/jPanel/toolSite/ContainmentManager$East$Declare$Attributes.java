/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.toolSite.ContainmentManager$East$Declare$Attributes
*/

package _package.component.gUI.control.container.jComponent.jPanel.toolSite;

public class ContainmentManager$East$Declare$Attributes
        extends    _package.component.gUI.control.container.jComponent.jPanel.CDComponentAttributes
    {
    // Fields declarations
    
    // Default constructor
    public ContainmentManager$East$Declare$Attributes()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ContainmentManager$East$Declare$Attributes(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(true);
            setTBorder("EtchedSimple");
            setTBounds("0,0,320,390");
            setTConstraints("North");
            setTLayout(null);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new ContainmentManager$East$Declare$Attributes$BTN_Apply("BTN_Apply", this, true), "BTN_Apply");
        _addChild(new ContainmentManager$East$Declare$Attributes$CHK_Abstract("CHK_Abstract", this, true), "CHK_Abstract");
        _addChild(new ContainmentManager$East$Declare$Attributes$CHK_Deprecated("CHK_Deprecated", this, true), "CHK_Deprecated");
        _addChild(new ContainmentManager$East$Declare$Attributes$CHK_Final("CHK_Final", this, true), "CHK_Final");
        _addChild(new ContainmentManager$East$Declare$Attributes$CHK_Persistent("CHK_Persistent", this, true), "CHK_Persistent");
        _addChild(new ContainmentManager$East$Declare$Attributes$CHK_Remote("CHK_Remote", this, true), "CHK_Remote");
        _addChild(new ContainmentManager$East$Declare$Attributes$CHK_Static("CHK_Static", this, true), "CHK_Static");
        _addChild(new ContainmentManager$East$Declare$Attributes$LBL_Integrates("LBL_Integrates", this, true), "LBL_Integrates");
        _addChild(new ContainmentManager$East$Declare$Attributes$LBL_Name("LBL_Name", this, true), "LBL_Name");
        _addChild(new ContainmentManager$East$Declare$Attributes$RG_Visible("RG_Visible", this, true), "RG_Visible");
        _addChild(new ContainmentManager$East$Declare$Attributes$TBL_Categories("TBL_Categories", this, true), "TBL_Categories");
        _addChild(new ContainmentManager$East$Declare$Attributes$TBL_Events("TBL_Events", this, true), "TBL_Events");
        _addChild(new ContainmentManager$East$Declare$Attributes$TBL_Interfaces("TBL_Interfaces", this, true), "TBL_Interfaces");
        _addChild(new ContainmentManager$East$Declare$Attributes$TXT_Integrates("TXT_Integrates", this, true), "TXT_Integrates");
        _addChild(new ContainmentManager$East$Declare$Attributes$TXT_Name("TXT_Name", this, true), "TXT_Name");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ContainmentManager$East$Declare$Attributes();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/toolSite/ContainmentManager$East$Declare$Attributes".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent().get_Parent();
        }
    
    // Declared at the super level
    public _package.component.dev.tool.host.CDTool getCDTool()
        {
        return (($Module) get_Module()).getContainmentTool();
        }
    
    // Declared at the super level
    public void setTitle(String pTitle)
        {
        super.setTitle(pTitle);
        
        (($Declare$Style) _findName("Declare$Style")).setText(pTitle);
        }
    }
