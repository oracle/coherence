/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.cDScript.Viewer
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.cDScript;

import _package.component.gUI.control.container.Window;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.Constants;
import com.tangosol.dev.component.Implementation;
import com.tangosol.dev.component.Storage;
import java.awt.Cursor;
import java.util.ArrayList;

public abstract class Viewer
        extends    _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDScript
    {
    // Fields declarations
    
    /**
    * Property ClassCache
    *
    * Privately used cache for [JCS] super classes.
    */
    private transient com.tangosol.util.LiteMap __m_ClassCache;
    
    /**
    * Property ScriptArray
    *
    * Array of pairs: {Behavior, Implementation} for a chain of implementation
    * to show in the viewer
    */
    private transient java.util.ArrayList __m_ScriptArray;
    
    // Initializing constructor
    public Viewer(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        
        // state initialization: private properties
        try
            {
            __m_ClassCache = new com.tangosol.util.LiteMap();
            __m_ScriptArray = new java.util.ArrayList();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/cDScript/Viewer".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "ClassCache"
    private com.tangosol.util.LiteMap getClassCache()
        {
        return __m_ClassCache;
        }
    
    // Accessor for the property "ScriptArray"
    private java.util.ArrayList getScriptArray()
        {
        return __m_ScriptArray;
        }
    
    // Declared at the super level
    public int getScriptCount()
        {
        return getScriptArray().size();
        }
    
    // Declared at the super level
    public void setBehavior(com.tangosol.dev.component.Behavior pBehavior)
        {
        setEnabled(pBehavior != null && !pBehavior.isDeclaredAtThisLevel());
        
        super.setBehavior(pBehavior);
        }
    
    // Accessor for the property "ClassCache"
    private void setClassCache(com.tangosol.util.LiteMap pClassCache)
        {
        __m_ClassCache = pClassCache;
        }
    
    // Accessor for the property "ScriptArray"
    private void setScriptArray(java.util.ArrayList pScriptArray)
        {
        __m_ScriptArray = pScriptArray;
        }
    
    // Declared at the super level
    public void setScriptPos(int pScriptPos)
        {
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Implementation;
        // import java.util.ArrayList;
        
        super.setScriptPos(pScriptPos);
        
        $Header Header = ($Header) _findName("Header");
        $Script Script = ($Script) _findName("Script");
        $Lang   Lang   = ($Lang)   _findName("Lang");
        $Info   Info   = ($Info)   _findName("Info");
        
        String sHeader = "";
        String sScript = "";
        String sLang   = "";
        String sInfo   = "";
        
        ArrayList array    = getScriptArray();
        Behavior  bhvrThis = getBehavior();
        
        if (bhvrThis != null && !bhvrThis.isDeclaredAtThisLevel() &&
                pScriptPos >= 0 && pScriptPos < getScriptCount())
            {
            Behavior bhvr;
            Object    oImpl = array.get(pScriptPos);
            if (oImpl instanceof Implementation)
                {
                Implementation impl = (Implementation) oImpl;
                sScript = impl.getScript();
                sLang   = impl.getLanguage();
                bhvr    = impl.getBehavior();
                }
            else
                {
                // there is no implemenation at this level
                bhvr    = (Behavior) oImpl;
                sScript = bhvr.isAbstract()           ? "<Abstract method>" :
                    bhvr.getComponent().isComponent() ? "<Default implementation>" :
                    bhvr.getComponent().isInterface() ? "<Interface method>" :
                                     /* isClass()   */  "<Declaration>";
                }
            sHeader = getHeader(bhvr);
        
            Component cdGlobalParent = bhvr.getComponent().getGlobalParent();
        
            String sName = cdGlobalParent.getName();
            if (sName.length() == 0)
                {
                sName = "Root";
                }
            sInfo = pScriptPos < getScriptCount() - 1 ||
                    bhvr == bhvrThis && !bhvr.isDeclaredAtThisLevel() &&
                        !bhvr.getComponent().isInterface() ?
                    "Implemented at "  : "Declared at ";
            sInfo += sName;
            }
        
        Header.setText(sHeader);
        Script.setText(sScript);
        Lang  .setText(sLang);
        Info  .setText(sInfo);
        }
    
    // Declared at the super level
    /**
    * Update the UI according to the Component Definition data.
    */
    protected void update()
        {
        // import Component.GUI.Control.Container.Window;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Constants;
        // import com.tangosol.dev.component.Implementation;
        // import com.tangosol.dev.component.Storage;
        // import java.awt.Cursor;
        // import java.util.ArrayList;
        
        Behavior bhvrThis = getBehavior();
        if (bhvrThis != null)
            {
            Window frame   = getParentWindow();
            Cursor _cursor = frame.get_Cursor();
        
            frame.set_Cursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
            try
                {
                // get the list of all "super" Implementations for specified behavior
                // and fill in the ScriptArray
                ArrayList array = getScriptArray();
                array.clear();
        
                Component cdThis   = bhvrThis.getComponent();
                Storage   storage  = getCDTool().getStorage();
        
                Component cd   = cdThis;
                Behavior  bhvr = bhvrThis;
                do
                    {
                    int cImplModify = bhvr.getModifiableImplementationCount();
                    int cImplAll    = bhvr.getImplementationCount();
                    int iImplFirst  = bhvr == bhvrThis ?  cImplModify : 0;
                    for (int i = iImplFirst; i < cImplAll; i++)
                        {
                        array.add(bhvr.getImplementation(i));
                        }
        
                    if (!bhvr.isFromSuper())
                        {
                        if (iImplFirst == cImplAll)
                            {
                            // there are no implementations at the declaration level
                            array.add(bhvr);
                            }
                        break;
                        }
        
                    try
                        {
                        String sSuperNameQ = cd.getSuperName();
                        String sChildNameQ = null;
        
                        if (sSuperNameQ.length() == 0)
                            {
                            sSuperNameQ = "java.lang.Object";
                            }
        
                        if (Component.isQualifiedNameLegal(sSuperNameQ))
                            {
                            int iPos = sSuperNameQ.indexOf(Constants.LOCAL_ID_DELIM);
                            if (iPos >= 0)
                                {
                                // given the name A.B$C$D, split it into A.B and C$D
                                sChildNameQ = sSuperNameQ.substring(iPos + 1);
                                sSuperNameQ = sSuperNameQ.substring(0, iPos);
                                }
                            cd = storage.loadComponent(sSuperNameQ, true, null);
                            }
                        else
                            {
                            if (getClassCache().containsKey(sSuperNameQ))
                                {
                                cd = (Component) getClassCache().get(sSuperNameQ);
                                }
                            else
                                {
                                cd = storage.loadComponent(sSuperNameQ, false, null);
                                if (cd != null)
                                    {
                                    cd.addJcsImplementations(storage.loadOriginalClass(sSuperNameQ),
                                                             storage.loadJava(sSuperNameQ));
                                    }
                                getClassCache().put(sSuperNameQ, cd);
                                }
                            }
        
                        if (cd != null && sChildNameQ != null)
                            {
                            cd = cd.getLocal(sChildNameQ);
                            }
        
                        if (cd != null)
                            {
                            bhvr = cd.getBehavior(bhvr.getSignature());
                            }
                        }
                    catch (Exception e) {}
        
                    } while (cd != null && bhvr != null);
                }
            finally
                {
                frame.set_Cursor(_cursor);
                }
            }
        
        super.update();
        }
    }
