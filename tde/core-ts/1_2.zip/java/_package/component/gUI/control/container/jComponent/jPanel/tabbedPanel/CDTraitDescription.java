/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDTraitDescription
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel;

import com.tangosol.dev.component.Trait;

public class CDTraitDescription
        extends    _package.component.gUI.control.container.jComponent.jPanel.TabbedPanel
    {
    // Fields declarations
    
    /**
    * Property Applying
    *
    * Specifies whether the tool is in a process of applying the changes made
    * by the user
    */
    private transient boolean __m_Applying;
    
    /**
    * Property NeedUpdate
    *
    */
    private transient boolean __m_NeedUpdate;
    
    /**
    * Property Trait
    *
    */
    private com.tangosol.dev.component.Trait __m_Trait;
    
    // Default constructor
    public CDTraitDescription()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDTraitDescription(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setIndex(-1);
            setResizable(true);
            setTBounds("0,0,200,300");
            setTConstraints("Center");
            setTFont("DefaultProportional-0-10");
            setTitle("Doc");
            setTLayout("BorderLayout");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new CDTraitDescription$Doc("Doc", this, true), "Doc");
        _addChild(new CDTraitDescription$North("North", this, true), "North");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CDTraitDescription();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/CDTraitDescription".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    public void apply()
        {
        // import com.tangosol.dev.component.Trait;
        
        if (isApplying())
            {
            return;
            }
        
        CDTraitDescription$Doc       Doc = (CDTraitDescription$Doc)       _findName("Doc");
        CDTraitDescription$North$Tip Tip = (CDTraitDescription$North$Tip) _findName("Tip");
        
        Trait trait = getTrait();
        if (trait != null && trait.getMode() != Trait.INVALID && !isNeedUpdate())
            {
            String  sDescr = Doc.getText();
            String  sTip   = Tip.getText();
        
            setApplying(true);
            try
                {
                trait.setDescription(sDescr);
                trait.setTip(sTip);
                }
            catch (java.beans.PropertyVetoException e)
                {
                _trace("Cannot set description: " + e.getMessage(), 1);
                }
            finally
                {
                setApplying(false);
                }
            }
        }
    
    // Accessor for the property "Trait"
    /**
    * Getter for property Trait.<p>
    */
    public com.tangosol.dev.component.Trait getTrait()
        {
        return __m_Trait;
        }
    
    // Accessor for the property "Applying"
    /**
    * Getter for property Applying.<p>
    * Specifies whether the tool is in a process of applying the changes made
    * by the user
    */
    protected boolean isApplying()
        {
        return __m_Applying;
        }
    
    // Accessor for the property "NeedUpdate"
    /**
    * Getter for property NeedUpdate.<p>
    */
    private boolean isNeedUpdate()
        {
        return __m_NeedUpdate;
        }
    
    // Declared at the super level
    /**
    * This event is called by the parent JTabbedPane when the tab gets
    * selected.
    * 
    * @see JTabbedPane#onSelectionChanged
    */
    public void onSelected()
        {
        super.onSelected();
        
        if (isNeedUpdate())
            {
            update();
            }
        }
    
    // Accessor for the property "Applying"
    /**
    * Setter for property Applying.<p>
    * Specifies whether the tool is in a process of applying the changes made
    * by the user
    */
    protected void setApplying(boolean pApplying)
        {
        __m_Applying = pApplying;
        }
    
    // Accessor for the property "NeedUpdate"
    /**
    * Setter for property NeedUpdate.<p>
    */
    private void setNeedUpdate(boolean pNeedUpdate)
        {
        __m_NeedUpdate = pNeedUpdate;
        }
    
    // Accessor for the property "Trait"
    /**
    * Setter for property Trait.<p>
    */
    public void setTrait(com.tangosol.dev.component.Trait pTrait)
        {
        apply();
        
        __m_Trait = (pTrait);
        
        setEnabled(pTrait != null);
        
        if (isVisible())
            {
            update();
            }
        else
            {
            setNeedUpdate(true);
            }
        }
    
    // Declared at the super level
    /**
    * Setter for property Visible.<p>
    */
    public void setVisible(boolean pVisible)
        {
        super.setVisible(pVisible);
        
        if (isNeedUpdate())
            {
            update();
            }
        }
    
    private void update()
        {
        // import com.tangosol.dev.component.Trait;
        
        Trait trait = getTrait();
        
        $Doc Doc = ($Doc) _findName("Doc");
        String sDoc = trait != null ? trait.getDescription() : "";
        if (!sDoc.equals(Doc.getText()))
            {
            Doc.setText(sDoc);
            }
        Doc.setEditable(trait != null ? trait.isTextSettable() : false);
        
        $Tip Tip = ($Tip) _findName("Tip");
        String sTip = trait != null ? trait.getTip() : "";
        if (!sTip.equals(Tip.getText()))
            {
            Tip.setText(sTip);
            }
        Tip.setEditable(trait != null ? trait.isTipSettable() : false);
        
        setNeedUpdate(false);
        
        // TODO: do we want to represent the "ReplaceDescription" attribute in UI somehow?
        }
    }
