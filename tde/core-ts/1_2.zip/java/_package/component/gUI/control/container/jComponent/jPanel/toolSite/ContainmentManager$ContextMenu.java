/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.toolSite.ContainmentManager$ContextMenu
*/

package _package.component.gUI.control.container.jComponent.jPanel.toolSite;

import _package.component.gUI.TreeNode;
import _package.component.gUI.control.container.jComponent.abstractButton.JMenuItem;
import _package.component.gUI.treeNode.SimpleNode;
import _package.component.gUI.treeNode.cDTraitNode.CDComponentNode;
import com.tangosol.dev.component.Component;

public class ContainmentManager$ContextMenu
        extends    _package.component.gUI.control.container.jComponent.JPopupMenu
    {
    // Fields declarations
    
    // Default constructor
    public ContainmentManager$ContextMenu()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ContainmentManager$ContextMenu(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new ContainmentManager$ContextMenu$Close("Close", this, true), "Close");
        _addChild(new ContainmentManager$ContextMenu$Duplicate("Duplicate", this, true), "Duplicate");
        _addChild(new ContainmentManager$ContextMenu$Insert("Insert", this, true), "Insert");
        _addChild(new ContainmentManager$ContextMenu$Remove("Remove", this, true), "Remove");
        _addChild(new ContainmentManager$ContextMenu$Rename("Rename", this, true), "Rename");
        _addChild(new ContainmentManager$ContextMenu$ReplaceSuper("ReplaceSuper", this, true), "ReplaceSuper");
        _addChild(new ContainmentManager$ContextMenu$SaveGlobal("SaveGlobal", this, true), "SaveGlobal");
        _addChild(new ContainmentManager$ContextMenu$Separator1("Separator1", this, true), "Separator1");
        _addChild(new ContainmentManager$ContextMenu$Separator2("Separator2", this, true), "Separator2");
        _addChild(new ContainmentManager$ContextMenu$ShowAttributes("ShowAttributes", this, true), "ShowAttributes");
        _addChild(new ContainmentManager$ContextMenu$ShowCategories("ShowCategories", this, true), "ShowCategories");
        _addChild(new ContainmentManager$ContextMenu$ShowIcons("ShowIcons", this, true), "ShowIcons");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ContainmentManager$ContextMenu();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/toolSite/ContainmentManager$ContextMenu".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    /**
    * Method notification sent when this popup menu is about to become visible.
    */
    public void onPopupVisible()
        {
        // import Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem;
        // import Component.GUI.TreeNode;
        // import Component.GUI.TreeNode.SimpleNode;
        // import Component.GUI.TreeNode.CDTraitNode.CDComponentNode;
        // import com.tangosol.dev.component.Component;
        
        super.onPopupVisible();
        
        JMenuItem Insert     = (JMenuItem) _findChild("Insert");
        JMenuItem Duplicate  = (JMenuItem) _findChild("Duplicate");
        JMenuItem Rename     = (JMenuItem) _findChild("Rename");
        JMenuItem Remove     = (JMenuItem) _findChild("Remove");
        JMenuItem SaveGlobal = (JMenuItem) _findChild("SaveGlobal");
        JMenuItem Replace    = (JMenuItem) _findChild("ReplaceSuper");
        
        Component cd = (($Module) get_Module()).getComponent();
        if (cd == null)
            {
            $Tree Tree = ($Tree) _findName("Tree");
        
            SimpleNode node = (SimpleNode) Tree.getSelectionNode();
        
            Insert.setEnabled(false);
            Duplicate.setEnabled(false);
            Rename.setEnabled(false);
            SaveGlobal.setEnabled(false);
            Replace.setEnabled(false);
        
            Object oRef = node.getReference();
            if (oRef != null)
                {
                // category
                Remove.setEnabled(false);
                Remove.setText("Remove Category"); // TODO: softcode
                }
            else
                {
                // removed child
                TreeNode nodeParent = node.getParent();
                boolean  fUnremove  = false;
                if (nodeParent instanceof CDComponentNode)
                    {
                    String sChild = ((SimpleNode) node).getName();
                    fUnremove = ((CDComponentNode) nodeParent).getComponent().isChildUnremovable(sChild);
                    }
                Remove.setEnabled(fUnremove);
                Remove.setText("Unremove Component"); // TODO: softcode
                }
            }
        else
            {
            Component cdGlobal = cd.getGlobalParent();
        
            Insert.setEnabled(cd.isModifiable());
            Duplicate.setEnabled(!cd.isGlobal() && cdGlobal.isModifiable());
            Rename.setEnabled(cd.isNameSettable());
            SaveGlobal.setEnabled(!cd.isGlobal());
            Replace.setEnabled(!cd.isGlobal() && cd.isDeclaredAtThisLevel());
            Remove.setEnabled(!cd.isGlobal() && cdGlobal.isModifiable());
        
            Remove.setText("Remove Component"); // TODO: softcode
            }
        }
    }
