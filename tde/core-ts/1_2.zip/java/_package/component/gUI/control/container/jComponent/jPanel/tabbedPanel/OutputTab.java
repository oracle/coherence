/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.OutputTab
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel;

public abstract class OutputTab
        extends    _package.component.gUI.control.container.jComponent.jPanel.TabbedPanel
    {
    // Fields declarations
    
    /**
    * Property ActionListener
    *
    * Listener to notify on user's selection in the output.
    */
    private transient java.awt.event.ActionListener __m_ActionListener;
    
    // Initializing constructor
    public OutputTab(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/OutputTab".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Clear the output.
    */
    public void clear()
        {
        }
    
    /**
    * Move the current item selection as specified and fire the "LocateTrait"
    * action.
    * 
    * @param index the base item index; pass -1 to specifiy the currently
    * selected item
    * @param iDirection pass -1, 0 or 1 to locate the previous, current or next
    * item accordingly
    */
    public void fireLocateTrait(int index, int iDirection)
        {
        }
    
    // Accessor for the property "ActionListener"
    /**
    * Getter for property ActionListener.<p>
    * Listener to notify on user's selection in the output.
    */
    public java.awt.event.ActionListener getActionListener()
        {
        return __m_ActionListener;
        }
    
    /**
    * Output the specified value (usually String or array of ListItems)
    */
    public void output(Object oValue)
        {
        }
    
    // Accessor for the property "ActionListener"
    /**
    * Setter for property ActionListener.<p>
    * Listener to notify on user's selection in the output.
    */
    public void setActionListener(java.awt.event.ActionListener pActionListener)
        {
        __m_ActionListener = pActionListener;
        }
    }
