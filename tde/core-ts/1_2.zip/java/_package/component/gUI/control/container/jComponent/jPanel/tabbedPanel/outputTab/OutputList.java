/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.outputTab.OutputList
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.outputTab;

import _package.component.dev.Tool;
import _package.component.dev.util.TraitLocator;
import _package.component.gUI.control.container.jComponent.jPanel.ToolSite;

public class OutputList
        extends    _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.OutputTab
    {
    // Fields declarations
    
    // Default constructor
    public OutputList()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public OutputList(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setIndex(-1);
            setResizable(true);
            setTConstraints("Center");
            setTFont("DefaultProportional-0-10");
            setTLayout("BorderLayout");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new OutputList$List("List", this, true), "List");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new OutputList();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/outputTab/OutputList".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Clear the output.
    */
    public void clear()
        {
        $List List = ($List) _findName("List");
        List.removeAllItems();
        }
    
    // Declared at the super level
    /**
    * Move the current item selection as specified and fire the "LocateTrait"
    * action.
    * 
    * @param index the base item index; pass -1 to specifiy the currently
    * selected item
    * @param iDirection pass -1, 0 or 1 to locate the previous, current or next
    * item accordingly
    */
    public void fireLocateTrait(int index, int iDirection)
        {
        // import Component.Dev.Tool;
        // import Component.Dev.Util.TraitLocator;
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite;
        
        $List list = ($List) _findName("List");
        
        int cItems = list.getItemCount();
        if (cItems == 0)
            {
            _beep();
            }
        else
            {
            Object locator;
        
            if (index == -1)
                {
                index = list.getSelectedIndex();
                }
        
            if (iDirection == 0)
                {
                locator = list.getItemAt(index);
                }
            else
                {
                int ixStart = index >= 0 ? index :
                    iDirection > 0 ? cItems - 1 : 0;
                do
                    {
                    index += iDirection;
                    if (index < 0)
                        {
                        index = cItems - 1;
                        }
                    else if (index >= cItems)
                        {
                        index = 0;
                        }
                    locator = list.getItemAt(index);
                    }
                while (!(locator instanceof TraitLocator) && index != ixStart);
        
                list.setSelectedIndex(index);
                list.ensureIndexIsVisible(index);
                }
        
            if (locator instanceof TraitLocator)
                {
                ToolSite site = ((ToolSite) _findAncestor(ToolSite.class));
                site.getTool().fireToolAction(Tool.ACTION_LOCATE_TRAIT, locator);
                }
            else
                {
                // cannot find a locator
                _beep();
                }
            }
        }
    
    // Declared at the super level
    /**
    * Output the specified value (usually String or array of ListItems)
    */
    public void output(Object oValue)
        {
        $List List = ($List) _findName("List");
        if (oValue instanceof Object[])
            {
            Object[] aoValue = (Object[]) oValue;
            for (int i = 0; i < aoValue.length; i++)
                {
                List.addItem(aoValue[i]);
                }
            }
        else if (oValue instanceof String)
            {
            String sValue  = (String) oValue;
            int    ofStart = 0;
            while (true)
                {
                int ofEnd = sValue.indexOf('\n', ofStart);
                if (ofEnd < 0)
                    {
                    List.addItem(sValue.substring(ofStart));
                    break;
                    }
                List.addItem(sValue.substring(ofStart, ofEnd));
                ofStart = ofEnd + 1;
                }
            }
        else
            {
            List.addItem(oValue);
            }
        
        List.ensureIndexIsVisible(List.getItemCount() - 1);
        }
    }
