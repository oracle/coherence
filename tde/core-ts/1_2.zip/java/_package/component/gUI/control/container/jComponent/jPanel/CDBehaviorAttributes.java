/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.CDBehaviorAttributes
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.dev.tool.host.CDTool;
import _package.component.gUI.Control;
import _package.component.gUI.control.container.jComponent.JTable;
import _package.component.gUI.control.container.jComponent.abstractButton.JToggleButton;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.Constants;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Interface;
import com.tangosol.dev.component.Parameter;
import java.beans.PropertyVetoException;

public abstract class CDBehaviorAttributes
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property Behavior
    *
    */
    private transient com.tangosol.dev.component.Behavior __m_Behavior;
    
    /**
    * Property CDTool
    *
    * CDTool component is needed to get to the storage and helper functions. It
    * has to be supplied by the ScriptEditor.
    */
    
    // Initializing constructor
    public CDBehaviorAttributes(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/CDBehaviorAttributes".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    public void apply()
        {
        // import Component.Dev.Tool.Host.CDTool;
        // import Component.GUI.Control;
        // import Component.GUI.Control.Container.JComponent.AbstractButton.JToggleButton;
        // import Component.GUI.Control.Container.JComponent.JTable;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Constants;
        // import com.tangosol.dev.component.DataType;
        // import java.beans.PropertyVetoException;
        
        $TXT_Name                TXT_Name       = ($TXT_Name)               _findName("TXT_Name");
        $CMB_Type                CMB_Type       = ($CMB_Type)               _findName("CMB_Type");
        $TBL_Param               TBL_Param      = ($TBL_Param)              _findName("TBL_Param");
        $TBL_Except              TBL_Except     = ($TBL_Except)             _findName("TBL_Except");
        $RG_Access               RG_Access      = ($RG_Access)              _findName("RG_Access");
        $RG_Access$RB_Public     RB_Public      = ($RG_Access$RB_Public)    _findName("RG_Access$RB_Public");
        $RG_Access$RB_Protected  RB_Protected   = ($RG_Access$RB_Protected) _findName("RG_Access$RB_Protected");
        $RG_Access$RB_Private    RB_Private     = ($RG_Access$RB_Private)   _findName("RG_Access$RB_Private");
        $RG_Visible              RG_Visible     = ($RG_Visible)             _findName("RG_Visible");
        $RG_Visible$RB_Visible   RB_Visible     = ($RG_Visible$RB_Visible)  _findName("RG_Visible$RB_Visible");
        $RG_Visible$RB_Hidden    RB_Hidden      = ($RG_Visible$RB_Hidden)   _findName("RG_Visible$RB_Hidden");
        $RG_Visible$RB_Advanced  RB_Advanced    = ($RG_Visible$RB_Advanced) _findName("RG_Visible$RB_Advanced");
        $RG_Visible$RB_System    RB_System      = ($RG_Visible$RB_System)   _findName("RG_Visible$RB_System");
        $CHK_Abstract            CHK_Abstract   = ($CHK_Abstract)           _findName("CHK_Abstract");
        $CHK_Static              CHK_Static     = ($CHK_Static)             _findName("CHK_Static");
        $CHK_Final               CHK_Final      = ($CHK_Final)              _findName("CHK_Final");
        $CHK_Sync                CHK_Sync       = ($CHK_Sync)               _findName("CHK_Sync");
        $CHK_Remote              CHK_Remote     = ($CHK_Remote)             _findName("CHK_Remote");
        $CHK_Over                CHK_Over       = ($CHK_Over)               _findName("CHK_Over");
        $CHK_Deprecated          CHK_Deprecated = ($CHK_Deprecated)         _findName("CHK_Deprecated");
        
        Behavior bhvr = getBehavior();
        CDTool   tool = getCDTool();
        
        String sName = TXT_Name.getText();
        if (sName.length() == 0)
            {
            onError(TXT_Name, "Invalid name");
            return;
            }
        
        String    sType = CMB_Type.getText();
        DataType  dtRet = tool.getDataType(sType);
        if (dtRet == null)
            {
            onError(CMB_Type, "Return type is invalid");
            return;
            }
        
        JTable tblParam = TBL_Param.getTable();
        tblParam.removeEmptyRows(true);
        
        String[]   asParamType  = tblParam.getColumnStrings(0);
        String[]   asParamName  = tblParam.getColumnStrings(1);
        int        cParams      = asParamType.length;
        DataType[] adtParamType = new DataType[cParams];
        
        for (int i = 0; i < cParams; i++)
            {
            if (asParamType[i].length() > 0)
                {
                adtParamType[i] = tool.getDataType(asParamType[i]);
                if (adtParamType[i] == null || adtParamType[i] == DataType.VOID)
                    {
                    onError(tblParam, "Invalid return type for parameter " + i);
                    tblParam.editCellAt(i, 0);
                    return;
                    }
        
                if (asParamName[i].length() == 0)
                    {
                    onError(tblParam, "Missing name for parameter " + i);
                    tblParam.editCellAt(i, 1);
                    return;
                    }
                }
            }
        
        JTable tblExcept = TBL_Except.getTable();
        tblExcept.removeEmptyRows(true);
        
        String[] asExcept = tblExcept.getColumnStrings(0);
        int      cExcepts = asExcept.length;
        
        for (int i = 0; i < cExcepts; i++)
            {
            // we don't perform a complete check (whether the class is throwable) (TODO)
            // but at least preventing the spelling error
            DataType dt = tool.getDataType(asExcept[i]);
            if (dt == null || !dt.isClass())
                {
                onError(tblExcept, "Invalid exception name " + asExcept[i]);
                tblExcept.editCellAt(i, 0);
                return;
                }
            }
        
        JToggleButton rb = RG_Access.getSelection();
        int nAccess = rb == RB_Public    ? Constants.ACCESS_PUBLIC    :
                      rb == RB_Protected ? Constants.ACCESS_PROTECTED :
                                           Constants.ACCESS_PRIVATE   ;
        rb = RG_Visible.getSelection();
        int nVisible = rb == RB_Visible  ? Constants.VIS_VISIBLE  :
                       rb == RB_Hidden   ? Constants.VIS_HIDDEN   :
                       rb == RB_Advanced ? Constants.VIS_ADVANCED :
                                           Constants.VIS_SYSTEM   ;
        boolean fAbstract   = CHK_Abstract  .isSelected();
        boolean fStatic     = CHK_Static    .isSelected();
        boolean fFinal      = CHK_Final     .isSelected();
        boolean fSync       = CHK_Sync      .isSelected();
        boolean fRemote     = CHK_Remote    .isSelected();
        boolean fOver       = CHK_Over      .isSelected();
        boolean fDeprecated = CHK_Deprecated.isSelected();
        
        // some change could be not allowed until another change is made
        // (e.g. we cannot change a return type before the name is changed because
        // of the collision with another behavior)
        // that is why we will try to make changes in a couple of passes
        // until all or none of the changes were successful
        boolean fChanged;
        String  sErrMsg;
        Control ctrlErr;
        do
            {
            fChanged = false;
            sErrMsg  = null;
            ctrlErr  = null;
        
            if (!bhvr.getName().equals(sName))
                {
                try
                    {
                    bhvr.setName(sName);
                    fChanged = true;
                    }
                catch (PropertyVetoException e)
                    {
                    ctrlErr = TXT_Name;
                    sErrMsg = e.toString();
                    }
                }
        
            if (bhvr.getReturnValue().getDataType() != dtRet)
                {
                try
                    {
                    bhvr.getReturnValue().setDataType(dtRet);
                    fChanged = true;
                    }
                catch (PropertyVetoException e)
                    {
                    ctrlErr = CMB_Type;
                    sErrMsg = e.toString();
                    }
                }
        
            if (bhvr.getAccess() != nAccess)
                {
                try
                    {
                    bhvr.setAccess(nAccess);
                    fChanged = true;
                    }
                catch (PropertyVetoException e)
                    {
                    ctrlErr = RB_Public;
                    sErrMsg = e.toString();
                    }
                }
        
            if (bhvr.isStatic() != fStatic)
                {
                try
                    {
                    bhvr.setStatic(fStatic);
                    fChanged = true;
                    }
                catch (PropertyVetoException e)
                    {
                    ctrlErr = CHK_Static;
                    sErrMsg = e.toString();
                    }
                }
        
            boolean fParamChanged = false;
            int     cParamCount   = bhvr.getParameterCount();
            if (cParamCount != adtParamType.length)
                {
                fParamChanged = true;
                }
            else
                {
                for (int i = 0; i < cParamCount; i++)
                    {
                    if (!bhvr.getParameter(i).getDataType().equals(adtParamType[i]) ||
                        !bhvr.getParameter(i).getName()    .equals(asParamName[i]))
                        {
                        fParamChanged = true;
                        break;
                        }
                    }
                }
        
            if (fParamChanged)
                {
                try
                    {
                    bhvr.setParameter(adtParamType, asParamName);
                    fChanged = true;
                    }
                 catch (PropertyVetoException e)
                    {
                    ctrlErr = tblParam;
                    sErrMsg = e.toString();
                    }
                }
        
            // assume no changes here (TODO)
            try
                {
                bhvr.setException(asExcept); 
                }
             catch (PropertyVetoException e)
                {
                ctrlErr = tblExcept;
                sErrMsg = e.toString();
                }
         
            try
                {
                if (bhvr.getVisible() != nVisible)
                    {
                    bhvr.setVisible(nVisible);
                    fChanged = true;
                    }
                if (bhvr.isAbstract() != fAbstract)
                    {
                    bhvr.setAbstract(fAbstract);
                    fChanged = true;
                    }
                if (bhvr.isFinal() != fFinal)
                    {
                    bhvr.setFinal(fFinal);
                    fChanged = true;
                    }
                if (bhvr.isSynchronized() != fSync)
                    {
                    bhvr.setSynchronized(fSync);
                    fChanged = true;
                    }
                if (bhvr.isRemote() != fRemote)
                    {
                    bhvr.setRemote(fRemote);
                    fChanged = true;
                    }
                if (bhvr.isOverrideBase() != fOver)
                    {
                    bhvr.setOverrideBase(fOver);
                    fChanged = true;
                    }
                if (bhvr.isDeprecated() != fDeprecated)
                    {
                    bhvr.setDeprecated(fDeprecated);
                    fChanged = true;
                    }
                }
            catch (PropertyVetoException e)
                {
                sErrMsg = e.toString();
                }
        
            } while (sErrMsg != null && fChanged);
        
        if (sErrMsg != null)
            {
            onError(ctrlErr, sErrMsg);
            }
        
        update();
        }
    
    // Accessor for the property "Behavior"
    public com.tangosol.dev.component.Behavior getBehavior()
        {
        return __m_Behavior;
        }
    
    // Accessor for the property "CDTool"
    public _package.component.dev.tool.host.CDTool getCDTool()
        {
        return null;
        }
    
    private void onError(_package.component.gUI.Control ctrl, String sErr)
        {
        if (ctrl != null)
            {
            ctrl.requestFocus();
            }
        _trace(sErr);
        _beep();
        }
    
    // Accessor for the property "Behavior"
    public void setBehavior(com.tangosol.dev.component.Behavior pBehavior)
        {
        if (getBehavior() != null)
            {
            // we could check whether anything has been changed
            // apply();
            }
        
        __m_Behavior = (pBehavior);
        
        if (pBehavior != null)
            {
            setVisible(true);
            update();
            }
        else
            {
            setVisible(false);
            setTitle(""); // used to show the origin
            }
        

        }
    
    private void update()
        {
        // import Component.GUI.Control.Container.JComponent.JTable;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Interface;
        // import com.tangosol.dev.component.Parameter;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Constants;
        
        $TXT_Name                TXT_Name       = ($TXT_Name)               _findName("TXT_Name");
        $CMB_Type                CMB_Type       = ($CMB_Type)               _findName("CMB_Type");
        $TBL_Param               TBL_Param      = ($TBL_Param)              _findName("TBL_Param");
        $TBL_Except              TBL_Except     = ($TBL_Except)             _findName("TBL_Except");
        $RG_Access               RG_Access      = ($RG_Access)              _findName("RG_Access");
        $RG_Access$RB_Public     RB_Public      = ($RG_Access$RB_Public)    _findName("RB_Public");
        $RG_Access$RB_Protected  RB_Protected   = ($RG_Access$RB_Protected) _findName("RB_Protected");
        $RG_Access$RB_Private    RB_Private     = ($RG_Access$RB_Private)   _findName("RB_Private");
        $RG_Visible              RG_Visible     = ($RG_Visible)             _findName("RG_Visible");
        $RG_Visible$RB_Visible   RB_Visible     = ($RG_Visible$RB_Visible)  _findName("RG_Visible$RB_Visible");
        $RG_Visible$RB_Hidden    RB_Hidden      = ($RG_Visible$RB_Hidden)   _findName("RG_Visible$RB_Hidden");
        $RG_Visible$RB_Advanced  RB_Advanced    = ($RG_Visible$RB_Advanced) _findName("RG_Visible$RB_Advanced");
        $RG_Visible$RB_System    RB_System      = ($RG_Visible$RB_System)   _findName("RG_Visible$RB_System");
        $CHK_Abstract            CHK_Abstract   = ($CHK_Abstract)           _findName("CHK_Abstract");
        $CHK_Static              CHK_Static     = ($CHK_Static)             _findName("CHK_Static");
        $CHK_Final               CHK_Final      = ($CHK_Final)              _findName("CHK_Final");
        $CHK_Sync                CHK_Sync       = ($CHK_Sync)               _findName("CHK_Sync");
        $CHK_Remote              CHK_Remote     = ($CHK_Remote)             _findName("CHK_Remote");
        $CHK_Over                CHK_Over       = ($CHK_Over)               _findName("CHK_Over");
        $CHK_Deprecated          CHK_Deprecated = ($CHK_Deprecated)         _findName("CHK_Deprecated");
        
        Behavior bhvr = getBehavior();
        
        boolean fEdit = bhvr.isModifiable();
        
        TXT_Name.setText(bhvr.getName());
        TXT_Name.setEditable(bhvr.isNameSettable());
        
        String type = getCDTool().getDisplayValue(bhvr.getReturnValue().getDataType());
        CMB_Type.setEnabled(bhvr.getReturnValue().isDataTypeSettable());
        CMB_Type.setText(type);
        
        JTable tblParam = TBL_Param.getTable();
        tblParam.removeAllRows();
        int cParams = bhvr.getParameterCount();
        for (int i = 0; i < cParams; i++)
            {
            Parameter p  = bhvr.getParameter(i);
            String sType = getCDTool().getDisplayValue(p.getDataType());
            String sName = p.getName();
            tblParam.addRow(new String[] {sType, sName});
            }
        // more specific check will be performed directly at tblParam.isCellEditable()
        tblParam.setEnabled(bhvr.isModifiable() && bhvr.isDeclaredAtThisLevel());
        tblParam.repaint(); // JTable's bug
        TBL_Param.getToolbar().setEnabled(bhvr.isParameterSettable());
        
        JTable tblExcept = TBL_Except.getTable();
        tblExcept.removeAllRows();
        String[] asException = bhvr.getExceptionNames();
        int      cExceptions = asException.length;
        for (int i = 0; i < cExceptions; i++)
            {
            String sExcept = asException[i];
            if (bhvr.getException(sExcept) != null) // it may have been removed
                {
                tblExcept.addRow(new String[] {sExcept});
                }
            }
        // You can almost always remove an exception but adding is only allowed
        // at the declaration level (see Beahvior.isExceptionSettable()).
        // However, since we don't have a way for un-removing an exception,
        // for now we don't disallow adding. (TODO)
        tblExcept.setEnabled(bhvr.isExceptionSettable());
        tblExcept.repaint(); // JTable's bug
        
        switch (bhvr.getAccess())
            {
            case Constants.ACCESS_PUBLIC:
                RB_Public.setSelected(true);
                break;
            case Constants.ACCESS_PROTECTED:
                RB_Protected.setSelected(true);
                break;
            default:
            case Constants.ACCESS_PRIVATE:
                RB_Private.setSelected(true);
                break;
            }
        
        if (bhvr.isAccessSettable())
            {
            RG_Access   .setEnabled(true);
            RB_Public   .setEnabled(bhvr.isAccessLegal(Constants.ACCESS_PUBLIC));
            RB_Protected.setEnabled(bhvr.isAccessLegal(Constants.ACCESS_PROTECTED));
            RB_Private  .setEnabled(bhvr.isAccessLegal(Constants.ACCESS_PRIVATE));
            }
        else
            {
            RG_Access.setEnabled(false);
            }
        
        switch (bhvr.getVisible())
            {
            default:
            case Constants.VIS_VISIBLE:
                RB_Visible.setSelected(true);
                break;
            case Constants.VIS_HIDDEN:
                RB_Hidden.setSelected(true);
                break;
            case Constants.VIS_ADVANCED:
                RB_Advanced.setSelected(true);
                break;
            case Constants.VIS_SYSTEM:
                RB_System.setSelected(true);
                break;
            }
        RG_Visible.setEnabled(bhvr.isVisibleSettable());
        
        CHK_Abstract.setSelected(bhvr.isAbstract());
        CHK_Abstract.setEnabled(bhvr.isAbstractSettable());
        
        CHK_Static.setSelected(bhvr.isStatic());
        CHK_Static.setEnabled(bhvr.isStaticSettable());
        
        CHK_Final.setSelected(bhvr.isFinal());
        CHK_Final.setEnabled(bhvr.isFinalSettable());
        
        CHK_Sync.setSelected(bhvr.isSynchronized());
        CHK_Sync.setEnabled(bhvr.isSynchronizedSettable());
        
        CHK_Remote.setSelected(bhvr.isRemote());
        CHK_Remote.setEnabled(bhvr.isRemoteSettable());
        
        CHK_Over.setSelected(bhvr.isOverrideBase());
        CHK_Over.setEnabled(fEdit);
        
        CHK_Deprecated.setSelected(bhvr.isDeprecated());
        CHK_Deprecated.setEnabled(bhvr.isDeprecatedSettable());
        
        StringBuffer sb = new StringBuffer();
        if (bhvr.isFromIntegration())
            {
            sb.append("Integrated");
            }
        if (bhvr.getPropertyName() != null)
            {
            if (sb.length() > 0)
                {
                sb.append(", ");
                }
            sb.append("Property Accessor");
            }
        if (bhvr.isFromImplements())
            {
            String sIface = (String) bhvr.enumImplements().nextElement();
            if (sb.length() > 0)
                {
                sb.append(", ");
                }
            sb.append(sIface.substring(sIface.lastIndexOf('.') + 1) + " Interface");
            }
        if (bhvr.isFromDispatches())
            {
            String sIface = (String) bhvr.enumDispatches().nextElement();
            if (sb.length() > 0)
                {
                sb.append(", ");
                }
            sb.append(sIface.substring(sIface.lastIndexOf('.') + 1) + " Event Interface");
            }
        
        if (sb.length() == 0)
            {
            if (bhvr.isFromSuper())
                {
                sb.append("Inherited");
                }
            else if (bhvr.isFromBase())
                {
                sb.append("Overlaid");
                }
            else
                {
                sb.append("Manually Declared");
                }
            }
        setTitle(sb.toString());
        }
    }
