/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDScript$Script
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel;

import java.awt.Event;
import java.awt.event.KeyEvent;

public class CDScript$Script
        extends    _package.component.gUI.control.container.jComponent.jTextComponent.JTextArea
    {
    // Fields declarations
    
    // Default constructor
    public CDScript$Script()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDScript$Script(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAutoIndent(true);
            setEditable(false);
            setFocusable(true);
            setScrollable(true);
            setTabAllowed(false);
            setTabSize(4);
            setTConstraints("Center");
            setTFont("TAPS.Scripts");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new CDScript$Script$FindText("FindText", this, true), "FindText");
        _addChild(new CDScript$Script$GotoLine("GotoLine", this, true), "GotoLine");
        _addChild(new CDScript$Script$KeyGotoMatchBrace("KeyGotoMatchBrace", this, true), "KeyGotoMatchBrace");
        _addChild(new CDScript$Script$KeyGotoMatchBraceExtend("KeyGotoMatchBraceExtend", this, true), "KeyGotoMatchBraceExtend");
        _addChild(new _package.component.gUI.control.container.jComponent.JTextComponent$KeyRedo("KeyRedo", this, true), "KeyRedo");
        _addChild(new _package.component.gUI.control.container.jComponent.JTextComponent$KeyUndo("KeyUndo", this, true), "KeyUndo");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CDScript$Script();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/CDScript$Script".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    /**
    * Finds a brace character matching the one at the current cursor position.
    * 
    * @param fSelect  if true selects the text between the matching braces;
    * otherwise just goes there
    */
    public void findMatchingBrace(boolean fSelect)
        {
        // import java.awt.Event;
        // import java.awt.event.KeyEvent;
        
        String sText   = getText();
        int    ofBrace = getCaretPosition();
        char   chBrace = sText.charAt(ofBrace);
        
        boolean fForward;
        char    chMatch;
        switch (chBrace)
            {
            case '{':
                chMatch  = '}';
                fForward = true;
                break;
            case '(':
                chMatch  = ')';
                fForward = true;
                break;
            case '[':
                chMatch  = ']';
                fForward = true;
                break;
            case '}':
                chMatch  = '{';
                fForward = false;
                break;
            case ')':
                chMatch  = '(';
                fForward = false;
                break;
            case ']':
                chMatch  = '[';
                fForward = false;
                break;
            default:
                _beep();
                return;
            }
        
        int ofStart, ofEnd, iDir;
        if (fForward)
            {
            ofStart = ofBrace + 1;
            ofEnd   = sText.length();
            iDir    = +1;
            }
        else
            {
            ofStart = ofBrace - 1;
            ofEnd   = -1;
            iDir    = -1;
            }
        
        int ofMatch = -1;
        for (int of = ofStart, cnt = 0; of != ofEnd; of += iDir)
            {
            char ch = sText.charAt(of);
            if (ch == chMatch)
                {
                if (cnt-- == 0)
                    {
                    ofMatch = of;
                    break;
                    }
                }
            if (ch == chBrace)
                {
                cnt++;
                }
            }
        
        if  (ofMatch == -1)
            {
            _beep();
            }
        else
            {
            if (fSelect)
                {
                ofStart = fForward ? ofBrace     : ofMatch;
                ofEnd   = fForward ? ofMatch + 1 : ofBrace + 1;
                }
            else
                {
                ofStart = ofEnd = ofMatch;
                }
            select(ofStart, ofEnd);
            }
        }
    
    // Declared at the super level
    public void onKeyReleased(char keyChar, int keyCode, int modifiers)
        {
        super.onKeyReleased(keyChar, keyCode, modifiers);
        
        reportPosition();
        }
    
    // Declared at the super level
    public void onMouseReleased(_package.component.gUI.Point point, int modifiers, int clickCount, boolean popupTrigger)
        {
        super.onMouseReleased(point, modifiers, clickCount, popupTrigger);
        
        reportPosition();
        }
    
    private void reportPosition()
        {
        $Status$Descr$Pos Pos = ($Status$Descr$Pos ) _findName("Status$Descr$Pos");
        
        int iPos  = getCaretPosition();
        int iLine = getLineOfOffset(iPos);
        int iOff  = iPos - getLineStartOffset(iLine);
        
        Pos.setText("Ln " + (iLine+1) + ", Col " + (iOff+1));

        }
    
    // Declared at the super level
    /**
    * Setter for property Editable.<p>
    * Specifies whether or not this TextComponent is editable.
    */
    public void setEditable(boolean pEditable)
        {
        super.setEditable(pEditable);
        
        if (pEditable)
            {
            setBackground(new Component.GUI.Color.White());
            }
        else
            {
            setBackground(new Component.GUI.Color.LightGray());
            }
        }
    
    // Declared at the super level
    /**
    * Setter for property Text.<p>
    * Specifies the text contained in this TextComponent.
    */
    public void setText(String pText)
        {
        super.setText(pText);
        
        reportPosition();
        }
    }
