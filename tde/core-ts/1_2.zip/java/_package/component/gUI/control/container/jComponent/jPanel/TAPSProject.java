/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.TAPSProject
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.dev.project.ProjectInfo$Target; // as Target
import _package.component.dev.project.ProjectInfo;
import _package.component.dev.project.ProjectInfo; // as Project
import _package.component.dev.project.StorageFactory;
import _package.component.dev.storage.TAPSStorage;
import _package.component.gUI.TreeNode;
import _package.component.gUI.control.container.jComponent.jPanel.TAPSLogin;
import _package.component.gUI.control.container.jComponent.jPanel.TAPSNewProject;
import _package.component.gUI.control.container.jComponent.jPanel.wizardPane.ProjectWizard;
import _package.component.gUI.treeNode.SimpleNode;
import com.tangosol.util.ListMap;
import java.util.Iterator;
import javax.swing.JOptionPane;

public class TAPSProject
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property Storage
    *
    */
    private transient _package.component.dev.storage.TAPSStorage __m_Storage;
    
    // Default constructor
    public TAPSProject()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPSProject(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(false);
            setTBounds("0,0,470,380");
            setTConstraints("Center");
            setTIcon("TAPS");
            setTitle("Open Project");
            setTLayout("BorderLayout");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new TAPSProject$Center("Center", this, true), "Center");
        _addChild(new TAPSProject$South("South", this, true), "South");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new TAPSProject();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/TAPSProject".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Change the server
    */
    public void changeHome()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.TAPSLogin;
        // import Component.Dev.Storage.TAPSStorage;
        
        TAPSStorage storage = (TAPSStorage) dialogBox(new TAPSLogin(), getStorage());
        
        if (storage != null)
            {
            setStorage(storage);
            updateTree(storage.getQualifiedProject());
            }
        }
    
    /**
    * Create a new project
    */
    public void createProject()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.TAPSNewProject;
        // import Component.Dev.Project.ProjectInfo;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.GUI.TreeNode.SimpleNode;
        
        $TX_Project TX_Project = ($TX_Project) _findName("TX_Project");
        
        String sBasePrj = "";
        
        SimpleNode node = (SimpleNode) TX_Project.getSelectionNode();
        if (node != null)
            {
            Object oRef = node.getReference();
            if (oRef instanceof Target)
                {
                oRef = ((Target) oRef).getProjectInfo();
                }
            if (oRef instanceof ProjectInfo)
                {
                sBasePrj = ((ProjectInfo) oRef).getName();
                }
            }
        
        String sProject = (String) dialogBox(new TAPSNewProject(),
            new Object[] {getStorage().getProjectFactory(), sBasePrj});
        
        if (sProject != null)
            {
            updateTree(sProject);
            }
        }
    
    /**
    * Update the selected project
    */
    public void createSubProject()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.WizardPane.ProjectWizard;
        // import Component.Dev.Project.ProjectInfo as Project;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.GUI.TreeNode.SimpleNode;
        
        $TX_Project TX_Project = ($TX_Project) _findName("TX_Project");
        
        Target target = null;
        
        SimpleNode node = (SimpleNode) TX_Project.getSelectionNode();
        if (node != null)
            {
            Object oRef = node.getReference();
            target = oRef instanceof Target ?
                (Target) oRef : ((Project) oRef).getDefaultTarget();
            }
        if (target == null)
            {
            _beep();
            return;
            }
        
        Target targetSub = (Target) dialogBox(new ProjectWizard(),
                new Object[] {getStorage().getProjectFactory(), target});
        
        // even if the dialog was canceled we need to refresh the tree to
        // discard all the changes that were entered but canceled
        updateTree(targetSub == null ?
            target.getQualifiedName() : targetSub.getQualifiedName());

        }
    
    // Declared at the super level
    /**
    * Ends a dialog, setting the specified result of the DailogBox. The
    * conventions for the result value are:
    * Value of null means the canceled action. Value of Boolean.TRUE means the
    * default action and then the DialogBox result value is set as follows:
    * if the panel implements XmlSerializable then the result is set to the
    * appropriate XML value; otherwise the result value is set to the Config
    * object.
    * 
    * @param oResult the result value of the dialiog box with this main panel
    * 
    * @see DialogParam property
    * @see JButton.DefaultButton#onAction
    * @see JButton.EscapeButton#onAction
    */
    public void endDialog(Object oResult)
        {
        // import Component.Dev.Project.ProjectInfo as Project;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Storage.TAPSStorage;
        // import Component.GUI.TreeNode;
        // import Component.GUI.TreeNode.SimpleNode;
        // import javax.swing.JOptionPane;
        
        TAPSStorage storage = getStorage();
        
        if (storage != null && oResult == Boolean.TRUE)
            {
            $TX_Project TX_Project = ($TX_Project) _findName("TX_Project");
        
            SimpleNode node   = (SimpleNode) TX_Project.getSelectionNode();
            Object     oRef   = node == null ? null : node.getReference();
            Target     target = null;
        
            if (oRef instanceof Target)
                {
                target = (Target) oRef;
                }
            else if (oRef instanceof Project)
                {
                target = ((Project) oRef).getDefaultTarget();
                if (target == null)
                    {
                    String sMsg = "Default sub-project is invalid.\n\n";
                    msg("Message", new Object[]
                        {
                        sMsg, getTitle(), new Integer(JOptionPane.ERROR_MESSAGE),
                        });
                    return;
                    }
                }
            else
                {
                _beep();
                return;
                }
        
            if (target.isLocked())
                {
                String sMsg = "This project is locked.\n\n" +
                              "Would you like to open it in a \"ReadOnly\" mode?";
                Integer intAns = (Integer) msg("Confirm", new Object[]
                    {
                    sMsg, getTitle(), new Integer(JOptionPane.YES_NO_OPTION),
                    });
        
                if (intAns.intValue() != JOptionPane.YES_OPTION)
                    {
                    return;
                    }
                }
        
            storage.setQualifiedProject(target.getQualifiedName());
            oResult = storage;
            }
        
        super.endDialog(oResult);
        }
    
    // Accessor for the property "Storage"
    /**
    * Getter for property Storage.<p>
    */
    public _package.component.dev.storage.TAPSStorage getStorage()
        {
        return __m_Storage;
        }
    
    // Declared at the super level
    /**
    * The "component has been added to a containing component"
    * method-notification.
    * 
    * Note: this notification is not sent during the component's state
    * initialization (deserialization)
    * 
    * @see _addChild
    */
    public void onAdd()
        {
        // import Component.Dev.Storage.TAPSStorage;
        
        super.onAdd();
        
        TAPSStorage storage = (TAPSStorage) getDialogParam();
        if (storage != null)
            {
            setStorage(storage);
            updateTree(storage.getQualifiedProject());
            }
        }
    
    /**
    * Create a new project
    */
    public void removeProject()
        {
        // import Component.Dev.Project.StorageFactory;
        // import Component.Dev.Project.ProjectInfo as Project;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.GUI.TreeNode.SimpleNode;
        // import javax.swing.JOptionPane;
        
        $TX_Project TX_Project = ($TX_Project) _findName("TX_Project");
        
        SimpleNode node = (SimpleNode) TX_Project.getSelectionNode();
        if (node != null)
            {
            Object oRef = node.getReference();
            if (oRef instanceof Project)
                {
                _beep();
                return;
                }
            
            Target target = (Target) oRef;
            if (target.getName().equals(
                    target.getProjectInfo().getDefaultTargetName()))
                {
                _beep();
                return;
                }
        
            String sMsg = "Removing the subproject definition will not remove\n" +
                          "the data from the project storage.\n\n" +
                          "Are you sure you want to proceed?";
            Integer intAns = (Integer) msg("Confirm", new Object[]
                {
                sMsg,
                getTitle(),
                new Integer(JOptionPane.YES_NO_OPTION),
                });
            if (intAns.intValue() != JOptionPane.YES_OPTION)
                {
                return;
                }
        
            StorageFactory factory  = getStorage().getProjectFactory();
            Project        project  = target.getProjectInfo();
        
            project.getTargetList().remove(target.getName());
            factory.storeProjectInfo(project);
        
            updateTree(project.getName());
            }
        }
    
    // Accessor for the property "Storage"
    /**
    * Setter for property Storage.<p>
    */
    private void setStorage(_package.component.dev.storage.TAPSStorage pStorage)
        {
        __m_Storage = pStorage;
        }
    
    public void updateDescription()
        {
        // import Component.Dev.Project.ProjectInfo;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.GUI.TreeNode.SimpleNode;
        
        $TX_Project TX_Project = ($TX_Project) _findName("TX_Project");
        $LBL_Descr  LBL_Descr  = ($LBL_Descr)  _findName("LBL_Descr");
        
        SimpleNode node = (SimpleNode) TX_Project.getSelectionNode();
        Object     oRef = node.getReference();
        String     sDescr;
        
        if (oRef instanceof ProjectInfo)
            {
            sDescr = ((ProjectInfo) oRef).toHTML();
            }
        else if (oRef instanceof Target)
            {
            sDescr = ((Target) oRef).toHTML();
            }
        else
            {
            sDescr = "";
            }
        
        LBL_Descr.setText(sDescr);
        

        }
    
    /**
    * Update the view and select the specified project
    */
    private void updateTree(String sProject)
        {
        // import Component.Dev.Project.ProjectInfo as Project;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Project.StorageFactory;
        // import Component.Dev.Storage.TAPSStorage;
        // import Component.GUI.TreeNode;
        // import Component.GUI.TreeNode.SimpleNode;
        // import com.tangosol.util.ListMap;
        // import java.util.Iterator;
        
        $TX_Project TX_Project = ($TX_Project) _findName("TX_Project");
        
        TAPSStorage    storage = getStorage();
        StorageFactory factory = storage.getProjectFactory();
        
        String[] asProject  = factory == null ? null : factory.getProjects();
        int      of         = sProject.indexOf(':');
        String   sPrjDomain = of < 0 ? sProject : sProject.substring(0, of);
        String   sPrjTarget = of < 0 ? ""       : sProject.substring(of + 1);
        TreeNode nodeRoot   = TX_Project.getRoot();
        TreeNode nodeSelect = null;
        
        TX_Project.removeAllNodes();
        
        for (int i = 0; i < asProject.length; i++)
            {
            String  sPrj = asProject[i];
            Project project;
            try
                {
                project = factory.loadProjectInfo(sPrj);
                if (project == null)
                    {
                    throw new RuntimeException("Project info is missing");
                    }
                }
            catch (Exception e)
                {
                String sMsg = "Failed to load project info for \"" + sPrj +
                    "\"\n\n" + e.getMessage();
                msg("Message", new Object[]
                    {
                    sMsg,
                    getTitle(),
                    new Integer(javax.swing.JOptionPane.INFORMATION_MESSAGE),
                    });
                continue;
                }
        
            ListMap     listTrg = project.getTargetList();
            SimpleNode  nodePrj = (SimpleNode) TX_Project.addNode(nodeRoot, sPrj);
        
            nodePrj.setReference(project);
        
            boolean fSelect = sPrj.equals(sPrjDomain);
            if (fSelect)
                {
                nodeSelect = nodePrj;
                }
        
            for (Iterator iter = listTrg.values().iterator(); iter.hasNext();)
                {
                Target target = (Target) iter.next();
        
                String     sTarget = target.getName();
                SimpleNode nodeSub = (SimpleNode) TX_Project.addNode(nodePrj, sTarget);
        
                nodeSub.setReference(target);
        
                if (fSelect && sTarget.equals(sPrjTarget))
                    {
                    nodeSelect = nodeSub;
                    }
                }
            nodePrj.setExpanded(fSelect);
            }
        
        if (nodeSelect == null && TX_Project.getRowCount() > 0)
            {
            nodeSelect = TX_Project.getNodeForRow(0);
            }
        
        if (nodeSelect != null)
            {
            TX_Project.setSelectionNode(nodeSelect);
            }
        }
    }
