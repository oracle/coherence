/* Class
*     _package.component.gUI.control.container.jComponent.jMenuBar.TAPSMenu$File$TestRun
*/

package _package.component.gUI.control.container.jComponent.jMenuBar;

public class TAPSMenu$File$TestRun
        extends    _package.component.gUI.control.container.jComponent.abstractButton.JMenuItem
    {
    // Fields declarations
    
    // Default constructor
    public TAPSMenu$File$TestRun()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPSMenu$File$TestRun(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(16.0F);
            setActionCommand("@TestRun");
            setFocusable(true);
            setMnemonic('U');
            setText("Unit Test");
            setTFont("DefaultMenu");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new TAPSMenu$File$TestRun();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jMenuBar/TAPSMenu$File$TestRun".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent();
        }
    }
