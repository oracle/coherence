/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.TAPSProject$Center$MainTab$TX_Project
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.dev.project.ProjectInfo$Target; // as Target
import _package.component.dev.project.ProjectInfo;
import _package.component.dev.project.ProjectInfo; // as Project
import _package.component.gUI.treeNode.SimpleNode;

public class TAPSProject$Center$MainTab$TX_Project
        extends    _package.component.gUI.control.container.jComponent.jTree.SimpleTree
    {
    // Fields declarations
    
    // Default constructor
    public TAPSProject$Center$MainTab$TX_Project()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPSProject$Center$MainTab$TX_Project(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setClosedIcon(null);
            setEditable(false);
            setFocusable(true);
            setHorizontalScrollBarPolicy(30);
            setLargeModel(false);
            setLeafIcon(null);
            setOpenIcon(null);
            setRedraw(true);
            setRootName(null);
            setRootVisible(false);
            setRowHeight(16);
            setScrollable(true);
            setScrollsOnExpand(true);
            setSelectionMode(1);
            setSeparator('.');
            setShowNodeTips(true);
            setShowsRootHandles(true);
            setSorted(true);
            setTBounds("10,5,175,315");
            setTFont("DefaultProportional");
            setVerticalScrollBarPolicy(20);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new _package.component.gUI.control.container.jComponent.JTree$KeyCollapse("KeyCollapse", this, true), "KeyCollapse");
        _addChild(new _package.component.gUI.control.container.jComponent.JTree$KeyExpand("KeyExpand", this, true), "KeyExpand");
        _addChild(new _package.component.gUI.control.container.jComponent.JTree$KeyExpandAll("KeyExpandAll", this, true), "KeyExpandAll");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new TAPSProject$Center$MainTab$TX_Project();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/TAPSProject$Center$MainTab$TX_Project".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent().get_Parent();
        }
    
    // Declared at the super level
    /**
    * Returns the tool tip text for the specified node. If the
    * <code>node</code> is null, there is no node at the mouse position.
    * Default implementation shows the full text of the node only when the node
    * is partially invisible.
    * 
    * Note: this method is only called if the ShowNodeTips property is set to
    * true.
    * 
    * @see#ShowNodeTips property
    * @see #getTooTipText(MouseEvent)
    */
    public String getToolTipText(_package.component.gUI.TreeNode node)
        {
        // import Component.GUI.TreeNode.SimpleNode;
        // import Component.Dev.Project.ProjectInfo;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        
        String sTip = "";
        
        if (node instanceof SimpleNode)
            {
            Object oRef = ((SimpleNode) node).getReference();
        
            if (oRef instanceof ProjectInfo)
                {
                sTip = ((ProjectInfo) oRef).getDescription();
                }
            else if (oRef instanceof Target)
                {
                sTip = ((Target) oRef).getDescription();
                }
            }
        
        return sTip.length() > 0 ? sTip : super.getToolTipText(node);
        }
    
    // Declared at the super level
    public void onMouseReleased(_package.component.gUI.Point point, int modifiers, int clickCount, boolean popupTrigger)
        {
        super.onMouseReleased(point, modifiers, clickCount, popupTrigger);
        
        if (clickCount == 2)
            {
            (($Module) get_Module()).endDialog(Boolean.TRUE);
            }
        }
    
    // Declared at the super level
    public void onSelected(_package.component.gUI.TreeNode node)
        {
        // import Component.Dev.Project.ProjectInfo as Project;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.GUI.TreeNode.SimpleNode;
        
        super.onSelected(node);
        
        boolean fSelectable = false;
        boolean fRemovable  = false;
        if (node instanceof SimpleNode)
            {
            Object oRef = ((SimpleNode) node).getReference();
            
            fSelectable = oRef instanceof Target || oRef instanceof Project;
            if (oRef instanceof Target)
                {
                Target target = (Target) oRef;
                fRemovable = !target.getName().equals(
                    target.getProjectInfo().getDefaultTargetName());
                }
            }
        
        (($CB_OK)     _findName("CB_OK"))    .setEnabled(fSelectable);
        (($CB_Remove) _findName("CB_Remove")).setEnabled(fRemovable);
        
        (($Module) get_Module()).updateDescription();
        }
    }
