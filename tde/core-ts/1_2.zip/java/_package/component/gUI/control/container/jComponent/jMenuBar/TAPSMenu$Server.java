/* Class
*     _package.component.gUI.control.container.jComponent.jMenuBar.TAPSMenu$Server
*/

package _package.component.gUI.control.container.jComponent.jMenuBar;

import _package.component.application.gUI.desktop.TDE;
import _package.component.dev.storage.TAPSStorage;

public class TAPSMenu$Server
        extends    _package.component.gUI.control.container.jComponent.abstractButton.jMenuItem.JMenu
    {
    // Fields declarations
    
    // Default constructor
    public TAPSMenu$Server()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPSMenu$Server(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(6.0F);
            setFocusable(true);
            setMnemonic('S');
            setText("Server");
            setTFont("DefaultMenu");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new TAPSMenu$Server$Config("Config", this, true), "Config");
        _addChild(new TAPSMenu$Server$Reload("Reload", this, true), "Reload");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new TAPSMenu$Server();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jMenuBar/TAPSMenu$Server".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    /**
    * Method notification (called by itemStateChanged) is sent when the
    * Selected property of an item changes its value
    * 
    * @param item  an AbstractButton item that originated the event
    * @param state  STATE_SELECTED if the Selected property value has changed
    * to true; STATE_DESELECTED otherwise
    * 
    * @see #onStateChanged
    * 
    * +++++++++++++++++++++++++++++
    * 
    * Specifically to JMenu: this notification comes with state parameter
    * having STATE_CHILD bit set when onItemStateChanged notification is sent
    * to any of this JMenu's children.
    * 
    * @see JMenuItem#onItemStateChanged
    */
    public void onItemStateChanged(_package.component.gUI.control.container.jComponent.AbstractButton item, int state)
        {
        // import Component.Application.GUI.Desktop.TDE;
        // import Component.Dev.Storage.TAPSStorage;
        
        super.onItemStateChanged(item, state);
        
        TDE         app     = (TDE) TDE.get_Instance();
        TAPSStorage storage = (TAPSStorage) app.getHost().getStorage();
        
        (($Reload) _findName("Reload")).setEnabled(storage != null);
        }
    }
