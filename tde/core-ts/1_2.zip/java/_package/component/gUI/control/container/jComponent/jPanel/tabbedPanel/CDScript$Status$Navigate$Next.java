/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDScript$Status$Navigate$Next
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel;

public class CDScript$Status$Navigate$Next
        extends    _package.component.gUI.control.container.jComponent.abstractButton.jButton.NoFocusButton
    {
    // Fields declarations
    
    // Default constructor
    public CDScript$Status$Navigate$Next()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDScript$Status$Navigate$Next(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(false);
            setFocusPainted(false);
            setOpaque(true);
            setTBounds("15,1,14,14");
            setTFont("DefaultProportional");
            setTIcon("Next14");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new CDScript$Status$Navigate$Next();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/CDScript$Status$Navigate$Next".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent().get_Parent();
        }
    
    // Declared at the super level
    /**
    * This notification (called by actionPerformed) is sent when an armed item
    * (Armed == true) gets unpressed (Pressed == false). This also could be a
    * result of an "accelerator key" action.
    * 
    * Note: setting the Selected property to true (calling setSelected(true))
    * does not trigger an Action event. However, calling doClick() does.
    * 
    * @param action  content of this component's ActionComand property
    * @param modifiers  the key modifier that was selected, and is used to
    * determine the state of the selected key
    * @param param  currently not used (intended for for event-logging and for
    * debugging)
    * 
    * @see #onItemStateChanged
    * @see #onStateChanged
    * @see javax.swing.DefaultButtonModel#setPressed
    */
    public void onAction(String action, int modifiers, String param)
        {
        super.onAction(action, modifiers, param);
        
        $Module module = ($Module) get_Module();
        
        int iScript  = module.getScriptPos() + 1;
        int cScripts = module.getScriptCount();
        
        if (iScript < cScripts)
            {
            module.setScriptPos(iScript);
            }
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        super.onInit();
        // TODO: complex property
        setDisabledIcon(new Component.GUI.Image.Icon.Next14D());
        }
    }
