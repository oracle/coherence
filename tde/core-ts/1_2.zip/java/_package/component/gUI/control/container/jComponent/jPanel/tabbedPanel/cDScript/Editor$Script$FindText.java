/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.cDScript.Editor$Script$FindText
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.cDScript;

import _package.component.dev.Tool;
import _package.component.gUI.control.container.jComponent.jPanel.ToolSite;

public class Editor$Script$FindText
        extends    _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDScript$Script$FindText
    {
    // Fields declarations
    
    /**
    * Property SearchAllScripts
    *
    * Specifies whether the search should go through all available scripts.
    */
    private boolean __m_SearchAllScripts;
    
    // Default constructor
    public Editor$Script$FindText()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Editor$Script$FindText(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(false);
            setTBounds("0,0,395,135");
            setTConstraints("Center");
            setTitle("Find");
            setTLayout(null);
            setVisible(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$BG_Direction("BG_Direction", this, true), "BG_Direction");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$BTN_Cancel("BTN_Cancel", this, true), "BTN_Cancel");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$BTN_Next("BTN_Next", this, true), "BTN_Next");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$CBX_Find("CBX_Find", this, true), "CBX_Find");
        _addChild(new Editor$Script$FindText$CHK_All("CHK_All", this, true), "CHK_All");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$CHK_Case("CHK_Case", this, true), "CHK_Case");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$CHK_Reg("CHK_Reg", this, true), "CHK_Reg");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$CHK_Word("CHK_Word", this, true), "CHK_Word");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$KeyFind("KeyFind", this, true), "KeyFind");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$KeyFindNext("KeyFindNext", this, true), "KeyFindNext");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$KeyFindPrev("KeyFindPrev", this, true), "KeyFindPrev");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$KeyFindSelection("KeyFindSelection", this, true), "KeyFindSelection");
        _addChild(new _package.component.gUI.control.container.jComponent.jPanel.FindText$LBL_Find("LBL_Find", this, true), "LBL_Find");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Editor$Script$FindText();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/cDScript/Editor$Script$FindText".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent();
        }
    
    // Accessor for the property "SearchAllScripts"
    /**
    * Getter for property SearchAllScripts.<p>
    * Specifies whether the search should go through all available scripts.
    */
    public boolean isSearchAllScripts()
        {
        return (($CHK_All) _findName("CHK_All")).isSelected();
        }
    
    // Declared at the super level
    /**
    * Perform the search based on the current settings. This method could be
    * overriten if the host is not one of the component types that the FindText
    * is aware of.
    * 
    * @param oAction  if the search is initiated by the dialog box, this
    * carries the value returned by the dialogBox() call; otherwise is null.
    */
    protected void performSearch(Object oAction)
        {
        // import Component.Dev.Tool;
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite;
        
        if (oAction != null && isSearchAllScripts())
            {
            String sPattern = getSearchPattern();
            if (sPattern.length() != 0)
                {
                updateSearchHistory(sPattern);
                (($Module) get_Module()).apply();
        
                ToolSite site = ((ToolSite) _findAncestor(ToolSite.class));
                site.getTool().fireToolAction(Tool.ACTION_SEARCH, oAction);
                }
            }
        else
            {
            super.performSearch(oAction);
            }
        }
    
    // Accessor for the property "SearchAllScripts"
    /**
    * Setter for property SearchAllScripts.<p>
    * Specifies whether the search should go through all available scripts.
    */
    public void setSearchAllScripts(boolean pSearchAllScripts)
        {
        (($CHK_All) _findName("CHK_All")).setSelected(pSearchAllScripts);
        }
    }
