/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.CDIntegrationAttributes
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import com.tangosol.dev.component.Integration;
import java.beans.PropertyVetoException;

/**
* doc
*/
public class CDIntegrationAttributes
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property INTEGRATOR_ROOT
    *
    */
    public static final String INTEGRATOR_ROOT = "Component.Dev.Compiler.Integrator.";
    
    /**
    * Property Map
    *
    */
    private transient com.tangosol.dev.component.Integration __m_Map;
    
    // Default constructor
    public CDIntegrationAttributes()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDIntegrationAttributes(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(true);
            setTBorder("EtchedSimple");
            setTBounds("0,0,320,140");
            setTConstraints("North");
            setTLayout(null);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new CDIntegrationAttributes$BTN_Apply("BTN_Apply", this, true), "BTN_Apply");
        _addChild(new CDIntegrationAttributes$LBL_Class("LBL_Class", this, true), "LBL_Class");
        _addChild(new CDIntegrationAttributes$LBL_Misc("LBL_Misc", this, true), "LBL_Misc");
        _addChild(new CDIntegrationAttributes$LBL_Model("LBL_Model", this, true), "LBL_Model");
        _addChild(new CDIntegrationAttributes$TXT_Class("TXT_Class", this, true), "TXT_Class");
        _addChild(new CDIntegrationAttributes$TXT_Misc("TXT_Misc", this, true), "TXT_Misc");
        _addChild(new CDIntegrationAttributes$TXT_Model("TXT_Model", this, true), "TXT_Model");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CDIntegrationAttributes();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/CDIntegrationAttributes".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    public void apply()
        {
        // import com.tangosol.dev.component.Integration;
        // import java.beans.PropertyVetoException;
        
        Integration map = getMap();
        if (map == null)
            {
            return;
            }
        
        $TXT_Model TXT_Model = ($TXT_Model) _findName("TXT_Model");
        $TXT_Misc  TXT_Misc  = ($TXT_Misc ) _findName("TXT_Misc" );
        
        String sModel = map.getModel();
        String sMisc  = map.getMisc();
        
        String sNewModel = TXT_Model.getText();
        String sNewMisc  = TXT_Misc .getText();
        
        if (!sNewModel.startsWith(INTEGRATOR_ROOT))
            {
            sNewModel = INTEGRATOR_ROOT + sNewModel;
            }
        
        if (!sModel.equals(sNewModel)
            || !sMisc.equals(sNewMisc))
           {
            try
                {
                map.setModel(sNewModel, sNewMisc);
                }
            catch (PropertyVetoException e)
                {
                onError(TXT_Model, e.toString());
                }
            }

        }
    
    // Accessor for the property "Map"
    /**
    * Getter for property Map.<p>
    */
    public com.tangosol.dev.component.Integration getMap()
        {
        return __m_Map;
        }
    
    private void loadMap()
        {
        // import com.tangosol.dev.component.Integration;
        
        Integration map = getMap();
        
        String sSignature = map.getSignature();
        setTitle(sSignature);
        (($TXT_Class) _findName("TXT_Class")).setText(sSignature);
        
        loadModel();

        }
    
    private void loadModel()
        {
        // import com.tangosol.dev.component.Integration;
        
        Integration map = getMap();
        
        $TXT_Model TXT_Model = ($TXT_Model) _findName("TXT_Model");
        $TXT_Misc  TXT_Misc  = ($TXT_Misc ) _findName("TXT_Misc" );
        
        String sModel = map.getModel();
        String sMisc  = map.getMisc();
        
        if (sModel.startsWith(INTEGRATOR_ROOT))
            {
            sModel = sModel.substring(INTEGRATOR_ROOT.length());
            }
        
        TXT_Model.setText(sModel);
        TXT_Misc .setText(sMisc);
        
        boolean fSettable = map.isModelSettable();
        TXT_Model.setEditable(fSettable);
        TXT_Misc .setEditable(fSettable);
        }
    
    private void onError(_package.component.gUI.Control ctrl, String sErr)
        {
        if (ctrl != null)
            {
            ctrl.requestFocus();
            }
        _trace(sErr);
        _beep();

        }
    
    public void onModelModified()
        {
        // import com.tangosol.dev.component.Integration;
        
        Integration map = getMap();
        if (map == null)
            {
            return;
            }
        
        loadModel();
        

        }
    
    public void onSignatureModified()
        {
        // import com.tangosol.dev.component.Integration;
        
        Integration map = getMap();
        if (map == null)
            {
            return;
            }
        
        loadMap();
        

        }
    
    // Accessor for the property "Map"
    /**
    * Setter for property Map.<p>
    */
    public void setMap(com.tangosol.dev.component.Integration map)
        {
        __m_Map = (map);
        
        if (map == null)
            {
            setVisible(false);
            setTitle("");
            return;
            }
        
        loadMap();
        
        $TXT_Class TXT_Class = ($TXT_Class) _findName("TXT_Class");
        
        String sSignature = map.getSignature();
        
        setTitle(sSignature);
        
        TXT_Class.setText(sSignature);
        
        loadModel();
        
        setVisible(true);

        }
    }
