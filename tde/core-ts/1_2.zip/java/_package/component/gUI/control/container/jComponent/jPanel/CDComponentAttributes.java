/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.CDComponentAttributes
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.dev.Design;
import _package.component.dev.tool.host.CDTool;
import _package.component.gUI.Control;
import _package.component.gUI.control.container.jComponent.JTable;
import _package.component.gUI.control.container.jComponent.abstractButton.JToggleButton;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.Constants;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Integration;
import com.tangosol.dev.component.Interface;
import com.tangosol.util.ChainedEnumerator;
import com.tangosol.util.SimpleEnumerator;
import java.beans.PropertyVetoException;
import java.util.Enumeration;
import javax.swing.JOptionPane;

public abstract class CDComponentAttributes
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property Applying
    *
    * Privately used property specifying that this component is currently in a
    * process of applying the changes to the corresponding Component
    * Definition.
    * 
    * @see #apply
    * @see #update
    */
    private boolean __m_Applying;
    
    /**
    * Property CDTool
    *
    */
    
    /**
    * Property Component
    *
    */
    private transient com.tangosol.dev.component.Component __m_Component;
    
    // Initializing constructor
    public CDComponentAttributes(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/CDComponentAttributes".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    public void apply()
        {
        // import Component.Dev.Tool.Host.CDTool;
        // import Component.GUI.Control;
        // import Component.GUI.Control.Container.JComponent.AbstractButton.JToggleButton;
        // import Component.GUI.Control.Container.JComponent.JTable;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.Constants;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Integration;
        // import com.tangosol.dev.component.Interface;
        // import java.beans.PropertyVetoException;
        
        $TXT_Name               TXT_Name        = ($TXT_Name)                _findName("TXT_Name");
        $TXT_Integrates         TXT_Integrates  = ($TXT_Integrates)          _findName("TXT_Integrates");
        $RG_Visible             RG_Visible      = ($RG_Visible)              _findName("RG_Visible");
        $RG_Visible$RB_Visible  RB_Visible      = ($RG_Visible$RB_Visible)   _findName("RG_Visible$RB_Visible");
        $RG_Visible$RB_Hidden   RB_Hidden       = ($RG_Visible$RB_Hidden)    _findName("RG_Visible$RB_Hidden");
        $RG_Visible$RB_Advanced RB_Advanced     = ($RG_Visible$RB_Advanced)  _findName("RG_Visible$RB_Advanced");
        $RG_Visible$RB_System   RB_System       = ($RG_Visible$RB_System)    _findName("RG_Visible$RB_System");
        $CHK_Abstract           CHK_Abstract    = ($CHK_Abstract)            _findName("CHK_Abstract");
        $CHK_Static             CHK_Static      = ($CHK_Static)              _findName("CHK_Static");
        $CHK_Final              CHK_Final       = ($CHK_Final)               _findName("CHK_Final");
        $CHK_Deprecated         CHK_Deprecated  = ($CHK_Deprecated)          _findName("CHK_Deprecated");
        $CHK_Remote             CHK_Remote      = ($CHK_Remote)              _findName("CHK_Remote");
        $CHK_Persistent         CHK_Persistent  = ($CHK_Persistent)          _findName("CHK_Persistent");
        $TBL_Events             TBL_Events      = ($TBL_Events)              _findName("TBL_Events");
        $TBL_Interfaces         TBL_Interfaces  = ($TBL_Interfaces)          _findName("TBL_Interfaces");
        $TBL_Categories         TBL_Categories  = ($TBL_Categories)          _findName("TBL_Categories");
        
        Component cd   = getComponent();
        CDTool    tool = getCDTool();
        
        // Phase 1 -- retrieve data and do some primary validation
        
        String sName = TXT_Name.getText();
        if (sName.length() == 0)
            {
            onError(TXT_Name, "Missing component name");
            }
        
        String sIntegration = TXT_Integrates.getText();
        
        JTable tblEvent = TBL_Events.getTable();
        tblEvent.removeEmptyRows(true);
        
        String[] asEvent = tblEvent.getColumnStrings(0);
        int      cEvents = asEvent.length;
        
        for (int i = 0; i < cEvents; i++)
            {
            // we dont perform a complete check whether the class is a listener (TODO)
            // but at least preventing the spelling error
            DataType dt = tool.getDataType(asEvent[i]);
            if (dt == null || !dt.isClass())
                {
                onError(tblEvent, "Invalid event name " + asEvent[i]);
                tblEvent.editCellAt(i, 0);
                return;
                }
            }
        
        JTable tblInterface = TBL_Interfaces.getTable();
        tblInterface.removeEmptyRows(true);
        
        String[] asInterface = tblInterface.getColumnStrings(0);
        int      cInterfaces = asInterface.length;
        for (int i = 0; i < cInterfaces; i++)
            {
            DataType dt = tool.getDataType(asInterface[i]);
            if (dt == null || !dt.isClass())
                {
                onError(tblEvent, "Invalid interface name " + asInterface[i]);
                tblInterface.editCellAt(i, 0);
                return;
                }
            }
        
        JTable tblCategory = TBL_Categories.getTable();
        tblCategory.removeEmptyRows(true);
        
        String[] asCategory  = tblCategory.getColumnStrings(0);
        int      cCategories = asCategory.length;
        for (int i = 0; i < cCategories; i++)
            {
            DataType dt = tool.getDataType(asCategory[i]);
            if (dt == null || !dt.isComponent())
                {
                onError(tblEvent, "Invalid category " + asCategory[i]);
                tblCategory.editCellAt(i, 0);
                return;
                }
            }
        
        JToggleButton rb = RG_Visible.getSelection();
        int nVisible = rb == RB_Visible  ? Constants.VIS_VISIBLE  :
                       rb == RB_Hidden   ? Constants.VIS_HIDDEN   :
                       rb == RB_Advanced ? Constants.VIS_ADVANCED :
                                           Constants.VIS_SYSTEM   ;
        
        boolean fAbstract   = CHK_Abstract  .isSelected();
        boolean fStatic     = CHK_Static    .isSelected();
        boolean fFinal      = CHK_Final     .isSelected();
        boolean fRemote     = CHK_Remote    .isSelected();
        boolean fDeprecated = CHK_Deprecated.isSelected();
        boolean fPersistent = CHK_Persistent.isSelected();
        
        // Phase 2 -- apply data do the component definition
        setApplying(true);
        
        if (!cd.getName().equals(sName))
            {
            try
                {
                cd.setName(sName);
                }
            catch (PropertyVetoException e)
                {
                onError(TXT_Name, e.toString());
                }
            }
        
        // Integrates
        Integration imap = cd.getIntegration();
        String      sIntegrationOrg = imap != null ? imap.getSignature() : "";
        if (!sIntegrationOrg.equals(sIntegration))
            {
            try
                {
                if (sIntegration.length() > 0)
                    {
                    Component jcsIntegratee = tool.getStorage().loadSignature(sIntegration);
        
                    cd.setIntegration(jcsIntegratee, tool.getErrorList());
                    }
                else
                    {
                    cd.setIntegration(null, null);
                    }
                }
            catch (ComponentException ce)
                {
                onError(TXT_Integrates, ce.toString());
                return;
                }
            catch (PropertyVetoException pve)
                {
                onError(TXT_Integrates, pve.toString());
                return;
                }
            }
        
        try
            {
            // Dispatches (EventListeners)
        
            String[] asEventOrg = cd.getDispatches();
            removeMatches(asEvent, asEventOrg);
        
            for (int i = 0; i < asEvent.length; i++)
                {
                String sEvent = asEvent[i];
                if (sEvent != null)
                    {
                    DataType  dtEvent  = tool.getDataType(sEvent);
                    Component jcsEvent = tool.getStorage().loadSignature(dtEvent.getClassName());
                    cd.addDispatches(jcsEvent);
                    }
                }
        
            for (int i = 0; i < asEventOrg.length; i++)
                {
                String sEvent = asEventOrg[i];
                if (sEvent != null)
                    {
                    Interface iface = cd.getDispatches(sEvent);
                    if (confirmRemove(iface))
                        {
                        cd.removeDispatches(sEvent);
                        }
                    }
                }
        
            // Implements (Interfaces)
        
            String[] asInterfaceOrg = cd.getImplements();
            removeMatches(asInterface, asInterfaceOrg);
        
            for (int i = 0; i < asInterface.length; i++)
                {
                String sInterface = asInterface[i];
                if (sInterface != null)
                    {
                    DataType  dtInterface  = tool.getDataType(sInterface);
                    Component jcsInterface = tool.getStorage().loadSignature(dtInterface.getClassName());
                    cd.addImplements(jcsInterface);
                    }
                }
        
            for (int i = 0; i < asInterfaceOrg.length; i++)
                {
                String sInterface = asInterfaceOrg[i];
                if (sInterface != null)
                    {
                    Interface iface = cd.getImplements(sInterface);
                    if (confirmRemove(iface))
                        {
                        cd.removeImplements(sInterface);
                        }
                    }
                }
        
            // Categories
        
            String[] asCategoryOrg = cd.getCategories();
            removeMatches(asCategory, asCategoryOrg);
        
            for (int i = 0; i < asCategory.length; i++)
                {
                String sCategory = asCategory[i];
                if (sCategory != null)
                    {
                    DataType dtCategory = tool.getDataType(sCategory);
                    cd.addCategory(dtCategory.getComponentName());
                    }
                }
        
            for (int i = 0; i < asCategoryOrg.length; i++)
                {
                String sCategory = asCategoryOrg[i];
                if (sCategory != null)
                    {
                    cd.removeCategory(sCategory);
                    }
                }
            }
        catch (ComponentException ce)
            {
            onError(null, ce.toString());
            return;
            }
        catch (PropertyVetoException pve)
            {
            onError(null, pve.toString());
            return;
            }
        
        // Other attributes
        try
            {
            if (cd.getVisible() != nVisible)
                {
                cd.setVisible(nVisible);
                }
            if (cd.isAbstract() != fAbstract)
                {
                cd.setAbstract(fAbstract);
                }
            if (cd.isStatic() != fStatic)
                {
                cd.setStatic(fStatic);
                }
            if (cd.isFinal() != fFinal)
                {
                cd.setFinal(fFinal);
                }
            if (cd.isRemote() != fRemote)
                {
                cd.setRemote(fRemote);
                }
            if (cd.isDeprecated() != fDeprecated)
                {
                cd.setDeprecated(fDeprecated);
                }
            if (cd.isPersistent() != fPersistent)
                {
                cd.setPersistent(fPersistent);
                }
            }
        catch (PropertyVetoException e)
            {
            onError(null, e.toString());
            }
        
        setApplying(false);
        update();
        }
    
    /**
    * Confirm whether or not the interface should be removed. This gives a user
    * the last chance to mark the methods on the interface as "manually
    * declared" to prevent their destruction.
    */
    protected boolean confirmRemove(com.tangosol.dev.component.Interface iface)
        {
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.util.ChainedEnumerator;
        // import com.tangosol.util.SimpleEnumerator;
        // import java.beans.PropertyVetoException;
        // import java.util.Enumeration;
        // import javax.swing.JOptionPane;
        
        String TITLE = "Remove interface";
        
        for (Enumeration enum = iface.getBehaviors(); enum.hasMoreElements();)
            {
            String   sBhvr = (String) enum.nextElement();
            Behavior bhvr  = iface.getComponent().getBehavior(sBhvr);
        
            if (!bhvr.isFromManual() && bhvr.isFromManualSettable() &&
                 bhvr.getModifiableImplementationCount() > 0)
                {
                Enumeration enumOrigin = new ChainedEnumerator(
                    bhvr.enumImplements(), bhvr.enumDispatches());
                Object[] aoOrigin = SimpleEnumerator.toArray(enumOrigin);
                if (aoOrigin.length > 1)
                    {
                    // there are other origins to keep this behavior in
                    continue;
                    }
        
                String sMsg = "The interface \"" + iface.getName() +
                    "\"\ncontains a scripted method \"" + bhvr +
                    "\"\n\nWould you like to retain this method?\n";
                Integer IAnswer = (Integer) msg("Confirm", new Object[]
                    {
                    sMsg,
                    TITLE,
                    new Integer(JOptionPane.YES_NO_CANCEL_OPTION),
                    });
        
                switch (IAnswer.intValue())
                    {
                    case JOptionPane.YES_OPTION:
                        try
                            {
                            bhvr.setFromManual(true);
                            }
                        catch (PropertyVetoException e)
                            {
                            sMsg = "Cannot set the manual origin:\n" + e.getMessage();
                            msg("Message", new Object[]
                                {
                                sMsg,
                                TITLE,
                                new Integer(JOptionPane.INFORMATION_MESSAGE),
                                });
                            return false;
                            }
                        // break through
        
                    case JOptionPane.NO_OPTION:
                        continue;
            
                    case JOptionPane.CANCEL_OPTION:
                    case JOptionPane.CLOSED_OPTION:
                    default:
                        return false;
                    }
                }
            }
        
        return true;
        }
    
    // Accessor for the property "CDTool"
    /**
    * Getter for property CDTool.<p>
    */
    public _package.component.dev.tool.host.CDTool getCDTool()
        {
        return null;
        }
    
    // Accessor for the property "Component"
    /**
    * Getter for property Component.<p>
    */
    public com.tangosol.dev.component.Component getComponent()
        {
        return __m_Component;
        }
    
    // Accessor for the property "Applying"
    /**
    * Getter for property Applying.<p>
    * Privately used property specifying that this component is currently in a
    * process of applying the changes to the corresponding Component
    * Definition.
    * 
    * @see #apply
    * @see #update
    */
    protected boolean isApplying()
        {
        return __m_Applying;
        }
    
    protected void onError(_package.component.gUI.Control ctrl, String sErr)
        {
        if (ctrl != null)
            {
            ctrl.requestFocus();
            }
        _trace(sErr);
        _beep();
        
        setApplying(false);
        }
    
    /**
    * Removes (by nulling out) matching objects out of two arrays (performing
    * kind of symmetrical difference)
    * 
    * @return number of matches (removed)
    */
    protected int removeMatches(Object[] ao1, Object[] ao2)
        {
        int cntMatches = 0;
        
        for (int i1 = 0; i1 < ao1.length; i1++)
            {
            Object o1 = ao1[i1];
        
            if (o1 != null)
                {
                for (int i2 = 0; i2 < ao2.length; i2++)
                    {
                    if (o1.equals(ao2[i2]))
                        {
                        ao1[i1] = null;
                        ao2[i2] = null;
                        cntMatches++;
                        break;
                        }
                    }
                }
            }
        return cntMatches;
        }
    
    // Accessor for the property "Applying"
    /**
    * Setter for property Applying.<p>
    * Privately used property specifying that this component is currently in a
    * process of applying the changes to the corresponding Component
    * Definition.
    * 
    * @see #apply
    * @see #update
    */
    protected void setApplying(boolean pApplying)
        {
        __m_Applying = pApplying;
        }
    
    // Accessor for the property "Component"
    /**
    * Setter for property Component.<p>
    */
    public void setComponent(com.tangosol.dev.component.Component pComponent)
        {
        __m_Component = (pComponent);
        
        update();
        }
    
    public void update()
        {
        // import Component.Dev.Design;
        // import Component.GUI.Control.Container.JComponent.JTable;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Constants;
        // import com.tangosol.dev.component.Interface;
        // import com.tangosol.dev.component.Integration;
        
        if (isApplying())
            {
            return;
            }
        
        Component cd = getComponent();
        if (cd == null)
            {
            setVisible(false);
            return;
            }
        
        $TXT_Name               TXT_Name        = ($TXT_Name)               _findName("TXT_Name");
        $TXT_Integrates         TXT_Integrates  = ($TXT_Integrates)         _findName("TXT_Integrates");
        $RG_Visible             RG_Visible      = ($RG_Visible)             _findName("RG_Visible");
        $RG_Visible$RB_Visible  RB_Visible      = ($RG_Visible$RB_Visible)  _findName("RG_Visible$RB_Visible");
        $RG_Visible$RB_Hidden   RB_Hidden       = ($RG_Visible$RB_Hidden)   _findName("RG_Visible$RB_Hidden");
        $RG_Visible$RB_Advanced RB_Advanced     = ($RG_Visible$RB_Advanced) _findName("RG_Visible$RB_Advanced");
        $RG_Visible$RB_System   RB_System       = ($RG_Visible$RB_System)   _findName("RG_Visible$RB_System");
        $CHK_Abstract           CHK_Abstract    = ($CHK_Abstract)           _findName("CHK_Abstract");
        $CHK_Static             CHK_Static      = ($CHK_Static)             _findName("CHK_Static");
        $CHK_Final              CHK_Final       = ($CHK_Final)              _findName("CHK_Final");
        $CHK_Deprecated         CHK_Deprecated  = ($CHK_Deprecated)         _findName("CHK_Deprecated");
        $CHK_Remote             CHK_Remote      = ($CHK_Remote)             _findName("CHK_Remote");
        $CHK_Persistent         CHK_Persistent  = ($CHK_Persistent)         _findName("CHK_Persistent");
        $TBL_Events             TBL_Events      = ($TBL_Events)             _findName("TBL_Events");
        $TBL_Interfaces         TBL_Interfaces  = ($TBL_Interfaces)         _findName("TBL_Interfaces");
        $TBL_Categories         TBL_Categories  = ($TBL_Categories)         _findName("TBL_Categories");
        
        TXT_Name.setText(cd.getName());
        TXT_Name.setEditable(cd.isNameSettable());
        
        Integration imap        = cd.getIntegration();
        String      sIntegrates = imap != null ? imap.getSignature() : "";
        
        TXT_Integrates.setText(sIntegrates);
        TXT_Integrates.setEditable(cd.isIntegrationSettable());
        
        switch (cd.getVisible())
            {
            default:
            case Constants.VIS_VISIBLE:
                RB_Visible.setSelected(true);
                break;
            case Constants.VIS_HIDDEN:
                RB_Hidden.setSelected(true);
                break;
            case Constants.VIS_ADVANCED:
                RB_Advanced.setSelected(true);
                break;
            case Constants.VIS_SYSTEM:
                RB_System.setSelected(true);
                break;
            }
        RG_Visible.setEnabled(cd.isVisibleSettable());
        
        CHK_Abstract.setSelected(cd.isAbstract());
        CHK_Abstract.setEnabled(cd.isAbstractSettable());
        
        CHK_Static.setSelected(cd.isStatic());
        CHK_Static.setEnabled(cd.isStaticSettable());
        
        CHK_Final.setSelected(cd.isFinal());
        CHK_Final.setEnabled(cd.isFinalSettable());
        
        CHK_Deprecated.setSelected(cd.isDeprecated());
        CHK_Deprecated.setEnabled(cd.isDeprecatedSettable());
        
        // Under conventions, the "remotness" is managed by both
        // Component Definition and the "Design.Component" information
        // TODO: consider to cache the "designInfo"
        Design.Component designInfo = Design.Component.getDesignInfo(cd);
        CHK_Remote.setSelected(cd.isRemote());
        CHK_Remote.setEnabled(cd.isRemoteSettable() && designInfo.isRemotable());
        
        CHK_Persistent.setSelected(cd.isPersistent());
        CHK_Persistent.setEnabled (cd.isPersistentSettable());
        
        JTable tblEvent = TBL_Events.getTable();
        tblEvent.removeAllRows();
        String[] asEvent = cd.getDispatches();
        for (int i = 0; i < asEvent.length; i++)
            {
            tblEvent.addRow(new String[] {asEvent[i]});
            }
        // more specific check is performed at tblEvent.isCellEditable()
        tblEvent.setEnabled(cd.isComponent() && cd.isModifiable());
        tblEvent.repaint(); // JTable's bug
        
        JTable tblInterface = TBL_Interfaces.getTable();
        tblInterface.removeAllRows();
        String[] asInterface = cd.getImplements();
        for (int i = 0; i < asInterface.length; i++)
            {
            tblInterface.addRow(new String[] {asInterface[i]});
            }
        // more specific check is performed on tblInterface.isCellEditable()
        tblInterface.setEnabled(cd.isModifiable());
        tblInterface.repaint(); // JTable's bug
        
        JTable tblCategory = TBL_Categories.getTable();
        tblCategory.removeAllRows();
        String[] asCategory = cd.getCategories();
        for (int i = 0; i < asCategory.length; i++)
            {
            tblCategory.addRow(new String[] {asCategory[i]});
            }
        // more specific check is performed at tblCategory.isCellEditable()
        tblCategory.setEnabled(cd.isComponent() && cd.isModifiable());
        tblCategory.repaint(); // JTable's bug
        
        String sHead = "";
        String sTail = cd.getGlobalSuperName();
        
        if (cd.isComponent())
            {
            if (sTail.length() == 0)
                {
                _assert(cd.getName().equals(Component.getRootName()));
                sHead = "Root Component";
                }
            else
                {
                if (!cd.isGlobal())
                    {
                     if (cd.isFromSuper())
                        {
                        sHead += "Inherited ";
                        }
                    else if (cd.isFromBase())
                        {
                        sHead += "Overlaid ";
                        }
                    }
                }
            }
        else if (cd.isSignature())
            {
            if (sTail.length() == 0)
                {
                // either an interface or java.lang.Object
                if (cd.getName().equals("java.lang.Object"))
                    {
                    sHead = "Root Object";
                    }
                else
                    {
                    sHead = "Java Interface";
                    }
                }
            else
                {
                sHead = "Extends: ";
                }
            }
        else 
            {
            throw new IllegalStateException();
            }
        
        // if the tail is too long, show just the trailing portion ...
        int cLimit = 35;
        int cLen   = sTail.length();
        if (cLen >= cLimit)
            {
            sTail = sTail.substring(sTail.indexOf('.', cLen - cLimit) + 1);
            }
        
        setVisible(true);
        setTitle(sHead + sTail);
        }
    }
