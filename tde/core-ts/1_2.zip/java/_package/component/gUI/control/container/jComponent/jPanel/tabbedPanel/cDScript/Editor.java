/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.cDScript.Editor
*/

package _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.cDScript;

import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Implementation;
import java.beans.PropertyVetoException;

public abstract class Editor
        extends    _package.component.gUI.control.container.jComponent.jPanel.tabbedPanel.CDScript
    {
    // Fields declarations
    
    /**
    * Property Applying
    *
    * Specifies whether the editor is in a process of applying the changes made
    * by the user
    */
    private transient boolean __m_Applying;
    
    /**
    * Property Implementation
    *
    */
    private com.tangosol.dev.component.Implementation __m_Implementation;
    
    // Initializing constructor
    public Editor(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/tabbedPanel/cDScript/Editor".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Apply script changes to the Component Definition.
    */
    public void apply()
        {
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Implementation;
        // import java.beans.PropertyVetoException;
        
        if (isApplying())
            {
            return;
            }
        
        $Script Script = ($Script) _findName("Script");
        String  sText  = Script.getText();
        
        Behavior       bhvr = getBehavior();
        Implementation impl = getImplementation();
        
        setApplying(true);
        try
            {
            if (impl == null)
                {
                if (bhvr != null && sText.trim().length() > 0)
                    {
                    setImplementation(
                        bhvr.addImplementation(0, "Java", sText));
                    }
                }
            else if (impl.getMode() != impl.INVALID && !isNeedUpdate())
                {
                if (sText.trim().length() == 0)
                    {
                    bhvr.removeImplementation(impl.getPosition());
                    }
                else
                    {
                    saveScriptConfig(impl);
        
                    impl.setScript(sText);
                    }
                }
            }
        catch (PropertyVetoException e)
            {
            _trace(e.getMessage(), 1); // should not happen
            }
        finally
            {
            setApplying(false);
            }
        
        if (bhvr != getBehavior() || impl != getImplementation())
            {
            // one of two things happened that forces us to reload script:
            // -- behavior has changed while we were applying the changes
            // (this could only happed when and implementation was removed
            // from the "Scripts" category)
            // -- implementation has changed while we were applying the changes
            // (this could happen if there was more then one implementation)
            updateScript();
            }
        }
    
    // Accessor for the property "Implementation"
    /**
    * Getter for property Implementation.<p>
    */
    public com.tangosol.dev.component.Implementation getImplementation()
        {
        return __m_Implementation;
        }
    
    // Declared at the super level
    /**
    * Getter for property ScriptCount.<p>
    * Total number of scripts to show.
    */
    public int getScriptCount()
        {
        // import com.tangosol.dev.component.Behavior;
        
        Behavior bhvr = getBehavior();
        
        return bhvr != null ? bhvr.getModifiableImplementationCount() : 0;
        }
    
    // Accessor for the property "Applying"
    /**
    * Getter for property Applying.<p>
    * Specifies whether the editor is in a process of applying the changes made
    * by the user
    */
    protected boolean isApplying()
        {
        return __m_Applying;
        }
    
    public void locateImplementation(_package.component.dev.util.traitLocator.componentLocator.behaviorLocator.ImplementationLocator locator)
        {
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Implementation;
        
        Behavior bhvr = getBehavior();
         
        int iImpl = locator.getImplementationPosition();
        if (iImpl < bhvr.getModifiableImplementationCount())
            {
            setImplementation(bhvr.getImplementation(iImpl));
        
            $Script Script = ($Script) _findName("Script");
        
            String sScript = Script.getText();
            int    iLine   = locator.getLine();
            int    ofPos   = locator.getOffset();
            int    nLength = locator.getLength();
        
            // make sure the tab is selected and Script has the focus
            moveToFront();
            Script.requestFocus();
        
            try
                {
                if (nLength >= 0)
                    {
                    int ofStart = Script.getLineStartOffset(iLine) + ofPos;
                    Script.select(ofStart, ofStart + nLength);
                    }
                else
                    {
                    Script.selectLine(iLine);
                    }
                }
            catch (Exception e)
                {
                // the selection coordinates are outdated
                // (i.e. user removed the offending text)
                _beep();
                }
            }
        }
    
    // Accessor for the property "Applying"
    /**
    * Setter for property Applying.<p>
    * Specifies whether the editor is in a process of applying the changes made
    * by the user
    */
    protected void setApplying(boolean pApplying)
        {
        __m_Applying = pApplying;
        }
    
    // Declared at the super level
    /**
    * Setter for property Behavior.<p>
    */
    public void setBehavior(com.tangosol.dev.component.Behavior pBehavior)
        {
        if (pBehavior == getBehavior())
            {
            // this is a update call
            updateHeader();
            setImplementation(getImplementation());
            return;
            }
        
        apply();
        
        setEnabled(pBehavior != null);
        
        super.setBehavior(pBehavior);
        }
    
    // Accessor for the property "Implementation"
    /**
    * Setter for property Implementation.<p>
    */
    public void setImplementation(com.tangosol.dev.component.Implementation pImplementation)
        {
        if (pImplementation == getImplementation())
            {
            // this is an update call
            updateScript();
            return;
            }
        
        apply();
        
        __m_Implementation = (pImplementation);
        
        setScriptPos(pImplementation == null ? -1 : pImplementation.getPosition());
        }
    
    // Declared at the super level
    /**
    * Setter for property ScriptPos.<p>
    * Current script position.
    */
    public void setScriptPos(int pScriptPos)
        {
        // import com.tangosol.dev.component.Behavior;
        
        if (!is_Constructed())
            {
            return;
            }
        
        super.setScriptPos(pScriptPos);
        
        Behavior bhvr = getBehavior();
        if (bhvr != null &&
            pScriptPos >= 0 && pScriptPos < getScriptCount())
            {
            setImplementation(bhvr.getImplementation(pScriptPos));
            }
        else
            {
            setImplementation(null);
            }
        }
    
    // Declared at the super level
    /**
    * Update the UI according to the Component Definition data.
    */
    protected void update()
        {
        // import com.tangosol.dev.component.Implementation;
        
        updateHeader();
        
        super.update(); // this sets up the Implementation property
        
        Implementation impl = getImplementation();
        if (impl != null)
            {
            applyScriptConfig(impl);
            }

        }
    
    /**
    * Update the header according to the Component Definition data.
    */
    protected void updateHeader()
        {
        $Header Header = ($Header) _findName("Header");
        Header.setText(getHeader(getBehavior()));

        }
    
    /**
    * Update the script editor according to the Component Definition data.
    */
    protected void updateScript()
        {
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Implementation;
        
        if (isApplying())
            {
            return;
            }
        
        $Script Script = ($Script) _findName("Script");
        $Lang   Lang   = ($Lang)   _findName("Lang");
        
        Behavior       bhvr = getBehavior();
        Implementation impl = getImplementation();
        
        boolean fEdit   = bhvr != null && bhvr.isModifiable();
        String  sScript = "";
        String  sLang   = "";
        
        if (impl != null)
            {
            sScript = impl.getScript();
            sLang   = impl.getLanguage();
            }
        
        Script.setEditable(fEdit);
        if (!Script.getText().equals(sScript))
            {
            // preserve the current cursor position and undo buffer if possible
            Script.setText(sScript);
            }
        
        Lang.setText(sLang);

        }
    }
