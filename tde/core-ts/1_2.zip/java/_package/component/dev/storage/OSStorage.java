/* Class
*     _package.component.dev.storage.OSStorage
*/

package _package.component.dev.storage;

import com.tangosol.dev.component.OSStorage; // as _OSStorage
import java.io.File;

public class OSStorage
        extends    _package.component.dev.Storage
    {
    // Fields declarations
    
    /**
    * Property RootDir
    *
    * Specifies the root directory path of this OSStorage.
    */
    private java.io.File __m_RootDir;
    
    // Default constructor
    public OSStorage()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public OSStorage(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new OSStorage();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/storage/OSStorage".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Returns the path that have to be added to the CLASSPATH (System property
    * "java.class.path") in order to be able to access classes managed by this
    * Storage. Subclasses should implement this method accordingly.
    */
    public String getClassPath()
        {
        // import java.io.File;
        
        // see com.tangosol.dev.component.OSStorage;
        return getRootDir().getAbsolutePath() + File.separatorChar + "classes";
        }
    
    // Declared at the super level
    public java.io.File getPackageDir()
        {
        return getRootDir();
        }
    
    // Accessor for the property "RootDir"
    public java.io.File getRootDir()
        {
        return __m_RootDir;
        }
    
    // Declared at the super level
    protected com.tangosol.dev.component.Storage instantiate_Storage()
        {
        // import com.tangosol.dev.component.OSStorage as _OSStorage;
        
        _assert(getRootDir() != null);
        
        return new _OSStorage(getRootDir());

        }
    
    // Accessor for the property "RootDir"
    public void setRootDir(java.io.File pRootDir)
        {
        __m_RootDir = (pRootDir);
        set_Storage(null);
        }
    }
