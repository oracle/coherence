/* Class
*     _package.component.dev.storage.ChainStorage
*/

package _package.component.dev.storage;

import _package.component.dev.Storage;
import com.tangosol.dev.component.ChainStorage; // as _ChainStorage
import java.io.File;

public class ChainStorage
        extends    _package.component.dev.Storage
    {
    // Fields declarations
    
    /**
    * Property Base
    *
    */
    private _package.component.dev.Storage __m_Base;
    
    /**
    * Property Delta
    *
    */
    private _package.component.dev.Storage __m_Delta;
    
    /**
    * Property Override
    *
    * Specifies whether or not the delta should "override" the base.
    * If this property is set to false, the delta will "modify" the base.
    */
    private boolean __m_Override;
    
    // Default constructor
    public ChainStorage()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ChainStorage(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setOverride(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ChainStorage();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/storage/ChainStorage".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Close this storage and releas all resources.
    * 
    * TODO: add this method to the Storage interface -- right now it's used by
    * JarStorage to release the jar file
    */
    public void close()
        {
        getBase().close();
        getDelta().close();
        super.close();
        }
    
    // Declared at the super level
    /**
    * Helper method collecting all the "Library" substorages for this storage
    * at the specified list.
    */
    public void collectLibraries(java.util.List list)
        {
        getBase() .collectLibraries(list);
        getDelta().collectLibraries(list);
         
        }
    
    // Accessor for the property "Base"
    /**
    * Getter for property Base.<p>
    */
    public _package.component.dev.Storage getBase()
        {
        return __m_Base;
        }
    
    // Declared at the super level
    /**
    * Returns the path that have to be added to the CLASSPATH (System property
    * "java.class.path") in order to be able to access classes managed by this
    * Storage. Subclasses should implement this method accordingly.
    */
    public String getClassPath()
        {
        // import java.io.File;
        
        return getDelta().getClassPath() + File.pathSeparatorChar +
               getBase() .getClassPath();
        }
    
    // Accessor for the property "Delta"
    /**
    * Getter for property Delta.<p>
    */
    public _package.component.dev.Storage getDelta()
        {
        return __m_Delta;
        }
    
    // Declared at the super level
    /**
    * Getter for property PackageDir.<p>
    * (Calculated) Specifies the directory to use by the packager to put the
    * produced packages
    */
    public java.io.File getPackageDir()
        {
        return getDelta().getPackageDir();
        }
    
    // Declared at the super level
    protected com.tangosol.dev.component.Storage instantiate_Storage()
        {
        // import com.tangosol.dev.component.ChainStorage as _ChainStorage;
        
        _assert(getBase () != null);
        _assert(getDelta() != null);
        
        return new _ChainStorage(
                getBase ().get_Storage(),
                getDelta().get_Storage(),
                isOverride());
        }
    
    // Accessor for the property "Override"
    /**
    * Getter for property Override.<p>
    * Specifies whether or not the delta should "override" the base.
    * If this property is set to false, the delta will "modify" the base.
    */
    public boolean isOverride()
        {
        return __m_Override;
        }
    
    // Declared at the super level
    /**
    * Getter for property ReadOnly.<p>
    * Specifies whether this storage is a read only.
    */
    public boolean isReadOnly()
        {
        return getDelta().isReadOnly();
        }
    
    // Declared at the super level
    /**
    * Walk the storage tree (right to left) and find a persistent storage (Jar
    * or OS) that has the specified locator
    * 
    * @param oLocator locator object to look for. If null then any persistent
    * storage should match
    * 
    * @return the Storage that has the locator matching the specified locator;
    * null if such a storage could not be found
    */
    public _package.component.dev.Storage locatePersistentStorage(Object oLocator)
        {
        // import Component.Dev.Storage;
        
        // right-to-left
        Storage storage = getDelta().locatePersistentStorage(oLocator);
        return storage == null ? getBase().locatePersistentStorage(oLocator) : storage;
        }
    
    // Accessor for the property "Base"
    /**
    * Setter for property Base.<p>
    */
    public void setBase(_package.component.dev.Storage pBase)
        {
        __m_Base = pBase;
        }
    
    // Accessor for the property "Delta"
    /**
    * Setter for property Delta.<p>
    */
    public void setDelta(_package.component.dev.Storage pDelta)
        {
        __m_Delta = pDelta;
        }
    
    // Accessor for the property "Override"
    /**
    * Setter for property Override.<p>
    * Specifies whether or not the delta should "override" the base.
    * If this property is set to false, the delta will "modify" the base.
    */
    public void setOverride(boolean pOverride)
        {
        __m_Override = pOverride;
        }
    }
