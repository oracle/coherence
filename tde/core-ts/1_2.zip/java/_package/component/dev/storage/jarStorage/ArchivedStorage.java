/* Class
*     _package.component.dev.storage.jarStorage.ArchivedStorage
*/

package _package.component.dev.storage.jarStorage;

import com.tangosol.dev.component.ArchivedStorage; // as _ArchivedStorage
import java.io.File;
import java.util.List;

public class ArchivedStorage
        extends    _package.component.dev.storage.JarStorage
    {
    // Fields declarations
    
    // Default constructor
    public ArchivedStorage()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ArchivedStorage(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ArchivedStorage();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/storage/jarStorage/ArchivedStorage".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Helper method collecting all the "Library" substorages for this storage
    * at the specified list.
    */
    public void collectLibraries(java.util.List list)
        {
        // import java.util.List;
        
        // do not call super
        return;
        }
    
    // Declared at the super level
    /**
    * Returns the path that have to be added to the CLASSPATH (System property
    * "java.class.path") in order to be able to access classes managed by this
    * Storage. Subclasses should implement this method accordingly.
    */
    public String getClassPath()
        {
        // usually there are no classes in ArchivedStorage
        // and it's not used by TestRun
        return "";
        }
    
    // Declared at the super level
    protected com.tangosol.dev.component.Storage instantiate_Storage()
        {
        // import com.tangosol.dev.component.ArchivedStorage as _ArchivedStorage;
        // import java.io.File;
        
        File fileJar = getJarFile();
        
        _assert(fileJar != null && fileJar.isFile(), "Not a file: " + fileJar);
        
        return new _ArchivedStorage(fileJar);

        }
    }
