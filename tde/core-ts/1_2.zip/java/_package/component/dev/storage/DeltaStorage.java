/* Class
*     _package.component.dev.storage.DeltaStorage
*/

package _package.component.dev.storage;

import com.tangosol.dev.component.CacheStorage;
import com.tangosol.dev.component.Extractor;
import com.tangosol.dev.component.Storage;

public class DeltaStorage
        extends    _package.component.dev.Storage
    {
    // Fields declarations
    
    /**
    * Property ActualStorage
    *
    */
    private _package.component.dev.Storage __m_ActualStorage;
    
    /**
    * Property Cache
    *
    */
    private boolean __m_Cache;
    
    // Default constructor
    public DeltaStorage()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public DeltaStorage(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setCache(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new DeltaStorage();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/storage/DeltaStorage".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Close this storage and releas all resources.
    * 
    * TODO: add this method to the Storage interface -- right now it's used by
    * JarStorage to release the jar file
    */
    public void close()
        {
        getActualStorage().close();
        super.close();
        }
    
    // Declared at the super level
    /**
    * Helper method collecting all the "Library" substorages for this storage
    * at the specified list.
    */
    public void collectLibraries(java.util.List list)
        {
        getActualStorage().collectLibraries(list);
        }
    
    // Accessor for the property "ActualStorage"
    /**
    * Getter for property ActualStorage.<p>
    */
    public _package.component.dev.Storage getActualStorage()
        {
        return __m_ActualStorage;
        }
    
    // Declared at the super level
    /**
    * Returns the path that have to be added to the CLASSPATH (System property
    * "java.class.path") in order to be able to access classes managed by this
    * Storage. Subclasses should implement this method accordingly.
    */
    public String getClassPath()
        {
        return getActualStorage().getClassPath();
        }
    
    // Declared at the super level
    /**
    * Getter for property PackageDir.<p>
    * (Calculated) Specifies the directory to use by the packager to put the
    * produced packages
    */
    public java.io.File getPackageDir()
        {
        return getActualStorage().getPackageDir();
        }
    
    // Declared at the super level
    protected com.tangosol.dev.component.Storage instantiate_Storage()
        {
        // import com.tangosol.dev.component.Storage;
        // import com.tangosol.dev.component.CacheStorage;
        // import com.tangosol.dev.component.Extractor;
        
        Storage store = getActualStorage();
        _assert(store != null);
        
        if (isCache())
            {
            store = new CacheStorage(store);
            }
        else
            {
            store = new Extractor(store);
            }
        return store;
        }
    
    // Accessor for the property "Cache"
    /**
    * Getter for property Cache.<p>
    */
    public boolean isCache()
        {
        return __m_Cache;
        }
    
    // Declared at the super level
    /**
    * Getter for property ReadOnly.<p>
    * Specifies whether this storage is a read only.
    */
    public boolean isReadOnly()
        {
        return getActualStorage().isReadOnly();
        }
    
    // Declared at the super level
    /**
    * Walk the storage tree (right to left) and find a persistent storage (Jar
    * or OS) that has the specified locator
    * 
    * @param oLocator locator object to look for. If null then any persistent
    * storage should match
    * 
    * @return the Storage that has the locator matching the specified locator;
    * null if such a storage could not be found
    */
    public _package.component.dev.Storage locatePersistentStorage(Object oLocator)
        {
        return getActualStorage().locatePersistentStorage(oLocator);
        }
    
    // Accessor for the property "ActualStorage"
    /**
    * Setter for property ActualStorage.<p>
    */
    public void setActualStorage(_package.component.dev.Storage pActualStorage)
        {
        if (pActualStorage != getActualStorage())
            {
            set_Storage(null);
            __m_ActualStorage = (pActualStorage);
            }
        }
    
    // Accessor for the property "Cache"
    /**
    * Setter for property Cache.<p>
    */
    public void setCache(boolean pCache)
        {
        if (pCache != isCache())
            {
            set_Storage(null);
            __m_Cache = (pCache);
            }
        }
    }
