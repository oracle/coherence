/* Class
*     _package.component.dev.storage.TAPSStorage
*/

package _package.component.dev.storage;

import _package.component.dev.Storage;
import _package.component.dev.project.ProjectInfo$Target; // as Target
import _package.component.dev.project.ProjectInfo; // as Project
import _package.component.dev.project.StorageFactory;
import com.tangosol.util.WrapperException;
import java.io.File;
import java.io.IOException;
import java.net.PasswordAuthentication;

public class TAPSStorage
        extends    _package.component.dev.Storage
    {
    // Fields declarations
    
    /**
    * Property History
    *
    * Helper property -- holds on a MRU list of the sever addresses
    */
    private String[] __m_History;
    
    /**
    * Property Password
    *
    */
    private char[] __m_Password;
    
    /**
    * Property Project
    *
    * Specifies the current project name (sometimes also referred to as a
    * "project domain")
    */
    private String __m_Project;
    
    /**
    * Property ProjectFactory
    *
    * Specifies the project factory used to open and create projects
    */
    private transient _package.component.dev.project.StorageFactory __m_ProjectFactory;
    
    /**
    * Property QualifiedProject
    *
    * Helper property specifying the fully qualified name of the project in the
    * following format:
    * <ProjectName> : <SubProjectName>
    */
    private String __m_QualifiedProject;
    
    /**
    * Property SavePassword
    *
    * Specifies whether we the password should be stored along with the
    * configuration
    */
    private boolean __m_SavePassword;
    
    /**
    * Property ServerUri
    *
    * Specifies the server URI
    */
    private String __m_ServerUri;
    
    /**
    * Property SubProject
    *
    * Specifies the current sub-project name (sometimes also referred to as
    * "project target")
    */
    private String __m_SubProject;
    
    /**
    * Property Target
    *
    * ProjectInfo$Target component describing the current sub-project (target)
    */
    private _package.component.dev.project.ProjectInfo$Target __m_Target;
    
    /**
    * Property User
    *
    * Current user name
    */
    private String __m_User;
    
    /**
    * Property Valid
    *
    * Checks whether this storage is valid
    */
    
    // Default constructor
    public TAPSStorage()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPSStorage(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new TAPSStorage();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/storage/TAPSStorage".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        String sAddress = config.getString(sPrefix + ".Address", "");
        setServerUri(sAddress);
        
        String sUser = config.getString(sPrefix + ".User", "");
        setUser(sUser);
        
        boolean fSavePwd = config.getBoolean(sPrefix + ".SavePassword");
        setSavePassword(fSavePwd);
        
        String sPassword = config.getString(sPrefix + ".Password", "");
        setPassword(sPassword.toCharArray());
        
        String sProject = config.getString(sPrefix + ".Project", "");
        setQualifiedProject(sProject);
        
        String[] asHistory = config.getStringArray(sPrefix + ".History", ' ');
        setHistory(asHistory);
        
        super.applyConfig(config, sPrefix);
        }
    
    // Declared at the super level
    /**
    * Close this storage and releas all resources.
    * 
    * TODO: add this method to the Storage interface -- right now it's used by
    * JarStorage to release the jar file
    */
    public void close()
        {
        // import Component.Dev.Storage;
        
        ((Storage) get_Storage()).close();
        super.close();
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof TAPSStorage)
            {
            TAPSStorage that = (TAPSStorage) obj;
        
            return this.getServerUri() .equals(that.getServerUri()) &&
                   this.getUser()      .equals(that.getUser())      &&
                   this.getProject()   .equals(that.getProject())   &&
                   this.getSubProject().equals(that.getSubProject());
            }
        return false;
        }
    
    // Declared at the super level
    /**
    * Returns the path that have to be added to the CLASSPATH (System property
    * "java.class.path") in order to be able to access classes managed by this
    * Storage. Subclasses should implement this method accordingly.
    */
    public String getClassPath()
        {
        // import Component.Dev.Storage;
        
        return ((Storage) get_Storage()).getClassPath();
        }
    
    // Accessor for the property "History"
    /**
    * Getter for property History.<p>
    * Helper property -- holds on a MRU list of the sever addresses
    */
    public String[] getHistory()
        {
        return __m_History;
        }
    
    // Accessor for the property "History"
    /**
    * Getter for property History.<p>
    * Helper property -- holds on a MRU list of the sever addresses
    */
    public String getHistory(int pIndex)
        {
        return getHistory()[pIndex];
        }
    
    // Declared at the super level
    /**
    * Getter for property PackageDir.<p>
    * (Calculated) Specifies the directory to use by the packager to put the
    * produced packages
    */
    public java.io.File getPackageDir()
        {
        // import Component.Dev.Storage;
        
        return ((Storage) get_Storage()).getPackageDir();
        }
    
    // Accessor for the property "Password"
    /**
    * Getter for property Password.<p>
    */
    public char[] getPassword()
        {
        return __m_Password;
        }
    
    // Accessor for the property "Project"
    /**
    * Getter for property Project.<p>
    * Specifies the current project name (sometimes also referred to as a
    * "project domain")
    */
    public String getProject()
        {
        return __m_Project;
        }
    
    // Accessor for the property "ProjectFactory"
    /**
    * Getter for property ProjectFactory.<p>
    * Specifies the project factory used to open and create projects
    */
    public _package.component.dev.project.StorageFactory getProjectFactory()
        {
        // import Component.Dev.Project.StorageFactory;
        // import java.io.IOException;
        
        StorageFactory factory = __m_ProjectFactory;
        if (factory == null)
            {
            try
                {
                factory = StorageFactory.
                    instantiate(getServerUri(), getUser(), getPassword());
        
                setProjectFactory(factory);
                }
            catch (IOException e)
                {
                _trace("Failed to instantiate storage factory: " + e);
                }
            }
        return factory;
        }
    
    // Accessor for the property "QualifiedProject"
    /**
    * Getter for property QualifiedProject.<p>
    * Helper property specifying the fully qualified name of the project in the
    * following format:
    * <ProjectName> : <SubProjectName>
    */
    public String getQualifiedProject()
        {
        String sProject    = getProject();
        String sSubProject = getSubProject();
        
        if (sSubProject != null && sSubProject.length() > 0)
            {
            sProject += ':' + sSubProject;
            }
        return sProject;
        }
    
    // Accessor for the property "ServerUri"
    /**
    * Getter for property ServerUri.<p>
    * Specifies the server URI
    */
    public String getServerUri()
        {
        return __m_ServerUri;
        }
    
    // Accessor for the property "SubProject"
    /**
    * Getter for property SubProject.<p>
    * Specifies the current sub-project name (sometimes also referred to as
    * "project target")
    */
    public String getSubProject()
        {
        return __m_SubProject;
        }
    
    // Accessor for the property "Target"
    /**
    * Getter for property Target.<p>
    * ProjectInfo$Target component describing the current sub-project (target)
    */
    public _package.component.dev.project.ProjectInfo$Target getTarget()
        {
        return __m_Target;
        }
    
    // Accessor for the property "User"
    /**
    * Getter for property User.<p>
    * Current user name
    */
    public String getUser()
        {
        return __m_User;
        }
    
    /**
    * Initializes this storage using the current environment settings.
    */
    public void initFromEnvironment()
        {
        // import java.io.File;
        
        String sUri = getServerUri();
        if (sUri == null || sUri.length() == 0)
            {
            File dirUser = new File(System.getProperty("user.dir", ""));
            File dirPrj  = new File(dirUser, "prj");
        
            if (!dirPrj.exists())
                {
                dirPrj = new File(dirUser.getParent(), "prj");
        
                if (!dirPrj.exists())
                    {
                    dirPrj = dirUser;
                    }
                }
        
            String sFile     = dirPrj.getAbsolutePath().replace('\\', '/');
            String sProtocol = "file:";
        
            if (!sFile.startsWith("/"))
                {
                sFile = "/" + sFile;
                }
            sUri = sProtocol + sFile;
            }
        
        String sUser = getUser();
        if (sUser == null || sUser.length() == 0)
            {
            sUser = "anonymous";
            }
        
        char[] acPwd = getPassword();
        String sPwd  = acPwd == null ? "" : new String(acPwd);
        
        String sPref = "tangosol.taps.";
        
        setServerUri       (System.getProperty(sPref + "repos"   , sUri));
        setUser            (System.getProperty(sPref + "user"    , sUser));
        setPassword        (System.getProperty(sPref + "password", sPwd).toCharArray());
        setQualifiedProject(System.getProperty(sPref + "prj"     , getQualifiedProject()));

        }
    
    // Declared at the super level
    protected com.tangosol.dev.component.Storage instantiate_Storage()
        {
        // import Component.Dev.Storage;
        // import Component.Dev.Project.ProjectInfo as Project;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Project.StorageFactory;
        // import com.tangosol.util.WrapperException;
        
        String         sProject = getProject();
        String         sTarget  = getSubProject();
        StorageFactory factory  = getProjectFactory();
        
        if (factory != null && sProject != null && sProject.length() > 0)
            {
            Project project = factory.loadProjectInfo(sProject);
            Target  target  = project == null ? null : project.getTarget(sTarget);
        
            if (target == null)
                {
                throw new RuntimeException("Fail to load project \"" +
                    sProject + ':' + sTarget + '"');
                }
        
            setQualifiedProject(target.getQualifiedName());        
            setTarget(target);
        
            return factory.getProjectStorage(getQualifiedProject());
            }
        return null;
        }
    
    // Declared at the super level
    /**
    * Getter for property ReadOnly.<p>
    * Specifies whether this storage is a read only.
    */
    public boolean isReadOnly()
        {
        return super.isReadOnly() || getTarget().isLocked();
        }
    
    // Accessor for the property "SavePassword"
    /**
    * Getter for property SavePassword.<p>
    * Specifies whether we the password should be stored along with the
    * configuration
    */
    public boolean isSavePassword()
        {
        return __m_SavePassword;
        }
    
    // Accessor for the property "Valid"
    /**
    * Getter for property Valid.<p>
    * Checks whether this storage is valid
    */
    public boolean isValid()
        {
        // import Component.Dev.Storage;
        
        Storage storage = null;
        try
            {
            storage = (Storage) get_Storage();
            }
        catch (Throwable e)
            {
            /*
            if (e instanceof WrapperException)
                {
                e = ((WrapperException) e).getOriginalException();
                }
            _trace("Invalid storage: " + e.toString(), 1);
            */
            }
        
        return storage != null;

        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        // import java.net.PasswordAuthentication;
        
        String sAddress = getServerUri();
        config.putString(sPrefix + ".Address", sAddress);
        
        String sUser = getUser();
        config.putString(sPrefix + ".User", sUser);
        
        boolean fSavePwd = isSavePassword();
        config.putBoolean(sPrefix + ".SavePassword", fSavePwd);
        
        if (fSavePwd)
            {
            char[] acPwd = getPassword();
            config.putString(sPrefix + ".Password",
                acPwd == null || acPwd.length == 0 ? null : new String(acPwd));
            }
        
        String sProject = getQualifiedProject();
        config.putString(sPrefix + ".Project", sProject);
        
        String[] asHistory = getHistory();
        config.putStringArray(sPrefix + ".History", asHistory, ' ');
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "History"
    /**
    * Setter for property History.<p>
    * Helper property -- holds on a MRU list of the sever addresses
    */
    public void setHistory(String[] pHistory)
        {
        __m_History = pHistory;
        }
    
    // Accessor for the property "History"
    /**
    * Setter for property History.<p>
    * Helper property -- holds on a MRU list of the sever addresses
    */
    public void setHistory(int pIndex, String pHistory)
        {
        getHistory()[pIndex] = pHistory;
        }
    
    // Accessor for the property "Password"
    /**
    * Setter for property Password.<p>
    */
    public void setPassword(char[] pPassword)
        {
        __m_Password = pPassword;
        }
    
    // Accessor for the property "Project"
    /**
    * Setter for property Project.<p>
    * Specifies the current project name (sometimes also referred to as a
    * "project domain")
    */
    public void setProject(String pProject)
        {
        __m_Project = (pProject);
        set_Storage(null);
        }
    
    // Accessor for the property "ProjectFactory"
    /**
    * Setter for property ProjectFactory.<p>
    * Specifies the project factory used to open and create projects
    */
    protected void setProjectFactory(_package.component.dev.project.StorageFactory pProjectFactory)
        {
        __m_ProjectFactory = pProjectFactory;
        }
    
    // Accessor for the property "QualifiedProject"
    /**
    * Setter for property QualifiedProject.<p>
    * Helper property specifying the fully qualified name of the project in the
    * following format:
    * <ProjectName> : <SubProjectName>
    */
    public void setQualifiedProject(String sProject)
        {
        int ofSub = sProject.indexOf(':');
        
        setProject   (ofSub < 0 ? sProject : sProject.substring(0, ofSub));
        setSubProject(ofSub < 0 ? ""       : sProject.substring(ofSub + 1));

        }
    
    // Accessor for the property "SavePassword"
    /**
    * Setter for property SavePassword.<p>
    * Specifies whether we the password should be stored along with the
    * configuration
    */
    public void setSavePassword(boolean pSavePassword)
        {
        __m_SavePassword = pSavePassword;
        }
    
    // Accessor for the property "ServerUri"
    /**
    * Setter for property ServerUri.<p>
    * Specifies the server URI
    */
    public void setServerUri(String pServerUri)
        {
        __m_ServerUri = (pServerUri);
        setProjectFactory(null);
        set_Storage(null);
        }
    
    // Accessor for the property "SubProject"
    /**
    * Setter for property SubProject.<p>
    * Specifies the current sub-project name (sometimes also referred to as
    * "project target")
    */
    public void setSubProject(String pSubProject)
        {
        __m_SubProject = (pSubProject);
        set_Storage(null);
        }
    
    // Accessor for the property "Target"
    /**
    * Setter for property Target.<p>
    * ProjectInfo$Target component describing the current sub-project (target)
    */
    public void setTarget(_package.component.dev.project.ProjectInfo$Target pTarget)
        {
        __m_Target = pTarget;
        }
    
    // Accessor for the property "User"
    /**
    * Setter for property User.<p>
    * Current user name
    */
    public void setUser(String pUser)
        {
        __m_User = (pUser);
        setProjectFactory(null);
        set_Storage(null);
        }
    
    // Declared at the super level
    public String toString()
        {
        return "TAPSStorage: Server=" + getServerUri() +
            " User=" + getUser() + " Project=" + getQualifiedProject() + "\n" + super.toString();
        }
    }
