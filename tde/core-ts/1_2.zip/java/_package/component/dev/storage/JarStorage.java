/* Class
*     _package.component.dev.storage.JarStorage
*/

package _package.component.dev.storage;

import com.tangosol.dev.component.JarStorage; // as _JarStorage
import com.tangosol.dev.component.WarStorage; // as _WarStorage
import java.io.File;

public class JarStorage
        extends    _package.component.dev.Storage
    {
    // Fields declarations
    
    /**
    * Property JarFile
    *
    * Specifies the path for the [wrapped] jar storage.
    */
    private java.io.File __m_JarFile;
    
    /**
    * Property RootPath
    *
    * Relative path within the JarFile to be used as a root path for this
    * Storage
    */
    private String __m_RootPath;
    
    // Default constructor
    public JarStorage()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JarStorage(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new JarStorage();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/storage/JarStorage".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Close this storage and releas all resources.
    * 
    * TODO: add this method to the Storage interface -- right now it's used by
    * JarStorage to release the jar file
    */
    public void close()
        {
        // import com.tangosol.dev.component.JarStorage as _JarStorage;
        try
            {
            ((_JarStorage) get_Storage()).close();
            }
        catch (Throwable e) {}

        }
    
    // Declared at the super level
    /**
    * Helper method collecting all the "Library" substorages for this storage
    * at the specified list.
    */
    public void collectLibraries(java.util.List list)
        {
        Object oLocator = getLocator();
        if (!list.contains(oLocator))
            {
            list.add(oLocator);
            }
        }
    
    // Declared at the super level
    /**
    * Returns the path that have to be added to the CLASSPATH (System property
    * "java.class.path") in order to be able to access classes managed by this
    * Storage. Subclasses should implement this method accordingly.
    */
    public String getClassPath()
        {
        return getJarFile().getAbsolutePath();
        }
    
    // Accessor for the property "JarFile"
    /**
    * Getter for property JarFile.<p>
    * Specifies the path for the [wrapped] jar storage.
    */
    public java.io.File getJarFile()
        {
        return __m_JarFile;
        }
    
    // Declared at the super level
    /**
    * Getter for property PackageDir.<p>
    * (Calculated) Specifies the directory to use by the packager to put the
    * produced packages
    */
    public java.io.File getPackageDir()
        {
        return getJarFile().getParentFile();
        }
    
    // Accessor for the property "RootPath"
    /**
    * Getter for property RootPath.<p>
    * Relative path within the JarFile to be used as a root path for this
    * Storage
    */
    public String getRootPath()
        {
        return __m_RootPath;
        }
    
    // Declared at the super level
    protected com.tangosol.dev.component.Storage instantiate_Storage()
        {
        // import com.tangosol.dev.component.JarStorage as _JarStorage;
        // import com.tangosol.dev.component.WarStorage as _WarStorage;
        // import java.io.File;
        
        File   fileJar = getJarFile();
        String sRoot   = getRootPath();
        
        _assert(fileJar != null && fileJar.isFile(), "Not a file: " + fileJar);
        
        if (fileJar.getPath().endsWith(".war") && sRoot.length() == 0)
            {
            return new _WarStorage(fileJar);
            }
        else if (sRoot.endsWith(".war"))
            {
            return new _WarStorage(fileJar, sRoot);
            }
        else
            {
            return new _JarStorage(fileJar, sRoot);
            }

        }
    
    // Declared at the super level
    /**
    * Getter for property ReadOnly.<p>
    * Specifies whether this storage is a read only.
    */
    public boolean isReadOnly()
        {
        return true;
        }
    
    // Accessor for the property "JarFile"
    /**
    * Setter for property JarFile.<p>
    * Specifies the path for the [wrapped] jar storage.
    */
    public void setJarFile(java.io.File pJarFile)
        {
        __m_JarFile = (pJarFile);
        set_Storage(null);
        }
    
    // Accessor for the property "RootPath"
    /**
    * Setter for property RootPath.<p>
    * Relative path within the JarFile to be used as a root path for this
    * Storage
    */
    public void setRootPath(String pRootPath)
        {
        __m_RootPath = (pRootPath);
        set_Storage(null);
        }
    }
