/* Class
*     _package.component.dev.service.TAPSLoader
*/

package _package.component.dev.service;

import _package.component.application.library.generic.TAPS;
import _package.component.dev.Storage;
import _package.component.dev.compiler.ClassGenerator;
import _package.component.dev.project.ProjectInfo$Target$Library; // as Library
import _package.component.dev.project.ProjectInfo$Target; // as Target
import _package.component.dev.storage.TAPSStorage;
import com.tangosol.dev.assembler.ClassFile$Relocator;
import com.tangosol.dev.assembler.ClassFile;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.ComponentType;
import com.tangosol.util.ErrorList;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

/**
* This component serves as a ClassLoader for the Tangosol  Server. It also
* implements a subset of Loader interface allowing it to be easily used by the
* ComponentClassLoader
* 
* @see com.tangosol.dev.component.ComponentClassLoader
* @see com.tangosol.taps.ClassPreprocessorWL60
* @see Component.Dev.Packager.Model#getClassLoader
*/
public class TAPSLoader
        extends    _package.component.dev.Service
        implements com.tangosol.dev.component.Loader
    {
    // Fields declarations
    
    /**
    * Property ErrorList
    *
    */
    private transient com.tangosol.util.ErrorList __m_ErrorList;
    
    /**
    * Property Libraries
    *
    * Hashtable of libraries "customized" by this project. The keys are the
    * canonical paths and the values are the "lastModified" timestamps.
    */
    private transient java.util.Hashtable __m_Libraries;
    
    /**
    * Property Storage
    *
    * Storage used to retrieve the Component Definitions
    */
    private transient _package.component.dev.Storage __m_Storage;
    
    /**
    * Property UpdateClassOnLoad
    *
    * If set to true, Java Classes should be updated during the "loadClass"
    * call with the design information stored as Java Class Signature
    * component; otherwise just use "loadOriginalClass" to get the result.
    */
    private boolean __m_UpdateClassOnLoad;
    
    /**
    * Property UpdateResourceOnLoad
    *
    * If set to true, Resources should be updated during the "loadResource"
    * call with the design information stored as ResourceSignature; otherwise
    * just use "loadOriginalResource" to get the result.
    */
    private boolean __m_UpdateResourceOnLoad;
    
    // Default constructor
    public TAPSLoader()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPSLoader(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setErrorList(new com.tangosol.util.ErrorList());
            setUpdateClassOnLoad(true);
            setUpdateResourceOnLoad(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        
        // state initialization: private properties
        try
            {
            __m_Libraries = new java.util.Hashtable(7);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new TAPSLoader();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/service/TAPSLoader".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Used by Application.get_Instance to create an instance of the correct
    * application.  This method is only called against the very first component
    * to be instantiated (an "entry point"), and only if it is not an
    * Application component. An entry point component can implement this method
    * if it knows what application should be instantiated.
    * 
    * @return an appropriate Application component, or null if this component
    * does not know what Application component should be instantiated
    * 
    * @see #_Reference
    */
    public _package.component.Application _makeApplication()
        {
        // import Component.Application.Library.Generic.TAPS;
        
        return (TAPS) TAPS.get_Instance();
        }
    
    public void configureStorage()
        {
        // import Component.Dev.Storage.TAPSStorage;
        // import java.util.Date;
        
        TAPSStorage storage = new TAPSStorage();
        storage.initFromEnvironment();
        
        String sMsg = "<" + new Date() + "> " + "<TangosolServer>";
        
        if (storage.isValid())
            {
            if (Boolean.getBoolean("tangosol.taps.verbose"))
                {
                _trace(sMsg + " Storage configured: " + storage);
                }
            }
        else
            {
            throw new RuntimeException(sMsg + " Failed to configure storage " + storage);
            }
        
        setStorage(storage);
        
        resetLibraries(storage);

        }
    
    // Accessor for the property "ErrorList"
    /**
    * Getter for property ErrorList.<p>
    */
    public com.tangosol.util.ErrorList getErrorList()
        {
        return __m_ErrorList;
        }
    
    // Accessor for the property "Libraries"
    /**
    * Getter for property Libraries.<p>
    * Hashtable of libraries "customized" by this project. The keys are the
    * canonical paths and the values are the "lastModified" timestamps.
    */
    private java.util.Hashtable getLibraries()
        {
        return __m_Libraries;
        }
    
    // Accessor for the property "Storage"
    /**
    * Getter for property Storage.<p>
    * Storage used to retrieve the Component Definitions
    */
    public _package.component.dev.Storage getStorage()
        {
        return __m_Storage;
        }
    
    // Accessor for the property "UpdateClassOnLoad"
    /**
    * Getter for property UpdateClassOnLoad.<p>
    * If set to true, Java Classes should be updated during the "loadClass"
    * call with the design information stored as Java Class Signature
    * component; otherwise just use "loadOriginalClass" to get the result.
    */
    public boolean isUpdateClassOnLoad()
        {
        return __m_UpdateClassOnLoad;
        }
    
    // Accessor for the property "UpdateResourceOnLoad"
    /**
    * Getter for property UpdateResourceOnLoad.<p>
    * If set to true, Resources should be updated during the "loadResource"
    * call with the design information stored as ResourceSignature; otherwise
    * just use "loadOriginalResource" to get the result.
    */
    public boolean isUpdateResourceOnLoad()
        {
        return __m_UpdateResourceOnLoad;
        }
    
    // From interface: com.tangosol.dev.component.Loader
    public com.tangosol.dev.assembler.ClassFile loadClass(String sName)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.ClassGenerator;
        // import Component.Dev.Storage;
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.dev.assembler.ClassFile$Relocator;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentType;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.util.ErrorList;
        
        Storage storage = getStorage();
        _assert(storage != null);
        
        ErrorList errList = getErrorList();
        errList.clear();
        
        try
            {
            ClassFile clsf     = storage.loadClass(sName);
            boolean   fCurrent = clsf != null; // TODO: use timestamps
        
            if (fCurrent)
                {
                return clsf;
                }
        
            String sRelocator = ClassFile$Relocator.PACKAGE.replace('/', '.');
        
            if (sName.startsWith(sRelocator))
                {
                String    sComponent = ComponentType.getComponentName(sName);
                String    sGlobal    = Component.getGlobalName(sComponent);
                Component cdGlobal   = storage.loadComponent(sGlobal, true, null);
        
                if (cdGlobal != null)
                    {
                    ClassGenerator gen = new ClassGenerator();
                    gen.setStorage(storage);
                    gen.setErrorList(errList);
                    gen.setGenerateListing(false);
                    gen.setCD(cdGlobal);
                    gen.setStoreResult(true); // could generate more than one class
                    gen.compile();
                    }
        
                return storage.loadClass(sName);
                }
            else
                {
                clsf = storage.loadOriginalClass(sName);
                if (clsf == null || clsf.isInterface() || !isUpdateClassOnLoad())
                    {
                    // - do nothing with interfaces
                    // - do nothing if UpdateClassOnLoad flag is not set
                    return clsf;
                    }
        
                updateClass(sName, clsf);
        
                return clsf;
                }
            }
        catch (ComponentException e)
            {
            errList.addException(e);
            throw e;
            }
        finally
            {
            if (errList.isSevere())
                {
                _trace(errList.toString());
                }
            }
        }
    
    // From interface: com.tangosol.dev.component.Loader
    public com.tangosol.dev.component.Component loadComponent(String sName, boolean fReadOnly, com.tangosol.util.ErrorList errlist)
            throws com.tangosol.dev.component.ComponentException
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.dev.component.Loader
    public String loadJava(String sName)
            throws java.io.IOException
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.dev.component.Loader
    public com.tangosol.dev.assembler.ClassFile loadOriginalClass(String sName)
            throws com.tangosol.dev.component.ComponentException
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.dev.component.Loader
    public byte[] loadOriginalResource(String sName)
            throws java.io.IOException
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.dev.component.Loader
    public byte[] loadResource(String sName)
            throws java.io.IOException
        {
        // import Component.Dev.Storage;
        // import java.io.IOException;
        
        Storage storage = getStorage();
        _assert(storage != null);
        
        byte[] abResource;
        if (isUpdateResourceOnLoad())
            {
            abResource = storage.loadResource(sName);
        
            boolean fCurrent = abResource != null;
            if (!fCurrent)
                {
                byte[] abResSig = storage.loadResourceSignature(sName);
                
                // TODO: merge
                abResource = abResSig;
                }
            }
        else
            {
            abResource = storage.loadOriginalResource(sName);
            }
        return abResource;
        }
    
    // From interface: com.tangosol.dev.component.Loader
    public byte[] loadResourceSignature(String sName)
            throws java.io.IOException
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.dev.component.Loader
    public com.tangosol.dev.component.Component loadSignature(String sName)
            throws com.tangosol.dev.component.ComponentException
        {
        throw new UnsupportedOperationException();
        }
    
    /**
    * Process the class with the specified name and java byte code according to
    * the customization data in the current project storage
    * 
    * @param sClassName  the class name
    * @param abCode  the java byte code for the class
    * 
    * @return the new byte code for the class reflecting the current
    * customization data
    * 
    * @see com.tangosol.taps.ClassPreprocessorWL60#preProcess
    */
    public byte[] processClass(String sClassName, byte[] abCode)
        {
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.util.ErrorList;
        // import java.util.Date;
        
        ErrorList errList = getErrorList();
        errList.clear();
        
        validateStorage();
        
        boolean fVerbose = Boolean.getBoolean("tangosol.taps.verbose");
        String  sMsg     = "<" + new Date() + "> " + "<TangosolServer>" +
                           " Requested to process " + sClassName;
        try
            {
            ClassFile clsf = new ClassFile(abCode);
            if (clsf.isInterface())
                {
                // do nothing with interfaces
                // (usually we are not even called)
                return abCode;
                }
        
            if (updateClass(sClassName, clsf))
                {
                if (fVerbose)
                    {
                    _trace(sMsg + " success");
                    }
                // ignore info and warnings...
                return clsf.getBytes();
                }
            else
                {
                sMsg += " no customization";
                }
            }
        catch (Throwable e)
            {
            errList.addException(e);
            if (fVerbose)
                {
                _trace(e);
                }
            }
        
        if (errList.isSevere() || fVerbose)
            {
            _trace(sMsg);
            if (!errList.isEmpty())
                {
                _trace(errList.toString());
                }
            }
        
        return abCode;
        }
    
    /**
    * Fills the table of timestamps for all the libraries in this project.
    */
    private void resetLibraries(_package.component.dev.storage.TAPSStorage storage)
        {
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Project.ProjectInfo$Target$Library as Library;
        // import Component.Dev.Storage.TAPSStorage;
        // import java.io.File;
        // import java.io.IOException;
        // import java.util.Hashtable;
        // import java.util.Iterator;
        
        Target      target  = storage.getTarget();
        Hashtable   tblLibs = getLibraries();
        
        tblLibs.clear();
        
        for (Iterator iter = target.getLibraryList().values().iterator(); iter.hasNext();)
            {
            Library lib = (Library) iter.next();
        
            String  sPath = lib.getStorageInfo().getSafeElement("Location").getString();
            boolean fCopy = lib.getStorageInfo().getSafeElement("UseCopy").getBoolean();
        
            int ofPath = sPath.indexOf('!');
            if (ofPath != -1)
                {
                sPath = sPath.substring(0, ofPath);
                }
        
            if (fCopy)
                {
                try
                    {
                    File fileLib = new File(sPath);
                    if (!fileLib.isAbsolute())
                        {
                        String sPrjRoot = target.getProjectInfo().getStorageInfo().
                            getSafeElement("Location").getString();
                        fileLib = new File(sPrjRoot, sPath);
                        }
        
                    if (fileLib.exists())
                        {
                        tblLibs.put(fileLib.getCanonicalPath(),
                            new Long(fileLib.lastModified()));
                        }
                    }
                catch (Exception e)
                    {
                    }
                }
            }

        }
    
    // Accessor for the property "ErrorList"
    /**
    * Setter for property ErrorList.<p>
    */
    public void setErrorList(com.tangosol.util.ErrorList pErrorList)
        {
        __m_ErrorList = pErrorList;
        }
    
    // Accessor for the property "Libraries"
    /**
    * Setter for property Libraries.<p>
    * Hashtable of libraries "customized" by this project. The keys are the
    * canonical paths and the values are the "lastModified" timestamps.
    */
    private void setLibraries(java.util.Hashtable pLibraries)
        {
        __m_Libraries = pLibraries;
        }
    
    // Accessor for the property "Storage"
    /**
    * Setter for property Storage.<p>
    * Storage used to retrieve the Component Definitions
    */
    public void setStorage(_package.component.dev.Storage pStorage)
        {
        __m_Storage = pStorage;
        }
    
    // Accessor for the property "UpdateClassOnLoad"
    /**
    * Setter for property UpdateClassOnLoad.<p>
    * If set to true, Java Classes should be updated during the "loadClass"
    * call with the design information stored as Java Class Signature
    * component; otherwise just use "loadOriginalClass" to get the result.
    */
    public void setUpdateClassOnLoad(boolean pUpdateClassOnLoad)
        {
        __m_UpdateClassOnLoad = pUpdateClassOnLoad;
        }
    
    // Accessor for the property "UpdateResourceOnLoad"
    /**
    * Setter for property UpdateResourceOnLoad.<p>
    * If set to true, Resources should be updated during the "loadResource"
    * call with the design information stored as ResourceSignature; otherwise
    * just use "loadOriginalResource" to get the result.
    */
    public void setUpdateResourceOnLoad(boolean pUpdateResourceOnLoad)
        {
        __m_UpdateResourceOnLoad = pUpdateResourceOnLoad;
        }
    
    /**
    * Process the class with the specified name and ClassFile according to the
    * customization data in the current project storage
    * 
    * @param sClassName  the class name
    * @param clsf  the ClassFile object to be customized
    * 
    * @return true if there was any customization data; false otherwise
    * 
    * @exception ComponentException thrown if an unrecoverable error ocuurs
    */
    protected boolean updateClass(String sClassName, com.tangosol.dev.assembler.ClassFile clsf)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.ClassGenerator;
        // import Component.Dev.Storage;
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.util.ErrorList;
        // import java.util.Date;
        
        Storage storage = getStorage();
        _assert(storage != null);
        
        ErrorList errList = getErrorList();
        
        Component cdJCS = null;
        try
            {
            cdJCS = storage.loadComponent(sClassName, true, null);
            }
        catch (ComponentException e)
            {
            // ignore any problem while loading the component
            // (i.e. the super cannot be loaded)
            errList.addWarning("Error loading: " + sClassName + " -- " + e.getMessage());
            }
        
        if (cdJCS == null)
            {
            // the class is not known to the storage or could not be loaded
            // (i.e. a transient class representing a jsp page)
            // let's try to customize any interface methods
            cdJCS = new Component(clsf);
        
            Component cdSuper = null;
            String    sSuper  = cdJCS.getSuperName();
            try
                {
                cdSuper = storage.loadSignature(sSuper);
                }
            catch (ComponentException e)
                {
                errList.addWarning("Error loading super: " + sSuper + " -- " + e.getMessage());
                }
        
            if (cdSuper == null)
                {
                // super not known -- use at least the java.lang.Object
                cdSuper = storage.loadSignature("java.lang.Object");
                if (cdSuper == null)
                    {
                    throw new IllegalStateException("Failed to load java.lang.Object");
                    }
                }
        
            cdJCS = cdSuper.resolve(cdJCS, storage, errList);
        
            cdJCS.finalizeResolve(storage, errList);
            }
        
        ClassGenerator gen = new ClassGenerator();
        
        gen.setCD(cdJCS);
        gen.setClassFile(clsf);
        gen.setStorage(storage);
        gen.setErrorList(errList);
        gen.setGenerateListing(false);
        gen.setStoreResult(false);
        
        return gen.updateClass();
        }
    
    /**
    * Check whether or not the libraries were updated (touched) since the
    * storage used by the loader has been configured. 
    * If so,  the storage will be reconfigured as well
    */
    private void validateStorage()
        {
        // import java.io.File;
        // import java.util.Hashtable;
        // import java.util.Enumeration;
        
        Hashtable tblLib = getLibraries();
        
        for (Enumeration enum = tblLib.keys(); enum.hasMoreElements();)
            {
            String sPath = (String) enum.nextElement();
            Long   LTime = (Long) tblLib.get(sPath);
            File   file  = new File(sPath);
        
            if (!file.exists() || file.lastModified() > LTime.longValue())
                {
                configureStorage();
                return;
                }
            }
        }
    }
