/* Class
*     _package.component.dev.compiler.script.info.MethodInfo
*/

package _package.component.dev.compiler.script.info;

import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.InterfaceConstant;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.assembler.SignatureConstant;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.Constants;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Parameter;
import com.tangosol.dev.component.Property;
import com.tangosol.dev.component.Throwee;
import com.tangosol.util.NullImplementation;
import java.util.Vector;

public class MethodInfo
        extends    _package.component.dev.compiler.script.Info
        implements com.tangosol.dev.compiler.MethodInfo
    {
    // Fields declarations
    
    /**
    * Property Behavior
    *
    */
    private transient com.tangosol.dev.component.Behavior __m_Behavior;
    
    /**
    * Property FieldConstant
    *
    */
    
    /**
    * Property FieldInfo
    *
    */
    
    /**
    * Property Inlineable
    *
    */
    
    /**
    * Property Inlined
    *
    */
    
    /**
    * Property MethodConstant
    *
    */
    private transient com.tangosol.dev.assembler.MethodConstant __m_MethodConstant;
    
    /**
    * Property ParamCount
    *
    */
    
    /**
    * Property ParamInfo
    *
    */
    
    /**
    * Property ParamTypes
    *
    */
    private transient com.tangosol.dev.component.DataType[] __m_ParamTypes;
    
    /**
    * Property TypeInfo
    *
    */
    
    // Default constructor
    public MethodInfo()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public MethodInfo(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new MethodInfo();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/info/MethodInfo".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public void addDependency(boolean fRuntime, int iStartLine, int ofStart, int iEndLine, int ofEnd)
            throws com.tangosol.dev.compiler.CompilerException
        {
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Property;
        
        // don't register compile-dependencies on the current component
        if (fRuntime || !getTypeInfo().equals(getContext().getMethodInfo().getTypeInfo()))
            {
            super.addDependency(fRuntime, iStartLine, ofStart, iEndLine, ofEnd);
                
            // register dependency on property if this is an accessor
            Behavior  behavior = getBehavior();
            Component cd       = behavior.getComponent();
            String    sProp    = behavior.getPropertyName();
            if (cd.isComponent() && sProp != null)
                {
                getTypeInfo().getFieldInfo(sProp).addDependency
                        (fRuntime, iStartLine, ofStart, iEndLine, ofEnd);
                }
            }

        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    public java.util.Enumeration exceptionTypes()
        {
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Throwee;
        // import com.tangosol.util.NullImplementation;
        // import java.util.Vector;
        
        // clone() on array throws no checked exceptions
        if (getTypeInfo().getDataType().isArray() && getName().equals("clone"))
            {
            return NullImplementation.getEnumeration();
            }
        
        Behavior beh      = getBehavior();
        String[] asExcept = beh.getExceptionNames();
        int      cExcepts = asExcept.length;
        if (cExcepts == 0)
            {
            return NullImplementation.getEnumeration();
            }
        
        Vector vect = new Vector();
        for (int i = 0; i < cExcepts; ++i)
            {
            Throwee throwee = beh.getException(asExcept[i]);
            if (throwee != null)
                {
                vect.add(throwee.getDataType());
                }
            }
        
        return vect.elements();
        }
    
    // Accessor for the property "Behavior"
    public com.tangosol.dev.component.Behavior getBehavior()
        {
        return __m_Behavior;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public com.tangosol.dev.assembler.Constant getConstant()
        {
        return getMethodConstant();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public com.tangosol.dev.component.DataType getDataType()
        {
        return getBehavior().getReturnValue().getDataType();
        }
    
    // Accessor for the property "FieldConstant"
    public com.tangosol.dev.assembler.FieldConstant getFieldConstant()
        {
        return getContext().inlineMethod(getTypeInfo().getDataType(),
                getDataType(), getName(), getParamTypes());
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "FieldInfo"
    public com.tangosol.dev.compiler.FieldInfo getFieldInfo()
        {
        // TODO: if the class generator can ever replace method calls with field
        // access, this would have to be implemented (note that property accessors
        // that map to fields are handled by the Synthetic.MethodInfo component)
        return null;
        }
    
    // Accessor for the property "MethodConstant"
    public com.tangosol.dev.assembler.MethodConstant getMethodConstant()
        {
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.InterfaceConstant;
        // import com.tangosol.dev.assembler.SignatureConstant;
        
        MethodConstant constant = __m_MethodConstant;
        
        if (constant == null)
            {
            constant = getContext().resolveMethod(getTypeInfo().getDataType(),
                    getDataType(), getName(), getParamTypes());
            _assert(constant != null, "Failed to resolve " + getBehavior() +
                " at " + getTypeInfo().getDataType());
        
            setMethodConstant(constant);
            }
        
        return constant;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public String getName()
        {
        return getBehavior().getName();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "ParamCount"
    public int getParamCount()
        {
        return getBehavior().getParameterCount();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "ParamInfo"
    public com.tangosol.dev.compiler.ParamInfo getParamInfo(int i)
        {
        // import com.tangosol.dev.component.Parameter;
        
        // check if parameter index is out of range
        if (i < 0 || i >= getParamCount())
            {
            return null;
            }
        
        // check if the method info is in the cache
        final String sLocalID = "P_" + i;
        ParamInfo info = (ParamInfo) _findChild(sLocalID);
        if (info != null)
            {
            return info;
            }
        
        // get parameter
        Parameter param = getBehavior().getParameter(i);
        _assert(param != null);
        
        // create new parameter info
        info = new ParamInfo();
        info.setContext(getContext());
        info.setParameter(param);
        
        // add the parameter info to the cache
        _addChild(info, sLocalID);
        
        return info;
        }
    
    // Accessor for the property "ParamTypes"
    public com.tangosol.dev.component.DataType[] getParamTypes()
        {
        // import com.tangosol.dev.component.DataType;
        
        DataType[] adt = __m_ParamTypes;
        
        if (adt == null)
            {
            int cdt = getParamCount();
            adt = new DataType [cdt];
            for (int i = 0; i < cdt; ++i)
                {
                adt[i] = getParamInfo(i).getDataType();
                }
        
            setParamTypes(adt);
            }
        
        return adt;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "TypeInfo"
    public com.tangosol.dev.compiler.TypeInfo getTypeInfo()
        {
        return (TypeInfo) get_Parent();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isAbstract()
        {
        return getBehavior().isAbstract();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isAccessible()
        {
        // import com.tangosol.dev.component.DataType;
        
        // public methods are always accessible
        // (note:  interfaces methods are always public)
        if (isPublic())
            {
            return true;
            }
        
        TypeInfo infoThis    = (TypeInfo) getTypeInfo();
        TypeInfo infoContext = (TypeInfo) getContext().getMethodInfo().getTypeInfo();
        
        // all members are accessible on the declaring class
        if (infoThis == infoContext)
            {
            return true;
            }
        
        /****************************************************************************
        * 1999.09.07 cp  the following would allow a derived class D to call a protected
        *                method against any object of the base class B; this code is not
        *                necessary to call protected methods against objects of class D
        *                (including "this") from class D
        if (isProtected())
            {
            // the script compilation context is always from a component
            // so the protected method must be on either a super component
            // or on java.lang.Object
            DataType dtThis    = infoThis   .getDataType();
            DataType dtContext = infoContext.getDataType();
            _assert(dtContext.isComponent());
        
            return dtThis == DataType.OBJECT || dtThis.isComponent() &&
                infoContext.getCD().isDerivedFrom(infoThis.getCD());
            }
        ****************************************************************************/
        
        // allow super call to protected methods
        // note:  no way to know the difference between the following:
        //      super.foo()
        //      ((BaseClass) that).foo()
        if (isProtected() && this.equals(getContext().getSuperInfo()))
            {
            return true;
            }
        
        return false;
        }
    
    // Declared at the super level
    public boolean isDeprecated()
        {
        return getBehavior().isDeprecated();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isFinal()
        {
        return getBehavior().isFinal();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "Inlineable"
    public boolean isInlineable()
        {
        
        // inlineable if a field constant is available
        return getFieldConstant() != null;

        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "Inlined"
    public boolean isInlined()
        {
        
        // at this point, the methods will always exist; when they are optimized out,
        // the method info can tell because the method constant resolves to null
        return getMethodConstant() == null;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isPackage()
        {
        // import com.tangosol.dev.component.Constants;
        
        return getBehavior().getAccess() == Constants.ACCESS_PACKAGE;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isPrivate()
        {
        // import com.tangosol.dev.component.Constants;
        // import com.tangosol.dev.component.Behavior;
        
        // get_Module() is private, although "declared" protected final
        Behavior beh = getBehavior();
        if (beh.getComponent().isComponent() && beh.getSignature().equals("get_Module()"))
            {
            return true;
            }
        
        return beh.getAccess() == Constants.ACCESS_PRIVATE;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isProtected()
        {
        // import com.tangosol.dev.component.Constants;
        // import com.tangosol.dev.component.Behavior;
        
        // get_Module() is private, although "declared" protected final
        Behavior beh = getBehavior();
        if (beh.getComponent().isComponent() && beh.getSignature().equals("get_Module()"))
            {
            return false;
            }
        
        // clone() on an array is public, although "declared" protected
        if (getTypeInfo().getDataType().isArray() && getName().equals("clone"))
            {
            return false;
            }
        
        return beh.getAccess() == Constants.ACCESS_PROTECTED;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isPublic()
        {
        // import com.tangosol.dev.component.Constants;
        
        // clone() on an array is public, although "declared" protected
        if (getTypeInfo().getDataType().isArray() && getName().equals("clone"))
            {
            return true;
            }
        
        return getBehavior().getAccess() == Constants.ACCESS_PUBLIC;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isStatic()
        {
        return getBehavior().isStatic();
        }
    
    // Accessor for the property "Behavior"
    public void setBehavior(com.tangosol.dev.component.Behavior pBehavior)
        {
        __m_Behavior = pBehavior;
        }
    
    // Accessor for the property "MethodConstant"
    public void setMethodConstant(com.tangosol.dev.assembler.MethodConstant pMethodConstant)
        {
        __m_MethodConstant = pMethodConstant;
        }
    
    // Accessor for the property "ParamTypes"
    public void setParamTypes(com.tangosol.dev.component.DataType[] pParamTypes)
        {
        __m_ParamTypes = pParamTypes;
        }
    
    // Declared at the super level
    public String toString()
        {
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        
        Behavior  beh = getBehavior();
        Component cd  = beh.getComponent();
        return cd.getName() + '.' + beh.getName() + "()";
        }
    }
