/* Class
*     _package.component.dev.compiler.script.info.TypeInfo
*/

package _package.component.dev.compiler.script.info;

import _package.component.dev.compiler.script.Context;
import _package.component.dev.compiler.script.info.synthetic.Accessor;
import _package.component.dev.compiler.script.info.synthetic.Constructor;
import _package.component.dev.compiler.script.info.synthetic.Index;
import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.Constants;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Property;
import com.tangosol.util.FilterEnumerator;
import com.tangosol.util.IteratorEnumerator;
import com.tangosol.util.NullFilter;
import com.tangosol.util.NullImplementation;
import com.tangosol.util.SimpleEnumerator;
import java.util.Enumeration;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

public class TypeInfo
        extends    _package.component.dev.compiler.script.Info
        implements com.tangosol.dev.compiler.TypeInfo
    {
    // Fields declarations
    
    /**
    * Property CD
    *
    */
    private transient com.tangosol.dev.component.Component __m_CD;
    
    /**
    * Property ClassConstant
    *
    */
    private transient com.tangosol.dev.assembler.ClassConstant __m_ClassConstant;
    
    /**
    * Property ParentInfo
    *
    */
    
    /**
    * Property SuperInfo
    *
    */
    
    /**
    * Property Throwable
    *
    */
    
    // Default constructor
    public TypeInfo()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TypeInfo(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new TypeInfo();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/info/TypeInfo".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Declared at the super level
    public void addDependency(boolean fRuntime, int iStartLine, int ofStart, int iEndLine, int ofEnd)
            throws com.tangosol.dev.compiler.CompilerException
        {
        // don't register self-dependencies
        if (!equals(getContext().getMethodInfo().getTypeInfo()))
            {
            super.addDependency(fRuntime, iStartLine, ofStart, iEndLine, ofEnd);
            }
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    public java.util.Enumeration childNames()
        {
        // import com.tangosol.util.FilterEnumerator;
        // import com.tangosol.util.NullFilter;
        // import com.tangosol.util.NullImplementation;
        // import com.tangosol.util.SimpleEnumerator;
        // import java.util.Enumeration;
        
        com.tangosol.dev.component.Component cd = getCD();
        
        if (cd.isComponent())
            {
            String[] asChild = cd.getChildren();
            int      cChilds = asChild.length;
        
            // check for removed children
            boolean fRemoved = false;
            for (int i = 0; i < cChilds; ++i)
                {
                if (cd.getChild(asChild[i]) == null)
                    {
                    asChild[i] = null;
                    fRemoved = true;
                    }
                }
        
            Enumeration enum = new SimpleEnumerator(asChild);
            if (fRemoved)
                {
                enum = new FilterEnumerator(enum, NullFilter.getInstance());
                }
            return enum;
            }
        else
            {
            return NullImplementation.getEnumeration();
            }
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    public java.util.Enumeration fieldNames()
        {
        // import com.tangosol.util.SimpleEnumerator;
        
        String[] asFields = getCD().getProperty();
        return new SimpleEnumerator(asFields);
        }
    
    // Accessor for the property "CD"
    public com.tangosol.dev.component.Component getCD()
        {
        return __m_CD;
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    public com.tangosol.dev.compiler.TypeInfo getChildInfo(String sChild)
        {
        
        // check if child info is in cache
        final String sLocalID = "C_" + sChild;
        TypeInfo info = (TypeInfo) _findChild(sLocalID);
        if (info != null)
            {
            return info;
            }
        
        // only components have children
        com.tangosol.dev.component.Component cd = getCD();
        if (!cd.isComponent())
            {
            return null;
            }
        
        // check if child exists
        com.tangosol.dev.component.Component cdChild = cd.getChild(sChild);
        if (cdChild == null)
            {
            return null;
            }
        
        // create new child info for the child
        info = new TypeInfo();
        info.setContext(getContext());
        info.setCD(cdChild);
        
        // add the child to the cache
        _addChild(info, sLocalID);
        
        return info;
        }
    
    // Accessor for the property "ClassConstant"
    public com.tangosol.dev.assembler.ClassConstant getClassConstant()
        {
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.component.DataType;
        
        ClassConstant constant = __m_ClassConstant;
        
        if (constant == null)
            {
            DataType dt = getDataType();
            // to support children being optimized out, ask the context what
            // the real class constant is
            // constant = dt.getClassConstant();
            constant = getContext().resolveClass(dt);
            setClassConstant(constant);
            }
        
        return constant;
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Declared at the super level
    public com.tangosol.dev.assembler.Constant getConstant()
        {
        return getClassConstant();
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Declared at the super level
    public com.tangosol.dev.component.DataType getDataType()
        {
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.DataType;
        
        Component cd = getCD();
        
        if (cd.isComponent())
            {
            // component type
            return DataType.getComponentType(cd.getQualifiedName());
            }
        
        // class type
        return DataType.getClassType(cd.getName());
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    public com.tangosol.dev.compiler.FieldInfo getFieldInfo(String sField)
        {
        // import com.tangosol.dev.component.Property;
        
        // check if the field info is in the cache
        final String sLocalID = "F_" + sField.replace('$', '~');
        FieldInfo info = (FieldInfo) _findChild(sLocalID);
        if (info != null)
            {
            return info;
            }
        
        // check if field/property exists
        Property  prop = getCD().getProperty(sField);
        if (prop == null)
            {
            return null;
            }
        
        // create new field info for the field/property
        info = new FieldInfo();
        info.setContext(getContext());
        info.setProperty(prop);
        
        // add the field info to the cache
        _addChild(info, sLocalID);
        
        return info;
        }
    
    public com.tangosol.dev.compiler.MethodInfo getMethodInfo(com.tangosol.dev.component.Behavior beh)
        {
        // import com.tangosol.dev.component.Behavior;
        
        final String sLocalID = "M_" + beh.getSignature().replace('$', '~');
        
        // check if the method info is in the cache
        com.tangosol.dev.compiler.MethodInfo info =
                (com.tangosol.dev.compiler.MethodInfo) _findChild(sLocalID);
        if (info != null)
            {
            return info;
            }
        
        // create new method info for the method/behavior
        MethodInfo method = new MethodInfo();
        method.setContext(getContext());
        method.setBehavior(beh);
        
        // add the method info to the cache
        _addChild(method, sLocalID);
        
        return method;
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    public com.tangosol.dev.compiler.MethodInfo getMethodInfo(String sMethod, com.tangosol.dev.component.DataType[] adtParam)
        {
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.DataType;
        // import Component.Dev.Compiler.Script.Info.Synthetic.Constructor;
        // import Component.Dev.Compiler.Script.Info.Synthetic.Accessor;
        // import Component.Dev.Compiler.Script.Info.Synthetic.Index;
        
        // check if the method info is in the cache
        final String sSig     = Behavior.getSignature(sMethod, adtParam);
        final String sLocalID = "M_" + sSig.replace('$', '~');
        com.tangosol.dev.compiler.MethodInfo info =
                (com.tangosol.dev.compiler.MethodInfo) _findChild(sLocalID);
        if (info != null)
            {
            return info;
            }
        
        // components have a default (0-parameter) constructor
        Component cd = getCD();
        final String CONSTRUCTOR = com.tangosol.dev.assembler.Constants.CONSTRUCTOR_NAME;
        if (cd.isComponent() && sMethod.equals(CONSTRUCTOR) && adtParam.length == 0)
            {
            Constructor constructor = new Constructor();
            constructor.setContext(getContext());
        
            // add the method info to the cache
            _addChild(constructor, sLocalID);
        
            return constructor;
            }
        
        // check if it is a virtual property accessor
        if (cd.isComponent() && adtParam.length <= 1 &&
                (sMethod.charAt(0) == 'g' || sMethod.charAt(0) == 'i'))
            {
            String sName = Property.getPropertyName(sSig);
            if (sName != null)
                {
                Property prop = cd.getProperty(sName);
                if (prop != null && prop.isVirtualConstant())
                    {
                    Accessor method = null;
        
                    // two potential cases:
                    // (1) not indexed-only means there is a no-param accessor
                    if (prop.getIndexed() != prop.PROP_INDEXEDONLY
                            && adtParam.length == 0)
                        {
                        method = new Accessor();
                        }
                    // (2) not single means there is an indexed accessor
                    else if (!prop.isSingle() && adtParam.length == 1
                            && adtParam[0] == DataType.INT)
                        {
                        method = new Accessor();
                        method.setParameter(new Index());
                        }
        
                    if (method != null)
                        {
                        // finish configuring the method
                        method.setContext(getContext());
                        method.setProperty(prop);
        
                        // add the method info to the cache
                        _addChild(method, sLocalID);
        
                        return method;
                        }
                    }
                }
            }
        
        // check if method/behavior exists
        Behavior beh = cd.getBehavior(sSig);
        
        return beh == null ? null : getMethodInfo(beh);
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Declared at the super level
    public String getName()
        {
        // import com.tangosol.dev.component.Component;
        
        Component cd = getCD();
        
        if (cd.isComponent())
            {
            return cd.getName();
            }
        else
            {
            String sName = cd.getName();
            int    ofDot = sName.lastIndexOf('.');
            return ofDot < 0 ? sName : sName.substring(ofDot + 1);
            }
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    public com.tangosol.dev.compiler.PackageInfo getPackageInfo()
        {
        // import com.tangosol.dev.component.Component;
        
        Component cd = getCD();
        String    sPkg;
        if (cd.isComponent())
            {
            sPkg = cd.getGlobalParent().getSuperName();
            }
        else
            {
            String sName = cd.getName();
            int    ofDot = sName.lastIndexOf('.');
            sPkg = ofDot < 0 ? "" : sName.substring(0, ofDot);
            }
        
        return getContext().getPackageInfo(sPkg);
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Accessor for the property "ParentInfo"
    public com.tangosol.dev.compiler.TypeInfo getParentInfo()
        {
        Object parent = get_Parent();
        
        if (parent instanceof TypeInfo)
            {
            return (TypeInfo) parent;
            }
        
        return null;
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Accessor for the property "SuperInfo"
    public com.tangosol.dev.compiler.TypeInfo getSuperInfo()
        {
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.DataType;
        
        // verify there is a super
        // (java.lang.Object and interfaces do not have super classes)
        // (root Component thinks it has no super, but it has java.lang.Object)
        Component cd     = getCD();
        String    sSuper = cd.getSuperName();
        if (sSuper.length() == 0)
            {
            if (cd.isComponent())
                {
                sSuper = DataType.OBJECT.getClassName();
                }
            else
                {
                return null;
                }
            }
        
        // a child component's super may be a child of the parent's super;
        // otherwise, the super is a Java Class Signature or global component
        TypeInfo parent = (TypeInfo) getParentInfo();
        TypeInfo info;
        if (parent != null && sSuper.indexOf('$') >= 0)
            {
            // this is a type info for a child component that derives from a child
            // of this parent's super component
            info = (TypeInfo) parent.getSuperInfo().getChildInfo(getName());
            }
        else
            {
            info = (TypeInfo) getContext().getTypeInfo(sSuper);
            }
        
        // assert should only be possible if someone registered a JCS without
        // registering its super class or if (somehow) the component storage
        // is out-of-sync
        _assert(info != null);
        
        return info;
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    public java.util.Enumeration interfaceTypes()
        {
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.util.NullImplementation;
        // import com.tangosol.util.SimpleEnumerator;
        // import java.util.Map;
        // import java.util.TreeMap;
        
        String[] asImpl = getCD().getImplements();
        String[] asDisp = getCD().getDispatches();
        int      cImpl  = asImpl.length;
        int      cDisp  = asDisp.length;
        
        // optimization -- no interfaces
        if (cImpl + cDisp <= 0)
            {
            return NullImplementation.getEnumeration();
            }
        
        // optimization -- only "implements" not "dispatches"
        if (cDisp == 0)
            {
            DataType[] adt = new DataType[cImpl];
            for (int i = 0; i < cImpl; ++i)
                {
                adt[i] = DataType.getClassType(asImpl[i]);
                }
            return new SimpleEnumerator(adt);
            }
        
        // merge implements/dispatches (keep them in order like the CD does)
        Map map = new TreeMap();
        for (int i = 0; i < cImpl; ++i)
            {
            String sIface = asImpl[i];
            map.put(sIface, DataType.getClassType(sIface));
            }
        for (int i = 0; i < cDisp; ++i)
            {
            String sIface = asDisp[i];
            map.put(sIface, DataType.getClassType(sIface));
            }
        return new SimpleEnumerator(map.values().toArray());
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Declared at the super level
    public boolean isAbstract()
        {
        return getCD().isResultAbstract();
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Declared at the super level
    public boolean isAccessible()
        {
        // - if the class or component is public, then it is accessible
        // - components are always public
        // - classes may not be public, in which case they are always inaccessible
        //   since this script is on a component and this component does not extend
        //   any class but Object (so protecteds are not accessible) nor does it
        //   reside in the same package (so protecteds and packages are not accessible)
        return isPublic();
        }
    
    // Declared at the super level
    public boolean isDeprecated()
        {
        return getCD().isDeprecated();
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Declared at the super level
    public boolean isFinal()
        {
        return getCD().isFinal();
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    public boolean isInterface()
        {
        return getCD().isInterface();
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    public boolean isInterface(com.tangosol.dev.component.DataType dt)
        {
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.DataType;
        // import java.util.Enumeration;
        // import Component.Dev.Compiler.Script.Context;
        
        if (!dt.isClass())
            {
            return false;
            }
        
        Component cd    = getCD();
        String    sName = dt.getClassName();
        
        if (cd.getImplements(sName) != null || cd.getDispatches(sName) != null)
            {
            return true;
            }
        
        // Components/classes/interfaces may implement interfaces that extend
        // other interfaces and so on
        Context ctx = getContext();
        for (Enumeration enum = interfaceTypes(); enum.hasMoreElements(); )
            {
            // get type info for each
            DataType dtIface = (DataType) enum.nextElement();
            TypeInfo info    = (TypeInfo) ctx.getTypeInfo(dtIface);
            _assert(info != null);
        
            // check if that type info implements the iface
            if (info.isInterface(dt))
                {
                return true;
                }
            }
        
        return false;
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Declared at the super level
    public boolean isPackage()
        {
        // import com.tangosol.dev.component.Constants;
        
        return getCD().getAccess() == Constants.ACCESS_PACKAGE;
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Declared at the super level
    public boolean isPrivate()
        {
        // import com.tangosol.dev.component.Constants;
        
        return getCD().getAccess() == Constants.ACCESS_PRIVATE;
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Declared at the super level
    public boolean isProtected()
        {
        // import com.tangosol.dev.component.Constants;
        
        return getCD().getAccess() == Constants.ACCESS_PROTECTED;
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Declared at the super level
    public boolean isPublic()
        {
        // import com.tangosol.dev.component.Constants;
        
        return getCD().getAccess() == Constants.ACCESS_PUBLIC;
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Declared at the super level
    public boolean isStatic()
        {
        return getCD().isStatic();
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    // Accessor for the property "Throwable"
    public boolean isThrowable()
        {
        return getCD().isThrowable();
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    public java.util.Enumeration methodNames()
        {
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.util.IteratorEnumerator;
        // import java.util.Enumeration;
        // import java.util.Vector;
        // import java.util.TreeSet;
        
        Component cd   = getCD();
        Vector    vect = new Vector();
        
        // get behavior names
        String sPrev = "";
        for (Enumeration enum = cd.getBehaviors(); enum.hasMoreElements(); )
            {
            String sName = ((Behavior) enum.nextElement()).getName();
            if (!sName.equals(sPrev))
                {
                vect.add(sName);
                sPrev = sName;
                }
            }
        
        // check for implied behaviors from virtual constants
        if (cd.isComponent())
            {
            TreeSet set = new TreeSet();
            for (Enumeration enum = cd.getProperties(); enum.hasMoreElements(); )
                {
                Property prop = (Property) enum.nextElement();
                if (prop.isVirtualConstant())
                    {
                    String sSig  = prop.getAccessorSignature(prop.PA_GET_SINGLE);
                    String sName = sSig.substring(0, sSig.indexOf('('));
                    set.add(sName);
                    }
                }
        
            if (!set.isEmpty())
                {
                set.addAll(vect);
                return new IteratorEnumerator(set.iterator());
                }
            }
        
        return vect.elements();
        }
    
    // From interface: com.tangosol.dev.compiler.TypeInfo
    public java.util.Enumeration paramTypes(String sMethod, int cParams)
        {
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.DataType;
        // import java.util.Enumeration;
        // import java.util.Vector;
        
        Component cd   = getCD();
        Vector    vect = new Vector();
        
        // enumerate behaviors with the specified name
        for (Enumeration enum = cd.getBehaviors(sMethod); enum.hasMoreElements(); )
            {
            Behavior beh = (Behavior) enum.nextElement();
            if (cParams < 0 || cParams == beh.getParameterCount())
                {
                vect.add(beh.getParameterTypes());
                }
            }
        
        // check for implied behaviors from virtual constants
        if (cd.isComponent() &&
                (sMethod.charAt(0) == 'g' || sMethod.charAt(0) == 'i'))
            {
            String sName = Property.getPropertyName(sMethod + "()");
            if (sName != null)
                {
                Property prop = cd.getProperty(sName);
                if (prop != null && prop.isVirtualConstant())
                    {
                    // two potential cases:
                    // (1) not indexed-only means there is a no-param accessor
                    if (prop.getIndexed() != prop.PROP_INDEXEDONLY)
                        {
                        vect.add(new DataType[0]);
                        }
                    // (2) not single means there is an indexed accessor
                    if (!prop.isSingle())
                        {
                        vect.add(new DataType[] {DataType.INT});
                        }
                    }
                }
            }
        
        return vect.elements();

        }
    
    // Accessor for the property "CD"
    public void setCD(com.tangosol.dev.component.Component pCD)
        {
        __m_CD = pCD;
        }
    
    // Accessor for the property "ClassConstant"
    public void setClassConstant(com.tangosol.dev.assembler.ClassConstant pClassConstant)
        {
        __m_ClassConstant = pClassConstant;
        }
    
    // Declared at the super level
    public String toString()
        {
        // import com.tangosol.dev.component.Component;
        
        Component cd = getCD();
        return cd.isComponent() ? cd.getQualifiedName() : cd.getName();
        }
    }
