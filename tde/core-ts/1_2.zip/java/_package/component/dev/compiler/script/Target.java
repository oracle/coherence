/* Class
*     _package.component.dev.compiler.script.Target
*/

package _package.component.dev.compiler.script;

import com.tangosol.util.StringTable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Target
        extends    _package.component.dev.compiler.Script
        implements com.tangosol.dev.compiler.Manager
    {
    // Fields declarations
    
    /**
    * Property CD
    *
    * The Component Definition representing the "this"
    */
    private transient com.tangosol.dev.component.Component __m_CD;
    
    /**
    * Property Check
    *
    */
    private transient boolean __m_Check;
    
    /**
    * Property ClassLookupMethods
    *
    */
    private java.util.Map __m_ClassLookupMethods;
    
    /**
    * Property Debug
    *
    */
    private transient boolean __m_Debug;
    
    /**
    * Property Imports
    *
    */
    private transient com.tangosol.util.StringTable __m_Imports;
    
    /**
    * Property Manager
    *
    */
    private transient com.tangosol.dev.compiler.Manager __m_Manager;
    
    /**
    * Property NonPackages
    *
    */
    private java.util.Set __m_NonPackages;
    
    /**
    * Property NonTypes
    *
    */
    private java.util.Set __m_NonTypes;
    
    /**
    * Property Options
    *
    */
    private transient java.util.Properties __m_Options;
    
    /**
    * Property Storage
    *
    */
    private transient com.tangosol.dev.component.Storage __m_Storage;
    
    // Default constructor
    public Target()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Target(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Target();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/Target".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    public com.tangosol.dev.assembler.Field addSyntheticField(com.tangosol.dev.component.DataType dt)
        {
        return getManager().addSyntheticField(dt);
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    public com.tangosol.dev.assembler.Method addSyntheticMethod(com.tangosol.dev.component.DataType[] adt)
        {
        return getManager().addSyntheticMethod(adt);
        }
    
    public Context createContext(com.tangosol.dev.component.Implementation script, com.tangosol.dev.assembler.Method method, com.tangosol.dev.assembler.Constant superconstant)
        {
        // import com.tangosol.util.StringTable;
        
        Context ctx = new Context();
        
        // initialize context
        ctx.setTarget(this);
        ctx.setScript(script);
        ctx.setMethod(method);
        ctx.setSuperConstant(superconstant);
        
        // copy any registered imports
        StringTable tblImports = getImports();
        if (tblImports != null)
            {
            ctx.setImports((StringTable) tblImports.clone());
            }
        
        return ctx;
        }
    
    // Accessor for the property "CD"
    public com.tangosol.dev.component.Component getCD()
        {
        return __m_CD;
        }
    
    // Accessor for the property "ClassLookupMethods"
    public synchronized java.util.Map getClassLookupMethods()
        {
        // import java.util.Map;
        // import java.util.HashMap;
        
        Map map = __m_ClassLookupMethods;
        
        if (map == null)
            {
            map = new HashMap();
            setClassLookupMethods(map);
            }
        
        return map;
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    public com.tangosol.util.ErrorList getErrorList()
        {
        return getManager().getErrorList();
        }
    
    // Accessor for the property "Imports"
    public com.tangosol.util.StringTable getImports()
        {
        return __m_Imports;
        }
    
    // Accessor for the property "Manager"
    public com.tangosol.dev.compiler.Manager getManager()
        {
        return __m_Manager;
        }
    
    // Accessor for the property "NonPackages"
    public java.util.Set getNonPackages()
        {
        // import java.util.Set;
        // import java.util.HashSet;
        
        Set set = __m_NonPackages;
        
        if (set == null)
            {
            set = new HashSet();
            setNonPackages(set);
            }
        
        return set;
        }
    
    // Accessor for the property "NonTypes"
    public java.util.Set getNonTypes()
        {
        // import java.util.Set;
        // import java.util.HashSet;
        
        Set set = __m_NonTypes;
        
        if (set == null)
            {
            set = new HashSet();
            setNonTypes(set);
            }
        
        return set;
        }
    
    // Accessor for the property "Options"
    public java.util.Properties getOptions()
        {
        return __m_Options;
        }
    
    // Accessor for the property "Storage"
    public com.tangosol.dev.component.Storage getStorage()
        {
        return __m_Storage;
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    public com.tangosol.dev.assembler.FieldConstant inlineMethod(com.tangosol.dev.component.DataType dtClass, com.tangosol.dev.component.DataType dtReturn, String sName, com.tangosol.dev.component.DataType[] adtParam)
        {
        return getManager().inlineMethod(dtClass, dtReturn, sName, adtParam);
        }
    
    // Accessor for the property "Check"
    public boolean isCheck()
        {
        return __m_Check;
        }
    
    // Accessor for the property "Debug"
    public boolean isDebug()
        {
        return __m_Debug;
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    public com.tangosol.dev.assembler.ClassConstant resolveClass(com.tangosol.dev.component.DataType dtClass)
        {
        return getManager().resolveClass(dtClass);
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    public com.tangosol.dev.assembler.FieldConstant resolveField(com.tangosol.dev.component.DataType dtClass, com.tangosol.dev.component.DataType dtField, String sName)
        {
        return getManager().resolveField(dtClass, dtField, sName);
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    public com.tangosol.dev.assembler.MethodConstant resolveMethod(com.tangosol.dev.component.DataType dtClass, com.tangosol.dev.component.DataType dtReturn, String sName, com.tangosol.dev.component.DataType[] adtParam)
        {
        return getManager().resolveMethod(dtClass, dtReturn, sName, adtParam);
        }
    
    // Accessor for the property "CD"
    public void setCD(com.tangosol.dev.component.Component pCD)
        {
        __m_CD = pCD;
        }
    
    // Accessor for the property "Check"
    public void setCheck(boolean pCheck)
        {
        __m_Check = pCheck;
        }
    
    // Accessor for the property "ClassLookupMethods"
    public void setClassLookupMethods(java.util.Map pClassLookupMethods)
        {
        __m_ClassLookupMethods = pClassLookupMethods;
        }
    
    // Accessor for the property "Debug"
    public void setDebug(boolean pDebug)
        {
        __m_Debug = pDebug;
        }
    
    // Accessor for the property "Imports"
    public void setImports(com.tangosol.util.StringTable pImports)
        {
        __m_Imports = pImports;
        }
    
    // Accessor for the property "Manager"
    public void setManager(com.tangosol.dev.compiler.Manager pManager)
        {
        __m_Manager = pManager;
        }
    
    // Accessor for the property "NonPackages"
    public void setNonPackages(java.util.Set pNonPackages)
        {
        __m_NonPackages = pNonPackages;
        }
    
    // Accessor for the property "NonTypes"
    public void setNonTypes(java.util.Set pNonTypes)
        {
        __m_NonTypes = pNonTypes;
        }
    
    // Accessor for the property "Options"
    public void setOptions(java.util.Properties pOptions)
        {
        __m_Options = pOptions;
        }
    
    // Accessor for the property "Storage"
    public void setStorage(com.tangosol.dev.component.Storage pLoader)
        {
        __m_Storage = pLoader;
        }
    }
