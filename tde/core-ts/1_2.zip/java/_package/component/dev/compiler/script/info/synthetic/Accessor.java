/* Class
*     _package.component.dev.compiler.script.info.synthetic.Accessor
*/

package _package.component.dev.compiler.script.info.synthetic;

import _package.component.dev.compiler.script.info.TypeInfo;
import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.assembler.SignatureConstant;
import com.tangosol.dev.component.Constants;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Property;
import com.tangosol.util.NullImplementation;

/**
* Virtual property accessor.  See Info.TypeInfo.getMethodInfo().
*/
public class Accessor
        extends    _package.component.dev.compiler.script.info.Synthetic
        implements com.tangosol.dev.compiler.MethodInfo
    {
    // Fields declarations
    
    /**
    * Property FieldInfo
    *
    */
    
    /**
    * Property MethodConstant
    *
    */
    private transient com.tangosol.dev.assembler.MethodConstant __m_MethodConstant;
    
    /**
    * Property ParamCount
    *
    */
    
    /**
    * Property Parameter
    *
    */
    private transient Index __m_Parameter;
    
    /**
    * Property ParamInfo
    *
    */
    
    /**
    * Property ParamTypes
    *
    */
    
    /**
    * Property Property
    *
    */
    private transient com.tangosol.dev.component.Property __m_Property;
    
    // Default constructor
    public Accessor()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Accessor(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Accessor();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/info/synthetic/Accessor".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    public java.util.Enumeration exceptionTypes()
        {
        // import com.tangosol.util.NullImplementation;
        
        return NullImplementation.getEnumeration();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public com.tangosol.dev.assembler.Constant getConstant()
        {
        
        return getMethodConstant();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public com.tangosol.dev.component.DataType getDataType()
        {
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.DataType;
        
        Property prop = getProperty();
        DataType dt   = prop.getDataType();
        
        // check if this is an array accessor for an indexed prop
        if (!prop.isSingle() && getParamCount() == 0)
            {
            dt = dt.getArrayType();
            }
        
        return dt;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "FieldInfo"
    public com.tangosol.dev.compiler.FieldInfo getFieldInfo()
        {
        return null;
        }
    
    // Accessor for the property "MethodConstant"
    public com.tangosol.dev.assembler.MethodConstant getMethodConstant()
        {
        // import com.tangosol.dev.assembler.Constants;
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.SignatureConstant;
        
        MethodConstant constant = __m_MethodConstant;
        
        if (constant == null)
            {
            ClassConstant     CLAZZ = (ClassConstant) getTypeInfo().getConstant();
            String            sSig  = '('
                                    + (getParamCount() == 0 ? "" : "I")
                                    + ')'
                                    + getDataType().getJVMSignature();
            // WARNING:  The above "getJVMSignature" will not work correctly in the
            // very improbable case of the data type of this virtual constant (which
            // this Accessor component is currently only used for) being a compiled
            // out component child.
            SignatureConstant SIG   = new SignatureConstant(getName(), sSig);
            constant = new MethodConstant(CLAZZ, SIG);
            setMethodConstant(constant);
            }
        
        return constant;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public String getName()
        {
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.DataType;
        
        Property prop = getProperty();
        return (prop.getDataType() == DataType.BOOLEAN ? "is" : "get") + prop.getName();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "ParamCount"
    public int getParamCount()
        {
        // either 1 parameter for indexed (iff a parameter exists) or 0 parameters
        return getParameter() == null ? 0 : 1;
        }
    
    // Accessor for the property "Parameter"
    public Index getParameter()
        {
        return (Index) _findChild("P_i");
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "ParamInfo"
    public com.tangosol.dev.compiler.ParamInfo getParamInfo(int i)
        {
        
        if (i < 0 || i >= getParamCount())
            {
            throw new ArrayIndexOutOfBoundsException();
            }
        
        return getParameter();
        }
    
    // Accessor for the property "ParamTypes"
    public com.tangosol.dev.component.DataType[] getParamTypes()
        {
        // import com.tangosol.dev.component.DataType;
        
        return getParamCount() == 0 ? new DataType[0] : new DataType[] {DataType.INT};
        }
    
    // Accessor for the property "Property"
    public com.tangosol.dev.component.Property getProperty()
        {
        return __m_Property;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public com.tangosol.dev.compiler.TypeInfo getTypeInfo()
        {
        // import Component.Dev.Compiler.Script.Info.TypeInfo;
        
        return (TypeInfo) get_Parent();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isAccessible()
        {
        // import com.tangosol.dev.component.DataType;
        // import Component.Dev.Compiler.Script.Info.TypeInfo;
        
        if (isPublic())
            {
            return true;
            }
        
        // virtual constants must be public or protected
        _assert(isProtected());
        
        // protected is accessible iff this class inherits from the class on which the
        // property exists
        TypeInfo infoThis    = (TypeInfo) getTypeInfo();
        TypeInfo infoContext = (TypeInfo) getContext().getMethodInfo().getTypeInfo();
        
        // all members are accessible on the declaring class
        if (infoThis == infoContext)
            {
            return true;
            }
        
        // the script compilation context is always from a component
        // so the protected method must be on either a super component
        // or on java.lang.Object
        DataType dtThis    = infoThis   .getDataType();
        DataType dtContext = infoContext.getDataType();
        _assert(dtContext.isComponent());
        
        return dtThis == DataType.OBJECT || dtThis.isComponent() &&
                infoContext.getCD().isDerivedFrom(infoThis.getCD());
        }
    
    // Declared at the super level
    public boolean isDeprecated()
        {
        return getProperty().isDeprecated();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isProtected()
        {
        // import com.tangosol.dev.component.Constants;
        
        return getProperty().getAccess() == Constants.ACCESS_PROTECTED;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isPublic()
        {
        // import com.tangosol.dev.component.Constants;
        
        return getProperty().getAccess() == Constants.ACCESS_PUBLIC;
        }
    
    // Accessor for the property "MethodConstant"
    public void setMethodConstant(com.tangosol.dev.assembler.MethodConstant pMethodConstant)
        {
        __m_MethodConstant = pMethodConstant;
        }
    
    // Accessor for the property "Parameter"
    public void setParameter(Index param)
        {
        _addChild(param, "P_i");
        }
    
    // Accessor for the property "Property"
    public void setProperty(com.tangosol.dev.component.Property pProperty)
        {
        __m_Property = pProperty;
        }
    }
