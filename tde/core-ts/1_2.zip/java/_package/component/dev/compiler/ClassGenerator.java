/* Class
*     _package.component.dev.compiler.ClassGenerator
*/

package _package.component.dev.compiler;

import _package.component.dev.Design;
import _package.component.dev.Storage;
import _package.component.dev.compiler.Integrator;
import _package.component.dev.compiler.script.Target;
import _package.component.dev.util.traitLocator.componentLocator.behaviorLocator.ImplementationLocator;
import com.tangosol.dev.assembler.Aaload;
import com.tangosol.dev.assembler.Aastore;
import com.tangosol.dev.assembler.AccessFlags;
import com.tangosol.dev.assembler.Aconst;
import com.tangosol.dev.assembler.Aload;
import com.tangosol.dev.assembler.Anewarray;
import com.tangosol.dev.assembler.Areturn;
import com.tangosol.dev.assembler.Arraylength;
import com.tangosol.dev.assembler.Astore;
import com.tangosol.dev.assembler.Athrow;
import com.tangosol.dev.assembler.Attribute;
import com.tangosol.dev.assembler.Avar;
import com.tangosol.dev.assembler.Baload;
import com.tangosol.dev.assembler.Bastore;
import com.tangosol.dev.assembler.Begin;
import com.tangosol.dev.assembler.Bnewarray;
import com.tangosol.dev.assembler.Caload;
import com.tangosol.dev.assembler.Case;
import com.tangosol.dev.assembler.Castore;
import com.tangosol.dev.assembler.Catch;
import com.tangosol.dev.assembler.Checkcast;
import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.ClassFile;
import com.tangosol.dev.assembler.Cnewarray;
import com.tangosol.dev.assembler.CodeAttribute;
import com.tangosol.dev.assembler.Constant;
import com.tangosol.dev.assembler.ConstantPool;
import com.tangosol.dev.assembler.ConstantValueAttribute;
import com.tangosol.dev.assembler.Constants;
import com.tangosol.dev.assembler.D2f;
import com.tangosol.dev.assembler.D2i;
import com.tangosol.dev.assembler.D2l;
import com.tangosol.dev.assembler.Dadd;
import com.tangosol.dev.assembler.Daload;
import com.tangosol.dev.assembler.Dastore;
import com.tangosol.dev.assembler.Dcmpg;
import com.tangosol.dev.assembler.Dcmpl;
import com.tangosol.dev.assembler.Dconst;
import com.tangosol.dev.assembler.Ddiv;
import com.tangosol.dev.assembler.DeprecatedAttribute;
import com.tangosol.dev.assembler.Dload;
import com.tangosol.dev.assembler.Dmul;
import com.tangosol.dev.assembler.Dneg;
import com.tangosol.dev.assembler.Dnewarray;
import com.tangosol.dev.assembler.DoubleConstant;
import com.tangosol.dev.assembler.Drem;
import com.tangosol.dev.assembler.Dreturn;
import com.tangosol.dev.assembler.Dstore;
import com.tangosol.dev.assembler.Dsub;
import com.tangosol.dev.assembler.Dup2;
import com.tangosol.dev.assembler.Dup2_x1;
import com.tangosol.dev.assembler.Dup2_x2;
import com.tangosol.dev.assembler.Dup;
import com.tangosol.dev.assembler.Dup_x1;
import com.tangosol.dev.assembler.Dup_x2;
import com.tangosol.dev.assembler.Dvar;
import com.tangosol.dev.assembler.End;
import com.tangosol.dev.assembler.ExceptionsAttribute;
import com.tangosol.dev.assembler.F2d;
import com.tangosol.dev.assembler.F2i;
import com.tangosol.dev.assembler.F2l;
import com.tangosol.dev.assembler.Fadd;
import com.tangosol.dev.assembler.Faload;
import com.tangosol.dev.assembler.Fastore;
import com.tangosol.dev.assembler.Fcmpg;
import com.tangosol.dev.assembler.Fcmpl;
import com.tangosol.dev.assembler.Fconst;
import com.tangosol.dev.assembler.Fdiv;
import com.tangosol.dev.assembler.Field;
import com.tangosol.dev.assembler.FieldConstant;
import com.tangosol.dev.assembler.Fload;
import com.tangosol.dev.assembler.FloatConstant;
import com.tangosol.dev.assembler.Fmul;
import com.tangosol.dev.assembler.Fneg;
import com.tangosol.dev.assembler.Fnewarray;
import com.tangosol.dev.assembler.Frem;
import com.tangosol.dev.assembler.Freturn;
import com.tangosol.dev.assembler.Fstore;
import com.tangosol.dev.assembler.Fsub;
import com.tangosol.dev.assembler.Fvar;
import com.tangosol.dev.assembler.Getfield;
import com.tangosol.dev.assembler.Getstatic;
import com.tangosol.dev.assembler.Goto;
import com.tangosol.dev.assembler.GuardedSection;
import com.tangosol.dev.assembler.I2b;
import com.tangosol.dev.assembler.I2c;
import com.tangosol.dev.assembler.I2d;
import com.tangosol.dev.assembler.I2f;
import com.tangosol.dev.assembler.I2l;
import com.tangosol.dev.assembler.I2s;
import com.tangosol.dev.assembler.Iadd;
import com.tangosol.dev.assembler.Iaload;
import com.tangosol.dev.assembler.Iand;
import com.tangosol.dev.assembler.Iastore;
import com.tangosol.dev.assembler.Iconst;
import com.tangosol.dev.assembler.Idiv;
import com.tangosol.dev.assembler.If_acmpeq;
import com.tangosol.dev.assembler.If_acmpne;
import com.tangosol.dev.assembler.If_icmpeq;
import com.tangosol.dev.assembler.If_icmpge;
import com.tangosol.dev.assembler.If_icmpgt;
import com.tangosol.dev.assembler.If_icmple;
import com.tangosol.dev.assembler.If_icmplt;
import com.tangosol.dev.assembler.If_icmpne;
import com.tangosol.dev.assembler.Ifeq;
import com.tangosol.dev.assembler.Ifge;
import com.tangosol.dev.assembler.Ifgt;
import com.tangosol.dev.assembler.Ifle;
import com.tangosol.dev.assembler.Iflt;
import com.tangosol.dev.assembler.Ifne;
import com.tangosol.dev.assembler.Ifnonnull;
import com.tangosol.dev.assembler.Ifnull;
import com.tangosol.dev.assembler.Iinc;
import com.tangosol.dev.assembler.Iload;
import com.tangosol.dev.assembler.Imul;
import com.tangosol.dev.assembler.Ineg;
import com.tangosol.dev.assembler.Inewarray;
import com.tangosol.dev.assembler.InnerClass;
import com.tangosol.dev.assembler.InnerClassesAttribute;
import com.tangosol.dev.assembler.Instanceof;
import com.tangosol.dev.assembler.IntConstant;
import com.tangosol.dev.assembler.InterfaceConstant;
import com.tangosol.dev.assembler.Invokeinterface;
import com.tangosol.dev.assembler.Invokespecial;
import com.tangosol.dev.assembler.Invokestatic;
import com.tangosol.dev.assembler.Invokevirtual;
import com.tangosol.dev.assembler.Ior;
import com.tangosol.dev.assembler.Irem;
import com.tangosol.dev.assembler.Ireturn;
import com.tangosol.dev.assembler.Ishl;
import com.tangosol.dev.assembler.Ishr;
import com.tangosol.dev.assembler.Istore;
import com.tangosol.dev.assembler.Isub;
import com.tangosol.dev.assembler.Iushr;
import com.tangosol.dev.assembler.Ivar;
import com.tangosol.dev.assembler.Ixor;
import com.tangosol.dev.assembler.Jsr;
import com.tangosol.dev.assembler.L2d;
import com.tangosol.dev.assembler.L2f;
import com.tangosol.dev.assembler.L2i;
import com.tangosol.dev.assembler.Label;
import com.tangosol.dev.assembler.Ladd;
import com.tangosol.dev.assembler.Laload;
import com.tangosol.dev.assembler.Land;
import com.tangosol.dev.assembler.Lastore;
import com.tangosol.dev.assembler.Lcmp;
import com.tangosol.dev.assembler.Lconst;
import com.tangosol.dev.assembler.Ldiv;
import com.tangosol.dev.assembler.LineNumberTableAttribute;
import com.tangosol.dev.assembler.Lload;
import com.tangosol.dev.assembler.Lmul;
import com.tangosol.dev.assembler.Lneg;
import com.tangosol.dev.assembler.Lnewarray;
import com.tangosol.dev.assembler.LocalVariableTableAttribute;
import com.tangosol.dev.assembler.LongConstant;
import com.tangosol.dev.assembler.Lookupswitch;
import com.tangosol.dev.assembler.Lor;
import com.tangosol.dev.assembler.Lrem;
import com.tangosol.dev.assembler.Lreturn;
import com.tangosol.dev.assembler.Lshl;
import com.tangosol.dev.assembler.Lshr;
import com.tangosol.dev.assembler.Lstore;
import com.tangosol.dev.assembler.Lsub;
import com.tangosol.dev.assembler.Lushr;
import com.tangosol.dev.assembler.Lvar;
import com.tangosol.dev.assembler.Lxor;
import com.tangosol.dev.assembler.Method;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.assembler.Monitorenter;
import com.tangosol.dev.assembler.Monitorexit;
import com.tangosol.dev.assembler.Multianewarray;
import com.tangosol.dev.assembler.New;
import com.tangosol.dev.assembler.Nop;
import com.tangosol.dev.assembler.Op;
import com.tangosol.dev.assembler.OpArray;
import com.tangosol.dev.assembler.OpBranch;
import com.tangosol.dev.assembler.OpConst;
import com.tangosol.dev.assembler.OpDeclare;
import com.tangosol.dev.assembler.OpLoad;
import com.tangosol.dev.assembler.OpStore;
import com.tangosol.dev.assembler.OpSwitch;
import com.tangosol.dev.assembler.OpVariable;
import com.tangosol.dev.assembler.Pop2;
import com.tangosol.dev.assembler.Pop;
import com.tangosol.dev.assembler.Putfield;
import com.tangosol.dev.assembler.Putstatic;
import com.tangosol.dev.assembler.RefConstant;
import com.tangosol.dev.assembler.Ret;
import com.tangosol.dev.assembler.Return;
import com.tangosol.dev.assembler.Rstore;
import com.tangosol.dev.assembler.Rvar;
import com.tangosol.dev.assembler.Saload;
import com.tangosol.dev.assembler.Sastore;
import com.tangosol.dev.assembler.SignatureConstant;
import com.tangosol.dev.assembler.Snewarray;
import com.tangosol.dev.assembler.SourceFileAttribute;
import com.tangosol.dev.assembler.StringConstant;
import com.tangosol.dev.assembler.Swap;
import com.tangosol.dev.assembler.Switch;
import com.tangosol.dev.assembler.SyntheticAttribute;
import com.tangosol.dev.assembler.Tableswitch;
import com.tangosol.dev.assembler.Try;
import com.tangosol.dev.assembler.UtfConstant;
import com.tangosol.dev.assembler.VMStructure;
import com.tangosol.dev.assembler.Znewarray;
import com.tangosol.dev.compiler.Compiler;
import com.tangosol.dev.compiler.CompilerErrorInfo;
import com.tangosol.dev.compiler.CompilerException;
import com.tangosol.dev.compiler.Context;
import com.tangosol.dev.compiler.Locator;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.CompilePlan;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Implementation;
import com.tangosol.dev.component.Integration;
import com.tangosol.dev.component.Interface;
import com.tangosol.dev.component.Parameter;
import com.tangosol.dev.component.Property;
import com.tangosol.dev.component.ReturnValue;
import com.tangosol.util.Base;
import com.tangosol.util.ClassHelper;
import com.tangosol.util.ErrorList$Constants; // as Severety
import com.tangosol.util.ErrorList$Item; // as ErrorInfo
import com.tangosol.util.ErrorList;
import com.tangosol.util.SimpleEnumerator;
import com.tangosol.util.StringTable;
import com.tangosol.util.UID;
import com.tangosol.util.WrapperException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
* This component provides a bulk of the functionality needed to generate java
* classes from Component Definitions
*/
public class ClassGenerator
        extends    _package.component.dev.Compiler
        implements com.tangosol.dev.compiler.Manager
    {
    // Fields declarations
    
    /**
    * Property BHVR_ADD_CHILD
    *
    * Should be initialized as:
    * 
    *     "_addChild(" + COMPONENT_CDSIG + STRING_SIG + ')';
    */
    public static final String BHVR_ADD_CHILD = "_addChild(RComponent;Ljava.lang.String;)";
    
    /**
    * Property BHVR_INIT
    *
    */
    public static final String BHVR_INIT = "_init()";
    
    /**
    * Property BHVR_INIT_STATIC
    *
    */
    public static final String BHVR_INIT_STATIC = "_initStatic()";
    
    /**
    * Property BHVR_REG_CHILD
    *
    * Should be initialized as:
    * 
    *     "_registerChild(" + COMPONENT_CDSIG + STRING_SIG + ')';
    */
    public static final String BHVR_REG_CHILD = "_registerChild(RComponent;Ljava.lang.String;)";
    
    /**
    * Property BHVR_TRACE
    *
    */
    public static final String BHVR_TRACE = "_trace(Ljava.lang.String;)";
    
    /**
    * Property BHVR_UNREG_CHILD
    *
    * Should be initialized as:
    * 
    *     "_unregisterChild(" + COMPONENT_CDSIG + ')';
    */
    public static final String BHVR_UNREG_CHILD = "_unregisterChild(RComponent;)";
    
    /**
    * Property CachedDefaultImports
    *
    * (Static) Cache of system level imports.
    * 
    * @see #getDefaultImports
    */
    private static transient com.tangosol.util.StringTable __s_CachedDefaultImports;
    
    /**
    * Property CachedIntegrators
    *
    * Cache of Component Integrators.
    * 
    * @see #findIntegrator
    */
    private transient com.tangosol.util.StringTable __m_CachedIntegrators;
    
    /**
    * Property CD
    *
    * The Component Definition to be compiled. This property must be set by the
    * caller.
    */
    private transient com.tangosol.dev.component.Component __m_CD;
    
    /**
    * Property ClassFile
    *
    * The class file generated by this ClassGenerator. This property is set by
    * the "compile" method.
    */
    private transient com.tangosol.dev.assembler.ClassFile __m_ClassFile;
    
    /**
    * Property Code
    *
    * Current code attribute processed (generated) by the ClassGenerator.
    */
    private transient com.tangosol.dev.assembler.CodeAttribute __m_Code;
    
    /**
    * Property CompilePlan
    *
    * Compile plan for this ClassGenerator
    */
    private transient com.tangosol.dev.component.CompilePlan __m_CompilePlan;
    
    /**
    * Property CompilePlanCache
    *
    * (Privately used) Cache of compile plans mapping the global component
    * names to the corresponding CompilePlans.
    * 
    * @see #resolveClass
    */
    private transient java.util.Hashtable __m_CompilePlanCache;
    
    /**
    * Property COMPONENT_CDSIG
    *
    * Should be initialized as:
    * 
    *     'R' + COMPONENT_ROOT + ';';
    */
    private static final String COMPONENT_CDSIG = "RComponent;";
    
    /**
    * Property COMPONENT_JVMSIG
    *
    * Should be initialized as:
    * 
    * DataType.getComponentType(COMPONENT_ROOT).getJVMSignature();
    */
    private static final String COMPONENT_JVMSIG = "L_package.Component;";
    
    /**
    * Property COMPONENT_ROOT
    *
    * Root component name. Should be initialized as:
    * 
    *     Component.getRootName();
    */
    private static final String COMPONENT_ROOT = "Component";
    
    /**
    * Property ComponentImports
    *
    * (Calculated) Map of imports known by this component.
    */
    
    /**
    * Property CONSTRUCTOR_NAME
    *
    * Should be initialized as:
    *     com.tangosol.dev.assembler.CONSTRUCTOR_NAME;
    */
    public static final String CONSTRUCTOR_NAME = "<init>";
    
    /**
    * Property DebugInfo
    *
    * This property controls whether the debug info (the file name attribute
    * and the line numbers) is being generated.
    * 
    * @see #OptimizePrivateAccessors property
    * @see #OptimizeDiscardedChildren property
    */
    private boolean __m_DebugInfo;
    
    /**
    * Property DefaultImports
    *
    * Map of default imports for this component (includes the system level
    * defaults as well as auto generated children imports)
    * 
    * @see #CachedDefaultImports
    */
    private transient com.tangosol.util.StringTable __m_DefaultImports;
    
    /**
    * Property ErrorList
    *
    * ErrorList is supposed to be set by the user (caller) of the
    * ClassGenerator.
    */
    private com.tangosol.util.ErrorList __m_ErrorList;
    
    /**
    * Property EXPOSE_AUTO
    *
    */
    public static final int EXPOSE_AUTO = 0;
    
    /**
    * Property EXPOSE_COMPONENT
    *
    */
    public static final int EXPOSE_COMPONENT = 1;
    
    /**
    * Property EXPOSE_FEED
    *
    */
    public static final int EXPOSE_FEED = 2;
    
    /**
    * Property EXPOSE_REMOTE
    *
    */
    public static final int EXPOSE_REMOTE = 3;
    
    /**
    * Property FLD_CHILDREN
    *
    */
    public static final String FLD_CHILDREN = "__mapChildren";
    
    /**
    * Property FLD_SINGLETON
    *
    */
    private static final String FLD_SINGLETON = "__singleton";
    
    /**
    * Property GenerateListing
    *
    * This property controls whether the ClassGenerator should generate the
    * java listing. The default value is true.
    */
    private boolean __m_GenerateListing;
    
    /**
    * Property ImplicitImports
    *
    * (Calculated) Map of implicit import aliases that include the "$Module"
    * alias as well as the children aliases.
    */
    
    /**
    * Property Indent
    *
    * Privately used property that is used by the listing generator.
    */
    private transient StringBuffer __m_Indent;
    
    /**
    * Property INIT_CONSTRUCTOR_SIG
    *
    * Should be initialized as:
    * 
    *     "(" + STRING_SIG + COMPONENT_JVMSIG + "Z)V";
    */
    public static final String INIT_CONSTRUCTOR_SIG = "(Ljava.lang.String;L_package.Component;Z)V";
    
    /**
    * Property INIT_EVENTS_NAME
    *
    */
    public static final String INIT_EVENTS_NAME = "__initEvents";
    
    /**
    * Property INIT_NAME
    *
    */
    public static final String INIT_NAME = "__init";
    
    /**
    * Property INIT_PRIVATE_NAME
    *
    */
    public static final String INIT_PRIVATE_NAME = "__initPrivate";
    
    /**
    * Property INIT_REMOTEOBJECT_SIG
    *
    */
    public static final String INIT_REMOTEOBJECT_SIG = "(Ljava.lang.Object;)V";
    
    /**
    * Property INIT_STATIC_NAME
    *
    */
    public static final String INIT_STATIC_NAME = "__initStatic";
    
    /**
    * Property INITIALIZER_NAME
    *
    * Should be initialized as:
    *     com.tangosol.dev.assembler.INITIALIZER_NAME;
    */
    public static final String INITIALIZER_NAME = "<clinit>";
    
    /**
    * Property Integrator
    *
    * Specifies the Integrator, set by the compile method or by the Integrators.
    */
    private transient Integrator __m_Integrator;
    
    /**
    * Property LISTENER_IFACE
    *
    */
    private static final String LISTENER_IFACE = "java.util.EventListener";
    
    /**
    * Property LISTENERS_CLASS
    *
    */
    private static final String LISTENERS_CLASS = "com.tangosol.util.Listeners";
    
    /**
    * Property Listing
    *
    * A StringBuffer used for the listing generation.
    */
    private transient StringBuffer __m_Listing;
    
    /**
    * Property LISTMAP_CLASS
    *
    */
    private static final String LISTMAP_CLASS = "com.tangosol.util.ListMap";
    
    /**
    * Property NewLine
    *
    * Privately used flag for listing generation
    */
    private transient boolean __m_NewLine;
    
    /**
    * Property NextTempVariableNumber
    *
    * Get the next temporary variable number.  This will return a unique number
    * for use in generating a guarenteed unique local variable name.
    */
    private int __m_NextTempVariableNumber;
    
    /**
    * Property OptimizeDiscardedChildren
    *
    * This property controls the way an instantation and access to
    * "discardable" children is implemented.  Discardable children are the ones
    * that have no design info ("delta") that differentiate them form their
    * supers.  If set to true, the classes for those children are not generated
    * and all the references are resolved all the way up to the closest not
    * discardable supers.
    */
    private boolean __m_OptimizeDiscardedChildren;
    
    /**
    * Property OptimizePrivateAccessors
    *
    * This property controls the way an access to properties with private
    * accessors is implemented. If set to true, the generated code accesses the
    * data member directly; otherwise via accessors.
    */
    private boolean __m_OptimizePrivateAccessors;
    
    /**
    * Property ParentGenerator
    *
    * The class generator of the component class compile.  For child
    * components, this is the generator used by it's parent component.  For
    * Integrator classes, this is the generator used for the primary component
    * class generation.
    */
    private transient ClassGenerator __m_ParentGenerator;
    
    /**
    * Property PROP_CHILD_CLASSES
    *
    */
    public static final String PROP_CHILD_CLASSES = "_ChildClasses";
    
    /**
    * Property PROP_CLASS
    *
    */
    public static final String PROP_CLASS = "_CLASS";
    
    /**
    * Property PROP_CONSTRUCTED
    *
    */
    public static final String PROP_CONSTRUCTED = "_Constructed";
    
    /**
    * Property PROP_FEED
    *
    */
    public static final String PROP_FEED = "_Feed";
    
    /**
    * Property PROP_INSTANCE
    *
    */
    public static final String PROP_INSTANCE = "_Instance";
    
    /**
    * Property PROP_MODULE
    *
    */
    public static final String PROP_MODULE = "_Module";
    
    /**
    * Property PROP_PARENT
    *
    */
    public static final String PROP_PARENT = "_Parent";
    
    /**
    * Property PROP_REFERENCE
    *
    */
    public static final String PROP_REFERENCE = "_Reference";
    
    /**
    * Property PROP_REMOTEOBJECT
    *
    */
    public static final String PROP_REMOTEOBJECT = "_RemoteObject";
    
    /**
    * Property PROP_SINK
    *
    */
    public static final String PROP_SINK = "_Sink";
    
    /**
    * Property ScriptTarget
    *
    * Privately used Target component.
    */
    private transient _package.component.dev.compiler.script.Target __m_ScriptTarget;
    
    /**
    * Property Storage
    *
    * The storage used by the ClassGenerator. This property must be set by the
    * caller.
    */
    private transient _package.component.dev.Storage __m_Storage;
    
    /**
    * Property StoreResult
    *
    * Specifies whether the generated classes and listings should be
    * automatically stored
    */
    private boolean __m_StoreResult;
    
    /**
    * Property STRING_SIG
    *
    */
    private static final String STRING_SIG = "Ljava.lang.String;";
    
    /**
    * Property SynthFieldCount
    *
    * Privately used to generate unique synthetic field names.
    */
    private transient int __m_SynthFieldCount;
    
    /**
    * Property SynthMethodCount
    *
    * Privately used to generate unique synthetic method names.
    */
    private transient int __m_SynthMethodCount;
    
    /**
    * Property TAB
    *
    * Four spaces.
    */
    public static final String TAB = "    ";
    
    /**
    * Property TRACE_LEVEL_LOW
    *
    */
    public static final int TRACE_LEVEL_LOW = 1;
    
    /**
    * Property TRACE_LEVEL_NONE
    *
    */
    public static final int TRACE_LEVEL_NONE = 0;
    
    /**
    * Property TraceLevel
    *
    */
    private transient int __m_TraceLevel;
    
    /**
    * Property WRAPPER_EXCEPTION
    *
    */
    private static final String WRAPPER_EXCEPTION = "com.tangosol.util.WrapperException";
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("ClassInfo", ClassGenerator$ClassInfo.get_CLASS());
        }
    
    // Default constructor
    public ClassGenerator()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ClassGenerator(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setDebugInfo(true);
            setGenerateListing(true);
            setOptimizeDiscardedChildren(true);
            setOptimizePrivateAccessors(true);
            setStoreResult(true);
            setTraceLevel(0);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        
        // state initialization: private properties
        try
            {
            __m_CachedIntegrators = new com.tangosol.util.StringTable();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ClassGenerator();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/ClassGenerator".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.Dev.Compiler.Integrator;
        // import Component.Dev.Design;
        // import Component.Dev.Storage;
        // import com.tangosol.dev.assembler.Aaload;
        // import com.tangosol.dev.assembler.Aastore;
        // import com.tangosol.dev.assembler.AccessFlags;
        // import com.tangosol.dev.assembler.Aconst;
        // import com.tangosol.dev.assembler.Aload;
        // import com.tangosol.dev.assembler.Anewarray;
        // import com.tangosol.dev.assembler.Areturn;
        // import com.tangosol.dev.assembler.Arraylength;
        // import com.tangosol.dev.assembler.Astore;
        // import com.tangosol.dev.assembler.Athrow;
        // import com.tangosol.dev.assembler.Attribute;
        // import com.tangosol.dev.assembler.Avar;
        // import com.tangosol.dev.assembler.Baload;
        // import com.tangosol.dev.assembler.Bastore;
        // import com.tangosol.dev.assembler.Begin;
        // import com.tangosol.dev.assembler.Bnewarray;
        // import com.tangosol.dev.assembler.Caload;
        // import com.tangosol.dev.assembler.Case;
        // import com.tangosol.dev.assembler.Castore;
        // import com.tangosol.dev.assembler.Catch;
        // import com.tangosol.dev.assembler.Checkcast;
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.dev.assembler.Cnewarray;
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.Constant;
        // import com.tangosol.dev.assembler.ConstantPool;
        // import com.tangosol.dev.assembler.Constants;
        // import com.tangosol.dev.assembler.ConstantValueAttribute;
        // import com.tangosol.dev.assembler.D2f;
        // import com.tangosol.dev.assembler.D2i;
        // import com.tangosol.dev.assembler.D2l;
        // import com.tangosol.dev.assembler.Dadd;
        // import com.tangosol.dev.assembler.Daload;
        // import com.tangosol.dev.assembler.Dastore;
        // import com.tangosol.dev.assembler.Dcmpg;
        // import com.tangosol.dev.assembler.Dcmpl;
        // import com.tangosol.dev.assembler.Dconst;
        // import com.tangosol.dev.assembler.Ddiv;
        // import com.tangosol.dev.assembler.DeprecatedAttribute;
        // import com.tangosol.dev.assembler.Dload;
        // import com.tangosol.dev.assembler.Dmul;
        // import com.tangosol.dev.assembler.Dneg;
        // import com.tangosol.dev.assembler.Dnewarray;
        // import com.tangosol.dev.assembler.DoubleConstant;
        // import com.tangosol.dev.assembler.Drem;
        // import com.tangosol.dev.assembler.Dreturn;
        // import com.tangosol.dev.assembler.Dstore;
        // import com.tangosol.dev.assembler.Dsub;
        // import com.tangosol.dev.assembler.Dup;
        // import com.tangosol.dev.assembler.Dup2;
        // import com.tangosol.dev.assembler.Dup2_x1;
        // import com.tangosol.dev.assembler.Dup2_x2;
        // import com.tangosol.dev.assembler.Dup_x1;
        // import com.tangosol.dev.assembler.Dup_x2;
        // import com.tangosol.dev.assembler.Dvar;
        // import com.tangosol.dev.assembler.End;
        // import com.tangosol.dev.assembler.ExceptionsAttribute;
        // import com.tangosol.dev.assembler.F2d;
        // import com.tangosol.dev.assembler.F2i;
        // import com.tangosol.dev.assembler.F2l;
        // import com.tangosol.dev.assembler.Fadd;
        // import com.tangosol.dev.assembler.Faload;
        // import com.tangosol.dev.assembler.Fastore;
        // import com.tangosol.dev.assembler.Fcmpg;
        // import com.tangosol.dev.assembler.Fcmpl;
        // import com.tangosol.dev.assembler.Fconst;
        // import com.tangosol.dev.assembler.Fdiv;
        // import com.tangosol.dev.assembler.Field;
        // import com.tangosol.dev.assembler.FieldConstant;
        // import com.tangosol.dev.assembler.Fload;
        // import com.tangosol.dev.assembler.FloatConstant;
        // import com.tangosol.dev.assembler.Fmul;
        // import com.tangosol.dev.assembler.Fneg;
        // import com.tangosol.dev.assembler.Fnewarray;
        // import com.tangosol.dev.assembler.Frem;
        // import com.tangosol.dev.assembler.Freturn;
        // import com.tangosol.dev.assembler.Fstore;
        // import com.tangosol.dev.assembler.Fsub;
        // import com.tangosol.dev.assembler.Fvar;
        // import com.tangosol.dev.assembler.Getfield;
        // import com.tangosol.dev.assembler.Getstatic;
        // import com.tangosol.dev.assembler.Goto;
        // import com.tangosol.dev.assembler.GuardedSection;
        // import com.tangosol.dev.assembler.I2b;
        // import com.tangosol.dev.assembler.I2c;
        // import com.tangosol.dev.assembler.I2d;
        // import com.tangosol.dev.assembler.I2f;
        // import com.tangosol.dev.assembler.I2l;
        // import com.tangosol.dev.assembler.I2s;
        // import com.tangosol.dev.assembler.Iadd;
        // import com.tangosol.dev.assembler.Iaload;
        // import com.tangosol.dev.assembler.Iand;
        // import com.tangosol.dev.assembler.Iastore;
        // import com.tangosol.dev.assembler.Iconst;
        // import com.tangosol.dev.assembler.Idiv;
        // import com.tangosol.dev.assembler.Ifeq;
        // import com.tangosol.dev.assembler.Ifge;
        // import com.tangosol.dev.assembler.Ifgt;
        // import com.tangosol.dev.assembler.Ifle;
        // import com.tangosol.dev.assembler.Iflt;
        // import com.tangosol.dev.assembler.Ifne;
        // import com.tangosol.dev.assembler.Ifnonnull;
        // import com.tangosol.dev.assembler.Ifnull;
        // import com.tangosol.dev.assembler.If_acmpeq;
        // import com.tangosol.dev.assembler.If_acmpne;
        // import com.tangosol.dev.assembler.If_icmpeq;
        // import com.tangosol.dev.assembler.If_icmpge;
        // import com.tangosol.dev.assembler.If_icmpgt;
        // import com.tangosol.dev.assembler.If_icmple;
        // import com.tangosol.dev.assembler.If_icmplt;
        // import com.tangosol.dev.assembler.If_icmpne;
        // import com.tangosol.dev.assembler.Iinc;
        // import com.tangosol.dev.assembler.Iload;
        // import com.tangosol.dev.assembler.Imul;
        // import com.tangosol.dev.assembler.Ineg;
        // import com.tangosol.dev.assembler.Inewarray;
        // import com.tangosol.dev.assembler.InnerClass;
        // import com.tangosol.dev.assembler.InnerClassesAttribute;
        // import com.tangosol.dev.assembler.Instanceof;
        // import com.tangosol.dev.assembler.IntConstant;
        // import com.tangosol.dev.assembler.InterfaceConstant;
        // import com.tangosol.dev.assembler.Invokeinterface;
        // import com.tangosol.dev.assembler.Invokespecial;
        // import com.tangosol.dev.assembler.Invokestatic;
        // import com.tangosol.dev.assembler.Invokevirtual;
        // import com.tangosol.dev.assembler.Ior;
        // import com.tangosol.dev.assembler.Irem;
        // import com.tangosol.dev.assembler.Ireturn;
        // import com.tangosol.dev.assembler.Ishl;
        // import com.tangosol.dev.assembler.Ishr;
        // import com.tangosol.dev.assembler.Istore;
        // import com.tangosol.dev.assembler.Isub;
        // import com.tangosol.dev.assembler.Iushr;
        // import com.tangosol.dev.assembler.Ivar;
        // import com.tangosol.dev.assembler.Ixor;
        // import com.tangosol.dev.assembler.Jsr;
        // import com.tangosol.dev.assembler.L2d;
        // import com.tangosol.dev.assembler.L2f;
        // import com.tangosol.dev.assembler.L2i;
        // import com.tangosol.dev.assembler.Label;
        // import com.tangosol.dev.assembler.Ladd;
        // import com.tangosol.dev.assembler.Laload;
        // import com.tangosol.dev.assembler.Land;
        // import com.tangosol.dev.assembler.Lastore;
        // import com.tangosol.dev.assembler.Lcmp;
        // import com.tangosol.dev.assembler.Lconst;
        // import com.tangosol.dev.assembler.Ldiv;
        // import com.tangosol.dev.assembler.LineNumberTableAttribute;
        // import com.tangosol.dev.assembler.Lload;
        // import com.tangosol.dev.assembler.Lmul;
        // import com.tangosol.dev.assembler.Lneg;
        // import com.tangosol.dev.assembler.Lnewarray;
        // import com.tangosol.dev.assembler.LocalVariableTableAttribute;
        // import com.tangosol.dev.assembler.LongConstant;
        // import com.tangosol.dev.assembler.Lookupswitch;
        // import com.tangosol.dev.assembler.Lor;
        // import com.tangosol.dev.assembler.Lrem;
        // import com.tangosol.dev.assembler.Lreturn;
        // import com.tangosol.dev.assembler.Lshl;
        // import com.tangosol.dev.assembler.Lshr;
        // import com.tangosol.dev.assembler.Lstore;
        // import com.tangosol.dev.assembler.Lsub;
        // import com.tangosol.dev.assembler.Lushr;
        // import com.tangosol.dev.assembler.Lvar;
        // import com.tangosol.dev.assembler.Lxor;
        // import com.tangosol.dev.assembler.Method;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.Monitorenter;
        // import com.tangosol.dev.assembler.Monitorexit;
        // import com.tangosol.dev.assembler.Multianewarray;
        // import com.tangosol.dev.assembler.New;
        // import com.tangosol.dev.assembler.Nop;
        // import com.tangosol.dev.assembler.Op;
        // import com.tangosol.dev.assembler.OpArray;
        // import com.tangosol.dev.assembler.OpBranch;
        // import com.tangosol.dev.assembler.OpConst;
        // import com.tangosol.dev.assembler.OpDeclare;
        // import com.tangosol.dev.assembler.OpLoad;
        // import com.tangosol.dev.assembler.OpStore;
        // import com.tangosol.dev.assembler.OpSwitch;
        // import com.tangosol.dev.assembler.OpVariable;
        // import com.tangosol.dev.assembler.Pop;
        // import com.tangosol.dev.assembler.Pop2;
        // import com.tangosol.dev.assembler.Putfield;
        // import com.tangosol.dev.assembler.Putstatic;
        // import com.tangosol.dev.assembler.RefConstant;
        // import com.tangosol.dev.assembler.Ret;
        // import com.tangosol.dev.assembler.Return;
        // import com.tangosol.dev.assembler.Rstore;
        // import com.tangosol.dev.assembler.Rvar;
        // import com.tangosol.dev.assembler.Saload;
        // import com.tangosol.dev.assembler.Sastore;
        // import com.tangosol.dev.assembler.SignatureConstant;
        // import com.tangosol.dev.assembler.Snewarray;
        // import com.tangosol.dev.assembler.SourceFileAttribute;
        // import com.tangosol.dev.assembler.StringConstant;
        // import com.tangosol.dev.assembler.Swap;
        // import com.tangosol.dev.assembler.Switch;
        // import com.tangosol.dev.assembler.SyntheticAttribute;
        // import com.tangosol.dev.assembler.Tableswitch;
        // import com.tangosol.dev.assembler.Try;
        // import com.tangosol.dev.assembler.UtfConstant;
        // import com.tangosol.dev.assembler.VMStructure;
        // import com.tangosol.dev.assembler.Znewarray;
        // import com.tangosol.dev.compiler.Compiler;
        // import com.tangosol.dev.compiler.CompilerErrorInfo;
        // import com.tangosol.dev.compiler.CompilerException;
        // import com.tangosol.dev.compiler.Context;
        // import com.tangosol.dev.compiler.Locator;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.CompilePlan;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Implementation;
        // import com.tangosol.dev.component.Integration;
        // import com.tangosol.dev.component.Interface;
        // import com.tangosol.dev.component.Parameter;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.ReturnValue;
        // import com.tangosol.util.WrapperException;
        

        }
    
    // Declared at the super level
    /**
    * This method is a very special one. If implemented (even with a trivial
    * implementation "super._init()"), the class generation will make sure this
    * script is called right after the component allocation has been made but
    * prior to any state initialization (except the constant properties that
    * are "inlined"). This gives the component a chance to stop or defer
    * initalization by not calling the super.
    * Very important note: this method is very similar to a Java constructor:
    * during construction it's only called at the level where it's declared.
    * However, this method could be called directly to reset the state of the
    * component (given the component itself or any of its super components do
    * have an implementation).
    * 
    * There is an analogous initialization methods that you can declare for any
    * integrating component:
    * 
    *     void _initFeed(<parameters>)
    * 
    * where <parameters> could be empty.
    * 
    * If such a method is declared, the class generation doesn't initialize the
    * component's state during _init()'s call to it's super.  Instead, state
    * initialization is performed when the _initFeed(<parameters>) script
    * call's it's super.
    * 
    * Currently, there are two ways this is being used.  The first is when the
    * integrated class doesn't have a default constructor, but could be
    * constructed with a constant (virtual or java).  This is done by
    * implementing _init() to call the appropriate _initFeed.  For example,
    * _init() would loook like:
    * 
    *     _initFeed(getVirtualConstantValue(), OTHER_CONSTANT);
    * 
    * The other use is to allow the script allocating the component to create
    * to corresponding feed directly with an explicit call.   For example:
    * 
    *     MyComponent myc = new MyComponent();
    *     myc._initFeed(aValue);
    * 
    * See generated java listings for implementation details.
    */
    public void _init()
        {
        super._init();
        }
    
    /**
    * Helper that adds the parameter variables to the current code segment.
    */
    public com.tangosol.dev.assembler.OpDeclare[] addBehaviorParameters(com.tangosol.dev.component.Behavior bhvr)
        {
        CodeAttribute code      = getCode();
        int           cntParams = bhvr.getParameterCount();
        OpDeclare[]   v_params  = new OpDeclare[cntParams];
        
        for (int i = 0; i < cntParams; i++)
            {
            Parameter param = bhvr.getParameter(i);
        
            v_params[i] = getDeclareVarOp(param.getDataType(), param.getName());
            code.add(v_params[i]);
            }
        return v_params;
        }
    
    /**
    * Add opcodes and listing for:
    * 
    *     catch (excpetion e)
    *         {
    *         throw new WrapperException(e);
    *         }
    */
    public void addCatchAndThrowWrapper(com.tangosol.dev.assembler.Try lbl_try, String sException)
        {
        CodeAttribute code = getCode();
        
        Label lbl_catch = new Label();
        
        code.add(new Catch(lbl_try,
            new ClassConstant(sException), lbl_catch));
        
        code.add(lbl_catch);
        
        println("catch (" + sException + " e)");
        
        addThrowWrapper();

        }
    
    /**
    * Add opcodes and listing for each passed exception:
    * 
    *     catch (excpetion e)
    *         {
    *         throw new WrapperException(e);
    *         }
    * 
    * No attempt is made to assure that the exceptions are ordered correctly.
    */
    public void addCatchesAndThrowWrappers(com.tangosol.dev.assembler.Try lbl_try, String[] asExceptions)
        {
        CodeAttribute code = getCode();
        
        int     cExceptions  = asExceptions.length;
        Label[] albl_catches = new Label[cExceptions];
        
        // First generate the catches
        
        for (int i = 0; i < cExceptions; ++i)
            {
            String sException = asExceptions[i];
            if (sException != null)
                {
                Label lbl = new Label();
                albl_catches[i] = lbl;
                code.add(new Catch(lbl_try, new ClassConstant(sException), lbl));
                }
            }
        
        // Then generate the catch code itself
        
        for (int i = 0; i < cExceptions; ++i)
            {
            Label lbl = albl_catches[i];
            if (lbl != null)
                {
                code.add(lbl);
                println("catch (" + asExceptions[i] + " e)");
                addThrowWrapper();
                }
            }

        }
    
    /**
    * Generate a child initializer.
    * 
    * @param cdChild     the child component
    * @param sLocalName  local child name (in the scope of the parent
    * component)
    * @param vL_this  current "this" variable reference
    * @param compilePlan  current compile plan
    */
    private void addChildClassRegistration(com.tangosol.dev.component.Component cdChild, String sLocalName, com.tangosol.dev.component.CompilePlan compilePlan)
        {
        String sFullName = cdChild.getQualifiedName();
        
        if (compilePlan.isDiscardable(sFullName))
            {
            sFullName = compilePlan.getSuperName(sFullName);
            }
        
        CodeAttribute  code        = getCode();
        String         sChildClass = DataType.getComponentClassName(sFullName);
        FieldConstant  cR_map      = getClassFile().getFieldConstant(FLD_CHILDREN);
        StringConstant cL_sName    = new StringConstant(sLocalName);
        
        code.add(new Getstatic(cR_map));
        code.add(new Aconst(cL_sName));
        MethodConstant cM_getClass = new MethodConstant(sChildClass,
            "get_CLASS", "()Ljava/lang/Class;");
        code.add(new Invokestatic(cM_getClass));
        MethodConstant cM_put = new MethodConstant(LISTMAP_CLASS,
            "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
        code.add(new Invokevirtual(cM_put));
        
        println(FLD_CHILDREN + ".put(\"" + sLocalName + "\", "
            + formatClass(sChildClass) + ".get_CLASS());");
        }
    
    /**
    * Recursively scan the children and fill in the "alias" imports map.
    */
    private void addChildImports(com.tangosol.dev.component.Component cd, com.tangosol.util.StringTable mapAlias, com.tangosol.util.StringTable mapConflict)
        {
        String[] asChildren = cd.getChildren();
        for (int iChild = 0; iChild < asChildren.length; iChild++)
            {
            Component cdChild = cd.getChild(asChildren[iChild]);
        
            if (cdChild == null)
                {
                // removed child
                continue;
                }
            String sNameQ = cdChild.getQualifiedName();             // "Component.A$B$C"
            String sNameU = sNameQ.substring(sNameQ.indexOf('$'));  // "$B$C"
        
            DataType dtChild = DataType.getComponentType(sNameQ);
            while (true)
                {
                if (mapAlias.contains(sNameU))
                    {
                    // ambiguios name -- remove
                    mapAlias.remove(sNameU);
                    mapConflict.add(sNameU);
                    }
                else if (!mapConflict.contains(sNameU))
                    {
                    mapAlias.put(sNameU, dtChild);
                    }
                int iPos = sNameU.indexOf('$', 1);
                if (iPos == -1)
                    {
                    break;
                    }
                sNameU = sNameU.substring(iPos);
                }
            
            addChildImports(cdChild, mapAlias, mapConflict);
            }
        }
    
    /**
    * Generate a child initializer.
    * 
    * @param cdChild     the child component
    * @param sLocalName  local child name (in the scope of the parent
    * component)
    * @param vL_this  current "this" variable reference
    * @param compilePlan  current compile plan
    */
    private void addChildInitializer(com.tangosol.dev.component.Component cdChild, String sLocalName, com.tangosol.dev.assembler.Avar vL_this, com.tangosol.dev.component.CompilePlan compilePlan)
            throws com.tangosol.dev.component.ComponentException
        {
        if (cdChild.isStatic())
            {
            // no initialization for static children
            return;
            }
        
        String sFullName = cdChild.getQualifiedName();
        
        if (compilePlan.isDiscardable(sFullName))
            {
            sFullName = compilePlan.getSuperName(sFullName);
            }
        
        String         sChildClass = DataType.getComponentClassName(sFullName);
        StringConstant cL_sName    = new StringConstant(sLocalName);
        
        CodeAttribute  code = getCode();
        
        code.add(new Aload(vL_this));                     // this[.addChild]
        code.add(new New(new ClassConstant(sChildClass)));// new <child>
        code.add(new Dup());
        code.add(new Aconst(cL_sName));                   // sName
        code.add(new Aload(vL_this));                     // compParent
        code.add(new Iconst(new IntConstant(1)));         // true
        MethodConstant cM_new = new MethodConstant(sChildClass,
            CONSTRUCTOR_NAME, INIT_CONSTRUCTOR_SIG);
        code.add(new Invokespecial(cM_new));
        code.add(new Aconst(cL_sName));
        
        MethodConstant cM = addMethodCall(getKnownBehavior(BHVR_ADD_CHILD));
        
        println(cM.getName() + "(new " + formatClass(sChildClass) +
            "(\"" + sLocalName + "\", this, true), \"" + sLocalName + "\");");
        }
    
    /**
    * Adds a fragment of code that calls Class.forName, catching the checked
    * exception ClassNotFoundException and rethrowing it as the unchecked
    * exception NoClassDefFoundError.  The class name is converted to be '/'
    * delimited prior to be put in the constant pool so if the class name is
    * relocatable (starts with "_package/") an appropriate string constant will
    * be "relocated" at packaging time.  The reason we "inline" the code
    * generation rather then calling into a helper is that Class.forName uses
    * the callee's class loader to load the specified class.
    * 
    * @param sClz  fully qualified name of the desired class
    * @param cL_clz  local variable of java.lang.Class type to assign to the
    * desired class instance
    * 
    * @see Class#forName
    */
    public void addClassForName(String sClz, com.tangosol.dev.assembler.Avar vL_clz)
        {
        CodeAttribute code = getCode();
        
        Try   lbl_try   = new Try();
        Label lbl_catch = new Label();
        Label lbl_done  = new Label();
        
        code.add(lbl_try);
        
        println("try");
        
        BeginScope();
            {
            sClz = sClz.replace('.', '/');
        
            code.add(new Aconst(new StringConstant(sClz)));
            MethodConstant cM_replace = new MethodConstant("java.lang.String",
                "replace","(CC)Ljava.lang.String;");
            code.add(new Iconst((int) '/'));
            code.add(new Iconst((int) '.'));
            code.add(new Invokevirtual(cM_replace));
            MethodConstant cM_forName = new MethodConstant("java.lang.Class",
                "forName", "(Ljava.lang.String;)Ljava.lang.Class;");
            code.add(new Invokestatic(cM_forName));
            code.add(new Astore(vL_clz));
            code.add(new Goto(lbl_done));
            
            println(vL_clz.getVariableName() + " = Class.forName(\"" + sClz +
                "\".replace('/', '.'));");
            }
        EndScope();
        
        code.add(new Catch(lbl_try,
            new ClassConstant("java.lang.ClassNotFoundException"), lbl_catch));
        
        println("catch (ClassNotFoundException e)");
        
        code.add(lbl_catch);
        BeginScope();
            {
            Avar vL_e = new Avar("e");
            code.add(vL_e);
        
            code.add(new Astore(vL_e));
            addThrow("java.lang.NoClassDefFoundError", null, vL_e);
            }
        EndScope();
        
        code.add(lbl_done);
        }
    
    /**
    * Generate a field initializer for a given constant property (Java Constant
    * or Virtual Constant)
    *                                                            
    * @param prop  the property
    * @param vL_this  current "this" variable reference
    * 
    * @see Component.Dev.Design#addConstantInitializer
    */
    private void addConstantInitializer(com.tangosol.dev.component.Property prop, com.tangosol.dev.assembler.Avar vL_this)
        {
        _assert(prop.getIndexed() != Property.PROP_INDEXEDONLY,
             "Indexed only constant is not initializable " + prop);
        
        ClassFile     clzThis = getClassFile();
        CodeAttribute code    = getCode();
        String        sField  = getFieldName(prop);
        Field         field   = clzThis.getField(sField); // must already be there
        boolean       fStatic = field.isStatic();
        
        if (field.isConstant())
            {
            // "static final" fields with a constant attribute
            // (aka static Java Constants of an intrinsic+ type)
            // don't need to be initialized.
            // However, if a final field with constant attribute is not "static" 
            // initialization is still required
            if (fStatic)
                {
                return;
                }
            else
                {
                // avoid a duplicate assignment in the listing
                print("// ");
                }
            }
        
        FieldConstant cR_field = clzThis.getFieldConstant(sField);
        
        if (isFromIntegration(prop))
            {
            getIntegrator().addConstantInitializer(this, prop, vL_this, sField, cR_field);
            }
        else
            {
            int      nIndexed = prop.getIndexed();
            DataType dtProp   = prop.getDataType();
            Object   oValue   = prop.isNoValue() ?
                                    (nIndexed == Property.PROP_SINGLE ?
                                        getDefaultValue(dtProp) : null) :
                                    prop.getValue();
        
            if (!fStatic)
                {
                code.add(new Aload(vL_this));
                }
        
             Design designInfo = Design.getDesignInfo(prop);
             designInfo.addConstantInitializer(this, oValue,
                nIndexed == Property.PROP_SINGLE ? dtProp : dtProp.getArrayType(),
                sField + " = ", ";");
        
            code.add(fStatic ?
                (Op) new Putstatic(cR_field) : (Op) new Putfield(cR_field));
        
            println();
            }
        }
    
    /**
    * Add an opcode for the default value return for the specified data type.
    */
    public void addDefaultReturn(com.tangosol.dev.component.DataType dtRet)
        {
        CodeAttribute code = getCode();
        
        if (dtRet == DataType.VOID)
            {
            code.add(new Return());
            }
        else
            {
            Constant constant = getConstant(getDefaultValue(dtRet), dtRet);
        
            code.add(getLoadConstOp(constant));
            code.add(getReturnOp(dtRet));
        
            println("return " + formatConstant(constant, dtRet) + ';');
            }
        }
    
    /**
    * Adds the specified error to the error list filtering out duplicate errors.
    */
    public void addError(com.tangosol.util.ErrorList$Item error)
        {
        // import com.tangosol.util.ErrorList;
        // import java.util.Iterator;
        
        ErrorList errlist = getErrorList();
        for (Iterator iter = errlist.iterator(); iter.hasNext();)
            {
            if (iter.next().equals(error))
                {
                // duplicate error
                return;
                }
            }
        
        errlist.add(error);
        }
    
    /**
    * Adds a specified error to the error list.
    */
    public void addError(String sMsg)
        {
        // import com.tangosol.util.ErrorList$Item as ErrorInfo;
        // import com.tangosol.util.ErrorList$Constants as Severety;
        
        addError(new ErrorInfo(Severety.ERROR, sMsg));
        }
    
    /**
    * Add the list of exceptions to the method and to the listing.
    * 
    * This assumes that the listing is currently at the end of the method
    * declaration with a pending end of line and will leave the listing with a
    * pending end of line.
    */
    public void addExceptionsToMethod(com.tangosol.dev.assembler.Method method, String[] asExceptions)
        {
        boolean fFirst = true;
        for (int i = 0; i < asExceptions.length; ++i)
            {
            String sException = asExceptions[i];
            if (sException != null)
                {
                method.addException(sException);
                if (fFirst)
                    {
                    println();
                    print(TAB + TAB + "throws ");
                    fFirst = false;
                    }
                else
                    {
                    println(",");
                    print(TAB + TAB + "       ");
                    }
                print(sException);
                }
            }
        }
    
    /**
    * Adds a specified fatal error to the error list.
    */
    public void addFatalError(String sMsg)
        {
        // import com.tangosol.util.ErrorList$Item as ErrorInfo;
        // import com.tangosol.util.ErrorList$Constants as Severety;
        
        addError(new ErrorInfo(Severety.FATAL, sMsg));
        }
    
    /**
    * Add the "dispatch router call".
    */
    private void addListenerRouter(com.tangosol.dev.assembler.Method methodRouter, com.tangosol.dev.assembler.Avar vL_this, com.tangosol.dev.assembler.Avar vL_ls)
        {
        CodeAttribute code = getCode();
        
        code.add(new Aload(vL_ls));
        MethodConstant cM_listeners = new MethodConstant(LISTENERS_CLASS,
            "listeners", "()[L" + LISTENER_IFACE + ';');
        code.add(new Invokevirtual(cM_listeners)); // optimize with Invokespecial?
        code.add(new Arraylength());
        Label lbl_endif_lengthNe0 = new Label();
        code.add(new Ifne(lbl_endif_lengthNe0));
        
        println("if (" + vL_ls.getVariableName() + ".listeners().length == 0)");
        
        BeginScope();
            {
            code.add(new Aload(vL_this));
            code.add(new Aload(vL_this)); 
            MethodConstant cM_route = new MethodConstant(getClassFile().getName(),
                methodRouter.getName(), methodRouter.getType());
            code.add(new Invokespecial(cM_route)); // the router is private
        
            println(methodRouter.getName() + "(this);");
            }
        EndScope();
        
        code.add(lbl_endif_lengthNe0);
        }
    
    /**
    * Helper that loads the specified parameters to make a method call.
    */
    public void addLoadParameters(com.tangosol.dev.component.Behavior bhvr, com.tangosol.dev.assembler.OpDeclare[] v_params)
        {
        CodeAttribute code      = getCode();
        int           cntParams = v_params.length;
        
        _assert(cntParams == bhvr.getParameterCount());
        
        for (int i = 0; i < cntParams; i++)
            {
            OpDeclare var = v_params[i];
        
            code.add(var.getLoadOp());
        
            if (i > 0)
                {
                print(", ");
                }
            print(var.getVariableName());
            }
        }
    
    /**
    * Adds a method call for a given behavior (assuming all the parameters are
    * already loaded on the VM stack)
    * 
    * @param bhvr  the behavior
    * 
    * The rules for "class" and "opcode" are:
    *     If the behavior is static  -- class is the closest super with an
    * implementation, opcode is Invokestatic.
    *     If the behavior is final -- class is the declaration level, opcode is
    * Invokespecial (given the opitimization is on)
    *     If the behavior is private -- class is "this", opcode is Invokespecial
    */
    public com.tangosol.dev.assembler.MethodConstant addMethodCall(com.tangosol.dev.component.Behavior bhvr)
        {
        MethodConstant cM_method = findMethod(bhvr, false);
        
        if (bhvr.isStatic())
            {
            getCode().add(new Invokestatic(cM_method));
            }
        else
            {
            getCode().add(bhvr.getAccess() == Behavior.ACCESS_PRIVATE ?
                (Op) new Invokespecial(cM_method) : (Op) new Invokevirtual(cM_method));
            }
        
        return cM_method;

        }
    
    /**
    * Generate a property initializer (either m_Prop assignment or a setProp
    * call)
    * 
    * @param prop     the property
    * @param vL_this  current "this" variable reference (null for static
    * properties)
    * @param fPrivate (meaningful only for non-static properties); if true
    * specifies that only the private setters have to be initialized; if false
    * specifies that only protected and public setters have to be initialized
    * 
    * @see Component.Dev.Design#addConstantInitializer
    */
    private void addPropertyInitializer(com.tangosol.dev.component.Property prop, com.tangosol.dev.assembler.Avar vL_this, boolean fPrivate)
            throws com.tangosol.dev.component.ComponentException
        {
        _assert((prop.getDirection() & Property.DIR_IN) != 0 &&
                !prop.isNoValue() &&
                 prop.getIndexed() != Property.PROP_INDEXEDONLY,
             "Property is not initializable " + prop);
        
        boolean  fStatic    = prop.isStatic();
        Behavior bhvrSetter = getSetter(prop);
        
        CodeAttribute  code = getCode();
        
        if (!fStatic)
            {
            // check for private (if fPrivate flag is set)
            // or public/protected (if fPrivate flag is not set)
            if (fPrivate ^ bhvrSetter.getAccess() == Behavior.ACCESS_PRIVATE)
                {
                return;
                }
        
            code.add(new Aload(vL_this));
            }
        
        boolean fOptimized = isAccessorOptimizedOut(bhvrSetter);
        
        DataType dtProp   = prop.getDataType();
        Object   oValue   = prop.getValue();
        int      nIndexed = prop.getIndexed();
        
        Design designInfo = Design.getDesignInfo(prop);
        designInfo.addConstantInitializer(this, oValue,
            nIndexed == Property.PROP_SINGLE ? dtProp : dtProp.getArrayType(),
            fOptimized ? getFieldName(prop) + " = " : bhvrSetter.getName() + "(",
            fOptimized ? ";"                        : ");"
            );
        
        addSetPropertyCall(prop);
        
        println();

        }
    
    /**
    * Adds a set property call for a given behavior (assuming the value is
    * already loaded on the VM stack)
    * 
    * @param prop  the property
    */
    public void addSetPropertyCall(com.tangosol.dev.component.Property prop)
            throws com.tangosol.dev.component.ComponentException
        {
        CodeAttribute code       = getCode();
        Behavior      bhvrSetter = getSetter(prop);
        boolean       fOptimized = isAccessorOptimizedOut(bhvrSetter);
        
        if (fOptimized)
            {
            String        sField   = getFieldName(prop);
            FieldConstant cR_field = getClassFile().getFieldConstant(sField);
        
            _assert(cR_field != null);
        
            code.add(prop.isStatic() ?
                (Op) new Putstatic(cR_field) : (Op) new Putfield (cR_field));
            }
        else
            {
            addMethodCall(bhvrSetter);
            }
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    /**
    * Create a synthetic field required by the context.
    * 
    * @return a new synthetic field
    */
    public com.tangosol.dev.assembler.Field addSyntheticField(com.tangosol.dev.component.DataType dt)
        {
        // generate unique ID for the synthetic member
        int cSynths;
        synchronized (this)
            {
            cSynths = getSynthFieldCount();
            setSynthFieldCount(cSynths + 1);
            }
        String sField = "__sf" + cSynths;
        
        // create the synthetic member
        Field field = getClassFile().addField(sField, resolveJVMSignature(dt));
        field.setSynthetic(true);
        field.setPrivate();
        
        return field;
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    /**
    * Create a synthetic method required by the context.
    * 
    * @param adt  an array of data types, [0] for the return type and [1..n]
    * for the parameters
    * 
    * @return a new synthetic field
    */
    public com.tangosol.dev.assembler.Method addSyntheticMethod(com.tangosol.dev.component.DataType[] adt)
        {
        // generate unique ID for the synthetic member
        int cSynths;
        synchronized (this)
            {
            cSynths = getSynthMethodCount();
            setSynthMethodCount(cSynths + 1);
            }
        String sMethod = "__sm" + cSynths;
        
        // generate method signature
        StringBuffer sb = new StringBuffer("(");
        int cParams = adt.length - 1;
        for (int i = 1; i <= cParams; ++i)
            {
            sb.append(resolveJVMSignature(adt[i]));
            }
        sb.append(')');
        sb.append(resolveJVMSignature(adt[0]));
        String sSig = sb.toString();
        
        // create the synthetic member
        Method method = getClassFile().addMethod(sMethod, sSig);
        method.setSynthetic(true);
        method.setPrivate();
        
        return method;
        }
    
    /**
    * Add opcodes for "throw new <sExcClz>(<sMsg>)" or "throw new
    * <sExcClz>(<exception>.getMessage())" 
    */
    public void addThrow(String sExcClz, String sMsg, com.tangosol.dev.assembler.Avar vL_exception)
        {
        CodeAttribute code = getCode();
        
        code.add(new New(new ClassConstant(sExcClz)));
        code.add(new Dup());
        
        print("throw new " + formatClass(sExcClz) + '(');
        
        if (sMsg != null)
            {
            code.add(new Aconst(new StringConstant(sMsg)));
            print('"' + sMsg + '"');
            }
        else
            {
            code.add(new Aload(vL_exception));
            MethodConstant cM_getMessage = new MethodConstant("java.lang.Throwable",
                "getMessage", "()Ljava.lang.String;");
            code.add(new Invokevirtual(cM_getMessage));
        
            print(vL_exception.getVariableName() + ".getMessage()");
            }
        
        MethodConstant cM_new = new MethodConstant(sExcClz,
            CONSTRUCTOR_NAME, "(Ljava.lang.String;)V");
        code.add(new Invokespecial(cM_new));
        code.add(new Athrow());
        
        println(");");
        }
    
    /**
    * Add opcodes for "throw new WrapperException(e);".
    * 
    * Note: the exception reference must be on the stack.
    */
    public void addThrowWrapper()
        {
        CodeAttribute code = getCode();
        
        BeginScope();
            {
            Avar vL_e = new Avar("e");
            code.add(vL_e);
        
            code.add(new Astore(vL_e));
            
            println("// re-throw as a runtime exception");
        
            String sException = WRAPPER_EXCEPTION;
            
            code.add(new New(new ClassConstant(sException)));
            code.add(new Dup());
            code.add(new Aload(vL_e));
            MethodConstant cM_new = new MethodConstant(sException,
                CONSTRUCTOR_NAME, "(Ljava.lang.Throwable;)V");
            code.add(new Invokespecial(cM_new));
            code.add(new Athrow());
        
            println("throw new " + formatClass(sException) +
                '(' + vL_e.getVariableName() + ");");
            }
        EndScope();
        }
    
    /**
    * Adds a specified warning to the error list.
    */
    public void addWarning(String sMsg)
        {
        // import com.tangosol.util.ErrorList$Item as ErrorInfo;
        // import com.tangosol.util.ErrorList$Constants as Severety;
        
        addError(new ErrorInfo(Severety.WARNING, sMsg));
        }
    
    public void BeginIndent()
        {
        getIndent().append(TAB);
        
        println("{");
        }
    
    public void BeginScope()
        {
        getCode().add(new Begin());
        
        BeginIndent();
        }
    
    /**
    * Begin a new code segment and make it current.
    */
    public com.tangosol.dev.assembler.CodeAttribute BeginSegment(com.tangosol.dev.assembler.Method method)
        {
        CodeAttribute code = getCode();
        
        if (code != null)
            {
            throw new IllegalStateException(get_Name() + ".BeginSegment: " +
                "EndSegment is missing for " + code);
            }
        
        if (method != null)
            {
            code = method.getCode();
            setCode(code);
        
            code.add(new Begin());
            }
        
        setNextTempVariableNumber(0);
        
        BeginIndent();
        
        return code;
        }
    
    /**
    * Collect all the [constant] fields with the specified name for the
    * specified interface or any of its sub-interfaces
    * 
    * @param cdJcs an interface JCS
    * @param sName the field name
    * @param listResults a list of field constants
    * 
    * Note: this is analogous to findInterface() with the difference being that
    * there cannot be more than one match for a method signature and there
    * could be more than one match for a [constant] field.
    */
    private void collectInterfaceFields(com.tangosol.dev.component.Component cdJcs, String sName, java.util.List listResults)
        {
        Storage storage = getStorage();
        try
            {
            Property field = cdJcs.getProperty(sName);
            if (field == null
                || field.getAccess() == Property.ACCESS_PRIVATE
                || field.getAccess() == Property.ACCESS_PACKAGE)
                {
                return;
                }
        
            if (field.getExists() != Property.EXISTS_NOT
                && !field.isFromSuper()
                && !field.isFromTrait())
                {
                listResults.add(cdJcs.getName());
                return;
                }
        
            String[] asIface = cdJcs.getImplements();
            for (int i = 0, c = asIface.length; i < c; ++i)
                {
                String    sIface = asIface[i];
                Component clz    = storage.loadSignature(sIface);
                _assert(clz != null, "Missing JCS: " + sIface);
        
                collectInterfaceFields(clz, sName, listResults);
                }
            }
        catch (ComponentException e)
            {
            throw new WrapperException(e);
            }
        }
    
    /**
    * Compile the specified Component Definition.
    * 
    * Note: properties CD and Storage must be set prior to the call to this
    * method.
    */
    public boolean compile()
            throws com.tangosol.dev.component.ComponentException
        {
        // import com.tangosol.util.Base;
        // import com.tangosol.util.StringTable;
        // import java.util.ArrayList;
        // import java.util.Enumeration;
        // import java.util.Iterator;
        
        Component cdThis  = getCD();
        Storage   storage = getStorage();
        
        _assert(cdThis != null && cdThis.isComponent());
        _assert(storage != null);
        
        //////// 0) Prepare commonly used variables
        //_trace((new java.util.Date()).toString() + " --> 0) Begin class generation " + sThisComponentU);
        
        String sThisComponentQ = cdThis.getQualifiedName();      // Qualified
        String sThisClass      = DataType.getComponentClassName(sThisComponentQ);
        String sThisComponentU = formatClass(sThisClass);        // Unqualified
        
        boolean fThisAbstract  = cdThis.isResultAbstract();
        boolean fThisFinal     = cdThis.isFinal();
        boolean fThisGlobal    = cdThis.isGlobal();
        boolean fThisStatic    = cdThis.isStatic();
        boolean fThisRoot      = sThisComponentQ.equals(COMPONENT_ROOT);
        
        CompilePlan compilePlan = getCompilePlan();
        _assert(compilePlan != null);
        
        String    sSuperClass;
        Component cdSuper;
        if (fThisRoot)
            {
            sSuperClass = "java.lang.Object";
            cdSuper     = storage.loadSignature(sSuperClass);
            }
        else
            {
            String sSuperQ = compilePlan.getSuperName(sThisComponentQ);
            
            sSuperClass = DataType.getComponentClassName(sSuperQ);
            cdSuper     = getComponent(sSuperQ);
            }
        
        // specifies whether we need to hook into _init() and _initStatic()
        Behavior bhvrInit       = getKnownBehavior(BHVR_INIT);
        Behavior bhvrInitStatic = getKnownBehavior(BHVR_INIT_STATIC);
        
        boolean  fInitImpl       = bhvrInit      .getCallableImplementationCount() > 0;
        boolean  fInitStaticImpl = bhvrInitStatic.getCallableImplementationCount() > 0;
        
        // specifies whether there are any children classes to be registered
        boolean  fRegisterChildren = false;
        String[] asChildren        = cdThis.getChildren();
        
        for (int iChild = 0, cChildren = asChildren.length; iChild < cChildren; iChild++)
            {
            String    sChild  = asChildren[iChild];
            Component cdChild = cdThis.getChild(sChild);
        
            if (cdChild != null && cdChild.isStatic())
                {
                fRegisterChildren = true;
                break;
                }
            }
        
        //////// 1) "Integration" support preparation
        Integrator integrator          = findIntegrator(cdThis);
        Integrator effectiveIntegrator = integrator == null
                                         && (cdThis.getIntegration() != null
                                             || cdThis.isRemote()) ?
                                         findEffectiveIntegrator(cdThis) : integrator;
        setIntegrator(integrator);
        
        // specifies whether integration requires custom initialization support
        boolean fEffectiveCustomInits = false;
        
        // specifies whether there is a custom _init() on the effective integrator level
        boolean fEffectiveInitImpl = false;
        
        if (effectiveIntegrator != null)
            {
            Component cdEffective       = effectiveIntegrator.getCD();
            Behavior  bhvrEffectiveInit = cdEffective.getBehavior(BHVR_INIT);
        
            fEffectiveCustomInits = effectiveIntegrator.isCustomInits();
            fEffectiveInitImpl    = bhvrEffectiveInit.getCallableImplementationCount() > 0;
            }
        
        //////// 2) Class file creation
        
        if (fThisAbstract && !fThisGlobal && !cdThis.getParent().isResultAbstract())
            {
            throw new ComponentException(get_Name() + ".compile: " +
                "Cannot compile an abstract child " + sThisComponentQ +
                " of the concrete parent");
            }
        
        ClassFile clzThis = new ClassFile(sThisClass, sSuperClass, false);
        
        setClassFile(clzThis);
        
        clzThis.setPublic();
        clzThis.setAbstract(fThisAbstract);
        clzThis.setFinal   (fThisFinal);
        
        Component cdGlobalParent = cdThis.getGlobalParent();
        
        println("/* Class"                              );
        println("*     " + formatClass(sThisClass, true));
        println("*/"                                    );
        println();
        
        println("package " + formatClass(DataType.getComponentPackage(cdThis), true) + ';');
        println();
        
        // at the global component level create an import map of implicit aliases
        // that includes the "$Module" alias as well as all the chilren aliases
        // and add it to DefaultImport, so any newly constructed ScriptTarget will get it
        // (see #getSciptTarget)
        if (fThisGlobal)
            {
            StringTable mapImplicit = getImplicitImports();
            getDefaultImports().addAll(mapImplicit);
            }
        
        // collect all the imports "known by the component"
        // and put them to the Target (used later by a Context)
        // possibly overriding previousely declared ones
        StringTable mapImports = getComponentImports();
        getScriptTarget().getImports().putAll(mapImports);
        
        printImports(mapImports);
        
        // add class comments (it should be here for javadoc to pick up)
        String sDescr = getCD().getText();
        if (sDescr.length() > 0)
            {
            println("/**");
            println("* " + Base.breakLines(sDescr, 80, getIndent() + "* ", false));
            println("*/");
            }
        
        if (integrator != null)
            {
            integrator.addComments(this);
            }
        
        println("public "                               + 
                (fThisAbstract ? "abstract " : "")      +
                (fThisFinal    ? "final "    : "")      +
                "class " + sThisComponentU              );
        println(TAB + TAB + "extends    "               +
                formatClass(sSuperClass)                );
        
        //////// 3) Interfaces (Implements and Dispatches)
        
        String[] asThisImplements  = cdThis .getImplements();
        String[] asSuperImplements = cdSuper.getImplements();
        if (removeMatches(asThisImplements, asSuperImplements) != asSuperImplements.length)
            {
            // "thisImplements" list could only be a superset of "superImplements"
            throw new ComponentException(get_Name() + ".compile: " +
                "\"implements\" are out of sync");
            }
        
        String[] asThisDispatches  = cdThis .getDispatches();
        String[] asSuperDispatches = cdSuper.getDispatches();
        if (removeMatches(asThisDispatches, asSuperDispatches) != asSuperDispatches.length)
            {
            // "thisDispatches" list could only be a superset of "superDispatches"
            throw new ComponentException(get_Name() + ".compile: " +
                "\"dispatches\" are out of sync");
            }
        
        String[] asInterfaces  = new String[asThisImplements.length + asThisDispatches.length];
        int      cntInterfaces = 0;
        
        int cntImplements = 0;
        for (int i = 0, c = asThisImplements.length; i < c; i++)
            {
            String sImplement = asThisImplements[i];
            if (sImplement != null)
                {
                clzThis.addImplements(sImplement);
                cntImplements++;
        
                asInterfaces[cntInterfaces++] = sImplement;
                }
            }
        
        int cntDispatches = 0;
        for (int i = 0, c = asThisDispatches.length; i < c; i++)
            {
            String sDispatch = asThisDispatches[i];
            if (sDispatch != null)
                {
                clzThis.addImplements(sDispatch);
                cntDispatches++;
        
                asInterfaces[cntInterfaces++] = sDispatch;
                }
            }
        
        if (cntInterfaces > 0)
            {
            for (int i = 0; i < cntInterfaces; i++)
                {
                if (i == 0)
                    {
                    print(TAB + TAB + "implements ");
                    }
                else
                    {
                    println(",");
                    print(TAB + TAB + "           ");
                    }
                print(asInterfaces[i]);
                }
            println();
            }
        
        // we will need to know what is the closest "super" component with events
        Component cdDispatchBase = cdSuper;
        
        while (true)
            {
            String sSuperBase = cdDispatchBase.getSuperName();
            if (sSuperBase.length() == 0)
                {
                cdDispatchBase = null;
                break;
                }
        
            Component cdSuperBase = getComponent(sSuperBase);
        
            String[] asSuperBaseDispatches = cdSuperBase.getDispatches();
            if (asSuperBaseDispatches.length < asSuperDispatches.length)
                {
                // cdDispatchBase has declared events -- so it must have
                // the event initializer
                break;
                }
        
            cdDispatchBase = cdSuperBase;
            }
        
        //++++++++++  Beginning of the class body
        BeginSegment(null);
        
        //////// 4) Fields
        ///////     Only Java Constants, Virtual Constants of non-intrinsic+ type
        //////      and Standard properties could be backed up by the fields
        
        ArrayList apBackedByFieldStaticConstant      = new ArrayList();
        ArrayList apBackedByFieldInstanceConstant    = new ArrayList();
        ArrayList apDeclaredOrValueVirtualConstant   = new ArrayList();
        ArrayList apStaticNonIntegratedSettableValue = new ArrayList();
        ArrayList apInstanceNonPrivateSettableValue  = new ArrayList();
        ArrayList apInstancePrivateSettableValue     = new ArrayList();
        
        println("// Fields declarations");
        
        for (Enumeration enumProp = cdThis.getProperties(); enumProp.hasMoreElements();)
            {
            Property prop    = (Property) enumProp.nextElement();
            String   sField  = getFieldName(prop);
            DataType dtProp  = prop.getDataType();
            boolean  fStatic = prop.isStatic();
        
            if (prop.isDesignOnly())
                {
                // design-only properties are compiled out
                // (they don't have any accessors either)
                continue;
                }
        
            if ((prop.getDirection() & Property.DIR_IN) != 0 && !prop.isNoValue())
                {
                if (fStatic)
                    {
                    if (!prop.isFromSuper() && !isFromIntegration(prop))
                        {
                        apStaticNonIntegratedSettableValue.add(prop);
                        }
                    }
                else
                    {
                    // If property is from super, the setter may be not accessible
                    Behavior bhvrSetter = getSetter(prop);
                    if (bhvrSetter != null)
                        {
                        if (bhvrSetter.getAccess() == Behavior.ACCESS_PRIVATE)
                            {
                            apInstancePrivateSettableValue.add(prop);
                            }
                        else
                            {
                            apInstanceNonPrivateSettableValue.add(prop);
                            }
                        }
                    }
                }
        
            if (!prop.isFromSuper())
                {
                String sPropDescr = prop.getDescription();
                println();
                println("/**");
                println("* Property " + prop.getName());
                println("*");
                if (sPropDescr.length() > 0)
                    {
                    println("* " + Base.breakLines(sPropDescr, 80, getIndent() + "* ", false));
                    }
                println("*/");
                }
        
            if (prop.isStandardProperty())
                {
                if (prop.isFromSuper())
                    {
                    continue;
                    }
        
                if (isFromIntegration(prop)
                    && !integrator.isFieldMirrored(prop))
                    {
                    continue;
                    }
        
                boolean fTransient = !prop.isPersistent();
                boolean fSingle    = prop.getIndexed() == Property.PROP_SINGLE;
                Field   field      = clzThis.addField(sField,
                    resolveJVMSignature(fSingle ? dtProp : dtProp.getArrayType()));
        
                field.setPrivate();
                field.setStatic(fStatic);
                field.setTransient(fTransient);
        
                println("private "                        +
                        (fStatic    ? "static " : ""    ) +
                        (fTransient ? "transient " : "" ) +
                        formatType(dtProp)                +
                        (fSingle    ? " " : "[] "       ) +
                        sField + ';'                      );
        
                // TODO: possible optimization:
                // final intrinsic+ out property with private trivial getter
                // could generate the constant attribute for the field
                }
            else if (prop.isJavaConstant())
                {
                if (prop.isFromSuper())
                    {
                    continue;
                    }
        
                if (fStatic)
                    {
                    apBackedByFieldStaticConstant.add(prop);
                    }
                else
                    {
                    apBackedByFieldInstanceConstant.add(prop);
                    }
        
                boolean  fSingle = prop.getIndexed() == Property.PROP_SINGLE;
                DataType dtField = fSingle ? dtProp : dtProp.getArrayType();
                Field    field   = clzThis.addField(sField, resolveJVMSignature(dtField));
        
                switch (prop.getAccess())
                    {
                    case Property.ACCESS_PUBLIC:
                        field.setPublic();
        
                        print("public ");
                        break;
        
                    case Property.ACCESS_PROTECTED:
                        field.setProtected();
        
                        print("protected ");
                        break;
        
                    default:
                    case Property.ACCESS_PRIVATE:
                        field.setPrivate();
        
                        print("private ");
                        break;
                    }
        
                field.setStatic(fStatic);
                field.setFinal(true);
                field.setTransient(false);
        
                print((fStatic ? "static " : "") +
                      "final " + formatType(dtField) + ' ' + sField);
        
                // Optimization -- add constant attribute for a Java Constant
                // property that is single intrinsic+ and not null
                // Note: we do this optimization even in the property is
                // an integrated constant field...
        
                Object oValue = prop.isNoValue() ? getDefaultValue(dtProp) : prop.getValue();
                if (fSingle && oValue != null && dtProp.isExtendedSimple())
                    {
                    Constant constant = getConstant(oValue, dtProp);
                    field.setConstantValue(constant);
        
                    print(" = " + formatConstant(constant, dtProp));
        
                    if (isFromIntegration(prop))
                        {
                        String sFld = integrator.getMappedField(prop.getName());
                        print("; // " + formatType(integrator.getIntegrateeType()) + '.' + sFld);
                        }
        
                    if (fStatic)
                        {
                        // static Java Constants of an intrinsic+ type
                        // don't need to be initialized (see addConstantInitializer())
                        apBackedByFieldStaticConstant.remove(prop);
                        }
                    }
        
                println(";");
                }
            else if (prop.isVirtualConstant())
                {
                if (prop.isFromSuper() &&
                       (prop.isNoValue() ||
                        prop.isValueEqual(cdSuper.getProperty(prop.getName()).getValue())))
                    {
                    continue;
                    }
        
                apDeclaredOrValueVirtualConstant.add(prop);
        
                // For a virtual constant of a non-intrsinsic+ type with a value,
                // we need to generate a field even if the property is inherited
                // Virtual constants of intrinsic+ types are in-lined into their getters
        
                boolean fSingle = prop.getIndexed() == Property.PROP_SINGLE;
                if ((!fSingle || !dtProp.isExtendedSimple()) &&
                        prop.getValue() != null)
                    {
                    Field field = clzThis.addField(sField,
                        resolveJVMSignature(fSingle ? dtProp : dtProp.getArrayType()));
        
                    field.setPrivate();
                    field.setStatic(true);
                    field.setFinal(true);
                    field.setTransient(false);
        
                    apBackedByFieldStaticConstant.add(prop);
        
                    println("private static final " + formatType(dtProp) +
                        (fSingle ? " " : "[] ") + sField + ';');
                    }
                }
            }
        
        if (fThisGlobal && fThisStatic && !cdSuper.isStatic())
            {
            // Static components that derive from instance components
            // are supposed to have the "__singleton" field declared
            Field field = clzThis.addField(FLD_SINGLETON, COMPONENT_JVMSIG);
        
            field.setProtected();
            field.setStatic(true);
        
            println("protected static " + formatType(DataType.COMPLEX) + ' ' +
                FLD_SINGLETON + ';');
            }
        
        if (fRegisterChildren)
            {
            // Classes for design-time children are registered in this static map
            Field field = clzThis.addField(FLD_CHILDREN, 'L' + LISTMAP_CLASS + ';');
        
            field.setPrivate();
            field.setStatic(true);
        
            println("private static " + LISTMAP_CLASS + ' ' + FLD_CHILDREN + ';');
            }
        
        if (integrator != null)
            {
            // Give the integrator a chance to add fields
            integrator.addFields(this);
            }
        
        //////// 5) Static initializer "<clinit>"
        
        boolean fInitFinalConstants = !apBackedByFieldStaticConstant.isEmpty();
        boolean fInitStaticDefault  = !apStaticNonIntegratedSettableValue.isEmpty() ||
                                      fRegisterChildren;
        
        if (fInitFinalConstants || fInitStaticImpl || fInitStaticDefault)
            {
            Method method = clzThis.addMethod(INITIALIZER_NAME, "()V");
            method.setStatic(true);
        
            println();
            println("// Static initializer");
            println("static");
        
            CodeAttribute code = BeginSegment(method);
                {
                if (fInitFinalConstants)
                    {
                    // static Java Constants and Virtual Constants are declared
                    // as "final", and must be initialized in the static initializer
                    Try   lbl_try      = new Try();
                    Label lbl_continue = new Label();
        
                    code.add(lbl_try);
        
                    println("try");
        
                    BeginScope();
                        {
                        for (Iterator iter = apBackedByFieldStaticConstant.iterator(); iter.hasNext();)
                            {
                            // only static Java Constants and Virtual Constants of not intrinsic+ types
                            // have static field initializers
                            addConstantInitializer((Property) iter.next(), null);
                            }
        
                        code.add(new Goto(lbl_continue));
                        }
                    EndScope();
        
                    addCatchAndThrowWrapper(lbl_try, "java.lang.Exception");
                    code.add(lbl_continue);
                    }
                
                if (fInitStaticImpl || fInitStaticDefault)
                    {
                    MethodConstant cM_initStatic = new MethodConstant(sThisClass,
                        fInitStaticImpl ? bhvrInitStatic.getName() : INIT_STATIC_NAME, "()V");
                    code.add(new Invokestatic(cM_initStatic));
            
                    println(cM_initStatic.getName() + "();");
                    }
                code.add(new Return());
                }
            EndSegment(method);
            }
        
        //////// 5.5) Static initializers:
        ////////      "static void _initStatic()" and "private static void __initStatic()"
        
        if (fInitStaticImpl)
            {
            String sName   = bhvrInitStatic.getName();
            int    cntImpl = bhvrInitStatic.getCallableImplementationCount();
        
            println();
        
            // we will auto-generate the default implementation
            // at the end of the implementations chain
            _assert(cntImpl > 0);
            _assert(bhvrInitStatic.isStatic());
        
            Method methodAuto = generateMethodHeader(bhvrInitStatic, sName + "$Default",
                Behavior.ACCESS_PRIVATE, false, false, null);
        
            CodeAttribute code = BeginSegment(methodAuto);
                {
                if (fInitStaticDefault)
                    {
                    MethodConstant cM_initStatic = new MethodConstant(sThisClass,
                            INIT_STATIC_NAME, "()V");
                    code.add(new Invokestatic(cM_initStatic));
        
                    println(cM_initStatic.getName() + "();");
                    }
                code.add(new Return());
                }
            EndSegment(methodAuto);
        
            generateBehavior(bhvrInitStatic, methodAuto);
            }
        
        if (fInitStaticDefault)
            {
            Method method = clzThis.addMethod(INIT_STATIC_NAME, "()V");
            method.setPrivate();
            method.setStatic(true);
        
            println();
            println("// Default static initializer");
            println("private static void " + INIT_STATIC_NAME + "()");
        
            CodeAttribute code = BeginSegment(method);
                {
                if (!apStaticNonIntegratedSettableValue.isEmpty())
                    {
                    println("// state initialization: static properties");
                    
                    Try   lbl_try      = new Try();
                    Label lbl_continue = new Label();
        
                    code.add(lbl_try);
        
                    println("try");
        
                    BeginScope();
                        {
                        // initialize regular static properties
                        for (Iterator iter = apStaticNonIntegratedSettableValue.iterator(); iter.hasNext();)
                            {
                            // all access type (public, protected and private)
                            // static properties are initialized here
                            addPropertyInitializer((Property) iter.next(), null, false);
                            }
        
                        code.add(new Goto(lbl_continue));
                        }
                    EndScope();
        
                    addCatchAndThrowWrapper(lbl_try, "java.lang.Exception");
                    code.add(lbl_continue);
                    }
        
                // register child classes
                if (fRegisterChildren)
                    {
                    ClassConstant cC_map = new ClassConstant(LISTMAP_CLASS);
                    FieldConstant cR_map = clzThis.getFieldConstant(FLD_CHILDREN);
        
                    code.add(new New(cC_map));
                    code.add(new Dup());
                    MethodConstant cM_new = new MethodConstant(cC_map,
                        new SignatureConstant(CONSTRUCTOR_NAME, "()V"));
                    code.add(new Invokespecial(cM_new));
                    code.add(new Putstatic(cR_map));
        
                    println("// register child classes");
                    println(FLD_CHILDREN + " = new " + LISTMAP_CLASS + "();");
        
                    for (int iChild = 0, cChildren = asChildren.length; iChild < cChildren; iChild++)
                        {
                        String    sChild  = asChildren[iChild];
                        Component cdChild = cdThis.getChild(sChild);
        
                        if (cdChild != null && cdChild.isStatic())
                            {
                            addChildClassRegistration(cdChild, sChild, compilePlan);
                            }
                        }
                    }
        
                code.add(new Return());
                }
            EndSegment(method);
            }
        
        //////// 6) Default constructor "<init>()"
        
        if (!fThisAbstract)
            {
            // default constructor is built only for CONCRETE components
            Method method = clzThis.addMethod(CONSTRUCTOR_NAME, "()V");
            method.setPublic();
        
            println();
            println("// Default constructor");
            println("public " + sThisComponentU + "()");
        
            CodeAttribute code = BeginSegment(method);
                {
                Avar vL_this = new Avar("this"); // first and only param is "this"
                code.add(vL_this);
        
                code.add(new Aload(vL_this));
                code.add(new Aconst());
                code.add(new Aconst());
                IntConstant cZ_fInit = new IntConstant(1);
                code.add(new Iconst(cZ_fInit));
        
                MethodConstant cM_this = new MethodConstant(sThisClass,
                    CONSTRUCTOR_NAME, INIT_CONSTRUCTOR_SIG);
                code.add(new Invokespecial(cM_this));
        
                println("this(null, null, true);");
        
                code.add(new Return());
                }
            EndSegment(method);
            }
        
        //////// 6.5) Remote object constructor:
        ////////     "<init>(Object)"
        if (cdThis.isRemote() && !fThisAbstract)
            {
            Method method = clzThis.addMethod(CONSTRUCTOR_NAME, INIT_REMOTEOBJECT_SIG);
            method.setPrivate();
        
            println();
            println("// Remote object constructor");
            println("private " + sThisComponentU +
                "(Object remoteObject)");
        
            CodeAttribute code = BeginSegment(method);
                {
                Avar vL_this         = new Avar("this");
                Avar vL_remoteObject = new Avar("remoteObject");
        
                code.add(vL_this);
                code.add(vL_remoteObject);
        
                code.add(new Aload(vL_this));
                code.add(new Aconst());
                code.add(new Aconst());
                code.add(new Iconst(0));
        
                MethodConstant cM = new MethodConstant(sThisClass,
                    CONSTRUCTOR_NAME, INIT_CONSTRUCTOR_SIG);
                code.add(new Invokespecial(cM));
        
                println("this(null, null, false);");
        
                code.add(new Aload(vL_this));
                code.add(new Aload(vL_remoteObject));
                cM = findMethod(getKnownAccessor(PROP_SINK, Property.PA_SET_SINGLE), false);
                code.add(new Invokevirtual(cM));
        
                println(cM.getName() + "(remoteObject);");
        
                code.add(new Aload(vL_this));
                cM = new MethodConstant(sThisClass, INIT_NAME, "()V");
                code.add(new Invokevirtual(cM));
        
                println(cM.getName() + "();");
        
                code.add(new Return());
                }
            EndSegment(method);
            }
        
        //////// 7) Initializing constructor:
        ////////    "<init>(String, Component, boolean)"
        
        if (true)
            {
            Method method = clzThis.addMethod(CONSTRUCTOR_NAME, INIT_CONSTRUCTOR_SIG);
            method.setPublic();
        
            println();
            println("// Initializing constructor");
            println("public " + sThisComponentU +
                "(String sName, " + formatType(DataType.COMPLEX) +
                " compParent, boolean fInit)");
                
            CodeAttribute code = BeginSegment(method);
        
            Avar vL_this       = new Avar("this");
            Avar vL_sName      = new Avar("sName");  
            Avar vL_compParent = new Avar("compParent");
            Ivar vZ_fInit      = new Ivar("fInit", "Z");
        
            code.add(vL_this);
            code.add(vL_sName);
            code.add(vL_compParent);
            code.add(vZ_fInit);
        
            if (fThisRoot)
                {
                code.add(new Aload(vL_this));
                MethodConstant cM_super = new MethodConstant(sSuperClass,
                    CONSTRUCTOR_NAME, "()V");
                code.add(new Invokespecial(cM_super));
        
                println("super();");
                println();
        
                // since the _Reference property is static and we don't plan to have
                // any implementation for accessors at the root component
                // (and it is a very touchy hack) we will access the field directly
        
                Property      propReference = cdThis.getProperty(PROP_REFERENCE);
                String        sRefField     = getFieldName(propReference);
                FieldConstant cR_reference  = clzThis.getFieldConstant(sRefField);
                _assert(propReference.isStatic() && cR_reference != null);
        
                Label lbl_endif_refNonNull = new Label();
                code.add(new Getstatic(cR_reference));
                code.add(new Ifnonnull(lbl_endif_refNonNull));
        
                println("if (" + sRefField + " == null)");
        
                BeginScope();
                    {
                    code.add(new Aload(vL_this));
                    code.add(new Putstatic(cR_reference));
        
                    println(sRefField + " = this;");
                    }
                EndScope();
                code.add(lbl_endif_refNonNull);
        
                println();
        
                Label lbl_endif_parentNull = new Label();
                code.add(new Aload(vL_compParent));
                code.add(new Ifnull(lbl_endif_parentNull));
        
                println("if (compParent != null)");
        
                BeginScope();
                    {
                    code.add(new Aload(vL_compParent));
                    code.add(new Aload(vL_this));
                    code.add(new Aload(vL_sName));
                    Behavior bhvr = getKnownBehavior(BHVR_REG_CHILD);
                    MethodConstant cM = addMethodCall(bhvr);
        
                    println("compParent." + cM.getName() + "(this, sName);");
                    }
                EndScope();
                code.add(lbl_endif_parentNull);
                }
            else
                {
                code.add(new Aload(vL_this));
                code.add(new Aload(vL_sName));
                code.add(new Aload(vL_compParent));
                code.add(new Iconst(new IntConstant(0)));
                MethodConstant cM_super = new MethodConstant(sSuperClass,
                    CONSTRUCTOR_NAME, INIT_CONSTRUCTOR_SIG);
                code.add(new Invokespecial(cM_super));
        
                println("super(sName, compParent, false);");
                }
        
            // initialize fields for instance Java Constants
            for (Iterator iter = apBackedByFieldInstanceConstant.iterator(); iter.hasNext();)
                {
                // It is quite rare but possible to have an instance Java Constant.
                addConstantInitializer((Property) iter.next(), vL_this);
                }
        
            // main initializer exists only for non-abstract components
            if (!fThisAbstract)
                {
                // only generate main initialization if there are not
                // any effective integrator inits or if a custom default
                // init was specified, either at this level or at the
                // effective integration level
                if (!fEffectiveCustomInits
                    || fInitImpl
                    || fEffectiveInitImpl)
                    {
                    println();
        
                    code.add(new Iload(vZ_fInit));
                    Label lbl_endif_fInit = new Label();
                    code.add(new Ifeq(lbl_endif_fInit));
        
                    println("if (fInit)");
            
                    BeginScope();
                        {
                        code.add(new Aload(vL_this));
                        MethodConstant cM_init = fInitImpl || fEffectiveInitImpl
                            ? findMethod(bhvrInit, false)
                            : new MethodConstant(sThisClass, INIT_NAME, "()V");
                        code.add(new Invokevirtual(cM_init));
            
                        println(cM_init.getName() + "();");
                        }
                    EndScope();
        
                    code.add(lbl_endif_fInit);
                    }
                }
        
            code.add(new Return());
            EndSegment(method);
            }
        
        //////// 8) Main initializers:
        ///////     "void _init()" and "public void __init()"
        
        // theoretically we don't need the main initializers on the root component
        // (which is abstract), but we have to "claim" the names to allow virtual calls.
        if (fThisRoot || !fThisAbstract)
            {
            // If we have effective integrator custom initializers
            // and the there are init implementations at the effective level
            // and we are a sub-class of the effective integrator level
            // then just rely on the supplied implementation call to super._init().
            boolean fDefer = fEffectiveCustomInits
                             && fEffectiveInitImpl
                             && integrator == null;
        
            if (!fDefer && (fThisRoot || fInitImpl))
                {
                println();
                println("// Main initializer's proxy");
        
                String sName   = bhvrInit.getName();
                int    cntImpl = bhvrInit.getCallableImplementationCount();
        
                // we will auto-generate the default implementation
                // at the end of the implementations chain
                String sNameAuto  = (cntImpl == 0) ? sName : sName + "$Default";
        
                Method methodAuto = generateMethodHeader(bhvrInit, sNameAuto,
                    cntImpl == 0 ? bhvrInit.getAccess() : Behavior.ACCESS_PRIVATE, false, false, null);
        
                CodeAttribute code = BeginSegment(methodAuto);
                    {
                    Avar vL_this = new Avar("this");
                    code.add(vL_this);
        
                    // The default for fEffectiveCustomInits is to do
                    // nothing except for the return.
                    if (!fEffectiveCustomInits)
                        {
                        code.add(new Aload(vL_this));
                        MethodConstant cM_init = new MethodConstant(sThisClass,
                            INIT_NAME, "()V");
                        code.add(new Invokevirtual(cM_init));
        
                        println(cM_init.getName() + "();");
                        }
        
                    code.add(new Return());
                    }
                EndSegment(methodAuto);
        
                generateBehavior(bhvrInit, methodAuto);
                }
        
            println();
            println("// Main initializer");
            Method method = clzThis.addMethod(INIT_NAME, "()V");
            method.setPublic();
        
            println("public void " + INIT_NAME + "()");
        
            CodeAttribute code = BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
        
            if (!fThisAbstract)
                {
                if (fThisGlobal && fThisStatic)
                    {
                    println("// singleton initialization");
        
                    FieldConstant cR_singleton = getSingletonField();
        
                    Label lbl_endif = new Label();
                    code.add(new Getstatic(cR_singleton));
                    code.add(new Ifnull(lbl_endif));
        
                    println("if (" + FLD_SINGLETON + " != null)");
        
                    BeginScope();
                        {
                        addThrow("java.lang.IllegalStateException",
                            "A singleton for \\\"" + formatClass(sThisClass) + "\\\" has already been set", null);
                        }
                    EndScope();
                    code.add(lbl_endif);
        
                    code.add(new Aload(vL_this));
                    code.add(new Putstatic(cR_singleton));
        
                    println(FLD_SINGLETON + " = this;");
                    println();
                    }
        
                if (true)
                    {
                    println("// private initialization");
                
                    code.add(new Aload(vL_this));
                    MethodConstant cM_initPrivate = new MethodConstant(sThisClass,
                        INIT_PRIVATE_NAME, "()V");
                    code.add(new Invokevirtual(cM_initPrivate));
        
                    println(INIT_PRIVATE_NAME + "();");
                    println();
                    }
        
                // state initialization
        
                if (!apInstanceNonPrivateSettableValue.isEmpty())
                    {
                    println("// state initialization: public and protected properties");
        
                    Try   lbl_try      = new Try();
                    Label lbl_continue = new Label();
        
                    code.add(lbl_try);
        
                    println("try");
        
                    BeginScope();
                        {
                        for (Iterator iter = apInstanceNonPrivateSettableValue.iterator(); iter.hasNext();)
                            {
                            addPropertyInitializer((Property) iter.next(), vL_this, false);
                            }
                        code.add(new Goto(lbl_continue));
                        }
                    EndScope();
        
                    addCatchAndThrowWrapper(lbl_try, "java.lang.Exception");
                    code.add(lbl_continue);
                    }
        
                // containment initialization
        
                int cChildren = asChildren.length;
                if (cChildren > 0)
                    {
                    println();
                    println("// containment initialization: children");
        
                    for (int iChild = 0; iChild < cChildren; iChild++)
                        {
                        String    sChild  = asChildren[iChild]; // Unqualified local name
                        Component cdChild = cdThis.getChild(sChild);
        
                        if (cdChild != null)
                            {
                            addChildInitializer(cdChild, sChild, vL_this, compilePlan);
                            }
                        }
                    }
        
                // events initialization
        
                if (cntDispatches > 0 || cdDispatchBase != null)
                    {
                    println();
                    println("// event initialization");
        
                    String sClz = cntDispatches > 0 ? sThisClass :
                        DataType.getComponentClassName(cdDispatchBase);
        
                    code.add(new Aload(vL_this));
                    MethodConstant cM_initEvents = new MethodConstant(sClz,
                        INIT_EVENTS_NAME, "()V");
                    code.add(new Invokevirtual(cM_initEvents));
        
                    println("__initEvents();");
                    }
        
                println();
                println("// signal the end of the initialization");
        
                Behavior bhvr =
                    getKnownAccessor(PROP_CONSTRUCTED, Property.PA_SET_SINGLE);
        
                code.add(new Aload(vL_this));
                code.add(new Iconst(new IntConstant(1)));
        
                MethodConstant cM = addMethodCall(bhvr);
        
                println(cM.getName() + "(true);");
                }
        
            code.add(new Return());
            EndSegment(method);
            }
        
        //////// 9) Private initializer: "protected void __initPrivate()"
        
        // TODO: the  __initPrivate method could be optimized out
        // if there are no private properties or singleton setup for this component
        if (true)
            {
            Method method = clzThis.addMethod(INIT_PRIVATE_NAME, "()V");
            method.setProtected();
        
            println();
            println("// Private initializer");
            println("protected void __initPrivate()");
        
            CodeAttribute code = BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
        
            if (integrator != null)
                {
                // Give the integrator a chance to initialize a peer
                integrator.addPeerInitializer(this, vL_this);
                }
        
            if (!fThisRoot)
                {
                println();
        
                code.add(new Aload(vL_this));
                MethodConstant cM_super = new MethodConstant(sSuperClass,
                    INIT_PRIVATE_NAME, "()V");
                code.add(new Invokespecial(cM_super));
        
                println("super.__initPrivate();");
                }
        
            if (!apInstancePrivateSettableValue.isEmpty())
                {
                println();
                println("// state initialization: private properties");
        
                Try   lbl_try      = new Try();
                Label lbl_continue = new Label();
        
                code.add(lbl_try);
        
                println("try");
        
                BeginScope();
                    {
                    for (Iterator iter = apInstancePrivateSettableValue.iterator(); iter.hasNext();)
                        {
                        addPropertyInitializer((Property) iter.next(), vL_this, true);
                        }
                    code.add(new Goto(lbl_continue));
                    }
                EndScope();
        
                addCatchAndThrowWrapper(lbl_try, "java.lang.Exception");
                code.add(lbl_continue);
                }
        
            code.add(new Return());
            EndSegment(method);
            }
        
        //////// 10) Event initializer: "protected void __initEvents()"
        
        if (cntDispatches > 0)
            {
            Method method = clzThis.addMethod(INIT_EVENTS_NAME, "()V");
            method.setProtected();
        
            println();
            println("// Event initializer");
            println("protected void __initEvents()");
        
            CodeAttribute code = BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
        
            // "super.__initEvents()" goes to the cdDispatchBase level
            if (cdDispatchBase != null)
                {
                code.add(new Aload(vL_this));
                MethodConstant cM_super = new MethodConstant(
                    DataType.getComponentClassName(cdDispatchBase),
                    INIT_EVENTS_NAME, "()V");
                code.add(new Invokespecial(cM_super));
        
                println("super.__initEvents();");
                println();
                }
        
            for (int iDisp = 0, cDisp = asThisDispatches.length; iDisp < cDisp; iDisp++)
                {
                String sListenerQ = asThisDispatches[iDisp]; // Qualified
                if (sListenerQ == null)
                    {
                    continue;
                    }
        
                String sListenerU = sListenerQ.substring(sListenerQ.lastIndexOf('.') + 1);
                String sName      = "add" + sListenerU;
        
                code.add(new Aload(vL_this));
                code.add(new Aload(vL_this));
                Behavior bhvrAddListener = getKnownBehavior(sName + "(L" + sListenerQ + ";)");
                MethodConstant cM = addMethodCall(bhvrAddListener);
        
                println(cM.getName() + "(this);");
                }
        
            code.add(new Return());
            EndSegment(method);
            }
        
        //////// 11) Virtual Constants are implemented by auto-generated "getters"
        ////////     that are reserved but don't appear in the behavior list
        
        for (Iterator iter = apDeclaredOrValueVirtualConstant.iterator(); iter.hasNext();)
            {
            generateVirtualPropertyGetter((Property) iter.next());
            }
        
        //////// 12) static calculated properties "_Instance", "_CLASS"
        ////////     instance calculated properties "_Module", "_ChildClasses"
        
        if (!fThisAbstract || fThisGlobal && fThisStatic)
            {
            Behavior bhvr = getKnownAccessor(PROP_INSTANCE, Property.PA_GET_SINGLE);
        
            println();
            println("//++ getter for static property " + PROP_INSTANCE);
        
            String sName   = bhvr.getName();
            int    cntImpl = bhvr.getCallableImplementationCount();
        
            // we will auto-generate the default getter implementation
            // at the end of the implementations chain
            String sNameAuto  = (cntImpl == 0) ? sName : sName + "$Default";
        
            Method methodAuto = generateMethodHeader(bhvr, sNameAuto,
                cntImpl == 0 ? bhvr.getAccess() : Behavior.ACCESS_PRIVATE, bhvr.isFinal(), false, null);
            generateGetInstance(methodAuto);
        
            generateBehavior(bhvr, methodAuto);
            }
        
        if (true)
            {
            Behavior bhvr = getKnownAccessor(PROP_CLASS, Property.PA_GET_SINGLE);
        
            println();
            println("//++ getter for static property " + PROP_CLASS);
        
            // we will auto-generate the default getter implementation
            // and ignore any implementations
        
            Method method = generateMethodHeader(bhvr, bhvr.getName(),
                bhvr.getAccess(), bhvr.isFinal(), false, null);
            generateGetClass(method);
            }
        
        if (true)
            {
            Behavior bhvr = getKnownAccessor(PROP_MODULE, Property.PA_GET_SINGLE);
        
            println();
            println("//++ getter for autogen property " + PROP_MODULE);
        
            // we will auto-generate the default getter implementation
            // and ignore any implementations
        
            Method method = generateMethodHeader(bhvr, bhvr.getName(),
                Behavior.ACCESS_PRIVATE, bhvr.isFinal(), false, null);
            generateGetModule(method);
            }
        
        if (fRegisterChildren)
            {
            Behavior bhvr = getKnownAccessor(PROP_CHILD_CLASSES, Property.PA_GET_SINGLE);
        
            println();
            println("//++ getter for autogen property " + PROP_CHILD_CLASSES);
        
            // we will auto-generate the default getter implementation
            // and ignore any implementations
        
            Method method = generateMethodHeader(bhvr, bhvr.getName(),
                bhvr.getAccess(), false, false, null);
            generateGetChildClasses(method);
            }
        
        //////// 13) Dispatches (events) are implementing add/remove<e>Listener
        //////// methods that are automatically added to the behavior list
        ////////     For dispatches declared at this level we generate
        //////// "addListener", "removeListener" and all the event stubs
        
        if (cntDispatches > 0)
            {
            for (int iDisp = 0, cDisp = asThisDispatches.length; iDisp < cDisp; iDisp++)
                {
                String sListenerQ = asThisDispatches[iDisp]; // Qualified
                if (sListenerQ == null)
                    {
                    continue;
                    }
        
                String sListenerU = sListenerQ.substring(sListenerQ.lastIndexOf('.') + 1);
        
                println();
                println("//++ " + sListenerU + " dispatcher");
        
                String sHolder      = "__" + sListenerU + 's';
                Field  fieldHolder  = clzThis.addField(sHolder, 'L' + LISTENERS_CLASS + ';');
        
                fieldHolder.setPrivate();
        
                println("private " + LISTENERS_CLASS + " " + sHolder + ';');
        
                FieldConstant cR_holder = clzThis.getFieldConstant(sHolder);
        
                // a) generate "addListener" method
                    {
                    String   sName      = "add" + sListenerU;
                    Behavior bhvr       = getKnownBehavior(sName + "(L" + sListenerQ + ";)");
                    int      cntImpl    = bhvr.getCallableImplementationCount();
            
                    // auto-generate the integration router if specified
        
                    Method methodRouter = null;
        
                    if (integrator != null &&
                        integrator.getMappedBehavior(bhvr.getSignature()) != null)
                        {
                        _assert(!bhvr.isRemote(), "TODO: PJM remoted dispatch " + bhvr);
        
                        methodRouter = integrator.generateMethodRouter(this, bhvr,
                            sName + "$Router", Behavior.ACCESS_PRIVATE);
                        }
        
                    // auto-generate the default implementation
        
                    String sImplName    = (cntImpl == 0) ? sName : sName + "$Default";
                    Method methodAuto   = generateMethodHeader(bhvr, sImplName,
                        cntImpl == 0 ? bhvr.getAccess() : Behavior.ACCESS_PRIVATE, bhvr.isFinal(), false, null);
                    generateAddListener(bhvr, methodAuto, methodRouter, cR_holder);
        
                    generateBehavior(bhvr, methodAuto);
                    }
        
                // b) generate "removeListener" method
                    {
                    String   sName   = "remove" + sListenerU;
                    Behavior bhvr    = getKnownBehavior(sName + "(L" + sListenerQ + ";)");
                    int      cntImpl = bhvr.getCallableImplementationCount();
            
                    // auto-generate the integration router if specified
        
                    Method methodRouter = null;
        
                    if (integrator != null &&
                        integrator.getMappedBehavior(bhvr.getSignature()) != null)
                        {
                        _assert(!bhvr.isRemote(), "TODO: PJM remoted dispatch " + bhvr);
                         
                        methodRouter = integrator.generateMethodRouter(this, bhvr,
                            sName + "$Router", Behavior.ACCESS_PRIVATE);
                        }
        
                    // auto-generate the default implementation
        
                    String sImplName = (cntImpl == 0) ? sName : sName + "$Default";
        
                    Method methodAuto = generateMethodHeader(bhvr, sImplName,
                        cntImpl == 0 ? bhvr.getAccess() : Behavior.ACCESS_PRIVATE, bhvr.isFinal(), false, null);
                    generateRemoveListener(bhvr, methodAuto, methodRouter, cR_holder);
        
                    generateBehavior(bhvr, methodAuto);
                    }
        
                // c) generate the events
                Component jcsListener = storage.loadSignature(sListenerQ);
        
                for (Enumeration enumEvent = jcsListener.getBehaviors(); enumEvent.hasMoreElements();)
                    {
                    Behavior event = (Behavior) enumEvent.nextElement();
                    Behavior bhvr  = cdThis.getBehavior(event.getSignature());
        
                    if (bhvr == null)
                        {
                        throw new IllegalStateException(get_Name() + 
                            ".compile: dispatch behavior is missing " + event);
                        }
        
                    String sName   = bhvr.getName();
                    int    cntImpl = bhvr.getCallableImplementationCount();
        
                    // we will auto-generate a "re-dispatch" stub
                    // (as required by the JavaBeans specification)
                    // at the end of the implementations chain
                    String sStubName  = (cntImpl == 0) ? sName : sName + "$Dispatch";
        
                    // TODO:  PJM what if this is integrated or remote ???
                    Method methodStub = generateMethodHeader(bhvr, sStubName,
                        cntImpl == 0 ? bhvr.getAccess() : Behavior.ACCESS_PRIVATE, bhvr.isFinal(), false, null);
                    generateDispatchStub(bhvr, methodStub, jcsListener);
        
                    generateBehavior(bhvr, methodStub);
                    }
        
                println("//-- " + sListenerU + " dispatcher");
                }
            }
        
        //////// 14) Integration 
        ////////    a) To optimize "feed" and/or "sink" access an integrator
        //////// may needs to interveen into setFeed() or setSink() generation
        ////////    b) For all the fields from the integration map we generate
        //////// accessor routers at the end of the implementations chain
        ////////    c) For all the methods from the integration map we generate
        //////// integration routers at the end of the implementations chain
        
        if (integrator != null)
            {
            println();
            println("//++ " + formatType(integrator.getIntegrateeType()) + " integration");
        
            println("// Access optimization");
        
            for (Iterator iter = integrator.getAutoGenBehaviors().iterator(); iter.hasNext();)
                {
                Behavior bhvr    = getKnownBehavior((String) iter.next());
                String   sName   = bhvr.getName();
                int      cntImpl = bhvr.getCallableImplementationCount();
            
                // we will auto-generate an optimization
                // at the end of the implementations chain
        
                String sImplName = (cntImpl == 0) ? sName : sName + "$AutoGen";
        
                Method methodAuto =
                    integrator.generateImplementation(this, bhvr, sImplName, cntImpl == 0);
        
                generateBehavior(bhvr, methodAuto);
                }
        
            println("// properties integration");
        
            for (Enumeration enumProp = integrator.getMappedProperties(); enumProp.hasMoreElements();)
                {
                String sProp = (String) enumProp.nextElement();
                if (sProp != null)
                    {
                    Property prop = cdThis.getProperty(sProp);
                    if (prop == null)
                        {
                        // This can happen in sub-Components when both the
                        // accessors of the property integrated in a super-
                        // Component are private.
                        continue;
                        }
                    if (!prop.isStandardProperty())
                        {
                        continue;
                        }
        
                    Behavior[] abhvrAccessors = prop.getAccessors();
                    for (int i = 0, c = abhvrAccessors.length; i < c; ++i)
                        {
                        Behavior bhvr = abhvrAccessors[i];
                        if (bhvr != null)
                            {
                            String  sName   = bhvr.getName();
                            int     cntImpl = bhvr.getCallableImplementationCount();
                            boolean fRemote = bhvr.isRemote();
                        
                            // we will auto-generate an integration router
                            // at the end of the implementations chain
        
                            String sImplName;
                            int    iAccess;
                            if (cntImpl == 0)
                                {
                                if (fRemote)
                                    {
                                    sImplName = sName + "$RemoteEntry";
                                    iAccess   = Behavior.ACCESS_PROTECTED;
                                    }
                                else
                                    {
                                    sImplName = sName;
                                    iAccess   = bhvr.getAccess();
                                    }
                                }
                            else
                                {
                                sImplName = sName + "$Router";
                                iAccess   = Behavior.ACCESS_PRIVATE;
                                }
        
                            Method methodRouter =
                                integrator.generateFieldAccessors(this, prop, bhvr, sImplName, iAccess);
        
                            generateBehavior(bhvr, methodRouter);
                            }
                        }
                    }
                }
        
            println("// methods integration");
        
            for (Enumeration enumBhvr = integrator.getMappedBehaviors(); enumBhvr.hasMoreElements();)
                {
                String sBhvrSig = (String) enumBhvr.nextElement();
                if (sBhvrSig != null)
                    {
                    Behavior bhvr    = cdThis.getBehavior(sBhvrSig);
                    String   sName   = bhvr.getName();
                    int      cntImpl = bhvr.getCallableImplementationCount();
                    boolean  fRemote = bhvr.isRemote();
        
                    if (clzThis.getMethod(sName, resolveJVMSignature(bhvr)) != null)
                        {
                        // the behavior has already been generated
                        // (quite probably as a part of "dispatches")
                        continue;
                        }
        
                    if (!isCodeGenerating(bhvr))
                        {
                        continue;
                        }
        
                    // we will auto-generate an integration router
                    // at the end of the implementations chain
        
                    String sImplName;
                    int    iAccess;
                    if (cntImpl == 0)
                        {
                        if (fRemote)
                            {
                            sImplName = sName + "$RemoteEntry";
                            iAccess = Behavior.ACCESS_PROTECTED;
                            }
                        else
                            {
                            sImplName = sName;
                            iAccess = bhvr.getAccess();
                            }
                        }
                    else
                        {
                        sImplName = sName + "$Router";
                        iAccess = Behavior.ACCESS_PRIVATE;
                        }
        
                    Method methodRouter = integrator.generateMethodRouter(this, bhvr, sImplName, iAccess);
                    generateBehavior(bhvr, methodRouter);
                    }
                }
        
            println("//-- " + formatType(integrator.getIntegrateeType()) + " integration");
            }
        
        //////// 15) Implements (interfaces) -- plug-in a custom code generation
        
        String[] asImplements = cdThis.getImplements();
        for (int i = 0, c = asImplements.length; i < c; i++)
            {
            String sIface = asImplements[i];
        
            (Design.Class.getClassInfo(sIface)).generateInterface(this, sIface);
            }
        
        //////// 16) Behaviors could originate from:
        ////////    Integration              -- already processed
        ////////    Dispatches (events)      -- already processed
        ////////    Implements (interfaces)  -- may have been processed
        ////////    Properties (getters/setters)
        ////////    Manual
        
        for (Enumeration enumBhvr = cdThis.getBehaviors(); enumBhvr.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enumBhvr.nextElement();
        
            if (clzThis.getMethod(bhvr.getName(), resolveJVMSignature(bhvr)) != null)
                {
                // already there
                continue;
                }
        
            if (!isCodeGenerating(bhvr))
                {
                continue;
                }
        
            println();
            if (bhvr.isFromImplements())
                {
                for (Enumeration enumImpl = bhvr.enumImplements(); enumImpl.hasMoreElements();)
                    {
                    println("// From interface: " + (String) enumImpl.nextElement());
                    }
                }
            if (bhvr.isFromSuper())
                {
                println("// Declared at the super level");
                }
            else
                {
                String sProp = bhvr.getPropertyName();
                if (sProp != null)
                    {
                    println("// Accessor for the property \"" + sProp + "\"");
                    }
                }
        
            generateBehavior(bhvr, null);
            }
        
        if (integrator != null)
            {
            // Give the integrator a chance to generate extra classes
            // and to add any code needed to this class
            integrator.generatePeer(this);
            }
        
        if (effectiveIntegrator != null)
            {
            // Give the effective integrator a chance to
            // add any code needed to this class
            effectiveIntegrator.addEffectiveIntegration(this);
            }
        
        //---------- End of the class body
        EndSegment(null);
        
        finalizeClassGeneration(!getErrorList().isSevere() && isStoreResult());
        
        //_trace((new java.util.Date()).toString() + " --> End class generation");
        //////// 17) Children....
        
        for (int iChild = 0, cChildren = asChildren.length; iChild < cChildren; iChild++)
            {
            String    sChildU = asChildren[iChild];
            Component cdChild = cdThis.getChild(sChildU);
        
            if (cdChild == null)
                {
                // removed child
                continue;
                }
        
            if (compilePlan.isDiscardable(cdChild.getQualifiedName()))
                {
                // discarded child
                continue;
                }
        
            ClassGenerator generator = new ClassGenerator();
        
            generator.setCD(cdChild);
            generator.setParentGenerator(this);
            generator.compile();
            }
        
        return getErrorList().isSevere();
        }
    
    /**
    * Compile the specified implementation script.
    * 
    * @param impl the implementation script to compile
    * @param method  the ClassFile method to add the generated byte code into
    * @param constSuper  the constant that should be used to interpret the
    * "super." calls
    */
    private void compileImplementation(com.tangosol.dev.component.Implementation impl, com.tangosol.dev.assembler.Method method, com.tangosol.dev.assembler.Constant constantSuper)
        {
        // import Component.Dev.Util.TraitLocator.ComponentLocator.BehaviorLocator.ImplementationLocator;
        // import com.tangosol.util.Base;
        // import com.tangosol.util.ErrorList;
        // import com.tangosol.util.ErrorList$Item as ErrorInfo;
        // import java.util.Iterator;
        
        // get a script context
        Context context = getScriptTarget().createContext(impl, method, constantSuper);
        
        // get a compiler (throws IllegalArgumentException if not found)
        Compiler compiler = Locator.getCompiler(impl.getLanguage());
        
        // compile the script
        ErrorList errScript = new ErrorList();
        try
            {
            compiler.compile(context, impl.getScript(), errScript);
            }
        catch (CompilerException e)
            {
            _assert(!errScript.isEmpty());
            }
        catch (Throwable e)
            {
            String sMsg = "Fatal exception occurred during compilation: " +
                 impl.getBehavior() + " -- " + e.getMessage();
            errScript.addFatal(sMsg);
        
            _trace(e);
            }
        
        if (!errScript.isEmpty())
            {
            for (Iterator iter = errScript.iterator(); iter.hasNext(); )
                {
                ErrorInfo error = (ErrorInfo) iter.next();
                ImplementationLocator locator = ImplementationLocator.newImplementationLocator(impl);
                if (error instanceof CompilerErrorInfo)
                    {
                    CompilerErrorInfo info = (CompilerErrorInfo) error;
                    locator.setLine(info.getLine());
                    locator.setOffset(info.getOffset());
                    locator.setLength(info.getLength());
                    }
                locator.setDescription(error.getMessage());
                error.setLocator(locator);
                addError(error);
                }
            }

        }
    
    public void EndIndent()
        {
        println("}");
        
        getIndent().setLength(getIndent().length() - TAB.length());
        }
    
    public void EndScope()
        {
        EndIndent();
        
        getCode().add(new End());
        }
    
    /**
    * End the current code segment.
    */
    public void EndSegment(com.tangosol.dev.assembler.Method method)
        {
        CodeAttribute codeSegment = getCode();
        CodeAttribute codeMethod  = method != null ? method.getCode() : null;
        
        if (codeMethod != codeSegment)
            {
            throw new IllegalArgumentException(get_Name() + ".EndSegment: " +
                "Segment mismatch for " + method);
            }
        
        EndIndent();
        
        if (codeSegment != null)
            {
            codeSegment.add(new End());
            setCode(null);
            }
        }
    
    /**
    * Extracts import statements out of the script and adds them to a
    * StringTable. The simplifying assumptions about the syntax of import
    * statements are:
    * 1) "import" statements are allowed only in the beginning of the script
    * and have format like:
    *     import java.awt.Color;
    *     import java.awt.Font as AWTFont;
    *     import Component.GUI.Font;
    * 2) "import" keyword must start at the begining of a new line
    * 3) import statements are followed by at least one line
    * 
    * TODO this is a temporary implementation until we have a compiler?
    * 
    * @param sScript  script
    * @param mapImports  StringTable with the imports
    * 
    * @return  script with the imports removed (and added to the setImports)
    */
    private String extractImports(String sScript, com.tangosol.util.StringTable mapImports)
        {
        // import com.tangosol.util.ClassHelper;
        
        final String IMPORT = "import ";
        
        StringBuffer sbImports = new StringBuffer();
        
        while (sScript.startsWith(IMPORT))
            {
            int ofSemi = sScript.indexOf(';');
            int ofEnd  = sScript.indexOf('\n');
            if (ofEnd < 0)
                {
                ofEnd = sScript.length();
                }
            if (ofSemi < 0)
                {
                // let the compiler deal with the errors
                ofSemi = ofEnd;
                }
        
            String sImport = sScript.substring(IMPORT.length(), ofSemi).trim();
        
            sbImports.append("// import ")
                     .append(sImport)
                     .append(";\n");
        
            sScript = sScript.length() > ofEnd + 1 ?
                sScript.substring(ofEnd + 1) : "";
        
            if (mapImports != null)
                {
                String sName;
                int    ofAlias = sImport.lastIndexOf(' ');
                if (ofAlias != -1)
                    {
                    sName   = sImport.substring(ofAlias + 1);
                    sImport = sImport.substring(0, sImport.indexOf(' '));
                    }
                else
                    {
                    sName = sImport.substring(sImport.lastIndexOf('.') + 1);
                    }
        
                if (!ClassHelper.isQualifiedNameLegal(sImport))
                    {
                    // let the compiler deal with this
                    continue;
                    }
        
                // we cannot use Component.isDerivedFrom because sImport could point to
                // a name that is not global (i.e. Component.Test$Child)
                DataType dtImport = sImport.startsWith(COMPONENT_ROOT + '.') || sImport.equals(COMPONENT_ROOT) ?
                    DataType.getComponentType(sImport) : DataType.getClassType(sImport);
        
                mapImports.put(sName, dtImport);
                }
            }
        return sbImports.append(sScript).toString();
        }
    
    /**
    * Finalizes the class generation -- storing the class, discarding the
    * listing, etc
    * 
    * @param fStore  if true, store the generated class
    * 
    * @return a ClassInfo object that carries the generated ClassFile and
    * (optional) source listing
    */
    public ClassGenerator$ClassInfo finalizeClassGeneration(boolean fStore)
            throws com.tangosol.dev.component.ComponentException
        {
        ClassFile    clsf     = getClassFile();
        StringBuffer sb       = getListing();
        String       sListing = sb == null ? null : sb.toString();
        
        if (fStore)
            {
            if (isDebugInfo())
                {
                ((SourceFileAttribute) clsf.addAttribute(ClassFile.ATTR_FILENAME)).
                    setSourceFile(getCD().getGlobalParent().getName() + ".CDB");
                }
        
            getStorage().storeClass(clsf, sListing);
            }
        
        $ClassInfo info = ($ClassInfo) _newChild("ClassInfo");
        info.setClassFile(clsf);
        info.setClassListing(sListing);
        
        setClassFile(null);
        setListing(null);
        setIntegrator(null);
        
        return info;

        }
    
    /**
    * Finds an instance of an existing integrator model for the specified
    * component or the closest super.
    * 
    * @return the integrator for the closest integrating super or null if none
    * exists.
    */
    public Integrator findEffectiveIntegrator(com.tangosol.dev.component.Component cd)
        {
        // import Component.Dev.Compiler.Integrator;
        // import com.tangosol.util.WrapperException;
        
        try
            {
            Component cdTarget = cd;
            while (true)
                {
                Integrator integrator = findIntegrator(cd);
        
                if (integrator != null)
                    {
                    return integrator;
                    }
            
                String sSuper = cd.getSuperName();
                if (sSuper.length() == 0)
                    {
                    // if we reached this far, cdCurrent is the root component
                    return null;
                    }
        
                cd = getStorage().loadComponent(sSuper, true, null);
                }
            }
        catch (ComponentException e)
            {
            throw new WrapperException(e);
            }
        }
    
    /**
    * Finds an instance of an integrator model for the specified component as
    * specified by the Remote attribute or the Component Integration Map.
    */
    public Integrator findIntegrator(com.tangosol.dev.component.Component cd)
        {
        // import com.tangosol.util.StringTable;
        // import java.util.Enumeration;
        
        StringTable tblIntegrators = getCachedIntegrators();
        String      sComponent     = cd.getQualifiedName();
        if (tblIntegrators.contains(sComponent))
            {
            return (Integrator) tblIntegrators.get(sComponent);
            }
        
        Integrator  integrator  = cd == getCD() ? getIntegrator() : null;
        Integration integration = cd.getIntegration();
        boolean     fRemote     = cd.isRemote() && cd.isGlobal();
        
        // check if we are a remote object that does not
        // need to integrate at this level
        if (integrator == null && fRemote
            && (integration == null || !integration.isNewIntegration()))
            {
            String    sSuper  = cd.getSuperName();
            Component cdSuper = sSuper.length() == 0 ? null : getComponent(sSuper);
        
            // check if we have the same exact set of remoted behavior
            // as the super does
        
            if (cdSuper != null && cdSuper.isRemote())
                {
                fRemote = false; // assume no differences
                for (Enumeration enum = cd.getBehaviors(); enum.hasMoreElements();)
                    {
                    Behavior bhvr = (Behavior) enum.nextElement();
                    if (bhvr.isRemote())
                        {
                        // If a new behavior, create a remote integrator
                        if (!bhvr.isFromSuper())
                            {
                            fRemote = true;
                            break;
                            }
                        // If a newly declared remote behavior, create a remote integrator
                        Behavior bhvrSuper = cdSuper.getBehavior(bhvr.getSignature());
                        if (!bhvrSuper.isRemote())
                            {
                            fRemote = true;
                            break;
                            }
                        }
                    }
                }
            // Check if this is a new remote definition
            if (fRemote)
                {
                // Check if a remote object without integration at all
                if (integration == null)
                    {
                    // Create an empty integration map against java.lang.Object
                    integration = new Integration(cd, "java.lang.Object");
                    integrator  = cd.isResultAbstract() ?
                         new Integrator.AbstractBean() : new Integrator.AbstractBean.JavaBean();
                    integrator.setCDAndMap(this, cd, integration);
                    }
                }
            }
                        
        if (integrator == null && integration != null
            && (fRemote || integration.isNewIntegration()))
            {
            String sModel = integration.getModel();
            integrator = (Integrator) _newInstance(sModel);
            if (integrator == null)
                {
                throw new IllegalStateException(get_Name() + ".findIntegrator: " +
                    "Integration model \"" + sModel + "\" does not exist");
                }
            integrator.setCDAndMap(this, cd, integration);
            }
        
        if (fRemote && (integrator == null || !integrator.isRemote()))
            {
            String sMsg = "Remote object " + sComponent +
                " has been integrated using a non-remote integration model " +
                ((integrator == null) ? "" : integrator.getIntegrationModel());
            addFatalError(sMsg);
            }
        
        tblIntegrators.put(sComponent, integrator);
        return integrator;
        }
    
    /**
    * Find an interface that declares the specified method
    * 
    * @param cdJCS  Java Class Signature for an interface that may extend
    * (implement) other interfaces
    * @param sBhvrSig  signature of the behavior we are looking for
    * 
    * @return  a Java Class Signature name for an interface that declares the
    * specified method; null if not found.
    */
    private String findInterface(com.tangosol.dev.component.Component cdJCS, String sBhvrSig)
            throws com.tangosol.dev.component.ComponentException
        {
        // 2001.04.24 cp  drill down interfaces until a declaring interface
        //                is found to avoid a JVM bug (you cannot use
        //                invokeinterface against an interface that does not
        //                actually declare the method)
        Behavior bhvr = cdJCS.getBehavior(sBhvrSig);
        if (bhvr == null)
            {
            return null;
            }
        
        if (bhvr.isFromTrait())
            {
            String[] asIface = cdJCS.getImplements();
            for (int i = 0; i < asIface.length; i++)
                {
                String    sClz  = asIface[i];
                Interface iface = cdJCS.getImplements(sClz);
                if (iface != null && bhvr.isFromTrait(iface))
                    {
                    Component cdClz = getStorage().loadSignature(sClz);
                    if (cdClz == null)
                        {
                        // problem!  we were told that the interface
                        // existed but we cannot find it!
                        _trace("ClassGenerator.findInterface:  Missing " + sClz);
                        continue;
                        }
                    
                    bhvr  = cdClz.getBehavior(sBhvrSig);
                    if (bhvr == null)
                        {
                        // problem!  we were told that the behavior
                        // existed on the interface but we cannot find it!
                        _trace("ClassGenerator.findInterface:  Missing "
                                + sBhvrSig + " on " + sClz);
                        continue;
                        }
                    
                    sClz = findInterface(cdClz, sBhvrSig);
                    if (sClz != null)
                        {
                        return sClz;
                        }
                    }
                }
            }
        
        // assume that this is the declaring interface
        return cdJCS.getName();
        }
    
    /**
    * Walks through the component inheritance chain to find the one that
    * implements the specified behavior and returns the corresponding
    * MethodConstant.
    * 
    * @param bhvr  the behavior that we look a method implemenation for
    * @param fSuper  if set to true, specifies that this behavior is calling
    * it's own super; false specifies that it is not a call to a behavior's own
    * super
    * 
    * @return the MethodConstant that points to the Java Class that implements
    * the specified behavior; null if not found
    */
    public com.tangosol.dev.assembler.MethodConstant findMethod(com.tangosol.dev.component.Behavior bhvr, boolean fSuper)
        {
        Component cd         = bhvr.getComponent();
        String    sComponent = cd.getQualifiedName();
        String    sBhvrSig   = bhvr.getSignature();
        
        boolean fCheck = !fSuper;
        while (true)
            {
            if (fCheck)
                {
                if (fSuper
                    ? isCodeGenerating(bhvr)
                    : isBehaviorImplemented(bhvr))
                    {
                    // generate the name of the method that will get called
                    String sName = bhvr.getName();
                    if (fSuper && bhvr.isRemote())
                        {
                        // remoted implementations are hidden
                        sName = sName + "$RemoteEntry";
                        }
                    return new MethodConstant(
                            resolveClass(DataType.getComponentType(sComponent)),
                            new SignatureConstant(sName, resolveJVMSignature(bhvr)));
                    }
                }
        
            sComponent = cd.getSuperName();
            if (sComponent.length() == 0)
                {
                // we reached the "Root" component -- go to Object
                break;
                }
        
            cd = getComponent(sComponent);
            if (cd == null)
                {
                throw new IllegalStateException(get_Name() + ".findMethod: " +
                    "Failed to load super component: " + sComponent);
                }
        
            bhvr = cd.getBehavior(sBhvrSig);
            if (bhvr == null)
                {
                throw new IllegalStateException(get_Name() + ".findMethod: " +
                    "Behavior is missing at the declaration level");
                }
        
            fCheck = true;
            }
        
        // super of Component is Object
        return findMethod(DataType.OBJECT.getClassName(),
            bhvr.getName(), resolveJVMSignature(bhvr));
        }
    
    /**
    * Walks through the specified class signature and all its supers and find
    * the one that implements the specified method.
    * 
    * @param sClzName  the JCS name
    * @param sMethName  method's name
    * @param sMethSig  method's JVM signature
    * 
    * @return the MethodConstant (could be an InterfaceConstant)  that points
    * to the Java Class that implements the specified behavior; null if not
    * found
    */
    public com.tangosol.dev.assembler.MethodConstant findMethod(String sClzName, String sMethName, String sMethSig)
        {
        Storage storage  = getStorage();
        String  sBhvrSig = sMethName + sMethSig.substring(0, sMethSig.lastIndexOf(')') + 1).replace('/', '.');
        
        try
            {
            while (sClzName.length() > 0)
                {
                Component cdJCS = storage.loadSignature(sClzName);
                if (cdJCS == null)
                    {
                    throw new ComponentException("Cannot find java class signature for " + sClzName);
                    }
        
                Behavior bhvr  = cdJCS.getBehavior(sBhvrSig);
                if (bhvr == null)
                    {
                    throw new ComponentException("Cannot find method " + sBhvrSig + " in " + sClzName);
                    }
        
                if (!sMethSig.endsWith(resolveJVMSignature(bhvr.getReturnValue().getDataType())))
                    {
                    throw new IllegalStateException("Return type mismatch for " + sBhvrSig);
                    }
        
                if (cdJCS.isClass())
                    {
                    // insert or update
                    if (bhvr.getExists() != Behavior.EXISTS_NOT)
                        {
                        return new MethodConstant(sClzName, sMethName, sMethSig);
                        }
                    }
                else
                    {
                    _assert(cdJCS.isInterface());
                    sClzName = findInterface(cdJCS, sBhvrSig);
                    if (sClzName != null)
                        {
                        return new InterfaceConstant(sClzName, sMethName, sMethSig);
                        }
        
                    // otherwise check if the method derives from the interface
                    // super-class, which is java.lang.Object
                    if (storage.loadSignature("java.lang.Object").getBehavior(sBhvrSig) != null)
                        {
                        return findMethod("java.lang.Object", sMethName, sMethSig);
                        }
                    }
        
                sClzName = cdJCS.getSuperName();
                }
        
            throw new ComponentException("Cannot find implementation for " + sBhvrSig);
            }
        catch (ComponentException e)
            {
            throw new WrapperException(e);
            }
        }
    
    /**
    * Formats the methods parameters for the listing file.
    * 
    * @param fDeclareTypes  if true, adds parameter types to the resulting
    * string.
    */
    public String formatBehaviorParameters(com.tangosol.dev.component.Behavior bhvr, boolean fDeclareTypes)
        {
        StringBuffer sb = new StringBuffer();
        
        sb.append('(');
        
        int cntParams = bhvr.getParameterCount();
        for (int i = 0; i < cntParams; i++)
            {
            Parameter param = bhvr.getParameter(i);
            if (i > 0)
                {
                sb.append(", ");
                }
        
            if (fDeclareTypes)
                {
                sb.append(formatType(param.getDataType()))
                  .append(' ');
                }
            sb.append(param.getName());
            }
        
        sb.append(')');
        
        return sb.toString();
        }
    
    /**
    * Formats the class or package name for the listing.  This will use the
    * current CD package to determine if the name needs to be qualified or not.
    * 
    * @param sName  fully qualified name of a class or package
    */
    public String formatClass(String sName)
        {
        sName = sName.replace('/', '.');
        
        /* TODO: if PACKAGE is non-printable
        if (sName.startsWith(ClassFile$Relocator.PACKAGE.replace('/', '.'))
            {
            }
        */
        
        int iLast = sName.lastIndexOf('.');
        if (iLast == -1)
            {
            return sName;
            }
        
        if (iLast == sName.length() - 1)
            {
            // remove the trailing dot
            sName = sName.substring(0, iLast);
            iLast = sName.lastIndexOf('.');
            if (iLast == -1)
                {
                return sName;
                }
            }
        
        String sPackage = sName.substring(0,iLast);
        if (sPackage.equals("java.lang"))
            {
            return sName.substring(iLast + 1);
            }
        
        String sOurPackage = DataType.getComponentPackage(getCD());
        if (sPackage.equals(sOurPackage))
            {
            sName = sName.substring(iLast + 1);
            }
        
        return sName;
        }
    
    /**
    * Formats the class or package name for the listing
    * 
    * @param sName  fully qualified name of a class or package
    * @param fQualified  if true, format and return the qualified name;
    * otherwise the unqualified name
    */
    public static String formatClass(String sName, boolean fQualified)
        {
        sName = sName.replace('/', '.');
        
        /* TODO: if PACKAGE is non-printable
        if (sName.startsWith(ClassFile$Relocator.PACKAGE.replace('/', '.'))
            {
            }
        */
        
        int iLast = sName.lastIndexOf('.');
        
        if (fQualified)
            {
            if (iLast == sName.length() - 1)
                {
                // remove the trailing dot
                sName = sName.substring(0, iLast);
                }
            }
        else
            {
            sName = sName.substring(iLast + 1);
            }
        
        return sName;
        }
    
    public static String formatConstant(com.tangosol.dev.assembler.Constant constant, com.tangosol.dev.component.DataType dt)
        {
        // import com.tangosol.util.Base;
        
        if (constant == null)
            {
            return "null";
            }
        else if (dt == DataType.BOOLEAN)
            {
            return ((IntConstant) constant).getValue() != 0 ? "true" :"false";
            }
        else if (dt == DataType.BYTE)
            {
            return "(byte) " + constant.format();
            }
        else if (dt == DataType.SHORT)
            {
            return "(short) " + constant.format();
            }
        else if (dt == DataType.CHAR)
            {
            char ch = (char) ((IntConstant) constant).getValue();
            switch (ch)
                {
                // escaped characters
                case '\b':
                    return "'\\b'";
                case '\t':
                    return "'\\t'";
                case '\n':
                    return "'\\n'";
                case '\f':
                    return "'\\f'";
                case '\r':
                    return "'\\r'";
                case '\'':
                    return "'\\''";
                case '\\':
                    return "'\\\\'";
                default:
                    return
                        ((int) ch & 0xFF00) != 0 ? ("'\\u"  + Base.toHexString((int) ch, 4)   + "'") :
                        ((int) ch > 0x001F)      ? ("'"     + String.valueOf(ch)              + "'") :
                                                   ("'\\"   + Integer.toOctalString((int) ch) + "'");
                }
            }
        else
            {
            // check whether we have 2-bytes character and "escape" them
            String str = constant.format();
            int    len = str.length();
            char[] ach = new char[len];
        
            str.getChars(0, len, ach, 0);
        
            // we won't use it until a Unicode character is met
            StringBuffer sb = null;
        
            for (int i = 0; i < len; i++)
                {
                if (((int) ach[i] & 0xFF00) != 0)
                    {
                    if (sb == null)
                        {
                        sb = new StringBuffer(str.substring(0, i));
                        }
                    sb.append("\\u");
        
                    String sHex = Integer.toHexString((int) ach[i]);
                    if (sHex.length() < 4)
                        {
                        sb.append('0');
                        }
                    sb.append(sHex);
                   }
                else
                    {
                    if (sb != null)
                        {
                        sb.append(ach[i]);
                        }
                    }
                }
            return sb != null ? sb.toString() : str;
            }
        }
    
    /**
    * Format the passed method name and signature to the listing, leaves a
    * pending end of line.
    */
    public void formatMethod(String sName, String sSignature, com.tangosol.dev.component.Behavior bhvr)
        {
        DataType[] dtSignature = DataType.parseSignature(sSignature);
        
        print(formatType(dtSignature[0]) + ' ' + sName + "(");
        
        int iBhvrParameterCount = (bhvr == null) ? 0 : bhvr.getParameterCount();
            
        for (int i = 1; i < dtSignature.length; ++i)
            {
            if (i > 1)
                {
                print(", ");
                }
            print(formatType(dtSignature[i]) + ' ');
            if (i <= iBhvrParameterCount)
                {
                print(bhvr.getParameter(i - 1).getName());
                }
            else
                {
                print("Param_" + i);
                }
            }
        
        print(")");

        }
    
    /**
    * Formats the data type for the listing.
    */
    public String formatType(com.tangosol.dev.component.DataType dt)
        {
        return dt.isComponent() ? formatClass(resolveDataType(dt).getClassName()) : // adds the "_package" prefix
               dt.isClass()     ? formatClass(dt.getClassName())                  : // converts '/'s to '.'s
               dt.isArray()     ? formatType(dt.getElementType()) + "[]"          :
                                  dt.toString();
        }
    
    private void generateAddListener(com.tangosol.dev.component.Behavior bhvr, com.tangosol.dev.assembler.Method methodThis, com.tangosol.dev.assembler.Method methodRouter, com.tangosol.dev.assembler.FieldConstant cR_holder)
        {
        CodeAttribute code = BeginSegment(methodThis);
        
        String sHolder = cR_holder.getName();
        String sParam  = bhvr.getParameter(0).getName();
        String sLocal  = "_listeners"; // local var
        
        Avar vL_this  = new Avar("this");
        Avar vL_l     = new Avar(sParam);
        Avar vL_lsnrs = new Avar(sLocal);
        
        code.add(vL_this);
        code.add(vL_l);
        code.add(vL_lsnrs);
        
        // some Swing/Kestrel classes call into "addListener" passing null
        
        code.add(new Aload(vL_l));
        Label lbl_endif_NeNull1 = new Label();
        code.add(new Ifnonnull(lbl_endif_NeNull1));
        
        println("if (" + sParam + " == null)");
        
        BeginScope();
            {
            code.add(new Return());
            
            println("return;");
            }
        EndScope();
        
        code.add(lbl_endif_NeNull1);
        
        code.add(new Aload(vL_this));
        code.add(new Getfield(cR_holder));
        code.add(new Astore(vL_lsnrs));
        
        println(formatClass(LISTENERS_CLASS) + " " + sLocal + " = " + sHolder + ';');
        
        code.add(new Aload(vL_lsnrs));
        Label lbl_endif_NeNull2 = new Label();
        code.add(new Ifnonnull(lbl_endif_NeNull2));
        
        println("if (" + sLocal + " == null)");
        
        BeginScope();
            {
            code.add(new Aload(vL_this));
            code.add(new New(new ClassConstant(LISTENERS_CLASS)));
            code.add(new Dup());
            MethodConstant cM_new = new MethodConstant(LISTENERS_CLASS,
                CONSTRUCTOR_NAME, "()V");
            code.add(new Invokespecial(cM_new));
            code.add(new Dup());
            code.add(new Astore(vL_lsnrs));
            code.add(new Putfield(cR_holder));
        
            println(sHolder + " = " + sLocal + " = new " + LISTENERS_CLASS + "();");
            }
        EndScope();
        
        code.add(lbl_endif_NeNull2);
        
        if (methodRouter != null)
            {
            addListenerRouter(methodRouter, vL_this, vL_lsnrs);
            }
        
        code.add(new Aload(vL_lsnrs));
        code.add(new Aload(vL_l));
        MethodConstant cM_add = new MethodConstant(LISTENERS_CLASS,
            "add", "(L" + LISTENER_IFACE + ";)V");
        code.add(new Invokevirtual(cM_add));
        
        println(sLocal + ".add(" + sParam + ");");
        
        code.add(new Return());
        EndSegment(methodThis);
        }
    
    /**
    * Generate a chain of implementation for the specified behavior
    * 
    * Note 1: There always at least one (possibly default) implementaion.  We
    * start generating the methods in the reverse order, which allows us to
    * have the "super" implementation always on hands.
    * Note 2: If the behavior is marked as remoted, the stub router will be
    * added in front of the implementation chain, and at least one synthetic
    * implementation will always be generated, so we don't have to repeat all
    * the logic of "generateImplementation" that deals with change of
    * accessibility, exceptions etc.
    * 
    * @param methodSuper the highest (last to call) auto-generated method in
    * the chain
    * 
    * @return true if success, false if compilation failed
    */
    public void generateBehavior(com.tangosol.dev.component.Behavior bhvr, com.tangosol.dev.assembler.Method methodSuper)
            throws com.tangosol.dev.component.ComponentException
        {
        String sName = bhvr.getName();
        
        if (getClassFile().getMethod(sName, resolveJVMSignature(bhvr)) != null)
            {
            // the behavior has already been generated
            return;
            }
        
        Integrator integrator = getIntegrator();
        Component  cdBhvr     = bhvr.getComponent();
        boolean    fRemote    = bhvr.isRemote();
        int        iAccess    = bhvr.getAccess();
        boolean    fFinal     = bhvr.isFinal();
        boolean    fTrace     = (getTraceLevel() != TRACE_LEVEL_NONE);
        int        cImpls     = bhvr.getCallableImplementationCount();
        
        for (int iImpl = cImpls - 1; iImpl >= 0 || methodSuper == null; iImpl--)
            {
            String sImplName;
            int    iImplAccess;
            if (iImpl > 0)
                {
                sImplName   = sName + '$' + iImpl;
                iImplAccess = Behavior.ACCESS_PRIVATE;
                }
            else if (fRemote)
                {
                if (fTrace)
                    {
                    sImplName   = sName + "$RemoteTraced";
                    iImplAccess = Behavior.ACCESS_PRIVATE;
                    }
                else
                    {
                    sImplName   = sName + "$RemoteEntry";
                    iImplAccess = Behavior.ACCESS_PROTECTED;
                    }
                }
            else
                {
                if (fTrace)
                    {
                    sImplName   = sName + "$Traced";
                    iImplAccess = Behavior.ACCESS_PRIVATE;
                    }
                else
                    {
                    sImplName   = sName;
                    iImplAccess = iAccess;
                    }
                }
                
            Method method =
                generateMethodHeader(bhvr, sImplName, iImplAccess, fFinal, false, null);
        
            Implementation impl = iImpl >= 0 ? bhvr.getImplementation(iImpl) : null;
        
            generateImplementation(bhvr, impl, method, methodSuper);
        
            methodSuper = method;
            }
        
        // Process remoted methods.
        if (fRemote)
            {
            if (fTrace)
                {
                // Generate a trace method for server side calls.
                String sImplName   = sName + "$RemoteEntry";
                int    iImplAccess = Behavior.ACCESS_PROTECTED;
                Method method =
                    generateMethodHeader(bhvr, sImplName, iImplAccess, fFinal, false, null);
                generateTraceImplementation(bhvr, method, methodSuper);
                methodSuper = method;
                }
        
            // Check if we have a super implementation that is also remoted
            boolean fGenerateStubRouter = true;
            if (bhvr.isFromSuper())
                {
                Component cdSuper   = getComponent(cdBhvr.getSuperName());
                Behavior  bhvrSuper = cdSuper.getBehavior(bhvr.getSignature());
                if (bhvrSuper.isRemote())
                    {
                    // No need to generate the stub router if the super is also remote.
                    // This is because only the initial remoting of a method has the
                    // method itself declared.
                    fGenerateStubRouter = false;
                    }
                }
        
            // Generate the stub router for a remoted method if needed
            if (fGenerateStubRouter)
                {
                String sImplName;
                int    iImplAccess;
                if (fTrace)
                    {
                    sImplName   = sName + "$Traced";
                    iImplAccess = Behavior.ACCESS_PRIVATE;
                    }
                else
                    {
                    sImplName   = sName;
                    iImplAccess = bhvr.getAccess();
                    }
                Method method =
                    generateMethodHeader(bhvr, sImplName, iImplAccess, true, false, null);
                integrator.generateStubRouter(this, bhvr, method, methodSuper);
                methodSuper = method;
        
                if (fTrace)
                    {
                    // Generate the trace for the client side entry point
                    method =
                        generateMethodHeader(bhvr, sName, bhvr.getAccess(), true, false, null);
                    generateTraceImplementation(bhvr, method, methodSuper);
                    }
                }
            }
        else
            {
            if (fTrace)
                {
                Method method =
                    generateMethodHeader(bhvr, sName, bhvr.getAccess(), fFinal, false, null);
                generateTraceImplementation(bhvr, method, methodSuper);
                }
            }
        }
    
    /**
    * Generate a dispatch stub for the specified behavior that is known to be
    * one of the "events" in the "Listener" interface.
    */
    private void generateDispatchStub(com.tangosol.dev.component.Behavior bhvr, com.tangosol.dev.assembler.Method method, com.tangosol.dev.component.Component jcsListener)
        {
        if (bhvr.getReturnValue().getDataType() != DataType.VOID)
            {
            throw new IllegalStateException(get_Name() + 
                ".generateDispatchStub: Event must return void " + bhvr);
            }
        
        String sListenerQ = jcsListener.getQualifiedName();
        String sListenerU = sListenerQ.substring(               // Unqualified ...
                               sListenerQ.lastIndexOf('.') + 1);
        String sEventName = bhvr.getName();
        String sEventSig  = resolveJVMSignature(bhvr);
        String sHolder    = "__" + sListenerU + 's';
        
        FieldConstant cR_holder = getClassFile().getFieldConstant(sHolder);
        
        CodeAttribute code = BeginSegment(method);
        
        Avar vL_this = new Avar("this");
        code.add(vL_this);
        
        OpDeclare[] v_params = addBehaviorParameters(bhvr);
        
        Avar vL_targets = new Avar("targets");
        code.add(vL_targets);
        
        code.add(new Aload(vL_this));
        code.add(new Getfield(cR_holder));
        MethodConstant cM_listeners = new MethodConstant(LISTENERS_CLASS,
            "listeners", "()[L" + LISTENER_IFACE + ';');
        code.add(new Invokevirtual(cM_listeners)); // optimize with Invokespecial?
        code.add(new Astore(vL_targets));
        
        println(LISTENER_IFACE + "[] targets = " + sHolder + ".listeners();");
        
        // we need the "no indent scope" to declare
        // two labels and a local loop counter
        code.add(new Begin());
            {
            Label lbl_for_body = new Label();
            Label lbl_for_test = new Label();
        
            Ivar vI_i = new Ivar("i");
            code.add(vI_i);
        
            code.add(new Aload(vL_targets));
            code.add(new Arraylength());
            code.add(new Istore(vI_i));
        
            println("for (int i = targets.length; --i >= 0;)");
        
            BeginScope();
                {
                Avar vL_target = new Avar("target");
                code.add(vL_target);
        
                code.add(new Goto(lbl_for_test));
                code.add(lbl_for_body);
                code.add(new Aload(vL_targets));
                code.add(new Iload(vI_i));
                code.add(new Aaload());
                code.add(new Checkcast(new ClassConstant(sListenerQ)));
                code.add(new Astore(vL_target));
        
                println(sListenerQ + " target = (" + sListenerQ + ") targets[i];");
                
                code.add(new Aload(vL_target));
                code.add(new Aload(vL_this));
                Label lbl_endif_targetNeThis = new Label();
                code.add(new If_acmpeq(lbl_endif_targetNeThis));
        
                println("if (target != this)");
        
                BeginScope();
                    {
                    code.add(new Aload(vL_target));
        
                    print("target." + sEventName + "(");
        
                    addLoadParameters(bhvr, v_params);
        
                    // we definitely know that a listener is an interface
                    InterfaceConstant cIM_event =
                        (InterfaceConstant) findMethod(sListenerQ, sEventName, sEventSig);
                    code.add(new Invokeinterface(cIM_event));
        
                    println(");");
                    }
                EndScope();
        
                code.add(lbl_endif_targetNeThis);
                }
            EndScope();
        
            code.add(lbl_for_test);
            code.add(new Iinc(vI_i, (short) -1));
            code.add(new Iload(vI_i));
            code.add(new Ifge(lbl_for_body));
            }
        code.add(new End());
        
        code.add(new Return());
        EndSegment(method);
        }
    
    /**
    * Generate the classes needed to "expose" this component for the external
    * use.
    * 
    * The package name and the base name to use for all classes is indicated,
    * in addition to the type of class to expose.  The type can indicate to
    * expose either the component itself, the component's feed, the component's
    * remote classes or to expose the feed if it exists and to expose the
    * component if the feed does not exist.
    * 
    * @param sPackage the Java package name to expose all classes under
    * @param sName     the base name of all exposed classes within the package
    * @param iType    indicates what classes to generate (EXPOSE_AUTO,
    * EXPOSE_COMPONENT, EXPOSE_FEED, EXPOSE_REMOTE)
    * @param fStore if true then the generated classes and listing will be
    * stored in the storage
    * 
    * @return a list of ClassInfo components for all generated classes.
    * 
    * If fStore is true, then the generated classes are stored in the storage
    * subsystem.
    * 
    * So, for example, if one wanted to expose a Component one would code the
    * following:
    * 
    * ClassGenerator gen = new ClassGenerator();
    * gen.setCD(cd);
    * gen.setErrorList(errList);
    * gen.setStorage(storage);
    * List list = gen.generateExposedClasses(
    *                           "com.tangosol.demo", "ExtremeBean",
    * gen.EXPOSE_AUTO, false);
    * // Deal with errors here....
    * for (Iterator iter = list.iterator();  iter.hasNext();)
    *     {
    *     ClassGenerator$ClassInfo info = (ClassGenerator$ClassInfo)
    * iter.next();
    * 
    *     ClassFile clzFile  = info.getClassFile();
    *     String    sListing = info.getClassListing();    // sListing is
    * optional depending on ClassGenerator flag
    *     }
    * 
    * @see #finalizeClassGeneration
    */
    public java.util.List generateExposedClasses(String sPackage, String sName, int iType, boolean fStore)
            throws com.tangosol.dev.component.ComponentException
        {
        // import java.util.LinkedList;
        
        LinkedList list       = new LinkedList();
        Component  cd         = getCD();
        Integrator integrator = null;
        
        if (iType != EXPOSE_COMPONENT)
            {
            try
                {
                integrator = findEffectiveIntegrator(cd);
                }
            catch (Exception e) {}
            }
        
        switch (iType)
            {
            case EXPOSE_AUTO:
                if (integrator == null)
                    {
                    // Expose the component itself
                    break;
                    }
                // break through
            case EXPOSE_FEED:
            case EXPOSE_REMOTE:
                // We need to expose the feed or remote class(es).
                if (integrator == null)
                    {
                    // There are no synthetic classes associated with this component
                    return null;
                    }
                setIntegrator(integrator);
                return integrator.generateExposedClasses(this, sPackage, sName, iType, fStore);
            }
        
        // Expose the component itself
        
        if (sPackage == null)
            {
            // component class already exists in the default package
            return null;
            }
        
        if (sName == null || sName.length() == 0)
            {
            sName = cd.getName();
            }
        
        String sExposedName = sPackage.length() > 0 ? sPackage + '.' + sName : sName;
        String sSuperName   = DataType.getComponentClassName(cd);
        
        // Check if we would be generating the same exact class name
        // as the component class itself.
        if (sExposedName.equals(sSuperName))
            {
            return null;
            }
        
        if (sPackage.length() > 0)
            {
            println();
            println("package " + sPackage + ';');
            }
        
        ClassFile clz = new ClassFile(sExposedName, sSuperName, false);
        setClassFile(clz);
        
        clz.setPublic();
        
        println();
        println("public class " + sName);
        println("        extends " + formatClass(sSuperName, true));
        
        BeginSegment(null);
            {
            Method method = clz.addMethod(CONSTRUCTOR_NAME, "()V");
            method.setPublic();
        
            println();
            println("// Default constructor required for JavaBeans");
            println("public " + sName + "()");
        
            CodeAttribute code = BeginSegment(method);
                {
                Avar vL_this = new Avar("this"); // first and only param is "this"
                code.add(vL_this);
        
                code.add(new Aload(vL_this));
                MethodConstant cM_super = new MethodConstant(sSuperName,
                        CONSTRUCTOR_NAME, "()V");
                code.add(new Invokespecial(cM_super));
        
                //println("super();");
        
                code.add(new Return());
                }
            EndSegment(method);
            }
        EndSegment(null);
        
        list.add(finalizeClassGeneration(fStore));
        
        return list;
        }
    
    /**
    * Generate the code for the "get_Module()" method
    */
    private void generateGetChildClasses(com.tangosol.dev.assembler.Method method)
        {
        CodeAttribute code = BeginSegment(method);
        
        Avar vL_this = new Avar("this"); // first and only param is "this"
        code.add(vL_this);
        
        code.add(new Getstatic(getClassFile().getFieldConstant(FLD_CHILDREN)));
        code.add(new Areturn());
        
        println("return " + FLD_CHILDREN + ';');
        
        EndSegment(method);
        }
    
    /**
    * Generate the code for the "get_CLASS()" method
    */
    public void generateGetClass(com.tangosol.dev.assembler.Method method)
        {
        String        sClz = getClassFile().getName();
        CodeAttribute code = BeginSegment(method);
        
        Avar vL_clz = new Avar("clz");
        code.add(vL_clz);
        
        println("Class clz;");
        
        addClassForName(sClz, vL_clz);
        
        code.add(new Aload(vL_clz));
        code.add(new Areturn());
        
        println("return clz;");
        
        EndSegment(method);
        }
    
    /**
    * Generate the code for the "get_Instance()" method
    * 
    */
    private void generateGetInstance(com.tangosol.dev.assembler.Method method)
        {
        Component     cd      = getCD();
        Storage       storage = getStorage();
        ClassFile     clzf    = getClassFile();
        String        sClz    = clzf.getName();
        String        sClzU   = formatClass(sClz); // Unqualified
        ClassConstant cC_clz  = new ClassConstant(sClz);
        
        CodeAttribute code = BeginSegment(method);
        
        if (cd.isGlobal() && cd.isStatic())
            {
            FieldConstant cR_sngl = getSingletonField();
            
            Avar vL_sngl = new Avar("singleton");
            code.add(vL_sngl);
                
            code.add(new Getstatic(cR_sngl));
            code.add(new Astore(vL_sngl));
        
            println(formatType(DataType.COMPLEX) + " singleton = " + FLD_SINGLETON + ';');
            println();
        
            Label lbl_endif_snglNeNull = new Label();
            Label lbl_endif            = new Label();
        
            if (!clzf.isAbstract())
                {
                code.add(new Aload(vL_sngl));
                code.add(new Ifnonnull(lbl_endif_snglNeNull));
        
                println("if (singleton == null)");
            
                BeginScope();
                    {
                    code.add(new New(cC_clz));
                    code.add(new Dup());
                    MethodConstant cM_new = new MethodConstant(sClz, CONSTRUCTOR_NAME, "()V");
                    code.add(new Invokespecial(cM_new));
                    code.add(new Astore(vL_sngl));
        
                    println("singleton = new " + sClzU + "();");            
                    }
                EndScope();
                }
        
            if (!cR_sngl.getClassConstant().equals(cC_clz))
                {
                if (!clzf.isAbstract())
                    {
                    code.add(new Goto(lbl_endif));
                    code.add(lbl_endif_snglNeNull);
        
                    print("else ");
                    }
        
                code.add(new Aload(vL_sngl));
                code.add(new Instanceof(cC_clz));
                code.add(new Ifne(lbl_endif));
        
                println("if (!(singleton instanceof " + sClzU + "))");
        
                BeginScope();
                    {
                    addThrow("java.lang.IllegalStateException",
                        "A singleton for \\\"" + sClzU + "\\\" has already been set to a different type", null);
                    }
                EndScope();
                }
            else
                {
                code.add(lbl_endif_snglNeNull);
                }
            code.add(lbl_endif);
            
            code.add(new Aload(vL_sngl));
            code.add(new Areturn());
        
            println("return singleton;");
            }
        else
            {
            code.add(new New(cC_clz));
            code.add(new Dup());
            MethodConstant cM_new = new MethodConstant(sClz, CONSTRUCTOR_NAME, "()V");
            code.add(new Invokespecial(cM_new));
            code.add(new Areturn());
        
            println("return new " + sClzU + "();");
            }
        
        EndSegment(method);
        }
    
    /**
    * Generate the code for the "get_Module()" method
    */
    private void generateGetModule(com.tangosol.dev.assembler.Method method)
        {
        Component     cd    = getCD();
        CodeAttribute code  = BeginSegment(method);
        
        Avar vL_this = new Avar("this"); // first and only param is "this"
        code.add(vL_this);
        code.add(new Aload(vL_this));
        
        print("return this");
        
        MethodConstant cM_getParent = null;
        
        cd = cd.getParent();
        while (cd != null)
            {
            if (cM_getParent == null)
                {
                cM_getParent = new MethodConstant(DataType.COMPLEX.getClassConstant(),
                    new SignatureConstant("get_Parent", "()" + DataType.COMPLEX.getJVMSignature()));
                }
            code.add(new Invokevirtual(cM_getParent));
        
            print(".get_Parent()");
        
            cd = cd.getParent();
            }
        
        code.add(new Areturn());
        
        println(";");
        
        EndSegment(method);
        }
    
    /**
    * Generate a method implementation
    * 
    * @param bhvr  Behavior for which the implementation is generated
    * @param impl  Implementation to generated the byte code for
    * @param method  Method for this implementaion
    * @param methodSuper  Method where the "super" call would go
    * 
    * @return true on success, false on compilation failure
    */
    private void generateImplementation(com.tangosol.dev.component.Behavior bhvr, com.tangosol.dev.component.Implementation impl, com.tangosol.dev.assembler.Method method, com.tangosol.dev.assembler.Method methodSuper)
            throws com.tangosol.dev.component.ComponentException
        {
        // import com.tangosol.util.Base;
        
        boolean  fStatic = bhvr.isStatic();
        DataType dtRet   = bhvr.getReturnValue().getDataType();
        Property prop    = null;
        
        if (!bhvr.isFromSuper())
            {
            String sProp = bhvr.getPropertyName();
            if (sProp != null)
                {
                prop = bhvr.getComponent().getProperty(sProp);
                }
            }
        
        if (impl == null)
            {
            CodeAttribute code = BeginSegment(method);
        
            Avar vL_this;
            if (fStatic)
                {
                vL_this = null;
                }
            else
                {
                vL_this = new Avar("this");
                code.add(vL_this);
                }
        
            OpDeclare[] v_params = addBehaviorParameters(bhvr);
        
            if (methodSuper != null)
                {
                // In this case super.method means a call to this.method$N+1(...)
        
                if (dtRet != DataType.VOID)
                    {
                    print("return ");
                    }
        
                if (vL_this != null)
                    {
                    code.add(new Aload(vL_this));
                    }
        
                print(methodSuper.getName() + "(");
        
                addLoadParameters(bhvr, v_params);
        
                MethodConstant cM_super = new MethodConstant(getClassFile().getName(),
                    methodSuper.getName(), methodSuper.getType());
                code.add(methodSuper.isPrivate() ?
                    (Op) new Invokespecial(cM_super) : (Op) new Invokevirtual(cM_super));
                code.add(getReturnOp(dtRet));
        
                println(");");
                }
            else if (bhvr.isFromSuper())
                {
                // We need a default implementation that calls the super because of
                // the one of the following:
                // 1) the accessibility changes from "protected" to "public"
                // 2) this method is synchronized while the super is not
                // 3) the exception list is smaller that the one for the super
                //
                // Cases 1) and 2) are trivial -- we just have to generate the super
                // call. In case 3) we have to catch the "removed" exceptions
        
                MethodConstant cM_super = findMethod(bhvr, true);
                _assert(cM_super != null);
        
                String[] asException = bhvr.getExceptionNames();
                int      cExceptions = asException.length;
                boolean  fNeedTry    = false;
                for (int i = 0; i < cExceptions; i++)
                    {
                    String sException = asException[i];
                    if (bhvr.getException(sException) == null)
                        {
                        fNeedTry = true;
                        }
                    else
                        {
                        asException[i] = null; // remove from the list
                        }
                    }
        
                Try lbl_try = fNeedTry ? new Try() : null;
        
                if (fNeedTry)
                    {
                    code.add(lbl_try);
                
                    println("try");
                
                    BeginScope();
                    }
        
                if (dtRet != DataType.VOID)
                    {
                    print("return ");
                    }
        
                if (vL_this != null)
                    {
                    code.add(new Aload(vL_this));
        
                    print("super");
                    }
                else
                    {
                    print(formatClass(cM_super.getClassName()));
                    }
                print('.' + cM_super.getName() + '(');
        
                addLoadParameters(bhvr, v_params);
        
                if (vL_this != null)
                    {
                    code.add(new Invokespecial(cM_super));
                    }
                else
                    {
                    code.add(new Invokestatic(cM_super));
                    }
                code.add(getReturnOp(dtRet));
        
                println(");");
        
                if (fNeedTry)
                    {
                    EndScope();
        
                    addCatchesAndThrowWrappers(lbl_try, asException);
                    }
                }
            else if (prop != null)
                {
                DataType dtProp = prop.getDataType();
        
                if (bhvr == prop.getApplicableAccessor(Property.PA_GET_INDEX) ||
                    bhvr == prop.getApplicableAccessor(Property.PA_SET_INDEX))
                    {
                    Behavior bhvrGetArray = prop.getApplicableAccessor(Property.PA_GET_ARRAY);
                    if (bhvrGetArray != null)
                        {
                        if (!fStatic)
                            {
                            code.add(new Aload(vL_this));
                            }
                        addMethodCall(bhvrGetArray);
        
                        if (bhvr == prop.getApplicableAccessor(Property.PA_GET_INDEX))
                            {
                            code.add(new Iload((Ivar) v_params[0]));
                            code.add(getArrayOp(dtProp, true));
                            code.add(getReturnOp(dtProp));
        
                            println("return " + bhvrGetArray.getName() + "()[" +
                                v_params[0].getVariableName() + "];");
                            }
                        else
                            {
                            code.add(new Iload((Ivar) v_params[0]));
                            code.add(v_params[1].getLoadOp());
                            code.add(getArrayOp(dtProp, false));
                            code.add(new Return());
        
                            println(bhvrGetArray.getName() + "()[" + v_params[0].getVariableName() + "] = " +
                                v_params[1].getVariableName() + ';');
                            }
                        }
                    else
                        {
                        addDefaultReturn(dtRet);
                        }
                    }
                else if (prop.isStandardProperty())
                    {
                    // trivial accessor
                    String        sField   = getFieldName(prop);
                    FieldConstant cR_field = getClassFile().getFieldConstant(sField);
        
                    _assert(cR_field != null, "Missing field for property " + prop.getName());
        
                    if (!fStatic)
                        {
                        code.add(new Aload(vL_this));
                        }
        
                    if (bhvr == prop.getApplicableAccessor(Property.PA_GET_SINGLE))
                        {
                        code.add(fStatic ?
                            (Op) new Getstatic(cR_field) : (Op) new Getfield(cR_field));
                        code.add(getReturnOp(dtProp));
        
                        println("return " + sField + ';');
                        }
                    else if (bhvr == prop.getApplicableAccessor(Property.PA_GET_ARRAY))
                        {
                        code.add(fStatic ?
                            (Op) new Getstatic(cR_field) : (Op) new Getfield(cR_field));
                        code.add(new Areturn());
        
                        println("return " + sField + ';');
                        }
                    else if (bhvr == prop.getApplicableAccessor(Property.PA_SET_SINGLE))
                        {
                        code.add(v_params[0].getLoadOp());
                        code.add(fStatic ?
                            (Op) new Putstatic(cR_field) : (Op) new Putfield(cR_field));
                        code.add(new Return());
        
                        println(sField + " = " +
                            v_params[0].getVariableName() + ';');
                        }
                    else if (bhvr == prop.getApplicableAccessor(Property.PA_SET_ARRAY))
                        {
                        code.add(new Aload((Avar) v_params[0]));
                        code.add(fStatic ?
                            (Op) new Putstatic(cR_field) : (Op) new Putfield(cR_field));
                        code.add(new Return());
        
                        println(sField + " = " +
                            v_params[0].getVariableName() + ';');
                        }
                    else
                        {
                        throw new IllegalStateException(get_Name() + ".generateImplementation: " +
                            "Unknown accessor " + bhvr + " for property " + prop);
                        }
                    }
                else
                    {
                    addDefaultReturn(dtRet);
                    }
                }
            else
                {
                // TODO: check for removed exceptions in case the behavior is from Implements
        
                addDefaultReturn(dtRet);
                }
        
            EndSegment(method);
            }
        else // if (impl != null)
            {
            // determine what the "super" is
            Constant constantSuper = null;
            if (methodSuper != null)
                {
                // synthetic super method, format "foo$1"
                constantSuper = new MethodConstant(getClassFile().getName(),
                    methodSuper.getName(), resolveJVMSignature(bhvr));
                }
            else if (bhvr.isFromSuper())
                {
                constantSuper = findMethod(bhvr, true);
                }
            else if (prop != null)
                {
                constantSuper = getClassFile().getFieldConstant(getFieldName(prop));
                }
        
            compileImplementation(impl, method, constantSuper);
            
            if (isGenerateListing())
                {
                BeginIndent();
        
                String sScript = extractImports(impl.getScript(), null);
        
                sScript = Base.indentString(sScript, getIndent().toString(), false);
        
                if (impl.getLanguage().equals("Java"))
                    {
                    if (methodSuper != null)
                        {
                        // Calling "super.foo(...)" means calling "foo$n(...)"
                        sScript = Base.replace(sScript,
                            "super." + bhvr.getName(), methodSuper.getName());
                        }
                    else if (bhvr.isFromSuper())
                        {
                        // Calling "super.foo(...)" means calling "super.???(...)"
                        // where ??? is determined by the super constant
                        MethodConstant cM_super = (MethodConstant) constantSuper;
                        String         sSuper   = bhvr.isStatic() ?
                            cM_super.getClassName().replace('/', '.') : "super";
                        sScript = Base.replace(sScript,
                            "super." + bhvr.getName(), sSuper + "." + cM_super.getName());
                        }
                    else if (prop != null && prop.isStandardProperty())
                        {
                        // Calling "super.?etFoo()" means accessing m_Foo
                        String sField = getFieldName(prop);
        
                        if (dtRet != DataType.VOID)
                            {
                            // getter
                            sScript = Base.replace(sScript,
                                "super." + bhvr.getName() + "()", sField);
                            }
                        else  
                            {
                            // setter
                            sScript = Base.replace(sScript,
                                "super." + bhvr.getName(), sField + " = ");
                            }
                        }
                    }
        
                // all the code has already been generated --
                // just print the script into the java listing
                println(sScript);
            
                EndIndent();
                }
            }
        }
    
    /**
    * Generate a method header for given behavior. This method is also called
    * to generate a header for synthetic implementation as well as integration
    * routers, in which case we may need to "unremove" the exceptions that were
    * removed at the integration level.
    * 
    * @param sImplName  a synthetic name to override the behavior name
    * @param nAccess  access value for the implementation (to override the
    * default one)
    * @param fAbstract  abstract value for the implementation (to override the
    * default one)
    * @param asException  if not null, specifies all the exceptions that should
    * be declared as thrown; otherwise only the default ones will be thrown.
    * 
    * @return a newly generated method object
    */
    public com.tangosol.dev.assembler.Method generateMethodHeader(com.tangosol.dev.component.Behavior bhvr, String sImplName, int nAccess, boolean fFinal, boolean fAbstract, String[] asException)
        {
        // import com.tangosol.util.SimpleEnumerator;
        // import com.tangosol.util.Base;
        // import java.util.Iterator;
        // import java.util.LinkedList;
        
        boolean  fStatic  = bhvr.isStatic();
        boolean  fSync    = bhvr.isSynchronized();
        String   sMethSig = resolveJVMSignature(bhvr);
        DataType dtRet    = bhvr.getReturnValue().getDataType();
        
        if (fAbstract && (fFinal || fStatic || nAccess == Behavior.ACCESS_PRIVATE))
            {
            throw new IllegalArgumentException(get_Name() + 
                ".generateMethodHeader: " + "Cannot generate abstract behavior " + bhvr);
            }
        
        // Don't generate comments for synthetic methods
        String sDescr = bhvr.getDescription();
        if (bhvr.getName().equals(sImplName) && asException == null)
            {
            if (sDescr.length() == 0)
                {
                String sProp = bhvr.getPropertyName();
                if (sProp != null)
                    {
                    sDescr = bhvr.getReturnValue().getDataType() == DataType.VOID ?
                        "Setter" : "Getter";
                    sDescr +=  " for property " + sProp + ".<p>\n" +
                        bhvr.getComponent().getProperty(sProp).getDescription();
                    }
                }
        
            if (sDescr.length() > 0)
                {
                println("/**");
                println("* " + Base.breakLines(sDescr, 80, getIndent() + "* ", false));
                println("*/");
                }
            }
        
        ClassFile clz = getClassFile();
        Method method = clz.addMethod(sImplName, sMethSig);
        
        switch (nAccess)
            {
            case Behavior.ACCESS_PUBLIC:
                method.setPublic();
        
                print("public ");
                break;
        
            case Behavior.ACCESS_PROTECTED:
                method.setProtected();
        
                print("protected ");
                break;
        
            case Behavior.ACCESS_PACKAGE: // used only in integration
                method.setPackage();
                break;
        
            default:
            case Behavior.ACCESS_PRIVATE:
                method.setPrivate();
        
                print("private ");
                break;
            }
        
        method.setAbstract    (fAbstract);
        method.setStatic      (fStatic);
        method.setFinal       (fFinal);
        method.setSynchronized(fSync);
        
        print((fAbstract && !clz.isInterface()
                         ? "abstract "     : "")  +
              (fStatic   ? "static "       : "")  +
              (fFinal    ? "final "        : "")  +
              (fSync     ? "synchronized " : "")  +
              formatType(dtRet) + " " + sImplName +
              formatBehaviorParameters(bhvr, true));
        
        if (asException == null)
            {
            asException = bhvr.getExceptionNames();
            for (int i = 0; i < asException.length; ++i)
                {
                if (bhvr.getException(asException[i]) == null)
                    {
                    asException[i] = null;
                    }
                }
            }
        addExceptionsToMethod(method, asException);
        
        println(fAbstract ? ";" : "");
        
        return method;
        }
    
    private void generateRemoveListener(com.tangosol.dev.component.Behavior bhvr, com.tangosol.dev.assembler.Method methodThis, com.tangosol.dev.assembler.Method methodRouter, com.tangosol.dev.assembler.FieldConstant cR_holder)
        {
        CodeAttribute code = BeginSegment(methodThis);
        
        String sHolder = cR_holder.getName();
        String sParam  = bhvr.getParameter(0).getName();
        String sLocal  = "_listeners"; // local var
        
        Avar vL_this  = new Avar("this");
        Avar vL_l     = new Avar(sParam);
        Avar vL_lsnrs = new Avar(sLocal);
        
        code.add(vL_this);
        code.add(vL_l);
        code.add(vL_lsnrs);
        
        code.add(new Aload(vL_this));
        code.add(new Getfield(cR_holder));
        code.add(new Astore(vL_lsnrs));
        
        println(formatClass(LISTENERS_CLASS) + " " + sLocal + " = " + sHolder + ';');
        
        code.add(new Aload(vL_lsnrs));
        Label lbl_endif_NeNull = new Label();
        code.add(new Ifnonnull(lbl_endif_NeNull));
        
        println("if (" + sLocal + " == null)");
        
        BeginScope();
            {
            code.add(new Return());
        
            println("return; // there is nothing to remove yet");
            }
        EndScope();
        
        code.add(lbl_endif_NeNull);
        
        code.add(new Aload(vL_lsnrs));
        code.add(new Aload(vL_l));
        MethodConstant cM_remove = new MethodConstant(LISTENERS_CLASS,
            "remove", "(L" + LISTENER_IFACE + ";)V");
        code.add(new Invokevirtual(cM_remove));
        
        println(sLocal + ".remove(" + sParam + ");");
        
        if (methodRouter != null)
            {
            addListenerRouter(methodRouter, vL_this, vL_lsnrs);
            }
        
        code.add(new Return());
        EndSegment(methodThis);
        }
    
    private void generateTraceImplementation(com.tangosol.dev.component.Behavior bhvr, com.tangosol.dev.assembler.Method method, com.tangosol.dev.assembler.Method methodSuper)
            throws com.tangosol.dev.component.ComponentException
        {
        Component cd      = getCD();
        ClassFile clzf    = getClassFile();
        DataType  dtRet   = bhvr.getReturnValue().getDataType();
        boolean   fStatic = bhvr.isStatic();
        
        String sBehaviorName = cd.getQualifiedName() + '.' + bhvr.getName() +
            formatBehaviorParameters(bhvr, false);
        
        CodeAttribute code = BeginSegment(method);
        
        Avar vL_this = null;
        if (!fStatic)
            {
            vL_this = new Avar("this");
            code.add(vL_this);
            }
        
        OpDeclare[] v_params = addBehaviorParameters(bhvr);
        
        Behavior bhvrTrace = getKnownBehavior(BHVR_TRACE);
        
        code.add(new Aconst(new StringConstant("Entering " + sBehaviorName)));
        MethodConstant cM = addMethodCall(bhvrTrace);
        
        println(cM.getName() + "(\"Entering " + sBehaviorName + "\");");
        
        // Marks start of the protected code
        Try lbl_try = new Try();
        
        // Marks start of the code executed
        // whenever any exception is thrown
        Label lbl_finally = new Label();
        
        // Marks start of the common code
        // executed by all exit paths
        Label lbl_exit = new Label();
        
        code.add(lbl_try);
        
        println("try");
        BeginScope();
            {
            if (dtRet != DataType.VOID)
                {
                print("return ");
                }
        
            if (!fStatic)
                {
                code.add(new Aload(vL_this));
                }
        
            print(methodSuper.getName() + '(');
        
            addLoadParameters(bhvr, v_params);
        
            MethodConstant cM_super = new MethodConstant(clzf.getName(),
                    methodSuper.getName(), methodSuper.getType());
            if (fStatic)
                {
                code.add(new Invokestatic(cM_super));
                }
            else
                {
                code.add(new Invokespecial(cM_super));
                }
        
            OpDeclare varReturn = null;
            if (dtRet != DataType.VOID)
                {
                varReturn = getDeclareVarOp(dtRet, null);
                code.add(varReturn);
                code.add(varReturn.getStoreOp());
                }
        
            code.add(new Jsr(lbl_exit));
        
            if (dtRet != DataType.VOID)
                {
                code.add(varReturn.getLoadOp());
                }
        
            code.add(getReturnOp(dtRet));
        
            println(");");
            }
        EndScope();
        
        code.add(new Catch(lbl_try, null, lbl_finally));
        code.add(lbl_finally);
        
        println("finally");
        BeginScope();
            {
            Avar varExcept = new Avar();
            code.add(varExcept);
            code.add(new Astore(varExcept));
            code.add(new Jsr(lbl_exit));
            code.add(new Aload(varExcept));
            code.add(new Athrow());
        
            code.add(lbl_exit);
            Rvar varReturn = new Rvar();
            code.add(varReturn);
            code.add(new Rstore(varReturn));
        
            code.add(new Aconst(new StringConstant("Leaving  " + sBehaviorName)));
            cM = addMethodCall(bhvrTrace);
        
            println(cM.getName() + "(\"Leaving  " + sBehaviorName + "\");");
        
            code.add(new Ret(varReturn));
            }
        EndScope();
        
        EndSegment(method);
        }
    
    /**
    * Generates a getter for the specified virtual property.
    */
    private void generateVirtualPropertyGetter(com.tangosol.dev.component.Property prop)
        {
        _assert(prop.getIndexed() != Property.PROP_INDEXEDONLY, "Virtual property cannot be " + "indexed only");
        _assert(prop.getAccess()  != Property.ACCESS_PRIVATE,   "Virtual property cannot be " + "private");
        
        DataType dtProp    = prop.getDataType();
        boolean  fSingle   = prop.getIndexed() == Property.PROP_SINGLE;
        boolean  fPublic   = prop.getAccess()  == Property.ACCESS_PUBLIC;
        String   sSig      = prop.getAccessorSignature(fSingle ?
                             Property.PA_GET_SINGLE : Property.PA_GET_ARRAY);
        int      iPos      = sSig.indexOf('(');
        String   sMethName = sSig.substring(0, iPos);
        String   sMethSig  = sSig.substring(iPos) +
                             resolveJVMSignature(fSingle ? dtProp : dtProp.getArrayType());
        
        ClassFile clzThis  = getClassFile();
        Method    method   = clzThis.addMethod(sMethName, sMethSig);
        method.setAccess(fPublic ? Method.ACC_PUBLIC : Method.ACC_PROTECTED);
        
        println();
        println("// Getter for virtual constant " + prop.getName());
        println((fPublic ? "public " : "protected ") + formatType(dtProp) +
            (fSingle ? " " : "[] ") + sMethName + "()");
        
        CodeAttribute code = BeginSegment(method);
        
        Avar vL_this = new Avar("this"); // first and only param is "this"
        code.add(vL_this);
        
        Object oValue = prop.isNoValue()
                            ? (fSingle ? getDefaultValue(dtProp) : null)
                            : prop.getValue();
        
        // Intrinsic+ or "null value" properties are in-lined
        if ((fSingle && dtProp.isExtendedSimple()) || oValue == null)
            {
            Design designInfo = Design.getDesignInfo(prop);
            designInfo.addConstantInitializer(this, oValue, dtProp, "return ", ";");
            }
        else
            {
            print("return ");
        
            String        sField   = getFieldName(prop);
            FieldConstant cR_field = clzThis.getFieldConstant(sField);
        
            // back-up fields for virtual properties are always static
            // (see step 4 of compile())
            code.add(new Getstatic(cR_field));
        
            if (fSingle && !dtProp.isArray())
                {
                print(sField);
                }
            else // array
                {
                if (oValue == null)
                    {
                    code.add(new Aconst());
        
                    print("null");
                    }
                else
                    {
                    DataType dtRet = fSingle ? dtProp : dtProp.getArrayType();
        
                    MethodConstant cM_clone = new MethodConstant("java.lang.Object",
                        "clone", "()Ljava.lang.Object;");
                    code.add(new Invokevirtual(cM_clone));
                    code.add(new Checkcast(new ClassConstant(resolveJVMSignature(dtRet))));
        
                    print('(' + formatType(dtRet) + ") " + sField + ".clone()");
                    }
                }
        
            print(";");
            }
        
        code.add(fSingle ? getReturnOp(dtProp) : new Areturn());
        
        println();
        
        EndSegment(method);

        }
    
    /**
    * Get an array load or store op for the specified data type.
    * 
    * @param fLoad  if true, return the "load" op; "store" op otherwise
    */
    public static com.tangosol.dev.assembler.Op getArrayOp(com.tangosol.dev.component.DataType dt, boolean fLoad)
        {
        switch (dt.getTypeString().charAt(0))
            {
            case 'Z':
            case 'B':
                return fLoad ? (Op) new Baload() : (Op) new Bastore();
            case 'C':
                return fLoad ? (Op) new Caload() : (Op) new Castore();
            case 'S':
                return fLoad ? (Op) new Saload() : (Op) new Sastore();
            case 'I':
                return fLoad ? (Op) new Iaload() : (Op) new Iastore();
            case 'J':
                return fLoad ? (Op) new Laload() : (Op) new Lastore();
            case 'F':
                return fLoad ? (Op) new Faload() : (Op) new Fastore();
            case 'D':
                return fLoad ? (Op) new Daload() : (Op) new Dastore();
            default:
                return fLoad ? (Op) new Aaload() : (Op) new Aastore();
            }
        }
    
    // Accessor for the property "CachedDefaultImports"
    /**
    * Getter for property CachedDefaultImports.<p>
    * (Static) Cache of system level imports.
    * 
    * @see #getDefaultImports
    */
    protected static com.tangosol.util.StringTable getCachedDefaultImports()
        {
        return __s_CachedDefaultImports;
        }
    
    // Accessor for the property "CachedIntegrators"
    /**
    * Getter for property CachedIntegrators.<p>
    * Cache of Component Integrators.
    * 
    * @see #findIntegrator
    */
    private com.tangosol.util.StringTable getCachedIntegrators()
        {
        return __m_CachedIntegrators;
        }
    
    // Accessor for the property "CD"
    /**
    * Getter for property CD.<p>
    * The Component Definition to be compiled. This property must be set by the
    * caller.
    */
    public com.tangosol.dev.component.Component getCD()
        {
        return __m_CD;
        }
    
    // Accessor for the property "ClassFile"
    /**
    * Getter for property ClassFile.<p>
    * The class file generated by this ClassGenerator. This property is set by
    * the "compile" method.
    */
    public com.tangosol.dev.assembler.ClassFile getClassFile()
        {
        return __m_ClassFile;
        }
    
    // Accessor for the property "Code"
    /**
    * Getter for property Code.<p>
    * Current code attribute processed (generated) by the ClassGenerator.
    */
    public com.tangosol.dev.assembler.CodeAttribute getCode()
        {
        return __m_Code;
        }
    
    // Accessor for the property "CompilePlan"
    /**
    * Getter for property CompilePlan.<p>
    * Compile plan for this ClassGenerator
    */
    public com.tangosol.dev.component.CompilePlan getCompilePlan()
        {
        // import com.tangosol.dev.component.CompilePlan;
        
        CompilePlan plan = __m_CompilePlan;
        if (plan == null)
            {
            Component cd = getCD();
            _assert(cd.isGlobal(), "Compile plan must be preset from the parent " + getCD());
        
            try
                {
                plan = cd.getCompilePlan(getStorage(), !isOptimizeDiscardedChildren());
                }
            catch (ComponentException e)
                {
                throw new WrapperException(e);
                }
            setCompilePlan(plan);
            }
        
        return plan;
        }
    
    // Accessor for the property "CompilePlanCache"
    /**
    * Getter for property CompilePlanCache.<p>
    * (Privately used) Cache of compile plans mapping the global component
    * names to the corresponding CompilePlans.
    * 
    * @see #resolveClass
    */
    private java.util.Hashtable getCompilePlanCache()
        {
        // import java.util.Hashtable;
        
        Hashtable cache = __m_CompilePlanCache;
        if (cache == null)
            {
            cache = new Hashtable(17);
            setCompilePlanCache(cache);
            }
        return cache;
        }
    
    /**
    * Get [read-only] component by name. The name could be a local name in
    * which case we should walk down the children tree.
    */
    public com.tangosol.dev.component.Component getComponent(String sName)
        {
        String sGlobalName = sName;
        String sLocalName  = null;
        
        if (Component.isQualifiedNameLegal(sGlobalName))
            {
            int of = sName.indexOf('$');
            if (of >= 0)
                {
                sGlobalName = sName.substring(0, of);
                sLocalName  = sName.substring(of + 1);
                }
            }
        
        Component cd             = null;
        Component cdGlobalParent = getCD().getGlobalParent();
        if (sGlobalName.equals(cdGlobalParent.getQualifiedName()))
            {
            cd = cdGlobalParent;
            }
        else
            {
            try
                {
                if (sGlobalName.length() == 0 || Component.isQualifiedNameLegal(sGlobalName))
                    {
                    cd = getStorage().loadComponent(sGlobalName, true, null);
                    }
                else
                    {
                    cd = getStorage().loadSignature(sGlobalName);
                    }
                }
            catch (ComponentException e)
                {
                throw new WrapperException(e);
                }
            }
        
        return cd == null || sLocalName == null ? cd : cd.getLocal(sLocalName);
        }
    
    // Accessor for the property "ComponentImports"
    /**
    * Returns a map of imports for this component.
    */
    private com.tangosol.util.StringTable getComponentImports()
        {
        // import com.tangosol.util.StringTable;
        
        StringTable mapImports = new StringTable();
        
        // TODO: replace the following with the getCD().getImports() as soon as implemented
        // Until then we have to fill in the target out of "_import()"
        
        Component cd = getCD();
        Behavior bhvrImports = getCD().getBehavior("_imports()");
        if (bhvrImports != null && bhvrImports.getCallableImplementationCount() > 0)
            {
            String sScript = bhvrImports.getImplementation(0).getScript();
            extractImports(sScript, mapImports);
            }
        
        return mapImports;
        }
    
    /**
    * Generate a constant for the specifed value and data type. This could only
    * be done for an intrinsic data type or not null strings.
    * 
    * @return  the Constant object or null for the null value of a reference
    * type.
    */
    public static com.tangosol.dev.assembler.Constant getConstant(Object oValue, com.tangosol.dev.component.DataType dt)
        {
        if (oValue == null)
            {
            if (dt.isPrimitive())
                {
                throw new IllegalArgumentException(get_CLASS().getName() + ".getConstant: " + 
                    "null is invalid value for the primitive type " + dt);
                }
            else
                {
                return null;
                }
            }
        
        if (dt == DataType.STRING)
            {
            return new StringConstant((String) oValue);
            }
        
        switch (dt.getTypeString().charAt(0))
            {
            case 'Z':
                return new IntConstant(((Boolean) oValue).booleanValue() ? 1 : 0);
            case 'B':
                return new IntConstant(((Byte) oValue).intValue());
            case 'C':
                return new IntConstant((int) ((Character) oValue).charValue());
            case 'S':
                return new IntConstant(((Short) oValue).intValue());
            case 'I':
                return new IntConstant(((Integer) oValue).intValue());
            case 'J':
                return new LongConstant(((Long) oValue).longValue());
            case 'F':
                return new FloatConstant(((Float) oValue).floatValue());
            case 'D':
                return new DoubleConstant(((Double) oValue).doubleValue());
            }
        
        throw new IllegalArgumentException(get_CLASS().getName() + ".getConstant: " +
            "cannot generate a constant for value " + oValue + " of data type " + dt);

        }
    
    /**
    * Get a variable reference for the specified data type.
    * 
    * @see com.tangosol.dev.assembler.OpDeclare#getDeclareVar()
    */
    public com.tangosol.dev.assembler.OpDeclare getDeclareVarOp(com.tangosol.dev.component.DataType dt, String sName)
        {
        switch (dt.getTypeString().charAt(0))
            {
            case 'Z':
                return new Ivar(sName, "Z");
            case 'B':
                return new Ivar(sName, "B");
            case 'C':
                return new Ivar(sName, "C");
            case 'S':
                return new Ivar(sName, "S");
            case 'I':
                return new Ivar(sName, "I");
            case 'J':
                return new Lvar(sName);
            case 'F':
                return new Fvar(sName);
            case 'D':
                return new Dvar(sName);
            default:
                return new Avar(sName, resolveJVMSignature(dt));
            }
        }
    
    // Accessor for the property "DefaultImports"
    /**
    * Getter for property DefaultImports.<p>
    * Map of default imports for this component (includes the system level
    * defaults as well as auto generated children imports)
    * 
    * @see #CachedDefaultImports
    */
    private com.tangosol.util.StringTable getDefaultImports()
        {
        // import com.tangosol.util.StringTable;
        // import java.util.Enumeration;
        
        StringTable tbl = __m_DefaultImports;
        
        if (tbl == null)
            {
            StringTable tblCache = getCachedDefaultImports();
        
            if (tblCache == null)
                {
                // import all java.lang classes (probably will be done by root Component?)
                // Note: this cannot be made static because of the Storage instance
                tblCache = getStorage().getPackageSignatures("java.lang", false);
                for (Enumeration enum = tblCache.keys(); enum.hasMoreElements(); )
                    {
                    String sName = (String) enum.nextElement();
                    tblCache.put(sName, DataType.getClassType("java.lang." + sName));
                    }
        
                setCachedDefaultImports(tblCache);
                }
            
            tbl = (StringTable) tblCache.clone();
        
            setDefaultImports(tbl);
            }
        
        return tbl;
        }
    
    /**
    * Returns a default value for a given data type.
    */
    public static Object getDefaultValue(com.tangosol.dev.component.DataType dt)
        {
        if (!dt.isPrimitive())
            {
            return null;
            }
        else if (dt == DataType.BOOLEAN)
            {
            return Boolean.FALSE;
            }
        else if (dt == DataType.CHAR)
            {
            return new Character((char) 0);
            }
        else if (dt == DataType.BYTE)
            {
            return new Byte((byte) 0);
            }
        else if (dt == DataType.SHORT)
            {
            return new Short((short) 0);
            }
        else if (dt == DataType.INT)
            {
            return new Integer((int) 0);
            }
        else if (dt == DataType.LONG)
            {
            return new Long((long) 0);
            }
        else if (dt == DataType.FLOAT)
            {
            return new Float((float) 0);
            }
        else if (dt == DataType.DOUBLE)
            {
            return new Double((double) 0);
            }
        
        throw new IllegalArgumentException(get_CLASS().getName() + ".getDefaultValue: " +
            "unknown data type " + dt);
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    // Accessor for the property "ErrorList"
    /**
    * Getter for property ErrorList.<p>
    * ErrorList is supposed to be set by the user (caller) of the
    * ClassGenerator.
    */
    public com.tangosol.util.ErrorList getErrorList()
        {
        // import com.tangosol.util.ErrorList;
        
        ErrorList errorlist = __m_ErrorList;
        if (errorlist == null)
            {
            errorlist = new ErrorList();
            setErrorList(errorlist);
            }
        return errorlist;
        }
    
    /**
    * Generate a field name for the specified property.
    */
    public String getFieldName(com.tangosol.dev.component.Property prop)
        {
        String sName = prop.getName();
        
        if (prop.isJavaConstant())
            {
            return sName;
            }
        else if (prop.isStatic() || prop.isVirtualConstant())
            {
            return "__s_" + sName;
            }
        else
            {
            return "__m_" + sName;
            }
        }
    
    // Accessor for the property "ImplicitImports"
    /**
    * Rerturns the caclulated map of children imports. This should only be
    * called at the global component level.
    */
    private com.tangosol.util.StringTable getImplicitImports()
        {
        // import com.tangosol.util.StringTable;
        
        Component cd = getCD();
        
        _assert(cd.isGlobal());
        
        StringTable mapAlias    = new StringTable();
        StringTable mapConflict = new StringTable();
        
        addChildImports(cd, mapAlias, mapConflict);
        
        // "$Module" alias is reserved for the global component itself
        mapAlias.put("$Module", DataType.getComponentType(cd.getQualifiedName()));
        
        return mapAlias;
        }
    
    // Accessor for the property "Indent"
    /**
    * Getter for property Indent.<p>
    * Privately used property that is used by the listing generator.
    */
    public StringBuffer getIndent()
        {
        StringBuffer buffer = __m_Indent;
        if (buffer == null)
            {
            setIndent(buffer = new StringBuffer());
            }
        return buffer;
        }
    
    // Accessor for the property "Integrator"
    /**
    * Getter for property Integrator.<p>
    * Specifies the Integrator, set by the compile method or by the Integrators.
    */
    public Integrator getIntegrator()
        {
        return __m_Integrator;
        }
    
    /**
    * Helper that gets the accessor behavior for the specified property
    * (incorporates the error checking)
    * 
    * @param sProp a name of  the property to get an accessor for
    * @param nAccessor  one of PA_GET_SINGLE, PA_SET_SINGLE
    */
    public com.tangosol.dev.component.Behavior getKnownAccessor(String sProp, int nAccessor)
        {
        Component cd   = getCD();
        Property  prop = cd.getProperty(sProp);
        
        if (prop == null)
            {
            throw new IllegalStateException(get_Name() +
                ".getKnownAccessor: " + "property is missing for " + sProp);
            }
        
        Behavior bhvr = cd.getBehavior(prop.getAccessorSignature(nAccessor));
        
        if (bhvr == null)
            {
            throw new IllegalArgumentException(get_Name() +
                ".getKnownAccessor: " + "invalid accessor for " + sProp);
            }
        
        return bhvr;
        }
    
    /**
    * Helper that gets the accessor behavior for the specified property
    * (incorporates the error checking)
    * 
    * @param sBhvrSig  behavior signature
    */
    public com.tangosol.dev.component.Behavior getKnownBehavior(String sBhvrSig)
        {
        Component cd   = getCD();
        Behavior  bhvr = cd.getBehavior(sBhvrSig);
        
        if (bhvr == null)
            {
            throw new IllegalArgumentException(get_Name() +
                ".getKnownBehavior: " + "invalid method signature " + sBhvrSig);
            }
        return bhvr;
        }
    
    // Accessor for the property "Listing"
    /**
    * Getter for property Listing.<p>
    * A StringBuffer used for the listing generation.
    */
    protected StringBuffer getListing()
        {
        StringBuffer listing = __m_Listing;
        
        if (listing == null && isGenerateListing())
            {
            setListing(listing = new StringBuffer(1024));
            }
        
        return listing;
        }
    
    /**
    * Get a load op for the specifed constant.
    */
    public static com.tangosol.dev.assembler.Op getLoadConstOp(com.tangosol.dev.assembler.Constant constant)
        {
        if (constant == null)
            {
            return new Aconst();
            }
        else if (constant instanceof IntConstant)
            {
            return new Iconst((IntConstant) constant);
            }
        else if (constant instanceof LongConstant)
            {
            return new Lconst((LongConstant) constant);
            }
        else if (constant instanceof FloatConstant)
            {
            return new Fconst((FloatConstant) constant);
            }
        else if (constant instanceof DoubleConstant)
            {
            return new Dconst((DoubleConstant) constant);
            }
        else if (constant instanceof StringConstant)
            {
            return new Aconst((StringConstant) constant);
            }
        
        throw new IllegalArgumentException(get_CLASS().getName() + ".getLoadConst: " + 
            "Unknown constant " + constant);
        }
    
    /**
    * Get a "newarray" op for the specifed data type.
    */
    public static com.tangosol.dev.assembler.Op getNewArrayOp(com.tangosol.dev.component.DataType dt)
        {
        switch (dt.getTypeString().charAt(0))
            {
            case 'Z':
                return new Znewarray();
            case 'B':
                return new Bnewarray();
            case 'C':
                return new Cnewarray();
            case 'S':
                return new Snewarray();
            case 'I':
                return new Inewarray();
            case 'J':
                return new Lnewarray();
            case 'F':
                return new Fnewarray();
            case 'D':
                return new Dnewarray();
            default:
                return new Anewarray(dt.getClassConstant());
            }
        }
    
    // Accessor for the property "NextTempVariableNumber"
    /**
    * Getter for property NextTempVariableNumber.<p>
    * Get the next temporary variable number.  This will return a unique number
    * for use in generating a guarenteed unique local variable name.
    */
    public int getNextTempVariableNumber()
        {
        int i = __m_NextTempVariableNumber;
        setNextTempVariableNumber(i + 1);
        return i;
        }
    
    // Accessor for the property "ParentGenerator"
    /**
    * Getter for property ParentGenerator.<p>
    * The class generator of the component class compile.  For child
    * components, this is the generator used by it's parent component.  For
    * Integrator classes, this is the generator used for the primary component
    * class generation.
    */
    public ClassGenerator getParentGenerator()
        {
        return __m_ParentGenerator;
        }
    
    /**
    * Get a return op for the specifed data type
    * 
    * @see com.tangosol.dev.assembler.OpDeclare#getReturnOp()
    */
    public static com.tangosol.dev.assembler.Op getReturnOp(com.tangosol.dev.component.DataType dt)
        {
        switch (dt.getTypeString().charAt(0))
            {
            case 'Z':
            case 'B':
            case 'C':
            case 'S':
            case 'I':
                return new Ireturn();
            case 'J':
                return new Lreturn();
            case 'F':
                return new Freturn();
            case 'D':
                return new Dreturn();
            case 'V':
                return new Return();
            default: // 'R', 'L', '['
                return new Areturn();
            }

        }
    
    // Accessor for the property "ScriptTarget"
    /**
    * Getter for property ScriptTarget.<p>
    * Privately used Target component.
    */
    private _package.component.dev.compiler.script.Target getScriptTarget()
        {
        // import Component.Dev.Compiler.Script.Target;
        // import com.tangosol.util.StringTable;
        
        Target target = __m_ScriptTarget;
        
        if (target == null)
            {
            target = new Target();
            target.setCD(getCD());
            target.setManager(this);
            target.setCheck(false);
            target.setDebug(isDebugInfo());
            target.setImports((StringTable) getDefaultImports().clone());
            // target.setOptions();
            target.setStorage(getStorage());
        
            setScriptTarget(target);
            }
        
        return target;
        }
    
    /**
    * Returns a setter behavior for the specified property.
    */
    public com.tangosol.dev.component.Behavior getSetter(com.tangosol.dev.component.Property prop)
        {
        Component cd = prop.getComponent();
        
        // see Property#isValueSettable() for more info
        switch (prop.getIndexed())
            {
            default:
            case Property.PROP_SINGLE:
                return cd.getBehavior(prop.getAccessorSignature(Property.PA_SET_SINGLE));
        
            case Property.PROP_INDEXED:
                return cd.getBehavior(prop.getAccessorSignature(Property.PA_SET_ARRAY));
        
            case Property.PROP_INDEXEDONLY:
                return cd.getBehavior(prop.getAccessorSignature(Property.PA_SET_INDEX));
            }
        }
    
    /**
    * Returns the FieldConstant for the SINGLETON field that had to be
    * generated for the first component in the inheritance chain that is static
    * but derives from an instance component.
    */
    private com.tangosol.dev.assembler.FieldConstant getSingletonField()
        {
        Component cd = getCD();
        
        _assert(cd.isGlobal() && cd.isStatic());
        
        // this loop terminates because the root Component is not static
        while (true)
            {
            String    sSuper  = cd.getSuperName();
            Component cdSuper = getComponent(sSuper);
        
            if (!cdSuper.isStatic())
                {
                break;
                }
            cd = cdSuper;
            }
        
        return new FieldConstant(DataType.getComponentClassName(cd),
            FLD_SINGLETON, COMPONENT_JVMSIG);
        }
    
    // Accessor for the property "Storage"
    /**
    * Getter for property Storage.<p>
    * The storage used by the ClassGenerator. This property must be set by the
    * caller.
    */
    public _package.component.dev.Storage getStorage()
        {
        return __m_Storage;
        }
    
    // Accessor for the property "SynthFieldCount"
    /**
    * Getter for property SynthFieldCount.<p>
    * Privately used to generate unique synthetic field names.
    */
    private int getSynthFieldCount()
        {
        return __m_SynthFieldCount;
        }
    
    // Accessor for the property "SynthMethodCount"
    /**
    * Getter for property SynthMethodCount.<p>
    * Privately used to generate unique synthetic method names.
    */
    private int getSynthMethodCount()
        {
        return __m_SynthMethodCount;
        }
    
    // Accessor for the property "TraceLevel"
    /**
    * Getter for property TraceLevel.<p>
    */
    public int getTraceLevel()
        {
        return __m_TraceLevel;
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    /**
    * Determine if the specified method could be inlined.
    * 
    * If the method referred to by the method constant can be inlined, return
    * the field constant that inlines it.  Naming conventions and design
    * patterns are based on the Java beans specification.
    * 
    * @param dtClass   the data type that the method exists on (or a subclass
    * thereof)
    * @param dtReturn  return value data type (can be ignored)
    * @param sName   the method name
    * @param adtParam  array of parameter data types
    * 
    * @return  the field constant to use instead of calling the method or null
    * if the method cannot be inlined
    */
    public com.tangosol.dev.assembler.FieldConstant inlineMethod(com.tangosol.dev.component.DataType dtClass, com.tangosol.dev.component.DataType dtReturn, String sName, com.tangosol.dev.component.DataType[] adtParam)
        {
        // TODO - optimization when the specified method is a private
        // accessor with a default implementation
        return null;
        }
    
    /**
    * Checks whether the "get/set property" call could be optimized with direct
    * field access.
    * 
    * Only a trivial (no implementation) private accessor for a standard not
    * integrated property could be optimized out.
    */
    public boolean isAccessorOptimizedOut(com.tangosol.dev.component.Behavior bhvr)
        {
        // If a behavior is a trivial (no implementaion) private accessor
        // for a standard not integrated property, it could be optimized out
        
        if (isOptimizePrivateAccessors() && bhvr.getCallableImplementationCount() == 0)
            {
            String sProp = bhvr.getPropertyName();
            if (sProp != null)
                {
                Property prop = bhvr.getComponent().getProperty(sProp);
        
                if (prop.isStandardProperty() && !isFromIntegration(prop) &&
                    bhvr.getAccess() == Behavior.ACCESS_PRIVATE)
                    {
                    return true;
                    }
                }
            }
        
        return false;
        }
    
    /**
    * If the result is true it should be interpreted as:  "The method for this
    * behavior has been implemented and can be called", so the actual method
    * constant should be obtained using the resolveMethod function.
    * 
    * If the behavior is marked as "remote", then this returns true if this is
    * the declaration level for this behavior or if the super is not remote. 
    * Otherwise, if the super behavior is also remote, then this returns false.
    * 
    * If the behavior is not marked as "remote", then this returns the return
    * value of isCodeGenerating.
    * 
    * Currently, this is only different from isCodeGenerating when a
    * sub-component *does* implements an inherited, remote method, in which
    * case isBehaviorImplemented returns false, while isCodeGenerating would
    * return true.  This is because the actual implementation has been renamed
    * off (using $0).
    * 
    * @see #isCodeGenerating
    */
    private boolean isBehaviorImplemented(com.tangosol.dev.component.Behavior bhvr)
        {
        if (bhvr.isRemote())
            {
            if (!bhvr.isFromSuper())
                {
                return true;
                }
            Component cd        = bhvr.getComponent();
            Component cdSuper   = getComponent(cd.getSuperName());
            Behavior  bhvrSuper = cdSuper.getBehavior(bhvr.getSignature());
            return !bhvrSuper.isRemote();
            }
        
        return isCodeGenerating(bhvr);

        }
    
    /**
    * Determines if any of the passed classes is the super of the requested
    * class.  A common use of this method is to determine if a set of
    * exceptions declares that a particular exception is thrown.  In that case,
    * if it throws the exception itself, or any supers of that exception, then
    * the behavior is considered as throwning the exception.
    */
    public boolean isClassesSuperOfClass(String[] asSuperClasses, String sSubClass)
        {
        if (asSuperClasses == null || sSubClass == null)
            {
            return false;
            }
        
        for (int i = 0; i < asSuperClasses.length; ++i)
            {
            if (isClassSuperOfClass(asSuperClasses[i], sSubClass))
                {
                return true;
                }
            }
        
        return false;

        }
    
    /**
    * Determines if the passed class is a super (or the class itself) of the
    * requested class.
    */
    public boolean isClassSuperOfClass(String sSuperClass, String sSubClass)
        {
        if (sSuperClass == null || sSubClass == null)
            {
            return false;
            }
        
        if (sSuperClass.equals(sSubClass))
            {
            return true;
            }
        
        Storage storage = getStorage();
        
        Component jcs = null;
        try
            {
            jcs = storage.loadSignature(sSubClass);
            }
        catch (ComponentException e) {}
        
        if (jcs == null)
            {
            throw new IllegalStateException(get_Name() + ".isClassSuperOfClass: " + 
                "Java Class Signature is missing for " + sSubClass);
            }
        
        if (isClassSuperOfClasses(sSuperClass, jcs.getImplements()))
            {
            return true;
            }
        
        String sSubSuper = jcs.getSuperName();
        if (sSubSuper.length() == 0)
            {
            return false;
            }
        
        return isClassSuperOfClass(sSuperClass, sSubSuper);
        

        }
    
    public boolean isClassSuperOfClasses(String sSuperClass, String[] asSubClasses)
        {
        if (sSuperClass == null || asSubClasses == null)
            {
            return false;
            }
        
        for (int i = 0; i < asSubClasses.length; ++i)
            {
            if (isClassSuperOfClass(sSuperClass, asSubClasses[i]))
                {
                return true;
                }
            }
        
        return false;

        }
    
    /**
    * Checks whether the mehtod will be generated for specified behavior. If
    * the result is true it should be interpreted as:  "The method for this
    * behavior will be generated if the component itself is not discarded", so
    * the actual method constant should be obtained using the resolveMethod
    * function.
    * 
    * A behavior will cause the code generation if any of the following is
    * true:
    *     1) there is an implementation for this behavior
    *     2) this is a declaration level for this behavior
    *     3) the accessibility, exceptions or synchronization attribute changed
    * compare to the super
    *     4) the behavior is auto-generated accessor for "CLASS", "Instance",
    * or "Module" properties
    *     5) remote attribute was triggered for this behavior
    *     6) the behavior is auto-generated for peer access optimization
    * purposes
    * 
    * Note: To figure out whether there was auto-generation for the specified
    * method (event though component shows no implementations) we may have to
    * load the integrator and ask whether it produces the specified behavior.
    * 
    * @see #generateBehavior
    */
    private boolean isCodeGenerating(com.tangosol.dev.component.Behavior bhvr)
        {
        if (bhvr.getCallableImplementationCount() > 0 || !bhvr.isFromSuper())
            {
            return true;
            }
        
        Component cd        = bhvr.getComponent();
        Component cdSuper   = getComponent(cd.getSuperName());
        Behavior  bhvrSuper = cdSuper.getBehavior(bhvr.getSignature());
        
        if (bhvrSuper == null)
            {
            throw new IllegalStateException("Super behavior for " + bhvr + " has been removed");
            }
        
        // the access could only change from protected to public
        if (bhvr.getAccess() != bhvrSuper.getAccess())
            {
            return true;
            }
        
        // check whether the synchronized attribute was toggled on
        if (bhvr.isSynchronized() && !bhvrSuper.isSynchronized())
            {
            return true;
            }
        
        // check whether any exceptions were removed
        String[] asException = bhvr.getExceptionNames();
        for (int i = 0; i < asException.length; i++)
            {
            String sExcept = asException[i];
            if (bhvr     .getException(sExcept) == null &&
                bhvrSuper.getException(sExcept) != null)
                {
                return true;
                }
            }
        
        // check for automatically generated accessors (see compile(), step 12)
        String sProp = bhvr.getPropertyName();
        if (sProp != null)
            {
            if (sProp.equals(PROP_INSTANCE))
                {        
                return !cd.isResultAbstract() || cd.isGlobal() && cd.isStatic();
                }
            else if (sProp.equals(PROP_CLASS))
                {
                return true;
                }
            else if (sProp.equals(PROP_MODULE))
                {
                return true;
                }
            }
        
        // check for the behaviors that generate code only in
        // a remoted component
        if (cd.isRemote())
            {
            // check whether the remote attribute was toggled on
            if (bhvr.isRemote()
                && !bhvrSuper.isRemote())
                {
                return true;
                }
            }
        
        // integration could cause code to be generated even though
        // there is no implementation present
        Integrator integrator = findIntegrator(cd);
        if (integrator != null
            && integrator.isBehaviorAutoGen(bhvr))
            {
            return true;
            }
        
        // Nobody claims that they have any code to be generated for
        // this behavior, return false...
        return false;
        }
    
    // Accessor for the property "DebugInfo"
    /**
    * Getter for property DebugInfo.<p>
    * This property controls whether the debug info (the file name attribute
    * and the line numbers) is being generated.
    * 
    * @see #OptimizePrivateAccessors property
    * @see #OptimizeDiscardedChildren property
    */
    public boolean isDebugInfo()
        {
        return __m_DebugInfo;
        }
    
    /**
    * Determine if the Property is mapped to the feed.
    */
    private boolean isFromIntegration(com.tangosol.dev.component.Property property)
        {
        if (property.isFromIntegration())
            {
            return true;
            }
        
        Integrator integrator = getIntegrator();
        if (integrator == null)
            {
            return false;
            }
        
        return integrator.getMappedField(property.getName()) != null;
        

        }
    
    // Accessor for the property "GenerateListing"
    /**
    * Getter for property GenerateListing.<p>
    * This property controls whether the ClassGenerator should generate the
    * java listing. The default value is true.
    */
    public boolean isGenerateListing()
        {
        return __m_GenerateListing;
        }
    
    // Accessor for the property "NewLine"
    /**
    * Getter for property NewLine.<p>
    * Privately used flag for listing generation
    */
    private boolean isNewLine()
        {
        return __m_NewLine;
        }
    
    // Accessor for the property "OptimizeDiscardedChildren"
    /**
    * Getter for property OptimizeDiscardedChildren.<p>
    * This property controls the way an instantation and access to
    * "discardable" children is implemented.  Discardable children are the ones
    * that have no design info ("delta") that differentiate them form their
    * supers.  If set to true, the classes for those children are not generated
    * and all the references are resolved all the way up to the closest not
    * discardable supers.
    */
    public boolean isOptimizeDiscardedChildren()
        {
        return __m_OptimizeDiscardedChildren;
        }
    
    // Accessor for the property "OptimizePrivateAccessors"
    /**
    * Getter for property OptimizePrivateAccessors.<p>
    * This property controls the way an access to properties with private
    * accessors is implemented. If set to true, the generated code accesses the
    * data member directly; otherwise via accessors.
    */
    public boolean isOptimizePrivateAccessors()
        {
        return __m_OptimizePrivateAccessors;
        }
    
    // Accessor for the property "StoreResult"
    /**
    * Getter for property StoreResult.<p>
    * Specifies whether the generated classes and listings should be
    * automatically stored
    */
    public boolean isStoreResult()
        {
        return __m_StoreResult;
        }
    
    /**
    * Print the listing without incrementing the line count.
    */
    public void print(String sText)
        {
        StringBuffer listing = getListing();
        
        if (listing != null)
            {
            if (isNewLine())
                {
                listing.append(getIndent());
                setNewLine(false);
                }
            listing.append(sText);
            }
        }
    
    /**
    * Parses all the component scripts looking for imports, adds them to the
    * specified set and prints them all.
    */
    private void printImports(com.tangosol.util.StringTable mapImports)
        {
        // import com.tangosol.util.StringTable;
        // import java.util.Arrays;
        // import java.util.Enumeration;
        
        mapImports = (StringTable) mapImports.clone();
        
        for (Enumeration enumBhvr = getCD().getBehaviors(); enumBhvr.hasMoreElements();)
            {
            Behavior bhvr    = (Behavior) enumBhvr.nextElement();
            int      cntImpl = bhvr.getCallableImplementationCount();
        
            for (int i = 0; i < cntImpl; i++)
                {
                String sScript = bhvr.getImplementation(i).getScript();
        
                // TODO: the following should be replaced with a call to a compiler
                extractImports(sScript, mapImports);
                }
            }
        
        if (!mapImports.isEmpty())
            {
            // mapImports table is sorted by the short name,
            // but we'd like to print it sorted by the full name
        
            int         cImports = mapImports.getSize();
            String[]    asImport = new String[cImports];
            Enumeration enum     = mapImports.keys();
            for (int i = 0; i < cImports; i++)
                {
                String   sName    = (String) enum.nextElement();
                DataType dtImport = (DataType) mapImports.get(sName);
                String   sImport  = dtImport.getClassName();
                String   sComment = sImport.substring(sImport.lastIndexOf('.') + 1).equals(sName) ?
                    "" : " // as " + sName;
                
                asImport[i] = sImport + ';' + sComment;
                }
        
            Arrays.sort(asImport);
            
            for (int i = 0; i < cImports; i++)
                {
                println("import " + asImport[i]);
                }
            println();
            }
        }
    
    /**
    * @see println(String)
    */
    public void println()
        {
        println(null);
        }
    
    /**
    * Print into the listing and increment the line count.
    */
    public void println(String sText)
        {
        StringBuffer listing = getListing();
        
        if (listing != null)
            {
            if (isNewLine())
                {
                listing.append(getIndent());
                }
        
            if (sText != null)
                {
                listing.append(sText);
                }
            listing.append('\n');
            setNewLine(true);
            }
        
        if (isDebugInfo())
            {
            CodeAttribute code = getCode();
            if (code != null)
                {
                code.nextLine();
                }
            }
        }
    
    /**
    * Removes (by nulling out) matching objects out of two arrays (performing
    * kind of symmetrical difference)
    * 
    * @return number of [removed] matches
    * 
    * TODO: exactly the same method is used by CDComponentAttributes. Move it
    * to Component.Dev.Utils or com.tangosol.util.Base?
    */
    private int removeMatches(Object[] ao1, Object[] ao2)
        {
        int cntMatches = 0;
        
        for (int i1 = 0; i1 < ao1.length; i1++)
            {
            Object o1 = ao1[i1];
        
            if (o1 != null)
                {
                for (int i2 = 0; i2 < ao2.length; i2++)
                    {
                    if (o1.equals(ao2[i2]))
                        {
                        ao1[i1] = null;
                        ao2[i2] = null;
                        cntMatches++;
                        break;
                        }
                    }
                }
            }
        return cntMatches;

        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    /**
    * Determine the class constant for the specified type.
    * 
    * @param dtClass  the class/component data type
    * 
    * @return the class constant to use
    */
    public com.tangosol.dev.assembler.ClassConstant resolveClass(com.tangosol.dev.component.DataType dtClass)
        {
        return resolveDataType(dtClass).getClassConstant();
        }
    
    /**
    * Determine the resolved data type for the specified data type.
    * 
    * This is needed in the case when the specified DataType represents a child
    * component and the optimization is turned on
    * 
    * @param dt  the data type
    * 
    * @return the resolved data type
    */
    public com.tangosol.dev.component.DataType resolveDataType(com.tangosol.dev.component.DataType dt)
        {
        // the only complication is the case when
        // the specified DataType represents a child component
        // and the optimization is turned on
        
        if (isOptimizeDiscardedChildren())
            {
            if (dt.isArray())
                {
                dt = resolveDataType(dt.getElementType()).getArrayType();
                }
            else
                {
                if (dt.isComponent())
                    {
                    String sComponent = dt.getComponentName();
                    if (!Component.isGlobal(sComponent))
                        {
                        Component cd = getComponent(sComponent);
                        if (cd == null)
                            {
                            throw new IllegalArgumentException("Cannot resolve " + dt +
                                " for " + getCD().getQualifiedName());
                            }
        
                        CompilePlan plan;
                        if (cd.isRelative(getCD()))
                            {
                            plan = getCompilePlan();
                            }
                        else
                            {
                            Component cdGlobalParent = cd.getGlobalParent();
                            String    sGlobalName    = cdGlobalParent.getQualifiedName();
        
                            plan = (CompilePlan) getCompilePlanCache().get(sGlobalName);
                            if (plan == null)
                                {
                                try
                                    {
                                    plan = cdGlobalParent.getCompilePlan(getStorage(), false);
                                    getCompilePlanCache().put(sGlobalName, plan);
                                    }
                                catch (ComponentException e)
                                    {
                                    throw new IllegalStateException();
                                    }
                                }
                            }
        
                        String sName = cd.getQualifiedName();
                        if (plan.isDiscardable(sName))
                            {
                            dt = DataType.getComponentType(plan.getSuperName(sName));
                            }
                        }
                    }
                }
            }
        return dt;
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    /**
    * Determine the field constant for the specified field.
    * 
    * If the field referred to by the method constant exists, then the manager
    * returns it unchanged.  If the field does not exist, the manager
    * determines what field constant should be used instead.  This
    * is used primarily to find what derivation level a field exists at.
    * 
    * @param dtClass  the data type that the field exists on (or a subclass
    * thereof)
    * @param dtField  the type of the field (can be ignored)
    * @param sName  the name of the field
    * 
    * @return  the field constant to use
    */
    public com.tangosol.dev.assembler.FieldConstant resolveField(com.tangosol.dev.component.DataType dtClass, com.tangosol.dev.component.DataType dtField, String sName)
        {
        // import java.util.List;
        // import java.util.LinkedList;
        
        Storage   storage = getStorage();
        String    sSig    = resolveJVMSignature(dtField);
        boolean   fCheckI = false;
        Component clzOrig = null;
        
        // members of an array resolve to java.lang.Object
        if (dtClass.isArray())
            {
            dtClass = DataType.OBJECT;
            }
        
        try
            {
            // components:  search up the inheritance chain
            if (dtClass.isComponent())
                {
                String sComponent = dtClass.getComponentName();
                while (sComponent.length() > 0)
                    {
                    // load the component
                    Component cd = getComponent(sComponent);
                    if (cd == null)
                        {
                        return null;
                        }
        
                    // check for property (even if it isn't at this level,
                    // information about it will be present)
                    Property prop = cd.getProperty(sName);
                    if (prop == null || !prop.isJavaConstant())
                        {
                        return null;
                        }
        
                    // if prop is declared at this level, return a field constant
                    if (!prop.isFromSuper())
                        {
                        return new FieldConstant(
                                resolveClass(DataType.getComponentType(sComponent)),
                                new SignatureConstant(sName, sSig));
                        }
        
                    sComponent = cd.getSuperName();
                    }
        
                // Object is super of root Component
                dtClass = DataType.OBJECT;
                }
            else if (dtClass.isArray())
                {
                if (sName.equals("length"))
                    {
                    throw new IllegalStateException("length is not a field of an array!");
                    }
        
                // treat arrays as Object
                dtClass = DataType.OBJECT;
                }
            else if (dtClass.isClass())
                {
                fCheckI = true;
                }
            else
                {
                throw new IllegalStateException();
                }
        
            // classes:  search up the inheritance chain
            String sClass = dtClass.getClassName();
            while (sClass.length() > 0)
                {
                Component clz = storage.loadSignature(sClass);
                if (clz == null)
                    {
                    return null;
                    }
        
                Property field = clz.getProperty(sName);
                if (field == null)
                    {
                    if (clzOrig == null)
                        {
                        // if it does not exist on the specified class, then
                        // it is either ambiguous or does not exist at all
                        return null;
                        }
                    else
                        {
                        // it existed on the specified class but now we don't
                        // see it -- it must be on an interface
                        break;
                        }
                    }
        
                if (field.getExists() != Property.EXISTS_NOT
                    && !field.isFromSuper()
                    && !field.isFromTrait())
                    {
                    return new FieldConstant(
                            resolveClass(DataType.getClassType(sClass)),
                            new SignatureConstant(sName, sSig));
                    }
        
                if (clzOrig == null)
                    {
                    clzOrig = clz;
                    }
        
                sClass = clz.getSuperName();
                }
        
            // search interfaces; assumption is that name is not ambiguous
            // (otherwise this would have been called with the correct type)
            if (fCheckI)
                {
                String[] asIface = clzOrig.getImplements();
                List     list    = new LinkedList();
                for (int i = 0, c = asIface.length; i < c; ++i)
                    {
                    String    sIface = asIface[i];
                    Component clz    = storage.loadSignature(sIface);
                    _assert(clz != null, "JCS " + sIface + " exists");
        
                    collectInterfaceFields(clz, sName, list);
                    }
                
                if (list.size() == 1)
                    {
                    return new FieldConstant(resolveClass(
                            DataType.getClassType((String) list.get(0))),
                            new SignatureConstant(sName, sSig));
                    }
                
                // ambiguous (>1) or does not exist (=0)
                return null;
                }
            }
        catch (ComponentException e)
            {
            throw new WrapperException(e);
            }
        
        return null;
        }
    
    /**
    * Determine the JVM Signature for the specified behavior.  This is needed
    * to handle the data types for the return value and parameters that
    * correspond to child components that have been optimized out.
    * 
    * @param dt  the data type
    * 
    * @return the JVM signature to use
    */
    public String resolveJVMSignature(com.tangosol.dev.component.Behavior bhvr)
        {
        StringBuffer sb = new StringBuffer();
        
        sb.append('(');
        
        DataType[] adtParam = bhvr.getParameterTypes();
        int cParams = adtParam.length;
        for (int i = 0; i < cParams; ++i)
            {
            sb.append(resolveJVMSignature(adtParam[i]));
            }
        
        sb.append(')')
          .append(resolveJVMSignature(bhvr.getReturnValue().getDataType()));
        
        return sb.toString();

        }
    
    /**
    * Determine the JVM Signature for the specified type.  This is needed to
    * handle those data types that correspond to child components that have
    * been optimized out.
    * 
    * @param dt  the data type
    * 
    * @return the JVM signature to use
    */
    public String resolveJVMSignature(com.tangosol.dev.component.DataType dt)
        {
        return resolveDataType(dt).getJVMSignature();
        }
    
    /**
    * Determine the JVM Signature for the specified property.  This is needed
    * to handle those data types that correspond to child components that have
    * been optimized out.
    * 
    * @param dt  the data type
    * 
    * @return the JVM signature to use
    */
    public String resolveJVMSignature(com.tangosol.dev.component.Property prop)
        {
        return resolveJVMSignature(prop.getDataType());
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    /**
    * Determine the method constant for the specified method.
    * 
    * @param dtClass  the data type that the method exists on (or a subclass
    * thereof)
    * @param dtReturn  return value data type (can be ignored)
    * @param sName  the method name
    * @param adtParam  array of parameter data types
    * 
    * @return  the method constant to call or null if the method call must be
    * inlined (or if it does not exist)
    */
    public com.tangosol.dev.assembler.MethodConstant resolveMethod(com.tangosol.dev.component.DataType dtClass, com.tangosol.dev.component.DataType dtReturn, String sName, com.tangosol.dev.component.DataType[] adtParam)
        {
        final boolean fDebug = "JAVA".equals(System.getProperty("DEBUG"));
        if (fDebug) _trace("entering resolveMethod for " + sName + " on " + dtClass);
        
        Storage storage = getStorage();
        String  sBeh    = Behavior.getSignature(sName, adtParam, 0);
        
        // generate method signature
        StringBuffer sb = new StringBuffer("(");
        int cParams = adtParam.length;
        for (int i = 0; i < cParams; ++i)
            {
            sb.append(resolveJVMSignature(adtParam[i]));
            }
        sb.append(')');
        String sSig = sb.toString() + resolveJVMSignature(dtReturn);
        
        // members of an array resolve to java.lang.Object
        if (dtClass.isArray())
            {
            dtClass = DataType.OBJECT;
            }
        
        if (fDebug) _trace("component: " + dtClass + ", behavior=" + sBeh + ", signature=" + sSig);
        
        if (dtClass.isComponent())
            {
            String  sComponent = dtClass.getComponentName();
            boolean fExists    = false;
            do
                {
                // load the component
                Component cd = getComponent(sComponent);
                _assert(cd != null);
        
                // check for behavior
                Behavior behavior = cd.getBehavior(sBeh);
        
                if (fDebug) _trace("behavior " + (behavior == null ? "not" : "") + " present on " + sComponent);
        
                if (behavior == null)
                    {
                    // behavior must gen code at least at its declaration level
                    _assert(!fExists, "Method " + sName + " on " +
                            dtClass + " has no implementation at declaration level!");
        
                    // not on Component; check Object
                    break;
                    }
                else
                    {
                    fExists = true;
                    }
        
                // if behavior is implemented in the class, return a method constant for it
                if (isBehaviorImplemented(behavior))
                    {
                    if (fDebug) _trace("code generated on " + sComponent);
        
                    return new MethodConstant(
                            resolveClass(DataType.getComponentType(sComponent)),
                            new SignatureConstant(sName, sSig));
                    }
        
                sComponent = cd.getSuperName();
        
                if (fDebug) _trace("super component: " + sComponent);
                }
            while (sComponent.length() > 0);
        
            // Object is super of root Component
            dtClass = DataType.OBJECT;
            }
        else if (dtClass.isArray())
            {
            // treat arrays as Object
            dtClass = DataType.OBJECT;
            }
        else if (!dtClass.isClass())
            {
            throw new IllegalStateException();
            }
        
        String sClass = dtClass.getClassName();
        while (sClass.length() > 0)
            {
            Component cdJCS = getComponent(sClass);
            _assert(cdJCS != null, "Missing Java Class " + sClass);
            
            Behavior behavior = cdJCS.getBehavior(sBeh);
            if (behavior == null)
                {
                if (fDebug) _trace("behavior not " + "present on " + sClass);
        
                return null;
                }
            else if (cdJCS != getCD() &&
                (  behavior.getAccess() == Behavior.ACCESS_PRIVATE
                || behavior.getAccess() == Behavior.ACCESS_PACKAGE))
                {
                if (fDebug) _trace("behavior not accessible on " + sClass);
        
                return null;
                }
            else if (cdJCS.isInterface())
                {
                // if the type is an interface, then the result is an interface
                // constant, unless the method comes from java.lang.Object
                if (fDebug) _trace("interface behavior on " + sClass);
        
                return findMethod(sClass, sName, sSig);
                }
            else if (behavior.getExists() != Behavior.EXISTS_NOT)
                {
                if (fDebug) _trace("behavior exists on " + sClass);
        
                return new MethodConstant(
                        resolveClass(DataType.getClassType(sClass)),
                        new SignatureConstant(sName, sSig));
                }
        
            sClass = cdJCS.getSuperName();
            }
        
        if (fDebug) _trace("exiting resolveMethod; no method found");
        return null;
        }
    
    // Accessor for the property "CachedDefaultImports"
    /**
    * Setter for property CachedDefaultImports.<p>
    * (Static) Cache of system level imports.
    * 
    * @see #getDefaultImports
    */
    protected static void setCachedDefaultImports(com.tangosol.util.StringTable pCachedDefaultImports)
        {
        __s_CachedDefaultImports = pCachedDefaultImports;
        }
    
    // Accessor for the property "CachedIntegrators"
    /**
    * Setter for property CachedIntegrators.<p>
    * Cache of Component Integrators.
    * 
    * @see #findIntegrator
    */
    private void setCachedIntegrators(com.tangosol.util.StringTable pCachedIntegrators)
        {
        __m_CachedIntegrators = pCachedIntegrators;
        }
    
    // Accessor for the property "CD"
    /**
    * Setter for property CD.<p>
    * The Component Definition to be compiled. This property must be set by the
    * caller.
    */
    public void setCD(com.tangosol.dev.component.Component pCD)
        {
        __m_CD = pCD;
        }
    
    // Accessor for the property "ClassFile"
    /**
    * Setter for property ClassFile.<p>
    * The class file generated by this ClassGenerator. This property is set by
    * the "compile" method.
    */
    public void setClassFile(com.tangosol.dev.assembler.ClassFile pClassFile)
        {
        __m_ClassFile = pClassFile;
        }
    
    // Accessor for the property "Code"
    /**
    * Setter for property Code.<p>
    * Current code attribute processed (generated) by the ClassGenerator.
    */
    public void setCode(com.tangosol.dev.assembler.CodeAttribute pCode)
        {
        __m_Code = pCode;
        }
    
    // Accessor for the property "CompilePlan"
    /**
    * Setter for property CompilePlan.<p>
    * Compile plan for this ClassGenerator
    */
    private void setCompilePlan(com.tangosol.dev.component.CompilePlan pCompilePlan)
        {
        __m_CompilePlan = pCompilePlan;
        }
    
    // Accessor for the property "CompilePlanCache"
    /**
    * Setter for property CompilePlanCache.<p>
    * (Privately used) Cache of compile plans mapping the global component
    * names to the corresponding CompilePlans.
    * 
    * @see #resolveClass
    */
    private void setCompilePlanCache(java.util.Hashtable pCompilePlanCache)
        {
        __m_CompilePlanCache = pCompilePlanCache;
        }
    
    // Accessor for the property "DebugInfo"
    /**
    * Setter for property DebugInfo.<p>
    * This property controls whether the debug info (the file name attribute
    * and the line numbers) is being generated.
    * 
    * @see #OptimizePrivateAccessors property
    * @see #OptimizeDiscardedChildren property
    */
    public void setDebugInfo(boolean pDebugInfo)
        {
        __m_DebugInfo = pDebugInfo;
        }
    
    // Accessor for the property "DefaultImports"
    /**
    * Setter for property DefaultImports.<p>
    * Map of default imports for this component (includes the system level
    * defaults as well as auto generated children imports)
    * 
    * @see #CachedDefaultImports
    */
    private void setDefaultImports(com.tangosol.util.StringTable pDefaultImports)
        {
        __m_DefaultImports = pDefaultImports;
        }
    
    // Accessor for the property "ErrorList"
    /**
    * Setter for property ErrorList.<p>
    * ErrorList is supposed to be set by the user (caller) of the
    * ClassGenerator.
    */
    public void setErrorList(com.tangosol.util.ErrorList pErrorList)
        {
        __m_ErrorList = pErrorList;
        }
    
    // Accessor for the property "GenerateListing"
    /**
    * Setter for property GenerateListing.<p>
    * This property controls whether the ClassGenerator should generate the
    * java listing. The default value is true.
    */
    public void setGenerateListing(boolean pGenerateListing)
        {
        __m_GenerateListing = pGenerateListing;
        }
    
    // Accessor for the property "Indent"
    /**
    * Setter for property Indent.<p>
    * Privately used property that is used by the listing generator.
    */
    private void setIndent(StringBuffer pIndent)
        {
        __m_Indent = pIndent;
        }
    
    // Accessor for the property "Integrator"
    /**
    * Setter for property Integrator.<p>
    * Specifies the Integrator, set by the compile method or by the Integrators.
    */
    public void setIntegrator(Integrator pIntegrator)
        {
        __m_Integrator = pIntegrator;
        }
    
    // Accessor for the property "Listing"
    /**
    * Setter for property Listing.<p>
    * A StringBuffer used for the listing generation.
    */
    private void setListing(StringBuffer pListing)
        {
        __m_Listing = pListing;
        }
    
    // Accessor for the property "NewLine"
    /**
    * Setter for property NewLine.<p>
    * Privately used flag for listing generation
    */
    private void setNewLine(boolean pNewLine)
        {
        __m_NewLine = pNewLine;
        }
    
    // Accessor for the property "NextTempVariableNumber"
    /**
    * Setter for property NextTempVariableNumber.<p>
    * Get the next temporary variable number.  This will return a unique number
    * for use in generating a guarenteed unique local variable name.
    */
    private void setNextTempVariableNumber(int pNextTempVariableNumber)
        {
        __m_NextTempVariableNumber = pNextTempVariableNumber;
        }
    
    // Accessor for the property "OptimizeDiscardedChildren"
    /**
    * Setter for property OptimizeDiscardedChildren.<p>
    * This property controls the way an instantation and access to
    * "discardable" children is implemented.  Discardable children are the ones
    * that have no design info ("delta") that differentiate them form their
    * supers.  If set to true, the classes for those children are not generated
    * and all the references are resolved all the way up to the closest not
    * discardable supers.
    */
    public void setOptimizeDiscardedChildren(boolean pOptimizeDiscardedChildren)
        {
        __m_OptimizeDiscardedChildren = pOptimizeDiscardedChildren;
        }
    
    // Accessor for the property "OptimizePrivateAccessors"
    /**
    * Setter for property OptimizePrivateAccessors.<p>
    * This property controls the way an access to properties with private
    * accessors is implemented. If set to true, the generated code accesses the
    * data member directly; otherwise via accessors.
    */
    public void setOptimizePrivateAccessors(boolean pOptimizePrivateAccessors)
        {
        __m_OptimizePrivateAccessors = pOptimizePrivateAccessors;
        }
    
    // Accessor for the property "ParentGenerator"
    /**
    * Setter for property ParentGenerator.<p>
    * The class generator of the component class compile.  For child
    * components, this is the generator used by it's parent component.  For
    * Integrator classes, this is the generator used for the primary component
    * class generation.
    */
    public void setParentGenerator(ClassGenerator gen)
        {
        __m_ParentGenerator = (gen);
        
        setStorage                 (gen.getStorage());
        setCompilePlan             (gen.getCompilePlan());
        setCompilePlanCache        (gen.getCompilePlanCache());
        setErrorList               (gen.getErrorList());
        setGenerateListing         (gen.isGenerateListing());
        setOptimizePrivateAccessors(gen.isOptimizePrivateAccessors());
        setDebugInfo               (gen.isDebugInfo());
        setDefaultImports          (gen.getDefaultImports());
        setTraceLevel              (gen.getTraceLevel());

        }
    
    // Accessor for the property "ScriptTarget"
    /**
    * Setter for property ScriptTarget.<p>
    * Privately used Target component.
    */
    private void setScriptTarget(_package.component.dev.compiler.script.Target pScriptTarget)
        {
        __m_ScriptTarget = pScriptTarget;
        }
    
    // Accessor for the property "Storage"
    /**
    * Setter for property Storage.<p>
    * The storage used by the ClassGenerator. This property must be set by the
    * caller.
    */
    public void setStorage(_package.component.dev.Storage pStorage)
        {
        __m_Storage = pStorage;
        }
    
    // Accessor for the property "StoreResult"
    /**
    * Setter for property StoreResult.<p>
    * Specifies whether the generated classes and listings should be
    * automatically stored
    */
    public void setStoreResult(boolean pStoreResult)
        {
        __m_StoreResult = pStoreResult;
        }
    
    // Accessor for the property "SynthFieldCount"
    /**
    * Setter for property SynthFieldCount.<p>
    * Privately used to generate unique synthetic field names.
    */
    private void setSynthFieldCount(int pSynthFieldCount)
        {
        __m_SynthFieldCount = pSynthFieldCount;
        }
    
    // Accessor for the property "SynthMethodCount"
    /**
    * Setter for property SynthMethodCount.<p>
    * Privately used to generate unique synthetic method names.
    */
    private void setSynthMethodCount(int pSynthMethodCount)
        {
        __m_SynthMethodCount = pSynthMethodCount;
        }
    
    // Accessor for the property "TraceLevel"
    /**
    * Setter for property TraceLevel.<p>
    */
    public void setTraceLevel(int pTraceLevel)
        {
        __m_TraceLevel = pTraceLevel;
        }
    
    /**
    * Modify the ClassFile according to the design data in the Component
    * Definition
    * 
    * @rertun true, if the ClassFile has been changed; false otherwise
    * 
    * Note: properties ClassFile, CD and Storage must be set prior to the call
    * to this method.
    */
    public boolean updateClass()
            throws com.tangosol.dev.component.ComponentException
        {
        // import java.util.Enumeration;
        
        Component cdJCS    = getCD();
        Storage   storage  = getStorage();
        ClassFile clsf     = getClassFile();
        boolean   fUpdated = false;
        
        _assert(cdJCS != null && storage != null && clsf != null);
        _assert(cdJCS.isClass());
        
        /*
            Unfortunately, the following wouldn't work, because
            java compilers optimize the references to "final static" fields
            of intrinsic+ types and in-line the values
            (also see Property#isModifiable())
        
        // update the Java Constant properties
        String[] asProp = cdJCS.getProperty();
        for (int i = 0, c = asProp.length; i < c; i++)
            {
            String   sProp  = asProp[i];
            Property prop   = cdJCS.getProperty(sProp);
            DataType dtProp = prop.getDataType();
            Object   oValue = prop.isNoValue() ? getDefaultValue(dtProp) : prop.getValue();
            Field    field  = clsf.getField(sProp);
        
            if (prop.isJavaConstant() && dtProp.isExtendedSimple()
             && oValue != null && field != null)
                {
                field.setConstantValue(getConstant(oValue, dtProp));
                }
            }
        */
        
        // check whether this class implements an interface that
        // has been designed as a Component Definition 
        String[] asIface = cdJCS.getImplements();
        for (int i = 0, c = asIface.length; i < c; i++)
            {
            String sIface = asIface[i];
        
            Component cdIface = storage.loadComponent(sIface, true, null);
            if (cdIface != null)
                {
                for (Enumeration enum = cdIface.getBehaviors(); enum.hasMoreElements();)
                    {
                    Behavior bhvr = (Behavior) enum.nextElement();
        
                    if (bhvr.getCallableImplementationCount() > 0)
                        {
                        updateMethod(bhvr);
                        fUpdated = true;
                        }
                    }
                }
            }
        
        for (Enumeration enum = cdJCS.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
        
            if (bhvr.getCallableImplementationCount() > 0)
                {
                updateMethod(bhvr);
                fUpdated = true;
                }
            }
        
        fUpdated &= !getErrorList().isSevere();
        
        finalizeClassGeneration(fUpdated && isStoreResult());
        
        return fUpdated;
        }
    
    /**
    * Modify the specified method in the ClassFile according to the design data
    * in the Component Definition
    */
    private void updateMethod(com.tangosol.dev.component.Behavior bhvr)
            throws com.tangosol.dev.component.ComponentException
        {
        // import com.tangosol.util.UID;
        // import java.util.Enumeration;
        
        ClassFile clsf        = getClassFile();
        Component cdJCS       = getCD();
        Behavior  bhvrJCS     = cdJCS.getBehavior(bhvr.getSignature()); // bhvr is from interface
        String    sMethodName = bhvr.getName();
        String    sMethodSig  = bhvr.getJVMSignature();
        Method    methodBase  = clsf.getMethod(sMethodName, sMethodSig);
        UID       uid         = bhvr.getUID();
        String    sGuid       = uid == null ? "tangosol" : uid.toString().substring(2); // skip "0x"
        
        if (methodBase == null &&
            bhvrJCS != null && bhvrJCS.isFromSuper() && bhvrJCS.isFinal())
            {
            // should not override final methods
            return;
            }
        
        moveOriginalMethod:
        if (methodBase != null)
            {
            // this method already exists, move it over
        
            clsf.removeMethod(sMethodSig);
        
            if (methodBase.isNative())
                {
                throw new IllegalStateException("Native method cannot be modified " + methodBase);
                }
        
            if (methodBase.isAbstract())
                {
                // no reason to move over an abstract method
                // just replace it with an implementation
                methodBase = null;
                break moveOriginalMethod;
                }
        
            // to name the "moved over" base method we will use
            // the GUID of the behavior. This will allow us not to
            // multiply the same method if an output class serves
            // again as an input...
            Method methodOrig   = methodBase;
            /*
            String sNameSynth = bhvr.getName() + "$Orig";
        
            sMethodName = sNameSynth;
            for (int i = 0; clsf.getMethod(sMethodName, sMethodSig) != null; i++)
                {
                sMethodName = sNameSynth + "$" + i;
                }
            */
            sMethodName = bhvr.getName() + "$" + sGuid + "$Orig";
            methodBase  = clsf.getMethod(sMethodName, sMethodSig);
            if (methodBase != null)
                {
                // the original has already been moved
                break moveOriginalMethod;
                }
            
            methodBase = clsf.addMethod(sMethodName, sMethodSig);
            methodBase.setPrivate();
            methodBase.setFinal(false);
            methodBase.setSynthetic(true);
        
            // clone the rest
            methodBase.setStatic(methodOrig.isStatic());
            methodBase.setSynchronized(methodOrig.isSynchronized());
        
            for (Enumeration enum = methodOrig.getExceptions(); enum.hasMoreElements();)
                {
                String sClz = (String) enum.nextElement();
                methodBase.addException(sClz);
                }
        
            CodeAttribute code = methodBase.getCode();
            for (Op op = methodOrig.getCode().getFirstOp(); op != null; op = op.getNext())
                {
                code.setLine(op.getLine());
                code.add(op);
                }
            }
        
        int cImpls = bhvr.getCallableImplementationCount();
        for (int i = cImpls - 1; i >= 0; i--)
            {
            Implementation impl = bhvr.getImplementation(i);
        
            sMethodName = bhvr.getName();
            if (i > 0)
                {
                // as above we will use the GUID of the behavior to generate
                // unique synthetic implementation name...
                /*
                String sNameSynth = sMethodName + "$" + i;
        
                sMethodName = sNameSynth;
                for (int j = 0; clsf.getMethod(sMethodName, sMethodSig) != null; j++)
                    {
                    sMethodName = sNameSynth + "$" + j;
                    }
                */
                sMethodName += "$" + sGuid + "$" + i;
                }
        
            Method method = clsf.addMethod(sMethodName, sMethodSig);
            if (i > 0)
                {
                method.setPrivate();
                method.setFinal(false);
                method.setSynthetic(true);
                }
            else
                {
                switch (bhvr.getAccess())
                    {
                    default:
                    case Behavior.ACCESS_PUBLIC:
                        method.setPublic();
                        break;
                    case Behavior.ACCESS_PROTECTED:
                        method.setProtected();
                        break;
                    case Behavior.ACCESS_PACKAGE:
                        method.setPackage();
                        break;
                    case Behavior.ACCESS_PRIVATE:
                        method.setPrivate();
                        break;
                    }
                method.setSynthetic(false);
                method.setSynchronized(bhvr.isSynchronized());
                }
            method.setStatic(bhvr.isStatic());
        
            String[] asException = bhvr.getExceptionNames();
            for (int j = 0; j < asException.length; j++)
                {
                String sClz = asException[j];
                method.addException(sClz);
                }
        
            // determine what the "super" is and compile the implementation
            Constant constantSuper = null;
            if (methodBase != null)
                {
                // synthetic super method
                constantSuper = new MethodConstant(clsf.getClassConstant(),
                    new SignatureConstant(methodBase.getName(), sMethodSig));
                }
            else if (bhvrJCS != null && bhvrJCS.isFromSuper())
                {
                _assert(bhvrJCS.getComponent().isClass());
                constantSuper = findMethod(bhvrJCS.getComponent().getSuperName(),
                    bhvr.getName(), sMethodSig);
                }
            else if (bhvr.getComponent().isInterface())
                {
                // we are trying to add a method that was designed on an interface
                // if super class for this ClassFile is not available
                // (which could happen in a case of dynamic personalization)
                // lets assume that the method is declared a the immediate super ...
                // usually JVM would be able to patch the "super" call
                constantSuper = new MethodConstant(clsf.getSuperClassConstant(),
                    new SignatureConstant(bhvr.getName(), sMethodSig));
                }
        
            compileImplementation(impl, method, constantSuper);
        
            methodBase = method;
            }
        }
    }
