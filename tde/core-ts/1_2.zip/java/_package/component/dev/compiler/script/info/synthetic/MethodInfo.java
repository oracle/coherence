/* Class
*     _package.component.dev.compiler.script.info.synthetic.MethodInfo
*/

package _package.component.dev.compiler.script.info.synthetic;

import com.tangosol.dev.assembler.Constant;
import com.tangosol.dev.assembler.FieldConstant;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.compiler.FieldInfo; // as iFieldInfo

/**
* Used for "super" invocations that actually go to the next implementation on
* the current component.
*/
public class MethodInfo
        extends    _package.component.dev.compiler.script.info.Synthetic
        implements com.tangosol.dev.compiler.MethodInfo
    {
    // Fields declarations
    
    /**
    * Property FieldInfo
    *
    */
    private com.tangosol.dev.compiler.FieldInfo __m_FieldInfo;
    
    /**
    * Property ParamCount
    *
    */
    
    /**
    * Property ParamInfo
    *
    */
    
    // Default constructor
    public MethodInfo()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public MethodInfo(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new MethodInfo();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/info/synthetic/MethodInfo".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    public java.util.Enumeration exceptionTypes()
        {
        
        return getContext().getMethodInfo().exceptionTypes();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public com.tangosol.dev.assembler.Constant getConstant()
        {
        // import com.tangosol.dev.assembler.Constant;
        // import com.tangosol.dev.assembler.MethodConstant;
        
        Constant constant = getContext().getSuperConstant();
        return constant instanceof MethodConstant ? constant : null;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public com.tangosol.dev.component.DataType getDataType()
        {
        
        return getContext().getMethodInfo().getDataType();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "FieldInfo"
    public com.tangosol.dev.compiler.FieldInfo getFieldInfo()
        {
        // import com.tangosol.dev.assembler.Constant;
        // import com.tangosol.dev.assembler.FieldConstant;
        // import com.tangosol.dev.compiler.FieldInfo as iFieldInfo;
        
        iFieldInfo info = (iFieldInfo) __m_FieldInfo;
        if (info != null)
            {
            return info;
            }
        
        Constant constant = getContext().getSuperConstant();
        if (constant == null)
            {
            // 1999.11.17  cp   When a super call is made from a script in which
            // there is no super, a Synthetic.MethodInfo is used to inline to a
            // Synthetic.NoFieldInfo to inline to a constant default value (or
            // nothing for VOID types)
            NoFieldInfo noinfo = new NoFieldInfo();
            noinfo.setContext(getContext());
            setFieldInfo(info = noinfo);
            }
        else if (constant instanceof FieldConstant)
            {
            FieldInfo fieldinfo = new FieldInfo();
            fieldinfo.setContext(getContext());
            setFieldInfo(info = fieldinfo);
            }
        
        return info;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public String getName()
        {
        
        return getContext().getMethodInfo().getName();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "ParamCount"
    public int getParamCount()
        {
        
        return getContext().getMethodInfo().getParamCount();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "ParamInfo"
    public com.tangosol.dev.compiler.ParamInfo getParamInfo(int i)
        {
        
        return getContext().getMethodInfo().getParamInfo(i);
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public com.tangosol.dev.compiler.TypeInfo getTypeInfo()
        {
        
        return getContext().getMethodInfo().getTypeInfo();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isInlineable()
        {
        
        // if there is a field info then this method exists solely to
        // be inlined by using that field
        return getFieldInfo() != null;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isInlined()
        {
        
        // if there is a field info then this method exists solely to
        // be inlined by using that field
        return getFieldInfo() != null;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isPrivate()
        {
        return true;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isStatic()
        {
        
        return getContext().getMethodInfo().isStatic();
        }
    
    // Accessor for the property "FieldInfo"
    public void setFieldInfo(com.tangosol.dev.compiler.FieldInfo pFieldInfo)
        {
        __m_FieldInfo = pFieldInfo;
        }
    }
