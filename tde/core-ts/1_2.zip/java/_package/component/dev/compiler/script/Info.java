/* Class
*     _package.component.dev.compiler.script.Info
*/

package _package.component.dev.compiler.script;

import com.tangosol.dev.compiler.CompilerErrorInfo;
import com.tangosol.dev.compiler.CompilerException;
import com.tangosol.dev.compiler.Constants;
import com.tangosol.util.ErrorList;

public abstract class Info
        extends    _package.component.dev.compiler.Script
        implements com.tangosol.dev.compiler.Info
    {
    // Fields declarations
    
    /**
    * Property Abstract
    *
    */
    
    /**
    * Property Accessible
    *
    */
    
    /**
    * Property Constant
    *
    */
    
    /**
    * Property Context
    *
    */
    private transient Context __m_Context;
    
    /**
    * Property DataType
    *
    */
    
    /**
    * Property Deprecated
    *
    */
    
    /**
    * Property DeprecationWarningIssued
    *
    */
    private boolean __m_DeprecationWarningIssued;
    
    /**
    * Property Final
    *
    */
    
    /**
    * Property Name
    *
    */
    
    /**
    * Property Package
    *
    */
    
    /**
    * Property Private
    *
    */
    
    /**
    * Property Protected
    *
    */
    
    /**
    * Property Public
    *
    */
    
    /**
    * Property Static
    *
    */
    
    // Initializing constructor
    public Info(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/Info".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.dev.compiler.Info
    public void addDependency(boolean fRuntime, int iStartLine, int ofStart, int iEndLine, int ofEnd)
            throws com.tangosol.dev.compiler.CompilerException
        {
        // import com.tangosol.util.ErrorList;
        // import com.tangosol.dev.compiler.CompilerErrorInfo;
        // import com.tangosol.dev.compiler.CompilerException;
        // import com.tangosol.dev.compiler.Constants;
        
        // TODO register dependency
        
        if (isDeprecated() && !isDeprecationWarningIssued())
            {
            // issue deprecation warning
            ErrorList errlist = getContext().getErrorList();
            if (errlist != null)
                {
                errlist.add(new CompilerErrorInfo(Constants.WARNING, Constants.WARN_DEPRECATED,
                        Constants.RESOURCES, new String[] {toString()}, iStartLine, ofStart, iEndLine, ofEnd));
                }
        
            setDeprecationWarningIssued(true);
            }
        }
    
    // From interface: com.tangosol.dev.compiler.Info
    // Accessor for the property "Constant"
    public com.tangosol.dev.assembler.Constant getConstant()
        {
        return null;
        }
    
    // Accessor for the property "Context"
    public Context getContext()
        {
        return __m_Context;
        }
    
    // From interface: com.tangosol.dev.compiler.Info
    // Accessor for the property "DataType"
    public com.tangosol.dev.component.DataType getDataType()
        {
        return null;
        }
    
    // From interface: com.tangosol.dev.compiler.Info
    // Accessor for the property "Name"
    public String getName()
        {
        return null;
        }
    
    // From interface: com.tangosol.dev.compiler.Info
    // Accessor for the property "Abstract"
    public boolean isAbstract()
        {
        return false;
        }
    
    // From interface: com.tangosol.dev.compiler.Info
    // Accessor for the property "Accessible"
    public boolean isAccessible()
        {
        // default implementation:  accessible iff public
        return isPublic();
        }
    
    // Accessor for the property "Deprecated"
    public boolean isDeprecated()
        {
        return false;
        }
    
    // Accessor for the property "DeprecationWarningIssued"
    private boolean isDeprecationWarningIssued()
        {
        return __m_DeprecationWarningIssued;
        }
    
    // From interface: com.tangosol.dev.compiler.Info
    // Accessor for the property "Final"
    public boolean isFinal()
        {
        return false;
        }
    
    // From interface: com.tangosol.dev.compiler.Info
    // Accessor for the property "Package"
    public boolean isPackage()
        {
        return false;
        }
    
    // From interface: com.tangosol.dev.compiler.Info
    // Accessor for the property "Private"
    public boolean isPrivate()
        {
        return false;
        }
    
    // From interface: com.tangosol.dev.compiler.Info
    // Accessor for the property "Protected"
    public boolean isProtected()
        {
        return false;
        }
    
    // From interface: com.tangosol.dev.compiler.Info
    // Accessor for the property "Public"
    public boolean isPublic()
        {
        return false;
        }
    
    // From interface: com.tangosol.dev.compiler.Info
    // Accessor for the property "Static"
    public boolean isStatic()
        {
        return false;
        }
    
    // Accessor for the property "Context"
    public void setContext(Context pContext)
        {
        __m_Context = pContext;
        }
    
    // Accessor for the property "DeprecationWarningIssued"
    private void setDeprecationWarningIssued(boolean f)
        {
        __m_DeprecationWarningIssued = f;
        }
    
    // Declared at the super level
    public String toString()
        {
        String s    = getClass().getName();
        final String CHOP = ".Info.";
        s = s.substring(s.indexOf(CHOP) + CHOP.length());
        return s + ' ' + getName();
        }
    }
