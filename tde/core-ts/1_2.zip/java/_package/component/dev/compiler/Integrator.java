/* Class
*     _package.component.dev.compiler.Integrator
*/

package _package.component.dev.compiler;

import _package.component.dev.Storage;
import _package.component.dev.compiler.ClassGenerator;
import com.tangosol.dev.assembler.Aaload;
import com.tangosol.dev.assembler.Aastore;
import com.tangosol.dev.assembler.AccessFlags;
import com.tangosol.dev.assembler.Aconst;
import com.tangosol.dev.assembler.Aload;
import com.tangosol.dev.assembler.Anewarray;
import com.tangosol.dev.assembler.Areturn;
import com.tangosol.dev.assembler.Arraylength;
import com.tangosol.dev.assembler.Astore;
import com.tangosol.dev.assembler.Athrow;
import com.tangosol.dev.assembler.Attribute;
import com.tangosol.dev.assembler.Avar;
import com.tangosol.dev.assembler.Baload;
import com.tangosol.dev.assembler.Bastore;
import com.tangosol.dev.assembler.Begin;
import com.tangosol.dev.assembler.Bnewarray;
import com.tangosol.dev.assembler.Caload;
import com.tangosol.dev.assembler.Case;
import com.tangosol.dev.assembler.Castore;
import com.tangosol.dev.assembler.Catch;
import com.tangosol.dev.assembler.Checkcast;
import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.ClassFile;
import com.tangosol.dev.assembler.Cnewarray;
import com.tangosol.dev.assembler.CodeAttribute;
import com.tangosol.dev.assembler.Constant;
import com.tangosol.dev.assembler.ConstantPool;
import com.tangosol.dev.assembler.ConstantValueAttribute;
import com.tangosol.dev.assembler.Constants;
import com.tangosol.dev.assembler.D2f;
import com.tangosol.dev.assembler.D2i;
import com.tangosol.dev.assembler.D2l;
import com.tangosol.dev.assembler.Dadd;
import com.tangosol.dev.assembler.Daload;
import com.tangosol.dev.assembler.Dastore;
import com.tangosol.dev.assembler.Dcmpg;
import com.tangosol.dev.assembler.Dcmpl;
import com.tangosol.dev.assembler.Dconst;
import com.tangosol.dev.assembler.Ddiv;
import com.tangosol.dev.assembler.DeprecatedAttribute;
import com.tangosol.dev.assembler.Dload;
import com.tangosol.dev.assembler.Dmul;
import com.tangosol.dev.assembler.Dneg;
import com.tangosol.dev.assembler.Dnewarray;
import com.tangosol.dev.assembler.DoubleConstant;
import com.tangosol.dev.assembler.Drem;
import com.tangosol.dev.assembler.Dreturn;
import com.tangosol.dev.assembler.Dstore;
import com.tangosol.dev.assembler.Dsub;
import com.tangosol.dev.assembler.Dup2;
import com.tangosol.dev.assembler.Dup2_x1;
import com.tangosol.dev.assembler.Dup2_x2;
import com.tangosol.dev.assembler.Dup;
import com.tangosol.dev.assembler.Dup_x1;
import com.tangosol.dev.assembler.Dup_x2;
import com.tangosol.dev.assembler.Dvar;
import com.tangosol.dev.assembler.End;
import com.tangosol.dev.assembler.ExceptionsAttribute;
import com.tangosol.dev.assembler.F2d;
import com.tangosol.dev.assembler.F2i;
import com.tangosol.dev.assembler.F2l;
import com.tangosol.dev.assembler.Fadd;
import com.tangosol.dev.assembler.Faload;
import com.tangosol.dev.assembler.Fastore;
import com.tangosol.dev.assembler.Fcmpg;
import com.tangosol.dev.assembler.Fcmpl;
import com.tangosol.dev.assembler.Fconst;
import com.tangosol.dev.assembler.Fdiv;
import com.tangosol.dev.assembler.Field;
import com.tangosol.dev.assembler.FieldConstant;
import com.tangosol.dev.assembler.Fload;
import com.tangosol.dev.assembler.FloatConstant;
import com.tangosol.dev.assembler.Fmul;
import com.tangosol.dev.assembler.Fneg;
import com.tangosol.dev.assembler.Fnewarray;
import com.tangosol.dev.assembler.Frem;
import com.tangosol.dev.assembler.Freturn;
import com.tangosol.dev.assembler.Fstore;
import com.tangosol.dev.assembler.Fsub;
import com.tangosol.dev.assembler.Fvar;
import com.tangosol.dev.assembler.Getfield;
import com.tangosol.dev.assembler.Getstatic;
import com.tangosol.dev.assembler.Goto;
import com.tangosol.dev.assembler.GuardedSection;
import com.tangosol.dev.assembler.I2b;
import com.tangosol.dev.assembler.I2c;
import com.tangosol.dev.assembler.I2d;
import com.tangosol.dev.assembler.I2f;
import com.tangosol.dev.assembler.I2l;
import com.tangosol.dev.assembler.I2s;
import com.tangosol.dev.assembler.Iadd;
import com.tangosol.dev.assembler.Iaload;
import com.tangosol.dev.assembler.Iand;
import com.tangosol.dev.assembler.Iastore;
import com.tangosol.dev.assembler.Iconst;
import com.tangosol.dev.assembler.Idiv;
import com.tangosol.dev.assembler.If_acmpeq;
import com.tangosol.dev.assembler.If_acmpne;
import com.tangosol.dev.assembler.If_icmpeq;
import com.tangosol.dev.assembler.If_icmpge;
import com.tangosol.dev.assembler.If_icmpgt;
import com.tangosol.dev.assembler.If_icmple;
import com.tangosol.dev.assembler.If_icmplt;
import com.tangosol.dev.assembler.If_icmpne;
import com.tangosol.dev.assembler.Ifeq;
import com.tangosol.dev.assembler.Ifge;
import com.tangosol.dev.assembler.Ifgt;
import com.tangosol.dev.assembler.Ifle;
import com.tangosol.dev.assembler.Iflt;
import com.tangosol.dev.assembler.Ifne;
import com.tangosol.dev.assembler.Ifnonnull;
import com.tangosol.dev.assembler.Ifnull;
import com.tangosol.dev.assembler.Iinc;
import com.tangosol.dev.assembler.Iload;
import com.tangosol.dev.assembler.Imul;
import com.tangosol.dev.assembler.Ineg;
import com.tangosol.dev.assembler.Inewarray;
import com.tangosol.dev.assembler.InnerClass;
import com.tangosol.dev.assembler.InnerClassesAttribute;
import com.tangosol.dev.assembler.Instanceof;
import com.tangosol.dev.assembler.IntConstant;
import com.tangosol.dev.assembler.InterfaceConstant;
import com.tangosol.dev.assembler.Invokeinterface;
import com.tangosol.dev.assembler.Invokespecial;
import com.tangosol.dev.assembler.Invokestatic;
import com.tangosol.dev.assembler.Invokevirtual;
import com.tangosol.dev.assembler.Ior;
import com.tangosol.dev.assembler.Irem;
import com.tangosol.dev.assembler.Ireturn;
import com.tangosol.dev.assembler.Ishl;
import com.tangosol.dev.assembler.Ishr;
import com.tangosol.dev.assembler.Istore;
import com.tangosol.dev.assembler.Isub;
import com.tangosol.dev.assembler.Iushr;
import com.tangosol.dev.assembler.Ivar;
import com.tangosol.dev.assembler.Ixor;
import com.tangosol.dev.assembler.Jsr;
import com.tangosol.dev.assembler.L2d;
import com.tangosol.dev.assembler.L2f;
import com.tangosol.dev.assembler.L2i;
import com.tangosol.dev.assembler.Label;
import com.tangosol.dev.assembler.Ladd;
import com.tangosol.dev.assembler.Laload;
import com.tangosol.dev.assembler.Land;
import com.tangosol.dev.assembler.Lastore;
import com.tangosol.dev.assembler.Lcmp;
import com.tangosol.dev.assembler.Lconst;
import com.tangosol.dev.assembler.Ldiv;
import com.tangosol.dev.assembler.LineNumberTableAttribute;
import com.tangosol.dev.assembler.Lload;
import com.tangosol.dev.assembler.Lmul;
import com.tangosol.dev.assembler.Lneg;
import com.tangosol.dev.assembler.Lnewarray;
import com.tangosol.dev.assembler.LocalVariableTableAttribute;
import com.tangosol.dev.assembler.LongConstant;
import com.tangosol.dev.assembler.Lookupswitch;
import com.tangosol.dev.assembler.Lor;
import com.tangosol.dev.assembler.Lrem;
import com.tangosol.dev.assembler.Lreturn;
import com.tangosol.dev.assembler.Lshl;
import com.tangosol.dev.assembler.Lshr;
import com.tangosol.dev.assembler.Lstore;
import com.tangosol.dev.assembler.Lsub;
import com.tangosol.dev.assembler.Lushr;
import com.tangosol.dev.assembler.Lvar;
import com.tangosol.dev.assembler.Lxor;
import com.tangosol.dev.assembler.Method;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.assembler.Monitorenter;
import com.tangosol.dev.assembler.Monitorexit;
import com.tangosol.dev.assembler.Multianewarray;
import com.tangosol.dev.assembler.New;
import com.tangosol.dev.assembler.Nop;
import com.tangosol.dev.assembler.Op;
import com.tangosol.dev.assembler.OpArray;
import com.tangosol.dev.assembler.OpBranch;
import com.tangosol.dev.assembler.OpConst;
import com.tangosol.dev.assembler.OpDeclare;
import com.tangosol.dev.assembler.OpLoad;
import com.tangosol.dev.assembler.OpStore;
import com.tangosol.dev.assembler.OpSwitch;
import com.tangosol.dev.assembler.OpVariable;
import com.tangosol.dev.assembler.Pop2;
import com.tangosol.dev.assembler.Pop;
import com.tangosol.dev.assembler.Putfield;
import com.tangosol.dev.assembler.Putstatic;
import com.tangosol.dev.assembler.RefConstant;
import com.tangosol.dev.assembler.Ret;
import com.tangosol.dev.assembler.Return;
import com.tangosol.dev.assembler.Rstore;
import com.tangosol.dev.assembler.Rvar;
import com.tangosol.dev.assembler.Saload;
import com.tangosol.dev.assembler.Sastore;
import com.tangosol.dev.assembler.SignatureConstant;
import com.tangosol.dev.assembler.Snewarray;
import com.tangosol.dev.assembler.SourceFileAttribute;
import com.tangosol.dev.assembler.StringConstant;
import com.tangosol.dev.assembler.Swap;
import com.tangosol.dev.assembler.Switch;
import com.tangosol.dev.assembler.SyntheticAttribute;
import com.tangosol.dev.assembler.Tableswitch;
import com.tangosol.dev.assembler.Try;
import com.tangosol.dev.assembler.UtfConstant;
import com.tangosol.dev.assembler.VMStructure;
import com.tangosol.dev.assembler.Znewarray;
import com.tangosol.dev.compiler.Compiler;
import com.tangosol.dev.compiler.CompilerException;
import com.tangosol.dev.compiler.Context;
import com.tangosol.dev.compiler.Locator;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Implementation;
import com.tangosol.dev.component.Integration;
import com.tangosol.dev.component.Interface;
import com.tangosol.dev.component.Parameter;
import com.tangosol.dev.component.Property;
import com.tangosol.dev.component.ReturnValue;
import com.tangosol.util.Base;
import com.tangosol.util.ChainedEnumerator;
import com.tangosol.util.IteratorEnumerator;
import com.tangosol.util.LiteSet;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public abstract class Integrator
        extends    _package.component.dev.Compiler
    {
    // Fields declarations
    
    /**
    * Property AutoGenBehaviors
    *
    * Specifies the list of signatures for behaviors that will be automatically
    * generated by this integration model to optimize the peer access. This
    * list is used by the ClassGenerator to allow the integrator make some
    * specific implementation by calling <code>generateImpementation</code> for
    * each behavior in this array (see compile(), step 14). This list is also
    * used by 
    * <code>isBehaviorAutogen</code> to answer a question asked by
    * <code>ClassGenerator.isCodeGenerating</code>.
    * 
    * @see AbstractBean#setGenerator
    */
    private transient java.util.List __m_AutoGenBehaviors;
    
    /**
    * Property CD
    *
    * The Integrator Component.
    */
    private transient com.tangosol.dev.component.Component __m_CD;
    
    /**
    * Property CustomInits
    *
    * Specifies whether there is a custom initialization for this component.
    * The sub classes override this.
    * 
    * @see AbstractBean.JavaBean#isCustomInits
    */
    
    /**
    * Property FeedType
    *
    * Specifies the integration feed type.
    */
    private transient com.tangosol.dev.component.DataType __m_FeedType;
    
    /**
    * Property IntegrateeType
    *
    * The data type for the integrated class.
    */
    
    /**
    * Property IntegrationMap
    *
    * (Privately used) Integration Map.  All access to the map information is
    * now done via virtual methods against this Integrator class.
    * 
    * This MUST be set before the CD is set.
    */
    private transient com.tangosol.dev.component.Integration __m_IntegrationMap;
    
    /**
    * Property IntegrationMisc
    *
    */
    
    /**
    * Property IntegrationModel
    *
    */
    
    /**
    * Property MappedBehaviors
    *
    * (Calculated) The enumeration of all the mapped behaviors.
    */
    
    /**
    * Property MappedProperties
    *
    * (Calculated) The enumeration of all the mapped properties.
    */
    
    /**
    * Property PEER_FEED
    *
    */
    public static final int PEER_FEED = 0;
    
    /**
    * Property PEER_SINK
    *
    */
    public static final int PEER_SINK = 1;
    
    /**
    * Property Remote
    *
    * Returns whether or not this integrator is an integrator that facilitates
    * remoting components.
    */
    private transient boolean __m_Remote;
    
    /**
    * Property RoutedProperties
    *
    * Used during feed generation to hold the Properties that are routed
    * between the component and the feed, but may not be present in the
    * integration map.
    * 
    * @see #setCDAndMap
    */
    private java.util.Collection __m_RoutedProperties;
    
    /**
    * Property SinkType
    *
    * Specifies the integration sink type.
    */
    private transient com.tangosol.dev.component.DataType __m_SinkType;
    
    // Initializing constructor
    public Integrator(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/Integrator".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.Dev.Compiler.ClassGenerator;
        // import Component.Dev.Storage;
        // import com.tangosol.dev.assembler.Aaload;
        // import com.tangosol.dev.assembler.Aastore;
        // import com.tangosol.dev.assembler.AccessFlags;
        // import com.tangosol.dev.assembler.Aconst;
        // import com.tangosol.dev.assembler.Aload;
        // import com.tangosol.dev.assembler.Anewarray;
        // import com.tangosol.dev.assembler.Areturn;
        // import com.tangosol.dev.assembler.Arraylength;
        // import com.tangosol.dev.assembler.Astore;
        // import com.tangosol.dev.assembler.Athrow;
        // import com.tangosol.dev.assembler.Attribute;
        // import com.tangosol.dev.assembler.Avar;
        // import com.tangosol.dev.assembler.Baload;
        // import com.tangosol.dev.assembler.Bastore;
        // import com.tangosol.dev.assembler.Begin;
        // import com.tangosol.dev.assembler.Bnewarray;
        // import com.tangosol.dev.assembler.Caload;
        // import com.tangosol.dev.assembler.Case;
        // import com.tangosol.dev.assembler.Castore;
        // import com.tangosol.dev.assembler.Catch;
        // import com.tangosol.dev.assembler.Checkcast;
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.dev.assembler.Cnewarray;
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.Constant;
        // import com.tangosol.dev.assembler.ConstantPool;
        // import com.tangosol.dev.assembler.Constants;
        // import com.tangosol.dev.assembler.ConstantValueAttribute;
        // import com.tangosol.dev.assembler.D2f;
        // import com.tangosol.dev.assembler.D2i;
        // import com.tangosol.dev.assembler.D2l;
        // import com.tangosol.dev.assembler.Dadd;
        // import com.tangosol.dev.assembler.Daload;
        // import com.tangosol.dev.assembler.Dastore;
        // import com.tangosol.dev.assembler.Dcmpg;
        // import com.tangosol.dev.assembler.Dcmpl;
        // import com.tangosol.dev.assembler.Dconst;
        // import com.tangosol.dev.assembler.Ddiv;
        // import com.tangosol.dev.assembler.DeprecatedAttribute;
        // import com.tangosol.dev.assembler.Dload;
        // import com.tangosol.dev.assembler.Dmul;
        // import com.tangosol.dev.assembler.Dneg;
        // import com.tangosol.dev.assembler.Dnewarray;
        // import com.tangosol.dev.assembler.DoubleConstant;
        // import com.tangosol.dev.assembler.Drem;
        // import com.tangosol.dev.assembler.Dreturn;
        // import com.tangosol.dev.assembler.Dstore;
        // import com.tangosol.dev.assembler.Dsub;
        // import com.tangosol.dev.assembler.Dup;
        // import com.tangosol.dev.assembler.Dup2;
        // import com.tangosol.dev.assembler.Dup2_x1;
        // import com.tangosol.dev.assembler.Dup2_x2;
        // import com.tangosol.dev.assembler.Dup_x1;
        // import com.tangosol.dev.assembler.Dup_x2;
        // import com.tangosol.dev.assembler.Dvar;
        // import com.tangosol.dev.assembler.End;
        // import com.tangosol.dev.assembler.ExceptionsAttribute;
        // import com.tangosol.dev.assembler.F2d;
        // import com.tangosol.dev.assembler.F2i;
        // import com.tangosol.dev.assembler.F2l;
        // import com.tangosol.dev.assembler.Fadd;
        // import com.tangosol.dev.assembler.Faload;
        // import com.tangosol.dev.assembler.Fastore;
        // import com.tangosol.dev.assembler.Fcmpg;
        // import com.tangosol.dev.assembler.Fcmpl;
        // import com.tangosol.dev.assembler.Fconst;
        // import com.tangosol.dev.assembler.Fdiv;
        // import com.tangosol.dev.assembler.Field;
        // import com.tangosol.dev.assembler.FieldConstant;
        // import com.tangosol.dev.assembler.Fload;
        // import com.tangosol.dev.assembler.FloatConstant;
        // import com.tangosol.dev.assembler.Fmul;
        // import com.tangosol.dev.assembler.Fneg;
        // import com.tangosol.dev.assembler.Fnewarray;
        // import com.tangosol.dev.assembler.Frem;
        // import com.tangosol.dev.assembler.Freturn;
        // import com.tangosol.dev.assembler.Fstore;
        // import com.tangosol.dev.assembler.Fsub;
        // import com.tangosol.dev.assembler.Fvar;
        // import com.tangosol.dev.assembler.Getfield;
        // import com.tangosol.dev.assembler.Getstatic;
        // import com.tangosol.dev.assembler.Goto;
        // import com.tangosol.dev.assembler.GuardedSection;
        // import com.tangosol.dev.assembler.I2b;
        // import com.tangosol.dev.assembler.I2c;
        // import com.tangosol.dev.assembler.I2d;
        // import com.tangosol.dev.assembler.I2f;
        // import com.tangosol.dev.assembler.I2l;
        // import com.tangosol.dev.assembler.I2s;
        // import com.tangosol.dev.assembler.Iadd;
        // import com.tangosol.dev.assembler.Iaload;
        // import com.tangosol.dev.assembler.Iand;
        // import com.tangosol.dev.assembler.Iastore;
        // import com.tangosol.dev.assembler.Iconst;
        // import com.tangosol.dev.assembler.Idiv;
        // import com.tangosol.dev.assembler.Ifeq;
        // import com.tangosol.dev.assembler.Ifge;
        // import com.tangosol.dev.assembler.Ifgt;
        // import com.tangosol.dev.assembler.Ifle;
        // import com.tangosol.dev.assembler.Iflt;
        // import com.tangosol.dev.assembler.Ifne;
        // import com.tangosol.dev.assembler.Ifnonnull;
        // import com.tangosol.dev.assembler.Ifnull;
        // import com.tangosol.dev.assembler.If_acmpeq;
        // import com.tangosol.dev.assembler.If_acmpne;
        // import com.tangosol.dev.assembler.If_icmpeq;
        // import com.tangosol.dev.assembler.If_icmpge;
        // import com.tangosol.dev.assembler.If_icmpgt;
        // import com.tangosol.dev.assembler.If_icmple;
        // import com.tangosol.dev.assembler.If_icmplt;
        // import com.tangosol.dev.assembler.If_icmpne;
        // import com.tangosol.dev.assembler.Iinc;
        // import com.tangosol.dev.assembler.Iload;
        // import com.tangosol.dev.assembler.Imul;
        // import com.tangosol.dev.assembler.Ineg;
        // import com.tangosol.dev.assembler.Inewarray;
        // import com.tangosol.dev.assembler.InnerClass;
        // import com.tangosol.dev.assembler.InnerClassesAttribute;
        // import com.tangosol.dev.assembler.Instanceof;
        // import com.tangosol.dev.assembler.IntConstant;
        // import com.tangosol.dev.assembler.InterfaceConstant;
        // import com.tangosol.dev.assembler.Invokeinterface;
        // import com.tangosol.dev.assembler.Invokespecial;
        // import com.tangosol.dev.assembler.Invokestatic;
        // import com.tangosol.dev.assembler.Invokevirtual;
        // import com.tangosol.dev.assembler.Ior;
        // import com.tangosol.dev.assembler.Irem;
        // import com.tangosol.dev.assembler.Ireturn;
        // import com.tangosol.dev.assembler.Ishl;
        // import com.tangosol.dev.assembler.Ishr;
        // import com.tangosol.dev.assembler.Istore;
        // import com.tangosol.dev.assembler.Isub;
        // import com.tangosol.dev.assembler.Iushr;
        // import com.tangosol.dev.assembler.Ivar;
        // import com.tangosol.dev.assembler.Ixor;
        // import com.tangosol.dev.assembler.Jsr;
        // import com.tangosol.dev.assembler.L2d;
        // import com.tangosol.dev.assembler.L2f;
        // import com.tangosol.dev.assembler.L2i;
        // import com.tangosol.dev.assembler.Label;
        // import com.tangosol.dev.assembler.Ladd;
        // import com.tangosol.dev.assembler.Laload;
        // import com.tangosol.dev.assembler.Land;
        // import com.tangosol.dev.assembler.Lastore;
        // import com.tangosol.dev.assembler.Lcmp;
        // import com.tangosol.dev.assembler.Lconst;
        // import com.tangosol.dev.assembler.Ldiv;
        // import com.tangosol.dev.assembler.LineNumberTableAttribute;
        // import com.tangosol.dev.assembler.Lload;
        // import com.tangosol.dev.assembler.Lmul;
        // import com.tangosol.dev.assembler.Lneg;
        // import com.tangosol.dev.assembler.Lnewarray;
        // import com.tangosol.dev.assembler.LocalVariableTableAttribute;
        // import com.tangosol.dev.assembler.LongConstant;
        // import com.tangosol.dev.assembler.Lookupswitch;
        // import com.tangosol.dev.assembler.Lor;
        // import com.tangosol.dev.assembler.Lrem;
        // import com.tangosol.dev.assembler.Lreturn;
        // import com.tangosol.dev.assembler.Lshl;
        // import com.tangosol.dev.assembler.Lshr;
        // import com.tangosol.dev.assembler.Lstore;
        // import com.tangosol.dev.assembler.Lsub;
        // import com.tangosol.dev.assembler.Lushr;
        // import com.tangosol.dev.assembler.Lvar;
        // import com.tangosol.dev.assembler.Lxor;
        // import com.tangosol.dev.assembler.Method;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.Monitorenter;
        // import com.tangosol.dev.assembler.Monitorexit;
        // import com.tangosol.dev.assembler.Multianewarray;
        // import com.tangosol.dev.assembler.New;
        // import com.tangosol.dev.assembler.Nop;
        // import com.tangosol.dev.assembler.Op;
        // import com.tangosol.dev.assembler.OpArray;
        // import com.tangosol.dev.assembler.OpBranch;
        // import com.tangosol.dev.assembler.OpConst;
        // import com.tangosol.dev.assembler.OpDeclare;
        // import com.tangosol.dev.assembler.OpLoad;
        // import com.tangosol.dev.assembler.OpStore;
        // import com.tangosol.dev.assembler.OpSwitch;
        // import com.tangosol.dev.assembler.OpVariable;
        // import com.tangosol.dev.assembler.Pop;
        // import com.tangosol.dev.assembler.Pop2;
        // import com.tangosol.dev.assembler.Putfield;
        // import com.tangosol.dev.assembler.Putstatic;
        // import com.tangosol.dev.assembler.RefConstant;
        // import com.tangosol.dev.assembler.Ret;
        // import com.tangosol.dev.assembler.Return;
        // import com.tangosol.dev.assembler.Rstore;
        // import com.tangosol.dev.assembler.Rvar;
        // import com.tangosol.dev.assembler.Saload;
        // import com.tangosol.dev.assembler.Sastore;
        // import com.tangosol.dev.assembler.SignatureConstant;
        // import com.tangosol.dev.assembler.Snewarray;
        // import com.tangosol.dev.assembler.SourceFileAttribute;
        // import com.tangosol.dev.assembler.StringConstant;
        // import com.tangosol.dev.assembler.Swap;
        // import com.tangosol.dev.assembler.Switch;
        // import com.tangosol.dev.assembler.SyntheticAttribute;
        // import com.tangosol.dev.assembler.Tableswitch;
        // import com.tangosol.dev.assembler.Try;
        // import com.tangosol.dev.assembler.UtfConstant;
        // import com.tangosol.dev.assembler.VMStructure;
        // import com.tangosol.dev.assembler.Znewarray;
        // import com.tangosol.dev.compiler.Compiler;
        // import com.tangosol.dev.compiler.CompilerException;
        // import com.tangosol.dev.compiler.Context;
        // import com.tangosol.dev.compiler.Locator;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Implementation;
        // import com.tangosol.dev.component.Integration;
        // import com.tangosol.dev.component.Interface;
        // import com.tangosol.dev.component.Parameter;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.ReturnValue;
        
        

        }
    
    /**
    * Add comments to the listing header.
    */
    public void addComments(ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import com.tangosol.util.Base;
        
        gen.println("/*"                                         );  
        gen.println("* Integrates"                               );
        gen.println("*     " + getIntegrateeType().getClassName());
        gen.println("*     using " + getIntegrationModel()       );
        
        String sDescr = getIntegrationMap().getText();
        if (sDescr.length() > 0)
            {
            gen.println("*");
            gen.println("* " + Base.breakLines(sDescr, 80, gen.getIndent() + "* ", false));
            gen.println("*");
            }
        
        gen.println("*/"                                         );
        }
    
    /**
    * Generate a field initializer for a given integrated constant property
    * (could only be a Java Constant)
    * 
    * @param gen the ClassGenerator used to generate the class
    * @param prop  the property
    * @param vL_this  current "this" variable reference
    * @param sField  field name for the integrator
    * @param cR_field  field constant for the integrator
    */
    public void addConstantInitializer(ClassGenerator gen, com.tangosol.dev.component.Property prop, com.tangosol.dev.assembler.Avar vL_this, String sField, com.tangosol.dev.assembler.FieldConstant cR_field)
        {
        DataType       dtBase     = getIntegrateeType();
        String         sBaseFld   = getMappedField(prop.getName());
        CodeAttribute  code       = gen.getCode();
        DataType       dtProp     = prop.getDataType();
        FieldConstant  cR_BaseFld = new FieldConstant(dtBase.getClassConstant(),
            new SignatureConstant(sBaseFld, gen.resolveJVMSignature(dtProp)));
        
        if (prop.getIndexed() == Property.PROP_SINGLE)
            {
            gen.print(sField  + " = ");
        
            if (prop.isStatic())
                {
                if (prop.isNullValue() || dtProp.isExtendedSimple())
                    {
                    // Optimization -- use the known constant value
        
                    Constant constant = gen.getConstant(prop.getValue(), dtProp);
                    Op       opLoad   = gen.getLoadConstOp(constant);
        
                    code.add(opLoad);
        
                    gen.print(gen.formatConstant(constant, dtProp) + "; // ");
                    }
                else
                    {
                    code.add(new Getstatic(cR_BaseFld));
                    }
                code.add(new Putstatic(cR_field));
        
                gen.println(gen.formatType(dtBase) + '.' + sBaseFld + ';');
                }
            else
                {
                /* theoretically we could do the following for non-static constants:
        
                    code.add(new Aload(vL_this));
                    loadFeed(vL_this);
                    code.add(new Getfield(cR_BaseFld));
                    code.add(new Putfield(cR_field));
        
                    gen.print('.' + sBaseFld);
        
                   but for "java source compatibility" reasons we can assign
                   instance constants (final fields) only in the constructor,
                   at which time the we don't have a feed yet!
        
                   Or we could simply ignore the problem:
        
                        gen.println("null; // not supported!");
        
                   For now we won't allow this extremely rare case of
                   instance constants integration.
                */
        
                throw new UnsupportedOperationException(get_Name() + 
                    ".addConstantInitializer: Integration of non-static final properties is not supported " + prop);
                }
            }
        else
            {
            throw new UnsupportedOperationException(get_Name() + 
                ".addConstantInitializer: Integration of indexed properties is not supported " + prop);
            }
        }
    
    /**
    * This method provides the operatunity for an integration to add code to
    * the class file generated for the main component class and the main class
    * file for all derived sub-components.
    */
    public void addEffectiveIntegration(ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        }
    
    /**
    * Add an integration specific fields to the class file.
    */
    public void addFields(ClassGenerator gen)
        {
        }
    
    /**
    * Load a reference to the component's SINK or FEED on the stack.
    * 
    * @param gen  current ClassGenerator
    * @param vL_this  current "this" variable reference
    * @param nPeerId  one of PEER_FEED or PEER_SINK
    * 
    * @return  the name of the appropriate field or an access method that
    * should be used for the Java listing.
    * 
    * @see #generateMethodRouter
    */
    protected String addPeerAccess(ClassGenerator gen, com.tangosol.dev.assembler.Avar vL_this, int nPeerId)
            throws com.tangosol.dev.component.ComponentException
        {
        return null;
        }
    
    /**
    * Add an integration specific portion of the private initializer
    * (__initPrivate) responsible for an integration peer initialization.
    */
    public void addPeerInitializer(ClassGenerator gen, com.tangosol.dev.assembler.Avar vL_this)
            throws com.tangosol.dev.component.ComponentException
        {
        }
    
    /**
    * Generate the classes needed to "expose" this component for the external
    * use.
    * 
    * The package name and the base name to use for all classes is indicated,
    * in addition to an enumeration which specifies the type of class to
    * expose.  The type can indicate to expose either the component's feed, or
    * remote classes.
    * 
    * @param gen   the ClassGenerator used to generate the class
    * @param sPackage the Java package name to expose all classes under
    * @param sName   the base name of all exposed classes within the package
    * @param iType  indicates what classes to generate (EXPOSE_AUTO,
    * EXPOSE_FEED, EXPOSE_REMOTE)
    * @param fStore if true then the generated classes and listing will be
    * stored in the storage
    * 
    * @return a list of ClassGenerator$ClassInfo components for all generated
    * classes.
    */
    public java.util.List generateExposedClasses(ClassGenerator gen, String sPackage, String sName, int iType, boolean fStore)
            throws com.tangosol.dev.component.ComponentException
        {
        return null;
        }
    
    /**
    * Generate a field accessor for an integrated standard property.
    * 
    * @param prop  property to integrate
    * @param bhvr  accessor for the property
    * @param sImplName  implementation name to use instead of bhvr.getName()
    * (synthetic)
    * @param nAccess accessibility of the accessor
    * 
    * @return  generated method
    */
    public com.tangosol.dev.assembler.Method generateFieldAccessors(ClassGenerator gen, com.tangosol.dev.component.Property prop, com.tangosol.dev.component.Behavior bhvr, String sImplName, int nAccess)
            throws com.tangosol.dev.component.ComponentException
        {
        String   sProp  = prop.getName();
        DataType dtProp = prop.getDataType();
        
        if (prop.isFromSuper())
            {
            // Check whether the super was integrated as well
            String sSuperName = prop.getComponent().getSuperName();
            while (sSuperName.length() != 0)
                {
                Component  cdSuper         = gen.getComponent(sSuperName);
                Integrator integratorSuper = gen.findIntegrator(cdSuper);
                if (integratorSuper != null)
                    {
                    if (integratorSuper.getMappedField(sProp) != null)
                        {
                        // Our super also integrates so we defer to it.
                        return null;
                        }
                    // Our super does not integrate this either, break
                    // out of this loop and report the warning
                    break;
                    }
                sSuperName = cdSuper.getSuperName();
                }
            // We have to go up or go over, we'll go over for now.
            // TODO:  Soft code the warning
            String sMsg = "Integrated property " + prop + " has been declared " +
                "at the super level, but the integration here " +
                "makes the \"super\" implementation inaccessible.";
            gen.addWarning(sMsg);
            }
        
        String sPeerField = getMappedField(sProp);
        if (sPeerField == null || sPeerField.length() == 0)
            {
            throw new IllegalStateException(get_Name() +
                ".generateFieldAccessor: " + "Mapping information is missing for " + prop);
            }
        
        // The property we are processing could be:
        //     a) regular integrated field that exist on the integratee
        //     b) routed property that was added on the feed
        
        DataType      dtFieldBase;
        FieldConstant cR_peer;
        if (getRoutedProperties().contains(sPeerField))
            {
            dtFieldBase = getFeedType();
            cR_peer = new FieldConstant(dtFieldBase.getClassConstant(),
                new SignatureConstant(sPeerField, gen.resolveJVMSignature(dtProp)));
            }
        else
            {
            dtFieldBase = getIntegrateeType();
            cR_peer = gen.resolveField(dtFieldBase, dtProp, sPeerField);
            if (cR_peer == null)
                {
                throw new IllegalStateException("Field " + sPeerField +
                    " is missing in " + dtFieldBase.getClassName());
                }
            }
        
        Method method = gen.generateMethodHeader(bhvr,
            sImplName, nAccess, bhvr.isFinal(), false, null);
        
        CodeAttribute code = gen.BeginSegment(method);
                                        
        Avar vL_this;
        if (prop.isStatic())
            {
            vL_this = null;
            }
        else
            {
            vL_this = new Avar("this");
            code.add(vL_this);
            }
        
        OpDeclare[] v_params = gen.addBehaviorParameters(bhvr);
        
        if (prop.isStatic())
            {
            if (bhvr.getReturnValue().getDataType() != DataType.VOID)
                {
                // getter
                code.add(new Getstatic(cR_peer));
                code.add(gen.getReturnOp(dtProp));
        
                gen.println("return " + gen.formatType(dtFieldBase) +
                    '.' + sPeerField + ';');
                }
            else
                {
                // setter
                code.add(v_params[0].getLoadOp());
                code.add(new Putstatic(cR_peer));
                code.add(new Return());
        
                gen.println(gen.formatType(dtFieldBase) +
                    '.' + sPeerField + " = " +  v_params[0].getVariableName() + ';');
                }
            }
        else
            {
            boolean       fMirrored  = isFieldMirrored(prop);
            String        sThisField = null;
            FieldConstant cR_this    = null;
        
            if (fMirrored)
                {
                sThisField = gen.getFieldName(prop);
                cR_this    = gen.getClassFile().getFieldConstant(sThisField);
                _assert(cR_this != null, "Missing field for property " + sProp);
                }
        
            boolean        fRouted   = getRoutedProperties().contains(sProp);
            MethodConstant cM_route  = null;
            OpConst        cO_invoke = null;
            String         sPeer;
        
            if (fRouted)
                {
                String sRouteName = Property.getAccessorPrefix(bhvr.getName()) + sPeerField;
                String sSig       = gen.resolveJVMSignature(bhvr);
        
                cM_route = getRoutingMethod(gen, sRouteName, sSig);
                if (cM_route instanceof InterfaceConstant)
                    {
                    cO_invoke = new Invokeinterface((InterfaceConstant) cM_route);
                    }
                else
                    {
                    cO_invoke = new Invokevirtual(cM_route);
                    }
                sPeer = addPeerAccess(gen, vL_this, PEER_SINK);
                }
            else
                {
                sPeer = addPeerAccess(gen, vL_this, PEER_FEED);
                }
        
            if (bhvr.getReturnValue().getDataType() != DataType.VOID)
                {
                // getter
                gen.print("return ");
        
                if (fMirrored)
                    {
                    code.add(new Dup());
                    Label lbl_peerNonNull = new Label();
                    code.add(new Ifnonnull(lbl_peerNonNull));
                    code.add(new Pop());
                    code.add(new Aload(vL_this));
                    code.add(new Getfield(cR_this));
                    code.add(gen.getReturnOp(dtProp));
                    code.add(lbl_peerNonNull);
        
                    gen.print("(" + sPeer + " == null) ? " + sThisField + " : ");
                    }
        
                // common code for both fMirrored and !fMirrored
        
                gen.print(sPeer + '.');
                if (fRouted)
                    {
                    gen.print(cM_route.getName() + '(');
        
                    gen.addLoadParameters(bhvr, v_params);
                    code.add(cO_invoke);
        
                    gen.print(")");
                    }
                else
                    {
                    code.add(new Getfield(cR_peer));
        
                    gen.print(sPeerField);
                    }
                code.add(gen.getReturnOp(dtProp));
        
                gen.println(";");
                }
            else
                {
                // setter
                if (fMirrored)
                    {
                    code.add(new Dup());
                    Label lbl_peerNonNull = new Label();
                    code.add(new Ifnonnull(lbl_peerNonNull));
        
                    gen.println("if (" + sPeer + " == null)");
        
                    gen.BeginScope();
                        {
                        code.add(new Pop());
                        code.add(new Aload(vL_this));
                        code.add(v_params[0].getLoadOp());
                        code.add(new Putfield(cR_this));
        
                        gen.println(sThisField + " = " + v_params[0].getVariableName() + ';');
        
                        code.add(new Return());
                        }
                    gen.EndScope();
        
                    gen.println("else");
        
                    code.add(lbl_peerNonNull);
                    gen.BeginScope();
                    }
        
                // common code for both fMirrored and !fMirrored
        
                gen.print(sPeer + '.');
                if (fRouted)
                    {
                    gen.print(cM_route.getName() + '(');
        
                    gen.addLoadParameters(bhvr, v_params);
        
                    code.add(cO_invoke);
        
                    gen.print(")");
                    }
                else
                    {
                    code.add(v_params[0].getLoadOp());
                    code.add(new Putfield(cR_peer));
        
                    gen.print(sPeerField + " = " + v_params[0].getVariableName());
                    }
        
                code.add(new Return());
        
                gen.println(";");
        
                if (fMirrored)
                    {
                    gen.EndScope();
                    }
                }
            }
        
        gen.EndSegment(method);
        return method;
        }
    
    /**
    * Generate an integration specific implementation for the specified method.
    * ClassGenerator calls this function for each behavior that is included
    * into the AutoGenBehavior array (see ClassGenerator.compile(), step 14).
    * Default implementation does nothing.
    * 
    * @param bhvr  accessor behavior
    * @param sImplName  implementation name to use instead of bhvr.getName()
    * (synthetic)
    * @param fMainImpl  if true, the method is the "entry point" implementation
    * 
    * @return  generated method
    */
    public com.tangosol.dev.assembler.Method generateImplementation(ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr, String sImplName, boolean fMainImpl)
            throws com.tangosol.dev.component.ComponentException
        {
        return null;
        }
    
    /**
    * Generate an integration specific implementation (routing) for the
    * specified behavior.
    * 
    * @param bhv  behavior that we are re-routing (the target method has
    * identical signature)
    * @param sImplName  implementation name to use instead of bhvr.getName()
    * (synthetic)
    * @param nAccess  access value for the implementation
    * 
    * @return  generated method
    */
    public com.tangosol.dev.assembler.Method generateMethodRouter(ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr, String sImplName, int nAccess)
            throws com.tangosol.dev.component.ComponentException
        {
        if (bhvr.isStatic())
            {
            throw new IllegalArgumentException(get_Name() + ".generateMethodRouterSub: " +
                "Unable to route a static behavior " + bhvr);
            }
        
        String sSignature = bhvr.getSignature();
        String sMeth      = getMappedMethod(sSignature);
        
        if (sMeth == null || sMeth.length() == 0)
            {
            throw new IllegalStateException(get_Name() +
                ".generateMethodRouterSub: " + "Mapping information is missing for " + bhvr);
            }
        
        if (bhvr.isFromSuper())
            {
            // Check whether the super was integrated as well
            String sSuperName = bhvr.getComponent().getSuperName();
            while (sSuperName.length() != 0)
                {
                Component  cdSuper         = gen.getComponent(sSuperName);
                Integrator integratorSuper = gen.findIntegrator(cdSuper);
                if (integratorSuper != null)
                    {
                    if (integratorSuper.getMappedMethod(sSignature) != null)
                        {
                        // Our super also integrates so we defer to it.
                        return null;
                        }
                    // Our super does not integrate this either, break
                    // out of this loop and report the warning
                    break;
                    }
                sSuperName = cdSuper.getSuperName();
                }
            // We have to go up or go over, we'll go over for now.
            // TODO:  Soft code the warning
            String sMsg = "Integrated behavior " + bhvr + " has been declared " +
                "at the super level, but the integration here " +
                "makes the \"super\" implementation inaccessible.";
            gen.addWarning(sMsg);
            }
        
        DataType  dtRet      = bhvr.getReturnValue().getDataType();
        String    sRouteName = sMeth.substring(0, sMeth.indexOf('('));
        String    sSig       = gen.resolveJVMSignature(bhvr);
        ClassFile clzf       = gen.getClassFile();
        Method    method     = gen.generateMethodHeader(bhvr, sImplName, nAccess, bhvr.isFinal(), false, null);
        
        CodeAttribute code   = gen.BeginSegment(method);
        
        Avar vL_this = new Avar("this");
        code.add(vL_this);
        
        OpDeclare[] v_params  = gen.addBehaviorParameters(bhvr);
        
        // It's possible that the interated method throws an exception that
        // was "undeclared" at the integration level.
        // The router should catch it then...
        
        String[] asException = bhvr.getExceptionNames();
        int      cExceptions = asException.length;
        boolean  fNeedTry    = false;
        for (int i = 0; i < cExceptions; i++)
            {
            String sException = asException[i];
            if (bhvr.getException(sException) == null)
                {
                fNeedTry = true;
                }
            else
                {
                asException[i] = null; // remove from the list
                }
            }
        
        Try lbl_try = fNeedTry ? new Try() : null;
        
        if (fNeedTry)
            {
            code.add(lbl_try);
        
            gen.println("try");
        
            gen.BeginScope();
            }
        
        if (dtRet != DataType.VOID)
            {
            gen.print("return ");
            }
        
        gen.print(addPeerAccess(gen, vL_this, PEER_SINK));
        
        MethodConstant cM_route = getRoutingMethod(gen, sRouteName, sSig);
        gen.print('.' + cM_route.getName() + '(');
        
        gen.addLoadParameters(bhvr, v_params);
        
        if (cM_route instanceof InterfaceConstant)
            {
            code.add(new Invokeinterface((InterfaceConstant) cM_route));
            }
        else
            {
            code.add(new Invokevirtual(cM_route));
            }
        
        code.add(gen.getReturnOp(dtRet));
        
        gen.println(");");
        
        if (fNeedTry)
            {
            gen.EndScope();
        
            for (int i = 0; i < cExceptions; i++)
                {
                String sException = asException[i];
                if (sException == null)
                    {
                    continue;
                    }
        
                Label lbl_catch = new Label();
        
                code.add(new Catch(lbl_try,
                            new ClassConstant(sException), lbl_catch));
                gen.println("catch (" + sException + " e)");
        
                code.add(lbl_catch);
                gen.BeginScope();
                    {
                    gen.println("// re-throw as a runtime exception");
        
                    Avar vL_e = new Avar("e");
                    code.add(vL_e);
        
                    code.add(new Astore(vL_e));
                    gen.addThrow("java.lang.RuntimeException", null, vL_e);
                    }
                gen.EndScope();
                }
            }
        
        gen.EndSegment(method);
        return method;

        }
    
    /**
    * Generate the integration specific extra classes.
    */
    public void generatePeer(ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        }
    
    /**
    * Generate an integration specific implementation (routing) for the
    * specified behavior.  This implementation will be placed at the beginning
    * of the implementation chain, as opposed to generateMethodRouter which is
    * placed at the end of the implementation chain.
    * 
    * The current use of this is to facilitate routing the method off to a
    * remote, server based version of the method.
    * 
    * @param gen the ClassGenerator being used to generate the code
    * @param bhv  behavior that we are pre-routing (the target method has
    * identical signature)
    * @param method the ClassFile method to place the pre-routing code into
    * @param methodSuper the ClassFile method used when the super of the
    * current method is called
    */
    public void generateStubRouter(ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr, com.tangosol.dev.assembler.Method method, com.tangosol.dev.assembler.Method methodSuper)
        {
        throw new IllegalStateException(get_Name() + ".generateStubRouter: " +
            "This model does not generate stub routers");
        }
    
    // Accessor for the property "AutoGenBehaviors"
    /**
    * Getter for property AutoGenBehaviors.<p>
    * Specifies the list of signatures for behaviors that will be automatically
    * generated by this integration model to optimize the peer access. This
    * list is used by the ClassGenerator to allow the integrator make some
    * specific implementation by calling <code>generateImpementation</code> for
    * each behavior in this array (see compile(), step 14). This list is also
    * used by 
    * <code>isBehaviorAutogen</code> to answer a question asked by
    * <code>ClassGenerator.isCodeGenerating</code>.
    * 
    * @see AbstractBean#setGenerator
    */
    public java.util.List getAutoGenBehaviors()
        {
        // import java.util.List;
        // import java.util.LinkedList;
        
        List list = __m_AutoGenBehaviors;
        if (list == null)
            {
            list = new LinkedList();
            setAutoGenBehaviors(list);
            }
        return list;
        }
    
    /**
    * Returns a class name that this Integrator generates for the specified
    * component and specified peer type.
    * 
    * @param cd  Component Definition for which a peer is being generated
    * @param nPeerId  type of the peer (one of PEER_FEED, PEER_SINK or another
    * type defined by a sub component)
    * 
    * @return the class name for the specified peer
    */
    public String getAutoGenClass(com.tangosol.dev.component.Component cd, int nPeerId)
        {
        return null;
        }
    
    // Accessor for the property "CD"
    /**
    * Getter for property CD.<p>
    * The Integrator Component.
    */
    public com.tangosol.dev.component.Component getCD()
        {
        return __m_CD;
        }
    
    // Accessor for the property "FeedType"
    /**
    * Getter for property FeedType.<p>
    * Specifies the integration feed type.
    */
    public com.tangosol.dev.component.DataType getFeedType()
        {
        return __m_FeedType;
        }
    
    // Accessor for the property "IntegrateeType"
    /**
    * Getter for property IntegrateeType.<p>
    * The data type for the integrated class.
    */
    public com.tangosol.dev.component.DataType getIntegrateeType()
        {
        return DataType.getClassType(getIntegrationMap().getSignature());

        }
    
    // Accessor for the property "IntegrationMap"
    /**
    * Getter for property IntegrationMap.<p>
    * (Privately used) Integration Map.  All access to the map information is
    * now done via virtual methods against this Integrator class.
    * 
    * This MUST be set before the CD is set.
    */
    private com.tangosol.dev.component.Integration getIntegrationMap()
        {
        return __m_IntegrationMap;
        }
    
    // Accessor for the property "IntegrationMisc"
    /**
    * Getter for property IntegrationMisc.<p>
    */
    public String getIntegrationMisc()
        {
        return getIntegrationMap().getMisc();
        

        }
    
    /**
    * Parse the integration map misc value as a series of properties of the
    * form "name=value" with each value pair separated by commas.
    */
    public String getIntegrationMiscProperty(String sProperty, String sDefault)
        {
        String sMisc   = getIntegrationMisc();
        int    cchMisc = sMisc.length();
        int    ofStart = 0;
        
        while (ofStart < cchMisc)
            {
            int ofEnd = sMisc.indexOf(';', ofStart);
            if (ofEnd == -1)
                {
                ofEnd = cchMisc;
                }
            
            String sPair   = sMisc.substring(ofStart, ofEnd);
            int    ofEqual = sPair.indexOf('=');
            String sName;
            String sValue;
            
            if (ofEqual == -1)
                {
                sName  = sPair;
                sValue = "";
                }
            else
                {
                sName  = sPair.substring(0, ofEqual);
                sValue = sPair.substring(ofEqual + 1);
                }
        
            if (sName.equals(sProperty))
                {
                return sValue;
                }
            ofStart = ofEnd + 1;
            }
        
        return sDefault;

        }
    
    // Accessor for the property "IntegrationModel"
    /**
    * Getter for property IntegrationModel.<p>
    */
    public String getIntegrationModel()
        {
        return getIntegrationMap().getModel();
        

        }
    
    public String getMappedBehavior(String sMethod)
        {
        return getIntegrationMap().getBehavior(sMethod);
        

        }
    
    // Accessor for the property "MappedBehaviors"
    /**
    * Getter for property MappedBehaviors.<p>
    * (Calculated) The enumeration of all the mapped behaviors.
    */
    public java.util.Enumeration getMappedBehaviors()
        {
        return getIntegrationMap().getBehaviors();
        
        

        }
    
    public String getMappedField(String sProperty)
        {
        String sField = getIntegrationMap().getField(sProperty);
        if (sField != null)
            {
            return sField;
            }
        
        if (getRoutedProperties().contains(sProperty))
            {
            return sProperty;
            }
        
        return null;
        

        }
    
    public String getMappedMethod(String sBehavior)
        {
        return getIntegrationMap().getMethod(sBehavior);

        }
    
    // Accessor for the property "MappedProperties"
    /**
    * Getter for property MappedProperties.<p>
    * (Calculated) The enumeration of all the mapped properties.
    */
    public java.util.Enumeration getMappedProperties()
        {
        // import com.tangosol.util.ChainedEnumerator;
        // import com.tangosol.util.IteratorEnumerator;
        
        return new ChainedEnumerator(getIntegrationMap().getProperties(),
                                     new IteratorEnumerator(getRoutedProperties().iterator()));
        

        }
    
    public String getMappedProperty(String sField)
        {
        String sProperty = getIntegrationMap().getProperty(sField);
        if (sProperty != null)
            {
            return sProperty;
            }
        
        if (getRoutedProperties().contains(sField))
            {
            return sField;
            }
        
        return null;

        }
    
    // Accessor for the property "RoutedProperties"
    /**
    * Getter for property RoutedProperties.<p>
    * Used during feed generation to hold the Properties that are routed
    * between the component and the feed, but may not be present in the
    * integration map.
    * 
    * @see #setCDAndMap
    */
    public java.util.Collection getRoutedProperties()
        {
        return __m_RoutedProperties;
        }
    
    // Accessor for the property "RoutedProperties"
    /**
    * Return a list of properties that are routed between the component and the
    * feed.
    * 
    * @see #setCDAndMap
    * @see #RoutedProperties property
    */
    protected java.util.Collection getRoutedProperties(ClassGenerator gen)
        {
        // import com.tangosol.util.LiteSet;
        
        return new LiteSet();
        }
    
    /**
    * Gets the routing method for the specified method 
    * 
    * @param gen  current ClassGenerator
    * @param sMethName  method's name
    * @param sMethSig  method's JVM signature
    * 
    * @see #generateMethodRouter
    */
    protected com.tangosol.dev.assembler.MethodConstant getRoutingMethod(ClassGenerator gen, String sMethName, String sMethSig)
        {
        return null;
        }
    
    // Accessor for the property "SinkType"
    /**
    * Getter for property SinkType.<p>
    * Specifies the integration sink type.
    */
    public com.tangosol.dev.component.DataType getSinkType()
        {
        return __m_SinkType;
        }
    
    /**
    * Specifies whether this model will auto-generate an implementation for
    * this behavior.
    * 
    * @return true if the specified behavior is auto-generated by this model;
    * false otherwise
    */
    public boolean isBehaviorAutoGen(com.tangosol.dev.component.Behavior bhvr)
        {
        // import java.util.Iterator;
        
        String sBhvrSig = bhvr.getSignature();
        for (Iterator iter = getAutoGenBehaviors().iterator(); iter.hasNext();)
            {
            String sSig = (String) iter.next();
            if (sBhvrSig.equals(sSig))
                {
                return true;
                }
            }
        return false;
        }
    
    // Accessor for the property "CustomInits"
    /**
    * Getter for property CustomInits.<p>
    * Specifies whether there is a custom initialization for this component.
    * The sub classes override this.
    * 
    * @see AbstractBean.JavaBean#isCustomInits
    */
    public boolean isCustomInits()
        {
        return false;
        }
    
    /**
    * Specifies whether the back up field is needed to be generated on the
    * integrator component for the specified property that is known to be
    * mapped to an integratee's field.
    * In the integration scenarios when a feed is guaranteed to exist the back
    * up field is not needed. However, for remote integration the feed may not
    * be there (on client-side) and the back up field is needed.
    * 
    * Note: usually the answer will be the same for all the integrated
    * properties. However, the Property parameter is passed to allow more
    * flexibility for integrators.
    * 
    * @param prop  mapped Property
    * 
    * @return true if the field should be created for the integrator component;
    * false otherwise
    */
    public boolean isFieldMirrored(com.tangosol.dev.component.Property prop)
        {
        // We only back up the routed property in the component
        // itself if it is a remote, routed property.  That way,
        // the remote component can run in a local mode.
        
        return isRemote()
               && getRoutedProperties().contains(prop.getName());
        }
    
    // Accessor for the property "Remote"
    /**
    * Those Integrator sub-classes that do remote object will override this to
    * return true.
    */
    public boolean isRemote()
        {
        return __m_Remote;
        }
    
    // Accessor for the property "AutoGenBehaviors"
    /**
    * Setter for property AutoGenBehaviors.<p>
    * Specifies the list of signatures for behaviors that will be automatically
    * generated by this integration model to optimize the peer access. This
    * list is used by the ClassGenerator to allow the integrator make some
    * specific implementation by calling <code>generateImpementation</code> for
    * each behavior in this array (see compile(), step 14). This list is also
    * used by 
    * <code>isBehaviorAutogen</code> to answer a question asked by
    * <code>ClassGenerator.isCodeGenerating</code>.
    * 
    * @see AbstractBean#setGenerator
    */
    private void setAutoGenBehaviors(java.util.List pAutoGenBehaviors)
        {
        __m_AutoGenBehaviors = pAutoGenBehaviors;
        }
    
    // Accessor for the property "CD"
    /**
    * The _Map must be set before the cd is set.
    */
    private void setCD(com.tangosol.dev.component.Component pCD)
        {
        __m_CD = pCD;
        }
    
    public void setCDAndMap(ClassGenerator gen, com.tangosol.dev.component.Component cd, com.tangosol.dev.component.Integration map)
        {
        // import java.util.Collection;
        // import java.util.Iterator;
        
        setCD(cd);
        setIntegrationMap(map);
        
        // In generic case, we don't generate the integratee class, but refer
        // the one specified in the integration map instead
        // assuming that FEED == SINK
        
        DataType dtIntegratee = getIntegrateeType();
        setSinkType(dtIntegratee);
        setFeedType(dtIntegratee);
        
        // trim any non-existant properties and any
        // properties that are both integrated and routed
        
        Collection routedProperties = getRoutedProperties(gen);
        
        for (Iterator itr = routedProperties.iterator();
             itr.hasNext();)
            {
            String sProperty = (String) itr.next();
            if (cd.getProperty(sProperty) == null
                || map.getField(sProperty) != null
                || map.getProperty(sProperty) != null)
                {
                routedProperties.remove(sProperty);
                }
            }
        
        setRoutedProperties(routedProperties);
        }
    
    // Accessor for the property "FeedType"
    /**
    * Setter for property FeedType.<p>
    * Specifies the integration feed type.
    */
    public void setFeedType(com.tangosol.dev.component.DataType pFeedType)
        {
        __m_FeedType = pFeedType;
        }
    
    // Accessor for the property "IntegrationMap"
    /**
    * Setter for property IntegrationMap.<p>
    * (Privately used) Integration Map.  All access to the map information is
    * now done via virtual methods against this Integrator class.
    * 
    * This MUST be set before the CD is set.
    */
    private void setIntegrationMap(com.tangosol.dev.component.Integration pIntegrationMap)
        {
        __m_IntegrationMap = pIntegrationMap;
        }
    
    // Accessor for the property "Remote"
    /**
    * Setter for property Remote.<p>
    * Returns whether or not this integrator is an integrator that facilitates
    * remoting components.
    */
    public void setRemote(boolean pRemote)
        {
        __m_Remote = pRemote;
        }
    
    // Accessor for the property "RoutedProperties"
    /**
    * Setter for property RoutedProperties.<p>
    * Used during feed generation to hold the Properties that are routed
    * between the component and the feed, but may not be present in the
    * integration map.
    * 
    * @see #setCDAndMap
    */
    private void setRoutedProperties(java.util.Collection pRoutedProperties)
        {
        __m_RoutedProperties = pRoutedProperties;
        }
    
    // Accessor for the property "SinkType"
    /**
    * Setter for property SinkType.<p>
    * Specifies the integration sink type.
    */
    public void setSinkType(com.tangosol.dev.component.DataType pSinkType)
        {
        __m_SinkType = pSinkType;
        }
    }
