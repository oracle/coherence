/* Class
*     _package.component.dev.compiler.script.info.Synthetic
*/

package _package.component.dev.compiler.script.info;

public abstract class Synthetic
        extends    _package.component.dev.compiler.script.Info
    {
    // Fields declarations
    
    /**
    * Property Inlineable
    *
    */
    
    /**
    * Property Inlined
    *
    */
    
    /**
    * Property TypeInfo
    *
    */
    
    // Initializing constructor
    public Synthetic(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/info/Synthetic".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "TypeInfo"
    public com.tangosol.dev.compiler.TypeInfo getTypeInfo()
        {
        return null;
        }
    
    // Declared at the super level
    public boolean isAccessible()
        {
        
        // synthetics are accessible (because they are on the class for
        // which we are compiling)
        return true;
        }
    
    // Accessor for the property "Inlineable"
    public boolean isInlineable()
        {
        return false;
        }
    
    // Accessor for the property "Inlined"
    public boolean isInlined()
        {
        return false;
        }
    }
