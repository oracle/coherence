/* Class
*     _package.component.dev.compiler.script.info.synthetic.Index
*/

package _package.component.dev.compiler.script.info.synthetic;

import com.tangosol.dev.component.DataType;

public class Index
        extends    _package.component.dev.compiler.script.info.Synthetic
        implements com.tangosol.dev.compiler.ParamInfo
    {
    // Fields declarations
    
    // Default constructor
    public Index()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Index(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Index();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/info/synthetic/Index".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.dev.compiler.ParamInfo
    // Declared at the super level
    public com.tangosol.dev.component.DataType getDataType()
        {
        // import com.tangosol.dev.component.DataType;
        
        return DataType.INT;
        }
    
    // From interface: com.tangosol.dev.compiler.ParamInfo
    public com.tangosol.dev.compiler.MethodInfo getMethodInfo()
        {
        return (MethodInfo) get_Parent();
        }
    
    // From interface: com.tangosol.dev.compiler.ParamInfo
    // Declared at the super level
    public String getName()
        {
        // pick a name, any name (since it doesn't get scripted)
        return "i";
        }
    
    // From interface: com.tangosol.dev.compiler.ParamInfo
    // Declared at the super level
    public boolean isPublic()
        {
        // all parameters are "public"
        return true;
        }
    }
