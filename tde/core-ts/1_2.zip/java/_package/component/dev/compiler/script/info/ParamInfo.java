/* Class
*     _package.component.dev.compiler.script.info.ParamInfo
*/

package _package.component.dev.compiler.script.info;

public class ParamInfo
        extends    _package.component.dev.compiler.script.Info
        implements com.tangosol.dev.compiler.ParamInfo
    {
    // Fields declarations
    
    /**
    * Property MethodInfo
    *
    */
    
    /**
    * Property Parameter
    *
    */
    private com.tangosol.dev.component.Parameter __m_Parameter;
    
    // Default constructor
    public ParamInfo()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ParamInfo(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ParamInfo();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/info/ParamInfo".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.dev.compiler.ParamInfo
    // Declared at the super level
    public com.tangosol.dev.component.DataType getDataType()
        {
        return getParameter().getDataType();
        }
    
    // From interface: com.tangosol.dev.compiler.ParamInfo
    // Accessor for the property "MethodInfo"
    public com.tangosol.dev.compiler.MethodInfo getMethodInfo()
        {
        return (MethodInfo) get_Parent();
        }
    
    // From interface: com.tangosol.dev.compiler.ParamInfo
    // Declared at the super level
    public String getName()
        {
        return getParameter().getName();
        }
    
    // Accessor for the property "Parameter"
    public com.tangosol.dev.component.Parameter getParameter()
        {
        return __m_Parameter;
        }
    
    // From interface: com.tangosol.dev.compiler.ParamInfo
    // Declared at the super level
    public boolean isPublic()
        {
        // all parameters are "public"
        return true;
        }
    
    // Accessor for the property "Parameter"
    public void setParameter(com.tangosol.dev.component.Parameter pParameter)
        {
        __m_Parameter = pParameter;
        }
    }
