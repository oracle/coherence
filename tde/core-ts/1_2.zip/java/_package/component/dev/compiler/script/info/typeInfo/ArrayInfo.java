/* Class
*     _package.component.dev.compiler.script.info.typeInfo.ArrayInfo
*/

package _package.component.dev.compiler.script.info.typeInfo;

import com.tangosol.dev.compiler.TypeInfo;
import com.tangosol.dev.component.DataType;
import com.tangosol.util.SimpleEnumerator;

public class ArrayInfo
        extends    _package.component.dev.compiler.script.info.TypeInfo
    {
    // Fields declarations
    
    /**
    * Property ArrayType
    *
    */
    private transient com.tangosol.dev.component.DataType __m_ArrayType;
    
    // Default constructor
    public ArrayInfo()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ArrayInfo(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ArrayInfo();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/info/typeInfo/ArrayInfo".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "ArrayType"
    public com.tangosol.dev.component.DataType getArrayType()
        {
        return __m_ArrayType;
        }
    
    // Declared at the super level
    public com.tangosol.dev.component.DataType getDataType()
        {
        return getArrayType();
        }
    
    // Declared at the super level
    public com.tangosol.dev.compiler.MethodInfo getMethodInfo(String sMethod, com.tangosol.dev.component.DataType[] adtParam)
        {
        
        if (sMethod.equals("clone") && adtParam.length == 0)
            {
            // TODO handle clone
            }
        
        return super.getMethodInfo(sMethod, adtParam);
        }
    
    // Declared at the super level
    public String getName()
        {
        // no really good name, so just use the JVM signature
        return getDataType().getJVMSignature();
        }
    
    // Declared at the super level
    public com.tangosol.dev.compiler.PackageInfo getPackageInfo()
        {
        // arrays are packageless (see JLS 10.8)
        return getContext().getPackageInfo("");
        }
    
    // Declared at the super level
    public com.tangosol.dev.compiler.TypeInfo getSuperInfo()
        {
        // import com.tangosol.dev.compiler.TypeInfo;
        // import com.tangosol.dev.component.DataType;
        
        TypeInfo info = getContext().getTypeInfo(DataType.OBJECT);
        _assert(info != null);
        
        return info;
        }
    
    // Declared at the super level
    public java.util.Enumeration interfaceTypes()
        {
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.util.SimpleEnumerator;
        
        return new SimpleEnumerator(new Object[] {DataType.CLONEABLE});
        }
    
    // Declared at the super level
    public boolean isInterface(com.tangosol.dev.component.DataType dt)
        {
        // import com.tangosol.dev.component.DataType;
        
        return dt == DataType.CLONEABLE;
        }
    
    // Accessor for the property "ArrayType"
    public void setArrayType(com.tangosol.dev.component.DataType pArrayType)
        {
        __m_ArrayType = pArrayType;
        }
    }
