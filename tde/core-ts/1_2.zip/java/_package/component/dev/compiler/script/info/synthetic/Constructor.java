/* Class
*     _package.component.dev.compiler.script.info.synthetic.Constructor
*/

package _package.component.dev.compiler.script.info.synthetic;

import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.Constants;
import com.tangosol.dev.assembler.InterfaceConstant;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.assembler.SignatureConstant;
import com.tangosol.dev.compiler.TypeInfo;
import com.tangosol.dev.component.DataType;
import com.tangosol.util.NullImplementation;

public class Constructor
        extends    _package.component.dev.compiler.script.info.Synthetic
        implements com.tangosol.dev.compiler.MethodInfo
    {
    // Fields declarations
    
    /**
    * Property FieldInfo
    *
    */
    
    /**
    * Property MethodConstant
    *
    */
    private transient com.tangosol.dev.assembler.MethodConstant __m_MethodConstant;
    
    /**
    * Property ParamCount
    *
    */
    
    /**
    * Property ParamInfo
    *
    */
    
    // Default constructor
    public Constructor()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Constructor(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Constructor();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/info/synthetic/Constructor".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    public java.util.Enumeration exceptionTypes()
        {
        // import com.tangosol.util.NullImplementation;
        
        return NullImplementation.getEnumeration();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public com.tangosol.dev.assembler.Constant getConstant()
        {
        return getMethodConstant();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public com.tangosol.dev.component.DataType getDataType()
        {
        // import com.tangosol.dev.component.DataType;
        
        return DataType.VOID;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "FieldInfo"
    public com.tangosol.dev.compiler.FieldInfo getFieldInfo()
        {
        return null;
        }
    
    // Accessor for the property "MethodConstant"
    public com.tangosol.dev.assembler.MethodConstant getMethodConstant()
        {
        // import com.tangosol.dev.assembler.Constants;
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.InterfaceConstant;
        // import com.tangosol.dev.assembler.SignatureConstant;
        
        MethodConstant constant = __m_MethodConstant;
        
        if (constant == null)
            {
            ClassConstant     CLAZZ = (ClassConstant) getTypeInfo().getConstant();
            SignatureConstant SIG   = new SignatureConstant(
                    Constants.CONSTRUCTOR_NAME, Constants.INITIALIZER_SIG);
        
            constant = new MethodConstant(CLAZZ, SIG);
            setMethodConstant(constant);
            }
        
        return constant;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public String getName()
        {
        // import com.tangosol.dev.assembler.Constants;
        
        return Constants.CONSTRUCTOR_NAME;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "ParamCount"
    public int getParamCount()
        {
        // components have no-parameter constructors
        return 0;
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Accessor for the property "ParamInfo"
    public com.tangosol.dev.compiler.ParamInfo getParamInfo(int i)
        {
        throw new ArrayIndexOutOfBoundsException();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public com.tangosol.dev.compiler.TypeInfo getTypeInfo()
        {
        // import Component.Dev.Compiler.Script.Info.TypeInfo;
        
        return (TypeInfo) get_Parent();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isAccessible()
        {
        return isPublic();
        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isPrivate()
        {
        return !isPublic();

        }
    
    // From interface: com.tangosol.dev.compiler.MethodInfo
    // Declared at the super level
    public boolean isPublic()
        {
        // import com.tangosol.dev.compiler.TypeInfo;
        
        // components that are abstract or global static do not have public constructors
        TypeInfo info = getTypeInfo();
        
        return !info.isAbstract() &&
               (info.getParentInfo() != null || !info.isStatic());
        }
    
    // Accessor for the property "MethodConstant"
    public void setMethodConstant(com.tangosol.dev.assembler.MethodConstant pMethodConstant)
        {
        __m_MethodConstant = pMethodConstant;
        }
    }
