/* Class
*     _package.component.dev.compiler.integrator.Wrapper
*/

package _package.component.dev.compiler.integrator;

import _package.component.dev.compiler.ClassGenerator;
import com.tangosol.dev.assembler.Aload;
import com.tangosol.dev.assembler.Checkcast;
import com.tangosol.dev.assembler.CodeAttribute;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Property;

/**
* Wrapper integrator doesn't generate the "integratee" class, it just
* re-directs all the "integrated" methods assuming FEED == SINK.
* 
* The main Wrapper's difference from the AbstractBean
* model is that the Wrapper doesn't optimize the mapping call, but does it the
* following way:
* 
*      ((<sinkName>) get<PrincipalProperty>()).route();
* 
* which allows get<PrincipalProperty> deferred sink creation by overriding
* <PrincipalProperty> getter:
* 
*      if (super.get<PrincipalProperty>() == null)
*          {
*          set<PrincipalProperty>(new <integratee>(...));
*          }
*      return super.get<PrincipalProperty>();
*/
public class Wrapper
        extends    _package.component.dev.compiler.Integrator
    {
    // Fields declarations
    
    /**
    * Property PrincipalPropertyName
    *
    * Name of a property that should be wrapped by this model.
    * 
    * The value is taken out of the Misc attribute of the Integration Map
    * ("_Sink" is the default value).
    */
    
    // Default constructor
    public Wrapper()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Wrapper(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setRemote(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Wrapper();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/integrator/Wrapper".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Load a reference to the component's SINK or FEED on the stack.
    * 
    * @param gen  current ClassGenerator
    * @param vL_this  current "this" variable reference
    * @param nPeerId  one of PEER_FEED or PEER_SINK
    * 
    * @return  the name of the appropriate field or an access method that
    * should be used for the Java listing.
    * 
    * @see #generateMethodRouter
    */
    protected String addPeerAccess(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.assembler.Avar vL_this, int nPeerId)
            throws com.tangosol.dev.component.ComponentException
        {
        // import com.tangosol.dev.assembler.Aload;
        // import com.tangosol.dev.assembler.Checkcast;
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Property;
        
        CodeAttribute  code  = gen.getCode();
        String   sPropWrap   = getPrincipalPropertyName();
        Behavior bhvrGetWrap = gen.getKnownAccessor(sPropWrap, Property.PA_GET_SINGLE);
        DataType dtWrap      = bhvrGetWrap.getReturnValue().getDataType();
        DataType dtSink      = getSinkType();
        
        code.add(new Aload(vL_this));
        MethodConstant cM = gen.addMethodCall(bhvrGetWrap);
        
        if (dtWrap == dtSink)
            {
            return cM.getName() + "()";
            }
        else
            {
            code.add(new Checkcast(dtSink.getClassConstant()));
        
            return "((" + gen.formatType(dtSink) + ") " + cM.getName() + "())";
            }
        }
    
    // Accessor for the property "PrincipalPropertyName"
    private String getPrincipalPropertyName()
        {
        // import Component.Dev.Compiler.ClassGenerator;
        
        String sName = getIntegrationMisc();
        if (sName.length() == 0)
            {
            sName = ClassGenerator.PROP_SINK;
            }
        return sName;
        }
    
    // Declared at the super level
    /**
    * Gets the routing method for the specified method 
    * 
    * @param gen  current ClassGenerator
    * @param sMethName  method's name
    * @param sMethSig  method's JVM signature
    * 
    * @see #generateMethodRouter
    */
    protected com.tangosol.dev.assembler.MethodConstant getRoutingMethod(_package.component.dev.compiler.ClassGenerator gen, String sMethName, String sMethSig)
        {
        // import com.tangosol.dev.assembler.MethodConstant;
        
        String         sIntegratee = getIntegrateeType().getClassName();
        MethodConstant cM_route    = gen.findMethod(sIntegratee, sMethName, sMethSig);
        
        if (cM_route == null)
            {
            throw new IllegalStateException(get_Name() + ".addRoutingMethod: " +
                "Cannot find routing method " + sMethName + sMethSig + " in " + sIntegratee);
            }
        
        return cM_route;

        }
    }
