/* Class
*     _package.component.dev.compiler.script.Context
*/

package _package.component.dev.compiler.script;

import _package.component.dev.compiler.script.info.PackageInfo;
import _package.component.dev.compiler.script.info.TypeInfo;
import _package.component.dev.compiler.script.info.synthetic.MethodInfo;
import _package.component.dev.compiler.script.info.typeInfo.ArrayInfo;
import com.tangosol.dev.assembler.Aconst;
import com.tangosol.dev.assembler.Aload;
import com.tangosol.dev.assembler.Areturn;
import com.tangosol.dev.assembler.Astore;
import com.tangosol.dev.assembler.Athrow;
import com.tangosol.dev.assembler.Avar;
import com.tangosol.dev.assembler.Begin;
import com.tangosol.dev.assembler.Catch;
import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.CodeAttribute;
import com.tangosol.dev.assembler.Dup;
import com.tangosol.dev.assembler.End;
import com.tangosol.dev.assembler.Field;
import com.tangosol.dev.assembler.FieldConstant;
import com.tangosol.dev.assembler.Getstatic;
import com.tangosol.dev.assembler.Goto;
import com.tangosol.dev.assembler.Ifnonnull;
import com.tangosol.dev.assembler.Invokespecial;
import com.tangosol.dev.assembler.Invokestatic;
import com.tangosol.dev.assembler.Invokevirtual;
import com.tangosol.dev.assembler.Label;
import com.tangosol.dev.assembler.Method;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.assembler.New;
import com.tangosol.dev.assembler.Pop;
import com.tangosol.dev.assembler.Putstatic;
import com.tangosol.dev.assembler.RefConstant;
import com.tangosol.dev.assembler.SignatureConstant;
import com.tangosol.dev.assembler.Try;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Storage;
import com.tangosol.util.StringTable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Context
        extends    _package.component.dev.compiler.Script
        implements com.tangosol.dev.compiler.Context,
                   com.tangosol.dev.compiler.Manager
    {
    // Fields declarations
    
    /**
    * Property Cache
    *
    */
    private transient java.util.Map __m_Cache;
    
    /**
    * Property Check
    *
    */
    
    /**
    * Property Code
    *
    */
    
    /**
    * Property Debug
    *
    */
    
    /**
    * Property ErrorList
    *
    */
    
    /**
    * Property Imports
    *
    */
    private transient com.tangosol.util.StringTable __m_Imports;
    
    /**
    * Property Method
    *
    */
    private transient com.tangosol.dev.assembler.Method __m_Method;
    
    /**
    * Property MethodInfo
    *
    */
    
    /**
    * Property Script
    *
    */
    private transient com.tangosol.dev.component.Implementation __m_Script;
    
    /**
    * Property Storage
    *
    */
    
    /**
    * Property SuperConstant
    *
    */
    private com.tangosol.dev.assembler.Constant __m_SuperConstant;
    
    /**
    * Property SuperInfo
    *
    */
    private transient com.tangosol.dev.compiler.MethodInfo __m_SuperInfo;
    
    /**
    * Property Target
    *
    */
    private transient Target __m_Target;
    
    // Default constructor
    public Context()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Context(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Context();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/Context".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    public boolean addImport(String sImport, com.tangosol.dev.component.DataType dt)
        {
        // import com.tangosol.util.StringTable;
        
        StringTable tblImports = getImports();
        boolean fExisted = tblImports.contains(sImport);
        tblImports.put(sImport, dt);
        return fExisted;
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    // From interface: com.tangosol.dev.compiler.Manager
    public com.tangosol.dev.assembler.Field addSyntheticField(com.tangosol.dev.component.DataType dt)
        {
        return getTarget().addSyntheticField(dt);
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    // From interface: com.tangosol.dev.compiler.Manager
    public com.tangosol.dev.assembler.Method addSyntheticMethod(com.tangosol.dev.component.DataType[] adt)
        {
        return getTarget().addSyntheticMethod(adt);
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    public Object get(String sName)
        {
        return getCache().get(sName);
        }
    
    // Accessor for the property "Cache"
    public java.util.Map getCache()
        {
        // import java.util.Map;
        // import java.util.HashMap;
        
        Map map = __m_Cache;
        if (map == null)
            {
            map = new HashMap();
            setCache(map);
            }
        
        return map;
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    /**
    * Create a synthetic (or provide a pre-existing) method with the signature:
    *     ()Ljava/lang/Class;
    * ... that returns the class specified by dt.  The method is static and
    * guaranteed accessible from this context.
    * 
    * @param dt  specifies the class that will be returned by the resulting
    * method
    * 
    * @return a method constant for a no-parameter method returning the
    * specified java.lang.Class instance
    */
    public com.tangosol.dev.assembler.MethodConstant getClassForName(com.tangosol.dev.component.DataType dt)
        {
        // import com.tangosol.dev.assembler.Field;
        // import com.tangosol.dev.assembler.Method;
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.assembler.SignatureConstant;
        // import com.tangosol.dev.assembler.FieldConstant;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.Begin;
        // import com.tangosol.dev.assembler.End;
        // import com.tangosol.dev.assembler.Try;
        // import com.tangosol.dev.assembler.Catch;
        // import com.tangosol.dev.assembler.Ifnonnull;
        // import com.tangosol.dev.assembler.Goto;
        // import com.tangosol.dev.assembler.Label;
        // import com.tangosol.dev.assembler.New;
        // import com.tangosol.dev.assembler.Dup;
        // import com.tangosol.dev.assembler.Pop;
        // import com.tangosol.dev.assembler.Aconst;
        // import com.tangosol.dev.assembler.Avar;
        // import com.tangosol.dev.assembler.Aload;
        // import com.tangosol.dev.assembler.Astore;
        // import com.tangosol.dev.assembler.Areturn;
        // import com.tangosol.dev.assembler.Athrow;
        // import com.tangosol.dev.assembler.Getstatic;
        // import com.tangosol.dev.assembler.Putstatic;
        // import com.tangosol.dev.assembler.Invokestatic;
        // import com.tangosol.dev.assembler.Invokevirtual;
        // import com.tangosol.dev.assembler.Invokespecial;
        // import com.tangosol.dev.component.DataType;
        // import java.util.Map;
        
        // check the cache of such methods
        Map mapMethods = getTarget().getClassLookupMethods();
        MethodConstant constant = (MethodConstant) mapMethods.get(dt);
        if (constant != null)
            {
            return constant;
            }
        
        final DataType dtString    = DataType.STRING;
        final DataType dtClass     = DataType.getClassType(Class.class);
        final DataType dtThrowable = DataType.getClassType(Throwable.class);
        final DataType dtNotFound  = DataType.getClassType(ClassNotFoundException.class);
        final DataType dtNoClass   = DataType.getClassType(NoClassDefFoundError.class);
        
        final DataType[] NO_PARAMS = new DataType[0];
        final DataType[] STR_PARAM = new DataType[] {DataType.STRING};
        
        if (dt.isComponent() && dt.getComponentName().indexOf('$') < 0)
            {
            // global components have a method already that does the work
            constant = (MethodConstant) getTypeInfo(dt).getMethodInfo(
                "get_CLASS", NO_PARAMS).getConstant();
            }
        else
            {
            _assert(!dt.isPrimitive());
        
            // create a synthetic method to get the class
            // signature "()Ljava/lang/Class;"
            Method method = addSyntheticMethod(new DataType[] {dtClass});
            method.setStatic(true);
            method.setPrivate();
        
            // get the field which will cache the class reference
            Field field = addSyntheticField(dtClass);
            field.setStatic(true);
            field.setPrivate();
        
            // get the method constant for the synthetic method
            ClassConstant CLZ = (ClassConstant) getMethodInfo().getTypeInfo().getConstant();
            String sSig = dtClass.getJVMSignature();
            SignatureConstant SIG = new SignatureConstant(method.getName(), "()" + sSig);
            constant = new MethodConstant(CLZ, SIG);
        
            // get the field constant for the synthetic field
            FieldConstant CLASS$ = new FieldConstant(CLZ,
                    new SignatureConstant(field.getName(), sSig));
        
        
            // ----- begin code production -----
        
            CodeAttribute code = method.getCode();
        
            // {
            code.add(new Begin());
        
            // if (CLASS$ == null)
            code.add(new Getstatic(CLASS$));
            code.add(new Dup());
            Label lblReturn = new Label();
            code.add(new Ifnonnull(lblReturn));
            code.add(new Pop());
        
            // try {
            Try opTry = (Try) code.add(new Try());
        
            // CLASS$ = Class.forName("<dt>");
            String sType = dt.isArray() ? dt.getJVMSignature().replace('/', '.')
                                        : dt.getClassName();
            code.add(new Aconst(sType));
            code.add(new Invokestatic((MethodConstant) getTypeInfo(dtClass).getMethodInfo(
                    "forName", STR_PARAM).getConstant()));
            code.add(new Dup());
            code.add(new Putstatic(CLASS$));
            code.add(new Goto(lblReturn));
        
            // } catch (java.lang.ClassNotFoundException e) {
            Label lblHandler = new Label();
            code.add(new Catch(opTry, (ClassConstant) getTypeInfo(dtNotFound).getConstant(), lblHandler));
            code.add(lblHandler);
            code.add(new Begin());
            Avar e = (Avar) code.add(new Avar("e", dtNotFound.getJVMSignature()));
            code.add(new Astore(e));
        
            // throw new NoClassDefFoundError(e.getMessage());
            code.add(new New((ClassConstant) getTypeInfo(dtNoClass).getConstant()));
            code.add(new Dup());
            code.add(new Aload(e));
            code.add(new Invokevirtual((MethodConstant) getTypeInfo(dtThrowable)
                    .getMethodInfo("getMessage", NO_PARAMS).getConstant()));
            code.add(new Invokespecial((MethodConstant) getTypeInfo(dtNoClass)
                    .getMethodInfo("<init>", new DataType[] {dtString}).getConstant()));
            code.add(new Athrow());
        
            // }
            code.add(new End());
        
            // return CLASS$
            code.add(lblReturn);
            code.add(new Areturn());
        
            // }
            code.add(new End());
        
            // ----- end code production -----
            }
        
        // add the method to the cache
        _assert(constant != null);
        synchronized(mapMethods)
            {
            mapMethods.put(dt, constant);
            }
        
        return constant;
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    // Accessor for the property "Code"
    public com.tangosol.dev.assembler.CodeAttribute getCode()
        {
        return getMethod().getCode();
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    // Accessor for the property "ErrorList"
    public com.tangosol.util.ErrorList getErrorList()
        {
        return getTarget().getErrorList();
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    public com.tangosol.dev.component.DataType getImport(String sImport)
        {
        // import com.tangosol.dev.component.DataType;
        
        return (DataType) getImports().get(sImport);
        }
    
    // Accessor for the property "Imports"
    public com.tangosol.util.StringTable getImports()
        {
        // import com.tangosol.util.StringTable;
        
        StringTable tblImports = __m_Imports;
        
        if (tblImports == null)
            {
            tblImports = new StringTable();
            setImports(tblImports);
            }
        
        return tblImports;
        }
    
    // Accessor for the property "Method"
    public com.tangosol.dev.assembler.Method getMethod()
        {
        return __m_Method;
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    // Accessor for the property "MethodInfo"
    public com.tangosol.dev.compiler.MethodInfo getMethodInfo()
        {
        // import Component.Dev.Compiler.Script.Info.TypeInfo;
        // import com.tangosol.dev.component.Behavior;
        
        TypeInfo type = getTypeInfo(getTarget().getCD());
        Behavior beh  = getScript().getBehavior();
        
        return type.getMethodInfo(beh);
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    public String getOption(String sOption, String sDefault)
        {
        return getTarget().getOptions().getProperty(sOption, sDefault);
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    public com.tangosol.dev.compiler.PackageInfo getPackageInfo(String sPkg)
        {
        // import Component.Dev.Compiler.Script.Info.PackageInfo;
        // import com.tangosol.dev.component.Storage;
        // import com.tangosol.dev.component.Component;
        // import java.util.Set;
        
        final String CDROOT = Component.getRootName();
        
        // check if package info is in cache
        if (sPkg == null)
            {
            sPkg = "";
            }
        final String sLocalID = "P_" + sPkg;
        PackageInfo info = (PackageInfo) _findChild(sLocalID);
        if (info != null)
            {
            return info;
            }
        
        // verify package name
        if (sPkg.length() > 0)
            {
            // check if package is known not to exist
            Set setNonPackages = getTarget().getNonPackages();
            if (setNonPackages.contains(sPkg))
                {
                return null;
                }
        
            Storage storage = getStorage();
            boolean fExists = false;
        
            // optimization -- check for the target's own package first
            Component cdTarget = getTarget().getCD();
            String    sTargetPkg;
            if (cdTarget.isComponent())
                {
                sTargetPkg = cdTarget.getGlobalParent().getSuperName();
                }
            else
                {
                String sName = cdTarget.getName();
                int    ofDot = sName.lastIndexOf('.');
                sTargetPkg = ofDot < 0 ? "" : sName.substring(0, ofDot);
                }
        
            if (sPkg.equals(sTargetPkg))
                {
                fExists = true;
                }
            else if (sPkg.equals(CDROOT) || sPkg.startsWith(CDROOT + '.'))
                {
                // component package iff there are subcomponents
                fExists = !storage.getSubComponents(sPkg, false).isEmpty();
                }
            else
                {
                // class package iff there are any classes or sub-packages
                fExists = !storage.getPackageSignatures(sPkg, false).isEmpty()
                       || !storage.getSignaturePackages(sPkg, false, false).isEmpty();
                }
        
            // if the packages does NOT exist, cache that information
            if (!fExists)
                {
                setNonPackages.add(sPkg);
                return null;
                }
            }
        
        // create new package info
        info = new PackageInfo();
        info.setContext(this);
        info.setPackageName(sPkg);
        
        // add the child to the cache
        _addChild(info, sLocalID);
        
        return info;
        }
    
    // Accessor for the property "Script"
    public com.tangosol.dev.component.Implementation getScript()
        {
        return __m_Script;
        }
    
    // Accessor for the property "Storage"
    public com.tangosol.dev.component.Storage getStorage()
        {
        return getTarget().getStorage();
        }
    
    // Accessor for the property "SuperConstant"
    public com.tangosol.dev.assembler.Constant getSuperConstant()
        {
        return __m_SuperConstant;
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    // Accessor for the property "SuperInfo"
    /**
    * Provide a "fake" MethodInfo instance that exists only to provide
    * information about the "super" of the script for which this context
    * exists.  In other words, what does "super.foo()" mean for the "foo()"
    * script?  It could be an error (non-accessor method at its declaration
    * level), it could be a method on a super class (as in Java), it could be a
    * synthetic method on this class (foo$1), or in the case of a property
    * accessor, it could be a field.
    * 
    * The methods that are most important on the simulated MethodInfo are:
    * 
    *     - addDependency - if this script calls its super, then the compiler
    * MUST call addDependency(true); if the script optimizes out its super,
    * then the compiler MUST call addDependency(false); if the script makes no
    * reference to its super and the compiler does not need the super
    * information to determine whether or not the super is going to be used,
    * then the compiler must NOT call addDependency
    *     - getConstant - if the super call actually goes to a method, this is
    * the method constant, otherwise null; if the method info is for this type
    * or a super class of this type, then a non-virtual call is made, otherwise
    * a virtual call is made
    *     - isInlineable - true if isInlined is true; the class generator may
    * also determine that the super is optimizable out (the script compiler's
    * choice)
    *     - isInlined - true if the super method must be inlined by directly
    * accessing a field (or inlined completely by using a constant)
    *     - getFieldInfo - if isInlineable, returns a simulated FieldInfo which
    * provides the inlining information
    * 
    * @return a MethodInfo representing the super method for the current
    * context or null if there is no super
    */
    public com.tangosol.dev.compiler.MethodInfo getSuperInfo()
        {
        // import com.tangosol.dev.assembler.RefConstant;
        // import com.tangosol.dev.assembler.FieldConstant;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.component.DataType;
        // import Component.Dev.Compiler.Script.Info.Synthetic.MethodInfo;
        
        // check if the super information was already determined
        com.tangosol.dev.compiler.MethodInfo info = __m_SuperInfo;
        if (info != null)
            {
            return info;
            }
        
        RefConstant constant = (RefConstant) getSuperConstant();
        
        // 1999.11.17  cp   All scripts have supers; if no "real" super exists, the
        // synthetic MethodInfo will inline to a synthetic FieldInfo which will inline
        // to a constant or (for void) no value
        
        /*
        // this script may not have a super
        if (constant == null)
             {
             return null;
             }
        */
        
        if (constant instanceof MethodConstant)
            {
            // disect the method constant; it could a Java super call, i.e. a
            // call to this behavior (method) on a super component (class) in
            // which case we can provide a "real" MethodInfo
            DataType dtThis = getMethodInfo().getTypeInfo().getDataType();
            if (!getTarget().resolveClass(dtThis).equals(constant.getClassConstant()))
                {
                // the method constant is from another class or component, so
                // provide a "real" method info; reverse engineer the constant
                // into a class type, method name, and method param types
                DataType   dtClass   = DataType.getJVMType('L' + constant.getClassName() + ';');
                String     sMethod   = constant.getName();
                DataType[] adtAll    = DataType.parseSignature(constant.getType());
                int        cParams   = adtAll.length - 1;
                DataType[] adtParams = new DataType[cParams];
                if (cParams > 0)
                    {
                    System.arraycopy(adtAll, 1, adtParams, 0, cParams);
                    }
        
                // look up that method information
                info = getTypeInfo(dtClass).getMethodInfo(sMethod, adtParams);
                }
            }
        
        if (info == null)
            {
            // not a real super method; generate information to expose the synthetic
            info = new MethodInfo();
            ((MethodInfo) info).setContext(this);
            }
        
        // cache the super info
        setSuperInfo(info);
        
        return info;
        }
    
    // Accessor for the property "Target"
    public Target getTarget()
        {
        return __m_Target;
        }
    
    public _package.component.dev.compiler.script.info.TypeInfo getTypeInfo(com.tangosol.dev.component.Component cd)
        {
        // import Component.Dev.Compiler.Script.Info.TypeInfo;
        // import com.tangosol.dev.component.Component;
        
        Component cdParent = cd.getParent();
        if (cdParent == null)
            {
            return (TypeInfo) getTypeInfo(cd.getQualifiedName());
            }
        else
            {
            return (TypeInfo) getTypeInfo(cdParent.getQualifiedName())
                .getChildInfo(cd.getName());
            }
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    public com.tangosol.dev.compiler.TypeInfo getTypeInfo(com.tangosol.dev.component.DataType dt)
        {
        // import Component.Dev.Compiler.Script.Info.TypeInfo.ArrayInfo;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Storage;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        
        if (dt.isArray())
            {
            // what is needed is a TypeInfo that answers all questions as if
            // it were the TypeInfo for java.lang.Object except that it answers
            // the getDataType() and getClassConstant() questions based on the
            // array type and its clone() method is public and throws no checked
            // exceptions and it implements java.lang.Cloneable.
            // note:  length "field" of an array is actually the Arraylength op
        
            // check if the array info is already cached
            String sType = dt.getTypeString();
            final String sLocalID = "C_" + sType.replace('$', '.');
            ArrayInfo info = (ArrayInfo) _findChild(sLocalID);
            if (info != null)
                {
                return info;
                }
        
            // load java.lang.Object
            Storage   storage = getStorage();
            Component cd      = null;
            try
                {
                cd = storage.loadSignature(DataType.OBJECT.getClassName());
                }
            catch (ComponentException e)
                {
                }
            _assert(cd != null, "Failed to load \"java.lang.Object\"");
        
            // create the array info
            info = new ArrayInfo();
            info.setContext(this);
            info.setCD(cd);
            info.setArrayType(dt);
        
            // add the child to the cache
            _addChild(info, sLocalID);
        
            return info;
            }
        
        if (dt.isClass())
            {
            return getTypeInfo(dt.getClassName());
            }
        
        if (dt.isComponent())
            {
            return getTypeInfo(dt.getComponentName());
            }
        
        return null;
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    public com.tangosol.dev.compiler.TypeInfo getTypeInfo(String sType)
        {
        // import Component.Dev.Compiler.Script.Info.TypeInfo;
        // import com.tangosol.dev.component.Storage;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import java.util.Set;
        
        final String  CDROOT     = Component.getRootName();
        final boolean fComponent = sType.equals(CDROOT) || sType.startsWith(CDROOT + '.');
        
        // check if type refers to a child component
        if (fComponent)
            {
            int    ofDot = sType.lastIndexOf('.');
            String sName = (ofDot < 0 ? sType : sType.substring(ofDot + 1));
        
            int ofChild = sName.indexOf('$') + 1;
            if (ofChild > 0)
                {
                // the requested type is not a global cd;
                // load the global cd and walk its hierarchy
                // to get the requested child
                TypeInfo info = (TypeInfo) getTypeInfo(sType.substring(0, ofDot + ofChild));
                if (info != null)
                    {
                    do
                        {
                        int ofNext = sName.indexOf('$', ofChild);
                        String sChild = (ofNext >= 0 ? sName.substring(ofChild, ofNext)
                                                     : sName.substring(ofChild));
                        info = (TypeInfo) info.getChildInfo(sChild);
                        ofChild = ofNext + 1;
                        }
                    while (info != null && ofChild > 0);
                    }
                return info;
                }
            }
        
        // check if type info is in cache
        final String sLocalID = "C_" + sType.replace('$', '.');
        TypeInfo info = (TypeInfo) _findChild(sLocalID, false);
        if (info != null)
            {
            return info;
            }
        
        // check if package is known not to exist
        Set setNonTypes = getTarget().getNonTypes();
        if (setNonTypes.contains(sType))
            {
            return null;
            }
        
        Component cd = null;
        
        if (sType.equals(getTarget().getCD().getQualifiedName()))
            {
            cd = getTarget().getCD();
            }
        else
            {
            try
                {
                cd = getStorage().loadComponent(sType, true, null);
                }
            catch (ComponentException e)
                {
                getErrorList().addException(e);
                }
            }
        
        // if the type does NOT exist, cache that information
        if (cd == null)
            {
            setNonTypes.add(sType);
            return null;
            }
        
        // create new type info
        info = new TypeInfo();
        info.setContext(this);
        info.setCD(cd);
        
        // add the child to the cache
        _addChild(info, sLocalID);
        
        return info;
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    public java.util.Enumeration importNames()
        {
        return getImports().keys();
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    public com.tangosol.dev.assembler.FieldConstant inlineMethod(com.tangosol.dev.component.DataType dtClass, com.tangosol.dev.component.DataType dtReturn, String sName, com.tangosol.dev.component.DataType[] adtParam)
        {
        return getTarget().inlineMethod(dtClass, dtReturn, sName, adtParam);
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    // Accessor for the property "Check"
    public boolean isCheck()
        {
        return getTarget().isCheck();
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    // Accessor for the property "Debug"
    public boolean isDebug()
        {
        return getTarget().isDebug();
        }
    
    // From interface: com.tangosol.dev.compiler.Context
    public void put(String sName, Object oItem)
        {
        getCache().put(sName, oItem);
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    public com.tangosol.dev.assembler.ClassConstant resolveClass(com.tangosol.dev.component.DataType dtClass)
        {
        return getTarget().resolveClass(dtClass);
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    public com.tangosol.dev.assembler.FieldConstant resolveField(com.tangosol.dev.component.DataType dtClass, com.tangosol.dev.component.DataType dtField, String sName)
        {
        return getTarget().resolveField(dtClass, dtField, sName);
        }
    
    // From interface: com.tangosol.dev.compiler.Manager
    public com.tangosol.dev.assembler.MethodConstant resolveMethod(com.tangosol.dev.component.DataType dtClass, com.tangosol.dev.component.DataType dtReturn, String sName, com.tangosol.dev.component.DataType[] adtParam)
        {
        return getTarget().resolveMethod(dtClass, dtReturn, sName, adtParam);
        }
    
    // Accessor for the property "Cache"
    public void setCache(java.util.Map pCache)
        {
        __m_Cache = pCache;
        }
    
    // Accessor for the property "Imports"
    public void setImports(com.tangosol.util.StringTable pImports)
        {
        __m_Imports = pImports;
        }
    
    // Accessor for the property "Method"
    public void setMethod(com.tangosol.dev.assembler.Method pMethod)
        {
        __m_Method = pMethod;
        }
    
    // Accessor for the property "Script"
    public void setScript(com.tangosol.dev.component.Implementation pScript)
        {
        __m_Script = pScript;
        }
    
    // Accessor for the property "SuperConstant"
    public void setSuperConstant(com.tangosol.dev.assembler.Constant pSuperConstant)
        {
        __m_SuperConstant = pSuperConstant;
        }
    
    // Accessor for the property "SuperInfo"
    public void setSuperInfo(com.tangosol.dev.compiler.MethodInfo pSuperInfo)
        {
        __m_SuperInfo = pSuperInfo;
        }
    
    // Accessor for the property "Target"
    public void setTarget(Target pTarget)
        {
        __m_Target = pTarget;
        }
    }
