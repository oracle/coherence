/* Class
*     _package.component.dev.compiler.remoter.EJB
*/

package _package.component.dev.compiler.remoter;

import _package.component.dev.Storage;
import _package.component.dev.compiler.ClassGenerator;
import _package.component.dev.compiler.Integrator;
import _package.component.dev.compiler.integrator.AbstractBean;
import com.tangosol.dev.assembler.Aaload;
import com.tangosol.dev.assembler.Aastore;
import com.tangosol.dev.assembler.AccessFlags;
import com.tangosol.dev.assembler.Aconst;
import com.tangosol.dev.assembler.Aload;
import com.tangosol.dev.assembler.Anewarray;
import com.tangosol.dev.assembler.Areturn;
import com.tangosol.dev.assembler.Arraylength;
import com.tangosol.dev.assembler.Astore;
import com.tangosol.dev.assembler.Athrow;
import com.tangosol.dev.assembler.Attribute;
import com.tangosol.dev.assembler.Avar;
import com.tangosol.dev.assembler.Baload;
import com.tangosol.dev.assembler.Bastore;
import com.tangosol.dev.assembler.Begin;
import com.tangosol.dev.assembler.Bnewarray;
import com.tangosol.dev.assembler.Caload;
import com.tangosol.dev.assembler.Case;
import com.tangosol.dev.assembler.Castore;
import com.tangosol.dev.assembler.Catch;
import com.tangosol.dev.assembler.Checkcast;
import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.ClassFile;
import com.tangosol.dev.assembler.Cnewarray;
import com.tangosol.dev.assembler.CodeAttribute;
import com.tangosol.dev.assembler.Constant;
import com.tangosol.dev.assembler.ConstantPool;
import com.tangosol.dev.assembler.ConstantValueAttribute;
import com.tangosol.dev.assembler.Constants;
import com.tangosol.dev.assembler.D2f;
import com.tangosol.dev.assembler.D2i;
import com.tangosol.dev.assembler.D2l;
import com.tangosol.dev.assembler.Dadd;
import com.tangosol.dev.assembler.Daload;
import com.tangosol.dev.assembler.Dastore;
import com.tangosol.dev.assembler.Dcmpg;
import com.tangosol.dev.assembler.Dcmpl;
import com.tangosol.dev.assembler.Dconst;
import com.tangosol.dev.assembler.Ddiv;
import com.tangosol.dev.assembler.DeprecatedAttribute;
import com.tangosol.dev.assembler.Dload;
import com.tangosol.dev.assembler.Dmul;
import com.tangosol.dev.assembler.Dneg;
import com.tangosol.dev.assembler.Dnewarray;
import com.tangosol.dev.assembler.DoubleConstant;
import com.tangosol.dev.assembler.Drem;
import com.tangosol.dev.assembler.Dreturn;
import com.tangosol.dev.assembler.Dstore;
import com.tangosol.dev.assembler.Dsub;
import com.tangosol.dev.assembler.Dup2;
import com.tangosol.dev.assembler.Dup2_x1;
import com.tangosol.dev.assembler.Dup2_x2;
import com.tangosol.dev.assembler.Dup;
import com.tangosol.dev.assembler.Dup_x1;
import com.tangosol.dev.assembler.Dup_x2;
import com.tangosol.dev.assembler.Dvar;
import com.tangosol.dev.assembler.End;
import com.tangosol.dev.assembler.ExceptionsAttribute;
import com.tangosol.dev.assembler.F2d;
import com.tangosol.dev.assembler.F2i;
import com.tangosol.dev.assembler.F2l;
import com.tangosol.dev.assembler.Fadd;
import com.tangosol.dev.assembler.Faload;
import com.tangosol.dev.assembler.Fastore;
import com.tangosol.dev.assembler.Fcmpg;
import com.tangosol.dev.assembler.Fcmpl;
import com.tangosol.dev.assembler.Fconst;
import com.tangosol.dev.assembler.Fdiv;
import com.tangosol.dev.assembler.Field;
import com.tangosol.dev.assembler.FieldConstant;
import com.tangosol.dev.assembler.Fload;
import com.tangosol.dev.assembler.FloatConstant;
import com.tangosol.dev.assembler.Fmul;
import com.tangosol.dev.assembler.Fneg;
import com.tangosol.dev.assembler.Fnewarray;
import com.tangosol.dev.assembler.Frem;
import com.tangosol.dev.assembler.Freturn;
import com.tangosol.dev.assembler.Fstore;
import com.tangosol.dev.assembler.Fsub;
import com.tangosol.dev.assembler.Fvar;
import com.tangosol.dev.assembler.Getfield;
import com.tangosol.dev.assembler.Getstatic;
import com.tangosol.dev.assembler.Goto;
import com.tangosol.dev.assembler.GuardedSection;
import com.tangosol.dev.assembler.I2b;
import com.tangosol.dev.assembler.I2c;
import com.tangosol.dev.assembler.I2d;
import com.tangosol.dev.assembler.I2f;
import com.tangosol.dev.assembler.I2l;
import com.tangosol.dev.assembler.I2s;
import com.tangosol.dev.assembler.Iadd;
import com.tangosol.dev.assembler.Iaload;
import com.tangosol.dev.assembler.Iand;
import com.tangosol.dev.assembler.Iastore;
import com.tangosol.dev.assembler.Iconst;
import com.tangosol.dev.assembler.Idiv;
import com.tangosol.dev.assembler.If_acmpeq;
import com.tangosol.dev.assembler.If_acmpne;
import com.tangosol.dev.assembler.If_icmpeq;
import com.tangosol.dev.assembler.If_icmpge;
import com.tangosol.dev.assembler.If_icmpgt;
import com.tangosol.dev.assembler.If_icmple;
import com.tangosol.dev.assembler.If_icmplt;
import com.tangosol.dev.assembler.If_icmpne;
import com.tangosol.dev.assembler.Ifeq;
import com.tangosol.dev.assembler.Ifge;
import com.tangosol.dev.assembler.Ifgt;
import com.tangosol.dev.assembler.Ifle;
import com.tangosol.dev.assembler.Iflt;
import com.tangosol.dev.assembler.Ifne;
import com.tangosol.dev.assembler.Ifnonnull;
import com.tangosol.dev.assembler.Ifnull;
import com.tangosol.dev.assembler.Iinc;
import com.tangosol.dev.assembler.Iload;
import com.tangosol.dev.assembler.Imul;
import com.tangosol.dev.assembler.Ineg;
import com.tangosol.dev.assembler.Inewarray;
import com.tangosol.dev.assembler.InnerClass;
import com.tangosol.dev.assembler.InnerClassesAttribute;
import com.tangosol.dev.assembler.Instanceof;
import com.tangosol.dev.assembler.IntConstant;
import com.tangosol.dev.assembler.InterfaceConstant;
import com.tangosol.dev.assembler.Invokeinterface;
import com.tangosol.dev.assembler.Invokespecial;
import com.tangosol.dev.assembler.Invokestatic;
import com.tangosol.dev.assembler.Invokevirtual;
import com.tangosol.dev.assembler.Ior;
import com.tangosol.dev.assembler.Irem;
import com.tangosol.dev.assembler.Ireturn;
import com.tangosol.dev.assembler.Ishl;
import com.tangosol.dev.assembler.Ishr;
import com.tangosol.dev.assembler.Istore;
import com.tangosol.dev.assembler.Isub;
import com.tangosol.dev.assembler.Iushr;
import com.tangosol.dev.assembler.Ivar;
import com.tangosol.dev.assembler.Ixor;
import com.tangosol.dev.assembler.Jsr;
import com.tangosol.dev.assembler.L2d;
import com.tangosol.dev.assembler.L2f;
import com.tangosol.dev.assembler.L2i;
import com.tangosol.dev.assembler.Label;
import com.tangosol.dev.assembler.Ladd;
import com.tangosol.dev.assembler.Laload;
import com.tangosol.dev.assembler.Land;
import com.tangosol.dev.assembler.Lastore;
import com.tangosol.dev.assembler.Lcmp;
import com.tangosol.dev.assembler.Lconst;
import com.tangosol.dev.assembler.Ldiv;
import com.tangosol.dev.assembler.LineNumberTableAttribute;
import com.tangosol.dev.assembler.Lload;
import com.tangosol.dev.assembler.Lmul;
import com.tangosol.dev.assembler.Lneg;
import com.tangosol.dev.assembler.Lnewarray;
import com.tangosol.dev.assembler.LocalVariableTableAttribute;
import com.tangosol.dev.assembler.LongConstant;
import com.tangosol.dev.assembler.Lookupswitch;
import com.tangosol.dev.assembler.Lor;
import com.tangosol.dev.assembler.Lrem;
import com.tangosol.dev.assembler.Lreturn;
import com.tangosol.dev.assembler.Lshl;
import com.tangosol.dev.assembler.Lshr;
import com.tangosol.dev.assembler.Lstore;
import com.tangosol.dev.assembler.Lsub;
import com.tangosol.dev.assembler.Lushr;
import com.tangosol.dev.assembler.Lvar;
import com.tangosol.dev.assembler.Lxor;
import com.tangosol.dev.assembler.Method;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.assembler.Monitorenter;
import com.tangosol.dev.assembler.Monitorexit;
import com.tangosol.dev.assembler.Multianewarray;
import com.tangosol.dev.assembler.New;
import com.tangosol.dev.assembler.Nop;
import com.tangosol.dev.assembler.Op;
import com.tangosol.dev.assembler.OpArray;
import com.tangosol.dev.assembler.OpBranch;
import com.tangosol.dev.assembler.OpConst;
import com.tangosol.dev.assembler.OpDeclare;
import com.tangosol.dev.assembler.OpLoad;
import com.tangosol.dev.assembler.OpStore;
import com.tangosol.dev.assembler.OpSwitch;
import com.tangosol.dev.assembler.OpVariable;
import com.tangosol.dev.assembler.Pop2;
import com.tangosol.dev.assembler.Pop;
import com.tangosol.dev.assembler.Putfield;
import com.tangosol.dev.assembler.Putstatic;
import com.tangosol.dev.assembler.RefConstant;
import com.tangosol.dev.assembler.Ret;
import com.tangosol.dev.assembler.Return;
import com.tangosol.dev.assembler.Rstore;
import com.tangosol.dev.assembler.Rvar;
import com.tangosol.dev.assembler.Saload;
import com.tangosol.dev.assembler.Sastore;
import com.tangosol.dev.assembler.SignatureConstant;
import com.tangosol.dev.assembler.Snewarray;
import com.tangosol.dev.assembler.SourceFileAttribute;
import com.tangosol.dev.assembler.StringConstant;
import com.tangosol.dev.assembler.Swap;
import com.tangosol.dev.assembler.Switch;
import com.tangosol.dev.assembler.SyntheticAttribute;
import com.tangosol.dev.assembler.Tableswitch;
import com.tangosol.dev.assembler.Try;
import com.tangosol.dev.assembler.UtfConstant;
import com.tangosol.dev.assembler.VMStructure;
import com.tangosol.dev.assembler.Znewarray;
import com.tangosol.dev.compiler.Compiler;
import com.tangosol.dev.compiler.CompilerException;
import com.tangosol.dev.compiler.Context;
import com.tangosol.dev.compiler.Locator;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.CompilePlan;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Implementation;
import com.tangosol.dev.component.Integration;
import com.tangosol.dev.component.Interface;
import com.tangosol.dev.component.Parameter;
import com.tangosol.dev.component.Property;
import com.tangosol.dev.component.ReturnValue;
import com.tangosol.util.Base;
import com.tangosol.util.ErrorList;
import com.tangosol.util.LiteMap;
import com.tangosol.util.LiteSet;
import com.tangosol.util.WrapperException;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;

public class EJB
        extends    _package.component.dev.compiler.Remoter
    {
    // Fields declarations
    
    /**
    * Property CLASS_ABSTRACT_REMOTE_SINK
    *
    */
    private static final String CLASS_ABSTRACT_REMOTE_SINK = "com.tangosol.run.component.AbstractRemoteSink";
    
    /**
    * Property CLASS_COLLECTION_HELPER
    *
    */
    private static final String CLASS_COLLECTION_HELPER = "com.tangosol.util.CollectionHelper";
    
    /**
    * Property CREATE_EXCEPTION
    *
    */
    private static final String CREATE_EXCEPTION = "javax.ejb.CreateException";
    
    /**
    * Property FIND_EXCEPTION
    *
    */
    private static final String FIND_EXCEPTION = "javax.ejb.FinderException";
    
    /**
    * Property FLD_HOME
    *
    */
    private static final String FLD_HOME = "__home";
    
    /**
    * Property FLD_PEER
    *
    */
    private static final String FLD_PEER = "__peer";
    
    /**
    * Property FLD_REMOTE
    *
    */
    private static final String FLD_REMOTE = "__remote";
    
    /**
    * Property IFACE_CONVERTER
    *
    */
    private static final String IFACE_CONVERTER = "com.tangosol.util.Converter";
    
    /**
    * Property IFACE_ENTITY_BEAN
    *
    */
    private static final String IFACE_ENTITY_BEAN = "javax.ejb.EntityBean";
    
    /**
    * Property IFACE_SERIALIZABLE
    *
    */
    private static final String IFACE_SERIALIZABLE = "java.io.Serializable";
    
    /**
    * Property IFACE_SESSION_BEAN
    *
    */
    private static final String IFACE_SESSION_BEAN = "javax.ejb.SessionBean";
    
    /**
    * Property METH_CONVERT
    *
    */
    private static final String METH_CONVERT = "__convert";
    
    /**
    * Property METH_CONVERT_VIRTUAL
    *
    */
    private static final String METH_CONVERT_VIRTUAL = "__convertVirtual";
    
    /**
    * Property METH_CONVERTER_CONVERT
    *
    */
    private static final String METH_CONVERTER_CONVERT = "convert";
    
    /**
    * Property METH_CREATEHOME
    *
    */
    private static final String METH_CREATEHOME = "__createHome";
    
    /**
    * Property METH_CREATEREMOTE
    *
    */
    private static final String METH_CREATEREMOTE = "__createRemote";
    
    /**
    * Property METH_GET_REMOTEOBJECT
    *
    */
    public static final String METH_GET_REMOTEOBJECT = "get_RemoteObject";
    
    /**
    * Property METH_SET_REMOTEOBJECT
    *
    */
    public static final String METH_SET_REMOTEOBJECT = "set_RemoteObject";
    
    /**
    * Property METHOD_TYPE_CREATE
    *
    */
    public static final int METHOD_TYPE_CREATE = 2;
    
    /**
    * Property METHOD_TYPE_FIND_COLLECTION
    *
    */
    public static final int METHOD_TYPE_FIND_COLLECTION = 5;
    
    /**
    * Property METHOD_TYPE_FIND_ENUMERATION
    *
    */
    public static final int METHOD_TYPE_FIND_ENUMERATION = 4;
    
    /**
    * Property METHOD_TYPE_FIND_SINGLE
    *
    */
    public static final int METHOD_TYPE_FIND_SINGLE = 3;
    
    /**
    * Property METHOD_TYPE_NOT_REMOTE
    *
    */
    public static final int METHOD_TYPE_NOT_REMOTE = 0;
    
    /**
    * Property METHOD_TYPE_REMOTE
    *
    */
    public static final int METHOD_TYPE_REMOTE = 1;
    
    /**
    * Property METHOD_TYPE_REMOVE
    *
    */
    public static final int METHOD_TYPE_REMOVE = 6;
    
    /**
    * Property PEER_HOME_INTERFACE
    *
    */
    public static final int PEER_HOME_INTERFACE = 4;
    
    /**
    * Property PEER_PRIMARY_KEY
    *
    */
    public static final int PEER_PRIMARY_KEY = 6;
    
    /**
    * Property PEER_REMOTE_INTERFACE
    *
    */
    public static final int PEER_REMOTE_INTERFACE = 5;
    
    /**
    * Property PEER_SINK_EJB
    *
    */
    public static final int PEER_SINK_EJB = 3;
    
    /**
    * Property PrimaryKeyDataType
    *
    * (Private) Cached value of the primary key data type.
    */
    private transient com.tangosol.dev.component.DataType __m_PrimaryKeyDataType;
    
    /**
    * Property PROP_CMP
    *
    */
    private static final String PROP_CMP = "ContainerManaged";
    
    /**
    * Property PROP_DATA_FIELDS
    *
    */
    public static final String PROP_DATA_FIELDS = "DataFields";
    
    /**
    * Property PROP_KEY_FIELDS
    *
    */
    private static final String PROP_KEY_FIELDS = "KeyFields";
    
    /**
    * Property PROP_PRIMARY_KEY
    *
    */
    private static final String PROP_PRIMARY_KEY = "PrimaryKeyField";
    
    /**
    * Property REMOTE_EXCEPTION
    *
    */
    private static final String REMOTE_EXCEPTION = "java.rmi.RemoteException";
    
    /**
    * Property REMOTE_IMPLEMENTATION_JVM_SIGNATURE
    *
    */
    private static final int REMOTE_IMPLEMENTATION_JVM_SIGNATURE = 5;
    
    /**
    * Property REMOTE_IMPLEMENTATION_NAME
    *
    */
    private static final int REMOTE_IMPLEMENTATION_NAME = 3;
    
    /**
    * Property REMOTE_IMPLEMENTATION_SIGNATURE
    *
    */
    private static final int REMOTE_IMPLEMENTATION_SIGNATURE = 4;
    
    /**
    * Property REMOTE_INTERFACE_JVM_SIGNATURE
    *
    */
    private static final int REMOTE_INTERFACE_JVM_SIGNATURE = 2;
    
    /**
    * Property REMOTE_INTERFACE_NAME
    *
    */
    private static final int REMOTE_INTERFACE_NAME = 0;
    
    /**
    * Property REMOTE_INTERFACE_SIGNATURE
    *
    */
    private static final int REMOTE_INTERFACE_SIGNATURE = 1;
    
    /**
    * Property REMOVE_EXCEPTION
    *
    */
    private static final String REMOVE_EXCEPTION = "javax.ejb.RemoveException";
    
    // Default constructor
    public EJB()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public EJB(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new EJB();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/remoter/EJB".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.Dev.Compiler.ClassGenerator;
        // import com.tangosol.dev.assembler.Aaload;
        // import com.tangosol.dev.assembler.Aastore;
        // import com.tangosol.dev.assembler.AccessFlags;
        // import com.tangosol.dev.assembler.Aconst;
        // import com.tangosol.dev.assembler.Aload;
        // import com.tangosol.dev.assembler.Anewarray;
        // import com.tangosol.dev.assembler.Areturn;
        // import com.tangosol.dev.assembler.Arraylength;
        // import com.tangosol.dev.assembler.Astore;
        // import com.tangosol.dev.assembler.Athrow;
        // import com.tangosol.dev.assembler.Attribute;
        // import com.tangosol.dev.assembler.Avar;
        // import com.tangosol.dev.assembler.Baload;
        // import com.tangosol.dev.assembler.Bastore;
        // import com.tangosol.dev.assembler.Begin;
        // import com.tangosol.dev.assembler.Bnewarray;
        // import com.tangosol.dev.assembler.Caload;
        // import com.tangosol.dev.assembler.Case;
        // import com.tangosol.dev.assembler.Castore;
        // import com.tangosol.dev.assembler.Catch;
        // import com.tangosol.dev.assembler.Checkcast;
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.dev.assembler.Cnewarray;
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.Constant;
        // import com.tangosol.dev.assembler.ConstantPool;
        // import com.tangosol.dev.assembler.Constants;
        // import com.tangosol.dev.assembler.ConstantValueAttribute;
        // import com.tangosol.dev.assembler.D2f;
        // import com.tangosol.dev.assembler.D2i;
        // import com.tangosol.dev.assembler.D2l;
        // import com.tangosol.dev.assembler.Dadd;
        // import com.tangosol.dev.assembler.Daload;
        // import com.tangosol.dev.assembler.Dastore;
        // import com.tangosol.dev.assembler.Dcmpg;
        // import com.tangosol.dev.assembler.Dcmpl;
        // import com.tangosol.dev.assembler.Dconst;
        // import com.tangosol.dev.assembler.Ddiv;
        // import com.tangosol.dev.assembler.DeprecatedAttribute;
        // import com.tangosol.dev.assembler.Dload;
        // import com.tangosol.dev.assembler.Dmul;
        // import com.tangosol.dev.assembler.Dneg;
        // import com.tangosol.dev.assembler.Dnewarray;
        // import com.tangosol.dev.assembler.DoubleConstant;
        // import com.tangosol.dev.assembler.Drem;
        // import com.tangosol.dev.assembler.Dreturn;
        // import com.tangosol.dev.assembler.Dstore;
        // import com.tangosol.dev.assembler.Dsub;
        // import com.tangosol.dev.assembler.Dup;
        // import com.tangosol.dev.assembler.Dup2;
        // import com.tangosol.dev.assembler.Dup2_x1;
        // import com.tangosol.dev.assembler.Dup2_x2;
        // import com.tangosol.dev.assembler.Dup_x1;
        // import com.tangosol.dev.assembler.Dup_x2;
        // import com.tangosol.dev.assembler.Dvar;
        // import com.tangosol.dev.assembler.End;
        // import com.tangosol.dev.assembler.ExceptionsAttribute;
        // import com.tangosol.dev.assembler.F2d;
        // import com.tangosol.dev.assembler.F2i;
        // import com.tangosol.dev.assembler.F2l;
        // import com.tangosol.dev.assembler.Fadd;
        // import com.tangosol.dev.assembler.Faload;
        // import com.tangosol.dev.assembler.Fastore;
        // import com.tangosol.dev.assembler.Fcmpg;
        // import com.tangosol.dev.assembler.Fcmpl;
        // import com.tangosol.dev.assembler.Fconst;
        // import com.tangosol.dev.assembler.Fdiv;
        // import com.tangosol.dev.assembler.Field;
        // import com.tangosol.dev.assembler.FieldConstant;
        // import com.tangosol.dev.assembler.Fload;
        // import com.tangosol.dev.assembler.FloatConstant;
        // import com.tangosol.dev.assembler.Fmul;
        // import com.tangosol.dev.assembler.Fneg;
        // import com.tangosol.dev.assembler.Fnewarray;
        // import com.tangosol.dev.assembler.Frem;
        // import com.tangosol.dev.assembler.Freturn;
        // import com.tangosol.dev.assembler.Fstore;
        // import com.tangosol.dev.assembler.Fsub;
        // import com.tangosol.dev.assembler.Fvar;
        // import com.tangosol.dev.assembler.Getfield;
        // import com.tangosol.dev.assembler.Getstatic;
        // import com.tangosol.dev.assembler.Goto;
        // import com.tangosol.dev.assembler.GuardedSection;
        // import com.tangosol.dev.assembler.I2b;
        // import com.tangosol.dev.assembler.I2c;
        // import com.tangosol.dev.assembler.I2d;
        // import com.tangosol.dev.assembler.I2f;
        // import com.tangosol.dev.assembler.I2l;
        // import com.tangosol.dev.assembler.I2s;
        // import com.tangosol.dev.assembler.Iadd;
        // import com.tangosol.dev.assembler.Iaload;
        // import com.tangosol.dev.assembler.Iand;
        // import com.tangosol.dev.assembler.Iastore;
        // import com.tangosol.dev.assembler.Iconst;
        // import com.tangosol.dev.assembler.Idiv;
        // import com.tangosol.dev.assembler.Ifeq;
        // import com.tangosol.dev.assembler.Ifge;
        // import com.tangosol.dev.assembler.Ifgt;
        // import com.tangosol.dev.assembler.Ifle;
        // import com.tangosol.dev.assembler.Iflt;
        // import com.tangosol.dev.assembler.Ifne;
        // import com.tangosol.dev.assembler.Ifnonnull;
        // import com.tangosol.dev.assembler.Ifnull;
        // import com.tangosol.dev.assembler.If_acmpeq;
        // import com.tangosol.dev.assembler.If_acmpne;
        // import com.tangosol.dev.assembler.If_icmpeq;
        // import com.tangosol.dev.assembler.If_icmpge;
        // import com.tangosol.dev.assembler.If_icmpgt;
        // import com.tangosol.dev.assembler.If_icmple;
        // import com.tangosol.dev.assembler.If_icmplt;
        // import com.tangosol.dev.assembler.If_icmpne;
        // import com.tangosol.dev.assembler.Iinc;
        // import com.tangosol.dev.assembler.Iload;
        // import com.tangosol.dev.assembler.Imul;
        // import com.tangosol.dev.assembler.Ineg;
        // import com.tangosol.dev.assembler.Inewarray;
        // import com.tangosol.dev.assembler.InnerClass;
        // import com.tangosol.dev.assembler.InnerClassesAttribute;
        // import com.tangosol.dev.assembler.Instanceof;
        // import com.tangosol.dev.assembler.IntConstant;
        // import com.tangosol.dev.assembler.InterfaceConstant;
        // import com.tangosol.dev.assembler.Invokeinterface;
        // import com.tangosol.dev.assembler.Invokespecial;
        // import com.tangosol.dev.assembler.Invokestatic;
        // import com.tangosol.dev.assembler.Invokevirtual;
        // import com.tangosol.dev.assembler.Ior;
        // import com.tangosol.dev.assembler.Irem;
        // import com.tangosol.dev.assembler.Ireturn;
        // import com.tangosol.dev.assembler.Ishl;
        // import com.tangosol.dev.assembler.Ishr;
        // import com.tangosol.dev.assembler.Istore;
        // import com.tangosol.dev.assembler.Isub;
        // import com.tangosol.dev.assembler.Iushr;
        // import com.tangosol.dev.assembler.Ivar;
        // import com.tangosol.dev.assembler.Ixor;
        // import com.tangosol.dev.assembler.Jsr;
        // import com.tangosol.dev.assembler.L2d;
        // import com.tangosol.dev.assembler.L2f;
        // import com.tangosol.dev.assembler.L2i;
        // import com.tangosol.dev.assembler.Label;
        // import com.tangosol.dev.assembler.Ladd;
        // import com.tangosol.dev.assembler.Laload;
        // import com.tangosol.dev.assembler.Land;
        // import com.tangosol.dev.assembler.Lastore;
        // import com.tangosol.dev.assembler.Lcmp;
        // import com.tangosol.dev.assembler.Lconst;
        // import com.tangosol.dev.assembler.Ldiv;
        // import com.tangosol.dev.assembler.LineNumberTableAttribute;
        // import com.tangosol.dev.assembler.Lload;
        // import com.tangosol.dev.assembler.Lmul;
        // import com.tangosol.dev.assembler.Lneg;
        // import com.tangosol.dev.assembler.Lnewarray;
        // import com.tangosol.dev.assembler.LocalVariableTableAttribute;
        // import com.tangosol.dev.assembler.LongConstant;
        // import com.tangosol.dev.assembler.Lookupswitch;
        // import com.tangosol.dev.assembler.Lor;
        // import com.tangosol.dev.assembler.Lrem;
        // import com.tangosol.dev.assembler.Lreturn;
        // import com.tangosol.dev.assembler.Lshl;
        // import com.tangosol.dev.assembler.Lshr;
        // import com.tangosol.dev.assembler.Lstore;
        // import com.tangosol.dev.assembler.Lsub;
        // import com.tangosol.dev.assembler.Lushr;
        // import com.tangosol.dev.assembler.Lvar;
        // import com.tangosol.dev.assembler.Lxor;
        // import com.tangosol.dev.assembler.Method;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.Monitorenter;
        // import com.tangosol.dev.assembler.Monitorexit;
        // import com.tangosol.dev.assembler.Multianewarray;
        // import com.tangosol.dev.assembler.New;
        // import com.tangosol.dev.assembler.Nop;
        // import com.tangosol.dev.assembler.Op;
        // import com.tangosol.dev.assembler.OpArray;
        // import com.tangosol.dev.assembler.OpBranch;
        // import com.tangosol.dev.assembler.OpConst;
        // import com.tangosol.dev.assembler.OpDeclare;
        // import com.tangosol.dev.assembler.OpLoad;
        // import com.tangosol.dev.assembler.OpStore;
        // import com.tangosol.dev.assembler.OpSwitch;
        // import com.tangosol.dev.assembler.OpVariable;
        // import com.tangosol.dev.assembler.Pop;
        // import com.tangosol.dev.assembler.Pop2;
        // import com.tangosol.dev.assembler.Putfield;
        // import com.tangosol.dev.assembler.Putstatic;
        // import com.tangosol.dev.assembler.RefConstant;
        // import com.tangosol.dev.assembler.Ret;
        // import com.tangosol.dev.assembler.Return;
        // import com.tangosol.dev.assembler.Rstore;
        // import com.tangosol.dev.assembler.Rvar;
        // import com.tangosol.dev.assembler.Saload;
        // import com.tangosol.dev.assembler.Sastore;
        // import com.tangosol.dev.assembler.SignatureConstant;
        // import com.tangosol.dev.assembler.Snewarray;
        // import com.tangosol.dev.assembler.SourceFileAttribute;
        // import com.tangosol.dev.assembler.StringConstant;
        // import com.tangosol.dev.assembler.Swap;
        // import com.tangosol.dev.assembler.Switch;
        // import com.tangosol.dev.assembler.SyntheticAttribute;
        // import com.tangosol.dev.assembler.Tableswitch;
        // import com.tangosol.dev.assembler.Try;
        // import com.tangosol.dev.assembler.UtfConstant;
        // import com.tangosol.dev.assembler.VMStructure;
        // import com.tangosol.dev.assembler.Znewarray;
        // import com.tangosol.dev.compiler.Compiler;
        // import com.tangosol.dev.compiler.CompilerException;
        // import com.tangosol.dev.compiler.Context;
        // import com.tangosol.dev.compiler.Locator;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Implementation;
        // import com.tangosol.dev.component.Integration;
        // import com.tangosol.dev.component.Interface;
        // import com.tangosol.dev.component.Parameter;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.ReturnValue;
        

        }
    
    // Declared at the super level
    /**
    * This adds comments to the head of the main component class file java
    * listing.
    */
    public void addComments(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import java.util.Collection;
        // import java.util.Iterator;
        
        super.addComments(gen);
        
        gen.println("/*"                                          );  
        gen.println("* This component is remoted according to the");
        gen.println("* Enterprise Javabean specification"         );
        
        if (isSessionEJB(gen))
            {
            gen.println("*     Session Bean");
            }
        else
            {
            gen.println("*     Entity Bean");
            gen.println("*     Primary Key Class \"" +
                                getPrimaryKeyDataType(gen) + '"');
            gen.println("*     " + (isContainerManaged(gen) ?
                                "Container Managed Persistence" :
                                "Bean Managed Persistence"      ));
        
            Collection col = getDataFields(gen);
            if (col != null)
                {
                gen.print  ("*     Data Fields:");
                char chSeparator = ' ';
                for (Iterator itr = col.iterator(); itr.hasNext();)
                    {
                    gen.print(chSeparator + (String) itr.next());
                    chSeparator = ',';
                    }
                gen.println();
                }
            }
        gen.println("*/"                                          );

        }
    
    /**
    * Convert the current object on the execution stack from one object type to
    * another.  This is used to convert between the generated remote component
    * objects and the EJB remote objects.  This assumes that a static public
    * convert method exists on the main component class which can be called to
    * do the conversion.
    * 
    * This will both add the code needed to convert the object in the current
    * java code attribute and add the text needed to convert the object in the
    * current java source listing.
    * 
    * @param gen the ClassGenerator used to generate the code
    * @param dtComponent the data type of the main component class which is
    * being converted
    * @param dtOriginal the data type of the object to convert from
    * @param sOriginal the source listing string used to load the original
    * object, this will be added
    *                            to the java source listing surrounded by the
    * needed to do the conversion
    * @param dtNew the data type to convert the original object to
    */
    private void addConvertCall(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.DataType dtComponent, com.tangosol.dev.component.DataType dtOriginal, String sOriginal, com.tangosol.dev.component.DataType dtNew)
        {
        CodeAttribute code = gen.getCode();
        
        while (dtComponent.isArray())
            {
            dtComponent = dtComponent.getElementType();
            }
        
        String sOrgJVMSig = gen.resolveJVMSignature(dtOriginal);
        String sNewJVMSig = gen.resolveJVMSignature(dtNew);
        
        Component cdGlobal = gen.getComponent(dtComponent.getComponentName()).getGlobalParent();
        DataType  dtGlobal = DataType.getComponentType(cdGlobal.getQualifiedName());
        
        code.add(new Aconst());
        MethodConstant cM = new MethodConstant(dtGlobal.getClassConstant(),
            new SignatureConstant(METH_CONVERT,
                '(' + sOrgJVMSig + sNewJVMSig + ')' + sNewJVMSig));
        code.add(new Invokestatic(cM));
        
        gen.print(gen.formatClass(dtGlobal.getClassName())
            + '.' + METH_CONVERT + '(' + sOriginal + ", null)");
        }
    
    // Declared at the super level
    public void addEffectiveIntegration(_package.component.dev.compiler.ClassGenerator gen, _package.component.dev.compiler.Integrator effectiveIntegrator)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.Integrator;
        // import Component.Dev.Storage;
        // import com.tangosol.util.ErrorList;
        
        Component cdIntegrator   = gen.getCD();
        if (cdIntegrator.isResultAbstract())
            {
            // nothing to do, lets get out of here now...
            return;
            }
        
        Component cdEffective      = effectiveIntegrator.getCD();
        String    sEffective       = cdEffective.getQualifiedName();
        DataType  dtEffective      = DataType.getComponentType(sEffective);
        String    sEffectiveName   = gen.formatType(dtEffective);
        String    sEffectiveJVMSig = dtEffective.getJVMSignature();
        
        String    sComponent       = cdIntegrator.getQualifiedName();
        String    sComponentName   = sComponent.substring(sComponent.lastIndexOf('.') + 1);
        DataType  dtComponent      = DataType.getComponentType(sComponent);
        String    sComponentJVMSig = dtComponent.getJVMSignature();
        
        String    sRemote          = getAutoGenClass(gen, cdEffective, PEER_REMOTE_INTERFACE);
        String    sRemoteName      = gen.formatClass(sRemote);
        DataType  dtRemote         = DataType.getClassType(sRemote.replace('/', '.'));
        String    sRemoteJVMSig    = dtRemote.getJVMSignature();
        
        // Generate component to remote object converters on
        // the main component class.
        
        ClassFile clz              = gen.getClassFile();
        
        // Component to Remote Object converters
        
        gen.println();
        gen.println("// Component to Remote Object converters");
        
        generateArrayConverter(gen, dtComponent, dtRemote);
        
        Method method = clz.addMethod(
            METH_CONVERT, "(" + sComponentJVMSig + sRemoteJVMSig + ')' + sRemoteJVMSig);
        method.setStatic(true);
        method.setPublic();
        
        gen.println("static public " + sRemoteName + ' ' + METH_CONVERT + '(' + sComponentName + " org, " + sRemoteName + " type)");
        
        CodeAttribute code = gen.BeginSegment(method);
        
        Avar vL_org = new Avar("org");
        code.add(vL_org);
        code.add(new Avar("type"));
        
        Label lbl_orgNonNull = new Label();
        code.add(new Aload(vL_org));
        code.add(new Ifnonnull(lbl_orgNonNull));
        
        gen.println("if (org == null)");
        gen.BeginScope();
            {
            code.add(new Aconst());
            code.add(new Areturn());
            gen.println("return null;");
            }
        gen.EndScope();
        code.add(lbl_orgNonNull);
        
        Property prop = cdIntegrator.getProperty(gen.PROP_REMOTEOBJECT);
        if (prop == null)
            {
            throw new IllegalStateException(get_Name() +
                ".generatePeer: " + "property is missing for " + gen.PROP_REMOTEOBJECT);
            }
        Behavior bhvrGetRemoteObject = cdIntegrator.getBehavior(
            prop.getAccessorSignature(Property.PA_GET_SINGLE));
        if (bhvrGetRemoteObject == null)
            {
            throw new IllegalArgumentException(get_Name() +
                ".generatePeer: " + "invalid accessor for " + gen.PROP_REMOTEOBJECT);
            }
        MethodConstant cM = gen.findMethod(bhvrGetRemoteObject, false);
        code.add(new Aload(vL_org));
        code.add(new Invokevirtual(cM));
        code.add(new Checkcast(dtRemote.getClassConstant()));
        code.add(new Areturn());
        
        gen.println("return (" + sRemoteName + ") org." + cM.getName() + "();");
        
        gen.EndSegment(method);
        
        
        // Remote Object to Component converters
        
        gen.println();
        gen.println("// Remote Object to Component converters");
        
        generateArrayConverter(gen, dtRemote, dtComponent);
        
        method = clz.addMethod(
            METH_CONVERT, "(" + sRemoteJVMSig + sComponentJVMSig + ')' + sComponentJVMSig);
        method.setStatic(true);
        method.setPublic();
        
        gen.println("static public " + sComponentName + ' ' + METH_CONVERT + '(' + sRemoteName + " org, " + sComponentName + " type)");
        
        code = gen.BeginSegment(method);
        
        vL_org = new Avar("org");
        code.add(vL_org);
        code.add(new Avar("type"));
        
        lbl_orgNonNull = new Label();
        code.add(new Aload(vL_org));
        code.add(new Ifnonnull(lbl_orgNonNull));
        
        gen.println("if (org == null)");
        gen.BeginScope();
            {
            code.add(new Aconst());
            code.add(new Areturn());
            gen.println("return null;");
            }
        gen.EndScope();
        code.add(lbl_orgNonNull);
        
        code.add(new New(dtComponent.getClassConstant()));
        code.add(new Dup());
        code.add(new Aload(vL_org));
        cM = new MethodConstant(dtComponent.getClassConstant(),
            new SignatureConstant(gen.CONSTRUCTOR_NAME, gen.INIT_REMOTEOBJECT_SIG));
        code.add(new Invokespecial(cM));
        code.add(new Areturn());
        
        gen.println("return new " + sComponentName + "(org);");
        
        gen.EndSegment(method);
        
        if (isNeedNewClientInstance(gen, cdEffective))
            {
            // Remote Object to Component virtual converter
        
            gen.println();
            gen.println("// Remote Object to Component virtual converter");
        
            method = clz.addMethod(
                METH_CONVERT_VIRTUAL, "(" + sRemoteJVMSig + ')' + sEffectiveJVMSig);
            method.setProtected();
        
            gen.println("protected " + sEffectiveName + ' ' + METH_CONVERT_VIRTUAL + '(' + sRemoteName + " org)");
        
            code = gen.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
            vL_org = new Avar("org");
            code.add(vL_org);
        
            lbl_orgNonNull = new Label();
            code.add(new Aload(vL_org));
            code.add(new Ifnonnull(lbl_orgNonNull));
        
            gen.println("if (org == null)");
            gen.BeginScope();
                {
                code.add(new Aconst());
                code.add(new Areturn());
                gen.println("return null;");
                }
            gen.EndScope();
            code.add(lbl_orgNonNull);
        
            code.add(new New(dtComponent.getClassConstant()));
            code.add(new Dup());
            code.add(new Aload(vL_org));
            cM = new MethodConstant(dtComponent.getClassConstant(),
                new SignatureConstant(gen.CONSTRUCTOR_NAME, gen.INIT_REMOTEOBJECT_SIG));
            code.add(new Invokespecial(cM));
            code.add(new Areturn());
        
            gen.println("return new " + sComponentName + "(org);");
        
            gen.EndSegment(method);
            }

        }
    
    /**
    * Add the java.rmi.RemoteException to the list of passed exceptions if it
    * is not already covered by the list of exceptions.
    * 
    * This also removes any exceptions which also have one of it's super-class
    * declared in the exception list.
    */
    private String[] addRemoteExceptions(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr)
            throws com.tangosol.dev.component.ComponentException
        {
        String[] asRemoteExceptions;
        switch (getMethodType(gen, bhvr))
            {
            case METHOD_TYPE_CREATE:
                asRemoteExceptions = new String[] {CREATE_EXCEPTION, REMOTE_EXCEPTION};
                break;
            case METHOD_TYPE_FIND_SINGLE:
            case METHOD_TYPE_FIND_ENUMERATION:
            case METHOD_TYPE_FIND_COLLECTION:
                asRemoteExceptions = new String[] {FIND_EXCEPTION, REMOTE_EXCEPTION};
                break;
            case METHOD_TYPE_REMOVE:
                asRemoteExceptions = new String[] {REMOVE_EXCEPTION, REMOTE_EXCEPTION};
                break;
            default:
                asRemoteExceptions = new String[] {REMOTE_EXCEPTION};
                break;
            }
        
        // gg TODO: replace with collections
        
        String[] asExceptions = bhvr.getExceptionNames();
        int      cExceptions  = asExceptions.length;
        
        // trim out the removed exceptions
        for (int i = 0; i < cExceptions;)
            {
            String sException = asExceptions[i];
            if (sException == null || bhvr.getException(sException) == null)
                {
                --cExceptions;
                String[] asNewExceptions = new String[cExceptions];
                System.arraycopy(asExceptions, 0, asNewExceptions, 0, i);
                System.arraycopy(asExceptions, i + 1, asNewExceptions, i, cExceptions - i);
                asExceptions = asNewExceptions;
                }
            else
                {
                ++i;
                }
            }
        
        if (cExceptions == 0)
            {
            return asRemoteExceptions;
            }
        
        // Add in the remote exceptions if not already there
        for (int i = 0; i < asRemoteExceptions.length; ++i)
            {
            String sRemoteException = asRemoteExceptions[i];
            if (!gen.isClassesSuperOfClass(asExceptions, sRemoteException))
                {
                String[] asNewExceptions = new String[cExceptions + 1];
                System.arraycopy(asExceptions, 0, asNewExceptions, 0, cExceptions);
                asNewExceptions[cExceptions] = sRemoteException;
                asExceptions = asNewExceptions;
                ++cExceptions;
                }
            }
        
        // Trim out all redundant exceptions
        /*
        for (int iA = 0; iA < cExceptions; ++iA)
            {
            String sExceptionA = asExceptions[iA];
            for (int iB = iA + 1; iB < cExceptions; ++iB)
                {
                String sExceptionB = asExceptions[iB];
                if (gen.isClassSuperOfClass(sExceptionB, sExceptionA))
                    {
                    // Get rid of Exception A
                    System.arraycopy(asExceptions, iA + 1, asExceptions, iA, cExceptions - (iA + 1));
                    --cExceptions;
                    --iA; // cheap way to not increment iA
                    break;
                    }
                if (gen.isClassSuperOfClass(sExceptionA, sExceptionB))
                    {
                    // Get rid of Exception B
                    int i = iExceptions - (iB + 1);
                    if (i > 0)
                        {
                        System.arraycopy(asExceptions, iB + 1, asExceptions, iB, i);
                        }
                    --cExceptions;
                    --iB; // cheap way to not increment iB
                    }
                }
            }
        */
        
        if (cExceptions == asExceptions.length)
            {
            return asExceptions;
            }
        
        String[] asNewExceptions = new String[cExceptions];
        System.arraycopy(asExceptions, 0, asNewExceptions, 0, cExceptions);
        return asNewExceptions;

        }
    
    private com.tangosol.dev.assembler.OpDeclare[] addRemoteParameters(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr, com.tangosol.dev.component.DataType[] adtRemoteSignature)
        {
        CodeAttribute code = gen.getCode();
        
        int cntParams = adtRemoteSignature.length - 1;
        _assert(cntParams == bhvr.getParameterCount());
        OpDeclare[] v_params = new OpDeclare[cntParams];
        
        for (int i = 0; i < cntParams; ++i)
            {
            v_params[i] = gen.getDeclareVarOp(adtRemoteSignature[i + 1],
                bhvr.getParameter(i).getName());
            code.add(v_params[i]);
            }
        
        return v_params;
        }
    
    // Declared at the super level
    /**
    * Return the interfaces that the feed needs to declare as implementing.
    * 
    * @see #generateFeedInterfaces
    */
    public void addRoutedInterfaces(_package.component.dev.compiler.ClassGenerator gen, java.util.Collection colRoutedInterfaces)
        {
        // import java.util.Enumeration;
        
        super.addRoutedInterfaces(gen, colRoutedInterfaces);
        
        String sInterface = isSessionEJB(gen) ?
            IFACE_SESSION_BEAN : IFACE_ENTITY_BEAN;
        
        if (!gen.isClassSuperOfClass(sInterface,
                gen.getIntegrator().getIntegrateeType().getClassName()))
            {
            colRoutedInterfaces.add(sInterface);
            }
        
        // Determine if this class has a home find method that
        // returns a collection of keys (only for BMP beans)
        
        if (!isContainerManaged(gen))
            {
            Component cd      = gen.getCD();
            String    sPKName = getPrimaryKeyValue(gen, cd);
            if (sPKName != null
                && sPKName.charAt(0) == '$')
                {
                for (Enumeration enum = cd.getBehaviors(); enum.hasMoreElements();)
                    {
                    Behavior bhvr = (Behavior) enum.nextElement();
                    if (bhvr != null)
                        {
                        switch (getMethodType(gen, bhvr))
                            {
                            case METHOD_TYPE_FIND_ENUMERATION:
                            case METHOD_TYPE_FIND_COLLECTION:
                                colRoutedInterfaces.add(IFACE_CONVERTER);
                                return;
                            }
                        }
                    }
                }
            }
        }
    
    // Declared at the super level
    /**
    * Add to the specified collection the property names that the feed needs to
    * declare.
    */
    public void addRoutedProperties(_package.component.dev.compiler.ClassGenerator gen, java.util.Collection colRoutedProperties)
        {
        // import java.util.Collection;
        
        super.addRoutedProperties(gen, colRoutedProperties);
        
        Collection fields = getDataFields(gen);
        if (fields != null)
            {
            colRoutedProperties.addAll(fields);
            }
        }
    
    // Declared at the super level
    /**
    * Add in any pre-amble required by the remoter to the set_Sink method.  The
    * set_Sink method is used to establish the remote object of a remoted
    * component.  This allows any remoter sub-class to check if the object
    * being set is of it's expected remote object type, and if so, it can wrap
    * it in the Sink class that deals with that type of remote object.
    * 
    * @param gen the ClassGenerator being used to generate the class
    * @param method the set_Sink method being generated
    * @param vL_this the "this" parameter associated with the above set_Sink
    * method
    * @param vL_prm the first parameter being passed into the above set_Sink
    * method
    */
    public void addSetSinkPreamble(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.assembler.Method method, com.tangosol.dev.assembler.Avar vL_this, com.tangosol.dev.assembler.Avar vL_prm)
        {
        super.addSetSinkPreamble(gen, method, vL_this, vL_prm);
        
        Component cdIntegrator    = gen.getCD();
        if (cdIntegrator.isResultAbstract())
            {
            return;
            }
        DataType  dtIntegrator    = DataType.getComponentType(cdIntegrator.getQualifiedName());
        String    sPrm            = vL_prm.getVariableName();
        DataType  dtSink          = gen.getIntegrator().getSinkType();
        String    sSink           = dtSink.getClassName();
        String    sSinkName       = gen.formatClass(sSink);
        String    sSinkEJB        = getAutoGenClass(gen, cdIntegrator, PEER_SINK_EJB);
        String    sEJBHome        = getAutoGenClass(gen, cdIntegrator, PEER_HOME_INTERFACE);
        String    sEJBRemote      = getAutoGenClass(gen, cdIntegrator, PEER_REMOTE_INTERFACE);
        String    sSinkEJBName    = gen.formatClass(sSinkEJB);
        String    sEJBHomeName    = gen.formatClass(sEJBHome);
        String    sEJBRemoteName  = gen.formatClass(sEJBRemote);
        DataType  dtSinkEJB       = DataType.getClassType(sSinkEJB.replace('/', '.'));
        DataType  dtEJBHome       = DataType.getClassType(sEJBHome.replace('/', '.'));
        DataType  dtEJBRemote     = DataType.getClassType(sEJBRemote.replace('/', '.'));
        ClassConstant ccSink      = dtSink.getClassConstant();
        ClassConstant ccSinkEJB   = dtSinkEJB.getClassConstant();
        ClassConstant ccEJBHome   = dtEJBHome.getClassConstant();
        ClassConstant ccEJBRemote = dtEJBRemote.getClassConstant();
        
        CodeAttribute code = gen.getCode();
        
        // Generate the set_Sink() preamble
        
        gen.println("//++ EJB preamble");
        gen.println("// check if the sink is not already a of the correct type");
        
        Label lbl_isNotEJBInterface = new Label();
        code.add(new Aload(vL_prm));
        code.add(new Ifnull(lbl_isNotEJBInterface));
        gen.println("while (" + sPrm + " != null");
        
        code.add(new Aload(vL_prm));
        code.add(new Instanceof(ccSink));
        code.add(new Ifne(lbl_isNotEJBInterface));
        gen.println("       && !(" + sPrm + " instanceof " + sSinkName + "))");
        
        gen.BeginScope();
            {
            gen.println("// check if the sink is either the EJB home or remote interface");
        
            code.add(new Aload(vL_prm));
            code.add(new Instanceof(ccEJBHome));
            Label lbl_isEJBInterface = new Label();
            code.add(new Ifne(lbl_isEJBInterface));
        
            gen.println("if (!(" + sPrm + " instanceof " + sEJBHomeName);
        
            code.add(new Aload(vL_prm));
            code.add(new Instanceof(ccEJBRemote));
            code.add(new Ifne(lbl_isEJBInterface));
        
            gen.println("      || " + sPrm + " instanceof " + sEJBRemoteName + "))");
            gen.BeginScope();
                {
                Try   lbl_try    = new Try();
                Label lbl_catch  = new Label();
        
                code.add(lbl_try);
        
                gen.println("try");
                gen.BeginScope();
                    {
                    Avar vL_clz = new Avar("clz");
                    code.add(vL_clz);
        
                    gen.println("Class clz;");
        
                    gen.addClassForName(dtEJBHome.getClassName(), vL_clz);
                    
                    code.add(new Aload(vL_prm));
                    code.add(new Aload(vL_clz));
                    MethodConstant cM_narrow = gen.findMethod("javax.rmi.PortableRemoteObject",
                        "narrow", "(Ljava/lang/Object;Ljava/lang/Class;)Ljava/lang/Object;");
                    code.add(new Invokestatic(cM_narrow));
                    code.add(new Astore(vL_prm));
        
                    gen.println(sPrm + " = javax.rmi.PortableRemoteObject.narrow("
                            + sPrm + ", clz);");
                    code.add(new Goto(lbl_isEJBInterface));
                    }
                gen.EndScope();
                code.add(new Catch(lbl_try,
                    new ClassConstant("java.lang.ClassCastException"), lbl_catch));
        
                code.add(lbl_catch);
                gen.println("catch (ClassCastException e)");
                gen.BeginScope();
                    {
                    code.add(new Pop());
                    code.add(new Goto(lbl_isNotEJBInterface));
                    gen.println("break;");
                    }
                gen.EndScope();
                }
            gen.EndScope();
            code.add(lbl_isEJBInterface);
        
            code.add(new New(ccSinkEJB));
            code.add(new Dup());
        
            gen.print(sSinkEJBName + " sinkEJB = new " + sSinkEJBName);
            if (isNeedNewClientInstance(gen, cdIntegrator))
                {
                code.add(new Aload(vL_this));
                MethodConstant cM = new MethodConstant(ccSinkEJB,
                    new SignatureConstant(gen.CONSTRUCTOR_NAME, "(" + dtIntegrator.getJVMSignature() + ")V"));
                code.add(new Invokespecial(cM));
        
                gen.println("(this);");
                }
            else
                {
                MethodConstant cM = new MethodConstant(ccSinkEJB,
                    new SignatureConstant(gen.CONSTRUCTOR_NAME, "()V"));
                code.add(new Invokespecial(cM));
        
                gen.println("();");
                }
        
            code.add(new Dup());
            code.add(new Aload(vL_prm));
            MethodConstant cM = new MethodConstant(ccSinkEJB,
                new SignatureConstant(METH_SET_REMOTEOBJECT, "(Ljava.lang.Object;)V"));
            code.add(new Invokevirtual(cM));
            
            gen.println("sinkEJB." + cM.getName() + "(" + sPrm + ");");
        
            code.add(new Astore(vL_prm));
        
            gen.println(sPrm + " = sinkEJB;");
        
            // the following would be optimized-out by the assembler anyway
            // code.add(new Goto(lbl_isNotEJBInterface));
            gen.println("break;");
            }
        gen.EndScope();
        code.add(lbl_isNotEJBInterface);
        
        gen.println("//-- EJB preamble");
        gen.println();
        }
    
    /**
    * Generate an array version of the static public conversion call.  This
    * assumes that a non-array version of the conversion exists to use to
    * convert each element of the array between the data types.
    * 
    * This generated public static method is then used by the generated code to
    * convert between remote component arrays and remote object arrays across
    * remote calls.
    * 
    * @param gen the ClassGenerator used to generate the code
    * @param dtOriginal the data type of the object array to convert from
    * @param dtNew the data type to convert the original object array to
    */
    private void generateArrayConverter(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.DataType dtOrg, com.tangosol.dev.component.DataType dtNew)
            throws com.tangosol.dev.component.ComponentException
        {
        
        ClassFile clz = gen.getClassFile();
        
        String sOrgType = gen.formatClass(dtOrg.getClassName());
        String sNewType = gen.formatClass(dtNew.getClassName());
        
        String sOrgJVMSig = dtOrg.getJVMSignature();
        String sNewJVMSig = dtNew.getJVMSignature();
        
        DataType dtArrayOrg = dtOrg.getArrayType();
        DataType dtArrayNew = dtNew.getArrayType();
        
        String sArrayOrgJVMSig = dtArrayOrg.getJVMSignature();
        String sArrayNewJVMSig = dtArrayNew.getJVMSignature();
        
        String sArrayOrgType = sOrgType + "[]";
        String sArrayNewType = sNewType + "[]";
        
        Method method = clz.addMethod(
            METH_CONVERT, "(" + sArrayOrgJVMSig + sArrayNewJVMSig + ')' + sArrayNewJVMSig);
        method.setStatic(true);
        method.setPublic();
        
        gen.println("static public " + sArrayNewType + ' ' + METH_CONVERT + '(' + sArrayOrgType + " aOrg, " + sArrayNewType + " type)");
        CodeAttribute code = gen.BeginSegment(method);
        
        Avar vL_aOrg = new Avar("aOrg");
        code.add(vL_aOrg);
        code.add(new Avar("type"));
        
        Label lbl_orgNonNull = new Label();
        code.add(new Aload(vL_aOrg));
        code.add(new Ifnonnull(lbl_orgNonNull));
        
        gen.println("if (aOrg == null)");
        gen.BeginScope();
            {
            code.add(new Aconst());
            code.add(new Areturn());
            gen.println("return null;");
            }
        gen.EndScope();
        code.add(lbl_orgNonNull);
        
        Ivar vL_count = new Ivar("count");
        code.add(vL_count);
        
        code.add(new Aload(vL_aOrg));
        code.add(new Arraylength());
        code.add(new Istore(vL_count));
        
        gen.println("int count = aOrg.length;");
        
        Avar vL_aNew = new Avar("aNew");
        code.add(vL_aNew);
        code.add(new Iload(vL_count));
        code.add(new Anewarray(dtNew.getClassConstant()));
        code.add(new Astore(vL_aNew));
        
        gen.println(sArrayNewType + " aNew = new " + sNewType + "[count];");
        
        Ivar vL_i = new Ivar("i");
        code.add(vL_i);
        code.add(new Iconst(0));
        code.add(new Istore(vL_i));
        Label lbl_forNext = new Label();
        code.add(lbl_forNext);
        code.add(new Iload(vL_i));
        code.add(new Iload(vL_count));
        Label lbl_forEnd = new Label();
        code.add(new If_icmpge(lbl_forEnd));
        
        gen.println("for (int i = 0; i < count; ++i)");
        
        gen.BeginScope();
            {
            code.add(new Aload(vL_aNew));
            code.add(new Iload(vL_i));
            code.add(new Aload(vL_aOrg));
            code.add(new Iload(vL_i));
            code.add(new Aaload());
            code.add(new Aconst());
            MethodConstant cM = new MethodConstant(clz.getClassConstant(),
                new SignatureConstant(METH_CONVERT,
                    '(' + sOrgJVMSig + sNewJVMSig + ')' + sNewJVMSig));
            code.add(new Invokestatic(cM));
            code.add(new Aastore());
        
            gen.println("aNew[i] = " + METH_CONVERT + "(aOrg[i], null);");
        
            code.add(new Iinc(vL_i, (short) 1)); // This is the "++i"
            code.add(new Goto(lbl_forNext));
            }
        gen.EndScope();
        
        code.add(lbl_forEnd);
        code.add(new Aload(vL_aNew));
        code.add(new Areturn());
        
        gen.println("return aNew;");
        
        gen.EndSegment(method);

        }
    
    private void generateEJBHome(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.Integrator;
        // import Component.Dev.Storage;
        // import com.tangosol.util.Base;
        // import java.util.Enumeration;
        
        Integrator integrator   = gen.getIntegrator();
        Component  cdIntegrator = gen.getCD();
        Storage    storage      = gen.getStorage();
        String     sHomeClz     = getAutoGenClass(gen, cdIntegrator, PEER_HOME_INTERFACE);
        String     sHomeName    = sHomeClz.substring(sHomeClz.lastIndexOf('.') + 1);
        DataType   dtHome       = DataType.getClassType(sHomeClz.replace('/', '.'));
        
        // The home interface may not extend the super's home
        // since the create and find methods could not be narrowed
        
        String    sSuper = cdIntegrator.getSuperName();
        Component cdSuperIntegrator;
        
        String    sRemoteClz  = getAutoGenClass(gen, cdIntegrator, PEER_REMOTE_INTERFACE);
        String    sRemoteName = gen.formatClass(sRemoteClz);
        DataType  dtRemote    = DataType.getClassType(sRemoteClz.replace('/', '.'));
        DataType  dtKey       = getPrimaryKeyDataType(gen);
        
        gen.println("/* Interface"                                   );
        gen.println("*      " + gen.formatType(dtHome)               );
        gen.println("*"                                              );
        gen.println("* automatically generated \"EJBHome\" interface");
        gen.println("* for the remoted component:"                   );
        gen.println("*      " + cdIntegrator.getQualifiedName()      );
        gen.println("*/"                                             );
        gen.println();
        
        gen.println("package " + gen.formatClass(
            DataType.getComponentPackage(cdIntegrator), true) + ';');
        
        ClassFile clzHome = new ClassFile(sHomeClz, "java.lang.Object", true);
        
        gen.setClassFile(clzHome);
        
        clzHome.setPublic();
        clzHome.setAbstract(true);
        clzHome.addImplements("javax.ejb.EJBHome");
        
        gen.println();
        gen.println("public interface " + sHomeName);
        gen.println("         extends " + "javax.ejb.EJBHome");
        
        gen.BeginSegment(null);
        
        boolean fGenerateDefaultCreate = (dtKey == DataType.VOID);
        
        for (Enumeration enum = cdIntegrator.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
            if (bhvr != null)
                {
                int iType = getMethodType(gen, bhvr);
                switch (iType)
                    {
                    case METHOD_TYPE_CREATE:
                        fGenerateDefaultCreate = false;
                    case METHOD_TYPE_FIND_SINGLE:
                    case METHOD_TYPE_FIND_ENUMERATION:
                    case METHOD_TYPE_FIND_COLLECTION:
                        {
                        String[] asRemoteSignatures = getRemoteSignatures(gen, bhvr);
        
                        String sDescr = bhvr.getDescription();
                        if (sDescr.length() > 0)
                            {
                            gen.println("/**");
                            gen.println("* " + Base.breakLines(sDescr, 80, "* ", false));
                            gen.println("*/");
                            }
                        Method method = clzHome.addMethod(asRemoteSignatures[REMOTE_INTERFACE_NAME],
                            asRemoteSignatures[REMOTE_INTERFACE_JVM_SIGNATURE]);
                        method.setPublic();
                        method.setAbstract(true);
                    
                        gen.print("public ");
                        gen.formatMethod(asRemoteSignatures[REMOTE_INTERFACE_NAME],
                            asRemoteSignatures[REMOTE_INTERFACE_JVM_SIGNATURE],
                            bhvr);
                        gen.addExceptionsToMethod(method, addRemoteExceptions(gen, bhvr));
                        gen.println(";");
                        }
                    }
                }
            }
        
        if (fGenerateDefaultCreate)
            {
            gen.println("// default create implementation");
            Method method = clzHome.addMethod("create", "()" + dtRemote.getJVMSignature());
            method.setPublic();
            method.setAbstract(true);
            method.addException(CREATE_EXCEPTION);
            method.addException(REMOTE_EXCEPTION);
        
            gen.println("public " + sRemoteName + " create()");
            gen.println("    throws " + CREATE_EXCEPTION + ',');
            gen.println("           " + REMOTE_EXCEPTION + ';');
            }
        
        gen.EndSegment(null);
        
        gen.finalizeClassGeneration(true);
        }
    
    private void generateEJBPrimaryKey(_package.component.dev.compiler.ClassGenerator genPKComponent, _package.component.dev.compiler.ClassGenerator genPKClass)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.Integrator;
        // import Component.Dev.Storage;
        // import com.tangosol.util.Base;
        // import com.tangosol.util.LiteMap;
        // import java.util.Enumeration;
        // import java.util.Collection;
        // import java.util.Iterator;
        
        Integrator integrator       = genPKClass.getIntegrator();
        Component  cdIntegrator     = genPKClass.getCD();
        String     sPKComponent     = getPrimaryKeyValue(genPKClass, cdIntegrator);
        _assert(sPKComponent.charAt(0) == '$');
        Component  cdPKComponent    = cdIntegrator.getChild(sPKComponent.substring(1));
                   sPKComponent     = cdPKComponent.getQualifiedName();
        String     sPKComponentName = sPKComponent.substring(sPKComponent.lastIndexOf('.') + 1);
        DataType   dtPKComponent    = DataType.getComponentType(sPKComponent);
        _assert(cdPKComponent != null);
        ClassFile  clzPKComponent   = genPKComponent.getClassFile();
        Collection colPKFields      = getPrimaryKeyFields(genPKClass, cdIntegrator);
        
        if (colPKFields == null || colPKFields.isEmpty())
            {
            // TODO: soft code the error
            String sMsg = 
                "No Primary Key Fields have been declared for " +
                "Primay Key Child Component " + sPKComponent;
            genPKClass.addError(sMsg);
            return;
            }
        
        String     sPKClass     = getAutoGenClass(genPKClass, cdIntegrator, PEER_PRIMARY_KEY);
        String     sPKClassName = sPKClass.substring(sPKClass.lastIndexOf('.') + 1);
        DataType   dtPKClass    = DataType.getClassType(sPKClass.replace('/', '.'));
        
        Storage    storage = genPKClass.getStorage();
        
        // We currently do not support primary key class inheritance, each
        // new primary key class is it's own class.
        String    sPKClassSuper = integrator.getIntegrationMiscProperty("key", null);
        Component jcsPKClassSuper;
        if (sPKClassSuper == null)
            {
            sPKClassSuper = "java.lang.Object";
            jcsPKClassSuper = null;
            }
        else
            {
            jcsPKClassSuper = storage.loadSignature(sPKClassSuper);
            if (jcsPKClassSuper == null)
                {
                throw new IllegalArgumentException("Cannot resolve EJB Primary Key class " + sPKClassSuper);
                }
            }
        
        genPKClass.println("/* Class"                                         );
        genPKClass.println("*      " + genPKClass.formatType(dtPKClass)       );
        genPKClass.println("*"                                                );
        genPKClass.println("* automatically generated \"EJBPrimaryKey\" class");
        genPKClass.println("* for the remoted component:"                     );
        genPKClass.println("*      " + cdIntegrator.getQualifiedName()        );
        genPKClass.println("*/"                                               );
        genPKClass.println();
        
        genPKClass.println("package " + genPKClass.formatClass(
            DataType.getComponentPackage(cdIntegrator), true) + ';');
        
        ClassFile clzPKClass = new ClassFile(sPKClass, sPKClassSuper, false);
        
        genPKClass.setClassFile(clzPKClass);
        
        clzPKClass.setPublic();
        
        genPKClass.println();
        genPKClass.println("public class " + sPKClassName);
        if (sPKClassSuper.equals("java.lang.Object"))
            {
            clzPKClass.addImplements(IFACE_SERIALIZABLE);
            genPKClass.println("        implements " + IFACE_SERIALIZABLE);
            }
        else
            {
            genPKClass.println("        extends " + genPKClass.formatClass(sPKClassSuper));
            }
        
        genPKClass.BeginSegment(null);
        
        // declare all the primary key fields, while we
        // are iterating through, determine each field's
        // assembly field constant used to access the field
        
        LiteMap mapCF = new LiteMap();
        
        genPKClass.println("// Primary Key Fields");
        
        for (Iterator itr = colPKFields.iterator(); itr.hasNext();)
            {
            String   sProperty  = (String) itr.next();
            Property property   = cdPKComponent.getProperty(sProperty);
            DataType dtProperty = property.getDataType();
            if (!property.isSingle())
                {
                dtProperty = dtProperty.getArrayType();
                }
            String   sField     = integrator.getMappedField(sProperty);
            if (sField == null)
                {
                sField = sProperty;
                }
            String sDefined = null;
            if (jcsPKClassSuper == null)
                {
                if (property.isFromSuper())
                    {
                    // this is ugly, we need to determine *where* this
                    // field is first flagged as being part of the
                    // primary key
                    Component cd = cdPKComponent;
                    while (true)
                        {
                        String sPKSuperName = cd.getSuperName();
                        if (sPKSuperName.length() == 0)
                            {
                            break;
                            }
                        Component cdPKSuper = genPKClass.getComponent(sPKSuperName);
                        if (cdPKSuper.isGlobal())
                            {
                            break;
                            }
                        Component cdGlobalSuper = cdPKSuper.getGlobalParent();
                        if (!cdGlobalSuper.isRemote())
                            {
                            break;
                            }
                        String sValue = getPrimaryKeyValue(genPKClass, cdGlobalSuper);
                        if (sValue == null || sValue.charAt(0) != '$'
                            || !sValue.substring(1).equals(cdPKSuper.getLocalName()))
                            {
                            break;
                            }
                        Property propSuper = cdPKSuper.getProperty(sProperty);
                        if (propSuper == null)
                            {
                            break;
                            }
                        Collection col = getPrimaryKeyFields(genPKClass, cdGlobalSuper);
                        if (!col.contains(sProperty))
                            {
                            break;
                            }
                        cd = cdGlobalSuper;
                        if (!property.isFromSuper())
                            {
                            break;
                            }
                        }
                    FieldConstant cF = new FieldConstant(
                            getAutoGenClass(genPKClass, cd.getGlobalParent(), PEER_PRIMARY_KEY),
                            sProperty, genPKClass.resolveJVMSignature(dtProperty));
                    mapCF.put(sProperty, cF);
                    sDefined = cF.getClassConstant().getJavaName();
                    }
                else
                    {
                    FieldConstant cF = new FieldConstant(sPKClass,
                        sProperty, genPKClass.resolveJVMSignature(dtProperty));
                    mapCF.put(sProperty, cF);
                    }
                }
            else
                {
                FieldConstant cF = genPKClass.resolveField(
                    DataType.getClassType(sPKClassSuper), dtProperty, sField);
                if (cF != null)
                    {
                    mapCF.put(sProperty, cF);
                    sDefined = cF.getClassConstant().getJavaName();
                    }
                }
            if (sDefined != null)
                {
                genPKClass.print("//");
                }
            else
                {
                Field fld = clzPKClass.addField(sField, genPKClass.resolveJVMSignature(dtProperty));
                fld.setPublic();
                }
            genPKClass.print("public " + dtProperty + ' ' + sField + ';');
            if (sDefined != null)
                {
                genPKClass.print(" // defined in " + sDefined);
                }
            genPKClass.println();
            }
        
        // Generate default constructor.
            {
            genPKClass.println();
            genPKClass.println("// default constructor");
            Method method = clzPKClass.addMethod(
                ClassGenerator.CONSTRUCTOR_NAME, "()V");
            method.setPublic();
        
            genPKClass.println("public " + sPKClassName + "()");
        
            CodeAttribute code = genPKClass.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
        
            code.add(vL_this);
        
            // Call the super's default constructor
            code.add(new Aload(vL_this));
            MethodConstant cM_super = new MethodConstant(sPKClassSuper,
                ClassGenerator.CONSTRUCTOR_NAME, "()V");
            code.add(new Invokespecial(cM_super));
        
            //genPKClass.println("super();");
        
            code.add(new Return());
            genPKClass.EndSegment(method);
            }
        
        // Generate equals(Object) implementation
            {
            genPKClass.println();
            Method method = clzPKClass.addMethod("equals", "(Ljava/lang/Object;)Z");
            method.setPublic();
        
            genPKClass.println("public boolean equals(Object oOther)");
        
            CodeAttribute code = genPKClass.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
        
            Avar vL_oOther = new Avar("oOther");
            code.add(vL_oOther);
        
            Label lbl_notEqual = new Label();    
            
            code.add(new Aload(vL_oOther));
            code.add(new Instanceof(dtPKClass.getClassConstant()));
            code.add(new Ifeq(lbl_notEqual));
        
            genPKClass.println("if (!(oOther instanceof " + sPKClassName + "))");
            genPKClass.BeginScope();
                {
                genPKClass.println("return false;");
                }
            genPKClass.EndScope();
        
            Avar vL_pkOther = new Avar("pkOther");
            code.add(vL_pkOther);
            code.add(new Aload(vL_oOther));
            code.add(new Checkcast(dtPKClass.getClassConstant()));
            code.add(new Astore(vL_pkOther));
            
            genPKClass.print(sPKClassName + " pkOther = (" + sPKClassName + ") oOther;");
        
            String sPrefix = "return (";
        
            for (Iterator itr = colPKFields.iterator(); itr.hasNext();)
                {
                String sProperty = (String) itr.next();
                FieldConstant cF = (FieldConstant) mapCF.get(sProperty);
                if (cF == null)
                    {
                    continue;
                    }
                genPKClass.println();
                genPKClass.print(sPrefix);
        
                Property property   = cdPKComponent.getProperty(sProperty);
                DataType dtProperty = property.getDataType();
        
                code.add(new Aload(vL_this));
                code.add(new Getfield(cF));
                code.add(new Aload(vL_pkOther));
                code.add(new Getfield(cF));
        
                String sType = dtProperty.getTypeString();
                if (property.isSingle())
                    {
                    switch (sType.charAt(0))
                        {
                        case 'Z':
                        case 'B':
                        case 'C':
                        case 'S':
                        case 'I':
                            code.add(new If_icmpne(lbl_notEqual));
                            genPKClass.print(cF.getName() + " == pkOther." + cF.getName());
                            break;
        
                        case 'J':
                            code.add(new Lcmp());
                            code.add(new Ifeq(lbl_notEqual));
                            genPKClass.print(cF.getName() + " == pkOther." + cF.getName());
                            break;
        
                        case 'F':
                            code.add(new Fcmpl());
                            code.add(new Ifeq(lbl_notEqual));
                            genPKClass.print(cF.getName() + " == pkOther." + cF.getName());
                            break;
        
                        case 'D':
                            code.add(new Dcmpl());
                            code.add(new Ifeq(lbl_notEqual));
                            genPKClass.print(cF.getName() + " == pkOther." + cF.getName());
                            break;
        
                        default:
                            MethodConstant cM = genPKClass.resolveMethod(dtProperty,
                                DataType.BOOLEAN, "equals", new DataType[] {DataType.OBJECT});
                            if (cM instanceof InterfaceConstant)
                                {
                                code.add(new Invokeinterface((InterfaceConstant) cM));
                                }
                            else
                                {
                                code.add(new Invokevirtual(cM));
                                }
                            code.add(new Ifeq(lbl_notEqual));
                            genPKClass.print(cF.getName() + ".equals(pkOther." + cF.getName() + ')');
                            break;
                        }
                    }
                else
                    {
                    switch (sType.charAt(0))
                        {
                        case 'Z':
                        case 'B':
                        case 'C':
                        case 'S':
                        case 'I':
                        case 'J':
                        case 'F':
                        case 'D':
                            break;
                        default:
                            sType = "Ljava/lang/Object;";
                        }
                    MethodConstant cM = genPKClass.findMethod("java.util.Arrays",
                        "equals", "([" + sType + '[' + sType + ")Z");
                    code.add(new Invokestatic(cM));
                    code.add(new Ifeq(lbl_notEqual));
                    genPKClass.print("java.util.Arrays.equals(" +
                        cF.getName() + ", pkOther." + cF.getName() + ')');
                    }
                sPrefix = "        && ";
                }
        
            code.add(new Iconst(1));
            code.add(new Ireturn());
            code.add(lbl_notEqual);
            code.add(new Iconst(0));
            code.add(new Ireturn());
        
            genPKClass.println(");");
        
            genPKClass.EndSegment(method);
            }
        
        // Generate hashCode() implementation
            {
            genPKClass.println();
            Method method = clzPKClass.addMethod("hashCode", "()I");
            method.setPublic();
        
            genPKClass.println("public int hashCode()");
        
            CodeAttribute code = genPKClass.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
        
            Ivar vL_hash = new Ivar("oOther");
            code.add(vL_hash);
        
            code.add(new Aload(vL_this));
            code.add(new Iconst(0));
            code.add(new Istore(vL_hash));
            genPKClass.println("int hash = 0;");
        
            for (Iterator itr = colPKFields.iterator(); itr.hasNext();)
                {
                String sProperty = (String) itr.next();
                FieldConstant cF = (FieldConstant) mapCF.get(sProperty);
                if (cF == null)
                    {
                    continue;
                    }
                Property property   = cdPKComponent.getProperty(sProperty);
                DataType dtProperty = property.getDataType();
        
                code.add(new Aload(vL_this));
                code.add(new Getfield(cF));
                code.add(new Iload(vL_hash));
        
                String sType = dtProperty.getTypeString();
                if (property.isSingle())
                    {
                    if (dtProperty.isReference())
                        {
                        sType = "Ljava/lang/Object;";
                        }
                    }
                else
                    {
                    switch (sType.charAt(0))
                        {
                        case 'Z':
                        case 'B':
                        case 'C':
                        case 'S':
                        case 'I':
                        case 'J':
                        case 'F':
                        case 'D':
                            break;
                        default:
                            sType = "Ljava/lang/Object;";
                        }
                    sType = "[" + sType;
                    }
                MethodConstant cM = genPKClass.findMethod("com.tangosol.util.HashHelper",
                    "hash", "(" + sType + "I)I");
                code.add(new Invokestatic(cM));
                code.add(new Istore(vL_hash));
                genPKClass.println("hash = com.tangosol.util.HashHelper.hash(" +
                    cF.getName() + ", hash);");
                }
        
            code.add(new Iload(vL_hash));
            code.add(new Ireturn());
            genPKClass.println("return hash;");
        
            genPKClass.EndSegment(method);
            }
        
        genPKClass.EndSegment(null);
        
        genPKClass.finalizeClassGeneration(true);
        
        String sPKComponentJVMSig = dtPKComponent.getJVMSignature();
        String sPKClassJVMSig     = dtPKClass.getJVMSignature();
        
        // Generate component primary key to remote primary key converters.
            {
            genPKComponent.println();
            genPKComponent.println("// Component Primary Key to Remote Primary Key converters");
        
            generateArrayConverter(genPKComponent, dtPKComponent, dtPKClass);
        
            Method method = clzPKComponent.addMethod(METH_CONVERT,
                "(" + sPKComponentJVMSig + sPKClassJVMSig + ')' + sPKClassJVMSig);
            method.setStatic(true);
            method.setPublic();
        
            genPKComponent.println("static public " + sPKClassName + ' ' +
                METH_CONVERT + '(' + sPKComponentName + " pkOrg, " + sPKClassName + " type)");
        
            CodeAttribute code = genPKComponent.BeginSegment(method);
        
            Avar vL_pkOrg = new Avar("pkOrg");
            code.add(vL_pkOrg);
            code.add(new Avar("type"));
        
            Label lbl_componentNonNull = new Label();
            code.add(new Aload(vL_pkOrg));
            code.add(new Ifnonnull(lbl_componentNonNull));
        
            genPKComponent.println("if (pkOrg == null)");
            genPKComponent.BeginScope();
                {
                code.add(new Aconst());
                code.add(new Areturn());
                genPKComponent.println("return null;");
                }
            genPKComponent.EndScope();
            code.add(lbl_componentNonNull);
        
            Avar vL_pkNew = new Avar("pkNew");
            code.add(vL_pkNew);
        
            code.add(new New(dtPKClass.getClassConstant()));
            code.add(new Dup());
            MethodConstant cM = new MethodConstant(dtPKClass.getClassConstant(),
                new SignatureConstant(ClassGenerator.CONSTRUCTOR_NAME, "()V"));
            code.add(new Invokespecial(cM));
            code.add(new Astore(vL_pkNew));
        
            genPKComponent.println(sPKClassName + " pkNew = new " + sPKClassName + "();");
        
            for (Iterator itr = colPKFields.iterator(); itr.hasNext();)
                {
                String sProperty = (String) itr.next();
                FieldConstant cF = (FieldConstant) mapCF.get(sProperty);
                if (cF == null)
                    {
                    continue;
                    }
                Property property = cdPKComponent.getProperty(sProperty);
                Behavior bhvr     = property.getAccessor(property.isSingle() ?
                    Property.PA_GET_SINGLE : Property.PA_GET_ARRAY);
                _assert(bhvr != null);
                cM = genPKComponent.findMethod(bhvr, false);
        
                code.add(new Aload(vL_pkNew));
                code.add(new Aload(vL_pkOrg));
                code.add(new Invokevirtual(cM));
                code.add(new Putfield(cF));
        
                genPKComponent.println("pkNew." + cF.getName() + " = pkOrg." + cM.getName() + "();");
                }
        
            code.add(new Aload(vL_pkNew));
            code.add(new Areturn());
        
            genPKComponent.println("return pkNew;");
        
            genPKComponent.EndSegment(method);
            }
        
        // Generate remote primary key to component primary key converters.
            {
            genPKComponent.println();
            genPKComponent.println("// Remote Primary Key to Component Primary Key converters");
        
            generateArrayConverter(genPKComponent, dtPKClass, dtPKComponent);
        
            Method method = clzPKComponent.addMethod(METH_CONVERT,
                "(" + sPKClassJVMSig + sPKComponentJVMSig + ')' + sPKComponentJVMSig);
            method.setStatic(true);
            method.setPublic();
        
            genPKComponent.println("static public " + sPKComponentName + ' ' +
                METH_CONVERT + '(' + sPKClassName + " pkOrg, " + sPKComponentName + " type)");
        
            CodeAttribute code = genPKComponent.BeginSegment(method);
        
            Avar vL_pkOrg = new Avar("pkOrg");
            code.add(vL_pkOrg);
            code.add(new Avar("type"));
        
            Label lbl_remoteNonNull = new Label();
            code.add(new Aload(vL_pkOrg));
            code.add(new Ifnonnull(lbl_remoteNonNull));
        
            genPKComponent.println("if (pkOrg == null)");
            genPKComponent.BeginScope();
                {
                code.add(new Aconst());
                code.add(new Areturn());
                genPKComponent.println("return null;");
                }
            genPKComponent.EndScope();
            code.add(lbl_remoteNonNull);
        
            Avar vL_pkNew = new Avar("pkNew");
            code.add(vL_pkNew);
        
            code.add(new New(dtPKComponent.getClassConstant()));
            code.add(new Dup());
            MethodConstant cM = new MethodConstant(dtPKComponent.getClassConstant(),
                new SignatureConstant(ClassGenerator.CONSTRUCTOR_NAME, "()V"));
            code.add(new Invokespecial(cM));
            code.add(new Astore(vL_pkNew));
        
            genPKComponent.println(sPKComponentName + " pkNew = new " + sPKComponentName + "();");
        
            for (Iterator itr = colPKFields.iterator(); itr.hasNext();)
                {
                String sProperty = (String) itr.next();
                FieldConstant cF = (FieldConstant) mapCF.get(sProperty);
                if (cF == null)
                    {
                    continue;
                    }
                Property property = cdPKComponent.getProperty(sProperty);
                Behavior bhvr     = property.getAccessor(property.isSingle() ?
                                        Property.PA_SET_SINGLE : Property.PA_SET_ARRAY);
                _assert(bhvr != null);
                cM = genPKComponent.findMethod(bhvr, false);
        
                code.add(new Aload(vL_pkNew));
                code.add(new Aload(vL_pkOrg));
                code.add(new Getfield(cF));
                code.add(new Invokevirtual(cM));
        
                genPKComponent.println("pkNew." + cM.getName() + "(pkOrg." + cF.getName() + ");");
                }
        
            code.add(new Aload(vL_pkNew));
            code.add(new Areturn());
        
            genPKComponent.println("return pkNew;");
        
            genPKComponent.EndSegment(method);
            }

        }
    
    private void generateEJBRemote(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.Integrator;
        // import Component.Dev.Storage;
        // import com.tangosol.util.Base;
        // import java.util.Enumeration;
        
        Integrator integrator   = gen.getIntegrator();
        Component  cdIntegrator = gen.getCD();
        Storage    storage      = gen.getStorage();
        String     sRemoteClz   = getAutoGenClass(gen, cdIntegrator, PEER_REMOTE_INTERFACE);
        String     sRemoteName  = sRemoteClz.substring(sRemoteClz.lastIndexOf('.') + 1);
        DataType   dtRemote     = DataType.getClassType(sRemoteClz.replace('/', '.'));
        String     sRemoteSuper;
        Component  jcsRemoteSuper;
        
        // Find the closest super component that integrates something.
        // Assuming that the integration models are compatible,
        // the name of the super component and the integration signature
        // is all we need to generate the sink.
        
        // We currently assume that all subs of a remote super are also
        // remote, so this really doesn't have to be in a loop to find the
        // first super.  I left it this way if this assumption changes.
        
        String    sSuper = cdIntegrator.getSuperName();
        Component cdSuperIntegrator;
        
        while (true)
            {
            cdSuperIntegrator = storage.loadComponent(sSuper, true, null);
            Integrator superIntegrator = gen.findIntegrator(cdSuperIntegrator);
            if (superIntegrator != null)
                {
                if (superIntegrator.isRemote())
                    {
                    sRemoteSuper   = getAutoGenClass(gen, cdSuperIntegrator, PEER_REMOTE_INTERFACE);
                    jcsRemoteSuper = null;
                    break;
                    }
                }
        
            sSuper = cdSuperIntegrator.getSuperName();
            if (sSuper.length() == 0)
                {
                // if we reached this far, cdSuperIntegrator is the root component
                sRemoteSuper   = integrator.getIntegrationMiscProperty("remote", "javax.ejb.EJBObject");
                jcsRemoteSuper = storage.loadSignature(sRemoteSuper);
                if (jcsRemoteSuper == null)
                    {
                    throw new IllegalArgumentException("Cannot resolve EJB Object interface " + sRemoteSuper);
                    }
                break;
                }
            }
        
        // Get our immediate super
        cdSuperIntegrator = storage.loadComponent(cdIntegrator.getSuperName(), true, null);
        
        gen.println("/* Interface"                                      );
        gen.println("*      " + gen.formatType(dtRemote)                );
        gen.println("*"                                                 );
        gen.println("* automatically generated \"EJBObject\" interface" );
        gen.println("* for the remoted component:"                      );
        gen.println("*      " + cdIntegrator.getQualifiedName()         );
        gen.println("*/"                                                );
        gen.println();
        
        gen.println("package " + gen.formatClass(
            DataType.getComponentPackage(cdIntegrator), true) + ';');
        
        ClassFile clzRemote = new ClassFile(sRemoteClz, "java.lang.Object", true);
        
        gen.setClassFile(clzRemote);
        
        clzRemote.setPublic();
        clzRemote.setAbstract(true);
        clzRemote.addImplements(sRemoteSuper);
        
        gen.println();
        gen.println("public interface " + sRemoteName);
        gen.println("        extends " + gen.formatClass(sRemoteSuper));
        
        gen.BeginSegment(null);
        
        for (Enumeration enum = cdIntegrator.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
            if (bhvr != null
                && getMethodType(gen, bhvr) == METHOD_TYPE_REMOTE)
                {
                String[] asRemoteSignatures = getRemoteSignatures(gen, bhvr);
                if (jcsRemoteSuper == null)
                    {
                    if (bhvr.isFromSuper()
                        && cdSuperIntegrator.getBehavior(bhvr.getSignature()).isRemote())
                        {
                        // Our super EJB Home interface already declares this
                        continue;
                        }
                    }
                else
                    {
                    if (jcsRemoteSuper.getBehavior(asRemoteSignatures[REMOTE_INTERFACE_SIGNATURE]) != null)
                        {
                        // Our super EJB Home interface already declares this
                        continue;
                        }
                    }
                String sDescr = bhvr.getDescription();
                if (sDescr.length() > 0)
                    {
                    gen.println("/**");
                    gen.println("* " + Base.breakLines(sDescr, 80, gen.getIndent() + "* ", false));
                    gen.println("*/");
                    }
                Method method = clzRemote.addMethod(asRemoteSignatures[REMOTE_INTERFACE_NAME],
                    asRemoteSignatures[REMOTE_INTERFACE_JVM_SIGNATURE]);
                method.setPublic();
                method.setAbstract(true);
                    
                gen.print("public ");
                gen.formatMethod(asRemoteSignatures[REMOTE_INTERFACE_NAME],
                    asRemoteSignatures[REMOTE_INTERFACE_JVM_SIGNATURE],
                    bhvr);
                gen.addExceptionsToMethod(method, addRemoteExceptions(gen, bhvr));
                gen.println(";");
                }
            }
        
        gen.EndSegment(null);
        
        gen.finalizeClassGeneration(true);
        }
    
    private void generateEJBStub(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.Integrator;
        // import Component.Dev.Storage;
        // import java.util.Enumeration;
        
        Integrator integrator       = gen.getIntegrator();
        Component cdIntegrator      = gen.getCD();
        DataType  dtIntegrator      = DataType.getComponentType(cdIntegrator.getQualifiedName());
        String    sIntegratorName   = cdIntegrator.getName();
        Storage   storage           = gen.getStorage();
        boolean   fAbstract         = cdIntegrator.isAbstract();
        DataType  dtSinkInterface   = integrator.getSinkType();
        
        String    sSinkEJB          = getAutoGenClass(gen, cdIntegrator, PEER_SINK_EJB);
        String    sEJBHome          = getAutoGenClass(gen, cdIntegrator, PEER_HOME_INTERFACE);
        String    sEJBRemote        = getAutoGenClass(gen, cdIntegrator, PEER_REMOTE_INTERFACE);
        
        String    sSinkEJBName      = sSinkEJB.substring(sSinkEJB.lastIndexOf('.') + 1);
        String    sEJBHomeName      = sEJBHome.substring(sEJBHome.lastIndexOf('.') + 1);
        String    sEJBRemoteName    = sEJBRemote.substring(sEJBRemote.lastIndexOf('.') + 1);
        
        
        DataType  dtSinkEJB         = DataType.getClassType(sSinkEJB.replace('/', '.'));
        DataType  dtEJBHome         = DataType.getClassType(sEJBHome.replace('/', '.'));
        DataType  dtEJBRemote       = DataType.getClassType(sEJBRemote.replace('/', '.'));
        
        ClassConstant ccEJBHome     = dtEJBHome.getClassConstant();
        ClassConstant ccEJBRemote   = dtEJBRemote.getClassConstant();
        boolean   fSession          = isSessionEJB(gen);
        String    sSinkEJBSuper     = CLASS_ABSTRACT_REMOTE_SINK;
        
        // Get the jcs of the super class of the home interface
        String sHomeBase = integrator.getIntegrationMiscProperty("home", "javax.ejb.EJBHome");
        Component jcsHomeBase = storage.loadSignature(sHomeBase);
        if (jcsHomeBase == null)
            {
            throw new IllegalArgumentException("Cannot resolve EJB Home interface " + sHomeBase);
            }
        
        boolean fNeedNewClientInstance = isNeedNewClientInstance(gen, cdIntegrator);
        
        gen.println("/* Class"                                                );
        gen.println("*      " + gen.formatType(dtSinkEJB)                     );
        gen.println("*"                                                       );
        gen.println("* automatically generated \"Sink\" which"                );
        gen.println("* represents a footprint of the class"                   );
        gen.println("*      " + gen.formatType(integrator.getIntegrateeType()));
        gen.println("* when used as a component callback by "                 );
        gen.println("*      " + cdIntegrator.getQualifiedName()               );
        gen.println("*/"                                                      );
        gen.println();
        
        gen.println("package " + gen.formatClass(
            DataType.getComponentPackage(cdIntegrator), true) + ';');
        
        ClassFile clzSinkEJB = new ClassFile(dtSinkEJB.getClassName(), sSinkEJBSuper, false);
        gen.setClassFile(clzSinkEJB);
        
        clzSinkEJB.setPublic();
        
        gen.println();
        gen.println("public class " + sSinkEJBName);
        gen.println("       extends " + gen.formatClass(sSinkEJBSuper));
        
        String sSinkInterface = dtSinkInterface.getClassName();
        clzSinkEJB.addImplements(sSinkInterface);
        gen.print("       implements " + gen.formatClass(sSinkInterface));
        
        if (fNeedNewClientInstance)
            {
            clzSinkEJB.addImplements(IFACE_CONVERTER);
            gen.print(", " + IFACE_CONVERTER);
            }
        gen.println();
        
        gen.BeginSegment(null);
        
        FieldConstant cR_peer = null;
        if (fNeedNewClientInstance)
            {
            Field fldPeer = clzSinkEJB.addField(FLD_PEER, dtIntegrator.getJVMSignature());
            fldPeer.setPrivate();
            cR_peer = clzSinkEJB.getFieldConstant(FLD_PEER);
        
            gen.println("private " + sIntegratorName + "           " + FLD_PEER + ';');
            }
        
        Field fldHome = clzSinkEJB.addField(FLD_HOME, dtEJBHome.getJVMSignature());
        fldHome.setPrivate();
        FieldConstant cR_home = clzSinkEJB.getFieldConstant(FLD_HOME);
        
        gen.println("private " + sEJBHomeName + "   " + FLD_HOME + ';');
        
        Field fldRemote = clzSinkEJB.addField(FLD_REMOTE, dtEJBRemote.getJVMSignature());
        fldRemote.setPrivate();
        FieldConstant cR_remote = clzSinkEJB.getFieldConstant(FLD_REMOTE);
        
        gen.println("private " + sEJBRemoteName + ' ' + FLD_REMOTE + ';');
        
        gen.println();
        
        // Generate default constructor.
            {
            gen.println();
            gen.println("// the peer constructor");
            Method method;
            if (fNeedNewClientInstance)
                {
                method = clzSinkEJB.addMethod(
                    gen.CONSTRUCTOR_NAME, "(" + dtIntegrator.getJVMSignature() + ")V");
        
                gen.println(sSinkEJBName + "(" + sIntegratorName + " peer)");
                }
            else
                {
                method = clzSinkEJB.addMethod(
                    gen.CONSTRUCTOR_NAME, "()V");
        
                gen.println(sSinkEJBName + "()");
                }
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
        
            Avar vL_peer;
            if (fNeedNewClientInstance)
                {
                vL_peer = new Avar("peer", dtIntegrator.getJVMSignature());
                code.add(vL_peer);
                }
            else
                {
                vL_peer = null;
                }
        
            // Call the super's default constructor
            code.add(new Aload(vL_this));
            MethodConstant cM_super = new MethodConstant(sSinkEJBSuper,
                ClassGenerator.CONSTRUCTOR_NAME, "()V");
            code.add(new Invokespecial(cM_super));
        
            gen.println("super();");
        
            if (fNeedNewClientInstance)
                {
                code.add(new Aload(vL_this));
                code.add(new Aload(vL_peer));
                code.add(new Putfield(cR_peer));
        
                gen.println(FLD_PEER + " = peer;");
                }
        
            code.add(new Return());
            gen.EndSegment(method);
            }
        
        // Dispatch the integration and remote methods --
        
        gen.println();
        gen.println("// methods integrated and remoted");
        
        boolean  fNeedCreateHome        = false; // flags if methods in the home interface are defined
        Behavior bhvrDefaultCreate      = null;  // this will be the null parameter create if found
        boolean  fNeedCreateRemote      = false; // flags if methods in the remote interface are defined
        
        for (Enumeration enum = cdIntegrator.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
            if (bhvr != null)
                {
                String sSignature    = bhvr.getSignature();
                String sMappedMethod = integrator.getMappedMethod(sSignature);
        
                if (sMappedMethod == null)
                    {
                    // check if it is a routed property accessor
                    String sField = bhvr.getPropertyName();
                    if (sField != null
                        && integrator.getRoutedProperties().contains(sField))
                        {
                        sMappedMethod = sSignature.substring(0, sSignature.indexOf('('));
                        }
                    }
                else
                    {
                    sMappedMethod = sMappedMethod.substring(0, sMappedMethod.indexOf('('));
                    }
        
                int iMethodType = getMethodType(gen, bhvr);
                if (iMethodType != METHOD_TYPE_NOT_REMOTE
                    || sMappedMethod != null)
                    {
                    if (sMappedMethod == null)
                        {
                        sMappedMethod = bhvr.getName();
                        }
        
                    Method method = gen.generateMethodHeader(bhvr, sMappedMethod,
                        Behavior.ACCESS_PUBLIC, bhvr.isFinal(), false, null);
                    CodeAttribute code = gen.BeginSegment(method);
                    Avar vL_this = new Avar("this");
                    code.add(vL_this);
                    OpDeclare[] aParameters = gen.addBehaviorParameters(bhvr);
                    switch (iMethodType)
                        {
                        case METHOD_TYPE_REMOTE:
                            fNeedCreateRemote = true;
                            break;
                        case METHOD_TYPE_CREATE:
                            if (bhvr.getParameterCount() == 0)
                                {
                                bhvrDefaultCreate = bhvr;
                                }
                        case METHOD_TYPE_FIND_SINGLE:
                        case METHOD_TYPE_FIND_ENUMERATION:
                        case METHOD_TYPE_FIND_COLLECTION:
                            fNeedCreateHome = true;
                        case METHOD_TYPE_REMOVE:
                            break;
                        default:
                            gen.addThrow("java.lang.IllegalStateException",
                                "Unexpected call to non-remote method \\\"" + sMappedMethod + "\\\" in EJB sink", null);
                            gen.EndSegment(method);
                            continue;
                        }
                    generateEJBStubRouter(gen, bhvr, iMethodType, method, vL_this, aParameters);
                    gen.EndSegment(method);
                    }
                }
            }
        
        // Generate the get_RemoteObject() method
        // (declared in com.tangosol.run.component.RemoteSink)
            {
            gen.println();
            gen.println("// Retrieves the remote object for this sink");
        
            Method method = clzSinkEJB.addMethod(METH_GET_REMOTEOBJECT, "()Ljava.lang.Object;");
            method.setPublic();
        
            gen.println("public Object " + METH_GET_REMOTEOBJECT + "()");
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
        
            code.add(new Aload(vL_this));
            code.add(new Getfield(cR_remote));
        
            code.add(new Dup());
            Label lbl_remoteNull = new Label();
            code.add(new Ifnull(lbl_remoteNull));
        
            gen.println("if (" + FLD_REMOTE + " != null)");
            gen.BeginScope();
                {
                code.add(new Areturn());
        
                gen.println("return " + FLD_REMOTE + ';');
                }
            gen.EndScope();
        
            code.add(lbl_remoteNull);    
            code.add(new Pop()); // get rid of saved object
        
            // Force the remote interface to be returned if we
            // have a default create method
            if (bhvrDefaultCreate != null
                || (!fNeedCreateHome && fSession))
                {
                code.add(new Aload(vL_this));
                code.add(new Getfield(cR_home));
        
                Label lbl_homeNull = new Label();
                code.add(new Ifnull(lbl_homeNull));
        
                gen.println("if (" + FLD_HOME + " != null)");
                gen.BeginScope();
                    {
                    code.add(new Aload(vL_this));
                    MethodConstant cM = new MethodConstant(dtSinkEJB.getClassConstant(),
                        new SignatureConstant(METH_CREATEREMOTE, "()" + dtEJBRemote.getJVMSignature()));
                    code.add(new Invokespecial(cM));
                    code.add(new Areturn());
                    gen.println("return " + METH_CREATEREMOTE + "();");
                    }
                gen.EndScope();
        
                code.add(lbl_homeNull);
                code.add(new Aconst());
                code.add(new Areturn());
                gen.println("return null;");
                fNeedCreateRemote = true;
                }
            else
                {
                code.add(new Aload(vL_this));
                code.add(new Getfield(cR_home));
                code.add(new Areturn());
        
                gen.println("return " + FLD_HOME + ';');
                }
            
            gen.EndSegment(method);
            }
        
        // Generate the set_RemoteObject() method
        // (declared in com.tangosol.run.component.RemoteSink)
            {
            gen.println();
            gen.println("// Establishes the remote object for this sink");
        
            Method method = clzSinkEJB.addMethod(METH_SET_REMOTEOBJECT, "(Ljava.lang.Object;)V");
            method.setPublic();
        
            gen.println("public void " + METH_SET_REMOTEOBJECT + "(Object object)");
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_this   = new Avar("this");
            Avar vL_object = new Avar("object");
        
            code.add(vL_this);
            code.add(vL_object);
        
            // Check if the passed object is the EJB home object    
        
            code.add(new Aload(vL_object));
            code.add(new Instanceof(ccEJBHome));
            Label lbl_notEJBHome = new Label();
            code.add(new Ifeq(lbl_notEJBHome));
        
            gen.println("if (object instanceof " + sEJBHomeName + ')');
            gen.BeginScope();
                {
                code.add(new Aload(vL_this));
                code.add(new Aload(vL_object));
                //code.add(new Checkcast(ccEJBHome)); // optimized out
                code.add(new Putfield(cR_home));
        
                gen.println(FLD_HOME + "   = (" + sEJBHomeName + ") object;");
                
                code.add(new Aload(vL_this));
                code.add(new Aconst());
                code.add(new Putfield(cR_remote));
        
                gen.println(FLD_REMOTE + " = null;");
        
                code.add(new Return());
        
                gen.println("return;");
                }
            gen.EndScope();
            
            code.add(lbl_notEJBHome);    
        
            // Check if the passed object is the EJB object object    
        
            code.add(new Aload(vL_object));
            code.add(new Instanceof(ccEJBRemote));
            Label lbl_notEJBObject = new Label();
            code.add(new Ifeq(lbl_notEJBObject));
        
            gen.println("if (object instanceof " + sEJBRemoteName + ')');
            gen.BeginScope();
                {
                code.add(new Aload(vL_this));
                code.add(new Aconst());
                code.add(new Putfield(cR_home));
        
                gen.println(FLD_HOME + "   = null;");
        
                code.add(new Aload(vL_this));
                code.add(new Aload(vL_object));
                //code.add(new Checkcast(ccEJBObject)); // optimized out
                code.add(new Putfield(cR_remote));
        
                gen.println(FLD_REMOTE + " = (" + sEJBRemoteName + ") object;");
                
                code.add(new Return());
        
                gen.println("return;");
                }
            gen.EndScope();
            
            code.add(lbl_notEJBObject);    
        
            // Check if the passed object is the null object
        
            code.add(new Aload(vL_object));
            Label lbl_notNull = new Label();
            code.add(new Ifnonnull(lbl_notNull));
        
            gen.println("if (object == null)");
            gen.BeginScope();
                {
                code.add(new Aload(vL_this));
                code.add(new Aconst());
                code.add(new Putfield(cR_home));
        
                gen.println(FLD_HOME + "   = null;");
        
                code.add(new Aload(vL_this));
                code.add(new Aconst());
                code.add(new Putfield(cR_remote));
        
                gen.println(FLD_REMOTE + " = null;");
        
                code.add(new Return());
        
                gen.println("return;");
                }
            gen.EndScope();
            
            code.add(lbl_notNull);    
            
            gen.addThrow("java.lang.IllegalArgumentException",
                "Remote object data type is not valid", null);
            
            gen.EndSegment(method);
            }
        
        // Check if we need to generate a create home interface
        
        if (fNeedCreateHome)
            {
            gen.println();
            gen.println("// Retrieves the home interface from the object interface for this sink");
        
            Method method = clzSinkEJB.addMethod(METH_CREATEHOME,
                "()" + dtEJBHome.getJVMSignature());
            method.setPrivate();
        
            gen.println("private " + sEJBHomeName + ' ' + METH_CREATEHOME + "()");
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
            
            code.add(new Aload(vL_this));
            code.add(new Getfield(cR_remote));
            
            Label lbl_objectNotNull = new Label();
            code.add(new Ifnonnull(lbl_objectNotNull));
        
            gen.println("if (" + FLD_REMOTE + " == null)");
            gen.BeginScope();
                {
                gen.addThrow("java.lang.IllegalStateException",
                    "Remote EJB object has not been established", null);
                }
            gen.EndScope();
            
            code.add(lbl_objectNotNull);    
        
            Try   lbl_try      = new Try();
            Label lbl_continue = new Label();
        
            code.add(lbl_try);
        
            gen.println("try");
        
            gen.BeginScope();
                {
                InterfaceConstant cI = new InterfaceConstant(dtEJBHome.getClassConstant(),
                    new SignatureConstant("getEJBHome", "()Ljavax.ejb.EJBHome;"));
        
                code.add(new Aload(vL_this));
                code.add(new Aload(vL_this));
                code.add(new Getfield(cR_remote));
                code.add(new Invokeinterface(cI));
                code.add(new Checkcast(dtEJBHome.getClassConstant()));
                code.add(new Putfield(cR_home));
                
                gen.println(FLD_HOME + " = (" + sEJBHomeName + ") " + FLD_REMOTE + '.' + cI.getName() + "();");
        
                code.add(new Goto(lbl_continue));
                }
            gen.EndScope();
        
            // TODO:  If this is an integrated component and the integrated component
            // declares other exceptions, then this might be out of sync.
            gen.addCatchAndThrowWrapper(lbl_try, REMOTE_EXCEPTION);
        
            code.add(lbl_continue);
            
            code.add(new Aload(vL_this));
            code.add(new Getfield(cR_home));
            code.add(new Areturn());
        
            gen.println("return " + FLD_HOME + ';');
            gen.EndSegment(method);
            }
        
        // Check if we need to generate a create remote interface
        
        if (fNeedCreateRemote)
            {
            gen.println();
            gen.println("// Retrieves the remote interface from the home interface for this sink");
        
            Method method = clzSinkEJB.addMethod(METH_CREATEREMOTE,
                "()" + dtEJBRemote.getJVMSignature());
            method.setPrivate();
        
            gen.println("private " + sEJBRemoteName + ' ' + METH_CREATEREMOTE + "()");
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
            
            code.add(new Aload(vL_this));
            code.add(new Getfield(cR_home));
            
            Label lbl_homeNotNull = new Label();
            code.add(new Ifnonnull(lbl_homeNotNull));
        
            gen.println("if (" + FLD_HOME + " == null)");
            gen.BeginScope();
                {
                gen.addThrow("java.lang.IllegalStateException",
                    "Remote EJB object has not been established", null);
                }
            gen.EndScope();
            
            code.add(lbl_homeNotNull);    
        
            if (bhvrDefaultCreate != null
                || (!fNeedCreateHome && fSession))
                {
                String   sEJBSignature;
                String   sJVMSignature;
                String[] asRemoteSignatures;
                String[] asExceptions;
                if (bhvrDefaultCreate != null)
                    {
                    asRemoteSignatures = getRemoteSignatures(gen, bhvrDefaultCreate);
                    asExceptions       = addRemoteExceptions(gen, bhvrDefaultCreate);
                    }
                else
                    {
                    asRemoteSignatures = new String[] {"create", "create()", "()" + dtEJBRemote.getJVMSignature()};
                    asExceptions       = new String[] {CREATE_EXCEPTION, REMOTE_EXCEPTION};
                    }
                
                Try   lbl_try      = new Try();
                Label lbl_continue = new Label();
        
                code.add(lbl_try);
        
                gen.println("try");
        
                gen.BeginScope();
                    {
                    code.add(new Aload(vL_this));
                    gen.print(cR_remote.getName() + " = ");
                    boolean fNeedCast = false;
                    DataType dtReturn = dtEJBRemote;
        
                    // Check if we are sub-classing another home-interface
                    Behavior bhvrHomeBase = jcsHomeBase.getBehavior(
                        asRemoteSignatures[REMOTE_INTERFACE_SIGNATURE]);
                    if (bhvrHomeBase != null)
                        {
                        DataType dt = bhvrHomeBase.getReturnValue().getDataType();
                        if (dt != dtReturn)
                            {
                            gen.print("(" + sEJBRemoteName + ") ");
                            fNeedCast = true;
                            dtReturn  = dt;
                            }
                        }
        
                    InterfaceConstant cI = new InterfaceConstant(dtEJBHome.getClassConstant(),
                        new SignatureConstant(
                            asRemoteSignatures[REMOTE_INTERFACE_NAME],
                            asRemoteSignatures[REMOTE_INTERFACE_JVM_SIGNATURE]));
        
                    code.add(new Aload(vL_this));
                    code.add(new Getfield(cR_home));
                    code.add(new Invokeinterface(cI));
                    if (fNeedCast)
                        {
                        code.add(new Checkcast(ccEJBRemote));
                        }
                    code.add(new Putfield(cR_remote));
                
                    gen.println(cR_home.getName() + '.' + cI.getName() + "();");
        
                    code.add(new Goto(lbl_continue));
                    }
                gen.EndScope();
        
                // TODO:  If this is an integrated component and the integrated component
                // declares other exceptions, then this might be out of sync.
                gen.addCatchesAndThrowWrappers(lbl_try, asExceptions);
        
                code.add(lbl_continue);
            
                code.add(new Aload(vL_this));
                code.add(new Getfield(cR_remote));
                code.add(new Areturn());
        
                gen.println("return " + FLD_REMOTE + ';');
                }
            else
                {
                gen.addThrow("java.lang.IllegalStateException",
                    "Remote EJB object has not been created", null);
                }
        
            gen.EndSegment(method);
            }
        
        // Check if we need to create "convert" which is used
        // by the find methods that return collections of entity beans
        
        if (fNeedNewClientInstance)
            {
            gen.println();
            gen.println("// Create a new client instance of a remote object, this is used");
            gen.println("// by the find methods that return collections of entity beans");
        
            Method method = clzSinkEJB.addMethod(METH_CONVERTER_CONVERT,
                "(Ljava.lang.Object;)Ljava.lang.Object;");
            method.setPublic();
        
            gen.println("public Object " + METH_CONVERTER_CONVERT + "(Object remoteObject)");
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_this         = new Avar("this");
            Avar vL_remoteObject = new Avar("remoteObject", "Ljava/lang/Object;");
        
            code.add(vL_this);
            code.add(vL_remoteObject);
        
            code.add(new Aload(vL_this));
            code.add(new Getfield(cR_peer));    
            code.add(new Aload(vL_remoteObject));
            code.add(new Checkcast(ccEJBRemote));
        
            MethodConstant cM = new MethodConstant(dtIntegrator.getClassConstant(),
                new SignatureConstant(METH_CONVERT_VIRTUAL,
                    '(' + dtEJBRemote.getJVMSignature() + ')' + dtIntegrator.getJVMSignature()));
            code.add(new Invokevirtual(cM));
            code.add(new Areturn());
        
            gen.println("return " + cR_peer.getName() + '.' + METH_CONVERT_VIRTUAL
                + "((" + sEJBRemoteName + ") remoteObject);");
        
            gen.EndSegment(method);
            }
        
        gen.EndSegment(null);
        
        gen.finalizeClassGeneration(true);
        }
    
    /**
    * Generates router of the specified behavior from Sink$Ejb into the remote
    * target (home or remote).
    */
    private void generateEJBStubRouter(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr, int iMethodType, com.tangosol.dev.assembler.Method method, com.tangosol.dev.assembler.Avar vL_this, com.tangosol.dev.assembler.OpDeclare[] aParameters)
            throws com.tangosol.dev.component.ComponentException
        {
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.dev.assembler.FieldConstant;
        // import com.tangosol.dev.assembler.SignatureConstant;
        
        ClassFile     clzSinkEJB = gen.getClassFile();
        CodeAttribute code       = gen.getCode();
        DataType      dtReturn   = bhvr.getReturnValue().getDataType();
        FieldConstant cR_remote  = clzSinkEJB.getFieldConstant(FLD_REMOTE);
        
        Component cdIntegrator   = gen.getCD();
        String    sSinkEJBName   = getAutoGenClass(gen, cdIntegrator, PEER_SINK_EJB);
        String    sEJBHomeName   = getAutoGenClass(gen, cdIntegrator, PEER_HOME_INTERFACE);
        String    sEJBRemoteName = getAutoGenClass(gen, cdIntegrator, PEER_REMOTE_INTERFACE);
        DataType  dtSinkEJB      = DataType.getClassType(sSinkEJBName.replace('/', '.'));
        DataType  dtEJBHome      = DataType.getClassType(sEJBHomeName.replace('/', '.'));
        DataType  dtEJBRemote    = DataType.getClassType(sEJBRemoteName.replace('/', '.'));
        
        String        sObjectClz;
        FieldConstant cR_object;
        String        sMethCreate;
        String        sTemp;
        
        if (iMethodType != METHOD_TYPE_REMOTE
            && iMethodType != METHOD_TYPE_REMOVE)
            {
            sObjectClz  = dtEJBHome.getClassName();
            cR_object   = clzSinkEJB.getFieldConstant(FLD_HOME);
            sMethCreate = METH_CREATEHOME;
            sTemp       = "home";
            }
        else
            {
            sObjectClz  = dtEJBRemote.getClassName();
            cR_object   = cR_remote;
            sMethCreate = METH_CREATEREMOTE;
            sTemp       = "remote";
            }
        
        String[] asBhvrExceptions   = bhvr.getExceptionNames();
        for (int i = 0; i < asBhvrExceptions.length; ++i)
            {
            if (bhvr.getException(asBhvrExceptions[i]) == null)
                {
                asBhvrExceptions[i] = null;
                }
            }
        
        String[] asRemoteExceptions = addRemoteExceptions(gen, bhvr);
        int      iBhvrExceptions    = asBhvrExceptions.length;
        int      cRemoteExceptions  = asRemoteExceptions.length;
        
        boolean fNeedTry = false;
        for (int i = 0; i < cRemoteExceptions; ++i)
            {
            String sRemoteException = asRemoteExceptions[i];
            if (gen.isClassesSuperOfClass(asBhvrExceptions, sRemoteException))
                {
                asRemoteExceptions[i] = null;
                }
            else
                {
                fNeedTry = true;
                }
            }
        
        code.add(new Aload(vL_this));
        code.add(new Getfield(cR_object));
        
        // The "temp" local variable has been optimized out using the operand stack
        gen.println(gen.formatClass(sObjectClz) + ' ' + sTemp + " = " + cR_object.getName() + ';');
        
        code.add(new Dup());
        Label lbl_objectNotNull = new Label();
        code.add(new Ifnonnull(lbl_objectNotNull));
        
        gen.println("if (" + sTemp + " == null)");
        gen.BeginScope();
            {
            code.add(new Pop()); // get rid of saved peer
            if (iMethodType == METHOD_TYPE_REMOVE)
                {
                gen.addThrow("java.lang.IllegalStateException",
                    "Remote EJB object has not been created", null);
                }
            else
                {
                code.add(new Aload(vL_this));
                MethodConstant cM = new MethodConstant(dtSinkEJB.getClassConstant(),
                    new SignatureConstant(sMethCreate, "()L" + sObjectClz + ';'));
                code.add(new Invokespecial(cM));
                // object is now top operand
        
                gen.println(sTemp + " = " + sMethCreate + "();");
                }
            }
        gen.EndScope();
        code.add(lbl_objectNotNull);
        
        Try lbl_try;
        if (fNeedTry)
            {
            lbl_try = new Try();
            code.add(lbl_try);
        
            gen.println("try");
            gen.BeginScope();
            }
        else
            {
            lbl_try = null;
            }
        
        String[]   asRemoteSignatures = getRemoteSignatures(gen, bhvr);
        DataType[] adtRemoteSignature = DataType.parseSignature(asRemoteSignatures[REMOTE_INTERFACE_JVM_SIGNATURE]);
        DataType   dtRemoteReturn     = adtRemoteSignature[0];
        
        switch (iMethodType)
            {
            case METHOD_TYPE_REMOTE:
                {
                if (dtReturn != DataType.VOID)
                    {
                    if (dtReturn == dtRemoteReturn)
                        {
                        gen.print("return ");
                        }
                    else
                        {
                        // We must be returning a remoted component, save the
                        // returned remote object for later use.
                        gen.print(gen.formatType(dtRemoteReturn) + " __return = ");
                        }
                    }
                break;
                }
            case METHOD_TYPE_CREATE:
            case METHOD_TYPE_FIND_SINGLE:
                {
                gen.print(cR_remote.getName() + " = ");
                break;
                }
            case METHOD_TYPE_FIND_ENUMERATION:
            case METHOD_TYPE_FIND_COLLECTION:
                {
                gen.print("return " + CLASS_COLLECTION_HELPER + '.' + METH_CONVERTER_CONVERT + '(');
                break;
                }
            }
        
        InterfaceConstant cI = new InterfaceConstant(sObjectClz,
            asRemoteSignatures[REMOTE_INTERFACE_NAME],
            asRemoteSignatures[REMOTE_INTERFACE_JVM_SIGNATURE]);
        
        gen.print(sTemp + '.' + cI.getName() + '(');
        
        int cntParams = aParameters.length;
        _assert(cntParams == adtRemoteSignature.length - 1); // less the return type
        _assert(cntParams == bhvr.getParameterCount());
        for (int i = 0;
             i < cntParams;
             ++i)
            {
            if (i > 0)
                {
                gen.print(", ");
                }
            DataType dtParameter       = bhvr.getParameter(i).getDataType();
            DataType dtRemoteSignature = adtRemoteSignature[i + 1];
            String   sParameterName    = aParameters[i].getVariableName();
            code.add(aParameters[i].getLoadOp());
            if (dtParameter == dtRemoteSignature)
                {
                gen.print(sParameterName);
                }
            else
                {
                addConvertCall(gen, dtParameter, dtParameter, sParameterName, dtRemoteSignature);
                }
            }
        
        code.add(new Invokeinterface(cI));
        gen.print(")");
        
        final String SIG_ENUMERATION = "Ljava/util/Enumeration;"   ;
        final String SIG_COLLECTION  = "Ljava/util/Collection;"    ;
        final String SIG_CONVERTER   = 'L' + IFACE_CONVERTER + ';' ;
        
        // Check if this "creates" the remote object from a
        // home interface method
        switch (iMethodType)
            {
            case METHOD_TYPE_REMOTE:
                {
                gen.println(";");
        
                if (dtReturn != dtRemoteReturn)
                    {
                    gen.print("return ");
                    addConvertCall(gen, dtReturn, dtRemoteReturn, "__return", dtReturn);
                    gen.println(";");
                    }
                break;
                }
            case METHOD_TYPE_CREATE:
            case METHOD_TYPE_FIND_SINGLE:
                {
                gen.println(";");
        
                code.add(new Dup());
                code.add(new Aload(vL_this));
                code.add(new Swap());
                code.add(new Putfield(cR_remote));
        
                // Return the primary key if this is a create or a find single
                // of an Entity Bean
                if (dtReturn != DataType.VOID)
                    {
                    //gen.print("return ");
                    //
                    //cI = (InterfaceConstant) gen.findMethod("javax.ejb.EJBObject",
                    //    "getPrimaryKey", "()Ljava/lang/Object;");
                    //code.add(new Invokeinterface(cI));
                    //if (dtReturn != DataType.OBJECT)
                    //    {
                    //    code.add(new Checkcast(new ClassConstant(dtReturn.getClassName())));
                    //
                    //    gen.print("(" + gen.formatClass(gen.formatType(dtReturn)) + ") ");
                    //    }
                    //gen.println(cR_remote.getName() + '.' + cI.getName() + "();");
        
                    // Let's just try returning null at the client for now...
                    code.add(new Aconst());
                    gen.println("return null;");
                    }
        
                break;
                }
            case METHOD_TYPE_FIND_ENUMERATION:
                {
                code.add(new Aload(vL_this));
                MethodConstant cM = gen.findMethod(CLASS_COLLECTION_HELPER,
                    METH_CONVERTER_CONVERT,
                    '(' + SIG_ENUMERATION + SIG_CONVERTER + ')' + SIG_ENUMERATION);
                code.add(new Invokestatic(cM));
        
                gen.println(", this);");
                break;
                }
            case METHOD_TYPE_FIND_COLLECTION:
                {
                code.add(new Aload(vL_this));
                MethodConstant cM = gen.findMethod(CLASS_COLLECTION_HELPER,
                    METH_CONVERTER_CONVERT,
                   '(' + SIG_COLLECTION + SIG_CONVERTER + ')' + SIG_COLLECTION);
                code.add(new Invokestatic(cM));
        
                gen.println(", this);");
                break;
                }
            case METHOD_TYPE_REMOVE:
                {
                gen.println(";");
                }
            }
        
        code.add(gen.getReturnOp(dtReturn));
        
        if (!fNeedTry)
            {
            return;
            }
        
        if (dtReturn == DataType.VOID)
            {
            gen.println("return;");
            }
        
        gen.EndScope();
        
        // We have to deal with any declared expections that derive
        // from the remote excpetions by catching them and rethrowing them
        // before we catch the remote exception itself
        
        Label[][] asaslbl = new Label[cRemoteExceptions][];
        
        // First generate the catches
        
        for (int i = 0; i < cRemoteExceptions; ++i)
            {
            String sRemoteException = asRemoteExceptions[i];
            if (sRemoteException != null)
                {
                Label[] aslbl = new Label[iBhvrExceptions + 1];
                for (int iBhvrException = 0;
                     iBhvrException < iBhvrExceptions;
                     ++iBhvrException)
                    {
                    String sBhvrException = asBhvrExceptions[iBhvrException];
                    if (sBhvrException != null)
                        {
                        if (gen.isClassSuperOfClass(sRemoteException, sBhvrException))
                            {
                            Label lbl = new Label();
                            code.add(new Catch(lbl_try, new ClassConstant(sBhvrException), lbl));
                            aslbl[iBhvrException] = lbl;
                            }
                        }
                    }
                Label lbl = new Label();
                code.add(new Catch(lbl_try, new ClassConstant(sRemoteException), lbl));
                aslbl[iBhvrExceptions] = lbl;
                asaslbl[i] = aslbl;
                }
            }
        
        // Then generate the catch code itself
        
        for (int i = 0; i < cRemoteExceptions; ++i)
            {
            Label[] aslbl = asaslbl[i];
            if (aslbl != null)
                {
                for (int iBhvrException = 0;
                     iBhvrException < iBhvrExceptions;
                     ++iBhvrException)
                    {
                    Label lbl = aslbl[iBhvrException];
                    if (lbl != null)
                        {
                        code.add(lbl);
                        gen.println("catch (" + asBhvrExceptions[iBhvrException] + " e)");
                        gen.BeginScope();
                            {
                            gen.println("// rethrow the exception out of the stub");
                            code.add(new Athrow());
                            gen.println("throw e;");
                            }
                        gen.EndScope();
                        }
                    }
                code.add(aslbl[iBhvrExceptions]);
                gen.println("catch (" + asRemoteExceptions[i] + " e)");
                gen.addThrowWrapper();
                }
            }

        }
    
    // Declared at the super level
    /**
    * Generate the remote classes needed to "expose" this component for the
    * external use.
    * 
    * The package name and the base name to use for all classes is indicated.
    * 
    * @param gen   the ClassGenerator used to generate the class
    * @param sPackage the Java package name to expose all classes under
    * @param sName     the base name of all exposed classes within the package
    * @param fStore if true then the generated classes and listing will be
    * stored in the storage
    * 
    * @return a list of ClassGenerator$ClassInfo components for all generated
    * classes.
    */
    public java.util.List generateExposedClasses(_package.component.dev.compiler.ClassGenerator gen, String sPackage, String sName, boolean fStore)
            throws com.tangosol.dev.component.ComponentException
        {
        // import java.util.LinkedList;
        
        LinkedList list   = new LinkedList();
        Component  cdThis = gen.getCD();
        
        if (sPackage == null)
            {
            // no need to generate the interfaces here -- caller might as well
            // use the effective ones
            return null;
            }
        else
            {
            if (sName == null || sName.length() == 0)
                {
                sName = cdThis.getName();
                }
            }
        
        // First, generate the home interface sub-class
        
        ClassGenerator genSub = new ClassGenerator();
        
        genSub.setCD(cdThis);
        genSub.setStorage(gen.getStorage());
        genSub.setGenerateListing(gen.isGenerateListing());
        genSub.setErrorList(gen.getErrorList());
        
        String sFullName  = sName + "_EJBHome";
        String sSuperName = getEffectiveClass(gen, cdThis, PEER_HOME_INTERFACE);
        
        String sQualifiedName;
        if (sPackage.length() == 0)
            {
            sQualifiedName = sFullName;
            }
        else
            {
            genSub.println();
            genSub.println("package " + sPackage + ';');
        
            sQualifiedName = sPackage + '.' + sFullName;
            }
        
        ClassFile clz = new ClassFile(sQualifiedName, "java.lang.Object", true);
        genSub.setClassFile(clz);
        
        clz.setPublic();
        clz.setAbstract(true);
        clz.addImplements(sSuperName);
        
        genSub.println();
        genSub.println("public abstract interface " + sFullName);
        genSub.println("         extends " + gen.formatClass(sSuperName, true));
        
        genSub.BeginSegment(null);
        genSub.EndSegment(null);
        
        list.add(genSub.finalizeClassGeneration(fStore));
        
        // Second, generate the remote interface sub-class
        
        sFullName  = sName + "_EJBRemote";
        sSuperName = getEffectiveClass(gen, cdThis, PEER_REMOTE_INTERFACE);
        
        if (sPackage.length() == 0)
            {
            sQualifiedName = sFullName;
            }
        else
            {
            genSub.println();
            genSub.println("package " + sPackage + ';');
            sQualifiedName = sPackage + '.' + sFullName;
            }
        
        clz = new ClassFile(sQualifiedName, "java.lang.Object", true);
        genSub.setClassFile(clz);
        
        clz.setPublic();
        clz.setAbstract(true);
        clz.addImplements(sSuperName);
        
        genSub.println();
        genSub.println("public abstract interface " + sFullName);
        genSub.println("         extends " + gen.formatClass(sSuperName, true));
        
        genSub.BeginSegment(null);
        genSub.EndSegment(null);
        
        list.add(genSub.finalizeClassGeneration(fStore));
        
        // Third, generate the primary key sub-class
        
        sFullName  = sName + "_PrimaryKey";
        sSuperName = getEffectiveClass(gen, cdThis, PEER_PRIMARY_KEY);
        
        if (sPackage.length() == 0)
            {
            sQualifiedName = sFullName;
            }
        else
            {
            genSub.println();
            genSub.println("package " + sPackage + ';');
            sQualifiedName = sPackage + '.' + sFullName;
            }
        
        clz = new ClassFile(sQualifiedName, sSuperName, false);
        genSub.setClassFile(clz);
        
        clz.setPublic();
        
        genSub.println();
        genSub.println("public class " + sFullName);
        genSub.println("         extends " + gen.formatClass(sSuperName, true));
        
        genSub.BeginSegment(null);
        genSub.EndSegment(null);
        
        list.add(genSub.finalizeClassGeneration(fStore));
        
        return list;
        }
    
    // Declared at the super level
    /**
    * Add in any methods in the feed that are required for the remoting of the
    * component.  This is where each remoter sub-class can add the code it
    * requires into the feed class.
    * 
    * @param gen the ClassGenerator used to generate the code
    */
    public void generateFeed(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.Integrator.AbstractBean;
        // import Component.Dev.Storage;
        // import java.util.Enumeration;
        
        ClassFile    clzFeed        = gen.getClassFile();
        AbstractBean abstractBean   = (AbstractBean) gen.getIntegrator();
        Component    cdIntegrator   = gen.getCD();
        DataType     dtIntegrator   = DataType.getComponentType(cdIntegrator.getQualifiedName());
        DataType     dtKey          = getPrimaryKeyDataType(gen);
        Storage      storage        = gen.getStorage();
        String       sIntegratee    = abstractBean.getIntegrateeType().getClassName();
        Component    jcsIntegratee  = storage.loadSignature(sIntegratee);
        String       sFeedClassName = clzFeed.getName();
        boolean      fSessionBean   = isSessionEJB(gen);
        boolean      fCMP           = isContainerManaged(gen);
        
        gen.println();
        gen.println("//++ Start of EJB Feed Implementation");
        gen.println();
        
        // We need a default create home interface method
        // if we are a session bean and our integratee does
        // not already define one.
        boolean fNeedDefaultCreate = fSessionBean
                                     && jcsIntegratee.getBehavior("ejbCreate()") == null;
        
        // Check if we should worry about find's that return
        // a collection of keys
        boolean fPrimaryKeyComponent = false;
        if (!fCMP)
            {
            String sValue = getPrimaryKeyValue(gen, cdIntegrator);
            if (sValue != null
                && sValue.charAt(0) == '$')
                {
                fPrimaryKeyComponent = true;
                }
            }
        
        // Flag if we need to generate the Converter interface method "convert".
        boolean fNeedConvert = false;
        
        // Loop through all of the component's behaviors
        
        for (Enumeration enum = cdIntegrator.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
            if (bhvr != null)
                {
                // First only deal with those methods that are remote
                int iMethodType = getMethodType(gen, bhvr);
                switch (iMethodType)
                    {
                    case METHOD_TYPE_NOT_REMOTE:
                    case METHOD_TYPE_REMOVE:
                        continue;
                    case METHOD_TYPE_FIND_SINGLE:
                    case METHOD_TYPE_FIND_ENUMERATION:
                    case METHOD_TYPE_FIND_COLLECTION:
                        if (fCMP)
                            {
                            continue;
                            }
                    }
        
                // Check if this method is returning or passing
                // remote components or primary keys
                String[]   asRemoteSignatures = getRemoteSignatures(gen, bhvr);
                DataType[] adtRemoteSignature = null;
        
                boolean fConvert = fPrimaryKeyComponent
                                   && (iMethodType == METHOD_TYPE_FIND_ENUMERATION
                                       || iMethodType == METHOD_TYPE_FIND_COLLECTION);
                String sBhvrJVMSignature = gen.resolveJVMSignature(bhvr);
                if (fConvert
                    || !asRemoteSignatures[REMOTE_IMPLEMENTATION_JVM_SIGNATURE].equals(sBhvrJVMSignature))
                    {
                    Method method = clzFeed.addMethod(asRemoteSignatures[REMOTE_IMPLEMENTATION_NAME],
                                                      asRemoteSignatures[REMOTE_IMPLEMENTATION_JVM_SIGNATURE]);
                    method.setPublic();
                    adtRemoteSignature = DataType.parseSignature(
                                                      asRemoteSignatures[REMOTE_IMPLEMENTATION_JVM_SIGNATURE]);
                    int cntParams = bhvr.getParameterCount();
                    _assert(cntParams == adtRemoteSignature.length - 1);
        
                    gen.print("public " + gen.formatType(adtRemoteSignature[0]) + ' ' +
                                                      asRemoteSignatures[REMOTE_IMPLEMENTATION_NAME] + '(');
                    for (int i = 0; i < cntParams; ++i)
                        {
                        if (i > 0)
                            {
                            gen.print(", ");
                            }
                        gen.print(gen.formatType(adtRemoteSignature[i + 1]) + ' ' +
                            bhvr.getParameter(i).getName());
                        }
                    gen.print(")");
                    gen.addExceptionsToMethod(method, bhvr.getExceptionNames());
                    gen.println();
        
                    CodeAttribute code = gen.BeginSegment(method);
                    Avar vL_this = new Avar("this");
                    code.add(vL_this);
                    OpDeclare[] aParameters = addRemoteParameters(gen, bhvr, adtRemoteSignature);
                    _assert(cntParams == aParameters.length);
        
                    DataType dtReturn = bhvr.getReturnValue().getDataType();
                    DataType dtRemoteReturn = adtRemoteSignature[0];
                    if (dtReturn == dtRemoteReturn)
                        {
                        if (dtRemoteReturn != DataType.VOID)
                            {
                            gen.print("return ");
                            }
                        }
                    else
                        {
                        gen.print(gen.formatType(dtReturn) + " __return = ");
                        }
                    if (fConvert)
                        {
                        fNeedConvert = true;
                        gen.print(CLASS_COLLECTION_HELPER + '.' + METH_CONVERTER_CONVERT + '(');
                        }
                    gen.print(bhvr.getName() + "$Router" + '(');
        
                    code.add(new Aload(vL_this));
        
                    for (int i = 0; i < cntParams; ++i)
                        {
                        if (i > 0)
                            {
                            gen.print(", ");
                            }
                        DataType dtParameter       = bhvr.getParameter(i).getDataType();
                        DataType dtRemoteSignature = adtRemoteSignature[i + 1];
                        String   sParameterName    = aParameters[i].getVariableName();
                        code.add(aParameters[i].getLoadOp());
                        if (dtParameter == dtRemoteSignature)
                            {
                            gen.print(sParameterName);
                            }
                        else
                            {
                            addConvertCall(gen, dtParameter, dtRemoteSignature, sParameterName, dtParameter);
                            }
                        }
        
                    MethodConstant cM = new MethodConstant(sFeedClassName,
                        bhvr.getName() + "$Router", sBhvrJVMSignature);
                    code.add(new Invokevirtual(cM));
        
                    gen.print(")");
        
                    if (fConvert)
                        {
                        final String SIG_ENUMERATION = "Ljava/util/Enumeration;"   ;
                        final String SIG_COLLECTION  = "Ljava/util/Collection;"    ;
                        final String SIG_CONVERTER   = 'L' + IFACE_CONVERTER + ';' ;
                        
                        code.add(new Aload(vL_this));
                        if (iMethodType == METHOD_TYPE_FIND_ENUMERATION)
                            {
                            cM = gen.findMethod(CLASS_COLLECTION_HELPER,
                                METH_CONVERTER_CONVERT,
                                '(' + SIG_ENUMERATION + SIG_CONVERTER + ')' + SIG_ENUMERATION);
                            }
                        else
                            {
                            cM = gen.findMethod(CLASS_COLLECTION_HELPER,
                                METH_CONVERTER_CONVERT,
                               '(' + SIG_COLLECTION + SIG_CONVERTER + ')' + SIG_COLLECTION);
                            }
                        code.add(new Invokestatic(cM));
        
                        gen.print(", this)");
                        }
        
                    gen.println(";");
                        
                    if (dtReturn != dtRemoteReturn)
                        {
                        gen.print("return ");
                        addConvertCall(gen, dtReturn, dtReturn, "__return", dtRemoteReturn);
                        gen.println(";");
                        }
                    
                    code.add(gen.getReturnOp(adtRemoteSignature[0]));
        
                    if (adtRemoteSignature[0] == DataType.VOID)
                        {
                        gen.println("return;");
                        }
        
                    gen.EndSegment(method);
                    }
        
                // Check if we still need a default create home interface method.
                if (iMethodType == METHOD_TYPE_CREATE)
                    {
                    if (fSessionBean)
                        {
                        fNeedDefaultCreate = false;
                        }
                    else
                        {
                        // Entity Beans need to implement an ejbPostCreate for every
                        // ejbCreate declared
                        String sPostCreateName = "ejbPostCreate";
                        String sRISig          = asRemoteSignatures[REMOTE_IMPLEMENTATION_SIGNATURE];
                        String sPostCreateSig  = sPostCreateName + sRISig.substring(sRISig.indexOf('('));
        
                        Behavior bhvrPostCreate = cdIntegrator.getBehavior(sPostCreateSig);
                        if (bhvrPostCreate != null)
                            {
                            if (bhvrPostCreate.getReturnValue().getDataType() == DataType.VOID)
                                {
                                abstractBean.generateFeedRouter(gen, bhvrPostCreate, sPostCreateName);
                                }
                            else
                                {
                                // TODO: soft code the warning
                                String sMsg = "Method " + sPostCreateName + " must return \"void\"";
                                gen.addError(sMsg);
                                throw new ComponentException(sMsg);
                                }
                            }
                        else
                            {
                            if (jcsIntegratee.getBehavior(sPostCreateSig) == null)
                                {
                                String sRIJSig       = asRemoteSignatures[REMOTE_IMPLEMENTATION_JVM_SIGNATURE];
                                String sJVMSignature = sRIJSig.substring(0, sRIJSig.indexOf(')') + 1) + 'V';
                                Method method        = clzFeed.addMethod("ejbPostCreate", sJVMSignature);
                                method.setPublic();
                
                                if (adtRemoteSignature == null)
                                    {
                                    adtRemoteSignature = DataType.parseSignature(sRIJSig);
                                    }
                
                                gen.print("public ");
                                gen.formatMethod("ejbPostCreate", sJVMSignature, bhvr);
        
                                // ejbPostCreate() doesn't have to throw exceptions
                                // (see chapters 9.2.3, 9.2.4 of the EJB 1.1 spec)
                                // gen.addExceptionsToMethod(method, bhvr.getExceptionNames());
                                gen.println();
                
                                CodeAttribute code = gen.BeginSegment(method);
                                code.add(new Avar("this"));
                                addRemoteParameters(gen, bhvr, adtRemoteSignature);
                                code.add(new Return());
                
                                gen.EndSegment(method);
                                }
                            }
                        }
                    }
                }
            }
        
        if (fNeedDefaultCreate)
            {
            gen.println();
            gen.println("// default session bean ejbCreate implementation");
        
            Method method = clzFeed.addMethod("ejbCreate", "()V");
            method.setPublic();
        
            gen.print("public ");
            gen.formatMethod("ejbCreate", "()V", null);
            gen.println();
        
            CodeAttribute code = gen.BeginSegment(method);
            code.add(new Avar("this"));
            code.add(new Return());
        
            gen.EndSegment(method);
            }
        
        if (fNeedConvert)
            {
            gen.println();
            gen.println("// Create a remote primary key of a component primary key, this is");
            gen.println("// used by the find methods that return collections of primary keys");
        
            String sEJBPrimaryKey = getAutoGenClass(gen, cdIntegrator, PEER_PRIMARY_KEY);
            DataType dtEJBPrimaryKey = DataType.getClassType(sEJBPrimaryKey.replace('/', '.'));
        
            Method method = clzFeed.addMethod(METH_CONVERTER_CONVERT,
                "(Ljava.lang.Object;)Ljava.lang.Object;");
            method.setPublic();
        
            gen.println("public Object " + METH_CONVERTER_CONVERT + "(Object pk)");
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            Avar vL_pk   = new Avar("pk", "Ljava/lang/Object;");
        
            code.add(vL_this);
            code.add(vL_pk);
        
            gen.print("return ");
        
            code.add(new Aload(vL_pk));
            code.add(new Checkcast(dtKey.getClassConstant()));
        
            addConvertCall(gen, dtIntegrator, dtKey, '(' + gen.formatClass(dtKey.getClassName()) + ") pk", dtEJBPrimaryKey);
        
            code.add(new Areturn());
        
            gen.println(";");
        
            gen.EndSegment(method);
            }
        
        gen.println();
        gen.println("//-- End of EJB Feed Implementation");
        }
    
    // Declared at the super level
    public void generatePeer(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.Integrator;
        // import Component.Dev.Storage;
        // import com.tangosol.util.ErrorList;
        
        Integrator integrator     = gen.getIntegrator();
        Component  cdIntegrator   = gen.getCD();
        boolean    fAbstract      = cdIntegrator.isResultAbstract();
        
        // Sink EJB Class
        if (!fAbstract)
            {
            ClassGenerator genSub = new ClassGenerator();
            genSub.setIntegrator(integrator);
            genSub.setCD(cdIntegrator);
            genSub.setParentGenerator(gen);
            generateEJBStub(genSub);
            }
        
        // Home Interface
        if (!fAbstract)
            {
            ClassGenerator genSub = new ClassGenerator();
            genSub.setIntegrator(integrator);
            genSub.setCD(cdIntegrator);
            genSub.setParentGenerator(gen);
            generateEJBHome(genSub);
            }
        
        // Object Interface
            {
            ClassGenerator genSub = new ClassGenerator();
            genSub.setIntegrator(integrator);
            genSub.setCD(cdIntegrator);
            genSub.setParentGenerator(gen);
            generateEJBRemote(genSub);
            }
        
        if (isEntityEJB(gen))
            {
            // Primary Key Class for Entity bean
            String sValue = getPrimaryKeyValue(gen, cdIntegrator);
            if (sValue != null
                && sValue.charAt(0) == '$')
                {
                Component cdPK = cdIntegrator.getChild(sValue.substring(1));
                if (!cdPK.isResultAbstract()
                    && !gen.getCompilePlan().isDiscardable(cdPK.getQualifiedName()))
                    {
                    ClassGenerator genSub = new ClassGenerator();
                    genSub.setIntegrator(integrator);
                    genSub.setCD(cdIntegrator);
                    genSub.setParentGenerator(gen);
                    generateEJBPrimaryKey(gen, genSub);
                    }
                }
            }
        }
    
    /**
    * Returns a class name that this Remoter generates for the specified
    * component and specified peer type.
    * 
    * @param gen  the currently used ClassGenerator
    * @param cd  Component Definition for which a peer is being generated
    * @param nPeerId  type of the peer (one of PEER_HOME_INTERFACE,
    * PEER_REMOTE_INTERFACE, PEER_PRIMARY_KEY, PEER_SINK_EJB or any other type
    * that the Intergrator is aware of)
    * 
    * @return the class name for the specified peer
    */
    public String getAutoGenClass(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Component cd, int nPeerId)
        {
        // import Component.Dev.Compiler.Integrator;
        // import com.tangosol.util.WrapperException;
        
        // we assume here that even if there is no immediate integrator
        // for this component, the classes could have been generated
        // as explicitly exposed (see generateExposedClasses())
        
        Integrator integrator = gen.findEffectiveIntegrator(cd);
        _assert(integrator != null);
        
        String sPrefix = null;
        switch (nPeerId)
            {
            case PEER_SINK_EJB:
                sPrefix = "Stub";
                break;
            case PEER_HOME_INTERFACE:
                sPrefix = "Home";
                break;
            case PEER_REMOTE_INTERFACE:
                sPrefix = "Remote";
                break;
            case PEER_PRIMARY_KEY:
                sPrefix = "PrimKey";
                break;
            default:
                return integrator.getAutoGenClass(cd, nPeerId);
            }
        
        return DataType.getComponentPackage(cd) + ".ejb" + sPrefix + '_' + cd.getName();
        

        }
    
    /**
    * Returns a base class name that this Remoter uses for the specified
    * component and specified peer type.
    * 
    * @param gen  the currently used ClassGenerator
    * @param cd  Component Definition for which a peer is being generated
    * @param nPeerId  type of the peer (one of PEER_HOME_INTERFACE,
    * PEER_REMOTE_INTERFACE or PEER_PRIMARY_KEY)
    * 
    * @return the base class name for the specified peer
    */
    public String getBaseClass(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Component cd, int nPeerId)
        {
        // import Component.Dev.Compiler.Integrator;
        // import Component.Dev.Storage;
        // import com.tangosol.util.WrapperException;
        
        // Find the effecit
        // and ask it.
        
        try
            {
            Storage    store  = gen.getStorage();
            Component  cdBase = cd;
            Integrator irBase = gen.findIntegrator(cd);
            String     sSuper = cd.getSuperName();
        
            do
                {
                Component  cdSuper = store.loadComponent(sSuper, true, null);
                Integrator irSuper = gen.findIntegrator(cdSuper);
        
                if (irSuper != null)
                    {
                    cdBase = cdSuper;
                    irBase = irSuper;
                    }
        
                sSuper = cdSuper.getSuperName();
                }
            while (sSuper.length() != 0);
            
            String sBase = getAutoGenClass(gen, cdBase, nPeerId);
            switch (nPeerId)
                {
                case PEER_HOME_INTERFACE:
                    return irBase.getIntegrationMiscProperty("home",   sBase);
                case PEER_REMOTE_INTERFACE:
                    return irBase.getIntegrationMiscProperty("remote", sBase);
                case PEER_PRIMARY_KEY:
                    return irBase.getIntegrationMiscProperty("key",    sBase);
                default:
                    throw new IllegalArgumentException();
                }
            }
        catch (ComponentException e)
            {
            throw new WrapperException(e);
            }
        }
    
    /**
    * Return a set of the property names that are known to be data fields for
    * the generated [entity] EJB.
    * 
    * @see #addRoutedPropertties
    * @see Packager.Model.JavaBeanLibrary.EJBLibrary#recordPackageEntry
    */
    public java.util.Collection getDataFields(_package.component.dev.compiler.ClassGenerator gen)
        {
        // import java.util.LinkedList;
        
        Component cdIntegrator = gen.getCD();
        Property  propFields   = cdIntegrator.getProperty(PROP_DATA_FIELDS);
        if (propFields == null)
            {
            return null;
            }
        
        if (propFields.getDataType() != DataType.STRING ||
            propFields.getIndexed()  != Property.PROP_INDEXED)
            {
            // TODO: soft code the warning
            String sMsg = "Property " + PROP_DATA_FIELDS + " must be an indexed String";
            gen.addFatalError(sMsg);
            throw new IllegalStateException(sMsg);
            }
        
        LinkedList fields = new LinkedList();
        Object     oValue = propFields.getValue();
        if (oValue instanceof Object[])
            {
            Object[] aoValue = (Object[]) oValue;
            for (int i = 0; i < aoValue.length; ++i)
                {
                oValue = aoValue[i];
                if (oValue instanceof String)
                    {
                    String   sProp = (String) oValue;
                    Property prop  = cdIntegrator.getProperty(sProp);
                    if (prop == null)
                        {
                        String sMsg = "Property " + PROP_DATA_FIELDS +
                            " refers to a non-existing property " + sProp;
                        gen.addWarning(sMsg);
                        }
                    else
                        {
                        // don't use "sProp" -- property names are case insensitive
                        fields.add(prop.getName());
                        }
                    }
                }
            }
        
        return fields;
        }
    
    /**
    * Returns a effective (the closest super that has changes affecting the
    * corresponding class generation) class that this Remoter uses for the
    * specified component and specified peer type. This is a helper method for
    * the Packager.
    * 
    * @param gen  the currently used ClassGenerator
    * @param cd  Component Definition for which a peer is being generated
    * @param nPeerId  type of the peer (one of PEER_HOME_INTERFACE,
    * PEER_REMOTE_INTERFACE or PEER_PRIMARY_KEY)
    * 
    * @return the effective class name for the specified peer
    */
    public String getEffectiveClass(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Component cd, int nPeerId)
        {
        // import Component.Dev.Compiler.Integrator;
        
        switch (nPeerId)
            {
            case PEER_HOME_INTERFACE:
            case PEER_REMOTE_INTERFACE:
                Integrator irEffect = gen.findEffectiveIntegrator(cd);
                return getAutoGenClass(gen, irEffect.getCD(), nPeerId);
        
            case PEER_PRIMARY_KEY:
                DataType dtPK = getPrimaryKeyDataType(gen);
                return getRemoteDataType(gen, dtPK).getClassName();
        
            default:
                throw new IllegalArgumentException();
            }
        }
    
    public int getMethodType(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr)
        {
        // First, it must be marked as remote to be remore
        if (!bhvr.isRemote())
            {
            return METHOD_TYPE_NOT_REMOTE;
            }
        
        String   sSignature = bhvr.getSignature();
        DataType dtReturn   = bhvr.getReturnValue().getDataType();
        
        // Check if this is mapped to an integrated EJB
        String sMapped = gen.findEffectiveIntegrator(bhvr.getComponent()).
                            getMappedMethod(sSignature);
        if (sMapped != null)
            {
            sSignature = sMapped;
            }
        
        String sName = sSignature.substring(0, sSignature.indexOf('('));
        
        // We are looking for ejbCreate's
        if (sName.equals("ejbCreate"))
            {
            if (isPrimaryKeyType(gen, dtReturn))
                {
                return METHOD_TYPE_CREATE;
                }
                
            // TODO: softcode the warning
            String sMsg = "The return type of method " + bhvr.getSignature() +
                " should be \"" + getPrimaryKeyDataType(gen) + '\"';
            gen.addWarning(sMsg);
            return METHOD_TYPE_REMOTE;
            }
        
        // Check if an entity bean
        if (isEntityEJB(gen))
            {
            // Also look for ejbFind's
            if (sName.startsWith("ejbFind"))
                {
                if (isPrimaryKeyType(gen, dtReturn))
                    {
                    return METHOD_TYPE_FIND_SINGLE;
                    }
                if (dtReturn == DataType.getClassType("java.util.Enumeration"))
                    {
                    return METHOD_TYPE_FIND_ENUMERATION;
                    }
                if (dtReturn == DataType.getClassType("java.util.Collection"))
                    {
                    return METHOD_TYPE_FIND_COLLECTION;
                    }
        
                // TODO: softcode the warning
                String sMsg = "The return type of method " + bhvr.getSignature() +
                    " should be \"" + getPrimaryKeyDataType(gen) +
                    "\", \"Enumeration\" or \"Collection\"";
                gen.addWarning(sMsg);
                }
            }
        
        // Handle ejbRemove's also
        if (dtReturn == DataType.VOID
            && sName.equals("ejbRemove"))
            {
            return METHOD_TYPE_REMOVE;
            }
        
        return METHOD_TYPE_REMOTE;
        }
    
    // Accessor for the property "PrimaryKeyDataType"
    /**
    * Getter for property PrimaryKeyDataType.<p>
    * (Private) Cached value of the primary key data type.
    */
    private com.tangosol.dev.component.DataType getPrimaryKeyDataType()
        {
        return __m_PrimaryKeyDataType;
        }
    
    // Accessor for the property "PrimaryKeyDataType"
    /**
    * Returns the DataType of the primary key.
    */
    public com.tangosol.dev.component.DataType getPrimaryKeyDataType(_package.component.dev.compiler.ClassGenerator gen)
        {
        // import Component.Dev.Compiler.Integrator;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.CompilePlan;
        
        DataType dtPK = getPrimaryKeyDataType();
        if (dtPK != null)
            {
            return dtPK;
            }
        
        // By default, we are a Session Bean, which has a void primary key data type
        dtPK = DataType.VOID;
        
        Component cd          = gen.getCD();
        String    sPrimaryKey = getPrimaryKeyValue(gen, cd);
        if (sPrimaryKey != null)
            {
            if (sPrimaryKey.charAt(0) == '$')
                {
                String    sPKChild = sPrimaryKey.substring(1);
                Component cdPK     = cd.getChild(sPKChild);
                String sPKQualifiedChild = cdPK.getQualifiedName();
        
                // The child is already validated -- see #getPrimaryKeyValue.
                // Use the compile plan to determine where this child has
                // been generated.
        
                CompilePlan compilePlan = gen.getCompilePlan();
                if (compilePlan.isDiscardable(sPKQualifiedChild))
                    {
                    sPKQualifiedChild = compilePlan.getSuperName(sPKQualifiedChild);
                    }
        
                dtPK = DataType.getComponentType(sPKQualifiedChild);
                }
            else
                {
                // the property is already validated -- see #getPrimaryKeyValue
                dtPK = cd.getProperty(sPrimaryKey).getDataType();
                }
            }
        
        setPrimaryKeyDataType(dtPK);
        return dtPK;
        }
    
    private java.util.Collection getPrimaryKeyFields(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Component cd)
        {
        // import com.tangosol.util.LiteSet;
        // import java.util.Collection;
        
        String sPrimaryKey = getPrimaryKeyValue(gen, cd);
        if (sPrimaryKey == null || sPrimaryKey.charAt(0) != '$')
            {
            // the primary key is not a child component,
            // return null
            return null;
            }
        
        Component cdPK = cd.getChild(sPrimaryKey.substring(1));
        _assert(cdPK != null);
        
        Property propPKFields = cdPK.getProperty(PROP_KEY_FIELDS);
        if (propPKFields == null)
            {
            // TODO: soft code the warning
            String sMsg = "Property " + PROP_KEY_FIELDS +
                " does not exists on primary key child " + sPrimaryKey;
            gen.addWarning(sMsg);
            return null;
            }
        
        if (propPKFields.getDataType() != DataType.STRING ||
            propPKFields.getIndexed()  != Property.PROP_INDEXED)
            {
            // TODO: soft code the warning
            String sMsg = "Property " + PROP_KEY_FIELDS + " must be an indexed String";
            gen.addFatalError(sMsg);
            throw new IllegalStateException(sMsg);
            }
        
        Collection col = new LiteSet();
        
        Object oValue = propPKFields.getValue();
        if (oValue instanceof Object[])
            {
            Object[] aoValue = (Object[]) oValue;
            for (int i = 0; i < aoValue.length; ++i)
                {
                oValue = aoValue[i];
                if (oValue instanceof String)
                    {
                    String   sProp = (String) oValue;
                    Property prop  = cdPK.getProperty(sProp);
                    if (prop == null)
                        {
                        String sMsg = "Property " + PROP_KEY_FIELDS +
                        " refers to a non-existing property " + sProp;
                        gen.addWarning(sMsg);
                        }
                    else
                        {
                        // don't use "sProp" -- property names are case insensitive
                        col.add(prop.getName());
                        }
                    }
                }
            }
        
        return col;

        }
    
    /**
    * Returns the name of the property (if any) that serves as the primary key.
    * 
    * @see #getPrimaryKeyDataType
    */
    public String getPrimaryKeyName(_package.component.dev.compiler.ClassGenerator gen)
        {
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Property;
        
        Component cd          = gen.getCD();
        String    sPrimaryKey = getPrimaryKeyValue(gen, cd);
        if (sPrimaryKey != null && sPrimaryKey.charAt(0) != '$')
            {
            // property names are case insensitive
            return cd.getProperty(sPrimaryKey).getName();
            }
        
        return null;
        }
    
    private String getPrimaryKeyValue(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Component cd)
        {
        Property  propPK = cd.getProperty(PROP_PRIMARY_KEY);
        if (propPK == null || !propPK.isVirtualConstant())
            {
            return null;
            }
        
        if (propPK.getDataType() != DataType.STRING || !propPK.isSingle())
            {
            // TODO: soft code the warning
            String sMsg = "Property " + PROP_PRIMARY_KEY +
                " must be a non-indexed String";
            gen.addError(sMsg);
            throw new IllegalStateException(sMsg);
            }
        
        Object oValue = propPK.getValue();
        if (!(oValue instanceof String))
            {
            // TODO: soft code the warning
            String sMsg = "Property " + PROP_PRIMARY_KEY +
                " is not specified -- assuming SessionBean";
            gen.addWarning(sMsg);
            return null;
            }
        
        String sValue = (String) oValue;
        
        // only return the value if it points to
        // an existing property or child
        
        if (sValue.charAt(0) == '$')
            {
            Component cdPK = cd.getChild(sValue.substring(1));
            if (cdPK == null)
                {
                // TODO: soft code the warning
                String sMsg = "Property " + PROP_PRIMARY_KEY +
                    " refers to a non-existing child component \"" + sValue +
                    "\" -- assuming SessionBean";
                gen.addWarning(sMsg);
                return null;
                }
            }
        else
            {
            Property prop = cd.getProperty(sValue);
            if (prop == null)
                {
                // TODO: soft code the warning
                String sMsg = "Property " + PROP_PRIMARY_KEY +
                    " refers to the non-existing property \"" + sValue +
                    "\" -- assuming SessionBean";
                 gen.addWarning(sMsg);
                return null;
                }
            }
        
        return sValue;
        }
    
    private com.tangosol.dev.component.DataType getRemoteDataType(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.DataType dt)
        {
        // import Component.Dev.Compiler.Integrator;
        
        if (dt.isArray())
            {
            DataType dtElement = dt.getElementType();
            // We only handle one dimensional arrays (so far...)
            if (dtElement.isArray())
                {
                return gen.resolveDataType(dt);
                }
            return getRemoteDataType(gen, dtElement).getArrayType();
            }
        
        dt = gen.resolveDataType(dt);
        
        if (dt.isComponent())
            {
            Component cd = gen.getComponent(dt.getComponentName());
            if (cd == null)
                {
                // TODO: soft code the warning
                String sMsg = 
                    "The Component Data Type \"" + dt + "\" specifies a " +
                    "component name which does not exist.";
                gen.addWarning(sMsg);
                return dt;
                }
        
            if (cd.isGlobal())
                {
                Integrator integrator = gen.findEffectiveIntegrator(cd);
                if (integrator != null
                    && integrator.isRemote())
                    {
                    String sEJBRemoteName = getAutoGenClass(gen, integrator.getCD(), PEER_REMOTE_INTERFACE);
                    dt = DataType.getClassType(sEJBRemoteName.replace('/', '.'));
                    }
                }
            else
                {
                Component  cdGlobal   = cd.getGlobalParent();
                Integrator integrator = gen.findEffectiveIntegrator(cdGlobal);
                if (integrator != null && integrator.isRemote())
                    {
                    cdGlobal = integrator.getCD();
                    String sPrimaryKey = getPrimaryKeyValue(gen, cdGlobal);
                    if (sPrimaryKey != null
                        && sPrimaryKey.charAt(0) == '$'
                        && cd.getLocalName().equals(sPrimaryKey.substring(1)))
                        {
                        String sEJBPrimaryKey = getAutoGenClass(gen, cdGlobal, PEER_PRIMARY_KEY);
                        dt = DataType.getClassType(sEJBPrimaryKey.replace('/', '.'));
                        }
                    }
                }        
            }
        
        return dt;
        }
    
    /**
    * Generate the name, signature, and JVM signature of both the remote
    * interface of the behavior and the remote implementation of the behavior.
    */
    private String[] getRemoteSignatures(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr)
        {
        // import Component.Dev.Compiler.Integrator;
        
        String sInterfaceName = bhvr.getName();
        
        // Check if this is mapped to an integrated EJB
        String sMapped = gen.findEffectiveIntegrator(bhvr.getComponent()).
                            getMappedMethod(bhvr.getSignature());
        if (sMapped != null)
            {
            sInterfaceName = sMapped.substring(0,sMapped.indexOf('('));
            }
        String sImplementationName = sInterfaceName;
        
        DataType dtReturn = bhvr.getReturnValue().getDataType();
        DataType dtKey    = getPrimaryKeyDataType(gen);
        
        // Check if a home interface create method
        if (sInterfaceName.equals("ejbCreate")
            && isPrimaryKeyType(gen, dtReturn))
            {
            // ejbCreate's are create in the home interface
            sInterfaceName = "create";
            }
        
        if (dtKey != DataType.VOID)
            {
            if (sInterfaceName.startsWith("ejbFind")
                && (isPrimaryKeyType(gen, dtReturn)
                    || dtReturn == DataType.getClassType("java.util.Enumeration")
                    || dtReturn == DataType.getClassType("java.util.Collection")))
                {
                // ejbFind*'s are find*'s in the home interface
                sInterfaceName = "find" + sInterfaceName.substring(7);
                }
            }
        
        if (dtReturn == DataType.VOID
            && sInterfaceName.equals("ejbRemove"))
            {
            // ejbRemove's are remove in the object interface
            sInterfaceName = "remove";
            }
        
        // Generate both the signature and the JVM signature
        // allowing for remote data types and primary keys.
        StringBuffer sbSignature    = new StringBuffer();
        StringBuffer sbJVMSignature = new StringBuffer();
        
        sbSignature   .append('(');
        sbJVMSignature.append('(');
        for (int i = 0, c = bhvr.getParameterCount(); i < c; ++i)
            {
            DataType dtParameter = getRemoteDataType(gen, bhvr.getParameter(i).getDataType());
        
            sbSignature   .append(dtParameter.getTypeString());
            sbJVMSignature.append(dtParameter.getJVMSignature());
            }
        sbSignature   .append(')');
        sbJVMSignature.append(')');
        
        DataType dtImplementationReturn = getRemoteDataType(gen, dtReturn);
        DataType dtInterfaceReturn;
        
        switch (getMethodType(gen, bhvr))
            {
            case METHOD_TYPE_CREATE:
            case METHOD_TYPE_FIND_SINGLE:
                {
                String sEJBRemoteName = getAutoGenClass(gen, bhvr.getComponent(), PEER_REMOTE_INTERFACE);
                dtInterfaceReturn = DataType.getClassType(sEJBRemoteName.replace('/', '.'));
                break;
                }
            default:
                dtInterfaceReturn = dtImplementationReturn;
                break;
            }
        
        String sJVMSignature = sbJVMSignature.toString();
        String sSignature    = sbSignature.toString();
        
        return new String[] {sInterfaceName,
                             sInterfaceName + sSignature,
                             sJVMSignature + dtInterfaceReturn.getJVMSignature(),
                             sImplementationName,
                             sImplementationName + sSignature,
                             sJVMSignature + dtImplementationReturn.getJVMSignature()
                            };

        }
    
    /**
    * Specifies whether the generated EJB has Container Managed Persistense.
    */
    public boolean isContainerManaged(_package.component.dev.compiler.ClassGenerator gen)
        {
        Component cdIntegrator = gen.getCD();
        Property  propCMP      = cdIntegrator.getProperty(PROP_CMP);
        if (propCMP != null)
            {
            Object oValue = propCMP.getValue();
            if (oValue instanceof Boolean)
                {
                return ((Boolean) oValue).booleanValue();
                }
            }
        return false;
        }
    
    /**
    * Returns true if the EJB generated by this remoter for the specified
    * ClassGenerator (which has a reference to a Component Definition and an
    * integrator) is an entity EJB; false otherwise.
    */
    public boolean isEntityEJB(_package.component.dev.compiler.ClassGenerator gen)
        {
        return !isSessionEJB(gen);
        }
    
    // Declared at the super level
    /**
    * Specifies whether a router for the specified behavior should be created
    * under a "hidden" name.  This is used by the remoter to create it's own
    * implementation of the feed router, which then calls the one generated by
    * AbstractBean.
    * 
    * @param gen ClassGenerator used to generate the code
    * @param bhvr behavior in question
    * 
    * @return true if the behavior should be generated, flase otherwise
    */
    public boolean isFeedRouterHidden(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr)
            throws com.tangosol.dev.component.ComponentException
        {
        if (super.isFeedRouterHidden(gen, bhvr))
            {
            return true;
            }
        
        // First only deal with those methods that are remote
        int iMethodType = getMethodType(gen, bhvr);
        if (iMethodType == METHOD_TYPE_NOT_REMOTE)
            {
            return false;
            }
        
        // Check if this method is returning or passing remote components
        String[] asRemoteSignatures = getRemoteSignatures(gen, bhvr);
        String   sBhvrJVMSignature  = gen.resolveJVMSignature(bhvr);
        if (!asRemoteSignatures[REMOTE_IMPLEMENTATION_JVM_SIGNATURE].equals(sBhvrJVMSignature))
            {
            return true;
            }
        
        // Determine if this class has a home find method that
        // returns a collection of keys (only for BMP beans)
        
        if (!isContainerManaged(gen))
            {
            Component cd     = gen.getCD();
            String    sValue = getPrimaryKeyValue(gen, cd);
        
            if (sValue != null
                && sValue.charAt(0) == '$')
                {
                switch (iMethodType)
                    {
                    case METHOD_TYPE_FIND_ENUMERATION:
                    case METHOD_TYPE_FIND_COLLECTION:
                        return true;
                    }
                }
            }
        
        return false;
        }
    
    // Declared at the super level
    /**
    * Specify whether a router for the specified remote behavior should be
    * generated in the feed.
    * 
    * @param gen ClassGenerator used to generate the code
    * @param bhvr behavior in question
    * @param sMethName  routed method name 
    * 
    * @return true if the behavior should be generated, flase otherwise
    */
    public boolean isFeedRouterImplemented(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr, String sMethName)
            throws com.tangosol.dev.component.ComponentException
        {
        if (!super.isFeedRouterImplemented(gen, bhvr, sMethName))
            {
            return false;
            }
        
        Component cdBhvr = bhvr.getComponent();
        if (cdBhvr != gen.getCD())
            {
            if (cdBhvr.isSignature()
                && cdBhvr.getQualifiedName().equals(IFACE_CONVERTER))
                {
                return false;
                }
            return true;
            }
        
        switch (getMethodType(gen, bhvr))
            {
            case METHOD_TYPE_FIND_SINGLE:
            case METHOD_TYPE_FIND_ENUMERATION:
            case METHOD_TYPE_FIND_COLLECTION:
                {
                if (isContainerManaged(gen))
                    {
                    if (bhvr.getCallableImplementationCount() > 0)
                        {
                        // TODO: soft code the warning
                        String sMsg =
                            "The \"" + bhvr.getSignature() + "\" method on the component \"" +
                            bhvr.getComponent().getQualifiedName() +
                            "\" will not get routed from the feed because it is Container Managed Persisted";
                        gen.addWarning(sMsg);
                        }
                    return false;
                    }
                }
            }
        
        return true;
        }
    
    /**
    * This returns true if support is needed for creating new client instances
    * in the ejb stub.  The ability to create new client instances are needed
    * if any of the home interfaces find methods return an enumeration or
    * collection of remote interfaces.
    */
    private boolean isNeedNewClientInstance(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Component cd)
        {
        // import java.util.Enumeration;
        
        // return true if there are any ejbFinds which
        // return collections (or enumerations)
        
        for (Enumeration enum = cd.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
            if (bhvr != null)
                {
                switch (getMethodType(gen, bhvr))
                    {
                    case METHOD_TYPE_FIND_ENUMERATION:
                    case METHOD_TYPE_FIND_COLLECTION:
                        return true;
                    }
                }
            }
        
        return false;
        }
    
    /**
    * Return true if the specified DataType is the PrimaryKey type or a derived
    * type.
    */
    private boolean isPrimaryKeyType(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.DataType dt)
        {
        DataType dtKey = getPrimaryKeyDataType(gen);
        
        if (dt == dtKey)
            {
            return true;
            }
        
        if (dt.isComponent() && dtKey.isComponent())
            {
            String sKey = dtKey.getComponentName();
        
            Component cdKey = gen.getComponent(sKey);
            _assert(cdKey != null);
            if (cdKey.isDerivedFrom(dt.getComponentName()))
                {
                return true;
                }
            }
        
        return false;
        }
    
    /**
    * Returns true if the EJB generated by this remoter for the specified
    * ClassGenerator (which has a reference to a Component Definition and an
    * integrator) is a session EJB; false otherwise.
    */
    public boolean isSessionEJB(_package.component.dev.compiler.ClassGenerator gen)
        {
        return gen.getCD().getImplements(IFACE_SESSION_BEAN) != null
            || getPrimaryKeyDataType(gen) == DataType.VOID;
        }
    
    // Accessor for the property "PrimaryKeyDataType"
    /**
    * Setter for property PrimaryKeyDataType.<p>
    * (Private) Cached value of the primary key data type.
    */
    private void setPrimaryKeyDataType(com.tangosol.dev.component.DataType pPrimaryKeyDataType)
        {
        __m_PrimaryKeyDataType = pPrimaryKeyDataType;
        }
    }
