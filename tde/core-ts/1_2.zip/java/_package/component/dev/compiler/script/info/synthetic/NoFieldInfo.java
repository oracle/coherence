/* Class
*     _package.component.dev.compiler.script.info.synthetic.NoFieldInfo
*/

package _package.component.dev.compiler.script.info.synthetic;

import _package.component.dev.compiler.ClassGenerator;

/**
* Currently only used by Synthetic.MethodInfo.
* 
* Represents an inlined field.
*/
public class NoFieldInfo
        extends    _package.component.dev.compiler.script.info.Synthetic
        implements com.tangosol.dev.compiler.FieldInfo
    {
    // Fields declarations
    
    /**
    * Property GetterInfo
    *
    */
    
    /**
    * Property IndexedGetterInfo
    *
    */
    
    /**
    * Property IndexedSetterInfo
    *
    */
    
    /**
    * Property SetterInfo
    *
    */
    
    /**
    * Property Value
    *
    */
    
    /**
    * Property ViaAccessor
    *
    */
    
    // Default constructor
    public NoFieldInfo()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public NoFieldInfo(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new NoFieldInfo();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/info/synthetic/NoFieldInfo".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public com.tangosol.dev.component.DataType getDataType()
        {
        // data type is the return type of the method being
        // compiled because this field info is the inlined
        // method info for the super of the method being compiled
        return getContext().getMethodInfo().getDataType();
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Accessor for the property "GetterInfo"
    public com.tangosol.dev.compiler.MethodInfo getGetterInfo()
        {
        return null;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Accessor for the property "IndexedGetterInfo"
    public com.tangosol.dev.compiler.MethodInfo getIndexedGetterInfo()
        {
        return null;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Accessor for the property "IndexedSetterInfo"
    public com.tangosol.dev.compiler.MethodInfo getIndexedSetterInfo()
        {
        return null;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Accessor for the property "SetterInfo"
    public com.tangosol.dev.compiler.MethodInfo getSetterInfo()
        {
        return null;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public com.tangosol.dev.compiler.TypeInfo getTypeInfo()
        {
        // same class as the context
        return getContext().getMethodInfo().getTypeInfo();
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Accessor for the property "Value"
    public Object getValue()
        {
        // import Component.Dev.Compiler.ClassGenerator;
        
        return ClassGenerator.getDefaultValue(getDataType());
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public boolean isInlineable()
        {
        return true;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public boolean isInlined()
        {
        return true;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public boolean isPrivate()
        {
        return true;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public boolean isStatic()
        {
        return true;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Accessor for the property "ViaAccessor"
    public boolean isViaAccessor()
        {
        return false;
        }
    }
