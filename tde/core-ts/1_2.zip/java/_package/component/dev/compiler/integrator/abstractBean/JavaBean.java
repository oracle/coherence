/* Class
*     _package.component.dev.compiler.integrator.abstractBean.JavaBean
*/

package _package.component.dev.compiler.integrator.abstractBean;

import _package.component.dev.compiler.ClassGenerator;
import _package.component.dev.compiler.Remoter;
import _package.component.dev.design.Class; // as ClassInfo
import com.tangosol.dev.assembler.Aaload;
import com.tangosol.dev.assembler.Aastore;
import com.tangosol.dev.assembler.AccessFlags;
import com.tangosol.dev.assembler.Aconst;
import com.tangosol.dev.assembler.Aload;
import com.tangosol.dev.assembler.Anewarray;
import com.tangosol.dev.assembler.Areturn;
import com.tangosol.dev.assembler.Arraylength;
import com.tangosol.dev.assembler.Astore;
import com.tangosol.dev.assembler.Athrow;
import com.tangosol.dev.assembler.Attribute;
import com.tangosol.dev.assembler.Avar;
import com.tangosol.dev.assembler.Baload;
import com.tangosol.dev.assembler.Bastore;
import com.tangosol.dev.assembler.Begin;
import com.tangosol.dev.assembler.Bnewarray;
import com.tangosol.dev.assembler.Caload;
import com.tangosol.dev.assembler.Case;
import com.tangosol.dev.assembler.Castore;
import com.tangosol.dev.assembler.Catch;
import com.tangosol.dev.assembler.Checkcast;
import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.ClassFile;
import com.tangosol.dev.assembler.Cnewarray;
import com.tangosol.dev.assembler.CodeAttribute;
import com.tangosol.dev.assembler.Constant;
import com.tangosol.dev.assembler.ConstantPool;
import com.tangosol.dev.assembler.ConstantValueAttribute;
import com.tangosol.dev.assembler.Constants;
import com.tangosol.dev.assembler.D2f;
import com.tangosol.dev.assembler.D2i;
import com.tangosol.dev.assembler.D2l;
import com.tangosol.dev.assembler.Dadd;
import com.tangosol.dev.assembler.Daload;
import com.tangosol.dev.assembler.Dastore;
import com.tangosol.dev.assembler.Dcmpg;
import com.tangosol.dev.assembler.Dcmpl;
import com.tangosol.dev.assembler.Dconst;
import com.tangosol.dev.assembler.Ddiv;
import com.tangosol.dev.assembler.DeprecatedAttribute;
import com.tangosol.dev.assembler.Dload;
import com.tangosol.dev.assembler.Dmul;
import com.tangosol.dev.assembler.Dneg;
import com.tangosol.dev.assembler.Dnewarray;
import com.tangosol.dev.assembler.DoubleConstant;
import com.tangosol.dev.assembler.Drem;
import com.tangosol.dev.assembler.Dreturn;
import com.tangosol.dev.assembler.Dstore;
import com.tangosol.dev.assembler.Dsub;
import com.tangosol.dev.assembler.Dup2;
import com.tangosol.dev.assembler.Dup2_x1;
import com.tangosol.dev.assembler.Dup2_x2;
import com.tangosol.dev.assembler.Dup;
import com.tangosol.dev.assembler.Dup_x1;
import com.tangosol.dev.assembler.Dup_x2;
import com.tangosol.dev.assembler.Dvar;
import com.tangosol.dev.assembler.End;
import com.tangosol.dev.assembler.ExceptionsAttribute;
import com.tangosol.dev.assembler.F2d;
import com.tangosol.dev.assembler.F2i;
import com.tangosol.dev.assembler.F2l;
import com.tangosol.dev.assembler.Fadd;
import com.tangosol.dev.assembler.Faload;
import com.tangosol.dev.assembler.Fastore;
import com.tangosol.dev.assembler.Fcmpg;
import com.tangosol.dev.assembler.Fcmpl;
import com.tangosol.dev.assembler.Fconst;
import com.tangosol.dev.assembler.Fdiv;
import com.tangosol.dev.assembler.Field;
import com.tangosol.dev.assembler.FieldConstant;
import com.tangosol.dev.assembler.Fload;
import com.tangosol.dev.assembler.FloatConstant;
import com.tangosol.dev.assembler.Fmul;
import com.tangosol.dev.assembler.Fneg;
import com.tangosol.dev.assembler.Fnewarray;
import com.tangosol.dev.assembler.Frem;
import com.tangosol.dev.assembler.Freturn;
import com.tangosol.dev.assembler.Fstore;
import com.tangosol.dev.assembler.Fsub;
import com.tangosol.dev.assembler.Fvar;
import com.tangosol.dev.assembler.Getfield;
import com.tangosol.dev.assembler.Getstatic;
import com.tangosol.dev.assembler.Goto;
import com.tangosol.dev.assembler.GuardedSection;
import com.tangosol.dev.assembler.I2b;
import com.tangosol.dev.assembler.I2c;
import com.tangosol.dev.assembler.I2d;
import com.tangosol.dev.assembler.I2f;
import com.tangosol.dev.assembler.I2l;
import com.tangosol.dev.assembler.I2s;
import com.tangosol.dev.assembler.Iadd;
import com.tangosol.dev.assembler.Iaload;
import com.tangosol.dev.assembler.Iand;
import com.tangosol.dev.assembler.Iastore;
import com.tangosol.dev.assembler.Iconst;
import com.tangosol.dev.assembler.Idiv;
import com.tangosol.dev.assembler.If_acmpeq;
import com.tangosol.dev.assembler.If_acmpne;
import com.tangosol.dev.assembler.If_icmpeq;
import com.tangosol.dev.assembler.If_icmpge;
import com.tangosol.dev.assembler.If_icmpgt;
import com.tangosol.dev.assembler.If_icmple;
import com.tangosol.dev.assembler.If_icmplt;
import com.tangosol.dev.assembler.If_icmpne;
import com.tangosol.dev.assembler.Ifeq;
import com.tangosol.dev.assembler.Ifge;
import com.tangosol.dev.assembler.Ifgt;
import com.tangosol.dev.assembler.Ifle;
import com.tangosol.dev.assembler.Iflt;
import com.tangosol.dev.assembler.Ifne;
import com.tangosol.dev.assembler.Ifnonnull;
import com.tangosol.dev.assembler.Ifnull;
import com.tangosol.dev.assembler.Iinc;
import com.tangosol.dev.assembler.Iload;
import com.tangosol.dev.assembler.Imul;
import com.tangosol.dev.assembler.Ineg;
import com.tangosol.dev.assembler.Inewarray;
import com.tangosol.dev.assembler.InnerClass;
import com.tangosol.dev.assembler.InnerClassesAttribute;
import com.tangosol.dev.assembler.Instanceof;
import com.tangosol.dev.assembler.IntConstant;
import com.tangosol.dev.assembler.InterfaceConstant;
import com.tangosol.dev.assembler.Invokeinterface;
import com.tangosol.dev.assembler.Invokespecial;
import com.tangosol.dev.assembler.Invokestatic;
import com.tangosol.dev.assembler.Invokevirtual;
import com.tangosol.dev.assembler.Ior;
import com.tangosol.dev.assembler.Irem;
import com.tangosol.dev.assembler.Ireturn;
import com.tangosol.dev.assembler.Ishl;
import com.tangosol.dev.assembler.Ishr;
import com.tangosol.dev.assembler.Istore;
import com.tangosol.dev.assembler.Isub;
import com.tangosol.dev.assembler.Iushr;
import com.tangosol.dev.assembler.Ivar;
import com.tangosol.dev.assembler.Ixor;
import com.tangosol.dev.assembler.Jsr;
import com.tangosol.dev.assembler.L2d;
import com.tangosol.dev.assembler.L2f;
import com.tangosol.dev.assembler.L2i;
import com.tangosol.dev.assembler.Label;
import com.tangosol.dev.assembler.Ladd;
import com.tangosol.dev.assembler.Laload;
import com.tangosol.dev.assembler.Land;
import com.tangosol.dev.assembler.Lastore;
import com.tangosol.dev.assembler.Lcmp;
import com.tangosol.dev.assembler.Lconst;
import com.tangosol.dev.assembler.Ldiv;
import com.tangosol.dev.assembler.LineNumberTableAttribute;
import com.tangosol.dev.assembler.Lload;
import com.tangosol.dev.assembler.Lmul;
import com.tangosol.dev.assembler.Lneg;
import com.tangosol.dev.assembler.Lnewarray;
import com.tangosol.dev.assembler.LocalVariableTableAttribute;
import com.tangosol.dev.assembler.LongConstant;
import com.tangosol.dev.assembler.Lookupswitch;
import com.tangosol.dev.assembler.Lor;
import com.tangosol.dev.assembler.Lrem;
import com.tangosol.dev.assembler.Lreturn;
import com.tangosol.dev.assembler.Lshl;
import com.tangosol.dev.assembler.Lshr;
import com.tangosol.dev.assembler.Lstore;
import com.tangosol.dev.assembler.Lsub;
import com.tangosol.dev.assembler.Lushr;
import com.tangosol.dev.assembler.Lvar;
import com.tangosol.dev.assembler.Lxor;
import com.tangosol.dev.assembler.Method;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.assembler.Monitorenter;
import com.tangosol.dev.assembler.Monitorexit;
import com.tangosol.dev.assembler.Multianewarray;
import com.tangosol.dev.assembler.New;
import com.tangosol.dev.assembler.Nop;
import com.tangosol.dev.assembler.Op;
import com.tangosol.dev.assembler.OpArray;
import com.tangosol.dev.assembler.OpBranch;
import com.tangosol.dev.assembler.OpConst;
import com.tangosol.dev.assembler.OpDeclare;
import com.tangosol.dev.assembler.OpLoad;
import com.tangosol.dev.assembler.OpStore;
import com.tangosol.dev.assembler.OpSwitch;
import com.tangosol.dev.assembler.OpVariable;
import com.tangosol.dev.assembler.Pop2;
import com.tangosol.dev.assembler.Pop;
import com.tangosol.dev.assembler.Putfield;
import com.tangosol.dev.assembler.Putstatic;
import com.tangosol.dev.assembler.RefConstant;
import com.tangosol.dev.assembler.Ret;
import com.tangosol.dev.assembler.Return;
import com.tangosol.dev.assembler.Rstore;
import com.tangosol.dev.assembler.Rvar;
import com.tangosol.dev.assembler.Saload;
import com.tangosol.dev.assembler.Sastore;
import com.tangosol.dev.assembler.SignatureConstant;
import com.tangosol.dev.assembler.Snewarray;
import com.tangosol.dev.assembler.SourceFileAttribute;
import com.tangosol.dev.assembler.StringConstant;
import com.tangosol.dev.assembler.Swap;
import com.tangosol.dev.assembler.Switch;
import com.tangosol.dev.assembler.SyntheticAttribute;
import com.tangosol.dev.assembler.Tableswitch;
import com.tangosol.dev.assembler.Try;
import com.tangosol.dev.assembler.UtfConstant;
import com.tangosol.dev.assembler.VMStructure;
import com.tangosol.dev.assembler.Znewarray;
import com.tangosol.dev.compiler.Compiler;
import com.tangosol.dev.compiler.CompilerException;
import com.tangosol.dev.compiler.Context;
import com.tangosol.dev.compiler.Locator;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Implementation;
import com.tangosol.dev.component.Integration;
import com.tangosol.dev.component.Interface;
import com.tangosol.dev.component.Parameter;
import com.tangosol.dev.component.Property;
import com.tangosol.dev.component.ReturnValue;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;

/**
* 
* *****************************
* 
*     JavaBean integrator generates the "integratee" class implementing
* "two-columns" JavaBean integration model.
*/
public class JavaBean
        extends    _package.component.dev.compiler.integrator.AbstractBean
    {
    // Fields declarations
    
    /**
    * Property BHVR_CUSTOM_INIT
    *
    */
    private static final String BHVR_CUSTOM_INIT = "_initFeed";
    
    /**
    * Property BHVR_MAKEREMOTEOBJECT
    *
    */
    private static final String BHVR_MAKEREMOTEOBJECT = "_makeRemoteObject()";
    
    // Default constructor
    public JavaBean()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JavaBean(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setRemote(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new JavaBean();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/integrator/abstractBean/JavaBean".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.Dev.Compiler.ClassGenerator;
        // import com.tangosol.dev.assembler.Aaload;
        // import com.tangosol.dev.assembler.Aastore;
        // import com.tangosol.dev.assembler.AccessFlags;
        // import com.tangosol.dev.assembler.Aconst;
        // import com.tangosol.dev.assembler.Aload;
        // import com.tangosol.dev.assembler.Anewarray;
        // import com.tangosol.dev.assembler.Areturn;
        // import com.tangosol.dev.assembler.Arraylength;
        // import com.tangosol.dev.assembler.Astore;
        // import com.tangosol.dev.assembler.Athrow;
        // import com.tangosol.dev.assembler.Attribute;
        // import com.tangosol.dev.assembler.Avar;
        // import com.tangosol.dev.assembler.Baload;
        // import com.tangosol.dev.assembler.Bastore;
        // import com.tangosol.dev.assembler.Begin;
        // import com.tangosol.dev.assembler.Bnewarray;
        // import com.tangosol.dev.assembler.Caload;
        // import com.tangosol.dev.assembler.Case;
        // import com.tangosol.dev.assembler.Castore;
        // import com.tangosol.dev.assembler.Catch;
        // import com.tangosol.dev.assembler.Checkcast;
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.dev.assembler.Cnewarray;
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.Constant;
        // import com.tangosol.dev.assembler.ConstantPool;
        // import com.tangosol.dev.assembler.Constants;
        // import com.tangosol.dev.assembler.ConstantValueAttribute;
        // import com.tangosol.dev.assembler.D2f;
        // import com.tangosol.dev.assembler.D2i;
        // import com.tangosol.dev.assembler.D2l;
        // import com.tangosol.dev.assembler.Dadd;
        // import com.tangosol.dev.assembler.Daload;
        // import com.tangosol.dev.assembler.Dastore;
        // import com.tangosol.dev.assembler.Dcmpg;
        // import com.tangosol.dev.assembler.Dcmpl;
        // import com.tangosol.dev.assembler.Dconst;
        // import com.tangosol.dev.assembler.Ddiv;
        // import com.tangosol.dev.assembler.DeprecatedAttribute;
        // import com.tangosol.dev.assembler.Dload;
        // import com.tangosol.dev.assembler.Dmul;
        // import com.tangosol.dev.assembler.Dneg;
        // import com.tangosol.dev.assembler.Dnewarray;
        // import com.tangosol.dev.assembler.DoubleConstant;
        // import com.tangosol.dev.assembler.Drem;
        // import com.tangosol.dev.assembler.Dreturn;
        // import com.tangosol.dev.assembler.Dstore;
        // import com.tangosol.dev.assembler.Dsub;
        // import com.tangosol.dev.assembler.Dup;
        // import com.tangosol.dev.assembler.Dup2;
        // import com.tangosol.dev.assembler.Dup2_x1;
        // import com.tangosol.dev.assembler.Dup2_x2;
        // import com.tangosol.dev.assembler.Dup_x1;
        // import com.tangosol.dev.assembler.Dup_x2;
        // import com.tangosol.dev.assembler.Dvar;
        // import com.tangosol.dev.assembler.End;
        // import com.tangosol.dev.assembler.ExceptionsAttribute;
        // import com.tangosol.dev.assembler.F2d;
        // import com.tangosol.dev.assembler.F2i;
        // import com.tangosol.dev.assembler.F2l;
        // import com.tangosol.dev.assembler.Fadd;
        // import com.tangosol.dev.assembler.Faload;
        // import com.tangosol.dev.assembler.Fastore;
        // import com.tangosol.dev.assembler.Fcmpg;
        // import com.tangosol.dev.assembler.Fcmpl;
        // import com.tangosol.dev.assembler.Fconst;
        // import com.tangosol.dev.assembler.Fdiv;
        // import com.tangosol.dev.assembler.Field;
        // import com.tangosol.dev.assembler.FieldConstant;
        // import com.tangosol.dev.assembler.Fload;
        // import com.tangosol.dev.assembler.FloatConstant;
        // import com.tangosol.dev.assembler.Fmul;
        // import com.tangosol.dev.assembler.Fneg;
        // import com.tangosol.dev.assembler.Fnewarray;
        // import com.tangosol.dev.assembler.Frem;
        // import com.tangosol.dev.assembler.Freturn;
        // import com.tangosol.dev.assembler.Fstore;
        // import com.tangosol.dev.assembler.Fsub;
        // import com.tangosol.dev.assembler.Fvar;
        // import com.tangosol.dev.assembler.Getfield;
        // import com.tangosol.dev.assembler.Getstatic;
        // import com.tangosol.dev.assembler.Goto;
        // import com.tangosol.dev.assembler.GuardedSection;
        // import com.tangosol.dev.assembler.I2b;
        // import com.tangosol.dev.assembler.I2c;
        // import com.tangosol.dev.assembler.I2d;
        // import com.tangosol.dev.assembler.I2f;
        // import com.tangosol.dev.assembler.I2l;
        // import com.tangosol.dev.assembler.I2s;
        // import com.tangosol.dev.assembler.Iadd;
        // import com.tangosol.dev.assembler.Iaload;
        // import com.tangosol.dev.assembler.Iand;
        // import com.tangosol.dev.assembler.Iastore;
        // import com.tangosol.dev.assembler.Iconst;
        // import com.tangosol.dev.assembler.Idiv;
        // import com.tangosol.dev.assembler.Ifeq;
        // import com.tangosol.dev.assembler.Ifge;
        // import com.tangosol.dev.assembler.Ifgt;
        // import com.tangosol.dev.assembler.Ifle;
        // import com.tangosol.dev.assembler.Iflt;
        // import com.tangosol.dev.assembler.Ifne;
        // import com.tangosol.dev.assembler.Ifnonnull;
        // import com.tangosol.dev.assembler.Ifnull;
        // import com.tangosol.dev.assembler.If_acmpeq;
        // import com.tangosol.dev.assembler.If_acmpne;
        // import com.tangosol.dev.assembler.If_icmpeq;
        // import com.tangosol.dev.assembler.If_icmpge;
        // import com.tangosol.dev.assembler.If_icmpgt;
        // import com.tangosol.dev.assembler.If_icmple;
        // import com.tangosol.dev.assembler.If_icmplt;
        // import com.tangosol.dev.assembler.If_icmpne;
        // import com.tangosol.dev.assembler.Iinc;
        // import com.tangosol.dev.assembler.Iload;
        // import com.tangosol.dev.assembler.Imul;
        // import com.tangosol.dev.assembler.Ineg;
        // import com.tangosol.dev.assembler.Inewarray;
        // import com.tangosol.dev.assembler.InnerClass;
        // import com.tangosol.dev.assembler.InnerClassesAttribute;
        // import com.tangosol.dev.assembler.Instanceof;
        // import com.tangosol.dev.assembler.IntConstant;
        // import com.tangosol.dev.assembler.InterfaceConstant;
        // import com.tangosol.dev.assembler.Invokeinterface;
        // import com.tangosol.dev.assembler.Invokespecial;
        // import com.tangosol.dev.assembler.Invokestatic;
        // import com.tangosol.dev.assembler.Invokevirtual;
        // import com.tangosol.dev.assembler.Ior;
        // import com.tangosol.dev.assembler.Irem;
        // import com.tangosol.dev.assembler.Ireturn;
        // import com.tangosol.dev.assembler.Ishl;
        // import com.tangosol.dev.assembler.Ishr;
        // import com.tangosol.dev.assembler.Istore;
        // import com.tangosol.dev.assembler.Isub;
        // import com.tangosol.dev.assembler.Iushr;
        // import com.tangosol.dev.assembler.Ivar;
        // import com.tangosol.dev.assembler.Ixor;
        // import com.tangosol.dev.assembler.Jsr;
        // import com.tangosol.dev.assembler.L2d;
        // import com.tangosol.dev.assembler.L2f;
        // import com.tangosol.dev.assembler.L2i;
        // import com.tangosol.dev.assembler.Label;
        // import com.tangosol.dev.assembler.Ladd;
        // import com.tangosol.dev.assembler.Laload;
        // import com.tangosol.dev.assembler.Land;
        // import com.tangosol.dev.assembler.Lastore;
        // import com.tangosol.dev.assembler.Lcmp;
        // import com.tangosol.dev.assembler.Lconst;
        // import com.tangosol.dev.assembler.Ldiv;
        // import com.tangosol.dev.assembler.LineNumberTableAttribute;
        // import com.tangosol.dev.assembler.Lload;
        // import com.tangosol.dev.assembler.Lmul;
        // import com.tangosol.dev.assembler.Lneg;
        // import com.tangosol.dev.assembler.Lnewarray;
        // import com.tangosol.dev.assembler.LocalVariableTableAttribute;
        // import com.tangosol.dev.assembler.LongConstant;
        // import com.tangosol.dev.assembler.Lookupswitch;
        // import com.tangosol.dev.assembler.Lor;
        // import com.tangosol.dev.assembler.Lrem;
        // import com.tangosol.dev.assembler.Lreturn;
        // import com.tangosol.dev.assembler.Lshl;
        // import com.tangosol.dev.assembler.Lshr;
        // import com.tangosol.dev.assembler.Lstore;
        // import com.tangosol.dev.assembler.Lsub;
        // import com.tangosol.dev.assembler.Lushr;
        // import com.tangosol.dev.assembler.Lvar;
        // import com.tangosol.dev.assembler.Lxor;
        // import com.tangosol.dev.assembler.Method;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.Monitorenter;
        // import com.tangosol.dev.assembler.Monitorexit;
        // import com.tangosol.dev.assembler.Multianewarray;
        // import com.tangosol.dev.assembler.New;
        // import com.tangosol.dev.assembler.Nop;
        // import com.tangosol.dev.assembler.Op;
        // import com.tangosol.dev.assembler.OpArray;
        // import com.tangosol.dev.assembler.OpBranch;
        // import com.tangosol.dev.assembler.OpConst;
        // import com.tangosol.dev.assembler.OpDeclare;
        // import com.tangosol.dev.assembler.OpLoad;
        // import com.tangosol.dev.assembler.OpStore;
        // import com.tangosol.dev.assembler.OpSwitch;
        // import com.tangosol.dev.assembler.OpVariable;
        // import com.tangosol.dev.assembler.Pop;
        // import com.tangosol.dev.assembler.Pop2;
        // import com.tangosol.dev.assembler.Putfield;
        // import com.tangosol.dev.assembler.Putstatic;
        // import com.tangosol.dev.assembler.RefConstant;
        // import com.tangosol.dev.assembler.Ret;
        // import com.tangosol.dev.assembler.Return;
        // import com.tangosol.dev.assembler.Rstore;
        // import com.tangosol.dev.assembler.Rvar;
        // import com.tangosol.dev.assembler.Saload;
        // import com.tangosol.dev.assembler.Sastore;
        // import com.tangosol.dev.assembler.SignatureConstant;
        // import com.tangosol.dev.assembler.Snewarray;
        // import com.tangosol.dev.assembler.SourceFileAttribute;
        // import com.tangosol.dev.assembler.StringConstant;
        // import com.tangosol.dev.assembler.Swap;
        // import com.tangosol.dev.assembler.Switch;
        // import com.tangosol.dev.assembler.SyntheticAttribute;
        // import com.tangosol.dev.assembler.Tableswitch;
        // import com.tangosol.dev.assembler.Try;
        // import com.tangosol.dev.assembler.UtfConstant;
        // import com.tangosol.dev.assembler.VMStructure;
        // import com.tangosol.dev.assembler.Znewarray;
        // import com.tangosol.dev.compiler.Compiler;
        // import com.tangosol.dev.compiler.CompilerException;
        // import com.tangosol.dev.compiler.Context;
        // import com.tangosol.dev.compiler.Locator;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Implementation;
        // import com.tangosol.dev.component.Integration;
        // import com.tangosol.dev.component.Interface;
        // import com.tangosol.dev.component.Parameter;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.ReturnValue;
        

        }
    
    // Declared at the super level
    /**
    * Add an integration specific portion of the private initializer
    * (__initPrivate) responsible for an integration peer initialization.
    */
    public void addPeerInitializer(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.assembler.Avar vL_this)
            throws com.tangosol.dev.component.ComponentException
        {
        super.addPeerInitializer(gen, vL_this);
        
        if (isCustomInits())
            {
            return;
            }
        
        CodeAttribute  code   = gen.getCode();
        ClassFile      clzf   = gen.getClassFile();
        
        String   sIntegratorClz = clzf.getName();
        String   sIntegratorSig = 'L' + sIntegratorClz + ';';
        DataType dtFeed         = getFeedType();
        String   sFeedName      = gen.formatClass(dtFeed.getClassName()); // same package
        
        Behavior bhvrGetSink  = gen.getKnownAccessor(ClassGenerator.PROP_SINK, Property.PA_GET_SINGLE);
        
        Label lbl_endif_sinkNeNull = new Label();
        code.add(new Aload(vL_this));
        MethodConstant cM = gen.addMethodCall(bhvrGetSink);
        code.add(new Ifnonnull(lbl_endif_sinkNeNull));
        
        gen.println("if (" + cM.getName() + "() == null)");
        
        gen.BeginScope();
            {
            if (isRemote())
                {
                gen.println("// construct the remote object that accesses the remote component");
                MethodConstant cM_constructRemoteObject = gen.findMethod(gen.getKnownBehavior(BHVR_MAKEREMOTEOBJECT), false);
        
                code.add(new Aload(vL_this));
                code.add(new Invokespecial(cM_constructRemoteObject));
        
                gen.println(cM_constructRemoteObject.getName() + "();");
                }
            else
                {
                String    sFeedBase     = getIntegrateeType().getClassName();
                Component jcsIntegratee = gen.getStorage().loadSignature(sFeedBase);
                if (jcsIntegratee.getBehavior(gen.CONSTRUCTOR_NAME + "()") == null)
                    {
                    throw new IllegalStateException(get_Name() + ".generateImplementation: " + 
                        "Integratee does not contain a default constructor");
                    }
        
                FieldConstant cR_tloPeer = new FieldConstant(dtFeed.getClassConstant(),
                    new SignatureConstant(FLD_TLOPEER, 'L' + THREADLOCAL + ';'));
                code.add(new Getstatic(cR_tloPeer));
                code.add(new Aload(vL_this));
                MethodConstant cM_setObject = new MethodConstant(THREADLOCAL,
                    "setObject", "(Ljava.lang.Object;)V");
                code.add(new Invokevirtual(cM_setObject));
                gen.println(sFeedName + '.' + FLD_TLOPEER + ".setObject(this);");
        
                code.add(new New(dtFeed.getClassConstant()));
                code.add(new Aload(vL_this));
                code.add(new Iconst(new IntConstant(0)));
                MethodConstant cM_newFeed = new MethodConstant(dtFeed.getClassConstant(),
                    new SignatureConstant(ClassGenerator.CONSTRUCTOR_NAME,
                        '(' + sIntegratorSig + "Z)V"));
                code.add(new Invokespecial(cM_newFeed));
        
                gen.println("new " + sFeedName +
                    "(this, false); // this sets the Sink which sets the Feed");
                }
            }
        gen.EndScope();
        
        code.add(lbl_endif_sinkNeNull);
        }
    
    private com.tangosol.dev.assembler.Method generateConstructorHeader(_package.component.dev.compiler.ClassGenerator gen, int iAccess, com.tangosol.dev.component.Behavior bhvr, com.tangosol.dev.component.DataType[] adtAdditionalTypes, String[] asAdditionalNames)
            throws com.tangosol.dev.component.ComponentException
        {
        String sMethSig = gen.resolveJVMSignature(bhvr);
        if (adtAdditionalTypes != null)
            {
            sMethSig = sMethSig.substring(0, sMethSig.indexOf(')'));
            for (int i = 0; i < adtAdditionalTypes.length; ++i)
                {
                sMethSig += gen.resolveJVMSignature(adtAdditionalTypes[i]);
                }
            sMethSig += ")V";
            }
        
        ClassFile clz = gen.getClassFile();
        Method method = clz.addMethod(bhvr.getName(), sMethSig);
        
        switch (iAccess)
            {
            case Behavior.ACCESS_PUBLIC:
                method.setPublic();
        
                gen.print("public ");
                break;
        
            case Behavior.ACCESS_PROTECTED:
                method.setProtected();
        
                gen.print("protected ");
                break;
        
            case Behavior.ACCESS_PACKAGE: // used only in integration
                method.setPackage();
                break;
        
            default:
            case Behavior.ACCESS_PRIVATE:
                method.setPrivate();
        
                gen.print("private ");
                break;
            }
        
        String sClassName = clz.getName();
        sClassName = sClassName.substring(sClassName.lastIndexOf('/') + 1);
        gen.print(sClassName + '(');
        
        boolean fFirst = true;
        
        int cntParams = bhvr.getParameterCount();
        for (int i = 0; i < cntParams; i++)
            {
            if (fFirst)
                {
                fFirst = false;
                }
            else
                {
                gen.print(", ");
                }
            Parameter param = bhvr.getParameter(i);
            gen.print(gen.formatType(param.getDataType()) + ' ' + param.getName());
            }
        
        if (adtAdditionalTypes != null)
            {
            for (int i = 0; i < adtAdditionalTypes.length; ++i)
                {
                if (fFirst)
                    {
                    fFirst = false;
                    }
                else
                    {
                    gen.print(", ");
                    }
                gen.print(gen.formatType(adtAdditionalTypes[i]) + ' ' + asAdditionalNames[i]);
                }
            }
        gen.print(")");
        
        String[] asException = bhvr.getExceptionNames();
        for (int i = 0;
             i < asException.length;
             ++i)
            {
            if (bhvr.getException(asException[i]) == null)
                {
                asException[i] = null;
                }
            }
        
        gen.addExceptionsToMethod(method, asException);
        
        gen.println();
        
        return method;

        }
    
    // Declared at the super level
    /**
    * Generate the classes needed to "expose" this component for the external
    * use.
    * 
    * The package name and the base name to use for all classes is indicated,
    * in addition to an enumeration which specifies the type of class to
    * expose.  The type can indicate to expose either the component's feed, or
    * remote classes.
    * 
    * @param gen   the ClassGenerator used to generate the class
    * @param sPackage the Java package name to expose all classes under
    * @param sName   the base name of all exposed classes within the package
    * @param iType  indicates what classes to generate (EXPOSE_AUTO,
    * EXPOSE_FEED, EXPOSE_REMOTE)
    * @param fStore if true then the generated classes and listing will be
    * stored in the storage
    * 
    * @return a list of ClassGenerator$ClassInfo components for all generated
    * classes.
    */
    public java.util.List generateExposedClasses(_package.component.dev.compiler.ClassGenerator gen, String sPackage, String sName, int iType, boolean fStore)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Design.Class as ClassInfo;
        // import java.util.Enumeration;
        // import java.util.List;
        // import java.util.LinkedList;
        
        List list = super.generateExposedClasses(gen, sPackage, sName, iType, fStore);
        
        if (iType != ClassGenerator.EXPOSE_AUTO &&
            iType != ClassGenerator.EXPOSE_FEED)
            {
            return list;
            }
        
        if (list == null)
            {
            list = new LinkedList();
            }
        
        Component cdThis       = gen.getCD();
        Component cdIntegrator = getCD();
        
        if (sPackage == null)
            {
            if (cdThis == cdIntegrator)
                {
                // the feed already exists here
                return null;
                }
            sPackage = DataType.getComponentPackage(cdThis);
            sName    = (isRemote() ? "ejbImpl_" : "jb_") + cdThis.getName();
            }
        else
            {
            if (sName == null || sName.length() == 0)
                {
                sName = cdThis.getName();
                }
            }
        
        String sFeedNameU = sName;
        String sFeedNameQ = sPackage.length() > 0 ? sPackage + '.' + sFeedNameU : sFeedNameU;
        
        ClassGenerator genSub = new ClassGenerator();
        
        genSub.setIntegrator(this);
        genSub.setCD(cdThis);
        genSub.setStorage(gen.getStorage());
        genSub.setGenerateListing(gen.isGenerateListing());
        genSub.setErrorList(gen.getErrorList());
        
        DataType dtIntegrator    = DataType.getComponentType(cdThis.getQualifiedName());
        String   sIntegratorName = gen.formatClass(dtIntegrator.getClassName(), true);
        String   sFeedBase       = getIntegrateeType().getClassName();
        String   sSuperName      = getAutoGenClass(cdIntegrator, PEER_FEED);
        
        ClassFile clz = new ClassFile(sFeedNameQ, sSuperName, false);
        genSub.setClassFile(clz);
        
        clz.setPublic();
        
        if (sPackage.length() > 0)
            {
            genSub.println();
            genSub.println("package " + sPackage + ';');
            }
        
        genSub.println();
        genSub.println("public class " + sFeedNameU);
        genSub.println("        extends " + genSub.formatClass(sSuperName, true));
        
        genSub.BeginSegment(null);
        
        Behavior bhvrGetClass = genSub.getKnownAccessor(gen.PROP_CLASS, Property.PA_GET_SINGLE);
        
        // create the constructors
        Component jcsIntegratee = gen.getStorage().loadSignature(sFeedBase);
        for (Enumeration enum = jcsIntegratee.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr    = (Behavior) enum.nextElement();
            int      nAccess = bhvr.getAccess();
        
            if (bhvr.getName().equals(ClassGenerator.CONSTRUCTOR_NAME)
                && (nAccess == Behavior.ACCESS_PUBLIC
                    || nAccess == Behavior.ACCESS_PROTECTED))
                {
                genSub.println();
                if (bhvr.getParameterCount() == 0)
                    {
                    genSub.println("// Default (JavaBean) constructor");
                    }
                else
                    {
                    genSub.println("// Parameterized constructor");
                    }
        
                Method method = generateConstructorHeader(genSub, nAccess, bhvr, null, null);
            
                CodeAttribute code = genSub.BeginSegment(method);
        
                Avar vL_this = new Avar("this");
                code.add(vL_this);
                
                OpDeclare[] v_params = genSub.addBehaviorParameters(bhvr);
        
                code.add(new Aload(vL_this));
                genSub.print("super(");
                genSub.addLoadParameters(bhvr, v_params);
        
                MethodConstant cM_bhvr    = genSub.addMethodCall(bhvrGetClass);
                String         sSignature = genSub.resolveJVMSignature(bhvr);
                
                sSignature = sSignature.substring(0, sSignature.indexOf(')')) +
                    "Ljava.lang.Class;)V";
                MethodConstant cM_super = new MethodConstant(sSuperName,
                    ClassGenerator.CONSTRUCTOR_NAME, sSignature);
                code.add(new Invokespecial(cM_super));
        
                if (v_params.length > 0)
                    {
                    genSub.print(", ");
                    }
                genSub.println(sIntegratorName + '.' + cM_bhvr.getName() + "());");
        
                code.add(new Return());
                genSub.EndSegment(method);
                }
            }
        
        // allow class specific adjustments be made
        ((ClassInfo) ClassInfo.getClassInfo(sFeedBase)).adjustFeed(genSub);
        
        genSub.EndSegment(null);
        
        list.add(genSub.finalizeClassGeneration(fStore));
        
        return list;
        }
    
    // Declared at the super level
    /**
    * Generates the constructor used by derived classes (i.e. JavaBeans
    * produced by this tool).
    * 
    * @see generateFeed()
    */
    protected void generateFeedActiveConstructor(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import java.util.Enumeration;
        
        Component cdIntegrator = gen.getCD();
        DataType  dtIntegrator = DataType.getComponentType(cdIntegrator.getQualifiedName());
        ClassFile clzFeed      = gen.getClassFile();
        
        String sIntegratorSig  = gen.resolveJVMSignature(dtIntegrator);
        String sIntegratorName = gen.formatClass(dtIntegrator.getClassName());
        String sFeedClz        = clzFeed.getName();
        String sFeedBase       = getIntegrateeType().getClassName();
        String sSinkClz        = getSinkType().getClassName();
        String sSinkName       = gen.formatClass(sSinkClz);
        
        Component jcsIntegratee = gen.getStorage().loadSignature(sFeedBase);
        
        // generate the "__createPeer" static helper
            {
            Method method = clzFeed.addMethod(
                METH_CREATE, "(Ljava.lang.Class;)" + sIntegratorSig);
            method.setPrivate();
            method.setStatic(true);
        
            gen.println();
            gen.println("private static " + sIntegratorName +
                ' ' + METH_CREATE + "(Class clzPeer)");
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_clzPeer  = new Avar("clzPeer");
            code.add(vL_clzPeer); // parameter
        
            Try   lbl_try    = new Try();
            Label lbl_catch  = new Label();
        
            code.add(lbl_try);
        
            gen.println("try");
        
            gen.BeginScope();
                {
                Avar vL_peer = new Avar("peer");
                code.add(vL_peer);    // local var
        
                gen.println("// create uninitialized component peer");
                gen.println(sIntegratorName + " peer = (" + sIntegratorName + ')');
                gen.println("    " + CLASSHELPER + ".newInstance");
            
                code.add(new Aload(vL_clzPeer));
                code.add(new Iconst(new IntConstant(3)));
                code.add(new Anewarray(new ClassConstant("java.lang.Object")));
                code.add(new Dup());
                code.add(new Iconst(new IntConstant(0)));   // [0] = null
                code.add(new Aconst());                 
                code.add(new Aastore());                    
                code.add(new Dup());                        
                code.add(new Iconst(new IntConstant(1)));   // [1] = null
                code.add(new Aconst());                 
                code.add(new Aastore());                    
                code.add(new Dup());                        
                code.add(new Iconst(new IntConstant(2)));   // [2] = true
                code.add(new Getstatic(new FieldConstant(
                    "java.lang.Boolean", "FALSE", "Ljava.lang.Boolean;")));
                code.add(new Aastore());
                MethodConstant cM_newInstance = new MethodConstant(CLASSHELPER,
                    "newInstance", "(Ljava.lang.Class;[Ljava.lang.Object;)Ljava.lang.Object;");
                code.add(new Invokestatic(cM_newInstance));
                code.add(new Checkcast(dtIntegrator.getClassConstant()));
                code.add(new Astore(vL_peer));
        
                gen.println("        (clzPeer, new Object[] {null, null, Boolean.FALSE});");
        
                gen.println();
                gen.println("// set-up the storage and return");
                code.add(new Getstatic(clzFeed.getFieldConstant(FLD_TLOPEER)));
                code.add(new Aload(vL_peer));
                MethodConstant cM_setObject = new MethodConstant(THREADLOCAL,
                    "setObject", "(Ljava.lang.Object;)V");
                code.add(new Invokevirtual(cM_setObject));
        
                gen.println(FLD_TLOPEER + ".setObject(peer);");
        
                code.add(new Aload(vL_peer));
                code.add(new Areturn());
        
                gen.println("return peer;");
                }
            gen.EndScope();
        
            code.add(new Catch(lbl_try,
                            new ClassConstant("java.lang.Exception"), lbl_catch));
            gen.println("catch (Exception e)");
        
            code.add(lbl_catch);
            gen.BeginScope();
                {
                gen.println("// catch everything and re-throw as a runtime exception");
        
                Avar vL_e = new Avar("e");
                code.add(vL_e);
        
                code.add(new Astore(vL_e));
                gen.addThrow("com.tangosol.run.component.IntegrationException",
                    null, vL_e);
                }
            gen.EndScope();
        
            gen.EndSegment(method);
            }
        
        Behavior bhvrGetClass = gen.getKnownAccessor(ClassGenerator.PROP_CLASS, Property.PA_GET_SINGLE);
        
        // create the constructors
        for (Enumeration enum = jcsIntegratee.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
            int nAccess = bhvr.getAccess();
            if (bhvr.getName().equals(gen.CONSTRUCTOR_NAME)
                && (nAccess == Behavior.ACCESS_PUBLIC
                    || nAccess == Behavior.ACCESS_PROTECTED))
                {
                gen.println();
                if (bhvr.getParameterCount() == 0)
                    {        
                    gen.println("// default (JavaBean) constructor");
                    }
                else
                    {
                    gen.println("// parameterized constructor");
                    }
        
                Method method = generateConstructorHeader(gen, nAccess, bhvr, null, null);
            
                CodeAttribute code = gen.BeginSegment(method);
        
                Avar vL_this = new Avar("this");
                code.add(vL_this);
                
                OpDeclare[] v_params = gen.addBehaviorParameters(bhvr);
        
                code.add(new Aload(vL_this));
                gen.print("this(");
                gen.addLoadParameters(bhvr, v_params);
        
                MethodConstant cM_bhvr = gen.addMethodCall(bhvrGetClass);
                String sSignature = gen.resolveJVMSignature(bhvr);
                sSignature = sSignature.substring(0, sSignature.indexOf(')')) + "Ljava.lang.Class;)V";
                MethodConstant cM_this = new MethodConstant(sFeedClz,
                    gen.CONSTRUCTOR_NAME, sSignature);
                code.add(new Invokespecial(cM_this));
        
                if (v_params.length > 0)
                    {
                    gen.print(", ");
                    }
                gen.println(sIntegratorName + '.' + cM_bhvr.getName() + "());");
        
                code.add(new Return());
                gen.EndSegment(method);
                }
            }
        
        MethodConstant cM_create = new MethodConstant(sFeedClz,
            METH_CREATE, "(Ljava.lang.Class;)" + sIntegratorSig);
        
        // now generate the "active" constructor
        for (Enumeration enum = jcsIntegratee.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
            int nAccess = bhvr.getAccess();
            if (bhvr.getName().equals(gen.CONSTRUCTOR_NAME)
                && (nAccess == Behavior.ACCESS_PUBLIC
                    || nAccess == Behavior.ACCESS_PROTECTED))
                {
                gen.println();
                gen.println("// the following constructor is used only by derived beans");
                gen.println("// to create the corresponding component peer and hook it up");
        
                DataType[] adtTypes = new DataType[] {DataType.getClassType(Class.class)};
                String[]   asNames  = new String[] {"clzPeer"};
                Method method = generateConstructorHeader(gen, Behavior.ACCESS_PROTECTED, bhvr, adtTypes, asNames);
            
                CodeAttribute code = gen.BeginSegment(method);
        
                Avar vL_this = new Avar("this");
                code.add(vL_this);
                
                OpDeclare[] v_params  = gen.addBehaviorParameters(bhvr);
                Avar        v_clzPeer = new Avar(asNames[0]);
                code.add(v_clzPeer);
        
                code.add(new Aload(vL_this));
                gen.print("this(");
                gen.addLoadParameters(bhvr, v_params);
        
                code.add(new Aload(v_clzPeer));
                code.add(new Invokestatic(cM_create));
                code.add(new Iconst(new IntConstant(1)));
        
                String sSignature = gen.resolveJVMSignature(bhvr);
                sSignature = sSignature.substring(0, sSignature.indexOf(')'))
                    + sIntegratorSig + "Z)V";
                MethodConstant cM_this = new MethodConstant(sFeedClz,
                    gen.CONSTRUCTOR_NAME, sSignature);
                code.add(new Invokespecial(cM_this));
        
                if (v_params.length > 0)
                    {
                    gen.print(", ");
                    }
                gen.println(METH_CREATE + '(' + asNames[0] + "), true);");
        
                code.add(new Return());
                gen.EndSegment(method);
                }
            }
        }
    
    // Declared at the super level
    /**
    * Generates the constructor used by the Component integrator to create a
    * Feed.
    * 
    * @see generateFeed()
    */
    protected void generateFeedPassiveConstructor(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import java.util.Enumeration;
        
        Component cdIntegrator = gen.getCD();
        DataType  dtIntegrator = DataType.getComponentType(cdIntegrator.getQualifiedName());
        ClassFile clzFeed      = gen.getClassFile();
        
        String sIntegratorSig  = gen.resolveJVMSignature(dtIntegrator);
        String sFeedClz        = clzFeed.getName();
        String sFeedBase       = getIntegrateeType().getClassName();
        
        Component jcsIntegratee = gen.getStorage().loadSignature(sFeedBase);
        
        for (Enumeration enum = jcsIntegratee.getBehaviors();
             enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
            int nAccess = bhvr.getAccess();
            if (bhvr.getName().equals(gen.CONSTRUCTOR_NAME)
                && (nAccess == Behavior.ACCESS_PUBLIC
                    || nAccess == Behavior.ACCESS_PROTECTED))
                {
                gen.println();
                gen.println("// this (package private) constructor is used by both:");
                gen.println("// the component peer to hook up (fInit set to false)");
                gen.println("// and default Javabean constructor (fInit set to true)");
        
                DataType[] adtTypes = new DataType[] {dtIntegrator, DataType.BOOLEAN};
                String[]   asNames  = new String[] {"peer", "fInit"};
                Method method = generateConstructorHeader(gen, Behavior.ACCESS_PACKAGE, bhvr, adtTypes, asNames);
            
                CodeAttribute code = gen.BeginSegment(method);
        
                Avar vL_this = new Avar("this");
                code.add(vL_this);
                OpDeclare[] v_params  = gen.addBehaviorParameters(bhvr);
                Avar vL_peer  = new Avar(asNames[0]);
                code.add(vL_peer);
                Ivar vZ_fInit = new Ivar(asNames[1], "Z");
                code.add(vZ_fInit);
        
                code.add(new Aload(vL_this));
                gen.print("super(");
                gen.addLoadParameters(bhvr, v_params);
        
                MethodConstant cM_super = new MethodConstant(sFeedBase,
                    ClassGenerator.CONSTRUCTOR_NAME, gen.resolveJVMSignature(bhvr));
                code.add(new Invokespecial(cM_super));
        
                gen.println(");");
        
                gen.println();
        
                Label lbl_ifPeerEq = new Label();
        
                code.add(new Aload(vL_this));
                MethodConstant cM_retrievePeer = new MethodConstant(sFeedClz,
                    METH_RETRIEVE, "()" + sIntegratorSig);
                code.add(new Invokespecial(cM_retrievePeer));
                code.add(new Aload(vL_peer));
                code.add(new If_acmpeq(lbl_ifPeerEq));
        
                gen.println("if (" + METH_RETRIEVE + "() != peer)");
        
                gen.BeginScope();
                    {
                    gen.addThrow("com.tangosol.run.component.IntegrationException",
                        "Invalid peer component", null);
                    }
                gen.EndScope();
        
                code.add(lbl_ifPeerEq);
        
                Label lbl_endif_fInit = new Label();
        
                code.add(new Iload(vZ_fInit));
                code.add(new Ifeq(lbl_endif_fInit));
        
                gen.println("if (fInit)");
        
                gen.BeginScope();
                    {
                    code.add(new Aload(vL_peer));
                    MethodConstant cM_init = new MethodConstant(dtIntegrator.getClassConstant(),
                        new SignatureConstant(ClassGenerator.INIT_NAME, "()V"));
                    code.add(new Invokevirtual(cM_init));
        
                    gen.println("peer." + ClassGenerator.INIT_NAME + "();");
                    }
                gen.EndScope();
        
                code.add(lbl_endif_fInit);
        
                code.add(new Return());
                gen.EndSegment(method);
                }
            }
        }
    
    // Declared at the super level
    /**
    * Generate an integration specific peer access optimization. Default
    * implementation does nothing.
    * 
    * @param bhvr  accessor behavior
    * @param sImplName  implementation name to use instead of bhvr.getName()
    * (synthetic)
    * @param fMainImpl  if true, the method is the "entry point" implementation
    * 
    * @return  generated method
    */
    public com.tangosol.dev.assembler.Method generateImplementation(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr, String sImplName, boolean fMainImpl)
            throws com.tangosol.dev.component.ComponentException
        {
        
        // Let our super handle the call if the bhvr is not implemented by us
        if (!bhvr.getName().equals(BHVR_CUSTOM_INIT)
            || bhvr.getReturnValue().getDataType() != DataType.VOID
            || bhvr.getImplementationCount() <= 0)
            {
            return super.generateImplementation(gen, bhvr, sImplName, fMainImpl);
            }
        
        ClassFile clzf      = gen.getClassFile();
        String    sClass    = clzf.getName();
        
        DataType  dtFeed    = getFeedType();
        String    sFeedName = gen.formatClass(dtFeed.getClassName()); // same package
        
        Method    method = gen.generateMethodHeader(bhvr, sImplName,
            fMainImpl ? bhvr.getAccess() : Behavior.ACCESS_PRIVATE, bhvr.isFinal(), false, null);
        CodeAttribute code = gen.BeginSegment(method);
        
        Avar vL_this = new Avar("this");
        code.add(vL_this);
        
        OpDeclare[] v_params = gen.addBehaviorParameters(bhvr);
        
        FieldConstant cR_tloPeer = new FieldConstant(dtFeed.getClassConstant(),
            new SignatureConstant(FLD_TLOPEER, 'L' + THREADLOCAL + ';'));
        code.add(new Getstatic(cR_tloPeer));
        code.add(new Aload(vL_this));
        MethodConstant cM_setObject = new MethodConstant(THREADLOCAL,
            "setObject", "(Ljava.lang.Object;)V");
        code.add(new Invokevirtual(cM_setObject));
        
        gen.println(sFeedName + '.' + FLD_TLOPEER + ".setObject(this);");
        
        code.add(new New(dtFeed.getClassConstant()));
        
        gen.print("new " + sFeedName + '(');
        
        gen.addLoadParameters(bhvr, v_params);
        
        code.add(new Aload(vL_this));
        code.add(new Iconst(new IntConstant(0)));
        
        // generate feed constructor method signature
        StringBuffer sb = new StringBuffer("(");
        DataType[] adtParam = bhvr.getParameterTypes();
        int cParams = adtParam.length;
        for (int i = 0; i < cParams; ++i)
            {
            sb.append(gen.resolveJVMSignature(adtParam[i]));
            }
        
        String    sSignature    = (ClassGenerator.CONSTRUCTOR_NAME + sb.toString() + ')').replace('/', '.');
        String    sFeedBase     = getIntegrateeType().getClassName();
        Component jcsIntegratee = gen.getStorage().loadSignature(sFeedBase);
        
        if (jcsIntegratee.getBehavior(sSignature) == null)
            {
            throw new IllegalStateException(get_Name() + ".generateImplementation: " + 
                "Integratee does not contain a constructor matching \"" + bhvr + '"');
            }
        
        sb.append('L').append(sClass).append(";Z)V");
        
        MethodConstant cM_newFeed = new MethodConstant(dtFeed.getClassConstant(),
            new SignatureConstant(ClassGenerator.CONSTRUCTOR_NAME, sb.toString()));
        code.add(new Invokespecial(cM_newFeed));
        
        if (adtParam.length > 0)
            {
            gen.print(", ");
            }
        gen.println("this, false); // this sets the Sink which sets the Feed");
        
        code.add(new Aload(vL_this));
        MethodConstant cM_init = new MethodConstant(sClass,
            ClassGenerator.INIT_NAME, "()V");
        code.add(new Invokevirtual(cM_init));
        
        gen.println(cM_init.getName() + "();");
        
        code.add(new Return());
        gen.EndSegment(method);
        
        return method;

        }
    
    // Declared at the super level
    /**
    * Generate the integration specific extra classes.
    */
    public void generatePeer(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.Remoter;
        
        if (gen.getCD().isResultAbstract())
            {
            throw new IllegalStateException(get_Name() + ".generatePeer: " + 
                "Cannot integrate abstract components");
            }
        
        super.generatePeer(gen);

        }
    
    // Declared at the super level
    /**
    * Returns a class name that this Integrator generates for the specified
    * component and specified peer type.
    * 
    * @param cd  Component Definition for which a peer is being generated
    * @param nPeerId  type of the peer (one of PEER_FEED, PEER_SINK or another
    * type defined by a sub component)
    * 
    * @return the class name for the specified peer
    * Get a name of an auto-generated Feed or Sink class for the specified
    * component.
    * 
    * @param cd  Component Definition
    * @param nPeerId  one of PEER_FEED or PEER_SINK
    */
    public String getAutoGenClass(com.tangosol.dev.component.Component cd, int nPeerId)
        {
        if (nPeerId == PEER_FEED)
            {
            String sPrefix = isRemote() ? ".ejbImpl_" : ".jb_";
            return DataType.getComponentPackage(cd) + sPrefix + cd.getName();
            }
        else
            {
            return super.getAutoGenClass(cd, nPeerId);
            }
        }
    
    // Declared at the super level
    /**
    * Getter for property CustomInits.<p>
    * Specifies whether there is a custom initialization for this component.
    * The sub classes override this.
    * 
    * @see AbstractBean.JavaBean#isCustomInits
    */
    public boolean isCustomInits()
        {
        // import java.util.Enumeration;
        
        for (Enumeration enum = getCD().getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
        
            if (bhvr.getName().equals(BHVR_CUSTOM_INIT)
                && bhvr.getReturnValue().getDataType() == DataType.VOID
                && bhvr.getImplementationCount() > 0)
                {
                return true;
                }
            }
        
        return false;
        }
    
    // Declared at the super level
    public void setCDAndMap(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Component cd, com.tangosol.dev.component.Integration map)
        {
        // import java.util.List;
        // import java.util.Enumeration;
        
        super.setCDAndMap(gen, cd, map);
        
        List list = getAutoGenBehaviors();
        
        for (Enumeration enum = cd.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
        
            if (bhvr.getName().equals(BHVR_CUSTOM_INIT)
                && bhvr.getReturnValue().getDataType() == DataType.VOID
                && bhvr.getImplementationCount() > 0)
                {
                list.add(bhvr.getSignature());
                }
            }

        }
    }
