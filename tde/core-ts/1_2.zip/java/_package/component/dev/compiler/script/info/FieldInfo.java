/* Class
*     _package.component.dev.compiler.script.info.FieldInfo
*/

package _package.component.dev.compiler.script.info;

import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.FieldConstant;
import com.tangosol.dev.assembler.SignatureConstant;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.Constants;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Property;

public class FieldInfo
        extends    _package.component.dev.compiler.script.Info
        implements com.tangosol.dev.compiler.FieldInfo
    {
    // Fields declarations
    
    /**
    * Property AccessorInfo
    *
    */
    
    /**
    * Property FieldConstant
    *
    */
    private transient com.tangosol.dev.assembler.FieldConstant __m_FieldConstant;
    
    /**
    * Property Inlineable
    *
    */
    
    /**
    * Property Inlined
    *
    */
    
    /**
    * Property Property
    *
    */
    private com.tangosol.dev.component.Property __m_Property;
    
    /**
    * Property TypeInfo
    *
    */
    
    /**
    * Property Value
    *
    */
    
    // Default constructor
    public FieldInfo()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public FieldInfo(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new FieldInfo();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/info/FieldInfo".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "AccessorInfo"
    protected MethodInfo getAccessorInfo(int iPA)
        {
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Property;
        
        /**
        * @param iPA  property accessor index
        */
        
        // only applicable for bean properties
        if (!isViaAccessor())
            {
            return null;
            }
        
        // determine the accessor signature
        Property prop = getProperty();
        String sSig = prop.getAccessorSignature(iPA);
        _assert(sSig != null);
        
        // grab that behavior
        Behavior beh = prop.getComponent().getBehavior(sSig);
        if (beh == null)
            {
            return null;
            }
        
        // check if the method info is cached
        final String sLocalID = "M_" + sSig;
        TypeInfo   type = (TypeInfo) getTypeInfo();
        MethodInfo info = (MethodInfo) type._findChild(sLocalID);
        if (info == null)
            {
            // method is not cached (or does not exist)
            info = (MethodInfo) type.getMethodInfo(beh.getName(), beh.getParameterTypes());
            }
        
        return info;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public com.tangosol.dev.assembler.Constant getConstant()
        {
        return getFieldConstant();
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public com.tangosol.dev.component.DataType getDataType()
        {
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Property;
        
        Property prop = getProperty();
        DataType dt   = prop.getDataType();
        
        // the type of an indexed property is actually an array
        if (!prop.isSingle())
            {
            dt = dt.getArrayType();
            }
        
        return dt;
        }
    
    // Accessor for the property "FieldConstant"
    public com.tangosol.dev.assembler.FieldConstant getFieldConstant()
        {
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.assembler.FieldConstant;
        // import com.tangosol.dev.assembler.SignatureConstant;
        
        FieldConstant constant = __m_FieldConstant;
        
        if (constant == null)
            {
            constant = getContext().resolveField(getTypeInfo().getDataType(),
                    getDataType(), getName());
            _assert(constant != null, "Failed to resolve " + getProperty());
        
            setFieldConstant(constant);
            }
        
        return constant;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    public com.tangosol.dev.compiler.MethodInfo getGetterInfo()
        {
        // import com.tangosol.dev.component.Property;
        
        // determine what behavior is the getter
        Property prop = getProperty();
        int iPA  = prop.isSingle() ? Property.PA_GET_SINGLE : Property.PA_GET_ARRAY;
        return getAccessorInfo(iPA);
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    public com.tangosol.dev.compiler.MethodInfo getIndexedGetterInfo()
        {
        // import com.tangosol.dev.component.Property;
        
        return getAccessorInfo(Property.PA_GET_INDEX);
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    public com.tangosol.dev.compiler.MethodInfo getIndexedSetterInfo()
        {
        // import com.tangosol.dev.component.Property;
        
        return getAccessorInfo(Property.PA_SET_INDEX);
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public String getName()
        {
        return getProperty().getName();
        }
    
    // Accessor for the property "Property"
    public com.tangosol.dev.component.Property getProperty()
        {
        return __m_Property;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    public com.tangosol.dev.compiler.MethodInfo getSetterInfo()
        {
        // import com.tangosol.dev.component.Property;
        
        // determine what behavior is the getter
        Property prop = getProperty();
        int iPA  = prop.isSingle() ? Property.PA_SET_SINGLE : Property.PA_SET_ARRAY;
        return getAccessorInfo(iPA);
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Accessor for the property "TypeInfo"
    public com.tangosol.dev.compiler.TypeInfo getTypeInfo()
        {
        return (TypeInfo) get_Parent();
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Accessor for the property "Value"
    public Object getValue()
        {
        
        return getProperty().getValue();
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public boolean isAccessible()
        {
        // import com.tangosol.dev.component.DataType;
        
        // public methods are always accessible
        // (note:  interfaces methods are always public)
        if (isPublic())
            {
            return true;
            }
        
        TypeInfo infoThis    = (TypeInfo) getTypeInfo();
        TypeInfo infoContext = (TypeInfo) getContext().getMethodInfo().getTypeInfo();
        
        // all members are accessible on the declaring class
        if (infoThis == infoContext)
            {
            return true;
            }
        
        if (isProtected())
            {
            // the script compilation context is always from a component
            // so the protected method must be on either a super component
            // or on java.lang.Object
            DataType dtThis    = infoThis   .getDataType();
            DataType dtContext = infoContext.getDataType();
            _assert(dtContext.isComponent());
        
            return dtThis == DataType.OBJECT || dtThis.isComponent() &&
                infoContext.getCD().isDerivedFrom(infoThis.getCD());
            }
        
        return false;
        }
    
    // Declared at the super level
    public boolean isDeprecated()
        {
        return getProperty().isDeprecated();
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public boolean isFinal()
        {
        return getProperty().isFinal();
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Accessor for the property "Inlineable"
    public boolean isInlineable()
        {
        // import com.tangosol.dev.component.DataType;
        
        if (isStatic() && isFinal() && !getProperty().isNoValue())
            {
            DataType dt = getDataType();
            return dt.isPrimitive() || dt == DataType.STRING
                    || dt.isReference() && getProperty().isNullValue();
            }
        
        return false;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Accessor for the property "Inlined"
    public boolean isInlined()
        {
        
        // at this point, the fields will always exist; when they are optimized out,
        // the field info can tell because the field constant resolves to null
        return getFieldConstant() == null;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public boolean isPackage()
        {
        // import com.tangosol.dev.component.Constants;
        
        return getProperty().getAccess() == Constants.ACCESS_PACKAGE;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public boolean isPrivate()
        {
        // import com.tangosol.dev.component.Constants;
        
        return getProperty().getAccess() == Constants.ACCESS_PRIVATE;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public boolean isProtected()
        {
        // import com.tangosol.dev.component.Constants;
        
        return getProperty().getAccess() == Constants.ACCESS_PROTECTED;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public boolean isPublic()
        {
        // import com.tangosol.dev.component.Constants;
        
        return getProperty().getAccess() == Constants.ACCESS_PUBLIC;
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    // Declared at the super level
    public boolean isStatic()
        {
        return getProperty().isStatic();
        }
    
    // From interface: com.tangosol.dev.compiler.FieldInfo
    public boolean isViaAccessor()
        {
        // import com.tangosol.dev.component.Property;
        
        // a field is accessed via an accessor under the following conditions:
        //  1)  the field represents a component property
        //  2)  the property is not a Java constant
        
        Property prop = getProperty();
        return prop.getComponent().isComponent() && !prop.isJavaConstant();
        }
    
    // Accessor for the property "FieldConstant"
    public void setFieldConstant(com.tangosol.dev.assembler.FieldConstant pFieldConstant)
        {
        __m_FieldConstant = pFieldConstant;
        }
    
    // Accessor for the property "Property"
    public void setProperty(com.tangosol.dev.component.Property pProperty)
        {
        __m_Property = pProperty;
        }
    
    // Declared at the super level
    public String toString()
        {
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.Component;
        
        Property  prop = getProperty();
        Component cd   = prop.getComponent();
        return cd.getName() + '.' + prop.getName();
        }
    }
