/* Class
*     _package.component.dev.compiler.integrator.AbstractBean
*/

package _package.component.dev.compiler.integrator;

import _package.component.dev.Storage;
import _package.component.dev.compiler.ClassGenerator;
import _package.component.dev.compiler.Integrator;
import _package.component.dev.compiler.Remoter;
import _package.component.dev.design.Class; // as ClassInfo
import com.tangosol.dev.assembler.Aaload;
import com.tangosol.dev.assembler.Aastore;
import com.tangosol.dev.assembler.AccessFlags;
import com.tangosol.dev.assembler.Aconst;
import com.tangosol.dev.assembler.Aload;
import com.tangosol.dev.assembler.Anewarray;
import com.tangosol.dev.assembler.Areturn;
import com.tangosol.dev.assembler.Arraylength;
import com.tangosol.dev.assembler.Astore;
import com.tangosol.dev.assembler.Athrow;
import com.tangosol.dev.assembler.Attribute;
import com.tangosol.dev.assembler.Avar;
import com.tangosol.dev.assembler.Baload;
import com.tangosol.dev.assembler.Bastore;
import com.tangosol.dev.assembler.Begin;
import com.tangosol.dev.assembler.Bnewarray;
import com.tangosol.dev.assembler.Caload;
import com.tangosol.dev.assembler.Case;
import com.tangosol.dev.assembler.Castore;
import com.tangosol.dev.assembler.Catch;
import com.tangosol.dev.assembler.Checkcast;
import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.ClassFile;
import com.tangosol.dev.assembler.Cnewarray;
import com.tangosol.dev.assembler.CodeAttribute;
import com.tangosol.dev.assembler.Constant;
import com.tangosol.dev.assembler.ConstantPool;
import com.tangosol.dev.assembler.ConstantValueAttribute;
import com.tangosol.dev.assembler.Constants;
import com.tangosol.dev.assembler.D2f;
import com.tangosol.dev.assembler.D2i;
import com.tangosol.dev.assembler.D2l;
import com.tangosol.dev.assembler.Dadd;
import com.tangosol.dev.assembler.Daload;
import com.tangosol.dev.assembler.Dastore;
import com.tangosol.dev.assembler.Dcmpg;
import com.tangosol.dev.assembler.Dcmpl;
import com.tangosol.dev.assembler.Dconst;
import com.tangosol.dev.assembler.Ddiv;
import com.tangosol.dev.assembler.DeprecatedAttribute;
import com.tangosol.dev.assembler.Dload;
import com.tangosol.dev.assembler.Dmul;
import com.tangosol.dev.assembler.Dneg;
import com.tangosol.dev.assembler.Dnewarray;
import com.tangosol.dev.assembler.DoubleConstant;
import com.tangosol.dev.assembler.Drem;
import com.tangosol.dev.assembler.Dreturn;
import com.tangosol.dev.assembler.Dstore;
import com.tangosol.dev.assembler.Dsub;
import com.tangosol.dev.assembler.Dup2;
import com.tangosol.dev.assembler.Dup2_x1;
import com.tangosol.dev.assembler.Dup2_x2;
import com.tangosol.dev.assembler.Dup;
import com.tangosol.dev.assembler.Dup_x1;
import com.tangosol.dev.assembler.Dup_x2;
import com.tangosol.dev.assembler.Dvar;
import com.tangosol.dev.assembler.End;
import com.tangosol.dev.assembler.ExceptionsAttribute;
import com.tangosol.dev.assembler.F2d;
import com.tangosol.dev.assembler.F2i;
import com.tangosol.dev.assembler.F2l;
import com.tangosol.dev.assembler.Fadd;
import com.tangosol.dev.assembler.Faload;
import com.tangosol.dev.assembler.Fastore;
import com.tangosol.dev.assembler.Fcmpg;
import com.tangosol.dev.assembler.Fcmpl;
import com.tangosol.dev.assembler.Fconst;
import com.tangosol.dev.assembler.Fdiv;
import com.tangosol.dev.assembler.Field;
import com.tangosol.dev.assembler.FieldConstant;
import com.tangosol.dev.assembler.Fload;
import com.tangosol.dev.assembler.FloatConstant;
import com.tangosol.dev.assembler.Fmul;
import com.tangosol.dev.assembler.Fneg;
import com.tangosol.dev.assembler.Fnewarray;
import com.tangosol.dev.assembler.Frem;
import com.tangosol.dev.assembler.Freturn;
import com.tangosol.dev.assembler.Fstore;
import com.tangosol.dev.assembler.Fsub;
import com.tangosol.dev.assembler.Fvar;
import com.tangosol.dev.assembler.Getfield;
import com.tangosol.dev.assembler.Getstatic;
import com.tangosol.dev.assembler.Goto;
import com.tangosol.dev.assembler.GuardedSection;
import com.tangosol.dev.assembler.I2b;
import com.tangosol.dev.assembler.I2c;
import com.tangosol.dev.assembler.I2d;
import com.tangosol.dev.assembler.I2f;
import com.tangosol.dev.assembler.I2l;
import com.tangosol.dev.assembler.I2s;
import com.tangosol.dev.assembler.Iadd;
import com.tangosol.dev.assembler.Iaload;
import com.tangosol.dev.assembler.Iand;
import com.tangosol.dev.assembler.Iastore;
import com.tangosol.dev.assembler.Iconst;
import com.tangosol.dev.assembler.Idiv;
import com.tangosol.dev.assembler.If_acmpeq;
import com.tangosol.dev.assembler.If_acmpne;
import com.tangosol.dev.assembler.If_icmpeq;
import com.tangosol.dev.assembler.If_icmpge;
import com.tangosol.dev.assembler.If_icmpgt;
import com.tangosol.dev.assembler.If_icmple;
import com.tangosol.dev.assembler.If_icmplt;
import com.tangosol.dev.assembler.If_icmpne;
import com.tangosol.dev.assembler.Ifeq;
import com.tangosol.dev.assembler.Ifge;
import com.tangosol.dev.assembler.Ifgt;
import com.tangosol.dev.assembler.Ifle;
import com.tangosol.dev.assembler.Iflt;
import com.tangosol.dev.assembler.Ifne;
import com.tangosol.dev.assembler.Ifnonnull;
import com.tangosol.dev.assembler.Ifnull;
import com.tangosol.dev.assembler.Iinc;
import com.tangosol.dev.assembler.Iload;
import com.tangosol.dev.assembler.Imul;
import com.tangosol.dev.assembler.Ineg;
import com.tangosol.dev.assembler.Inewarray;
import com.tangosol.dev.assembler.InnerClass;
import com.tangosol.dev.assembler.InnerClassesAttribute;
import com.tangosol.dev.assembler.Instanceof;
import com.tangosol.dev.assembler.IntConstant;
import com.tangosol.dev.assembler.InterfaceConstant;
import com.tangosol.dev.assembler.Invokeinterface;
import com.tangosol.dev.assembler.Invokespecial;
import com.tangosol.dev.assembler.Invokestatic;
import com.tangosol.dev.assembler.Invokevirtual;
import com.tangosol.dev.assembler.Ior;
import com.tangosol.dev.assembler.Irem;
import com.tangosol.dev.assembler.Ireturn;
import com.tangosol.dev.assembler.Ishl;
import com.tangosol.dev.assembler.Ishr;
import com.tangosol.dev.assembler.Istore;
import com.tangosol.dev.assembler.Isub;
import com.tangosol.dev.assembler.Iushr;
import com.tangosol.dev.assembler.Ivar;
import com.tangosol.dev.assembler.Ixor;
import com.tangosol.dev.assembler.Jsr;
import com.tangosol.dev.assembler.L2d;
import com.tangosol.dev.assembler.L2f;
import com.tangosol.dev.assembler.L2i;
import com.tangosol.dev.assembler.Label;
import com.tangosol.dev.assembler.Ladd;
import com.tangosol.dev.assembler.Laload;
import com.tangosol.dev.assembler.Land;
import com.tangosol.dev.assembler.Lastore;
import com.tangosol.dev.assembler.Lcmp;
import com.tangosol.dev.assembler.Lconst;
import com.tangosol.dev.assembler.Ldiv;
import com.tangosol.dev.assembler.LineNumberTableAttribute;
import com.tangosol.dev.assembler.Lload;
import com.tangosol.dev.assembler.Lmul;
import com.tangosol.dev.assembler.Lneg;
import com.tangosol.dev.assembler.Lnewarray;
import com.tangosol.dev.assembler.LocalVariableTableAttribute;
import com.tangosol.dev.assembler.LongConstant;
import com.tangosol.dev.assembler.Lookupswitch;
import com.tangosol.dev.assembler.Lor;
import com.tangosol.dev.assembler.Lrem;
import com.tangosol.dev.assembler.Lreturn;
import com.tangosol.dev.assembler.Lshl;
import com.tangosol.dev.assembler.Lshr;
import com.tangosol.dev.assembler.Lstore;
import com.tangosol.dev.assembler.Lsub;
import com.tangosol.dev.assembler.Lushr;
import com.tangosol.dev.assembler.Lvar;
import com.tangosol.dev.assembler.Lxor;
import com.tangosol.dev.assembler.Method;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.assembler.Monitorenter;
import com.tangosol.dev.assembler.Monitorexit;
import com.tangosol.dev.assembler.Multianewarray;
import com.tangosol.dev.assembler.New;
import com.tangosol.dev.assembler.Nop;
import com.tangosol.dev.assembler.Op;
import com.tangosol.dev.assembler.OpArray;
import com.tangosol.dev.assembler.OpBranch;
import com.tangosol.dev.assembler.OpConst;
import com.tangosol.dev.assembler.OpDeclare;
import com.tangosol.dev.assembler.OpLoad;
import com.tangosol.dev.assembler.OpStore;
import com.tangosol.dev.assembler.OpSwitch;
import com.tangosol.dev.assembler.OpVariable;
import com.tangosol.dev.assembler.Pop2;
import com.tangosol.dev.assembler.Pop;
import com.tangosol.dev.assembler.Putfield;
import com.tangosol.dev.assembler.Putstatic;
import com.tangosol.dev.assembler.RefConstant;
import com.tangosol.dev.assembler.Ret;
import com.tangosol.dev.assembler.Return;
import com.tangosol.dev.assembler.Rstore;
import com.tangosol.dev.assembler.Rvar;
import com.tangosol.dev.assembler.Saload;
import com.tangosol.dev.assembler.Sastore;
import com.tangosol.dev.assembler.SignatureConstant;
import com.tangosol.dev.assembler.Snewarray;
import com.tangosol.dev.assembler.SourceFileAttribute;
import com.tangosol.dev.assembler.StringConstant;
import com.tangosol.dev.assembler.Swap;
import com.tangosol.dev.assembler.Switch;
import com.tangosol.dev.assembler.SyntheticAttribute;
import com.tangosol.dev.assembler.Tableswitch;
import com.tangosol.dev.assembler.Try;
import com.tangosol.dev.assembler.UtfConstant;
import com.tangosol.dev.assembler.VMStructure;
import com.tangosol.dev.assembler.Znewarray;
import com.tangosol.dev.compiler.Compiler;
import com.tangosol.dev.compiler.CompilerException;
import com.tangosol.dev.compiler.Context;
import com.tangosol.dev.compiler.Locator;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Implementation;
import com.tangosol.dev.component.Integration;
import com.tangosol.dev.component.Interface;
import com.tangosol.dev.component.Parameter;
import com.tangosol.dev.component.Property;
import com.tangosol.dev.component.ReturnValue;
import com.tangosol.util.LiteSet;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

/**
* AbstractBean integrator is an integration model that generates the Sink class
* that routes onto the Feed class that is known to exist.
* 
*     Unlike the Wrapper model it optimizes access to the Feed and Sink using
* the auto-generated fields.
*  
*     The AbstractBean model is used for an abstract JavaBean integration (i.e.
* Component.GUI.Control integrating java.awt.Component) as well as it is a
* super class for the JavaBean integration model.
*/
public class AbstractBean
        extends    _package.component.dev.compiler.Integrator
    {
    // Fields declarations
    
    /**
    * Property CLASSHELPER
    *
    * The full name of the ClassHelper class
    */
    protected static final String CLASSHELPER = "com.tangosol.util.ClassHelper";
    
    /**
    * Property COMPONENT_PEER
    *
    * The full name of the ComponentPeer interface
    */
    public static final String COMPONENT_PEER = "com.tangosol.run.component.ComponentPeer";
    
    /**
    * Property FLD_FEED
    *
    * Field used to optimize the Component's access to its Feed.
    */
    protected static final String FLD_FEED = "__feed";
    
    /**
    * Property FLD_PEER
    *
    * Field used to optimize the Sink's access to the associated Feed.
    */
    protected static final String FLD_PEER = "__peer";
    
    /**
    * Property FLD_SINK
    *
    * Field used to optimize the Component's access to its Sink.
    */
    protected static final String FLD_SINK = "__sink";
    
    /**
    * Property FLD_TLOPEER
    *
    * The name of a field (package private static) on the Feed that holds a
    * reference to the associated Component during the initialization.
    */
    protected static final String FLD_TLOPEER = "__tloPeer";
    
    /**
    * Property METH_CREATE
    *
    * Name of a helper method on the Feed used to instantiate the associated
    * Component.
    */
    protected static final String METH_CREATE = "__createPeer";
    
    /**
    * Property METH_GET
    *
    * Name of a method in the COMPONENT_PEER interface used to get a reference
    * to the associated Component.
    */
    public static final String METH_GET = "get_ComponentPeer";
    
    /**
    * Property METH_RETRIEVE
    *
    * Name of a helper method on the Feed used to get a reference to the
    * associated Component.
    */
    protected static final String METH_RETRIEVE = "__retrievePeer";
    
    /**
    * Property PEER_SINK_CALLBACK
    *
    */
    public static final int PEER_SINK_CALLBACK = 2;
    
    /**
    * Property Remoter
    *
    */
    private transient _package.component.dev.compiler.Remoter __m_Remoter;
    
    /**
    * Property ROUTER_PREFIX
    *
    * Prefix for synthetic routers to super classes.
    */
    protected static final String ROUTER_PREFIX = "super$";
    
    /**
    * Property SinkCallbackType
    *
    * The data type of the implementation class used to implement the call back
    * sink.  For most abstract bean generations, this is the same as the
    * SinkType.  Remote implementations use an interface data type for the
    * SinkType, and set the SinkCallbackType to the class that implements the
    * SinkType interface.
    */
    private transient com.tangosol.dev.component.DataType __m_SinkCallbackType;
    
    /**
    * Property THREADLOCAL
    *
    * The full name of the ThreadLocalObject class.
    */
    protected static final String THREADLOCAL = "com.tangosol.util.ThreadLocalObject";
    
    // Default constructor
    public AbstractBean()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public AbstractBean(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setRemote(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new AbstractBean();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/integrator/AbstractBean".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.Dev.Compiler.ClassGenerator;
        // import Component.Dev.Storage;
        // import com.tangosol.dev.assembler.Aaload;
        // import com.tangosol.dev.assembler.Aastore;
        // import com.tangosol.dev.assembler.AccessFlags;
        // import com.tangosol.dev.assembler.Aconst;
        // import com.tangosol.dev.assembler.Aload;
        // import com.tangosol.dev.assembler.Anewarray;
        // import com.tangosol.dev.assembler.Areturn;
        // import com.tangosol.dev.assembler.Arraylength;
        // import com.tangosol.dev.assembler.Astore;
        // import com.tangosol.dev.assembler.Athrow;
        // import com.tangosol.dev.assembler.Attribute;
        // import com.tangosol.dev.assembler.Avar;
        // import com.tangosol.dev.assembler.Baload;
        // import com.tangosol.dev.assembler.Bastore;
        // import com.tangosol.dev.assembler.Begin;
        // import com.tangosol.dev.assembler.Bnewarray;
        // import com.tangosol.dev.assembler.Caload;
        // import com.tangosol.dev.assembler.Case;
        // import com.tangosol.dev.assembler.Castore;
        // import com.tangosol.dev.assembler.Catch;
        // import com.tangosol.dev.assembler.Checkcast;
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.dev.assembler.Cnewarray;
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.Constant;
        // import com.tangosol.dev.assembler.ConstantPool;
        // import com.tangosol.dev.assembler.Constants;
        // import com.tangosol.dev.assembler.ConstantValueAttribute;
        // import com.tangosol.dev.assembler.D2f;
        // import com.tangosol.dev.assembler.D2i;
        // import com.tangosol.dev.assembler.D2l;
        // import com.tangosol.dev.assembler.Dadd;
        // import com.tangosol.dev.assembler.Daload;
        // import com.tangosol.dev.assembler.Dastore;
        // import com.tangosol.dev.assembler.Dcmpg;
        // import com.tangosol.dev.assembler.Dcmpl;
        // import com.tangosol.dev.assembler.Dconst;
        // import com.tangosol.dev.assembler.Ddiv;
        // import com.tangosol.dev.assembler.DeprecatedAttribute;
        // import com.tangosol.dev.assembler.Dload;
        // import com.tangosol.dev.assembler.Dmul;
        // import com.tangosol.dev.assembler.Dneg;
        // import com.tangosol.dev.assembler.Dnewarray;
        // import com.tangosol.dev.assembler.DoubleConstant;
        // import com.tangosol.dev.assembler.Drem;
        // import com.tangosol.dev.assembler.Dreturn;
        // import com.tangosol.dev.assembler.Dstore;
        // import com.tangosol.dev.assembler.Dsub;
        // import com.tangosol.dev.assembler.Dup;
        // import com.tangosol.dev.assembler.Dup2;
        // import com.tangosol.dev.assembler.Dup2_x1;
        // import com.tangosol.dev.assembler.Dup2_x2;
        // import com.tangosol.dev.assembler.Dup_x1;
        // import com.tangosol.dev.assembler.Dup_x2;
        // import com.tangosol.dev.assembler.Dvar;
        // import com.tangosol.dev.assembler.End;
        // import com.tangosol.dev.assembler.ExceptionsAttribute;
        // import com.tangosol.dev.assembler.F2d;
        // import com.tangosol.dev.assembler.F2i;
        // import com.tangosol.dev.assembler.F2l;
        // import com.tangosol.dev.assembler.Fadd;
        // import com.tangosol.dev.assembler.Faload;
        // import com.tangosol.dev.assembler.Fastore;
        // import com.tangosol.dev.assembler.Fcmpg;
        // import com.tangosol.dev.assembler.Fcmpl;
        // import com.tangosol.dev.assembler.Fconst;
        // import com.tangosol.dev.assembler.Fdiv;
        // import com.tangosol.dev.assembler.Field;
        // import com.tangosol.dev.assembler.FieldConstant;
        // import com.tangosol.dev.assembler.Fload;
        // import com.tangosol.dev.assembler.FloatConstant;
        // import com.tangosol.dev.assembler.Fmul;
        // import com.tangosol.dev.assembler.Fneg;
        // import com.tangosol.dev.assembler.Fnewarray;
        // import com.tangosol.dev.assembler.Frem;
        // import com.tangosol.dev.assembler.Freturn;
        // import com.tangosol.dev.assembler.Fstore;
        // import com.tangosol.dev.assembler.Fsub;
        // import com.tangosol.dev.assembler.Fvar;
        // import com.tangosol.dev.assembler.Getfield;
        // import com.tangosol.dev.assembler.Getstatic;
        // import com.tangosol.dev.assembler.Goto;
        // import com.tangosol.dev.assembler.GuardedSection;
        // import com.tangosol.dev.assembler.I2b;
        // import com.tangosol.dev.assembler.I2c;
        // import com.tangosol.dev.assembler.I2d;
        // import com.tangosol.dev.assembler.I2f;
        // import com.tangosol.dev.assembler.I2l;
        // import com.tangosol.dev.assembler.I2s;
        // import com.tangosol.dev.assembler.Iadd;
        // import com.tangosol.dev.assembler.Iaload;
        // import com.tangosol.dev.assembler.Iand;
        // import com.tangosol.dev.assembler.Iastore;
        // import com.tangosol.dev.assembler.Iconst;
        // import com.tangosol.dev.assembler.Idiv;
        // import com.tangosol.dev.assembler.Ifeq;
        // import com.tangosol.dev.assembler.Ifge;
        // import com.tangosol.dev.assembler.Ifgt;
        // import com.tangosol.dev.assembler.Ifle;
        // import com.tangosol.dev.assembler.Iflt;
        // import com.tangosol.dev.assembler.Ifne;
        // import com.tangosol.dev.assembler.Ifnonnull;
        // import com.tangosol.dev.assembler.Ifnull;
        // import com.tangosol.dev.assembler.If_acmpeq;
        // import com.tangosol.dev.assembler.If_acmpne;
        // import com.tangosol.dev.assembler.If_icmpeq;
        // import com.tangosol.dev.assembler.If_icmpge;
        // import com.tangosol.dev.assembler.If_icmpgt;
        // import com.tangosol.dev.assembler.If_icmple;
        // import com.tangosol.dev.assembler.If_icmplt;
        // import com.tangosol.dev.assembler.If_icmpne;
        // import com.tangosol.dev.assembler.Iinc;
        // import com.tangosol.dev.assembler.Iload;
        // import com.tangosol.dev.assembler.Imul;
        // import com.tangosol.dev.assembler.Ineg;
        // import com.tangosol.dev.assembler.Inewarray;
        // import com.tangosol.dev.assembler.InnerClass;
        // import com.tangosol.dev.assembler.InnerClassesAttribute;
        // import com.tangosol.dev.assembler.Instanceof;
        // import com.tangosol.dev.assembler.IntConstant;
        // import com.tangosol.dev.assembler.InterfaceConstant;
        // import com.tangosol.dev.assembler.Invokeinterface;
        // import com.tangosol.dev.assembler.Invokespecial;
        // import com.tangosol.dev.assembler.Invokestatic;
        // import com.tangosol.dev.assembler.Invokevirtual;
        // import com.tangosol.dev.assembler.Ior;
        // import com.tangosol.dev.assembler.Irem;
        // import com.tangosol.dev.assembler.Ireturn;
        // import com.tangosol.dev.assembler.Ishl;
        // import com.tangosol.dev.assembler.Ishr;
        // import com.tangosol.dev.assembler.Istore;
        // import com.tangosol.dev.assembler.Isub;
        // import com.tangosol.dev.assembler.Iushr;
        // import com.tangosol.dev.assembler.Ivar;
        // import com.tangosol.dev.assembler.Ixor;
        // import com.tangosol.dev.assembler.Jsr;
        // import com.tangosol.dev.assembler.L2d;
        // import com.tangosol.dev.assembler.L2f;
        // import com.tangosol.dev.assembler.L2i;
        // import com.tangosol.dev.assembler.Label;
        // import com.tangosol.dev.assembler.Ladd;
        // import com.tangosol.dev.assembler.Laload;
        // import com.tangosol.dev.assembler.Land;
        // import com.tangosol.dev.assembler.Lastore;
        // import com.tangosol.dev.assembler.Lcmp;
        // import com.tangosol.dev.assembler.Lconst;
        // import com.tangosol.dev.assembler.Ldiv;
        // import com.tangosol.dev.assembler.LineNumberTableAttribute;
        // import com.tangosol.dev.assembler.Lload;
        // import com.tangosol.dev.assembler.Lmul;
        // import com.tangosol.dev.assembler.Lneg;
        // import com.tangosol.dev.assembler.Lnewarray;
        // import com.tangosol.dev.assembler.LocalVariableTableAttribute;
        // import com.tangosol.dev.assembler.LongConstant;
        // import com.tangosol.dev.assembler.Lookupswitch;
        // import com.tangosol.dev.assembler.Lor;
        // import com.tangosol.dev.assembler.Lrem;
        // import com.tangosol.dev.assembler.Lreturn;
        // import com.tangosol.dev.assembler.Lshl;
        // import com.tangosol.dev.assembler.Lshr;
        // import com.tangosol.dev.assembler.Lstore;
        // import com.tangosol.dev.assembler.Lsub;
        // import com.tangosol.dev.assembler.Lushr;
        // import com.tangosol.dev.assembler.Lvar;
        // import com.tangosol.dev.assembler.Lxor;
        // import com.tangosol.dev.assembler.Method;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.Monitorenter;
        // import com.tangosol.dev.assembler.Monitorexit;
        // import com.tangosol.dev.assembler.Multianewarray;
        // import com.tangosol.dev.assembler.New;
        // import com.tangosol.dev.assembler.Nop;
        // import com.tangosol.dev.assembler.Op;
        // import com.tangosol.dev.assembler.OpArray;
        // import com.tangosol.dev.assembler.OpBranch;
        // import com.tangosol.dev.assembler.OpConst;
        // import com.tangosol.dev.assembler.OpDeclare;
        // import com.tangosol.dev.assembler.OpLoad;
        // import com.tangosol.dev.assembler.OpStore;
        // import com.tangosol.dev.assembler.OpSwitch;
        // import com.tangosol.dev.assembler.OpVariable;
        // import com.tangosol.dev.assembler.Pop;
        // import com.tangosol.dev.assembler.Pop2;
        // import com.tangosol.dev.assembler.Putfield;
        // import com.tangosol.dev.assembler.Putstatic;
        // import com.tangosol.dev.assembler.RefConstant;
        // import com.tangosol.dev.assembler.Ret;
        // import com.tangosol.dev.assembler.Return;
        // import com.tangosol.dev.assembler.Rstore;
        // import com.tangosol.dev.assembler.Rvar;
        // import com.tangosol.dev.assembler.Saload;
        // import com.tangosol.dev.assembler.Sastore;
        // import com.tangosol.dev.assembler.SignatureConstant;
        // import com.tangosol.dev.assembler.Snewarray;
        // import com.tangosol.dev.assembler.SourceFileAttribute;
        // import com.tangosol.dev.assembler.StringConstant;
        // import com.tangosol.dev.assembler.Swap;
        // import com.tangosol.dev.assembler.Switch;
        // import com.tangosol.dev.assembler.SyntheticAttribute;
        // import com.tangosol.dev.assembler.Tableswitch;
        // import com.tangosol.dev.assembler.Try;
        // import com.tangosol.dev.assembler.UtfConstant;
        // import com.tangosol.dev.assembler.VMStructure;
        // import com.tangosol.dev.assembler.Znewarray;
        // import com.tangosol.dev.compiler.Compiler;
        // import com.tangosol.dev.compiler.CompilerException;
        // import com.tangosol.dev.compiler.Context;
        // import com.tangosol.dev.compiler.Locator;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Implementation;
        // import com.tangosol.dev.component.Integration;
        // import com.tangosol.dev.component.Interface;
        // import com.tangosol.dev.component.Parameter;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.ReturnValue;
        

        }
    
    // Declared at the super level
    /**
    * Add comments to the listing header.
    */
    public void addComments(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.Remoter;
        
        super.addComments(gen);
        
        if (isRemote())
            {
            getRemoter().addComments(gen);
            }
        }
    
    // Declared at the super level
    /**
    * This method provides the operatunity for an integration to add code to
    * the class file generated for the main component class and the main class
    * file for all derived sub-components.
    */
    public void addEffectiveIntegration(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        super.addEffectiveIntegration(gen);
        
        if (isRemote())
            {
            getRemoter().addEffectiveIntegration(gen, this);
            }
        }
    
    // Declared at the super level
    /**
    * Add an integration specific fields to the class file.
    */
    public void addFields(_package.component.dev.compiler.ClassGenerator gen)
        {
        super.addFields(gen);
        
        ClassFile clzf = gen.getClassFile();
        
        gen.println();
        gen.println("// fields used by the integration model:");
        
        DataType dtSink  = getSinkType();
        Field    fldSink = clzf.addField(FLD_SINK, dtSink.getJVMSignature());
        fldSink.setPrivate();
        
        gen.println("private " + gen.formatClass(dtSink.getClassName()) + " " + FLD_SINK + ';');
        
        DataType dtBase  = getIntegrateeType();
        Field    fldFeed = clzf.addField(FLD_FEED, dtBase.getJVMSignature());
        fldFeed.setPrivate();
        
        gen.println("private " + gen.formatType(dtBase) + " " + FLD_FEED + ';');
        }
    
    // Declared at the super level
    /**
    * Load a reference to the component's SINK or FEED on the stack.
    * 
    * @param gen  current ClassGenerator
    * @param vL_this  current "this" variable reference
    * @param nPeerId  one of PEER_FEED or PEER_SINK
    * 
    * @return  the name of the appropriate field or an access method that
    * should be used for the Java listing.
    * 
    * @see #generateMethodRouter
    */
    protected String addPeerAccess(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.assembler.Avar vL_this, int nPeerId)
            throws com.tangosol.dev.component.ComponentException
        {
        ClassFile      clzf  = gen.getClassFile();
        CodeAttribute  code  = gen.getCode();
        String         sPeer = nPeerId == PEER_SINK ? FLD_SINK : FLD_FEED;
        
        code.add(new Aload(vL_this));
        code.add(new Getfield(clzf.getFieldConstant(sPeer)));
        
        return sPeer;
        }
    
    protected void addSetSinkPreamble(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.assembler.Method method, com.tangosol.dev.assembler.Avar vL_this, com.tangosol.dev.assembler.Avar vL_prm)
        {
        // import Component.Dev.Compiler.Remoter;
        
        if (isRemote())
            {
            getRemoter().addSetSinkPreamble(gen, method, vL_this, vL_prm);
            }

        }
    
    /**
    * Finalize feed generation.  Subclasses of AbstartBean's usually override
    * this method to add any additional fields or methods to the feed.
    * 
    * @see generateFeed()
    */
    protected void finalizeFeed(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Design.Class as ClassInfo;
        // import Component.Dev.Compiler.Remoter;
        
        // allow remoter to do it's part
        if (isRemote())
            {
            getRemoter().generateFeed(gen);
            }
        
        // allow class specific adjustments be made
        String sFeedBase = getIntegrateeType().getClassName();
        ((ClassInfo) ClassInfo.getClassInfo(sFeedBase)).adjustFeed(gen);
        }
    
    // Declared at the super level
    /**
    * Generate the classes needed to "expose" this component for the external
    * use.
    * 
    * The package name and the base name to use for all classes is indicated,
    * in addition to an enumeration which specifies the type of class to
    * expose.  The type can indicate to expose either the component's feed, or
    * remote classes.
    * 
    * @param gen   the ClassGenerator used to generate the class
    * @param sPackage the Java package name to expose all classes under
    * @param sName   the base name of all exposed classes within the package
    * @param iType  indicates what classes to generate (EXPOSE_AUTO,
    * EXPOSE_FEED, EXPOSE_REMOTE)
    * @param fStore if true then the generated classes and listing will be
    * stored in the storage
    * 
    * @return a list of ClassGenerator$ClassInfo components for all generated
    * classes.
    */
    public java.util.List generateExposedClasses(_package.component.dev.compiler.ClassGenerator gen, String sPackage, String sName, int iType, boolean fStore)
            throws com.tangosol.dev.component.ComponentException
        {
        return isRemote()
               && iType == ClassGenerator.EXPOSE_REMOTE
            ? getRemoter().generateExposedClasses(gen, sPackage, sName, fStore)
            : null;

        }
    
    /**
    * Feed generation.
    * 
    * The AbstractBean model "almost" knows how to create the feed -- there are
    * two methods that should be filled in by the derived models (like JavaBean
    * and OwnedBean):
    *     - generateActiveFeedConstructor()
    *     - generatePassiveFeedConstructor()
    * 
    * @param cdIntegrator  the integrator component
    */
    protected void generateFeed(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import java.util.Collection;
        // import java.util.Iterator;
        // import java.util.Enumeration;
        
        Component  cdIntegrator    = gen.getCD();
        DataType   dtFeed          = getFeedType();
        DataType   dtIntegrator    = DataType.getComponentType(cdIntegrator.getQualifiedName());
        DataType   dtFeedBase      = getIntegrateeType();
        String     sFeedBase       = dtFeedBase.getClassName();
        Component  jcsIntegratee   = gen.getStorage().loadSignature(sFeedBase);
        String     sFeedName       = gen.formatClass(dtFeed.getClassName());
        DataType   dtSink          = getSinkCallbackType();
        String     sSinkName       = gen.formatClass(dtSink.getClassName());
        String     sIntegratorName = cdIntegrator.getName();
        Collection colImplements   = getRoutedInterfaces(gen);
        
        gen.println("/* Class"                                       );
        gen.println("*      " + gen.formatType(dtFeed)               );
        gen.println("*"                                              );
        gen.println("* automatically generated \"Feed\" which"       );
        gen.println("* a) extends an external bean:"                 );
        gen.println("*      " + sFeedBase                            );
        gen.println("* b) delegates to the peer component:"          );
        gen.println("*      " + cdIntegrator.getQualifiedName()      );
        gen.println("*/"                                             );
        
        gen.println();
        gen.println("package " + gen.formatClass(
            DataType.getComponentPackage(cdIntegrator), true) + ';');
        
        ClassFile clzFeed = new ClassFile(dtFeed.getClassName(), sFeedBase, false);
        
        gen.setClassFile(clzFeed);
        
        clzFeed.setPublic();
        
        gen.println();
        gen.print("public class " + sFeedName);
        if (dtFeedBase != DataType.OBJECT)
            {
            gen.println();
            gen.print("        extends    " + gen.formatType(dtFeedBase));
            }
        
        Iterator iter   = colImplements.iterator();
        boolean  fFirst = true;
        boolean  fDone  = false;
        do
            {
            String sInterface;
            if (iter.hasNext())
                {
                sInterface = (String) iter.next();
                }
            else
                {
                sInterface = COMPONENT_PEER;
                fDone = true;
                }
            clzFeed.addImplements(sInterface);
            if (fFirst)
                {
                fFirst = false;
                gen.println();
                gen.print("        implements ");
                }
            else
                {
                gen.println(",");
                gen.print("                   ");
                }
            gen.print(sInterface);
            }
            while (!fDone);
        
        gen.println();
        
        gen.BeginSegment(null);
        
        // add static field
        
        gen.println("// thread local storage for component peer during");
        gen.println("// the integratee and component peer initialization");
        
        Field fld_tloPeer = clzFeed.addField(FLD_TLOPEER, 'L' + THREADLOCAL + ';');
        fld_tloPeer.setPackage();
        fld_tloPeer.setStatic(true);
        
        FieldConstant cR_tloPeer = clzFeed.getFieldConstant(FLD_TLOPEER);
        
        gen.println("static " + gen.formatClass(THREADLOCAL) + ' ' + FLD_TLOPEER + ';');
        
        // initialize the static field
            {
            Method method = clzFeed.addMethod(ClassGenerator.INITIALIZER_NAME, "()V");
            method.setStatic(true);
        
            gen.println("static");
        
            CodeAttribute code = gen.BeginSegment(method);
        
            code.add(new New(new ClassConstant(THREADLOCAL)));
            code.add(new Dup());
            MethodConstant cM_new = new MethodConstant(THREADLOCAL,
                ClassGenerator.CONSTRUCTOR_NAME, "()V");
            code.add(new Invokespecial(cM_new));
            code.add(new Putstatic(clzFeed.getFieldConstant(FLD_TLOPEER)));
        
            gen.println(FLD_TLOPEER + " = new " + THREADLOCAL + "();");
        
            code.add(new Return());
            gen.EndSegment(method);
            }
        
        // add instance field
        gen.println();
        gen.println("// component peer (integrator) accessible from sub-classes");
        
        Field fldPeer = clzFeed.addField(FLD_PEER, dtIntegrator.getJVMSignature());
        fldPeer.setProtected();
        
        FieldConstant cR_peer = clzFeed.getFieldConstant(FLD_PEER);
        
        gen.println("protected " + sIntegratorName + ' ' + FLD_PEER + ';');
        
        // Make sure all integrated/routed properties exist
        
        fFirst = true;
        for (Enumeration enum = getMappedProperties(); enum.hasMoreElements();)
            {
            String   sProperty = (String) enum.nextElement();
            Property property  = cdIntegrator.getProperty(sProperty);
            if (property == null)
                {
                // This can happen in sub-Components when both the
                // accessors of the property integrated in a super-
                // Component are private.
                continue;
                }
            DataType dtProperty = property.getDataType();
            String   sField     = getMappedField(sProperty);
            Property field      = jcsIntegratee.getProperty(sField);
        
            if (field == null)
                {
                if (fFirst)
                    {
                    fFirst = false;
                    gen.println();
                    gen.println("// routed properties");
                    }
                Field fld = clzFeed.addField(sField, gen.resolveJVMSignature(dtProperty));
                fld.setPublic();
                gen.println("public " + fld.getTypeString() + ' ' + fld.getName() + ';');
                }
            else
                {
                if (field.getDataType() != dtProperty)
                    {
                    // TODO: soft code the error
                    String sMsg = 
                        "The \"" + sProperty + "\" field on the integrated " +
                        "class \"" + sFeedBase + "\" has a different data type " +
                        "than the same property on the Component and can not " +
                        "be integrated or routed.";
                    gen.addError(sMsg);
                    }
                }
            }
        
        // Generate constructors
        
        generateFeedActiveConstructor (gen);
        generateFeedPassiveConstructor(gen);
        
        // generate peer retriever (out of local storage)
            {
            Method method = clzFeed.addMethod(METH_RETRIEVE, "()" + dtIntegrator.getJVMSignature());
            method.setPrivate();
        
            gen.println();
            gen.println("private " + sIntegratorName + ' ' + METH_RETRIEVE + "()");
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
        
            Label lbl_peerNeNull = new Label();
        
            code.add(new Aload(vL_this));
            code.add(new Getfield(cR_peer));
            code.add(new Ifnonnull(lbl_peerNeNull));
        
            gen.println("if (" + FLD_PEER + " == null)");
        
            gen.BeginScope();
                {
                gen.println("// first call -- the peer must be in the thread local storage");
        
                code.add(new Aload(vL_this));
                code.add(new Getstatic(cR_tloPeer));
                MethodConstant cM_getObject = new MethodConstant(THREADLOCAL,
                    "getObject", "()Ljava.lang.Object;");
                code.add(new Invokevirtual(cM_getObject));
                code.add(new Checkcast(dtIntegrator.getClassConstant()));
                code.add(new Putfield(cR_peer));
        
                gen.println(FLD_PEER + " = (" + sIntegratorName + ") " +
                    FLD_TLOPEER + ".getObject();");
                
                gen.println();
                gen.println("// clean-up the storage");
        
                code.add(new Getstatic(cR_tloPeer));
                code.add(new Aconst());
                MethodConstant cM_setObject = new MethodConstant(THREADLOCAL,
                    "setObject", "(Ljava.lang.Object;)V");
                code.add(new Invokevirtual(cM_setObject));
        
                gen.println(FLD_TLOPEER + ".setObject(null);");
                
                gen.println();
                gen.println("// create the sink and notify the component peer");
        
                code.add(new Aload(vL_this));
                code.add(new Getfield(cR_peer));
                code.add(new New(dtSink.getClassConstant()));
                code.add(new Dup());
                code.add(new Aload(vL_this));
                MethodConstant cM_newSink = new MethodConstant(dtSink.getClassConstant(),
                    new SignatureConstant(ClassGenerator.CONSTRUCTOR_NAME, "(L" + dtFeed.getClassName() + ";)V"));
                code.add(new Invokespecial(cM_newSink));
                Behavior bhvrSetSink = gen.getKnownAccessor(ClassGenerator.PROP_SINK, Property.PA_SET_SINGLE);
                MethodConstant cM = gen.addMethodCall(bhvrSetSink);
        
                gen.println(FLD_PEER + '.' + cM.getName() +
                    "(new " + sSinkName + "(this));");
                }
            gen.EndScope();
        
            code.add(lbl_peerNeNull);
            code.add(new Aload(vL_this));
            code.add(new Getfield(cR_peer));
            code.add(new Areturn());
        
            gen.println("return " + FLD_PEER + ';');
            gen.EndSegment(method);
            }
        
        // dispatch the integration methods
        
        gen.println();
        gen.println("// methods integration and/or remoted");
        
        for (Enumeration enum = cdIntegrator.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
        
            String sMethodSig = getMappedMethod(bhvr.getSignature());
            if (sMethodSig != null || bhvr.isRemote())
                {
                String sMethodName = sMethodSig == null ?
                    bhvr.getName() : sMethodSig.substring(0, sMethodSig.indexOf('('));
        
                generateFeedRouter(gen, bhvr, sMethodName);
                }
            }
        
        // process each of the routed interfaces
        
        for (iter = colImplements.iterator(); iter.hasNext();)
            {
            String sInterface = (String) iter.next();
        
            gen.println();
            gen.println("// declared interface " + sInterface);
            Component jcsInterface = gen.getStorage().loadSignature(sInterface);
            _assert(jcsInterface != null);
        
            // Create each of the interface's methods that are
            // not already declared by the integratee class.
            // Even if a routed behavior doesn't exist we still need to
            // generate a default implementation.
        
            for (Enumeration enumBhvr = jcsInterface.getBehaviors(); enumBhvr.hasMoreElements();)
                {
                Behavior bhvr      = (Behavior) enumBhvr.nextElement();
                Behavior bhvrRoute = cdIntegrator.getBehavior(bhvr.getSignature());
        
                generateFeedRouter(gen,
                    bhvrRoute == null ? bhvr : bhvrRoute, bhvr.getName());
                }
            }
        
        // generate the ComponentPeer interface implementation
            {
            Method method = clzFeed.addMethod(METH_GET, "()Ljava.lang.Object;");
            method.setPublic();
        
            gen.println();
            gen.println("// interface " + gen.formatClass(COMPONENT_PEER));
            gen.println("public Object " + METH_GET + "()");
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
        
            code.add(new Aload(vL_this));
            MethodConstant cM_retrievePeer = new MethodConstant(getFeedType().getClassConstant(),
                new SignatureConstant(METH_RETRIEVE, "()" + dtIntegrator.getJVMSignature()));
            code.add(new Invokespecial(cM_retrievePeer));
            code.add(new Areturn());
        
            gen.println("return " + METH_RETRIEVE + "();");
            gen.EndSegment(method);
            }
        
        // let sub-classes add any additional feed fields or methods required
        finalizeFeed(gen);
        
        gen.EndSegment(null);
        
        gen.finalizeClassGeneration(true);
        }
    
    /**
    * Generates the constructor used by derived classes (i.e. JavaBeans
    * produced by this tool).
    * 
    * @see generateFeed()
    */
    protected void generateFeedActiveConstructor(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        throw new IllegalStateException(get_Name() + ".generateActiveFeedConstructor: " +
            "This model does not generate a feed");
        }
    
    /**
    * Generates the constructor used by the Component integrator to create a
    * Feed.
    * 
    * @see generateFeed()
    */
    protected void generateFeedPassiveConstructor(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        throw new IllegalStateException(get_Name() + ".generatePassiveFeedConstructor: " +
            "This model does not generate a feed");
        }
    
    /**
    * Generate a code that re-routes a call coming to the Feed onto the
    * Component peer and the call coming from the Sink onto the super class
    * (integratee).
    * 
    * @param gen ClassGenerator being used to generate the feed class
    * @param bhvr Behavior used to determine the return type and parameter
    * types of the method/behavior being routed
    * @param sMethName method name on the feed to create
    */
    public void generateFeedRouter(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr, String sMethName)
            throws com.tangosol.dev.component.ComponentException
        {
        // generate the Component Behavior signature and the feed
        // Method signature from the passed names and the passed
        // bhvr object signature
        String sBhvrName = bhvr.getName();
        String sBhvrSig  = bhvr.getSignature();
        String sMethSig  = sMethName + sBhvrSig.substring(sBhvrSig.indexOf('('));
        
        DataType  dtFeed        = getFeedType();
        String    sFeedBase     = getIntegrateeType().getClassName();
        Component jcsIntegratee = gen.getStorage().loadSignature(sFeedBase);
        
        Component cdIntegrator  = gen.getCD();
        DataType  dtIntegrator  = DataType.getComponentType(cdIntegrator.getQualifiedName());
        
        DataType  dtRet         = bhvr.getReturnValue().getDataType();
        ClassFile clzFeed       = gen.getClassFile();
        
        // make sure that we haven't already routed this one, this
        // can happen if a routed interface contains a method that
        // is also integrated, thus causing two calls to generateFeedRouter
        // for the same Behavior
        if (clzFeed.getMethod(sMethName, gen.resolveJVMSignature(bhvr)) != null)
            {
            return;
            }
        
        // get the component behavior and the feed method
        Behavior methIntegratee = jcsIntegratee.getBehavior(sMethSig);
        Behavior bhvrIntegrator = cdIntegrator.getBehavior(sBhvrSig);
        
        // if the integratee already declares the method and the
        // Component does not, then we do not have do anything
        // PJM: TODO: is this right???  What if the base class implements
        // PJM: a method that is later declared as a method of an interface ???
        if (methIntegratee != null && bhvrIntegrator == null)
            {
            return;
            }
        
        // let sub-classes suppress the implementation of any
        // behavior, currently used by EJB to suppress the generation
        // of the ejbFind<method>'s when Container Managed Persistant
        if (!isFeedRouterImplemented(gen, bhvr, sMethName))
            {
            return;
            }
        
        // if the method being routed exists on the integratee
        // class, check if the method is marked as final
        if (methIntegratee != null && methIntegratee.isFinal())
            {
            // TODO: soft code the warning
            String sMsg =
                "The \"" + sMethSig + "\" method on the integrated " +
                "class \"" + sFeedBase + "\" is a final method " +
                "and can not be overriden, making the component " +
                "implementation inaccessible from the feed.";
            gen.addWarning(sMsg);
            }
        else
            {
            String sName   = sMethName;
            int    iAccess = methIntegratee == null ? bhvr.getAccess() : methIntegratee.getAccess();
            if (isFeedRouterHidden(gen, bhvr))
                {
                sName   = sName + "$Router";
                iAccess = Behavior.ACCESS_PRIVATE;
                }
            // router to the component integrator
            Method method = gen.generateMethodHeader(bhvr, sName,
                iAccess, bhvr.isFinal(), false, bhvr.getExceptionNames());
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
        
            OpDeclare[] v_params = gen.addBehaviorParameters(bhvr);
        
            // check if the routed to behavior exists on the Component
            if (bhvrIntegrator == null)
                {
                // this normally occurs when a routed interface has
                // a method which the Component has not implemented
                gen.addDefaultReturn(dtRet);
                }
            else
                {
                code.add(new Aload(vL_this));
                FieldConstant cR_peer = clzFeed.getFieldConstant(FLD_PEER);
                code.add(new Getfield(cR_peer));
        
                // The "peer" local variable has been optimized out using the operand stack
                gen.println(gen.formatClass(dtIntegrator.getClassName()) +
                    " peer = " + cR_peer.getName() + ';');
        
                code.add(new Dup());
                Label lbl_peerNeNull = new Label();
                code.add(new Ifnonnull(lbl_peerNeNull));
        
                gen.print("if (peer == null)");
                    {
                    code.add(new Pop()); // get rid of saved peer
                    code.add(new Aload(vL_this));
                    MethodConstant cM_retrievePeer = new MethodConstant(dtFeed.getClassConstant(),
                        new SignatureConstant(METH_RETRIEVE, "()" + dtIntegrator.getJVMSignature()));
                    code.add(new Invokespecial(cM_retrievePeer));
                    // peer is now top operand
        
                    gen.println(" peer = " + METH_RETRIEVE + "();");
                    }
                code.add(lbl_peerNeNull);
        
                if (dtRet != DataType.VOID)
                    {
                    gen.print("return ");
                    }
        
                MethodConstant cM_route = gen.findMethod(bhvrIntegrator, false);
                gen.print("peer." + cM_route.getName() + '(');
                gen.addLoadParameters(bhvr, v_params);
                code.add(new Invokevirtual(cM_route));
                gen.println(");");
        
                code.add(gen.getReturnOp(dtRet));
                }
        
            gen.EndSegment(method);
            }
        
        // router to the super class, only if this is
        // an integrated method
        if (getMappedMethod(sBhvrSig) != null)
            {
            Method method = gen.generateMethodHeader(bhvr, ROUTER_PREFIX + sMethName,
                Behavior.ACCESS_PACKAGE, bhvr.isFinal(), false, bhvr.getExceptionNames());
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
        
            OpDeclare[] v_params = gen.addBehaviorParameters(bhvr);
        
            code.add(new Aload(vL_this));
        
            if (methIntegratee.isAbstract())
                {
                gen.addDefaultReturn(dtRet);
                }
            else
                {
                if (dtRet != DataType.VOID)
                    {
                    gen.print("return ");
                    }
        
                // given the "synchronized" attribute is set (aka ATTR_SUPER)
                // we don't have to be precise about the "declaring" super class.
                // However, the javac is trying to be precise, and so will we...
                MethodConstant cM_super = gen.findMethod(sFeedBase, sMethName,
                    gen.resolveJVMSignature(bhvr));
                if (cM_super == null)
                    {
                    throw new IllegalStateException(get_Name() + ".generateFeedRouter: " +
                        "Cannot find routed method " + sMethSig + " in " + sFeedBase);
                    }
        
                gen.print("super." + cM_super.getName() + '(');
        
                gen.addLoadParameters(bhvr, v_params);
        
                code.add(new Invokespecial(cM_super));
        
                gen.println(");");
        
                code.add(gen.getReturnOp(dtRet));
                }
            gen.EndSegment(method);
            }
        }
    
    // Declared at the super level
    /**
    * Generate an integration specific peer access optimization. Default
    * implementation does nothing.
    * 
    * @param bhvr  accessor behavior
    * @param sImplName  implementation name to use instead of bhvr.getName()
    * (synthetic)
    * @param fMainImpl  if true, the method is the "entry point" implementation
    * 
    * @return  generated method
    */
    public com.tangosol.dev.assembler.Method generateImplementation(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr, String sImplName, boolean fMainImpl)
            throws com.tangosol.dev.component.ComponentException
        {
        
        Behavior bhvrSetSink = gen.getKnownAccessor(ClassGenerator.PROP_SINK, Property.PA_SET_SINGLE);
        Behavior bhvrSetFeed = gen.getKnownAccessor(ClassGenerator.PROP_FEED, Property.PA_SET_SINGLE);
        
        String   sField;
        DataType dtField;
        String   sFieldClz;
        if (bhvr == bhvrSetSink)
            {
            sField    = FLD_SINK;
            dtField   = getSinkType();
            sFieldClz = gen.formatClass(dtField.getClassName());
            }
        else if (bhvr == bhvrSetFeed)
            {
            sField    = FLD_FEED;
            dtField   = getIntegrateeType();
            sFieldClz = gen.formatType(dtField);
            }
        else
            {
            throw new IllegalArgumentException(get_Name() + ".generateImplementation: " +
                "Unknown behavior " + bhvr);
            }
        
        boolean fObject = (dtField == DataType.OBJECT);
        
        ClassFile      clzf   = gen.getClassFile();
        Method         method = gen.generateMethodHeader(bhvr, sImplName,
            fMainImpl ? bhvr.getAccess() : Behavior.ACCESS_PRIVATE, bhvr.isFinal(), false, null);
        CodeAttribute  code   = gen.BeginSegment(method);
        String         sPrm   = bhvr.getParameter(0).getName();
        
        Avar vL_this = new Avar("this");
        Avar vL_prm  = new Avar(sPrm);
        FieldConstant cR_fld = clzf.getFieldConstant(sField);
        
        code.add(vL_this);
        code.add(vL_prm);
        
        if (bhvr == bhvrSetSink)
            {
            addSetSinkPreamble(gen, method, vL_this, vL_prm);
            }
        
        code.add(new Aload(vL_this));
        code.add(new Aload(vL_prm));
        if (!fObject)
            {
            code.add(new Checkcast(dtField.getClassConstant()));
            }
        code.add(new Putfield(cR_fld));
        
        gen.print(sField + " = ");
        if (!fObject)
            {
            gen.print("(" + sFieldClz + ") ");
            }
        gen.println(sPrm + ';');
        
        code.add(new Aload(vL_this));
        code.add(new Aload(vL_prm));
        MethodConstant cM_super = gen.findMethod(bhvr, true);
        code.add(new Invokespecial(cM_super));
        
        gen.println("super." + cM_super.getName() + '(' + sPrm + ");");
        
        code.add(new Return());
        gen.EndSegment(method);
        return method;
        }
    
    // Declared at the super level
    /**
    * Generate the integration specific extra classes.
    */
    public void generatePeer(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        Component cdIntegrator = gen.getCD();
        
        boolean fAbstract = cdIntegrator.isResultAbstract();
        boolean fRemote   = isRemote();
        
        if (!fAbstract)
            {
            ClassGenerator genSub = new ClassGenerator();
        
            genSub.setIntegrator(this);
            genSub.setCD(cdIntegrator);
            genSub.setParentGenerator(gen);
        
            generateFeed(genSub);
            }
        
        if (fRemote)
            {
            ClassGenerator genSub = new ClassGenerator();
        
            genSub.setIntegrator(this);
            genSub.setCD(cdIntegrator);
            genSub.setParentGenerator(gen);
        
            generateSinkInterface(genSub);
        
            getRemoter().generatePeer(gen);
            }
        
        if (!fRemote || !fAbstract)
            {
            ClassGenerator genSub = new ClassGenerator();
        
            genSub.setIntegrator(this);
            genSub.setCD(cdIntegrator);
            genSub.setParentGenerator(gen);
        
            generateSinkCallback(genSub);
            }
        }
    
    /**
    * Sink generation.
    * 
    * @param cdIntegrator the integrator component
    * @param sIntegratorClz  class name of the integrator
    */
    protected void generateSinkCallback(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.Integrator;
        // import java.util.Enumeration;
        
        Component cdIntegrator      = gen.getCD();
        boolean   fAbstract         = cdIntegrator.isAbstract();
        boolean   fRemote           = isRemote();
        Storage   storage           = gen.getStorage();
        DataType  dtSink            = getSinkType();
        DataType  dtSinkCallback    = getSinkCallbackType();
        DataType  dtFeed            = getFeedType();
        String    sFeedName         = gen.formatClass(dtFeed.getClassName());
        String    sFeedBase         = gen.formatType(getIntegrateeType());
        String    sSinkCallbackName = gen.formatClass(dtSinkCallback.getClassName());
        
        String    sSinkSuper        = "com.tangosol.run.component.CallbackSink";
        if (!fRemote)
            {
            // Find the closest super component that integrates something.
            // Assuming that the integration models are compatible,
            // the name of the super component and the integration signature
            // is all we need to generate the sink.
            String    sSuper = cdIntegrator.getSuperName();
            Component cdSuperIntegrator;
        
            while (true)
                {
                cdSuperIntegrator = storage.loadComponent(sSuper, true, null);
                Integrator integrator = gen.findIntegrator(cdSuperIntegrator);
                if (integrator != null)
                    {
                    sSinkSuper = integrator.getAutoGenClass(cdSuperIntegrator, PEER_SINK_CALLBACK);
                    break;
                    }
        
                sSuper = cdSuperIntegrator.getSuperName();
                if (sSuper.length() == 0)
                    {
                    // if we reached this far, cdSuperIntegrator is the root component
                    break;
                    }
                }
            }
        
        gen.println("/* Class"                                       );
        gen.println("*      " + gen.formatType(dtSinkCallback)       );
        gen.println("*"                                              );
        gen.println("* automatically generated \"Sink\" which"       );
        gen.println("* represents a footprint of the class"          );
        gen.println("*      " + sFeedBase                            );
        gen.println("* when used as a component callback by "        );
        gen.println("*      " + cdIntegrator.getQualifiedName()      );
        gen.println("*/"                                             );
        gen.println();
        
        gen.println("package " + gen.formatClass(
            DataType.getComponentPackage(cdIntegrator), true) + ';');
        
        ClassFile clzSink = new ClassFile(dtSinkCallback.getClassName(), sSinkSuper, false);
        
        gen.setClassFile(clzSink);
        
        clzSink.setPublic();
        clzSink.setAbstract(fAbstract);
        
        gen.println();
        gen.println("public " + (fAbstract ? "abstract " : "") + "class " + sSinkCallbackName);
        gen.println("       extends " + gen.formatClass(sSinkSuper));
        
        if (isRemote())
            {
            // The sink is an interface and the callback
            // implements that interface
            String sSink = dtSink.getClassName();
            clzSink.addImplements(sSink);
            gen.println("       implements " + gen.formatClass(sSink));
            }
        
        gen.BeginSegment(null);
        
        Field         fldPeer = null;
        FieldConstant cR_peer = null;
        
        if (!fAbstract)
            {
            fldPeer = clzSink.addField(FLD_PEER, dtFeed.getJVMSignature());
            fldPeer.setPrivate();
            cR_peer = clzSink.getFieldConstant(FLD_PEER);
        
            gen.println("private " + sFeedName + ' ' + FLD_PEER + ';');
            }
        
        // Generate default constructor used by sub-sinks
            {
            gen.println();
            gen.println("// this default (protected) constructor is used by sinks that extend this one");
            Method method = clzSink.addMethod(
                ClassGenerator.CONSTRUCTOR_NAME, "()V");
            method.setProtected();
        
            gen.println("protected " + sSinkCallbackName + "()");
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
        
            code.add(vL_this);
        
            // Call the super's default constructor
            code.add(new Aload(vL_this));
            MethodConstant cM_super = new MethodConstant(sSinkSuper,
                ClassGenerator.CONSTRUCTOR_NAME, "()V");
            code.add(new Invokespecial(cM_super));
        
            code.add(new Return());
            gen.EndSegment(method);
            }
        
        // Generate constructor used by the component peer (or feed)
        if (!fAbstract)
            {
            gen.println();
            gen.println("// this (protected) constructor is used by the feed");
        
            Method method = clzSink.addMethod(
                ClassGenerator.CONSTRUCTOR_NAME, "(L" + dtFeed.getClassName() + ";)V");
            method.setProtected();
        
            gen.println("protected " + sSinkCallbackName + '(' + sFeedName + " feed)");
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            Avar vL_feed = new Avar("feed");
        
            code.add(vL_this);
            code.add(vL_feed);
        
            // Call the super's default constructor
            code.add(new Aload(vL_this));
            MethodConstant cM_super = new MethodConstant(sSinkSuper,
                ClassGenerator.CONSTRUCTOR_NAME, "()V");
            code.add(new Invokespecial(cM_super));
        
            gen.println("super();");
        
            code.add(new Aload(vL_this));
            code.add(new Aload(vL_feed));
            code.add(new Putfield(cR_peer));
        
            gen.println(FLD_PEER + " = feed;");
        
            code.add(new Return());
            gen.EndSegment(method);
            }
        
        // Generate the get_Feed() method
        // (declared in com.tangosol.run.component.CallbackSink)
        if (!fAbstract)
            {
            gen.println();
            gen.println("// Retrieves the feed object for this sink");
        
            Method method = clzSink.addMethod("get_Feed", "()Ljava.lang.Object;");
            method.setPublic();
        
            gen.println("public Object get_Feed()");
        
            CodeAttribute code = gen.BeginSegment(method);
        
            Avar vL_this = new Avar("this");
            code.add(vL_this);
        
            code.add(new Aload(vL_this));
            code.add(new Getfield(cR_peer));
            code.add(new Areturn());
        
            gen.println("return " + FLD_PEER + ';');
            gen.EndSegment(method);
            }
        
        // Dispatch the integration methods --
        // we need to do this for all the methods, even including the ones that are
        // integrated at the super level, because the routing call is not virtual --
        // for a method "foo()" it goes into a package private method "super$foo()"
        // that in turn actually calls "super.foo()"
        
        gen.println();
        gen.println("// methods integrated and/or remoted");
        
        for (Enumeration enum = cdIntegrator.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
        
            String sMethSig = getMappedMethod(bhvr.getSignature());
            if (sMethSig != null)
                {
                generateSinkCallbackRouter(gen, bhvr, sMethSig, cR_peer, fAbstract);
                }
            else
                {
                // Check if this is an accessor of a routed field
                String sField = bhvr.getPropertyName();
                if (sField != null
                    && getRoutedProperties().contains(sField))
                    {
                    generateSinkCallbackAccessor(gen, bhvr, sField, cR_peer, fAbstract);
                    }
                else if (bhvr.isRemote())
                    {
                    // if it is not an integrated behavior or field and
                    // is a remoted method, generate a stub that throws
                    // an exception if it ever gets called
                    String sName  = bhvr.getName();
                    Method method = gen.generateMethodHeader(bhvr, sName,
                        Behavior.ACCESS_PUBLIC, bhvr.isFinal(), fAbstract, null);
                    if (!fAbstract)
                        {
                        CodeAttribute code = gen.BeginSegment(method);
                        code.add(new Avar("this"));
                        gen.addBehaviorParameters(bhvr);
                        gen.addThrow("java.lang.IllegalStateException",
                            "Unexpected call to remote method \\\"" + sName + "\\\" in callback sink", null);
                        gen.EndSegment(method);
                        }
                    }
                }
            }
        
        gen.EndSegment(null);
        
        gen.finalizeClassGeneration(true);
        }
    
    /**
    * Generate a code that re-routes a property access call coming to the Sink
    * onto the Feed (integratee).
    */
    private void generateSinkCallbackAccessor(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr, String sField, com.tangosol.dev.assembler.FieldConstant cR_peer, boolean fAbstract)
        {
        String sMethName = Property.getAccessorPrefix(bhvr.getSignature()) + sField;
        
        Method method = gen.generateMethodHeader(bhvr, sMethName,
            isRemote() ? Behavior.ACCESS_PUBLIC : bhvr.getAccess(),
            bhvr.isFinal(), fAbstract, null);
        
        if (fAbstract)
            {
            return;
            }
        
        Property prop = bhvr.getComponent().getProperty(bhvr.getPropertyName());
        if (prop == null)
            {
            throw new IllegalStateException("Property is missing for accessor " + bhvr);
            }
        
        if (prop.getIndexed() != Property.PROP_SINGLE)
            {
            throw new IllegalStateException(get_Name() +
                ".generateSinkCallbackAccessor: Unable to route an indexed property " + prop);
            }
        
        DataType dtProp = prop.getDataType();
        
        // The property we are processing could be:
        //     a) regular integrated field that exist on the integratee
        //     b) routed property that was added on the feed
        //
        DataType dtFieldBase = getRoutedProperties().contains(sField) ?
            getFeedType() : getIntegrateeType();
        
        FieldConstant cR_field = new FieldConstant(dtFieldBase.getClassConstant(),
            new SignatureConstant(sField, gen.resolveJVMSignature(dtProp)));
        
        CodeAttribute code = gen.BeginSegment(method);
                                        
        Avar vL_this = new Avar("this");
        code.add(vL_this);
        
        OpDeclare[] v_params = gen.addBehaviorParameters(bhvr);
        
        DataType dtRet = bhvr.getReturnValue().getDataType();
        
        code.add(new Aload(vL_this));
        code.add(new Getfield(cR_peer));
        
        if (dtRet != DataType.VOID)
            {
            // getter
            _assert(dtRet == dtProp);
            code.add(new Getfield(cR_field));
            code.add(gen.getReturnOp(dtRet));
        
            gen.println("return " + cR_peer.getName() + '.' + cR_field.getName() + ';');
            }
        else
            {
            // setter
            code.add(v_params[0].getLoadOp());
            code.add(new Putfield(cR_field));
            code.add(new Return());
        
            gen.println(cR_peer.getName() + '.' + cR_field.getName() + " = " +
                v_params[0].getVariableName() + ';');
            }
        
        gen.EndSegment(method);
        }
    
    /**
    * Generate a code that re-routes a method call coming to the Sink onto the
    * Feed (integratee).
    */
    private void generateSinkCallbackRouter(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr, String sMethSig, com.tangosol.dev.assembler.FieldConstant cR_peer, boolean fAbstract)
        {
        String sMethName = sMethSig.substring(0, sMethSig.indexOf('('));
        
        Method method = gen.generateMethodHeader(bhvr, sMethName,
            isRemote() ? Behavior.ACCESS_PUBLIC : bhvr.getAccess(),
            bhvr.isFinal(), fAbstract, bhvr.getExceptionNames());
        
        if (fAbstract)
            {
            return;
            }
        
        String sRouteClz   = getFeedType().getClassName();
        String sRouteName  = ROUTER_PREFIX + sMethName;
        CodeAttribute code = gen.BeginSegment(method);
        
        Avar vL_this = new Avar("this");
        code.add(vL_this);
        
        OpDeclare[] v_params = gen.addBehaviorParameters(bhvr);
        
        DataType dtRet = bhvr.getReturnValue().getDataType();
        
        if (dtRet != DataType.VOID)
            {
            gen.print("return ");
            }
        
        code.add(new Aload(vL_this));
        code.add(new Getfield(cR_peer));
        MethodConstant cM_route = new MethodConstant(sRouteClz, sRouteName,
            gen.resolveJVMSignature(bhvr));
        
        gen.print(cR_peer.getName() + '.' + sRouteName + '(');
        
        gen.addLoadParameters(bhvr, v_params);
        
        code.add(new Invokevirtual(cM_route));
        
        gen.println(");");
        
        code.add(gen.getReturnOp(dtRet));
        gen.EndSegment(method);

        }
    
    /**
    * Generates the "sink" interface -- the set of methods used by the
    * integrator component route methods out of the component.
    */
    protected void generateSinkInterface(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.Integrator;
        // import Component.Dev.Storage;
        // import java.util.Enumeration;
        
        Component cdIntegrator       = gen.getCD();
        Storage   storage            = gen.getStorage();
        DataType  dtSinkInterface    = getSinkType();
        String    sSinkInterfaceName = gen.formatClass(dtSinkInterface.getClassName());
        String    sSinkInterfaceSuper;
        
        // Find the closest super component that integrates something.
        // Assuming that the integration models are compatible,
        // the name of the super component and the integration signature
        // is all we need to generate the sink.
        
        // We currently assume that all subs of a remote super are also
        // remote, so this really doesn't have to be in a loop to find the
        // first super.  I left it this way for if this assumption changes.
        
        String    sSuper   = cdIntegrator.getSuperName();
        Component cdSuperIntegrator;
        
        while (true)
            {
            cdSuperIntegrator = storage.loadComponent(sSuper, true, null);
            Integrator integrator = gen.findIntegrator(cdSuperIntegrator);
            if (integrator != null)
                {
                if (integrator.isRemote())
                    {
                    sSinkInterfaceSuper = getAutoGenClass(cdSuperIntegrator, PEER_SINK);
                    break;
                    }
                }
        
            sSuper = cdSuperIntegrator.getSuperName();
            if (sSuper.length() == 0)
                {
                // if we reached this far, cdSuperIntegrator is the root component
                sSinkInterfaceSuper = "com.tangosol.run.component.RemoteSink";
                break;
                }
            }
        
        gen.println("/* Interface"                                      );
        gen.println("*      " + gen.formatType(dtSinkInterface)         );
        gen.println("*"                                                 );
        gen.println("* automatically generated \"interface Sink\""      );
        gen.println("* which defines the set of methods used by the"    );
        gen.println("*     " + cdIntegrator.getQualifiedName()          );
        gen.println("* component to route methods out of the component" );
        gen.println("*/"                                                );
        gen.println();
        
        gen.println("package " + gen.formatClass(
            DataType.getComponentPackage(cdIntegrator), true) + ';');
        
        ClassFile clzSinkInterface = new ClassFile(dtSinkInterface.getClassName(), "java.lang.Object", true);
        
        gen.setClassFile(clzSinkInterface);
        
        clzSinkInterface.setPublic();
        clzSinkInterface.setAbstract(true);
        clzSinkInterface.addImplements(sSinkInterfaceSuper);
        
        gen.println();
        gen.println("public interface " + sSinkInterfaceName);
        gen.println("         extends " + gen.formatClass(sSinkInterfaceSuper));
        
        gen.BeginSegment(null);
        
        // Dispatch the integration and routed methods --
        // we only have to add new methods since we are only defining
        // the interface and we already extend our super.
        
        for (Enumeration enum = cdIntegrator.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
        
            String sSignature    = bhvr.getSignature();
            String sMappedMethod = getMappedMethod(sSignature);
            if (sMappedMethod != null)
                {
                gen.println(bhvr.isRemote() ?
                    "// integrated and remoted method" : "// integrated method");
        
                sMappedMethod = sMappedMethod.substring(0, sMappedMethod.indexOf('('));
                gen.generateMethodHeader(bhvr, sMappedMethod,
                    Behavior.ACCESS_PUBLIC, false, true, null);
                }
            else
                {
                // Check if this is an accessor of a routed field
                String sField = bhvr.getPropertyName();
                if (sField != null && getRoutedProperties().contains(sField))
                    {
                    gen.println(bhvr.isRemote() ?
                        "// routed and remoted property accessor" : "// routed property accessor");
        
                    sMappedMethod = Property.getAccessorPrefix(sSignature) + sField;
                    gen.generateMethodHeader(bhvr, sMappedMethod,
                        Behavior.ACCESS_PUBLIC, false, true, null);
                    }
                else if (bhvr.isRemote())
                    {
                    gen.println("// remoted method");
        
                    sMappedMethod = sSignature.substring(0, sSignature.indexOf('('));
                    gen.generateMethodHeader(bhvr, sMappedMethod,
                        Behavior.ACCESS_PUBLIC, false, true, null);
                    }
                }
            }
        
        gen.EndSegment(null);
        
        gen.finalizeClassGeneration(true);
        }
    
    // Declared at the super level
    /**
    * Generate an integration specific implementation (routing) for the
    * specified behavior.  This implementation will be placed at the beginning
    * of the implementation chain, as opposed to generateMethodRouter which is
    * placed at the end of the implementation chain.
    * 
    * The current use of this is to facilitate routing the method off to a
    * remote, server based version of the method.
    * 
    * @param gen the ClassGenerator being used to generate the code
    * @param bhv  behavior that we are pre-routing (the target method has
    * identical signature)
    * @param method the ClassFile method to place the pre-routing code into
    * @param methodSuper the ClassFile method used when the super of the
    * current method is called
    */
    public void generateStubRouter(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr, com.tangosol.dev.assembler.Method method, com.tangosol.dev.assembler.Method methodSuper)
        {
        if (!isRemote()
            || !bhvr.isRemote())
            {
            throw new IllegalStateException("Call in generateStubRouter when not remote");
            }
        
        if (bhvr.isStatic())
            {
            throw new IllegalStateException("Cannot remote static behavior " + bhvr);
            }
        
        ClassFile      clzf       = gen.getClassFile();
        DataType       dtSink     = getSinkType();
        FieldConstant  cR_feed    = clzf.getFieldConstant(FLD_FEED);
        FieldConstant  cR_sink    = clzf.getFieldConstant(FLD_SINK);
        DataType       dtRet      = bhvr.getReturnValue().getDataType();
        CodeAttribute  code       = gen.BeginSegment(method);
        String         sSignature = bhvr.getSignature();
        String         sMapped    = getMappedMethod(sSignature);
        
        if (sMapped != null)
            {
            sMapped = sMapped.substring(0, sMapped.indexOf('('));
            }
        else
            {
            sMapped = bhvr.getName();
            }
        
        Avar vL_this = new Avar("this");
        code.add(vL_this);
        
        OpDeclare[] v_params = gen.addBehaviorParameters(bhvr);
        
        Label lbl_FeedNotNull = new Label();
        Label lbl_SinkNull    = new Label();
        
        code.add(new Aload(vL_this));
        code.add(new Getfield(cR_feed));
        code.add(new Ifnonnull(lbl_FeedNotNull));
        gen.println("if (" + FLD_FEED + " == null");
        
        code.add(new Aload(vL_this));
        code.add(new Getfield(cR_sink));
        code.add(new Dup()); // save a copy of the sink on the stack
        code.add(new Ifnull(lbl_SinkNull));
        gen.println("    && " + FLD_SINK + " != null)");
        
        gen.BeginScope();
            {
            if (dtRet != DataType.VOID)
                {
                gen.print("return ");
                }
        
            // sink is already first operand on stack
            gen.print(FLD_SINK + '.' + sMapped + '(');
        
            gen.addLoadParameters(bhvr, v_params);
                
            InterfaceConstant cI_route = new InterfaceConstant(dtSink.getClassConstant(),
                new SignatureConstant(sMapped, gen.resolveJVMSignature(bhvr)));
            code.add(new Invokeinterface(cI_route));
            code.add(gen.getReturnOp(dtRet));
        
            gen.println(");");
        
            if (dtRet == DataType.VOID)
                {
                gen.println("return;");
                }
            }
        gen.EndScope();
        
        code.add(lbl_SinkNull);
        code.add(new Pop()); // need to get rid of saved copy if sink
        code.add(lbl_FeedNotNull);
        
        _assert(methodSuper != null, "must be a synthetic super");
        
        if (dtRet != DataType.VOID)
            {
            gen.print("return ");
            }
               
        code.add(new Aload(vL_this));
        
        gen.print(methodSuper.getName() + '(');
        
        gen.addLoadParameters(bhvr, v_params);
                
        MethodConstant cM_super = new MethodConstant(clzf.getName(),
                methodSuper.getName(), methodSuper.getType());
        code.add(methodSuper.isPrivate() ?
               (Op) new Invokespecial(cM_super) : (Op) new Invokevirtual(cM_super));
        code.add(gen.getReturnOp(dtRet));
        
        gen.println(");");
        
        gen.EndSegment(method);
        }
    
    // Declared at the super level
    /**
    * Returns a class name that this Integrator generates for the specified
    * component and specified peer type.
    * 
    * @param cd  Component Definition for which a peer is being generated
    * @param nPeerId  type of the peer (one of PEER_FEED, PEER_SINK or another
    * type defined by a sub component)
    * 
    * @return the class name for the specified peer
    * Get a name of an auto-generated Feed or Sink class for the specified
    * component.
    * 
    * @param cd  Component Definition
    * @param nPeerId  one of PEER_FEED or PEER_SINK
    */
    public String getAutoGenClass(com.tangosol.dev.component.Component cd, int nPeerId)
        {
        String sPrefix;
        
        switch (nPeerId)
            {
            case PEER_SINK_CALLBACK:
                if (isRemote())
                    {
                    sPrefix = "ejbCallback";
                    break;
                    }
                // fall into same as sink
            case PEER_SINK:
                sPrefix = "sink";
                break;
        
            default:
                throw new IllegalStateException(get_Name() + ".getAutoGenClass: " +
                    "This model does not generate a feed " + nPeerId);
            }
        
        return DataType.getComponentPackage(cd) + '.' + sPrefix + '_' + cd.getName();
        }
    
    // Accessor for the property "Remoter"
    /**
    * Getter for property Remoter.<p>
    */
    public _package.component.dev.compiler.Remoter getRemoter()
        {
        return __m_Remoter;
        }
    
    /**
    * Return a list of interfaces that should be forced onto the feed.
    * 
    * @see #generateFeed
    */
    protected java.util.Collection getRoutedInterfaces(_package.component.dev.compiler.ClassGenerator gen)
            throws com.tangosol.dev.component.ComponentException
        {
        // import com.tangosol.util.LiteSet;
        // import java.util.Enumeration;
        // import java.util.StringTokenizer;
        
        LiteSet setIface = new LiteSet();
        
        String sList = getIntegrationMiscProperty("interface", null);
        if (sList != null)
            {
            Storage storage  = gen.getStorage();
        
            for (StringTokenizer tokens = new StringTokenizer(sList, " ,"); tokens.hasMoreTokens();)
                {
                String sIface = tokens.nextToken();
                
                if (sIface.length() > 0)
                    {
                    if (storage.loadSignature(sIface) == null)
                        {
                        gen.getErrorList().addWarning(
                            "Invalid interface reference in the \"Misc\" attribute of the integration map: " +
                            sIface);
                        }
                    else
                        {
                        setIface.add(sIface);
                        }
                    }
                }
            }
        
        if (isRemote())
            {
            getRemoter().addRoutedInterfaces(gen, setIface);
            }
        
        return setIface;

        }
    
    // Declared at the super level
    /**
    * Return a list of properties that are routed between the component and the
    * feed.
    * 
    * @see #setCDAndMap
    * @see #RoutedProperties property
    */
    protected java.util.Collection getRoutedProperties(_package.component.dev.compiler.ClassGenerator gen)
        {
        // import Component.Dev.Compiler.Remoter;
        // import java.util.Collection;
        
        Collection colRoutedProperties = super.getRoutedProperties(gen);
        
        if (isRemote())
            {
            getRemoter().addRoutedProperties(gen, colRoutedProperties);
            }
        
        return colRoutedProperties;

        }
    
    // Declared at the super level
    /**
    * Gets the routing method for the specified method 
    * 
    * @param gen  current ClassGenerator
    * @param sMethName  method's name
    * @param sMethSig  method's JVM signature
    * 
    * @see #generateMethodRouter
    */
    protected com.tangosol.dev.assembler.MethodConstant getRoutingMethod(_package.component.dev.compiler.ClassGenerator gen, String sMethName, String sMethSig)
        {
        // since this methods could only be called for methods in the
        // integration map that do not exist at the super component,
        // we can safely assume that the method has been generated for
        // the synthetic sink class
        
        DataType dtSink = getSinkType();
        
        if (isRemote())
            {
            return new InterfaceConstant(dtSink.getClassConstant(),
                new SignatureConstant(sMethName, sMethSig));
            }
        else
            {
            return new MethodConstant(dtSink.getClassConstant(),
                new SignatureConstant(sMethName, sMethSig));
            }
        

        }
    
    // Accessor for the property "SinkCallbackType"
    /**
    * Getter for property SinkCallbackType.<p>
    * The data type of the implementation class used to implement the call back
    * sink.  For most abstract bean generations, this is the same as the
    * SinkType.  Remote implementations use an interface data type for the
    * SinkType, and set the SinkCallbackType to the class that implements the
    * SinkType interface.
    */
    public com.tangosol.dev.component.DataType getSinkCallbackType()
        {
        return __m_SinkCallbackType;
        }
    
    /**
    * Return true if the behavior's feed router should be created under a
    * "hidden" name.  This is used by the EJB router to create it's own
    * implementation of the feed router, which then calls the one generated by
    * AbstractBean.
    */
    protected boolean isFeedRouterHidden(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.Remoter;
        
        if (isRemote())
            {
            if (getRemoter().isFeedRouterHidden(gen, bhvr))
                {
                return true;
                }
            }
        
        return false;

        }
    
    /**
    * Specify whether the specified behavior should be generated in the feed. 
    * Allows sub-classes suppress the implementation of behaviors in the feed. 
    * Currently used by EJB to suppress the generation of the ejbFind<method>'s
    * when Container Managed Persistent.
    * 
    * @param gen ClassGenerator used to generate the code
    * @param bhvr behavior in question
    * @param sMethName  routed method name 
    * 
    * @return true if the behavior should be generated, flase otherwise
    * 
    * @see generateFeedRouter()
    */
    protected boolean isFeedRouterImplemented(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Behavior bhvr, String sMethName)
            throws com.tangosol.dev.component.ComponentException
        {
        // import Component.Dev.Compiler.Remoter;
        
        if (isRemote())
            {
            if (!getRemoter().isFeedRouterImplemented(gen, bhvr, sMethName))
                {
                return false;
                }
            }
        
        return true;

        }
    
    // Declared at the super level
    public void setCDAndMap(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.component.Component cd, com.tangosol.dev.component.Integration map)
        {
        // import Component.Dev.Compiler.Remoter;
        // import java.util.List;
        
        if (cd.isRemote())
            {
            // Hard code to EJB for now...
            setRemoter(new Remoter.EJB());
            setRemote(true);
            }
        
        // This must be last to allow getRoutedProperties to work
        super.setCDAndMap(gen, cd, map);
        
        List list = getAutoGenBehaviors();
        
        list.add(gen.getKnownAccessor(gen.PROP_SINK, Property.PA_SET_SINGLE).getSignature());
        list.add(gen.getKnownAccessor(gen.PROP_FEED, Property.PA_SET_SINGLE).getSignature());
        
        super.setCDAndMap(gen, cd, map);
        
        if (cd.isResultAbstract())
            {
            // Abstract classes don't generate the Feed class, but refer
            // the one specified in the integration map instead
        
            setFeedType(getIntegrateeType());
            }
        else
            {
            String sFeedClz = getAutoGenClass(cd, PEER_FEED);
            setFeedType(DataType.getClassType(sFeedClz.replace('/', '.')));
            }
        
        if (true)
            {
            String sSinkClz = getAutoGenClass(cd, PEER_SINK);
            setSinkType(DataType.getClassType(sSinkClz.replace('/', '.')));
        
            String sSinkCallbackClz = getAutoGenClass(cd, PEER_SINK_CALLBACK);
            setSinkCallbackType(DataType.getClassType(sSinkCallbackClz.replace('/', '.')));
            }
        }
    
    // Accessor for the property "Remoter"
    /**
    * Setter for property Remoter.<p>
    */
    public void setRemoter(_package.component.dev.compiler.Remoter pRemoter)
        {
        __m_Remoter = pRemoter;
        }
    
    // Accessor for the property "SinkCallbackType"
    /**
    * Setter for property SinkCallbackType.<p>
    * The data type of the implementation class used to implement the call back
    * sink.  For most abstract bean generations, this is the same as the
    * SinkType.  Remote implementations use an interface data type for the
    * SinkType, and set the SinkCallbackType to the class that implements the
    * SinkType interface.
    */
    public void setSinkCallbackType(com.tangosol.dev.component.DataType pSinkCallbackType)
        {
        __m_SinkCallbackType = pSinkCallbackType;
        }
    }
