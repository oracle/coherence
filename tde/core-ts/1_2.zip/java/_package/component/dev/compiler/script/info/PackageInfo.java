/* Class
*     _package.component.dev.compiler.script.info.PackageInfo
*/

package _package.component.dev.compiler.script.info;

import com.tangosol.dev.component.Storage;
import com.tangosol.util.ChainedEnumerator;
import com.tangosol.util.SimpleEnumerator;
import com.tangosol.util.StringTable;
import java.util.Enumeration;

public class PackageInfo
        extends    _package.component.dev.compiler.script.Info
        implements com.tangosol.dev.compiler.PackageInfo
    {
    // Fields declarations
    
    /**
    * Property PackageName
    *
    */
    private transient String __m_PackageName;
    
    // Default constructor
    public PackageInfo()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PackageInfo(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new PackageInfo();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/compiler/script/info/PackageInfo".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.dev.compiler.PackageInfo
    // Declared at the super level
    public String getName()
        {
        String sPkg  = getPackageName();
        int    ofDot = sPkg.lastIndexOf('.');
        if (ofDot >= 0)
            {
            sPkg = sPkg.substring(ofDot + 1);
            }
        
        return sPkg;
        }
    
    // From interface: com.tangosol.dev.compiler.PackageInfo
    public com.tangosol.dev.compiler.PackageInfo getPackageInfo()
        {
        String sPkg  = getPackageName();
        int    ofDot = sPkg.lastIndexOf('.');
        if (ofDot < 0)
            {
            return null;
            }
        
        return getContext().getPackageInfo(sPkg.substring(0, ofDot));
        }
    
    // From interface: com.tangosol.dev.compiler.PackageInfo
    public com.tangosol.dev.compiler.PackageInfo getPackageInfo(String sPkg)
        {
        String sThisPkg = getPackageName();
        if (sThisPkg.length() > 0)
            {
            sPkg = sThisPkg + '.' + sPkg;
            }
        
        return getContext().getPackageInfo(sPkg);
        }
    
    // Accessor for the property "PackageName"
    public String getPackageName()
        {
        return __m_PackageName;
        }
    
    // From interface: com.tangosol.dev.compiler.PackageInfo
    public com.tangosol.dev.compiler.TypeInfo getTypeInfo(String sType)
        {
        String sPkg  = getPackageName();
        if (sPkg.length() > 0)
            {
            sType = sPkg + '.' + sType;
            }
        return getContext().getTypeInfo(sType);
        }
    
    // From interface: com.tangosol.dev.compiler.PackageInfo
    // Declared at the super level
    public boolean isPublic()
        {
        // all packages are public
        return true;
        }
    
    // From interface: com.tangosol.dev.compiler.PackageInfo
    public java.util.Enumeration packageNames()
        {
        // import com.tangosol.dev.component.Storage;
        // import com.tangosol.util.SimpleEnumerator;
        // import com.tangosol.util.ChainedEnumerator;
        // import com.tangosol.util.StringTable;
        // import java.util.Enumeration;
        
        final String CDROOT = "Component";
        
        Storage storage = getContext().getStorage();
        
        String sPkg = getPackageName();
        if (sPkg.length() <= 0)
            {
            // root package contains the root component "Component" and all Java packages
            Enumeration enumCD  = new SimpleEnumerator(new String[] {CDROOT});
        
            // root package contains Java packages
            StringTable tblNames = storage.getSignaturePackages("", false, false);
            Enumeration enumPkg = tblNames.keys();
        
            return new ChainedEnumerator(enumCD, enumPkg);
            }
        
        if (sPkg.equals(CDROOT) || sPkg.startsWith(CDROOT + '.'))
            {
            // enumerate derived components (which are themselves packages)
            StringTable tblNames = storage.getSubComponents(sPkg, false);
            return tblNames.keys();
            }
        
        // enumerate sub-packages
        StringTable tblNames = storage.getSignaturePackages(sPkg, false, false);
        return tblNames.keys();
        }
    
    // Accessor for the property "PackageName"
    public void setPackageName(String pPackageName)
        {
        __m_PackageName = pPackageName;
        }
    
    // From interface: com.tangosol.dev.compiler.PackageInfo
    public java.util.Enumeration typeNames()
        {
        // import com.tangosol.dev.component.Storage;
        // import com.tangosol.util.SimpleEnumerator;
        // import com.tangosol.util.ChainedEnumerator;
        // import com.tangosol.util.StringTable;
        // import java.util.Enumeration;
        
        final String CDROOT = "Component";
        
        Storage storage = getContext().getStorage();
        
        String sPkg = getPackageName();
        if (sPkg.length() <= 0)
            {
            // root package contains the root component "Component"
            Enumeration enumCD  = new SimpleEnumerator(new String[] {CDROOT});
        
            // root package may contain Java Class Signatures
            StringTable tblNames = storage.getPackageSignatures("", false);
            Enumeration enumClz = tblNames.keys();
        
            return new ChainedEnumerator(enumCD, enumClz);
            }
        
        if (sPkg.equals(CDROOT) || sPkg.startsWith(CDROOT + '.'))
            {
            // enumerate derived components
            StringTable tblNames = storage.getSubComponents(sPkg, false);
            return tblNames.keys();
            }
        
        // enumerate package of Java Class Signatures
        StringTable tblNames = storage.getPackageSignatures(sPkg, false);
        return tblNames.keys();
        }
    }
