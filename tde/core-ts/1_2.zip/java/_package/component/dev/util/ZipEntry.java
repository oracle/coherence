/* Class
*     _package.component.dev.util.ZipEntry
*/

package _package.component.dev.util;

/**
* This component represents a thin wrapper around java.util.zip.ZipEntry that
* unlike the java.util.zip.ZipEntry carries the reference back to the
* corresponding ZipFile. This component is usually used as an data element in a
* table carrying ZipEntries for different zip files.
*/
public class ZipEntry
        extends    _package.component.dev.Util
    {
    // Fields declarations
    
    /**
    * Property _ZipEntry
    *
    * Specifies a java.util.zip.ZipEntry object wrapped by this component.
    */
    private java.util.zip.ZipEntry __m__ZipEntry;
    
    /**
    * Property Folder
    *
    * (Calculated) Specifies this entry's folder (aka directory or package
    * name).
    */
    
    /**
    * Property InputStream
    *
    * (Calculated) Returns an input stream for reading the contents of this zip
    * file entry.
    */
    
    /**
    * Property Name
    *
    * (Calculated) Specifies this entry's name.
    */
    
    /**
    * Property Path
    *
    * (Calculated) Specifies this entry's fully specified path.
    */
    
    /**
    * Property ZipFile
    *
    */
    private java.util.zip.ZipFile __m_ZipFile;
    
    // Default constructor
    public ZipEntry()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ZipEntry(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ZipEntry();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/util/ZipEntry".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "_ZipEntry"
    public java.util.zip.ZipEntry get_ZipEntry()
        {
        return __m__ZipEntry;
        }
    
    // Accessor for the property "Folder"
    /**
    * Returns the entry's folder (aka directory)
    */
    public String getFolder()
        {
        String sPath = get_ZipEntry().getName();
        
        // the delimiter '/' is hard coded in the java.util.zip.ZipFile
        int of = sPath.lastIndexOf('/');
        
        return of < 0 ? "" : sPath.substring(0, of);
        }
    
    // Accessor for the property "InputStream"
    public java.io.InputStream getInputStream()
            throws java.io.IOException
        {
        return getZipFile().getInputStream(get_ZipEntry());
        }
    
    // Accessor for the property "Name"
    /**
    * Returns the entry's non qualified name.
    */
    public String getName()
        {
        String sName = get_ZipEntry().getName();
        
        // the delimiter '/' is hard coded in the java.util.zip.ZipFile
        int of = sName.lastIndexOf('/');
        
        return sName.substring(of + 1);

        }
    
    // Accessor for the property "Path"
    public String getPath()
        {
        return get_ZipEntry().getName();
        }
    
    // Accessor for the property "ZipFile"
    public java.util.zip.ZipFile getZipFile()
        {
        return __m_ZipFile;
        }
    
    public static ZipEntry instantiate(java.util.zip.ZipEntry _zipEntry, java.util.zip.ZipFile zipFile)
        {
        ZipEntry ze = (ZipEntry) ZipEntry.get_Instance();
        
        ze.set_ZipEntry(_zipEntry);
        ze.setZipFile(zipFile);
        
        return ze;
        }
    
    // Accessor for the property "_ZipEntry"
    protected void set_ZipEntry(java.util.zip.ZipEntry p_ZipEntry)
        {
        __m__ZipEntry = p_ZipEntry;
        }
    
    // Accessor for the property "ZipFile"
    protected void setZipFile(java.util.zip.ZipFile pZipFile)
        {
        __m_ZipFile = pZipFile;
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_ZipEntry().toString();
        }
    }
