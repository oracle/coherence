/* Class
*     _package.component.dev.util.traitLocator.componentLocator.BehaviorLocator
*/

package _package.component.dev.util.traitLocator.componentLocator;

import _package.component.dev.util.traitLocator.componentLocator.behaviorLocator.ImplementationLocator;

public class BehaviorLocator
        extends    _package.component.dev.util.traitLocator.ComponentLocator
    {
    // Fields declarations
    
    /**
    * Property BehaviorSignature
    *
    */
    private String __m_BehaviorSignature;
    
    /**
    * Property PREFIX_IMPLEMENTATION
    *
    * Prefix used to mark the "ImplementationId" part of a
    * ImplementationLocator.
    */
    protected static final char PREFIX_IMPLEMENTATION = 'I';
    
    // Default constructor
    public BehaviorLocator()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public BehaviorLocator(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setDescription("");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new BehaviorLocator();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/util/traitLocator/componentLocator/BehaviorLocator".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "BehaviorSignature"
    public String getBehaviorSignature()
        {
        return __m_BehaviorSignature;
        }
    
    // Declared at the super level
    public String getUniqueId()
        {
        return super.getUniqueId() + PREFIX_BEHAVIOR +
            getBehaviorSignature() + DELIM;
        }
    
    public static BehaviorLocator newBehaviorLocator(com.tangosol.dev.component.Behavior bhvr)
        {
        BehaviorLocator locator = new BehaviorLocator();
        locator.setComponentName(bhvr.getComponent().getQualifiedName());
        locator.setBehaviorSignature(bhvr.getSignature());
        return locator;

        }
    
    /**
    * This method is used to "deserialize" a BehaviorLocator by its data stored
    * as a String.
    */
    public static BehaviorLocator newBehaviorLocator(String sId)
        {
        // import Component.Dev.Util.TraitLocator.ComponentLocator.BehaviorLocator.ImplementationLocator;
        
        int ofNext = parseId(sId, null);
        
        if (ofNext == sId.length())
            {
            BehaviorLocator locator = new BehaviorLocator();
            parseId(sId, locator);
            return locator;
            }
        
        switch (sId.charAt(ofNext))
            {
            case PREFIX_IMPLEMENTATION:
                return ImplementationLocator.newImplementationLocator(sId);
            default:
                throw new IllegalArgumentException("BehaviorLocator" +
                    ".newBehaviorLocator: " + "Invalid id " + sId);
            }
        }
    
    // Declared at the super level
    /**
    * Parse an identifier. If the locator component is specified, initialize
    * (deserialize) it.
    * 
    * @return the offset after the parsed out portion of the id (after the
    * delimiter)
    */
    public static int parseId(String sId, _package.component.dev.util.TraitLocator locator)
        {
        int ofStart = _package.component.dev.util.traitLocator.ComponentLocator.parseId(sId, locator);
        
        _assert(sId.charAt(ofStart) == PREFIX_BEHAVIOR);
        
        int ofEnd = sId.indexOf(DELIM, ++ofStart);
        
        if (locator != null)
            {
            ((BehaviorLocator) locator).
                setBehaviorSignature(sId.substring(ofStart, ofEnd));
            }
        
        return ofEnd + 1;
        }
    
    // Accessor for the property "BehaviorSignature"
    public void setBehaviorSignature(String pBehaviorSignature)
        {
        __m_BehaviorSignature = pBehaviorSignature;
        }
    
    // Declared at the super level
    public String toString()
        {
        String sNameQ = getComponentName();
        String sNameU = sNameQ.substring(sNameQ.lastIndexOf('.') + 1);
        String sBhvrQ = getBehaviorSignature();
        String sBhvrU = sBhvrQ.substring(0, sBhvrQ.indexOf('('));
        return sNameU + '.' + sBhvrU + ": " + getDescription();
        }
    }
