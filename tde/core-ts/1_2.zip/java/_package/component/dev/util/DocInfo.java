/* Class
*     _package.component.dev.util.DocInfo
*/

package _package.component.dev.util;

import _package.component.dev.project.ProjectInfo$Target$Library; // as Library
import _package.component.dev.project.ProjectInfo$Target; // as Target
import _package.component.dev.project.ProjectInfo; // as Project
import com.tangosol.dev.component.Constants;

/**
* This component represents an information about a document stored by the
* Component Management system and showed by any document browser in this tool.
*/
public class DocInfo
        extends    _package.component.dev.Util
    {
    // Fields declarations
    
    /**
    * Property Customizable
    *
    * Calculated property that specifies whether the document represented by
    * this DocInfo is supposed to be customizable
    */
    
    /**
    * Property Name
    *
    * Specifies the name of the corresponding document.
    */
    private String __m_Name;
    
    /**
    * Property StorageLocator
    *
    * The locator object assosiated with the storage carrying the top-most
    * "delta" for this document (Component or Signature).
    */
    private Object __m_StorageLocator;
    
    /**
    * Property SubLocator
    *
    * The locator object assosiated with the storage carrying the top-most
    * "delta" for any of the sub components of this document (applicable for
    * Components only).
    */
    private Object __m_SubLocator;
    
    /**
    * Property Type
    *
    * Specifies the user defined type of the document refered by this DocInfo
    * component (in cases when there is no compelling reason to subclass the
    * DocInfo component).
    */
    private String __m_Type;
    
    // Default constructor
    public DocInfo()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public DocInfo(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new DocInfo();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/util/DocInfo".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        setName(config.getString(sPrefix + ".Name"));
        setType(config.getString(sPrefix + ".Type"));
        
        super.applyConfig(config, sPrefix);
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof DocInfo)
            {
            DocInfo infoThis = this;
            DocInfo infoThat = (DocInfo) obj;
        
            String sNameThis = infoThis.getName();
            String sTypeThis = infoThis.getType();
            String sNameThat = infoThat.getName();
            String sTypeThat = infoThat.getType();
            
            return (sNameThis == null ? sNameThat == null : sNameThis.equals(sNameThat))
                && (sTypeThis == null ? sTypeThat == null : sTypeThis.equals(sTypeThat));
            }
        else
            {
            return false;
            }
        }
    
    // Accessor for the property "Name"
    /**
    * Getter for property Name.<p>
    * Specifies the name of the corresponding document.
    */
    public String getName()
        {
        return __m_Name;
        }
    
    // Accessor for the property "StorageLocator"
    /**
    * Getter for property StorageLocator.<p>
    * The locator object assosiated with the storage carrying the top-most
    * "delta" for this document (Component or Signature).
    */
    public Object getStorageLocator()
        {
        return __m_StorageLocator;
        }
    
    // Accessor for the property "SubLocator"
    /**
    * Getter for property SubLocator.<p>
    * The locator object assosiated with the storage carrying the top-most
    * "delta" for any of the sub components of this document (applicable for
    * Components only).
    */
    public Object getSubLocator()
        {
        return __m_SubLocator;
        }
    
    // Accessor for the property "Type"
    /**
    * Getter for property Type.<p>
    * Specifies the user defined type of the document refered by this DocInfo
    * component (in cases when there is no compelling reason to subclass the
    * DocInfo component).
    */
    public String getType()
        {
        return __m_Type;
        }
    
    public static DocInfo instantiate(String sName, String sType)
        {
        DocInfo info = new DocInfo();
        
        info.setName(sName);
        info.setType(sType);
        
        return info;
        }
    
    // Accessor for the property "Customizable"
    /**
    * Getter for property Customizable.<p>
    * Calculated property that specifies whether the document represented by
    * this DocInfo is supposed to be customizable
    */
    public boolean isCustomizable()
        {
        // import Component.Dev.Project.ProjectInfo$Target$Library as Library;
        
        Object oLocator = getStorageLocator();
        
        return oLocator instanceof Library ?
            ((Library) oLocator).isCustomizable() : true;
        

        }
    
    /**
    * Return true iff the document described by this DocInfo has a non-empty
    * delta at any storage that belongs to the same project as the specified
    * project
    */
    public boolean isModifiedAtProject(_package.component.dev.project.ProjectInfo project)
        {
        // import Component.Dev.Project.ProjectInfo as Project;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Project.ProjectInfo$Target$Library as Library;
        
        Object oLocatorThis = getStorageLocator();
        
        Project prjThis = null;
        Project prjThat = project;
        
        if (oLocatorThis instanceof Target)
            {
            prjThis = ((Target) oLocatorThis).getProjectInfo();
            }
        else if (oLocatorThis instanceof Library)
            {
            prjThis = ((Library) oLocatorThis).getTargetInfo().getProjectInfo();
            }
        
        return prjThis != null && prjThat != null &&
            prjThis.getName().equals(prjThat.getName());

        }
    
    /**
    * Return true iff the document described by this DocInfo has a non-empty
    * delta at the storage that belongs to the specified sub-project
    */
    public boolean isModifiedAtSubproject(_package.component.dev.project.ProjectInfo$Target target)
        {
        Object oLocatorThis = getStorageLocator();
        Object oLocatorThat = target;
        
        return oLocatorThis != null && oLocatorThis.equals(oLocatorThat);
        }
    
    /**
    * Return true iff the document described by this DocInfo has a non-empty
    * delta for any of its sub components at the storage that belongs to the
    * same project as the specified project
    */
    public boolean isSubModifiedAtProject(_package.component.dev.project.ProjectInfo project)
        {
        // import Component.Dev.Project.ProjectInfo as Project;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Project.ProjectInfo$Target$Library as Library;
        
        Object oLocatorThis = getSubLocator();
        
        Project prjThis = null;
        Project prjThat = project;
        
        if (oLocatorThis instanceof Target)
            {
            prjThis = ((Target) oLocatorThis).getProjectInfo();
            }
        else if (oLocatorThis instanceof Library)
            {
            prjThis = ((Library) oLocatorThis).getTargetInfo().getProjectInfo();
            }
        
        return prjThis != null && prjThat != null &&
            prjThis.getName().equals(prjThat.getName());

        }
    
    /**
    * Return true iff the [Component Definition] document described by this
    * DocInfo has a non-empty delta for any of its sub components at the
    * storage that belongs to the specified sub-project
    */
    public boolean isSubModifiedAtSubproject(_package.component.dev.project.ProjectInfo$Target target)
        {
        Object oLocatorThis = getSubLocator();
        Object oLocatorThat = target;
        
        return oLocatorThis != null && oLocatorThis.equals(oLocatorThat);
        }
    
    /**
    * Returns true if the "Visibility" attribute of this document matches to
    * the value of the specified filter
    */
    public boolean isVisible(int nFilter)
        {
        // import Component.Dev.Project.ProjectInfo as Project;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Project.ProjectInfo$Target$Library as Library;
        // import com.tangosol.dev.component.Constants;
        
        Object oLocator    = getStorageLocator();
        int    nVisibility = Constants.VIS_VISIBLE;
        
        // first take the library's visibility
        if (oLocator instanceof Library)
            {
            nVisibility = ((Library) oLocator).getVisibility();
            }
        
        // second, "downgrade" inner names to ADVANCED
        // and synthetic names to HIDDEN
        if (nVisibility == Constants.VIS_VISIBLE ||
            nVisibility == Constants.VIS_ADVANCED)
            {
            String sName = getName();
            sName = sName.substring(sName.lastIndexOf('.') + 1);
        
            int ofInner = sName.indexOf('$');
            if (ofInner > 0)
                {
                ofInner++;
        
                int    of      = sName.indexOf('$', ofInner);
                String sInner  = of > 0 ?
                    sName.substring(ofInner, of) : sName.substring(ofInner);
                char  ch       = sInner.length() == 0 ? '0' : sInner.charAt(0);
        
                nVisibility = ch >= '0' && ch <= '9' ?
                    Constants.VIS_HIDDEN : Constants.VIS_ADVANCED;
                }
            }
        
        switch (nFilter)
            {
            case Constants.VIS_SYSTEM:
                return true;
            case Constants.VIS_HIDDEN:
                return nVisibility != Constants.VIS_SYSTEM;
            case Constants.VIS_ADVANCED:
                return  nVisibility == Constants.VIS_ADVANCED ||
                        nVisibility == Constants.VIS_VISIBLE;
            case Constants.VIS_VISIBLE:
            default:
                return nVisibility == Constants.VIS_VISIBLE;
            }

        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        config.putString(sPrefix + ".Name", getName());
        config.putString(sPrefix + ".Type", getType());
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "Name"
    /**
    * Setter for property Name.<p>
    * Specifies the name of the corresponding document.
    */
    public void setName(String pName)
        {
        __m_Name = pName;
        }
    
    // Accessor for the property "StorageLocator"
    /**
    * Setter for property StorageLocator.<p>
    * The locator object assosiated with the storage carrying the top-most
    * "delta" for this document (Component or Signature).
    */
    public void setStorageLocator(Object pStorageLocator)
        {
        __m_StorageLocator = pStorageLocator;
        }
    
    // Accessor for the property "SubLocator"
    /**
    * Setter for property SubLocator.<p>
    * The locator object assosiated with the storage carrying the top-most
    * "delta" for any of the sub components of this document (applicable for
    * Components only).
    */
    public void setSubLocator(Object pSubLocator)
        {
        __m_SubLocator = pSubLocator;
        }
    
    // Accessor for the property "Type"
    /**
    * Setter for property Type.<p>
    * Specifies the user defined type of the document refered by this DocInfo
    * component (in cases when there is no compelling reason to subclass the
    * DocInfo component).
    */
    public void setType(String pType)
        {
        __m_Type = pType;
        }
    
    // Declared at the super level
    public String toString()
        {
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Project.ProjectInfo$Target$Library as Library;
        
        String s = getName();
        
        Object oLocator = getStorageLocator();
        if (oLocator instanceof Target)
            {
            Target target = (Target) oLocator;
            s += " (" + target.getQualifiedName() + ')';
            }
        else if (oLocator instanceof Library)
            {
            Library lib = (Library) oLocator;
            s += " (" + lib.getName() + ')';
            }
        else if (oLocator instanceof String)
            {
            s = (String) oLocator;
            }
        return s;
        }
    }
