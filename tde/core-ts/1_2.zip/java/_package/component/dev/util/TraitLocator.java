/* Class
*     _package.component.dev.util.TraitLocator
*/

package _package.component.dev.util;

import _package.component.dev.util.traitLocator.ComponentLocator;

/**
* This Component serves as a "convertor" object that encodes a component trait
* into a string id and decodes a string id back into a component trait. The
* encoding could also include information that identifies a sub-trait (i.e. a
* line number of a behavior implementation).
* 
* Known subclasses of TraitLocator are ComponentLocator, SignatureLocator and
* IntegrationLocator.
* 
* Note that we do this despite the fact that Integration does not inherit from
* Trait at the moment.
*/
public class TraitLocator
        extends    _package.component.dev.Util
    {
    // Fields declarations
    
    /**
    * Property DELIM
    *
    * Delimiter used to seprate trait information in the UniqueId
    */
    protected static final char DELIM = '%';
    
    /**
    * Property Description
    *
    * Human readable description of this locator.
    */
    private String __m_Description;
    
    /**
    * Property PREFIX_COMPONENT
    *
    * Prefix used to mark the "ComponentId" part of a ComponentLocator.
    */
    protected static final char PREFIX_COMPONENT = 'C';
    
    /**
    * Property PREFIX_INTEGRATION
    *
    * Prefix used to mark the "IntegrationId" part of a IntegrationLocator.
    */
    protected static final char PREFIX_INTEGRATION = 'I';
    
    /**
    * Property PREFIX_SIGNATURE
    *
    * Prefix used to mark the "SignatureId" part of a SignatureLocator.
    */
    protected static final char PREFIX_SIGNATURE = 'S';
    
    /**
    * Property UniqueId
    *
    * This property serves as the "serialized" data representing a component
    * trait. The value of this property is not supposed to be in human readable
    * format.
    * 
    * The examples of possible values:
    * 
    * -- ComponentLocator for Component.GUI.Font CComponent.GUI.Font%
    * 
    * -- IntegrationLocator for java.awt.Font
    * Ijava.awt.Font%
    * 
    * -- BehaviorLocator for getSize() for Component.GUI.Font 
    * CComponent.GUI.Font%BgetSize()%
    * 
    * -- BehaviorLocator for offset 3 in line 5 of the first implementation of
    * getSize() for Component.GUI.Font
    * CComponent.GUI.Font%BgetSize()%I0#5#3%
    */
    
    // Default constructor
    public TraitLocator()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TraitLocator(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setDescription("");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new TraitLocator();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/util/TraitLocator".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "Description"
    public String getDescription()
        {
        return __m_Description;
        }
    
    // Accessor for the property "UniqueId"
    public String getUniqueId()
        {
        return "";
        }
    
    /**
    * This method is used to "deserialize" a TraitLocator by its data stored as
    * a String.
    */
    public static TraitLocator newTraitLocator(String sId)
        {
        // import Component.Dev.Util.TraitLocator.ComponentLocator;
        // import Component.Dev.Util.TraitLocator.IntegrationLocator;
        // import Component.Dev.Util.TraitLocator.SignatureLocator;
        
        switch (sId.charAt(0))
            {
            case PREFIX_COMPONENT:
                return ComponentLocator.newComponentLocator(sId);
            case PREFIX_INTEGRATION:
                // return IntegrationLocator.newIntegrationLocator(sId);
            case PREFIX_SIGNATURE:
                // return SignatureLocator.newSignatureLocator(sId);
            default:
                throw new IllegalArgumentException("TraitLocator" +
                    ".newTraitLocator: " + "Invalid id " + sId);
            }
        }
    
    /**
    * Parse an identifier. If the locator component is specified, initialize
    * (deserialize) it.
    * 
    * @return the offset after the parsed out portion of the id (after the
    * delimiter)
    */
    public static int parseId(String sId, TraitLocator locator)
        {
        return 0;
        }
    
    // Accessor for the property "Description"
    public void setDescription(String pDescription)
        {
        __m_Description = pDescription;
        }
    
    // Declared at the super level
    public String toString()
        {
        return getDescription();
        }
    }
