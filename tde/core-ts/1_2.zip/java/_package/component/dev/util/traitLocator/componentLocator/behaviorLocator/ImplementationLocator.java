/* Class
*     _package.component.dev.util.traitLocator.componentLocator.behaviorLocator.ImplementationLocator
*/

package _package.component.dev.util.traitLocator.componentLocator.behaviorLocator;

public class ImplementationLocator
        extends    _package.component.dev.util.traitLocator.componentLocator.BehaviorLocator
    {
    // Fields declarations
    
    /**
    * Property ImplementationPosition
    *
    */
    private transient int __m_ImplementationPosition;
    
    /**
    * Property Length
    *
    */
    private int __m_Length;
    
    /**
    * Property Line
    *
    */
    private transient int __m_Line;
    
    /**
    * Property Offset
    *
    */
    private transient int __m_Offset;
    
    /**
    * Property SEPARATOR
    *
    * Character used to separate the position, line number and offset in the
    * UniqueId
    */
    private static final char SEPARATOR = '#';
    
    // Default constructor
    public ImplementationLocator()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ImplementationLocator(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setDescription("");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ImplementationLocator();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/util/traitLocator/componentLocator/behaviorLocator/ImplementationLocator".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "ImplementationPosition"
    public int getImplementationPosition()
        {
        return __m_ImplementationPosition;
        }
    
    // Accessor for the property "Length"
    public int getLength()
        {
        return __m_Length;
        }
    
    // Accessor for the property "Line"
    public int getLine()
        {
        return __m_Line;
        }
    
    // Accessor for the property "Offset"
    public int getOffset()
        {
        return __m_Offset;
        }
    
    // Declared at the super level
    public String getUniqueId()
        {
        return super.getUniqueId()      + PREFIX_IMPLEMENTATION +
            getImplementationPosition() + SEPARATOR +
            getLine()                   + SEPARATOR +
            getOffset()                 + SEPARATOR +
            getLength()                 + DELIM;
        }
    
    public static ImplementationLocator newImplementationLocator(com.tangosol.dev.component.Implementation impl)
        {
        ImplementationLocator locator = new ImplementationLocator();
        locator.setComponentName(impl.getBehavior().getComponent().getQualifiedName());
        locator.setBehaviorSignature(impl.getBehavior().getSignature());
        locator.setImplementationPosition(impl.getPosition());
        return locator;

        }
    
    /**
    * This method is used to "deserialize" an ImpelmentationtLocator by its
    * data stored as a String.
    */
    public static ImplementationLocator newImplementationLocator(String sId)
        {
        int ofNext = parseId(sId, null);
        
        if (ofNext == sId.length())
            {
            ImplementationLocator locator = new ImplementationLocator();
            parseId(sId, locator);
            return locator;
            }
        
        switch (sId.charAt(ofNext))
            {
            default:
                throw new IllegalArgumentException("ImplementationLocator" +
                    ".newImplementationLocator: " + "Invalid id " + sId);
            }
        }
    
    // Declared at the super level
    /**
    * Parse an identifier. If the locator component is specified, initialize
    * (deserialize) it.
    * 
    * @return the offset after the parsed out portion of the id (after the
    * delimiter)
    */
    public static int parseId(String sId, _package.component.dev.util.TraitLocator locator)
        {
        int ofStart = _package.component.dev.util.traitLocator.componentLocator.BehaviorLocator.parseId(sId, locator);
        
        _assert(sId.charAt(ofStart) == PREFIX_IMPLEMENTATION);
        
        int ofEnd = sId.indexOf(DELIM, ++ofStart);
        
        if (locator != null)
            {
            int ofFrom = ofStart;
            int ofTo   = sId.indexOf(SEPARATOR, ofFrom);
            ((ImplementationLocator) locator).setImplementationPosition(
                Integer.parseInt(sId.substring(ofFrom, ofTo)));
        
            ofFrom = ofTo + 1;
            ofTo   = sId.indexOf(SEPARATOR, ofFrom);
            ((ImplementationLocator) locator).setLine(
                Integer.parseInt(sId.substring(ofFrom, ofTo)));
        
            ofFrom = ofTo + 1;
            ofTo   = sId.indexOf(SEPARATOR, ofFrom);
            ((ImplementationLocator) locator).setOffset(
                Integer.parseInt(sId.substring(ofFrom, ofTo)));
        
            ofFrom = ofTo + 1;
            ofTo   = sId.indexOf(SEPARATOR, ofFrom);
            ((ImplementationLocator) locator).setLength(
                Integer.parseInt(sId.substring(ofFrom, ofTo)));
            }
        
        return ofEnd + 1;
        }
    
    // Accessor for the property "ImplementationPosition"
    public void setImplementationPosition(int pImplementationPosition)
        {
        __m_ImplementationPosition = pImplementationPosition;
        }
    
    // Accessor for the property "Length"
    public void setLength(int pLength)
        {
        __m_Length = pLength;
        }
    
    // Accessor for the property "Line"
    public void setLine(int pLine)
        {
        __m_Line = pLine;
        }
    
    // Accessor for the property "Offset"
    public void setOffset(int pOffset)
        {
        __m_Offset = pOffset;
        }
    
    // Declared at the super level
    public String toString()
        {
        String sNameQ = getComponentName();
        String sNameU = sNameQ.substring(sNameQ.lastIndexOf('.') + 1);
        String sBhvrQ = getBehaviorSignature();
        String sBhvrU = sBhvrQ.substring(0, sBhvrQ.indexOf('('));
        return sNameU + '.' + sBhvrU + ':' + (getLine() + 1) + ": " + getDescription();
        }
    }
