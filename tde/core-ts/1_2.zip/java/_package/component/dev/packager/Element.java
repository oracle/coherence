/* Class
*     _package.component.dev.packager.Element
*/

package _package.component.dev.packager;

public abstract class Element
        extends    _package.component.dev.Packager
        implements com.tangosol.dev.packager.PackagerDependencyElement
    {
    // Fields declarations
    
    /**
    * Property PackageInfo
    *
    * Specifies the packaging information collected by the Packaging tool.
    */
    private transient PackageInfo __m_PackageInfo;
    
    /**
    * Property Storage
    *
    * Specifies the Storage component that serves as an interface to the
    * Component Management.
    */
    private transient _package.component.dev.Storage __m_Storage;
    
    // Initializing constructor
    public Element(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/Element".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.dev.packager.PackagerDependencyElement
    /**
    * Return the immediate dependents of this PackagerDependencyElement in the
    * context of the specified ClassLoader.
    */
    public java.util.List getDependents(ClassLoader classLoader)
        {
        return null;
        }
    
    // Accessor for the property "PackageInfo"
    public PackageInfo getPackageInfo()
        {
        return __m_PackageInfo;
        }
    
    // From interface: com.tangosol.dev.packager.PackagerDependencyElement
    /**
    * Return the direct PackagerEntries of this PackagerDependencyElement.
    */
    public java.util.List getPackagerEntries()
        {
        return null;
        }
    
    // Accessor for the property "Storage"
    public _package.component.dev.Storage getStorage()
        {
        return __m_Storage;
        }
    
    // Accessor for the property "PackageInfo"
    public void setPackageInfo(PackageInfo pPackageInfo)
        {
        __m_PackageInfo = pPackageInfo;
        }
    
    // Accessor for the property "Storage"
    public void setStorage(_package.component.dev.Storage pStorage)
        {
        __m_Storage = pStorage;
        }
    }
