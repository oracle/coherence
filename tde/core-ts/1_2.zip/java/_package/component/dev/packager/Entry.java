/* Class
*     _package.component.dev.packager.Entry
*/

package _package.component.dev.packager;

import java.util.Date;
import java.util.Properties;

/**
* This component represents a packager entry.<p>
* A Packager.Element component that creates a Packager.Entry component has an
* option of instantiating the Entry component itself and setting up the Data,
* ModificationTime, Path, Attributes and Comment or creating a subcomponent of
* the Entry component that overrides any of the corresponding getters.
*/
public class Entry
        extends    _package.component.dev.Packager
        implements com.tangosol.dev.packager.PackagerEntry
    {
    // Fields declarations
    
    /**
    * Property Attributes
    *
    * Specifies the map of attribute names to attribute values.
    */
    private transient java.util.Properties __m_Attributes;
    
    /**
    * Property Comment
    *
    * Specifies a comment for this Entry.
    */
    private transient String __m_Comment;
    
    /**
    * Property Data
    *
    * Specifies this Entry as binary data suitable for packager. 
    */
    private transient byte[] __m_Data;
    
    /**
    * Property Element
    *
    * Specifies an Element that "produced" this Entry.
    */
    private transient Element __m_Element;
    
    /**
    * Property ModificationTime
    *
    * Specifies the time when this Entry was last modified.
    */
    private transient long __m_ModificationTime;
    
    /**
    * Property Path
    *
    * Specifies a path for this Entry.
    */
    private com.tangosol.dev.packager.PackagerPath __m_Path;
    
    /**
    * Property Secured
    *
    * Specifies whether this entry should be "secured" in a package
    */
    private transient boolean __m_Secured;
    
    // Default constructor
    public Entry()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Entry(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Entry();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/Entry".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.dev.packager.PackagerEntry
    // Accessor for the property "Attributes"
    /**
    * Return the complete map of attribute names to attribute values for 
    * examination or modification.
    */
    public java.util.Properties getAttributes()
        {
        return __m_Attributes;
        }
    
    /**
    * Get the value of the specified attribute.
    */
    public String getAttributeValue(String sAttributeName)
        {
        // import java.util.Properties;
        
        Properties attributes = getAttributes();
        return attributes == null ? null : attributes.getProperty(sAttributeName);

        }
    
    /**
    * Get the value of the specified attribute, returning the provided default
    * value if not present.
    */
    public String getAttributeValue(String sAttributeName, String sDefaultValue)
        {
        String sValue = getAttributeValue(sAttributeName);
        
        return sValue != null ? sValue : sDefaultValue;
        }
    
    // From interface: com.tangosol.dev.packager.PackagerEntry
    // Accessor for the property "Comment"
    /**
    * Returns a comment for this Entry.
    */
    public String getComment()
        {
        return __m_Comment;
        }
    
    // Accessor for the property "Data"
    /**
    * Returns binary data for this Entry suitable for the Packager.
    */
    public byte[] getData()
            throws com.tangosol.dev.packager.PackagerEntryNotFoundException
        {
        return __m_Data;
        }
    
    // From interface: com.tangosol.dev.packager.PackagerEntry
    // Accessor for the property "Data"
    /**
    * Getter for property Data.<p>
    * Specifies this Entry as binary data suitable for packager. 
    */
    public byte[] getData(ClassLoader classLoader)
            throws com.tangosol.dev.packager.PackagerEntryNotFoundException
        {
        return getData();
        }
    
    // Accessor for the property "Element"
    /**
    * Getter for property Element.<p>
    * Specifies an Element that "produced" this Entry.
    */
    public Element getElement()
        {
        return __m_Element;
        }
    
    // From interface: com.tangosol.dev.packager.PackagerEntry
    // Accessor for the property "ModificationTime"
    /**
    * Returns the time when this Entry was last modified.
    */
    public long getModificationTime()
        {
        // import java.util.Date;
        
        long lTime = __m_ModificationTime;
        
        return lTime == 0 ? new Date().getTime() : lTime;
        }
    
    // From interface: com.tangosol.dev.packager.PackagerEntry
    // Accessor for the property "Path"
    /**
    * Returns a PackagerPath for this Entry.
    */
    public com.tangosol.dev.packager.PackagerPath getPath()
        {
        return __m_Path;
        }
    
    // From interface: com.tangosol.dev.packager.PackagerEntry
    // Accessor for the property "Secured"
    /**
    * Getter for property Secured.<p>
    * Specifies whether this entry should be "secured" in a package
    */
    public boolean isSecured()
        {
        return __m_Secured;
        }
    
    // Accessor for the property "Attributes"
    /**
    * Setter for property Attributes.<p>
    * Specifies the map of attribute names to attribute values.
    */
    private void setAttributes(java.util.Properties pAttributes)
        {
        __m_Attributes = pAttributes;
        }
    
    /**
    * Set the value of the specified attribute.
    */
    public void setAttributeValue(String sAttributeName, String sValue)
        {
        // import java.util.Properties;
        
        Properties attributes = getAttributes();
        if (attributes == null)
            {
            attributes = new Properties();
            setAttributes(attributes);
            }
        
        attributes.setProperty(sAttributeName, sValue);

        }
    
    // Accessor for the property "Comment"
    /**
    * Setter for property Comment.<p>
    * Specifies a comment for this Entry.
    */
    public void setComment(String pComment)
        {
        __m_Comment = pComment;
        }
    
    // Accessor for the property "Data"
    /**
    * Setter for property Data.<p>
    * Specifies this Entry as binary data suitable for packager. 
    */
    public void setData(byte[] pData)
        {
        __m_Data = pData;
        }
    
    // Accessor for the property "Element"
    /**
    * Setter for property Element.<p>
    * Specifies an Element that "produced" this Entry.
    */
    public void setElement(Element pElement)
        {
        __m_Element = pElement;
        }
    
    // Accessor for the property "ModificationTime"
    /**
    * Setter for property ModificationTime.<p>
    * Specifies the time when this Entry was last modified.
    */
    public void setModificationTime(long pModificationTime)
        {
        __m_ModificationTime = pModificationTime;
        }
    
    // Accessor for the property "Path"
    /**
    * Setter for property Path.<p>
    * Specifies a path for this Entry.
    */
    public void setPath(com.tangosol.dev.packager.PackagerPath pPath)
        {
        __m_Path = pPath;
        }
    
    // Accessor for the property "Secured"
    /**
    * Setter for property Secured.<p>
    * Specifies whether this entry should be "secured" in a package
    */
    public void setSecured(boolean pSecured)
        {
        __m_Secured = pSecured;
        }
    }
