/* Class
*     _package.component.dev.packager.model.Customization
*/

package _package.component.dev.packager.model;

import _package.component.dev.packager.PackageInfo;
import _package.component.dev.packager.element.ClassElement;
import _package.component.dev.packager.entry.ArchiveEntry;
import _package.component.dev.packager.entry.ClassEntry;
import _package.component.dev.packager.entry.TransientEntry;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.JarStorage;
import com.tangosol.dev.packager.JarFilePackagerSet;
import com.tangosol.dev.packager.PackagerDependencyElement; // as Element
import com.tangosol.dev.packager.UnexpectedPackagerException;
import com.tangosol.util.Base;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
* This component represents a packager model producing a customization of a
* library that must be specified in the root set.
*/
public class Customization
        extends    _package.component.dev.packager.Model
    {
    // Fields declarations
    
    // Default constructor
    public Customization()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Customization(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setClassRoot("");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Customization();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/model/Customization".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Process a jar entry representing an archive
    */
    protected void addArchiveElement(java.util.jar.JarFile jar, java.util.jar.JarEntry entry)
            throws java.io.IOException
        {
        // import Component.Dev.Packager.Entry.ArchiveEntry;
        // import com.tangosol.dev.component.JarStorage;
        // import java.io.File;
        // import java.util.jar.JarFile;
        
        String  sArchive = entry.getName();
        JarFile jarInner = JarStorage.extractJar(jar, sArchive);
        
        ArchiveEntry ae = new ArchiveEntry();
        
        ae.setPathName(sArchive);
        ae.setJarFile(jarInner);
        ae.setPackageInfo(getPackageInfo());
        ae.setPackageModel(this);
        
        addRootDependencyElement(ae);

        }
    
    /**
    * Process a jar entry representing a java class
    */
    protected void addClassElement(java.util.jar.JarFile jar, java.util.jar.JarEntry entry, String sClassName)
            throws java.io.IOException
        {
        // import Component.Dev.Packager.Element.ClassElement;
        // import Component.Dev.Packager.Entry.TransientEntry;
        // import com.tangosol.dev.packager.PackagerDependencyElement as Element;
        
        Element el;
        
        if (isDynamicCustomization())
            {
            // DynamicCustomization assumes class customization done at run-time
            TransientEntry te = new TransientEntry();
            te.setPathName(entry.getName());
            te.setInput(jar.getInputStream(entry));
        
            el = te;
            }
        else
            {
            ClassElement ce = new ClassElement();
            ce.setClassName(sClassName);
            ce.setStorage(getStorage());
            ce.setPackageInfo(getPackageInfo());
        
            el = ce;
            }
        
        addRootDependencyElement(el);

        }
    
    /**
    * Process a jar entry representing a resource
    */
    protected void addResourceElement(java.util.jar.JarFile jar, java.util.jar.JarEntry entry)
            throws java.io.IOException
        {
        // import Component.Dev.Packager.Entry.TransientEntry;
        // import com.tangosol.util.Base;
        // import java.util.Arrays;
        
        String sClassRoot = getClassRoot();
        String sEntry     = entry.getName();
        String sResource  = sEntry.startsWith(sClassRoot) ?
                                sEntry.substring(sClassRoot.length()) : sEntry;
        byte[] abResJar   = Base.read(jar.getInputStream(entry));
        byte[] abResOrig  = getStorage().loadOriginalResource(sResource);
        byte[] abResource = getClassLoader().loadResourceData(sResource);
        
        if (!Arrays.equals(abResJar, abResOrig))
            {
            // the fact that the results are different means
            // that there is more that one resource with the same name
            // (i.e. META-INF/ejb-jar.xml)
            // in which case it shouldn't have been attempted to be customized
        
            if (!Arrays.equals(abResOrig, abResource))
                {
                getOutputTool().output("Packager",
                    "??? Ambigious resource data for: " + sResource);
                }
            abResource = abResJar;
            }
        
        TransientEntry te = new TransientEntry();
        te.setPathName(sEntry);
        te.setData(abResource);
        
        addRootDependencyElement(te);
        }
    
    /**
    * Add all the entries of the specified archive to the "root" set.
    */
    protected void addRootArchive(java.util.jar.JarFile jar, String sClassRoot)
            throws java.io.IOException
        {
        // import Component.Dev.Packager.PackageInfo;
        // import com.tangosol.dev.packager.JarFilePackagerSet;
        // import java.util.Enumeration;
        // import java.util.jar.JarFile;
        // import java.util.jar.JarEntry;
        
        PackageInfo info = getPackageInfo();
        
        // if SuppressManifest is true -- leave the original manifest
        if (info.isSuppressManifest())
            {
            JarFilePackagerSet packagerSet = (JarFilePackagerSet) getPackagerSet();
            packagerSet.setManifest(jar.getManifest());
            }
        
        for (Enumeration enum = jar.entries(); enum.hasMoreElements();)
            {
            JarEntry entry = (JarEntry) enum.nextElement();
        
            if (entry.isDirectory())
                {
                continue;
                }
            
            String sEntry = entry.getName();
        
            if (sEntry.endsWith(".jar") || sEntry.endsWith(".war"))
                {
                addArchiveElement(jar, entry);
                }
            else if (sEntry.startsWith(sClassRoot) &&
                     sEntry.endsWith(".class"))
                {
                // ".class".length() == 6
                String sClassName = sEntry.
                    substring(sClassRoot.length(), sEntry.length() - 6).
                    replace('/', '.');
                addClassElement(jar, entry, sClassName);
                }
            else if (!sEntry.equalsIgnoreCase(JarFile.MANIFEST_NAME))
                {
                addResourceElement(jar, entry);
                }
            }
        }
    
    // Declared at the super level
    /**
    * Add the specified file to the "root" set.
    * 
    * @param file the file to package
    * @param sPackagedDir  the directory name where this file should be
    * packaged at
    */
    protected void addRootFile(java.io.File file, String sPackagedDir)
        {
        // import java.io.IOException;
        // import java.util.jar.JarFile;
        // import com.tangosol.dev.packager.UnexpectedPackagerException;
        
        JarFile jar = null;
        try
            {
            jar = new JarFile(file);
            }
        catch (IOException e)
            {
            }
        
        if (jar == null)
            {
            super.addRootFile(file, sPackagedDir);
            }
        else
            {
            try
                {
                addRootArchive(jar, sPackagedDir);
                }
            catch (IOException e)
                {
                throw new UnexpectedPackagerException(e);
                }
            finally
                {
                try
                    {
                    jar.close();
                    }
                catch (IOException e) {}
                }
            }
        }
    
    // Declared at the super level
    /**
    * Getter for property ApplicationComponent.<p>
    * Specifies the application component that is a "root" component for this
    * packaging model
    */
    public com.tangosol.dev.component.Component getApplicationComponent()
        {
        return null;
        }
    
    // Declared at the super level
    /**
    * Returns a list of immediate dependents of the specified
    * PackagerDependencyElement in the context of this packaging Model.
    */
    protected java.util.List getDependents(com.tangosol.dev.packager.PackagerDependencyElement dependencyElem)
        {
        return isDynamicCustomization() ? null : super.getDependents(dependencyElem);
        }
    
    // Declared at the super level
    /**
    * Records the specified entry to the PackagerSet.
    * 
    * @return true is the entry is accepted; false otherwise
    * 
    * @throws com.tangosol.dev.packager.PackagerException if an entry cannot be
    * recorded
    */
    protected boolean recordPackagerEntry(com.tangosol.dev.packager.PackagerEntry entry)
            throws com.tangosol.dev.packager.PackagerException
        {
        // import Component.Dev.Packager.Entry.ClassEntry;
        // import com.tangosol.dev.component.ComponentException;
        
        if (entry instanceof ClassEntry)
            {
            ClassEntry entryClass = (ClassEntry) entry;
        
            // make sure that the class is loadable;
            // otherwise ignore the element
            String  sClass  = entryClass.getClassElement().getClassName();
            boolean fExists = false;
            try
                {
                fExists = getStorage().loadOriginalClass(sClass) != null;
                }
            catch (ComponentException e) {}
        
            if (!fExists)
                {
                // the only remedy we could have is to enumerate all ArchiveEntry elements
                // in the RootDependencyElements list, find the one that has a jar
                // containing this class and package it as a TransientEntry
                // However, the question is: why it cannot be loaded?
                getOutputTool().output("Packager",
                    "??? Failed to load class: " + sClass, false);
                return false;
                }
            }
        
        return super.recordPackagerEntry(entry);
        }
    
    // Declared at the super level
    /**
    * Removes a ResourceSet from the set of exclusion sets used to check for
    * the presence of PackagerElements in other places, so that they are  not
    * added to the package.
    */
    public void removeExclusionSet(com.tangosol.dev.packager.ResourceSet exclusionSet)
        {
        super.removeExclusionSet(exclusionSet);
        }
    
    // Declared at the super level
    /**
    * Removes a PackagerDependencyElement from the set of roots for collecting 
    * the full set of PackagerElements required for this package.
    */
    public void removeRootDependencyElement(com.tangosol.dev.packager.PackagerDependencyElement el)
        {
        super.removeRootDependencyElement(el);
        }
    }
