/* Class
*     _package.component.dev.packager.model.EnterpriseArchive
*/

package _package.component.dev.packager.model;

import _package.component.Application;
import _package.component.application.library.Ejb;
import _package.component.application.library.Web;
import _package.component.dev.Storage;
import _package.component.dev.packager.Model;
import _package.component.dev.packager.PackageInfo$ComponentInfo; // as ComponentInfo
import _package.component.dev.packager.PackageInfo;
import _package.component.dev.packager.entry.TransientEntry;
import _package.component.dev.tool.OutputTool;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.packager.PackagerException;
import com.tangosol.dev.packager.PackagerFileEntry;
import com.tangosol.run.xml.SimpleDocument;
import com.tangosol.run.xml.SimpleElement;
import com.tangosol.run.xml.XmlElement;
import java.io.File;
import java.util.Iterator;
import java.util.List;

/**
* This component represents a packager model producing an Enterprise Archive
* (.ear) file.
*/
public class EnterpriseArchive
        extends    _package.component.dev.packager.Model
    {
    // Fields declarations
    
    /**
    * Property DESCRIPTOR_APPLICATION
    *
    */
    public static final String DESCRIPTOR_APPLICATION = "META-INF/application.xml";
    
    /**
    * Property ModuleList
    *
    * Specifies the list of modules contained by this enterprise application.
    * Each element is an XmlElement object containing the module information.
    * 
    * @see #collectDependents
    * @see #generateDescriptor
    */
    private transient java.util.LinkedList __m_ModuleList;
    
    // Default constructor
    public EnterpriseArchive()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public EnterpriseArchive(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setClassRoot("");
            setModuleList(new java.util.LinkedList());
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new EnterpriseArchive();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/model/EnterpriseArchive".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Collects all of the PackagerEntries required by the members of the root
    * set that are not contained in the exclusion sets, in the context of this
    * packaging Model..
    */
    protected void collectDependents()
            throws com.tangosol.dev.packager.PackagerException
        {
        // import Component.Application;
        // import Component.Dev.Packager.Model;
        // import Component.Dev.Packager.PackageInfo;
        // import Component.Dev.Packager.PackageInfo$ComponentInfo as ComponentInfo;
        // import Component.Dev.Storage;
        // import Component.Dev.Tool.OutputTool;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.packager.PackagerFileEntry;
        // import com.tangosol.dev.packager.PackagerException;
        
        Component   cdApp      = getApplicationComponent();
        PackageInfo infoApp    = getPackageInfo();
        OutputTool  toolOutput = getOutputTool();
        Storage     storage    = getStorage();
        
        String[] asChildren = cdApp.getChildren();
        for (int i = 0; i < asChildren.length;  i++)
            {
            String    sChild   = asChildren[i];
            Component cdModule = cdApp.getChild(sChild);
        
            if (cdModule == null ||
               !cdModule.getGlobalSuperName().startsWith("Component.Application"))
                {
                continue;
                }
            
            PackageInfo infoModule = new PackageInfo();
            infoModule.load(cdModule);
        
            Model packager = infoModule.getModel();
            if (packager == null)
                {
                throw new IllegalStateException("Component " + sChild +
                    " refers to unsupported model " + infoModule.getModelName());
                }
        
            // ensure the Java Package setting is copathetic
            infoModule.setJavaPackage(infoApp.getJavaPackage());
        
            // add the "include" list of the main application component
            // to the "include" list of the module
            infoModule.getIncludeComponents().putAll(infoApp.getIncludeComponents());
        
            packager.setApplicationComponent(cdModule);
            packager.setStorage(storage);
            packager.setOutputTool(toolOutput);
        
            toolOutput.output("Packager", "--- Packaging module:  " + sChild);
        
            packager.buildPackage();
        
            recordModule(cdModule, infoModule);
        
            String sPath = infoModule.resolveTargetFile(storage).getPath();
            PackagerFileEntry entry = new PackagerFileEntry(sPath, "");
        
            recordPackagerEntry(entry);
            }
        }
    
    protected String generateAppDescriptor()
        {
        // import Component.Dev.Packager.PackageInfo;
        // import com.tangosol.run.xml.SimpleDocument;
        // import com.tangosol.run.xml.XmlElement;
        // import java.io.File;
        // import java.util.Iterator;
        // import java.util.List;
        
        PackageInfo info = getPackageInfo();
        
        SimpleDocument xml = new SimpleDocument("application",
            "http://java.sun.com/j2ee/dtds/application_1_2.dtd",
            "-//Sun Microsystems, Inc.//DTD J2EE Application 1.2//EN");
        
        // TODO: icon?
        
        String sFileName    = new File(info.getTargetPath()).getName();
        int    ofExt        = sFileName.indexOf('.');
        String sDisplayName = ofExt < 0 ? sFileName : sFileName.substring(0, ofExt);
        
        xml.addElement("display-name").setString(sDisplayName);
        
        String sDescr = info.getDescription();
        if (sDescr.length() > 0)
            {
            int ofLine = sDescr.indexOf('\n');
            sDescr = ofLine < 0 ? sDescr : sDescr.substring(0, ofLine);
            }
        xml.addElement("description").setString(sDescr);
        
        // modules
        for (Iterator iter = getModuleList().iterator(); iter.hasNext();)
            {
            xml.getElementList().add((XmlElement) iter.next());
            }
        
        // TODO: allow to control
        XmlElement xmlRole = xml.addElement("security-role");
        xmlRole.addElement("description").setString("users");
        xmlRole.addElement("role-name").setString("users");
        
        return xml.toString();
        }
    
    // Accessor for the property "ModuleList"
    /**
    * Getter for property ModuleList.<p>
    * Specifies the list of modules contained by this enterprise application.
    * Each element is an XmlElement object containing the module information.
    * 
    * @see #collectDependents
    * @see #generateDescriptor
    */
    public java.util.LinkedList getModuleList()
        {
        return __m_ModuleList;
        }
    
    // Declared at the super level
    /**
    * Perform any required postprocessing on the PackagerSet after collecting
    * dependents, in the context of this packaging Model.
    */
    protected void postProcessPackagerEntries()
            throws com.tangosol.dev.packager.PackagerException
        {
        // import Component.Dev.Packager.Entry.TransientEntry;
        
        super.postProcessPackagerEntries();
        
        String sDescriptor = generateAppDescriptor();
        
        TransientEntry descriptor = new TransientEntry();
        descriptor.setPathName(DESCRIPTOR_APPLICATION);
        descriptor.setData(sDescriptor.getBytes());
        
        getPackagerSet().recordEntry(descriptor);

        }
    
    protected void recordModule(com.tangosol.dev.component.Component cdModule, _package.component.dev.packager.PackageInfo infoModule)
        {
        // import Component.Application.Library.Ejb;
        // import Component.Application.Library.Web;
        // import com.tangosol.run.xml.SimpleElement;
        // import com.tangosol.run.xml.XmlElement;
        // import java.io.File;
        
        SimpleElement xml = new SimpleElement("module");
        
        String sFile = new File(infoModule.getTargetPath()).getName();
        String sType = cdModule.getGlobalSuperName();
        
        if (sType.startsWith("Component.Application.Library.Ejb"))
            {
            xml.addElement("ejb").setString(sFile);
            }
        else if (sType.startsWith("Component.Application.Library.Web"))
            {
            String sContextRoot = (String) getPropertyValue(cdModule, "ContextPath");
            if (sContextRoot == null)
                {
                sContextRoot = '/' + cdModule.getName().toLowerCase();
                }
        
            XmlElement xmlWeb = xml.addElement("web");
        
            xmlWeb.addElement("web-uri").setString(sFile);
            xmlWeb.addElement("context-root").setString(sContextRoot);
            }
        else
            {
            getOutputTool().output("Packager",
                "*** Failed to process module " + cdModule);
            return;
            }
        
        getModuleList().add(xml);
        }
    
    // Accessor for the property "ModuleList"
    /**
    * Setter for property ModuleList.<p>
    * Specifies the list of modules contained by this enterprise application.
    * Each element is an XmlElement object containing the module information.
    * 
    * @see #collectDependents
    * @see #generateDescriptor
    */
    public void setModuleList(java.util.LinkedList pModuleList)
        {
        __m_ModuleList = pModuleList;
        }
    }
