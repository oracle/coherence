/* Class
*     _package.component.dev.packager.model.Library
*/

package _package.component.dev.packager.model;

import _package.component.dev.compiler.ClassGenerator$ClassInfo; // as ClassInfo
import _package.component.dev.compiler.ClassGenerator;
import _package.component.dev.compiler.Integrator;
import _package.component.dev.packager.PackageInfo$ComponentInfo; // as ComponentInfo
import _package.component.dev.packager.PackageInfo;
import _package.component.dev.packager.element.CDElement;
import _package.component.dev.packager.entry.CDEntry;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.packager.PackagerComponentEntry;
import com.tangosol.dev.packager.UnexpectedPackagerException;
import java.util.LinkedList;
import java.util.List;

/**
* This component represents a packager model producing a library of Java
* classes (.jar). Since Component Definitions produce the classes according to
* the JavaBean specification, the corresponding classes are marked as JavaBeans
* in the manifest (only if the manifest generation is not suppressed).
*/
public class Library
        extends    _package.component.dev.packager.Model
    {
    // Fields declarations
    
    // Default constructor
    public Library()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Library(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setClassRoot("");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Library();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/model/Library".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Returns a list of immediate dependents of the specified
    * PackagerDependencyElement in the context of this packaging Model.
    */
    protected java.util.List getDependents(com.tangosol.dev.packager.PackagerDependencyElement dependencyElem)
        {
        // import Component.Dev.Compiler.ClassGenerator;
        // import Component.Dev.Compiler.ClassGenerator$ClassInfo as ClassInfo;
        // import Component.Dev.Compiler.Integrator;
        // import Component.Dev.Packager.Element.CDElement;
        // import Component.Dev.Packager.Entry.CDEntry;
        // import Component.Dev.Packager.PackageInfo;
        // import Component.Dev.Packager.PackageInfo$ComponentInfo as ComponentInfo;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.packager.UnexpectedPackagerException;
        // import java.util.LinkedList;
        // import java.util.List;
        
        List dependents = super.getDependents(dependencyElem);
        
        processJavaBean:
        if (dependencyElem instanceof CDElement)
            {
            CDElement elemCD = (CDElement) dependencyElem;
            Component cd     = elemCD.getComponent();
        
            // every JavaBean has to be explicitly specified as a "root element"
            if (cd != null && cd.isGlobal() && !cd.isResultAbstract() &&
                getRootDependencyElements().contains(elemCD))
                {
                PackageInfo info = getPackageInfo();
        
                String sExposePkg  = null;
                String sExposeName = null;
                String sJavaBean   = null;
        
                /*
                * the strategy of using "exposed" names is not as simple as just
                * saying:
                
                ComponentInfo compInfo = (ComponentInfo)
                    info.getIncludeComponents().get(cd.getQualifiedName());
                if (compInfo == null)
                    {
                    sExposePkg  = compInfo.getExposePackage();
                    sExposeName = compInfo.getExposeName();
                    }
        
                * it would also affect the ejb-jar generation
                * (see EJBLibrary#recordEJB)
                */
        
                ClassGenerator gen = elemCD.getClassGenerator();
                List listClassInfo;
                try
                    {
                    listClassInfo = gen.generateExposedClasses(sExposePkg, sExposeName,
                        ClassGenerator.EXPOSE_AUTO, true);
                    }
                 catch (ComponentException e)
                    {
                    throw new UnexpectedPackagerException(e);
                    }
        
                if (listClassInfo == null)
                    {
                    Integrator integrator = gen.findEffectiveIntegrator(cd);
                    if (integrator != null)
                        {
                        sJavaBean = integrator.getAutoGenClass(cd, Integrator.PEER_FEED);
                        }
                    }
                else
                    {
                    _assert(listClassInfo.size() == 1);
        
                    ClassInfo classInfo = (ClassInfo) listClassInfo.get(0);
        
                    sJavaBean = classInfo.getClassFile().getName().replace('/', '.');
                    }
        
                CDElement elBean = elemCD;
        
                if (sJavaBean != null)
                    {
                    elBean = new CDElement();
        
                    elBean.setSynthetic(true);
                    elBean.setComponentName(cd.getQualifiedName());
                    elBean.setClassName(sJavaBean);
                    elBean.setPackageInfo(info);
                    elBean.setStorage(elemCD.getStorage());
        
                    dependents.add(elBean);
                    }
        
                 if (!info.isSuppressManifest())
                    {
                    elBean.getMainCDEntry().setAttributeValue("JavaBean", "true");
                    }
                }
            }
        
        return dependents;
        }
    
    /**
    * Records the specified JavaBean to the PackagerSet
    */
    protected void recordJavaBean(com.tangosol.dev.component.Component cd, _package.component.dev.compiler.ClassGenerator gen)
        {
        }
    
    // Declared at the super level
    /**
    * Records the specified entry to the PackagerSet.
    * 
    * @return true is the entry is accepted; false otherwise
    * 
    * @throws com.tangosol.dev.packager.PackagerException if an entry cannot be
    * recorded
    */
    protected boolean recordPackagerEntry(com.tangosol.dev.packager.PackagerEntry entry)
            throws com.tangosol.dev.packager.PackagerException
        {
        // import Component.Dev.Packager.Element.CDElement;
        // import Component.Dev.Packager.Entry.CDEntry;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.packager.PackagerComponentEntry;
        
        boolean fAdded = super.recordPackagerEntry(entry);
        
        if (fAdded && entry instanceof PackagerComponentEntry)
            {
            CDEntry   entryCD = (CDEntry) ((PackagerComponentEntry) entry).getCDEntry();
            CDElement elemCD  = entryCD.getCDElement();
            Component cd      = elemCD.getComponent();
        
            // every JavaBean has to be explicitly specified as a "root element"
            if (cd != null && cd.isGlobal() && !cd.isResultAbstract() &&
                getRootDependencyElements().contains(elemCD))
                {
                recordJavaBean(cd, elemCD.getClassGenerator());
                }
            }
        
        return fAdded;
        }
    }
