/* Class
*     _package.component.dev.packager.PackageInfo
*/

package _package.component.dev.packager;

import _package.component.dev.packager.Model;
import _package.component.util.NamedRef;
import com.tangosol.dev.assembler.ClassFile$Relocator;
import com.tangosol.dev.component.Property;
import com.tangosol.util.ListMap;
import java.io.File;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
* This component represents the information collected and used by the Packager
* in order to package an application built in this tool.
*/
public class PackageInfo
        extends    _package.component.dev.Packager
    {
    // Fields declarations
    
    /**
    * Property ApplicationName
    *
    * Specifies the name of the application that is currently being packaged.
    * This property is used as a reasonable default for some descriptors.
    * 
    * @see #load
    */
    private transient String __m_ApplicationName;
    
    /**
    * Property Compressed
    *
    * Specifies whether the package should be compressed.
    */
    private boolean __m_Compressed;
    
    /**
    * Property Description
    *
    * Specifies a human readable description of this package definition.
    * 
    * @see #load
    */
    private String __m_Description;
    
    /**
    * Property ExcludeResources
    *
    * Specifies the list of resources (jars, java classes, etc.) to be excluded
    * from the package. The entries in this list represent the  resource paths.
    */
    private java.util.List __m_ExcludeResources;
    
    /**
    * Property IncludeComponents
    *
    * Specifies the map of root components to be included into the package. The
    * keys in this map are fully qualified component names and the values are
    * instances of $ComponentInfo.
    */
    private java.util.Map __m_IncludeComponents;
    
    /**
    * Property IncludeResources
    *
    * Specifies the list of root resources (jars, java classes, etc.) to be
    * included to the package. The entries in this list are NamedRef components
    * with Name representing the resource path and Ref value being the packaged
    * directory name for this resource.
    */
    private java.util.List __m_IncludeResources;
    
    /**
    * Property INFO_DEPENDENCY
    *
    */
    private static final int INFO_DEPENDENCY = 0;
    
    /**
    * Property INFO_MANIFEST
    *
    */
    private static final int INFO_MANIFEST = 1;
    
    /**
    * Property INFO_XML
    *
    */
    private static final int INFO_XML = 2;
    
    /**
    * Property JavaPackage
    *
    * Specifies the java package (i.e. "com.tangosol.example") for this 
    * package definition.
    */
    private String __m_JavaPackage;
    
    /**
    * Property ManifestEntries
    *
    * Specifies the list of global entries in the manifest. Each entry is a
    * NamedRef component.
    */
    private java.util.List __m_ManifestEntries;
    
    /**
    * Property Model
    *
    * Specifies the packager model used to produce this package.
    */
    private transient Model __m_Model;
    
    /**
    * Property ModelName
    *
    * Specifies the packager model name (with implied prefix
    * "Component.Dev.Packager.Model.")
    */
    private String __m_ModelName;
    
    /**
    * Property PROP_COMPONENTS
    *
    */
    private static final String PROP_COMPONENTS = "$Components";
    
    /**
    * Property PROP_COMPONENTS_INFO
    *
    */
    private static final String PROP_COMPONENTS_INFO = "$ComponentsInfo";
    
    /**
    * Property PROP_EXCLUDES
    *
    */
    private static final String PROP_EXCLUDES = "$Excludes";
    
    /**
    * Property PROP_PACKAGE_INFO
    *
    */
    public static final String PROP_PACKAGE_INFO = "$PackageInfo";
    
    /**
    * Property PROP_RESOURCES
    *
    */
    private static final String PROP_RESOURCES = "$Resources";
    
    /**
    * Property SuppressManifest
    *
    * Specifies whether the manifest should be generated at all.
    */
    private boolean __m_SuppressManifest;
    
    /**
    * Property TargetPath
    *
    * Specifies the target package file path (usually a ".jar", ".war" or
    * ".ear")
    */
    private String __m_TargetPath;
    
    /**
    * Property XMLEntries
    *
    * Specifies the list of global entries in an XML descriptor. Each entry is
    * a NamedRef component.
    */
    private java.util.List __m_XMLEntries;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("ComponentInfo", PackageInfo$ComponentInfo.get_CLASS());
        }
    
    // Default constructor
    public PackageInfo()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PackageInfo(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setCompressed(false);
            setModelName("Executable");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new PackageInfo();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/PackageInfo".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Accessor for the property "ApplicationName"
    public String getApplicationName()
        {
        return __m_ApplicationName;
        }
    
    // Accessor for the property "Description"
    public String getDescription()
        {
        return __m_Description;
        }
    
    // Accessor for the property "ExcludeResources"
    public java.util.List getExcludeResources()
        {
        return __m_ExcludeResources;
        }
    
    // Accessor for the property "IncludeComponents"
    public java.util.Map getIncludeComponents()
        {
        return __m_IncludeComponents;
        }
    
    // Accessor for the property "IncludeResources"
    public java.util.List getIncludeResources()
        {
        return __m_IncludeResources;
        }
    
    // Accessor for the property "JavaPackage"
    public String getJavaPackage()
        {
        return __m_JavaPackage;
        }
    
    // Accessor for the property "ManifestEntries"
    public java.util.List getManifestEntries()
        {
        return __m_ManifestEntries;
        }
    
    // Accessor for the property "Model"
    public Model getModel()
        {
        // import Component.Dev.Packager.Model;
        
        Model packager = __m_Model;
        if (packager == null)
            {
            String sName = getModelName();
            if (!sName.startsWith("Component.Dev.Packager.Model."))
                {
                sName = "Component.Dev.Packager.Model." + sName;
                }
            packager = (Model) _newInstance(sName);
            setModel(packager);
        
            if (packager != null)
                {
                packager.setPackageInfo(this);
                }
            }
        return packager;
        }
    
    // Accessor for the property "ModelName"
    public String getModelName()
        {
        return __m_ModelName;
        }
    
    // Accessor for the property "TargetPath"
    public String getTargetPath()
        {
        return __m_TargetPath;
        }
    
    // Accessor for the property "XMLEntries"
    public java.util.List getXMLEntries()
        {
        return __m_XMLEntries;
        }
    
    // Accessor for the property "Compressed"
    public boolean isCompressed()
        {
        return __m_Compressed;
        }
    
    // Accessor for the property "SuppressManifest"
    public boolean isSuppressManifest()
        {
        return __m_SuppressManifest;
        }
    
    /**
    * Loads a package info from the specified application component.
    */
    public void load(com.tangosol.dev.component.Component cdApp)
        {
        // import Component.Util.NamedRef;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.util.ListMap;
        // import java.util.Arrays;
        // import java.util.LinkedList;
        
        Property propPkgInfo = cdApp.getProperty(PROP_PACKAGE_INFO);
        Object[] aoPkgInfo   = propPkgInfo.isNoValue() || propPkgInfo.isNullValue() ?
            new String[0] : (Object[]) propPkgInfo.getValue();
        
        String sModelName   = aoPkgInfo.length == 0 ? "" : (String) aoPkgInfo[0];
        String sJavaPackage = aoPkgInfo.length <= 1 ? "" : (String) aoPkgInfo[1];
        String sTargetPath  = aoPkgInfo.length <= 2 ? "" : (String) aoPkgInfo[2];
        String sSuppress    = aoPkgInfo.length <= 3 ? "" : (String) aoPkgInfo[3];
        String sManifest    = aoPkgInfo.length <= 4 ? "" : (String) aoPkgInfo[4];
        String sXML         = aoPkgInfo.length <= 5 ? "" : (String) aoPkgInfo[5];
        String sAppName     = cdApp.getName();
        String sDescription = cdApp.getText();
        
        setModelName(sModelName);
        setJavaPackage(sJavaPackage);
        setTargetPath(sTargetPath);
        setSuppressManifest(new Boolean(sSuppress).booleanValue());
        setManifestEntries(parseList(sManifest));
        setXMLEntries(parseList(sXML));
        setApplicationName(sAppName);
        setDescription(sDescription);
        
        Property propComponents     = cdApp.getProperty(PROP_COMPONENTS);
        Property propComponentsInfo = cdApp.getProperty(PROP_COMPONENTS_INFO);
        
        Object[] aoName  = propComponents.isNoValue()     || propComponents.isNullValue() ?
            new String[0] : (Object[]) propComponents.getValue();
        Object[] aaoInfo = propComponentsInfo.isNoValue() || propComponentsInfo.isNullValue() ?
            new String[0][0] : (Object[]) propComponentsInfo.getValue();
        
        ListMap mapComp = new ListMap();
        for (int i = 0; i < aoName.length; i++)
            {
            String sName = (String) aoName[i];
            if (sName == null || sName.length() == 0)
                {
                // this should not happen unless the data is manually entered
                continue;
                }
        
            Object[] aoInfo =
                aaoInfo.length > i && aaoInfo[i] instanceof Object[] ?
                (Object[]) aaoInfo[i] : new String[0];
        
            $ComponentInfo compInfo = ($ComponentInfo) _newChild("ComponentInfo");
        
            if (aoInfo.length > INFO_DEPENDENCY)
                {
                try
                    {
                    compInfo.setDependencyStyle(Integer.parseInt((String) aoInfo[INFO_DEPENDENCY]));
                    }
                catch (NumberFormatException e) {}
                }
            if (aoInfo.length > INFO_MANIFEST)
                {
                compInfo.setManifestEntries(parseList((String) aoInfo[INFO_MANIFEST]));
                }
            if (aoInfo.length > INFO_XML)
                {
                compInfo.setXMLEntries(parseList((String) aoInfo[INFO_XML]));
                }
        
            mapComp.put(sName, compInfo);
            }
        setIncludeComponents(mapComp);
        
        Property propResources = cdApp.getProperty(PROP_RESOURCES);
        Object[] aoResources   = propResources.isNoValue() || propResources.isNullValue() ?
            new String[0] : (Object[]) propResources.getValue();
        
        LinkedList listResources = new LinkedList();
        for (int i = 0; i < aoResources.length; i++)
            {
            listResources.add(parseNamedRef((String) aoResources[i]));
            }
        setIncludeResources(listResources);
        
        Property propExcludes = cdApp.getProperty(PROP_EXCLUDES);
        Object[] aoExcludes   = propExcludes.isNoValue() || propExcludes.isNullValue() ?
            new String[0] : (Object[]) propExcludes.getValue();
        setExcludeResources(new LinkedList(Arrays.asList(aoExcludes)));
        }
    
    /**
    * Packs the specified list into a string.
    */
    private String packList(java.util.List list)
        {
        // import Component.Util.NamedRef;
        // import java.util.Iterator;
        
        if (list == null)
            {
            return "";
            }
        
        StringBuffer sb = new StringBuffer();
        for (Iterator iter = list.iterator(); iter.hasNext();)
            {
            NamedRef ref = (NamedRef) iter.next();
            sb.append('&')
              .append(packNamedRef(ref));
            }
        
        return sb.length() > 0 ? sb.substring(1) : "";
        }
    
    /**
    * Packs the specified NamedRef into a string.
    */
    private String packNamedRef(_package.component.util.NamedRef ref)
        {
        return ref.getName() + "=" + String.valueOf(ref.getRef());
        }
    
    /**
    * Parses the specified string into a list of NamedRef components.
    */
    private java.util.List parseList(String sProps)
        {
        // import Component.Util.NamedRef;
        // import java.util.LinkedList;
        // import java.util.StringTokenizer;
        
        LinkedList list = new LinkedList();
        
        for (StringTokenizer tokens = new StringTokenizer(sProps, "&");
             tokens.hasMoreTokens();)
            {
            NamedRef ref = parseNamedRef(tokens.nextToken());
        
            if (ref != null)
                {
                list.add(ref);
                }
            }
        
        return list;
        }
    
    /**
    * Parses the specified string into a NamedRef component.
    */
    private _package.component.util.NamedRef parseNamedRef(String sPair)
        {
        // import Component.Util.NamedRef;
        
        int    of   = sPair.indexOf('=');
        String sKey = sPair;
        String sVal = "";
        
        if (of != -1)
            {
            sKey = sPair.substring(0, of);
            if (of + 1 < sPair.length())
                {
                sVal = sPair.substring(of + 1);
                }
            }
        
        return sKey.length() > 0 ? NamedRef.instantiate(sKey, sVal) : null;
        }
    
    /**
    * Helper method that converts the relocatable prefix to the value of
    * JavaPackage property in the specified string.
    */
    public String relocateName(String sName)
        {
        // import com.tangosol.dev.assembler.ClassFile$Relocator;
        
        String sRelocator = ClassFile$Relocator.PACKAGE.replace('/', '.');
        
        return sName.startsWith(sRelocator) ?
            getJavaPackage() + sName.substring(sRelocator.length()) : sName;

        }
    
    /**
    * If the target file is specified as a relative path, resolve it relative
    * to the storage's package directory
    */
    public java.io.File resolveTargetFile(_package.component.dev.Storage storage)
        {
        // import java.io.File;
        
        File file = new File(getTargetPath());
        if (!file.isAbsolute())
            {
            File dir = storage.getPackageDir();
        
            file = new File(dir, file.getPath());
            }
        return file;
        }
    
    // Accessor for the property "ApplicationName"
    public void setApplicationName(String pApplicationName)
        {
        __m_ApplicationName = pApplicationName;
        }
    
    // Accessor for the property "Compressed"
    public void setCompressed(boolean pCompressed)
        {
        __m_Compressed = pCompressed;
        }
    
    // Accessor for the property "Description"
    public void setDescription(String pDescription)
        {
        __m_Description = pDescription;
        }
    
    // Accessor for the property "ExcludeResources"
    public void setExcludeResources(java.util.List pExcludeResources)
        {
        __m_ExcludeResources = pExcludeResources;
        }
    
    // Accessor for the property "IncludeComponents"
    public void setIncludeComponents(java.util.Map pIncludeComponents)
        {
        __m_IncludeComponents = pIncludeComponents;
        }
    
    // Accessor for the property "IncludeResources"
    public void setIncludeResources(java.util.List pIncludeResources)
        {
        __m_IncludeResources = pIncludeResources;
        }
    
    // Accessor for the property "JavaPackage"
    public void setJavaPackage(String pJavaPackage)
        {
        __m_JavaPackage = pJavaPackage;
        }
    
    // Accessor for the property "ManifestEntries"
    public void setManifestEntries(java.util.List pManifestEntries)
        {
        __m_ManifestEntries = pManifestEntries;
        }
    
    // Accessor for the property "Model"
    private void setModel(Model pModel)
        {
        __m_Model = pModel;
        }
    
    // Accessor for the property "ModelName"
    public void setModelName(String pModelName)
        {
        if (pModelName != null && pModelName.equals(getModelName()))
            {
            return;
            }
        
        __m_ModelName = (pModelName);
        
        setModel(null);
        }
    
    // Accessor for the property "SuppressManifest"
    public void setSuppressManifest(boolean pSuppressManifest)
        {
        __m_SuppressManifest = pSuppressManifest;
        }
    
    // Accessor for the property "TargetPath"
    public void setTargetPath(String pTargetPath)
        {
        __m_TargetPath = pTargetPath;
        }
    
    // Accessor for the property "XMLEntries"
    public void setXMLEntries(java.util.List pXMLEntries)
        {
        __m_XMLEntries = pXMLEntries;
        }
    
    /**
    * Stores this package info into the specified application component.
    */
    public void store(com.tangosol.dev.component.Component cdApp)
            throws java.beans.PropertyVetoException
        {
        // import Component.Util.NamedRef;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.util.ListMap;
        // import java.util.Iterator;
        // import java.util.List;
        // import java.util.Map;
        
        Property propPkgInfo = cdApp.getProperty(PROP_PACKAGE_INFO);
        String[] asPkgInfo   = new String[]
            {
            getModelName(),
            getJavaPackage(),
            getTargetPath(),
            String.valueOf(isSuppressManifest()),
            packList(getManifestEntries()),
            packList(getXMLEntries()),
            };
        propPkgInfo.setValue(asPkgInfo);
        
        Map      mapComp            = getIncludeComponents();
        Property propComponents     = cdApp.getProperty(PROP_COMPONENTS);
        Property propComponentsInfo = cdApp.getProperty(PROP_COMPONENTS_INFO);
        
        if (mapComp.isEmpty())
            {
            propComponents    .setValue(Property.NO_VALUE);
            propComponentsInfo.setValue(Property.NO_VALUE);
            }
        else
            {
            String[]   asName  = new String[mapComp.size()];
            String[][] aasInfo = new String[mapComp.size()][3];
        
            Iterator iter = mapComp.keySet().iterator();
            for (int i = 0; iter.hasNext(); i++)
                {
                String sName = (String) iter.next();
        
                asName[i] = sName;
            
                $ComponentInfo compInfo = ($ComponentInfo) mapComp.get(sName);
        
                aasInfo[i][INFO_DEPENDENCY] = String.valueOf(compInfo.getDependencyStyle());
                aasInfo[i][INFO_MANIFEST  ] = packList(compInfo.getManifestEntries());
                aasInfo[i][INFO_XML       ] = packList(compInfo.getXMLEntries());
                }
            propComponents    .setValue(asName);
            propComponentsInfo.setValue(aasInfo);
            }
        
        List      listResources = getIncludeResources();
        Property propResources = cdApp.getProperty(PROP_RESOURCES);
        
        if (listResources.isEmpty())
            {
            propResources.setValue(Property.NO_VALUE);
            }
        else
            {
            String[] asResource = new String[listResources.size()];
            
            Iterator iter = listResources.iterator();
            for (int i = 0; iter.hasNext(); i++)
                {
                asResource[i] = packNamedRef((NamedRef) iter.next());
                }
            propResources.setValue(asResource);
            }
        
        List     listExcludes = getExcludeResources();
        Property propExcludes = cdApp.getProperty(PROP_EXCLUDES);
        propExcludes.setValue(listExcludes.isEmpty() ?
            Property.NO_VALUE : listExcludes.toArray());
        }
    }
