/* Class
*     _package.component.dev.packager.element.ClassElement
*/

package _package.component.dev.packager.element;

import _package.component.dev.Storage;
import _package.component.dev.packager.PackageInfo;
import _package.component.dev.packager.entry.ClassEntry;
import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.UtfConstant;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.packager.PackagerDependencyClassElement; // as _ClassElement
import com.tangosol.dev.packager.PackagerDependencyElement; // as Element
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
* The packager element representing a Java Class.
*/
public class ClassElement
        extends    _package.component.dev.packager.Element
    {
    // Fields declarations
    
    /**
    * Property ClassName
    *
    * Specifies a name of a class this ClassElement component represents.
    */
    private String __m_ClassName;
    
    /**
    * Property Dependents
    *
    * Privately used hash table of dependents that is used to communicate
    * between with Resolver interface
    */
    private transient java.util.HashMap __m_Dependents;
    
    // Default constructor
    public ClassElement()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ClassElement(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ClassElement();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/element/ClassElement".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof ClassElement)
            {
            ClassElement that = (ClassElement) obj;
            return this.getClassName().equals(that.getClassName());
            }
        return super.equals(obj);
        }
    
    // Accessor for the property "ClassName"
    /**
    * Getter for property ClassName.<p>
    * Specifies a name of a class this ClassElement component represents.
    */
    public String getClassName()
        {
        return __m_ClassName;
        }
    
    // Accessor for the property "Dependents"
    /**
    * Getter for property Dependents.<p>
    * Privately used hash table of dependents that is used to communicate
    * between with Resolver interface
    */
    private java.util.HashMap getDependents()
        {
        return __m_Dependents;
        }
    
    // Declared at the super level
    /**
    * Return the immediate dependents of this PackagerDependencyElement in the
    * context of the specified ClassLoader.
    */
    public java.util.List getDependents(ClassLoader classLoader)
        {
        // import Component.Dev.Packager.PackageInfo;
        // import Component.Dev.Storage;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.packager.PackagerDependencyClassElement as _ClassElement;
        // import com.tangosol.dev.packager.PackagerDependencyElement as Element;
        // import java.util.ArrayList;
        // import java.util.Iterator;
        // import java.util.List;
        
        _ClassElement _el = new _ClassElement(getClassName());
        List      listSrc = _el.getDependents(classLoader);
        ArrayList listDst = new ArrayList(listSrc.size());
        
        Storage     store = getStorage();
        PackageInfo info  = getPackageInfo();
        
        for (Iterator iter = listSrc.iterator(); iter.hasNext();)
            {
            Element el = (Element) iter.next();
            if (el instanceof _ClassElement)
                {
                ClassElement elClz = new ClassElement();
                elClz.setPackageInfo(info);
                elClz.setStorage(store);
                elClz.setClassName(((_ClassElement) el).getClassName());
                el = elClz;
                }
            listDst.add(el);
            }
        return listDst;
        
        /*
        import com.tangosol.dev.assembler.ClassFile;
        import java.util.HashMap;
        
        // get all dependent classes by implementing the "Resolver" interface
        // this would allow us to finally not to be dependent on the
        // com.tangosol.dev.packager.ConstantPoolEntry processing
        
        ClassFile clzf  = null;
        
        try
            {
            clzf = store.loadClass(getClassName());
            }
        catch (ComponentException e) {}
        
        if (clzf == null)
            {
            throw new IllegalStateException("Failed to load class " + getClassName());
            }
        
        HashMap tbl = new HashMap();
        setDependents(tbl);
        
        clzf.resolve(this);
        
        setDependents(null);
        
        ArrayList list = new ArrayList(tbl.size());
        list.addAll(tbl.values());
        return list;
        */
        

        }
    
    // Declared at the super level
    /**
    * Return the direct PackagerEntries of this PackagerDependencyElement.
    */
    public java.util.List getPackagerEntries()
        {
        // import Component.Dev.Packager.Entry.ClassEntry;
        // import java.util.Collections;
        
        ClassEntry entry = new ClassEntry();
        entry.setElement(this);
        
        return Collections.singletonList(entry);

        }
    
    // Declared at the super level
    public int hashCode()
        {
        return getClassName().hashCode();
        }
    
    private com.tangosol.dev.assembler.Constant resolve(com.tangosol.dev.assembler.Constant constant)
        {
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.assembler.UtfConstant;
        
        // TODO: not used
        // TODO: the following must be replaced by the dedicated ClassFile functionality
        String sClz = null;
        if      (constant instanceof ClassConstant)
            {
            // this never happens
            sClz = ((ClassConstant) constant).getJavaName();
            }
        else if (constant instanceof UtfConstant)
            {
            String sName = ((UtfConstant) constant).getValue();
            int    cc    = sName.length();
            if (cc > 0 && sName.charAt(0) == 'L' && sName.charAt(cc - 1) == ';')
                {
                sClz = sName.substring(1, cc - 1).replace('/', '.');
                }
            else
                {
                if (sName.indexOf("_package") >= 0) _trace("ClassElement.resolve: missed " + sName, 1);
                }
            }
        
        if (sClz != null && getDependents().get(sClz) == null)
            {
            ClassElement el = new ClassElement();
            el.setStorage(getStorage());
            el.setClassName(sClz);
            el.setPackageInfo(getPackageInfo());
            
            getDependents().put(sClz, el);
            }
        
        return constant;
        }
    
    // Accessor for the property "ClassName"
    /**
    * Setter for property ClassName.<p>
    * Specifies a name of a class this ClassElement component represents.
    */
    public void setClassName(String pClassName)
        {
        __m_ClassName = pClassName;
        }
    
    // Accessor for the property "Dependents"
    /**
    * Setter for property Dependents.<p>
    * Privately used hash table of dependents that is used to communicate
    * between with Resolver interface
    */
    private void setDependents(java.util.HashMap pDependents)
        {
        __m_Dependents = pDependents;
        }
    
    // Declared at the super level
    public String toString()
        {
        return "ClassElement [" + getClassName() + ']';
        }
    }
