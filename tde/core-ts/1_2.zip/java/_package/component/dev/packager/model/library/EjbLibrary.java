/* Class
*     _package.component.dev.packager.model.library.EjbLibrary
*/

package _package.component.dev.packager.model.library;

import _package.component.dev.compiler.Integrator;
import _package.component.dev.compiler.Remoter;
import _package.component.dev.compiler.remoter.EJB;
import _package.component.dev.packager.PackageInfo$ComponentInfo; // as ComponentInfo
import _package.component.dev.packager.PackageInfo;
import _package.component.dev.packager.entry.TransientEntry;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Property;
import com.tangosol.run.xml.SimpleDocument;
import com.tangosol.run.xml.SimpleElement;
import com.tangosol.run.xml.XmlElement;
import java.io.File;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;

/**
* 
* +++++++++++++++++++++++++
* 
* The EjbLibrary packaging model additionally generates an EJB Deployment
* Descriptor. According to EJB 1.1 specification the descriptor is an XML
* document with the following DTD:
* http://java.sun.com/j2ee/dtds/ejb-jar_1.1.dtd
*/
public class EjbLibrary
        extends    _package.component.dev.packager.model.Library
    {
    // Fields declarations
    
    /**
    * Property DESCRIPTOR_EJB
    *
    * The name of a deployment descriptor
    */
    public static final String DESCRIPTOR_EJB = "META-INF/ejb-jar.xml";
    
    /**
    * Property EjbNames
    *
    * Specifies the map of EJB names included into the package. It is keyed by
    * an EJB name (as it's put into the ejb-jar.xml) and a corresponding value
    * is the EJB  component name.
    * 
    * @see #recordEJB
    */
    private transient com.tangosol.util.StringTable __m_EjbNames;
    
    /**
    * Property EjbTable
    *
    * Specifies the map of EJBs included into the package. It is keyed by a
    * component name and a corresponding value is an XmlElement carrying the
    * EJB descriptor.
    * 
    * @see #recordPackagerEntry
    * @see #generateDescriptor
    */
    private transient com.tangosol.util.StringTable __m_EjbTable;
    
    /**
    * Property XMLElements
    *
    * Specifies a set of XML element names for the ejb-jar.xml deployment 
    * descriptor.  The following is a quote from ejb-jar_1_1.dtd:
    * 
    * <!ELEMENT ejb-jar (description?, display-name?, small-icon?, large-icon?,
    * enterprise-beans, assembly-descriptor?, ejb-client-jar?)>
    * 
    * @see http://java.sun.com/j2ee/dtds/ejb-jar_1_1.dtd
    */
    private static final String[] __s_XMLElements;
    
    // Static initializer
    static
        {
        try
            {
            String[] a0 = new String[6];
                {
                a0[0] = "description";
                a0[1] = "display-name";
                a0[2] = "ejb-name";
                a0[3] = "small-icon";
                a0[4] = "large-icon";
                a0[5] = "ejb-client-jar";
                }
            __s_XMLElements = a0;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public EjbLibrary()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public EjbLibrary(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setClassRoot("");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        
        // state initialization: private properties
        try
            {
            __m_EjbNames = new com.tangosol.util.StringTable();
            __m_EjbTable = new com.tangosol.util.StringTable();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Getter for virtual constant XMLElements
    public String[] getXMLElements()
        {
        return (String[]) __s_XMLElements.clone();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new EjbLibrary();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/model/library/EjbLibrary".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Generates a deployment descriptor according to the EJB 1.1 specification.
    */
    protected String generateEjbDescriptor()
        {
        // import Component.Dev.Packager.PackageInfo;
        // import com.tangosol.run.xml.SimpleDocument;
        // import com.tangosol.run.xml.XmlElement;
        // import java.io.File;
        // import java.util.Enumeration;
        
        PackageInfo info = getPackageInfo();
        
        SimpleDocument xml = new SimpleDocument("ejb-jar",
            "http://java.sun.com/j2ee/dtds/ejb-jar_1_1.dtd",
            "-//Sun Microsystems, Inc.//DTD Enterprise JavaBeans 1.1//EN");
        
        String sDescr = info.getDescription();
        if (sDescr.length() > 0)
            {
            int ofLine = sDescr.indexOf('\n');
            sDescr = ofLine > 0 ? sDescr.substring(0, ofLine) : sDescr;
            }
        else
            {
            sDescr = "no description";
            }
        xml.addElement("description").setString(sDescr);
        
        String sFileName    = new File(info.getTargetPath()).getName();
        int    ofExt        = sFileName.indexOf('.');
        String sDisplayName = ofExt < 0 ? sFileName : sFileName.substring(0, ofExt);
        xml.addElement("display-name").setString(sDisplayName);
        
        // TODO: small-icon?, large-icon?
          
        XmlElement xmlEjbs = xml.addElement("enterprise-beans");
        for (Enumeration enum = getEjbTable().elements(); enum.hasMoreElements();)
            {
            xmlEjbs.getElementList().add((XmlElement) enum.nextElement());
            }
        
        // TODO: assembly-descriptor?, ejb-client-jar?
         
        return xml.toString();
        }
    
    // Accessor for the property "EjbNames"
    /**
    * Getter for property EjbNames.<p>
    * Specifies the map of EJB names included into the package. It is keyed by
    * an EJB name (as it's put into the ejb-jar.xml) and a corresponding value
    * is the EJB  component name.
    * 
    * @see #recordEJB
    */
    public com.tangosol.util.StringTable getEjbNames()
        {
        return __m_EjbNames;
        }
    
    // Accessor for the property "EjbTable"
    /**
    * Getter for property EjbTable.<p>
    * Specifies the map of EJBs included into the package. It is keyed by a
    * component name and a corresponding value is an XmlElement carrying the
    * EJB descriptor.
    * 
    * @see #recordPackagerEntry
    * @see #generateDescriptor
    */
    public com.tangosol.util.StringTable getEjbTable()
        {
        return __m_EjbTable;
        }
    
    // Declared at the super level
    /**
    * Perform any required postprocessing on the PackagerSet after collecting
    * dependents, in the context of this packaging Model.
    */
    protected void postProcessPackagerEntries()
            throws com.tangosol.dev.packager.PackagerException
        {
        // import Component.Dev.Packager.Entry.TransientEntry;
        
        super.postProcessPackagerEntries();
        
        String sDescriptor = generateEjbDescriptor();
        
        TransientEntry descriptor = new TransientEntry();
        descriptor.setPathName(DESCRIPTOR_EJB);
        descriptor.setData(sDescriptor.getBytes());
        
        getPackagerSet().recordEntry(descriptor);

        }
    
    // Declared at the super level
    /**
    * Processes the packaging info adding the root dependency elements and
    * exclusion elements, in the context of this packaging Model.
    */
    protected void processPackageInfo()
            throws com.tangosol.dev.packager.PackagerException
        {
        super.processPackageInfo();
        
        // clear the maps
        getEjbNames().clear();
        getEjbTable().clear();

        }
    
    /**
    * Records the specified EJB to the PackagerSet.
    */
    protected void recordEjb(com.tangosol.dev.component.Component cd, _package.component.dev.compiler.ClassGenerator gen, _package.component.dev.compiler.remoter.EJB remoter)
        {
        // import Component.Dev.Compiler.Integrator;
        // import Component.Dev.Compiler.Remoter.EJB;
        // import Component.Dev.Packager.PackageInfo;
        // import Component.Dev.Packager.PackageInfo$ComponentInfo as ComponentInfo;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.run.xml.SimpleElement;
        // import com.tangosol.run.xml.XmlElement;
        // import java.util.Collection;
        // import java.util.Iterator;
        
        PackageInfo   info     = getPackageInfo();
        boolean       fSession = remoter.isSessionEJB(gen);
        SimpleElement xml      = new SimpleElement(fSession ? "session" : "entity");
        
        String sText = cd.getText();
        xml.addElement("description").
                setString(sText.length() > 0 ? sText : "no description");
        xml.addElement("display-name").setString(cd.getName());
        
        // TODO: small-icon?, large-icon?,
        
        Object oName    = getPropertyValue(cd, "_DefaultRemoteName");
        String sEjbName = oName instanceof String ? (String) oName : cd.getName();
        xml.addElement("ejb-name").setString(sEjbName);
        
        if (getEjbNames().contains(sEjbName))
            {
            getOutputTool().output("Packager",
                "*** Duplicate EJB name for " + cd.getQualifiedName() +
                " and " + getEjbNames().get(sEjbName));
            }
        else
            {
            getEjbNames().put(sEjbName, cd.getQualifiedName());
            }
        
        String sHome = remoter.getEffectiveClass(gen, cd, EJB.PEER_HOME_INTERFACE);
        xml.addElement("home").setString(relocateName(sHome));
        
        String sRemote = remoter.getEffectiveClass(gen, cd, EJB.PEER_REMOTE_INTERFACE);
        xml.addElement("remote").setString(relocateName(sRemote));
        
        // we can assume that Implementation exists at this level
        // (see JavaBeanLibrary#getDependents)
        String sImpl = remoter.getAutoGenClass(gen, cd, Integrator.PEER_FEED);
        xml.addElement("ejb-class").setString(relocateName(sImpl));
        
        if (fSession)
            {
            String   sSessionType = "Stateful";
            Object   oSessionType = getPropertyValue(cd, "Stateful");
            if (oSessionType instanceof Boolean &&
               ((Boolean) oSessionType).equals(Boolean.FALSE))
                {
                sSessionType = "Stateless";
                }
            xml.addElement("session-type").setString(sSessionType);
        
            String sTransType = "Container";
            Object oTransType = getPropertyValue(cd, "ContainerManagedTransaction");
            if (oTransType instanceof Boolean &&
               ((Boolean) oTransType).equals(Boolean.FALSE))
                {
                sTransType = "Bean";
                }
            xml.addElement("transaction-type").setString(sTransType);
            }
        else
            {
            boolean fCMP = remoter.isContainerManaged(gen);
        
            xml.addElement("persistence-type").
                setString(fCMP ? "Container" : "Bean");
        
            DataType dtPrimKey     = remoter.getPrimaryKeyDataType(gen);
            String   sPrimKeyClass = dtPrimKey.isComponent() ?
                relocateName(remoter.getEffectiveClass(gen, cd, EJB.PEER_PRIMARY_KEY)) :
                dtPrimKey.getClassName();
            xml.addElement("prim-key-class").setString(sPrimKeyClass);
        
            String sReentrant = "False"; // TODO: get from CD
            xml.addElement("reentrant").setString(sReentrant);
        
            if (fCMP)
                {
                Collection fieldsCMP = remoter.getDataFields(gen);
                for (Iterator iter = fieldsCMP.iterator(); iter.hasNext();)
                    {
                    String   sProp = (String) iter.next();
                    Property prop  = cd.getProperty(sProp);
                    if (prop == null)
                        {
                        continue;
                        }
        
                    XmlElement xmlCmp = xml.addElement("cmp-field");
        
                    String   sDescr = prop.getDescription();
                    if (sDescr.length() > 0)
                        {
                        xmlCmp.addElement("description").setString(sDescr);
                        }
                    xmlCmp.addElement("field-name").setString(sProp);
                    }
        
                String sPrimKeyField = remoter.getPrimaryKeyName(gen);
                if (sPrimKeyField != null)
                    {
                    xml.addElement("primkey-field").setString(sPrimKeyField);
                    }
                }
            }
        
        // TODO: env-entry*, ejb-ref*, security-role-ref*, resource-ref*
        
        ComponentInfo compInfo =
            (ComponentInfo) info.getIncludeComponents().get(cd.getQualifiedName());
        if (compInfo != null &&
            compInfo.getXMLEntries() != null && !compInfo.getXMLEntries().isEmpty())
            {
            _trace("TODO: XML entries are currently ignored", 1);
            }
        
        // TODO: assembly-descriptor?, ejb-client-jar?
        
        getEjbTable().put(cd.getQualifiedName(), xml);
        }
    
    // Declared at the super level
    /**
    * Records the specified JavaBean to the PackagerSet
    */
    protected void recordJavaBean(com.tangosol.dev.component.Component cd, _package.component.dev.compiler.ClassGenerator gen)
        {
        // import Component.Dev.Compiler.Remoter;
        
        super.recordJavaBean(cd, gen);
        
        if (cd.isRemote())
            {
            recordEjb(cd, gen, new Remoter.EJB());
            }
        }
    
    // Accessor for the property "EjbNames"
    /**
    * Setter for property EjbNames.<p>
    * Specifies the map of EJB names included into the package. It is keyed by
    * an EJB name (as it's put into the ejb-jar.xml) and a corresponding value
    * is the EJB  component name.
    * 
    * @see #recordEJB
    */
    private void setEjbNames(com.tangosol.util.StringTable pEjbNames)
        {
        __m_EjbNames = pEjbNames;
        }
    
    // Accessor for the property "EjbTable"
    /**
    * Setter for property EjbTable.<p>
    * Specifies the map of EJBs included into the package. It is keyed by a
    * component name and a corresponding value is an XmlElement carrying the
    * EJB descriptor.
    * 
    * @see #recordPackagerEntry
    * @see #generateDescriptor
    */
    private void setEjbTable(com.tangosol.util.StringTable pEjbTable)
        {
        __m_EjbTable = pEjbTable;
        }
    }
