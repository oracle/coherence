/* Class
*     _package.component.dev.packager.model.library.ejbLibrary.WebLogic
*/

package _package.component.dev.packager.model.library.ejbLibrary;

import _package.component.dev.compiler.remoter.EJB;
import _package.component.dev.packager.entry.TransientEntry;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.DataType;
import com.tangosol.run.xml.SimpleDocument;
import com.tangosol.run.xml.SimpleElement;
import com.tangosol.run.xml.XmlElement;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;

/**
* 
* +++++++++++++++++++++++++++
* 
* WebLogic packaging model is specific to the WebLogic application server
* (version 5.10 and above). It produces addition XML descriptors according to
* the following DTD: http://www.bea.com/servers/wls510/dtd/weblogic-ejb-jar.dtd
*/
public class WebLogic
        extends    _package.component.dev.packager.model.library.EjbLibrary
    {
    // Fields declarations
    
    /**
    * Property DefaultPersistenceTypeId
    *
    * Specified the default value of the <persistence-type>/<type-identifier>
    * element in weblogic-ejb-jar.xml descriptor.
    */
    private String __m_DefaultPersistenceTypeId;
    
    /**
    * Property DefaultPersistenceTypeVersion
    *
    * Specified the default value of the <persistence-type>/<type-version>
    * element in weblogic-ejb-jar.xml descriptor.
    */
    private String __m_DefaultPersistenceTypeVersion;
    
    /**
    * Property DefaultTypeStoragePrefix
    *
    * Specified the default value of the prefix for the
    * <persistence-type>/<type-storage> element in weblogic-ejb-jar.xml
    * descriptor.
    */
    private String __m_DefaultTypeStoragePrefix;
    
    /**
    * Property DESCRIPTOR_EJB_WL
    *
    */
    public static final String DESCRIPTOR_EJB_WL = "META-INF/weblogic-ejb-jar.xml";
    
    /**
    * Property EjbTableWL
    *
    * Specifies the map of EJBs that should be referenced in the
    * weblogic-ejb-jar.xml. It is keyed by a component name and a corresponding
    * value is an XmlElement.
    * 
    * @see #recordEJB
    * @see #generateDescriptorWL
    */
    private transient com.tangosol.util.StringTable __m_EjbTableWL;
    
    // Default constructor
    public WebLogic()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public WebLogic(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setClassRoot("");
            setDefaultPersistenceTypeId("WebLogic_CMP_RDBMS");
            setDefaultPersistenceTypeVersion("5.1.0");
            setDefaultTypeStoragePrefix("META-INF/weblogic-cmp-rdbms-");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        
        // state initialization: private properties
        try
            {
            __m_EjbTableWL = new com.tangosol.util.StringTable();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new WebLogic();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/model/library/ejbLibrary/WebLogic".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Add the child elements to the of <finder-list> element of the ejb
    * descriptor.
    */
    private void addFinders(com.tangosol.dev.component.Component cd, _package.component.dev.compiler.ClassGenerator gen, _package.component.dev.compiler.remoter.EJB remoter, com.tangosol.run.xml.XmlElement xml)
        {
        // import Component.Dev.Compiler.Remoter.EJB;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.run.xml.XmlElement;
        // import java.util.Enumeration;
        
        for (Enumeration enum = cd.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
            
            switch (remoter.getMethodType(gen, bhvr))
                {
                case EJB.METHOD_TYPE_FIND_SINGLE:
                case EJB.METHOD_TYPE_FIND_COLLECTION:
                case EJB.METHOD_TYPE_FIND_ENUMERATION:
                    {
                    String sMethName = bhvr.getName();
                    if (sMethName.startsWith("ejbFind"))
                        {
                        sMethName = "find" + sMethName.substring("ejbFind".length());
                        }
        
                    int cParams = bhvr.getParameterCount();
                    if (cParams == 1 &&
                        bhvr.getParameter(0).getDataType() == remoter.getPrimaryKeyDataType(gen))
                        {
                        // disregard "findByPrimaryKey" method
                        continue;
                        }
        
                    XmlElement xmlFinder = xml.addElement("finder");
                        {
                        xmlFinder.addElement("method-name").setString(sMethName);
        
                        XmlElement xmlParams = xmlFinder.addElement("method-params");
                        for (int i = 0; i < cParams; i++)
                            {
                            DataType dtParam = bhvr.getParameter(i).getDataType();
        
                            xmlParams.addElement("method-param").setString(dtParam.toString());
                            }
        
                        String sLookupName = "";
                        if (sMethName.startsWith("findBy"))
                            {
                            sLookupName = sMethName.substring("findBy".length());
                            }
                        String sQuery = cParams == 0 ? "(= 1 1)" : "(= " + sLookupName + " $0)";
        
                        xmlFinder.addElement("finder-query").setString(sQuery);
                        }
                    break;
                    }
                }
            }
        }
    
    /**
    * Generates a WebLogic specific CMP bean descriptor.
    */
    protected String generateCMPDescriptorWL(com.tangosol.dev.component.Component cd, _package.component.dev.compiler.ClassGenerator gen, _package.component.dev.compiler.remoter.EJB remoter)
        {
        // import com.tangosol.run.xml.SimpleDocument;
        // import com.tangosol.run.xml.XmlElement;
        // import java.util.Collection;
        // import java.util.Iterator;
        
        SimpleDocument xml = new SimpleDocument("weblogic-rdbms-bean",
            "http://www.bea.com/servers/wls510/dtd/weblogic-rdbms-persistence.dtd",
            "-//BEA Systems, Inc.//DTD WebLogic 5.1.0 EJB RDBMS Persistence//EN");
        
        xml.addElement("pool-name").setString(getPoolName(cd));
        xml.addElement("table-name").setString(getTableName(cd));
        
        XmlElement xmlMap = xml.addElement("attribute-map");
        
        Object[] aoFields  = (Object[]) getPropertyValue(cd, "DataFields");
        Object[] aoColumns = (Object[]) getPropertyValue(cd, "ContainerManagedColumns");
        
        if (aoFields != null)
            {
            int cFields  = aoFields.length;
            int cColumns = aoColumns ==  null ? 0 : aoColumns.length;
        
            for (int i = 0; i < cFields; i++)
                {
                String sFieldName  = (String) aoFields[i];
                String sColumnName = i < cColumns ? (String) aoColumns[i] : sFieldName;
        
                XmlElement xmlLink = xmlMap.addElement("object-link");
        
                xmlLink.addElement("bean-field").setString(sFieldName);
                xmlLink.addElement("dbms-column").setString(sColumnName);
                }
            }
            
        XmlElement xmlFinders = xml.addElement("finder-list");
        addFinders(cd, gen, remoter, xmlFinders);
        
        XmlElement xmlOptions = xml.addElement("options");
        xmlOptions.addElement("use-quoted-names").setString("false");
        
        return xml.toString();
        }
    
    /**
    * Generates a WebLogic specific ejb-jar descriptor.
    */
    protected String generateEjbDescriptorWL()
        {
        // import com.tangosol.run.xml.SimpleDocument;
        // import com.tangosol.run.xml.XmlElement;
        // import java.util.Enumeration;
        
        SimpleDocument xml = new SimpleDocument("weblogic-ejb-jar",
            "http://www.bea.com/servers/wls510/dtd/weblogic-ejb-jar.dtd",
            "-//BEA Systems, Inc.//DTD WebLogic 5.1.0 EJB//EN");
        
        for (Enumeration enum = getEjbTableWL().elements(); enum.hasMoreElements();)
            {
            xml.getElementList().add((XmlElement) enum.nextElement());
            }
        
        return xml.toString();
        }
    
    // Accessor for the property "DefaultPersistenceTypeId"
    /**
    * Getter for property DefaultPersistenceTypeId.<p>
    * Specified the default value of the <persistence-type>/<type-identifier>
    * element in weblogic-ejb-jar.xml descriptor.
    */
    public String getDefaultPersistenceTypeId()
        {
        return __m_DefaultPersistenceTypeId;
        }
    
    // Accessor for the property "DefaultPersistenceTypeVersion"
    /**
    * Getter for property DefaultPersistenceTypeVersion.<p>
    * Specified the default value of the <persistence-type>/<type-version>
    * element in weblogic-ejb-jar.xml descriptor.
    */
    public String getDefaultPersistenceTypeVersion()
        {
        return __m_DefaultPersistenceTypeVersion;
        }
    
    // Accessor for the property "DefaultTypeStoragePrefix"
    /**
    * Getter for property DefaultTypeStoragePrefix.<p>
    * Specified the default value of the prefix for the
    * <persistence-type>/<type-storage> element in weblogic-ejb-jar.xml
    * descriptor.
    */
    public String getDefaultTypeStoragePrefix()
        {
        return __m_DefaultTypeStoragePrefix;
        }
    
    // Accessor for the property "EjbTableWL"
    /**
    * Getter for property EjbTableWL.<p>
    * Specifies the map of EJBs that should be referenced in the
    * weblogic-ejb-jar.xml. It is keyed by a component name and a corresponding
    * value is an XmlElement.
    * 
    * @see #recordEJB
    * @see #generateDescriptorWL
    */
    public com.tangosol.util.StringTable getEjbTableWL()
        {
        return __m_EjbTableWL;
        }
    
    /**
    * Returns the value of the <pool-name> element in
    * weblogic-cmp-rdbms-XXX.xml descriptor for the specified EJB.
    */
    protected String getPoolName(com.tangosol.dev.component.Component cd)
        {
        Object oSource = getPropertyValue(cd, "ContainerManagedDatasource");
        
        return oSource instanceof String ?
            (String) oSource : getPackageInfo().getApplicationName() + "Pool";
        }
    
    /**
    * Returns the value of the <table-name> element in
    * weblogic-cmp-rdbms-XXX.xml descriptor for the specified EJB.
    */
    protected String getTableName(com.tangosol.dev.component.Component cd)
        {
        Object oTable = getPropertyValue(cd, "ContainerManagedTable");
        
        return oTable instanceof String ? (String) oTable : cd.getName();
        }
    
    // Declared at the super level
    /**
    * Perform any required postprocessing on the PackagerSet after collecting
    * dependents, in the context of this packaging Model.
    */
    protected void postProcessPackagerEntries()
            throws com.tangosol.dev.packager.PackagerException
        {
        // import Component.Dev.Packager.Entry.TransientEntry;
        
        super.postProcessPackagerEntries();
        
        String sDescriptor = generateEjbDescriptorWL();
        
        TransientEntry descriptor = new TransientEntry();
        descriptor.setPathName(DESCRIPTOR_EJB_WL);
        descriptor.setData(sDescriptor.getBytes());
        
        getPackagerSet().recordEntry(descriptor);
        }
    
    // Declared at the super level
    /**
    * Processes the packaging info adding the root dependency elements and
    * exclusion elements, in the context of this packaging Model.
    */
    protected void processPackageInfo()
            throws com.tangosol.dev.packager.PackagerException
        {
        super.processPackageInfo();
        
        // clear the maps
        getEjbTableWL().clear();

        }
    
    // Declared at the super level
    /**
    * Records the specified EJB to the PackagerSet.
    */
    protected void recordEjb(com.tangosol.dev.component.Component cd, _package.component.dev.compiler.ClassGenerator gen, _package.component.dev.compiler.remoter.EJB remoter)
        {
        // import Component.Dev.Packager.Entry.TransientEntry;
        // import com.tangosol.run.xml.SimpleElement;
        // import com.tangosol.run.xml.XmlElement;
        
        super.recordEjb(cd, gen, remoter);
        
        boolean    fEntity  = remoter.isEntityEJB(gen);
        boolean    fCMP     = fEntity && remoter.isContainerManaged(gen);
        String     sCMPName = fCMP ? getDefaultTypeStoragePrefix() +
                                cd.getName() + ".xml" : null;
        Object     oName    = getPropertyValue(cd, "_DefaultRemoteName");
        String     sEjbName = oName instanceof String ? (String) oName : cd.getName();
        
        SimpleElement xml = new SimpleElement("weblogic-enterprise-bean");
        
        xml.addElement("ejb-name").setString(sEjbName);
        
        if (fEntity)
            {
            XmlElement xmlPD = xml.addElement("persistence-descriptor");
                {
                XmlElement xmlType = xmlPD.addElement("persistence-type");
                    {
                    xmlType.addElement("type-identifier").
                        setString(getDefaultPersistenceTypeId());
                    xmlType.addElement("type-version").
                        setString(getDefaultPersistenceTypeVersion());
                    xmlType.addElement("type-storage").
                        setString(sCMPName);
                    }
                
                XmlElement xmlUse = xmlPD.addElement("persistence-use");
                    {
                    xmlUse.addElement("type-identifier").
                        setString(getDefaultPersistenceTypeId());
                    xmlUse.addElement("type-version").
                        setString(getDefaultPersistenceTypeVersion());
                    }
                }
            }
        xml.addElement("jndi-name").setString(sEjbName);
        
        getEjbTableWL().put(cd.getQualifiedName(), xml);
        
        if (fCMP)
            {
            // make the CMP-RDMS descriptor
            String sDescriptor = generateCMPDescriptorWL(cd, gen, remoter);
        
            TransientEntry descriptor = new TransientEntry();
            descriptor.setPathName(sCMPName);
            descriptor.setData(sDescriptor.getBytes());
        
            getPackagerSet().recordEntry(descriptor);
            }
        }
    
    // Accessor for the property "DefaultPersistenceTypeId"
    /**
    * Setter for property DefaultPersistenceTypeId.<p>
    * Specified the default value of the <persistence-type>/<type-identifier>
    * element in weblogic-ejb-jar.xml descriptor.
    */
    public void setDefaultPersistenceTypeId(String pDefaultPersistenceTypeId)
        {
        __m_DefaultPersistenceTypeId = pDefaultPersistenceTypeId;
        }
    
    // Accessor for the property "DefaultPersistenceTypeVersion"
    /**
    * Setter for property DefaultPersistenceTypeVersion.<p>
    * Specified the default value of the <persistence-type>/<type-version>
    * element in weblogic-ejb-jar.xml descriptor.
    */
    public void setDefaultPersistenceTypeVersion(String pDefaultPersistenceTypeVersion)
        {
        __m_DefaultPersistenceTypeVersion = pDefaultPersistenceTypeVersion;
        }
    
    // Accessor for the property "DefaultTypeStoragePrefix"
    /**
    * Setter for property DefaultTypeStoragePrefix.<p>
    * Specified the default value of the prefix for the
    * <persistence-type>/<type-storage> element in weblogic-ejb-jar.xml
    * descriptor.
    */
    public void setDefaultTypeStoragePrefix(String pDefaultTypeStoragePrefix)
        {
        __m_DefaultTypeStoragePrefix = pDefaultTypeStoragePrefix;
        }
    
    // Accessor for the property "EjbTableWL"
    /**
    * Setter for property EjbTableWL.<p>
    * Specifies the map of EJBs that should be referenced in the
    * weblogic-ejb-jar.xml. It is keyed by a component name and a corresponding
    * value is an XmlElement.
    * 
    * @see #recordEJB
    * @see #generateDescriptorWL
    */
    private void setEjbTableWL(com.tangosol.util.StringTable pEjbTableWL)
        {
        __m_EjbTableWL = pEjbTableWL;
        }
    }
