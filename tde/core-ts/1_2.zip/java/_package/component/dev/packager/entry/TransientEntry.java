/* Class
*     _package.component.dev.packager.entry.TransientEntry
*/

package _package.component.dev.packager.entry;

import com.tangosol.dev.packager.FilePackagerPath;
import com.tangosol.dev.packager.PackagerEntryNotFoundException;
import com.tangosol.util.Base;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;

/**
* 
* ++++++++++++++++++++++++++++++++++++++
* 
* TransientEntry represents a synthetic data without external storage and is
* specified using the data byte array or alternatively an InputStream. It also
* implements the PackagerDependencyElement interface being an element that has
* no dependencies and returns itself as a PackagerEntry.
*/
public class TransientEntry
        extends    _package.component.dev.packager.Entry
        implements com.tangosol.dev.packager.PackagerDependencyElement
    {
    // Fields declarations
    
    /**
    * Property Input
    *
    * Specifies an InputStream that has to be used in case the Data property is
    * not specified
    */
    private transient java.io.InputStream __m_Input;
    
    /**
    * Property PathName
    *
    * Specifies the fully qualified [packaged] path of this entry
    */
    private String __m_PathName;
    
    // Default constructor
    public TransientEntry()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TransientEntry(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new TransientEntry();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/entry/TransientEntry".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof TransientEntry)
            {
            TransientEntry that = (TransientEntry) obj;
            return this.getPathName().equals(that.getPathName());
            }
        return super.equals(obj);
        }
    
    // Declared at the super level
    /**
    * Returns binary data for this Entry suitable for the Packager.
    */
    public byte[] getData()
            throws com.tangosol.dev.packager.PackagerEntryNotFoundException
        {
        // import com.tangosol.dev.packager.PackagerEntryNotFoundException;
        // import com.tangosol.util.Base;
        // import java.io.InputStream;
        // import java.io.IOException;
        
        byte[] ab = super.getData();
        
        if (ab == null)
            {
            InputStream stream = getInput();
            if (stream != null)
                {
                try
                    {
                    ab = Base.read(stream);
                    }
                catch (IOException e)
                    {
                    throw new PackagerEntryNotFoundException(e.toString());
                    }
                }
            // this method is called just once, so there is no reason to cache...
            }
        
        return ab;
        }
    
    // From interface: com.tangosol.dev.packager.PackagerDependencyElement
    public java.util.List getDependents(ClassLoader classLoader)
        {
        return null;
        }
    
    // Accessor for the property "Input"
    /**
    * Getter for property Input.<p>
    * Specifies an InputStream that has to be used in case the Data property is
    * not specified
    */
    public java.io.InputStream getInput()
        {
        return __m_Input;
        }
    
    // From interface: com.tangosol.dev.packager.PackagerDependencyElement
    public java.util.List getPackagerEntries()
        {
        // import java.util.Collections;
        
        return Collections.singletonList(this);
        }
    
    // Declared at the super level
    /**
    * Returns a PackagerPath for this Entry.
    */
    public com.tangosol.dev.packager.PackagerPath getPath()
        {
        // import com.tangosol.dev.packager.FilePackagerPath;
        
        return new FilePackagerPath(getPathName());

        }
    
    // Accessor for the property "PathName"
    /**
    * Getter for property PathName.<p>
    * Specifies the fully qualified [packaged] path of this entry
    */
    public String getPathName()
        {
        return __m_PathName;
        }
    
    // Declared at the super level
    public int hashCode()
        {
        return getPathName().hashCode();
        }
    
    // Accessor for the property "Input"
    /**
    * Setter for property Input.<p>
    * Specifies an InputStream that has to be used in case the Data property is
    * not specified
    */
    public void setInput(java.io.InputStream pInput)
        {
        __m_Input = pInput;
        }
    
    // Accessor for the property "PathName"
    /**
    * Setter for property PathName.<p>
    * Specifies the fully qualified [packaged] path of this entry
    */
    public void setPathName(String pPathName)
        {
        __m_PathName = pPathName;
        }
    
    // Declared at the super level
    public String toString()
        {
        return "TransientEntry: " + getPathName();
        }
    }
