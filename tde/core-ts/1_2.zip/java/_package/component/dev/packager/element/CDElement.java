/* Class
*     _package.component.dev.packager.element.CDElement
*/

package _package.component.dev.packager.element;

import _package.component.dev.Design;
import _package.component.dev.Storage;
import _package.component.dev.compiler.ClassGenerator;
import _package.component.dev.packager.PackageInfo$ComponentInfo; // as ComponentInfo
import _package.component.dev.packager.PackageInfo;
import _package.component.dev.packager.element.ClassElement;
import _package.component.dev.packager.entry.CDEntry;
import com.tangosol.dev.assembler.ClassFile$Relocator;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.ComponentType;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.packager.PackagerComponentEntry;
import com.tangosol.dev.packager.PackagerDependencyElement; // as Element
import com.tangosol.dev.packager.PackagerEntry;
import com.tangosol.dev.packager.UnexpectedPackagerException;
import com.tangosol.util.WrapperException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
* The packager element representing a Component Definition.
*/
public class CDElement
        extends    _package.component.dev.packager.Element
    {
    // Fields declarations
    
    /**
    * Property ClassGenerator
    *
    * Specifies an instance of ClassGenerator that is used to either "compile
    * on-the-fly" or answer some compilation questions (for example: what
    * Integrator is used to compile this Component Definition?)
    */
    private transient _package.component.dev.compiler.ClassGenerator __m_ClassGenerator;
    
    /**
    * Property ClassName
    *
    * Specifies a "relocatable" name of a class this CDElement represents.
    * If this CDElement is not synthetic then ClassName is equal to
    * DataType.getComponentClassName(getComponent()).
    */
    private String __m_ClassName;
    
    /**
    * Property Component
    *
    * Specifies the Component Definition associated with this element (null if
    * the Component Definition is not available or this element is a synthetic
    * one)
    */
    private transient com.tangosol.dev.component.Component __m_Component;
    
    /**
    * Property ComponentName
    *
    * Specifies a fully qualified name of the Component Definition this
    * CDElement is bound to.
    * 
    * @see #ClassName property
    */
    private String __m_ComponentName;
    
    /**
    * Property MainCDEntry
    *
    * Specifies the main packager entry for this CDElement.
    */
    private transient _package.component.dev.packager.entry.CDEntry __m_MainCDEntry;
    
    /**
    * Property Synthetic
    *
    * Specifies whether this CDElement represents a synthetic class generated
    * out of Component Definition.
    */
    private boolean __m_Synthetic;
    
    // Default constructor
    public CDElement()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDElement(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CDElement();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/element/CDElement".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Define two CDElements to be equivalent iff their modelled classes are the
    * same.
    */
    public boolean equals(Object obj)
        {
        if (obj instanceof CDElement)
            {
            CDElement that = (CDElement) obj;
            return this.getClassName().equals(that.getClassName());
            }
        return super.equals(obj);
        }
    
    // Accessor for the property "ClassGenerator"
    /**
    * Getter for property ClassGenerator.<p>
    * Specifies an instance of ClassGenerator that is used to either "compile
    * on-the-fly" or answer some compilation questions (for example: what
    * Integrator is used to compile this Component Definition?)
    */
    public _package.component.dev.compiler.ClassGenerator getClassGenerator()
        {
        // import Component.Dev.Compiler.ClassGenerator;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.util.WrapperException;
        
        ClassGenerator gen = __m_ClassGenerator;
        if (gen == null)
            {
            Component cd = getComponent();
            if (cd != null)
                {
                gen = new ClassGenerator();
                gen.setCD(cd);
                gen.setStorage(getStorage());
                gen.setIntegrator(gen.findIntegrator(cd));
        
                setClassGenerator(gen);
                }
            }
        return gen;
        }
    
    // Accessor for the property "ClassName"
    /**
    * Getter for property ClassName.<p>
    * Specifies a "relocatable" name of a class this CDElement represents.
    * If this CDElement is not synthetic then ClassName is equal to
    * DataType.getComponentClassName(getComponent()).
    */
    public String getClassName()
        {
        // import com.tangosol.dev.component.DataType;
        
        String sClassName = __m_ClassName;
        if (sClassName == null)
            {
            if (isSynthetic())
                {
                throw new IllegalStateException("Unassigned synthetic name for: " + this);
                }
            sClassName = DataType.getComponentClassName(getComponentName());
            setClassName(sClassName);    
            }
        return sClassName;
        }
    
    // Accessor for the property "Component"
    /**
    * Getter for property Component.<p>
    * Specifies the Component Definition associated with this element (null if
    * the Component Definition is not available or this element is a synthetic
    * one)
    */
    public com.tangosol.dev.component.Component getComponent()
        {
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.packager.UnexpectedPackagerException;
        
        Component cd = __m_Component;
        if (cd == null && !isSynthetic())
            {
            String sName   = getComponentName();
            int    ofLocal = sName.indexOf('$');
            String sGlobal = ofLocal > 0 ? sName.substring(0, ofLocal) : sName;
        
            try
                {
                cd = getStorage().loadComponent(sGlobal, true, null);
                if (cd != null && ofLocal > 0)
                    {
                    cd = cd.getLocal(sName.substring(ofLocal + 1));
                    }
        
                if (cd == null)
                    {
                    throw new ComponentException("Unknown component: " + sName);
                    }
                setComponent(cd);
                }
            catch (ComponentException e)
                {
                throw new UnexpectedPackagerException(e);
                }
            }
        return cd;
        }
    
    // Accessor for the property "ComponentName"
    /**
    * Getter for property ComponentName.<p>
    * Specifies a fully qualified name of the Component Definition this
    * CDElement is bound to.
    * 
    * @see #ClassName property
    */
    public String getComponentName()
        {
        return __m_ComponentName;
        }
    
    // Declared at the super level
    /**
    * Return the immediate dependents of this PackagerDependencyElement in the
    * context of the specified ClassLoader.
    */
    public java.util.List getDependents(ClassLoader classLoader)
        {
        // import Component.Dev.Design;
        // import Component.Dev.Storage;
        // import Component.Dev.Packager.Element.ClassElement;
        // import Component.Dev.Packager.PackageInfo;
        // import Component.Dev.Packager.PackageInfo$ComponentInfo as ComponentInfo;
        // import com.tangosol.dev.assembler.ClassFile$Relocator;
        // import com.tangosol.dev.component.ComponentType;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.packager.PackagerDependencyElement as Element;
        // import java.util.LinkedList;
        // import java.util.List;
        // import java.util.Iterator;
        
        PackageInfo info    = getPackageInfo();
        Storage     store   = getStorage();
        Component   cd      = getComponent();
        List        listOne = null;
        List        listTwo = null;
        
        // check the component info
        ComponentInfo infoCD = null;
        if (cd != null)
            {
            infoCD = (ComponentInfo) info.getIncludeComponents().
                get(cd.getGlobalParent().getQualifiedName());
            }
        
        if (infoCD != null &&
            infoCD.getDependencyStyle() == ComponentInfo.DEPEND_BLANK)
            {
            return null;
            }
        
        // pass 1 -- use the Design info to get [non-calculatable] dependents
        if (cd != null)
            {
            listOne = Design.getDesignInfo(cd).getDependents(cd, store, info);
            }
        
        // pass2 -- calculate the direct (compile time) dependents
        ClassElement classElement = new ClassElement();
        classElement.setStorage(getStorage());
        classElement.setClassName(getClassName());
        classElement.setPackageInfo(info);
        
        _assert(info.getModel().getClassLoader() == classLoader);
        
        listTwo = classElement.getDependents(classLoader);
        if (listTwo == null)
            {
            return listOne;
            }
        
        if (listOne == null)
            {
            listOne = new LinkedList();
            }
        
        String sRelocator = ClassFile$Relocator.PACKAGE.replace('/', '.');
        
        // substitute ClassElements for "Component"s with CDElements
        for (Iterator iter = listTwo.iterator(); iter.hasNext();)
            {
            Element el = (Element) iter.next();
            if (el instanceof ClassElement)
                {
                String sClassName = ((ClassElement) el).getClassName();
                if (sClassName.startsWith(sRelocator))
                    {
                    // replace a ClassElement with a CDElement
                    CDElement cdElement = new CDElement();
        
                    String sName = ComponentType.getComponentName(sClassName);
        
                    if (Component.isQualifiedNameLegal(sName))
                        {
                        cdElement.setComponentName(sName);
                        }
                    else
                        {
                        cdElement.setSynthetic(true);
        
                        // make our best guess
                        int ofSuper  = sName.lastIndexOf('.') + 1;
                        int ofPrefix = sName.indexOf('_', ofSuper);
                        if (ofPrefix > 0)
                            {
                            sName = sName.substring(0, ofSuper) + sName.substring(ofPrefix);
                            }
        
                        cdElement.setComponentName(sName);
                        }
        
                    cdElement.setClassName(sClassName);
                    cdElement.setPackageInfo(info);
                    cdElement.setStorage(store);
        
                    iter.remove();
                    listOne.add(cdElement);
                    }
                }
            }
        
        if (!listOne.isEmpty())
            {
            listTwo.addAll(listOne);
            }
        return listTwo;
        }
    
    // Accessor for the property "MainCDEntry"
    /**
    * Getter for property MainCDEntry.<p>
    * Specifies the main packager entry for this CDElement.
    */
    public _package.component.dev.packager.entry.CDEntry getMainCDEntry()
        {
        // import Component.Dev.Packager.Entry.CDEntry;
        
        CDEntry entry = __m_MainCDEntry;
        if (entry == null)
            {
            entry = new CDEntry();
            entry.setElement(this);
        
            setMainCDEntry(entry);
            }
        return entry;
        }
    
    // Declared at the super level
    /**
    * Return the direct PackagerEntries of this PackagerDependencyElement.
    */
    public java.util.List getPackagerEntries()
        {
        // import Component.Dev.Design;
        // import Component.Dev.Packager.Entry.CDEntry;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.packager.PackagerEntry;
        // import com.tangosol.dev.packager.PackagerComponentEntry;
        // import com.tangosol.util.WrapperException;
        // import java.util.LinkedList;
        // import java.util.List;
        
        List      list = null;
        Component cd   = getComponent();
        
        if (cd != null)
            {
            list = Design.getDesignInfo(cd).getPackagerEntries(cd, getStorage(), getPackageInfo());
            }
        
        if (list == null)
            {
            list = new LinkedList();
            }
        
        list.add(new PackagerComponentEntry(getMainCDEntry()));
        
        return list;
        }
    
    // Declared at the super level
    /**
    * Define the hashCode of a PackagerDependencyClassElement to be that of the
    * modelled class.
    */
    public int hashCode()
        {
        return getClassName().hashCode();
        }
    
    // Accessor for the property "Synthetic"
    /**
    * Getter for property Synthetic.<p>
    * Specifies whether this CDElement represents a synthetic class generated
    * out of Component Definition.
    */
    public boolean isSynthetic()
        {
        return __m_Synthetic;
        }
    
    // Accessor for the property "ClassGenerator"
    /**
    * Setter for property ClassGenerator.<p>
    * Specifies an instance of ClassGenerator that is used to either "compile
    * on-the-fly" or answer some compilation questions (for example: what
    * Integrator is used to compile this Component Definition?)
    */
    public void setClassGenerator(_package.component.dev.compiler.ClassGenerator pClassGenerator)
        {
        __m_ClassGenerator = pClassGenerator;
        }
    
    // Accessor for the property "ClassName"
    /**
    * Setter for property ClassName.<p>
    * Specifies a "relocatable" name of a class this CDElement represents.
    * If this CDElement is not synthetic then ClassName is equal to
    * DataType.getComponentClassName(getComponent()).
    */
    public void setClassName(String pClassName)
        {
        __m_ClassName = pClassName;
        }
    
    // Accessor for the property "Component"
    /**
    * Setter for property Component.<p>
    * Specifies the Component Definition associated with this element (null if
    * the Component Definition is not available or this element is a synthetic
    * one)
    */
    public void setComponent(com.tangosol.dev.component.Component pComponent)
        {
        __m_Component = pComponent;
        }
    
    // Accessor for the property "ComponentName"
    /**
    * Setter for property ComponentName.<p>
    * Specifies a fully qualified name of the Component Definition this
    * CDElement is bound to.
    * 
    * @see #ClassName property
    */
    public void setComponentName(String pComponentName)
        {
        __m_ComponentName = pComponentName;
        }
    
    // Accessor for the property "MainCDEntry"
    /**
    * Setter for property MainCDEntry.<p>
    * Specifies the main packager entry for this CDElement.
    */
    protected void setMainCDEntry(_package.component.dev.packager.entry.CDEntry pMainCDEntry)
        {
        __m_MainCDEntry = pMainCDEntry;
        }
    
    // Accessor for the property "Synthetic"
    /**
    * Setter for property Synthetic.<p>
    * Specifies whether this CDElement represents a synthetic class generated
    * out of Component Definition.
    */
    public void setSynthetic(boolean pSynthetic)
        {
        __m_Synthetic = pSynthetic;
        }
    
    // Declared at the super level
    public String toString()
        {
        return "CDElement [" + getClassName() + ']';
        }
    }
