/* Class
*     _package.component.dev.packager.PackageInfo$ComponentInfo
*/

package _package.component.dev.packager;

/**
* This component represents the information about a particular component
* collected and used by the Packager.
* 
* @see PackageInfo#IncludeComponents property
*/
public class PackageInfo$ComponentInfo
        extends    _package.Component
    {
    // Fields declarations
    
    /**
    * Property DEPEND_BLANK
    *
    */
    public static final int DEPEND_BLANK = 2;
    
    /**
    * Property DEPEND_STANDARD
    *
    */
    public static final int DEPEND_STANDARD = 0;
    
    /**
    * Property DEPEND_SUBS
    *
    */
    public static final int DEPEND_SUBS = 1;
    
    /**
    * Property DependencyStyle
    *
    * Specifies the style of dependecy generation for an appropriate component.
    * Valid values are:
    * 
    * DEPEND_STANDARD -- Standard
    * DEPEND_SUBS -- All Subs
    * DEPEND_BLANK -- Blank
    */
    private int __m_DependencyStyle;
    
    /**
    * Property ExposeName
    *
    * Specifies the base name this component should be exposed at.
    * 
    * Currently not used.
    */
    private String __m_ExposeName;
    
    /**
    * Property ExposePackage
    *
    * Specifies the package this component should be exposed at.
    * 
    * Currently not used.
    */
    private String __m_ExposePackage;
    
    /**
    * Property ManifestEntries
    *
    * Specifies the list of manifest entries for an appropriate component. Each
    * entry is a NamedRef component.
    */
    private java.util.List __m_ManifestEntries;
    
    /**
    * Property XMLEntries
    *
    * Specifies the list of XML elements for an appropriate component. Each
    * entry is a NamedRef component.
    */
    private java.util.List __m_XMLEntries;
    
    // Default constructor
    public PackageInfo$ComponentInfo()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PackageInfo$ComponentInfo(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setDependencyStyle(0);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new PackageInfo$ComponentInfo();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/PackageInfo$ComponentInfo".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Accessor for the property "DependencyStyle"
    public int getDependencyStyle()
        {
        return __m_DependencyStyle;
        }
    
    // Accessor for the property "ExposeName"
    public String getExposeName()
        {
        return __m_ExposeName;
        }
    
    // Accessor for the property "ExposePackage"
    public String getExposePackage()
        {
        return __m_ExposePackage;
        }
    
    // Accessor for the property "ManifestEntries"
    public java.util.List getManifestEntries()
        {
        return __m_ManifestEntries;
        }
    
    // Accessor for the property "XMLEntries"
    public java.util.List getXMLEntries()
        {
        return __m_XMLEntries;
        }
    
    // Accessor for the property "DependencyStyle"
    public void setDependencyStyle(int pDependencyStyle)
        {
        __m_DependencyStyle = pDependencyStyle;
        }
    
    // Accessor for the property "ExposeName"
    public void setExposeName(String pExposeName)
        {
        __m_ExposeName = pExposeName;
        }
    
    // Accessor for the property "ExposePackage"
    public void setExposePackage(String pExposePackage)
        {
        __m_ExposePackage = pExposePackage;
        }
    
    // Accessor for the property "ManifestEntries"
    public void setManifestEntries(java.util.List pManifestEntries)
        {
        __m_ManifestEntries = pManifestEntries;
        }
    
    // Accessor for the property "XMLEntries"
    public void setXMLEntries(java.util.List pXMLEntries)
        {
        __m_XMLEntries = pXMLEntries;
        }
    }
