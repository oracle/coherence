/* Class
*     _package.component.dev.packager.entry.CDEntry
*/

package _package.component.dev.packager.entry;

import _package.component.dev.packager.element.CDElement;
import com.tangosol.dev.assembler.ClassFile;
import com.tangosol.dev.component.ComponentClassLoader; // as Loader
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.packager.ClassPackagerPath;
import com.tangosol.dev.packager.PackagerEntryNotFoundException;
import com.tangosol.dev.packager.PackagerPath;

/**
* 
* +++++++++++++++++++++++++++
* 
* CDEntry represents an Entry component for a Component Definition.
*/
public class CDEntry
        extends    _package.component.dev.packager.Entry
    {
    // Fields declarations
    
    /**
    * Property CDElement
    *
    * Helper property that specifies a CDElement that "produced" this CDEntry.
    */
    
    // Default constructor
    public CDEntry()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDEntry(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setSecured(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CDEntry();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/entry/CDEntry".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "CDElement"
    /**
    * Getter for property CDElement.<p>
    * Helper property that specifies a CDElement that "produced" this CDEntry.
    */
    public _package.component.dev.packager.element.CDElement getCDElement()
        {
        // import Component.Dev.Packager.Element.CDElement;
        
        return (CDElement) getElement();
        }
    
    // Declared at the super level
    /**
    * Returns binary data for this Entry suitable for the Packager.
    */
    public byte[] getData()
            throws com.tangosol.dev.packager.PackagerEntryNotFoundException
        {
        // import Component.Dev.Packager.Element.CDElement;
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.ComponentClassLoader as Loader;
        // import com.tangosol.dev.packager.PackagerEntryNotFoundException;
                
        CDElement element  = getCDElement();
        Loader    loader   = (Loader) element.getPackageInfo().getModel().getClassLoader();
        String    sClass   = element.getClassName();
        String    sPackage = element.getPackageInfo().getJavaPackage();
        
        try
            {
            ClassFile clsf = new ClassFile(loader.loadClassData(sClass));
            if (clsf == null)
                {
                throw new ComponentException("Cannot load class: " + sClass);
                }
        
            clsf.relocate(sPackage.replace('.', '/'));
        
            return clsf.getBytes();
            }
        catch (ComponentException e)
            {
            throw new PackagerEntryNotFoundException(e.getMessage());
            }
        }
    
    // Declared at the super level
    /**
    * Returns a PackagerPath for this Entry.
    */
    public com.tangosol.dev.packager.PackagerPath getPath()
        {
        // import Component.Dev.Packager.Element.CDElement;
        // import com.tangosol.dev.packager.ClassPackagerPath;
        // import com.tangosol.dev.packager.PackagerPath;
        
        PackagerPath path = super.getPath();
        if (path == null)
            {
            CDElement element    = getCDElement();
            String    sClassName = element.getClassName();
        
            path = new ClassPackagerPath(
                element.getPackageInfo().relocateName(sClassName));
            setPath(path);
            }
        return path;
        }
    
    // Declared at the super level
    public String toString()
        {
        return "CDEntry: " + getPath();
        }
    }
