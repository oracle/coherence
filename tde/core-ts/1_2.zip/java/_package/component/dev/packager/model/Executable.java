/* Class
*     _package.component.dev.packager.model.Executable
*/

package _package.component.dev.packager.model;

import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.DataType;
import java.util.Properties;

/**
* This component represents a packager model producing an Excutable (.jar or
* .zip) file.
*/
public class Executable
        extends    _package.component.dev.packager.Model
    {
    // Fields declarations
    
    // Default constructor
    public Executable()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Executable(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setClassRoot("");
            String[] a0 = new String[1];
                {
                a0[0] = "Class-Path";
                }
            setOptionalPackageAttributes(a0);
            String[] a1 = new String[1];
                {
                a1[0] = "Main-Class";
                }
            setRequiredPackageAttributes(a1);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Executable();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/model/Executable".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    protected java.util.Properties getManifestAttributes()
        {
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Component;
        // import java.util.Properties;
        
        Properties attributes = super.getManifestAttributes();
        
        String sMainClass = attributes.getProperty("Main-Class");
        if (Component.isQualifiedNameLegal(sMainClass))
            {
            attributes.setProperty("Main-Class",
                relocateName(DataType.getComponentClassName(sMainClass)));
            }
        return attributes;
        }
    }
