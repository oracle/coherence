/* Class
*     _package.component.dev.packager.model.webArchive.WebLogic
*/

package _package.component.dev.packager.model.webArchive;

import _package.component.Application;
import _package.component.dev.packager.element.CDElement;
import _package.component.dev.packager.entry.CDEntry;
import _package.component.dev.packager.entry.TransientEntry;
import com.tangosol.dev.packager.PackagerComponentEntry;
import com.tangosol.run.xml.SimpleElement;
import com.tangosol.run.xml.XmlElement;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;

/**
* 
* +++++++++++++++++++++++++++
* 
* WebLogic packaging model is specific to the WebLogic application server
* (version 5.10 and above). It produces addition XML descriptors according to
* the following DTD: http://www.bea.com/???/weblogic-web-jar.dtd
*/
public class WebLogic
        extends    _package.component.dev.packager.model.WebArchive
    {
    // Fields declarations
    
    /**
    * Property DESCRIPTOR_WEB_WL
    *
    */
    public static final String DESCRIPTOR_WEB_WL = "WEB-INF/weblogic.xml";
    
    /**
    * Property EjbTableWL
    *
    * Specifies the map of EJBs that should be referenced in the weblogic.xml.
    * It is keyed by a component name and a corresponding value is an
    * XmlElement.
    * 
    * @see #recordEJB
    * @see #generateDescriptorWL
    */
    private transient com.tangosol.util.StringTable __m_EjbTableWL;
    
    // Default constructor
    public WebLogic()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public WebLogic(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setClassRoot("WEB-INF/classes/");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        
        // state initialization: private properties
        try
            {
            __m_EjbTableWL = new com.tangosol.util.StringTable();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new WebLogic();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/model/webArchive/WebLogic".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Generates a deployment descriptor specific the the WebLogic web container.
    */
    protected String generateWebDescriptorWL()
        {
        // import Component.Application;
        // import com.tangosol.run.xml.SimpleElement;
        // import com.tangosol.run.xml.XmlElement;
        // import java.io.BufferedReader;
        // import java.io.InputStream;
        // import java.io.InputStreamReader;
        // import java.io.IOException;
        // import java.util.Enumeration;
        
        final String TAB = "  ";
        StringBuffer sb  = new StringBuffer();
        
        /*
        We can ieither nline the weblogic-web-jar.dtd
        
        <!DOCTYPE weblogic-web-app [
          ... the content of the dtd goes here
        ]>
        
        or make it a relative reference
        
        <!DOCTYPE weblogic-web-app SYSTEM './weblogic-web-jar.dtd'>
        
        and include the file itself into the war
        */
        
        StringBuffer sbXml = new StringBuffer("<?xml version=\"1.0\"?>\n");
        if (false)
            {
            sbXml.append("\n<!DOCTYPE weblogic-web-app SYSTEM 'file:d:/java/wl510/classes/weblogic/servlet/internal/dd/weblogic-web-jar.dtd'>\n\n");
            }
        else
            {
            sbXml.append("\n<!DOCTYPE weblogic-web-app [\n");
            try
                {
                InputStream inStream = ((Application) Application.get_Instance()).
                    getResourceAsStream("dtd/weblogic-web-jar.dtd");
                _assert(inStream != null, "dtd/weblogic-web-jar.dtd" + " is missing");
                BufferedReader in = new BufferedReader(
                    new InputStreamReader(inStream, "8859_1"));
                while (true)
                    {
                    String sLine = in.readLine();
                    if (sLine == null)
                        {
                        break;
                        }
                    sbXml.append(sLine + '\n');
                    }
                }
            catch (IOException e)
                {
                }
            sbXml.append("\n]>\n\n");
            }
        
        SimpleElement xml = new SimpleElement("weblogic-web-app");
        
        XmlElement xmlRef = xml.addElement("reference-descriptor");
        for (Enumeration enum = getEjbTableWL().elements(); enum.hasMoreElements();)
            {
            xmlRef.getElementList().add((XmlElement) enum.nextElement());
            }
        
        return sbXml.toString() + xml.toString();
        }
    
    // Accessor for the property "EjbTableWL"
    /**
    * Getter for property EjbTableWL.<p>
    * Specifies the map of EJBs that should be referenced in the weblogic.xml.
    * It is keyed by a component name and a corresponding value is an
    * XmlElement.
    * 
    * @see #recordEJB
    * @see #generateDescriptorWL
    */
    public com.tangosol.util.StringTable getEjbTableWL()
        {
        return __m_EjbTableWL;
        }
    
    // Declared at the super level
    /**
    * Perform any required postprocessing on the PackagerSet after collecting
    * dependents, in the context of this packaging Model.
    */
    protected void postProcessPackagerEntries()
            throws com.tangosol.dev.packager.PackagerException
        {
        // import Component.Dev.Packager.Entry.TransientEntry;
        
        super.postProcessPackagerEntries();
        
        String sDescriptor = generateWebDescriptorWL();
        
        TransientEntry descriptor = new TransientEntry();
        descriptor.setPathName(DESCRIPTOR_WEB_WL);
        descriptor.setData(sDescriptor.getBytes());
        
        getPackagerSet().recordEntry(descriptor);
        }
    
    // Declared at the super level
    /**
    * Processes the packaging info adding the root dependency elements and
    * exclusion elements, in the context of this packaging Model.
    */
    protected void processPackageInfo()
            throws com.tangosol.dev.packager.PackagerException
        {
        super.processPackageInfo();
        
        // clear the maps
        getEjbTableWL().clear();
        }
    
    // Declared at the super level
    /**
    * Record the specified EJB to the PackagerSet.
    */
    protected void recordEjb(com.tangosol.dev.component.Component cd, _package.component.dev.compiler.ClassGenerator gen, _package.component.dev.compiler.remoter.EJB remoter)
        {
        // import com.tangosol.run.xml.SimpleElement;
        
        super.recordEjb(cd, gen, remoter);
        
        SimpleElement xml = new SimpleElement("ejb-reference-description");
        
        Object oName    = getPropertyValue(cd, "_DefaultRemoteName");
        String sEjbName = oName instanceof String ? (String) oName : cd.getName();
        
        xml.addElement("ejb-ref-name").setString("ejb/" + sEjbName);
        xml.addElement("jndi-name").setString(sEjbName);
        
        getEjbTableWL().put(cd.getQualifiedName(), xml);
        }
    
    // Declared at the super level
    /**
    * Records the specified entry to the PackagerSet.
    * 
    * @return true is the entry is accepted; false otherwise
    * 
    * @throws com.tangosol.dev.packager.PackagerException if an entry cannot be
    * recorded
    */
    protected boolean recordPackagerEntry(com.tangosol.dev.packager.PackagerEntry entry)
            throws com.tangosol.dev.packager.PackagerException
        {
        // import Component.Dev.Packager.Element.CDElement;
        // import Component.Dev.Packager.Entry.CDEntry;
        // import com.tangosol.dev.packager.PackagerComponentEntry;
        
        if (entry instanceof PackagerComponentEntry)
            {
            CDEntry   entryCD = (CDEntry) ((PackagerComponentEntry) entry).getCDEntry();
            CDElement elemCD  = entryCD.getCDElement();
            
            if (elemCD.isSynthetic())
                {
                String sName = elemCD.getClassName();
                if (sName.indexOf(".ejbHome_")    > 0
                 || sName.indexOf(".ejbRemote_")  > 0
                 || sName.indexOf(".ejbPrimKey_") > 0)
                    {
                    // Weblogic requires those classes not to be deployed
                    // into the .war file
                    return false;
                    }
                }
            }
        
        return super.recordPackagerEntry(entry);
        }
    
    // Accessor for the property "EjbTableWL"
    /**
    * Setter for property EjbTableWL.<p>
    * Specifies the map of EJBs that should be referenced in the weblogic.xml.
    * It is keyed by a component name and a corresponding value is an
    * XmlElement.
    * 
    * @see #recordEJB
    * @see #generateDescriptorWL
    */
    private void setEjbTableWL(com.tangosol.util.StringTable pEjbTableWL)
        {
        __m_EjbTableWL = pEjbTableWL;
        }
    }
