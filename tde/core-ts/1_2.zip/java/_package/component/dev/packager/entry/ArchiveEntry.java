/* Class
*     _package.component.dev.packager.entry.ArchiveEntry
*/

package _package.component.dev.packager.entry;

import _package.component.dev.packager.Model;
import _package.component.dev.packager.PackageInfo;
import _package.component.util.NamedRef;
import com.tangosol.dev.packager.FilePackagerPath;
import com.tangosol.dev.packager.UnexpectedPackagerException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collections;

/**
* 
* ++++++++++++++++++++++++++++++++++++++
* 
* ArchiveEntry represents a Java Archive as a package entry. It has no
* "dependencies" and is specified using a temorary jar file. It also implements
* the PackagerDependencyElement interface being an element that has no
* dependencies and returns itself as a PackagerEntry.
*/
public class ArchiveEntry
        extends    _package.component.dev.packager.Entry
        implements com.tangosol.dev.packager.PackagerDependencyElement
    {
    // Fields declarations
    
    /**
    * Property JarFile
    *
    * JarFile object specifying the jar to read and customize entries from.
    */
    private transient java.util.jar.JarFile __m_JarFile;
    
    /**
    * Property PackageInfo
    *
    * PackageInfo describing the package this archive is an entry of.
    */
    private transient _package.component.dev.packager.PackageInfo __m_PackageInfo;
    
    /**
    * Property PackageModel
    *
    * Model used to build the package this archive is a part of
    */
    private transient _package.component.dev.packager.Model __m_PackageModel;
    
    /**
    * Property PathName
    *
    * Specifies the fully qualified [packaged] path of this entry
    */
    private String __m_PathName;
    
    // Default constructor
    public ArchiveEntry()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ArchiveEntry(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ArchiveEntry();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/entry/ArchiveEntry".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof ArchiveEntry)
            {
            ArchiveEntry that = (ArchiveEntry) obj;
            return this.getJarFile().equals(that.getJarFile()) &&
                   this.getPathName().equals(that.getPathName());
            }
        return super.equals(obj);
        }
    
    // Declared at the super level
    /**
    * Getter for property Data.<p>
    * Specifies this Entry as binary data suitable for packager. 
    */
    public byte[] getData(ClassLoader classLoader)
            throws com.tangosol.dev.packager.PackagerEntryNotFoundException
        {
        // import Component.Dev.Packager.Model;
        // import Component.Dev.Packager.PackageInfo;
        // import Component.Util.NamedRef;
        // import com.tangosol.dev.packager.UnexpectedPackagerException;
        // import java.io.File;
        // import java.io.FileInputStream;
        // import java.io.IOException;
        // import java.util.Collections;
        
        // create an temporary package info to build the archive
        PackageInfo infoOuter = getPackageInfo();
        PackageInfo infoInner = new PackageInfo();
        
        File fileInput  = new File(getJarFile().getName());
        File fileOutput = new File(fileInput.getParent(), "T_" + fileInput.getName());
        
        String sJarPath   = fileInput.getAbsolutePath();
        String sClassRoot = sJarPath.endsWith(".war") ? "WEB-INF/classes/" : "";
        
        infoInner.setModelName("Customization");
        infoInner.setTargetPath(fileOutput.getAbsolutePath());
        infoInner.setSuppressManifest(true);
        infoInner.setManifestEntries(Collections.EMPTY_LIST);
        infoInner.setXMLEntries(Collections.EMPTY_LIST);
        infoInner.setApplicationName(infoOuter.getApplicationName());
        infoInner.setDescription("");
        infoInner.setIncludeComponents(Collections.EMPTY_MAP);
        infoInner.setIncludeResources(Collections.singletonList(
            NamedRef.instantiate(sJarPath, sClassRoot)));
        infoInner.setExcludeResources(infoOuter.getExcludeResources());
        
        // build an inner archive
        Model pkgrOuter = getPackageModel();
        Model pkgrInner = infoInner.getModel();
        _assert(pkgrInner != null);
        
        pkgrInner.setOutputTool(pkgrOuter.getOutputTool());
        pkgrInner.setStorage(pkgrOuter.getStorage());
        pkgrInner.setDepth(pkgrOuter.getDepth() + 1);
        pkgrInner.setClassRoot(sClassRoot);
        pkgrInner.setDynamicCustomization(pkgrOuter.isDynamicCustomization());
        
        pkgrInner.getOutputTool().output("Packager", "Packaging " + this, true);
        
        try
            {
            pkgrInner.buildPackage();
        
            int    iSize = (int) fileOutput.length();
            byte[] ab    = new byte[iSize];
        
            FileInputStream stream = new FileInputStream(fileOutput);
        
            stream.read(ab);
            stream.close();
        
            return ab;
            }
        catch (Exception e)
            {
            throw new UnexpectedPackagerException(e);
            }
        finally
            {
            try
                {
                getJarFile().close();
                fileInput .delete();
                fileOutput.delete();
                }
            catch (IOException e) {}
            }
        
        

        }
    
    // From interface: com.tangosol.dev.packager.PackagerDependencyElement
    public java.util.List getDependents(ClassLoader classLoader)
        {
        return null;
        }
    
    // Accessor for the property "JarFile"
    /**
    * Getter for property JarFile.<p>
    * JarFile object specifying the jar to read and customize entries from.
    */
    public java.util.jar.JarFile getJarFile()
        {
        return __m_JarFile;
        }
    
    // Accessor for the property "PackageInfo"
    /**
    * Getter for property PackageInfo.<p>
    * PackageInfo describing the package this archive is an entry of.
    */
    public _package.component.dev.packager.PackageInfo getPackageInfo()
        {
        return __m_PackageInfo;
        }
    
    // Accessor for the property "PackageModel"
    /**
    * Getter for property PackageModel.<p>
    * Model used to build the package this archive is a part of
    */
    public _package.component.dev.packager.Model getPackageModel()
        {
        return __m_PackageModel;
        }
    
    // From interface: com.tangosol.dev.packager.PackagerDependencyElement
    public java.util.List getPackagerEntries()
        {
        // import java.util.Collections;
        
        return Collections.singletonList(this);
        }
    
    // Declared at the super level
    /**
    * Returns a PackagerPath for this Entry.
    */
    public com.tangosol.dev.packager.PackagerPath getPath()
        {
        // import com.tangosol.dev.packager.FilePackagerPath;
        
        return new FilePackagerPath(getPathName());

        }
    
    // Accessor for the property "PathName"
    /**
    * Getter for property PathName.<p>
    * Specifies the fully qualified [packaged] path of this entry
    */
    public String getPathName()
        {
        return __m_PathName;
        }
    
    // Declared at the super level
    public int hashCode()
        {
        return getPathName().hashCode();
        }
    
    // Accessor for the property "JarFile"
    /**
    * Setter for property JarFile.<p>
    * JarFile object specifying the jar to read and customize entries from.
    */
    public void setJarFile(java.util.jar.JarFile pJarFile)
        {
        __m_JarFile = pJarFile;
        }
    
    // Accessor for the property "PackageInfo"
    /**
    * Setter for property PackageInfo.<p>
    * PackageInfo describing the package this archive is an entry of.
    */
    public void setPackageInfo(_package.component.dev.packager.PackageInfo pPackageInfo)
        {
        __m_PackageInfo = pPackageInfo;
        }
    
    // Accessor for the property "PackageModel"
    /**
    * Setter for property PackageModel.<p>
    * Model used to build the package this archive is a part of
    */
    public void setPackageModel(_package.component.dev.packager.Model pPackageModel)
        {
        __m_PackageModel = pPackageModel;
        }
    
    // Accessor for the property "PathName"
    /**
    * Setter for property PathName.<p>
    * Specifies the fully qualified [packaged] path of this entry
    */
    public void setPathName(String pPathName)
        {
        __m_PathName = pPathName;
        }
    
    // Declared at the super level
    public String toString()
        {
        return "ArchiveEntry: " + getPathName();
        }
    }
