/* Class
*     _package.component.dev.packager.model.WebArchive
*/

package _package.component.dev.packager.model;

import _package.component.Ejb;
import _package.component.application.library.Web;
import _package.component.dev.compiler.Remoter;
import _package.component.dev.compiler.remoter.EJB;
import _package.component.dev.packager.PackageInfo;
import _package.component.dev.packager.element.CDElement;
import _package.component.dev.packager.entry.CDEntry;
import _package.component.dev.packager.entry.TransientEntry;
import _package.component.util.Config;
import _package.component.util.NamedRef;
import _package.component.web.EjbRef;
import _package.component.web.http.JspTag;
import _package.component.web.http.Servlet;
import _package.component.web.http.View;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.packager.PackagerComponentEntry;
import com.tangosol.run.xml.SimpleDocument;
import com.tangosol.run.xml.SimpleElement;
import com.tangosol.run.xml.XmlElement;
import com.tangosol.util.StringTable;
import java.beans.Introspector;
import java.io.File;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

/**
* This component represents a packager model producing a Web Archive (.war)
* file.
*/
public class WebArchive
        extends    _package.component.dev.packager.Model
    {
    // Fields declarations
    
    /**
    * Property DESCRIPTOR_WEB
    *
    * The name of a deployment descriptor
    */
    public static final String DESCRIPTOR_WEB = "WEB-INF/web.xml";
    
    /**
    * Property EjbNames
    *
    * Specifies the map of EJB names referred by this web module. It is keyed
    * by an EJB name (as it's put into the ejb-jar.xml) and a corresponding
    * value is the  EJB component name.
    * 
    * @see #recordEJB
    */
    private transient com.tangosol.util.StringTable __m_EjbNames;
    
    /**
    * Property EjbTable
    *
    * Specifies the map of EJBs referred by this web module. It is keyed by a
    * component name and a corresponding value is an XmlElement object
    * containing the EJB information.
    * Note: the value could be a DependencyElement for deferred processing.
    * 
    * @see #recordPackagerEntry
    * @see #recordEjb
    * @see #generateDescriptor
    */
    private transient com.tangosol.util.StringTable __m_EjbTable;
    
    /**
    * Property RouteTable
    *
    * Specifies the map of route Http elements included into this web module.
    * It is keyed by a route name and a corresponding value is a class name.
    * 
    * @see #recordHttp
    * @see #generateDescriptor
    */
    private transient com.tangosol.util.StringTable __m_RouteTable;
    
    /**
    * Property ServletList
    *
    * Specifies the list of servlet components included into this web module.
    * 
    * Note: currenty one and only one servlet is supported
    * 
    * @see #recordPackagerEntry
    * @see #generateDescriptor
    */
    private transient java.util.LinkedList __m_ServletList;
    
    /**
    * Property TAGLIB_EXT
    *
    * The tag lib file extension.
    */
    public static final String TAGLIB_EXT = ".tld";
    
    /**
    * Property TAGLIB_ROOT
    *
    * The root package for the automatically generated .tld files.
    */
    public static final String TAGLIB_ROOT = "WEB-INF/";
    
    /**
    * Property TagLibTable
    *
    * Specifies the map of tag libraries included into this web module. It is
    * keyed by a component name and a corresponding value is an XmlElement
    * carrying the taglib description.
    * 
    * @see #recordPackagerEntry
    * @see #generateDescriptor
    */
    private transient com.tangosol.util.StringTable __m_TagLibTable;
    
    /**
    * Property XMLElements
    *
    * Specifies a set of XML element names for the web.xml deployment 
    * descriptor.  The following is a quote from web-app_2_2.dtd:
    * 
    * <!ELEMENT web-app (icon?, display-name?, description?, distributable?,
    * context-param*, servlet*, servlet-mapping*, session-config?,
    * mime-mapping*, welcome-file-list?, error-page*, taglib*,
    * resource-ref*, security-constraint*, login-config?, security-role*,
    * env-entry*, ejb-ref*)>
    * 
    * @see http://java.sun.com/j2ee/dtds/web-app_2_2.dtd
    * 
    * The following elements are currently supported:
    *   - welcome-file (ref is the file path)
    *   - init-param (ref is a pair <name>=<value>)
    *   - env-entry (ref is a pair <name>=<value>)
    *     (only String type is currently supported)
    */
    private static final String[] __s_XMLElements;
    
    // Static initializer
    static
        {
        try
            {
            String[] a0 = new String[3];
                {
                a0[0] = "welcome-file";
                a0[1] = "init-param";
                a0[2] = "env-entry";
                }
            __s_XMLElements = a0;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public WebArchive()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public WebArchive(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setClassRoot("WEB-INF/classes/");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        
        // state initialization: private properties
        try
            {
            __m_EjbNames = new com.tangosol.util.StringTable();
            __m_EjbTable = new com.tangosol.util.StringTable();
            __m_RouteTable = new com.tangosol.util.StringTable();
            __m_ServletList = new java.util.LinkedList();
            __m_TagLibTable = new com.tangosol.util.StringTable();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Getter for virtual constant DefaultTargetExtension
    public String getDefaultTargetExtension()
        {
        return ".war";
        }
    
    // Getter for virtual constant XMLElements
    public String[] getXMLElements()
        {
        return (String[]) __s_XMLElements.clone();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new WebArchive();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/packager/model/WebArchive".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Find all the EJBs that the specified View component refers to.
    */
    private String[] findEjbReferences(com.tangosol.dev.component.Component cd, _package.component.dev.compiler.ClassGenerator gen)
        {
        // import Component.Web.EjbRef;
        // import com.tangosol.dev.component.Component;
        // import java.util.ArrayList;
        
        ArrayList list = new ArrayList();
        
        // check the EjbClass property on EjbRef children
        
        String[] asChildren = cd.getChildren();
        for (int iChild = 0; iChild < asChildren.length; iChild++)
            {
            String    sChildU = asChildren[iChild];
            Component cdChild = cd.getChild(sChildU);
        
            if (cdChild == null)
                {
                continue;
                }
            
             if (cdChild.isDerivedFrom("Component.Web.EjbRef"))
                {
                Object oTarget = getPropertyValue(cdChild, "EjbClass");
                if (oTarget instanceof String)
                    {
                    list.add(oTarget);
                    }
                }
            }
        
        return (String[]) list.toArray(new String[list.size()]);
        }
    
    /**
    * Generate a deployment descriptor according to the EJB 1.1 specification.
    */
    protected String generateWebDescriptor()
        {
        // import Component.Dev.Packager.PackageInfo;
        // import Component.Util.NamedRef;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.run.xml.SimpleDocument;
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.util.StringTable;
        // import java.io.File;
        // import java.util.Enumeration;
        // import java.util.Iterator;
        // import java.util.List;
        
        PackageInfo info        = getPackageInfo();
        Component   cdWebModule = getApplicationComponent();
        
        SimpleDocument xmlWeb   = new SimpleDocument("web-app",
            "http://java.sun.com/j2ee/dtds/web-app_2_2.dtd",
            "-//Sun Microsystems, Inc.//DTD Web Application 2.2//EN");
        
        // TODO: icon?
        
        // display-name
            {
            String sFileName    = new File(info.getTargetPath()).getName();
            int    ofExt        = sFileName.indexOf('.');
            String sDisplayName = ofExt < 0 ? sFileName : sFileName.substring(0, ofExt);
        
            xmlWeb.addElement("display-name").setString(sDisplayName);
            }
        
        // description
            {
            String sDescr = info.getDescription();
            if (sDescr.length() > 0)
                {
                int ofLine = sDescr.indexOf('\n');
                sDescr = ofLine < 0 ? sDescr : sDescr.substring(0, ofLine);
                }
            xmlWeb.addElement("description").setString(sDescr);
            }
        
        // TODO: distributable?
        
        // for now there is one and only one servlet
        if (!getServletList().isEmpty())
            {
            Component cdServlet    = (Component) getServletList().get(0);
            String    sServletName = cdServlet.getName();
        
            // context-param: Route-<name>
            StringTable tblRoute    = getRouteTable();
            String      sAttrPrefix = (String) getPropertyValue(cdServlet, "ATTR_ROUTEPREFIX");
            for (Enumeration enum = tblRoute.keys(); enum.hasMoreElements();)
                {
                String sRouteName = (String) enum.nextElement();
                String sRouteClz  = (String) tblRoute.get(sRouteName);
        
                XmlElement xmlParam = xmlWeb.addElement("context-param");
        
                xmlParam.addElement("param-name").setString(sAttrPrefix + sRouteName);
                xmlParam.addElement("param-value").setString(sRouteClz);
                // descriptor?
                }
        
            // other context-param's
            List listCtx = NamedRef.extractNamedRefList(info.getXmlEntries(), "context-param");
            for (Iterator iter = listCtx.iterator(); iter.hasNext();)
                {
                XmlElement xmlParam = xmlWeb.addElement("context-param");
        
                String sPair  = (String) ((NamedRef) iter.next()).getRef();
                int    of     = sPair.indexOf('=');
                String sName  = of < 0 ? sPair : sPair.substring(0, of);
                String sValue = of < 0 ? sPair : sPair.substring(of + 1);
        
                xmlParam.addElement("param-name").setString(sName);
                xmlParam.addElement("param-value").setString(sValue);
                // descriptor?
                }
        
            // servlet
                {
                XmlElement xmlServlet = xmlWeb.addElement("servlet");
        
                // TODO: icon?
        
                xmlServlet.addElement("servlet-name").setString(sServletName);
                xmlServlet.addElement("display-name").setString(sServletName);
        
                String sDescr = cdServlet.getText();
                xmlServlet.addElement("description").
                    setString(sDescr.length() > 0 ? sDescr : "no description");
        
                String sServletClz = DataType.getComponentClassName(cdServlet);
                xmlServlet.addElement("servlet-class").setString(relocateName(sServletClz));
        
                // init-param: ContextPath
                    {        
                    XmlElement xmlParam = xmlServlet.addElement("init-param");
        
                    // same as Model.EnterpriseArchive#recordModule
                    String sContextPath = (String)
                        getPropertyValue(cdWebModule, "ContextPath");
                    if (sContextPath == null)
                        {
                        sContextPath = '/' + cdWebModule.getName().toLowerCase();
                        }
        
                    String sAttrName = (String) getPropertyValue(cdServlet, "ATTR_CONTEXTPATH");
        
                    xmlParam.addElement("param-name").setString(sAttrName);
                    xmlParam.addElement("param-value").setString(sContextPath);
                    // description?
                    }
        
                // other init-param's
                List listInit = NamedRef.extractNamedRefList(info.getXmlEntries(), "init-param");
                for (Iterator iter = listInit.iterator(); iter.hasNext();)
                    {
                    XmlElement xmlParam = xmlServlet.addElement("init-param");
        
                    String sPair  = (String) ((NamedRef) iter.next()).getRef();
                    int    of     = sPair.indexOf('=');
                    String sName  = of < 0 ? sPair : sPair.substring(0, of);
                    String sValue = of < 0 ? sPair : sPair.substring(of + 1);
        
                    xmlParam.addElement("param-name").setString(sName);
                    xmlParam.addElement("param-value").setString(sValue);
                    // descriptor?
                    }
        
                // TODO: load-on-startup?, security-role-ref*
                }
        
            // servlet-mapping
                {
                XmlElement xmlMap = xmlWeb.addElement("servlet-mapping");
                
                xmlMap.addElement("servlet-name").setString(sServletName);
                xmlMap.addElement("url-pattern").setString("*" + 
                    getPropertyValue(cdServlet, "AnonymousExtension"));
                }
            
                {
                XmlElement xmlMap = xmlWeb.addElement("servlet-mapping");
        
                xmlMap.addElement("servlet-name").setString(sServletName);
                xmlMap.addElement("url-pattern").setString("*" + 
                    getPropertyValue(cdServlet, "AuthenticatingExtension"));
                }
            }
        
        // TODO: session-config?, mime-mapping*,
        
        // welcome-file-list
            {
            List listFiles = NamedRef.extractNamedRefList(info.getXmlEntries(), "welcome-file");
            if (!listFiles.isEmpty())
                {
                XmlElement xmlFiles = xmlWeb.addElement("welcome-file-list");
                for (Iterator iter = listFiles.iterator(); iter.hasNext();)
                    {
                    String sFile = (String) ((NamedRef) iter.next()).getRef();
                    xmlFiles.addElement("welcome-file").setString(sFile);
                    }
                }
            }
        
        // TODO: error-page*
        
        // taglib
            {
            for (Enumeration enum = getTaglibTable().elements(); enum.hasMoreElements();)
                {
                xmlWeb.getElementList().add((XmlElement) enum.nextElement());
                }
            }
        
        // TODO: resource-ref*, security-constraint*, login-config?, security-role*,
        
        // env-entry*
            {
            List listEnv = NamedRef.extractNamedRefList(info.getXmlEntries(), "env-entry");
            for (Iterator iter = listEnv.iterator(); iter.hasNext();)
                {
                XmlElement xmlEnv = xmlWeb.addElement("env-entry");
        
                String sPair  = (String) ((NamedRef) iter.next()).getRef();
                int    of     = sPair.indexOf('=');
                String sName  = of < 0 ? sPair : sPair.substring(0, of);
                String sValue = of < 0 ? sPair : sPair.substring(of + 1);
        
                xmlEnv.addElement("env-entry-name").setString(sName);
                xmlEnv.addElement("env-entry-value").setString(sValue);
                xmlEnv.addElement("env-entry-type").setString("java.lang.String");
                }
            }
        
        // ejb-ref
            {
            for (Enumeration enum = getEjbTable().elements(); enum.hasMoreElements();)
                {
                xmlWeb.getElementList().add((XmlElement) enum.nextElement());
                }
            }
        
        return xmlWeb.toString();

        }
    
    // Declared at the super level
    /**
    * Return the path of a configuration file entry for this packaging model.
    * Default implementation defers to the Util.Config that places the config
    * entry into /META-INF directory. Subcomponents override this method if
    * they need to place configutation files differently.
    * 
    * @param sConfigName  name of the configuration file (unqualified)
    * 
    * @return full path of the configuration file in the package
    */
    public String getConfigPath(String sConfigName)
        {
        // import Component.Util.Config;
        
        // WebLogic and Orion (unlike Apachi and JRun) see the root of the war,
        // but not the "WEB-INF/classes" in a classpath!
        
        return Config.resolveName(sConfigName);
        }
    
    // Accessor for the property "EjbNames"
    /**
    * Getter for property EjbNames.<p>
    * Specifies the map of EJB names referred by this web module. It is keyed
    * by an EJB name (as it's put into the ejb-jar.xml) and a corresponding
    * value is the  EJB component name.
    * 
    * @see #recordEJB
    */
    public com.tangosol.util.StringTable getEjbNames()
        {
        return __m_EjbNames;
        }
    
    // Accessor for the property "EjbTable"
    /**
    * Getter for property EjbTable.<p>
    * Specifies the map of EJBs referred by this web module. It is keyed by a
    * component name and a corresponding value is an XmlElement object
    * containing the EJB information.
    * Note: the value could be a DependencyElement for deferred processing.
    * 
    * @see #recordPackagerEntry
    * @see #recordEjb
    * @see #generateDescriptor
    */
    public com.tangosol.util.StringTable getEjbTable()
        {
        return __m_EjbTable;
        }
    
    // Accessor for the property "RouteTable"
    /**
    * Getter for property RouteTable.<p>
    * Specifies the map of route Http elements included into this web module.
    * It is keyed by a route name and a corresponding value is a class name.
    * 
    * @see #recordHttp
    * @see #generateDescriptor
    */
    public com.tangosol.util.StringTable getRouteTable()
        {
        return __m_RouteTable;
        }
    
    // Accessor for the property "ServletList"
    /**
    * Getter for property ServletList.<p>
    * Specifies the list of servlet components included into this web module.
    * 
    * Note: currenty one and only one servlet is supported
    * 
    * @see #recordPackagerEntry
    * @see #generateDescriptor
    */
    public java.util.LinkedList getServletList()
        {
        return __m_ServletList;
        }
    
    // Accessor for the property "TagLibTable"
    /**
    * Getter for property TagLibTable.<p>
    * Specifies the map of tag libraries included into this web module. It is
    * keyed by a component name and a corresponding value is an XmlElement
    * carrying the taglib description.
    * 
    * @see #recordPackagerEntry
    * @see #generateDescriptor
    */
    public com.tangosol.util.StringTable getTagLibTable()
        {
        return __m_TagLibTable;
        }
    
    // Declared at the super level
    /**
    * Perform any required postprocessing on the PackagerSet after collecting
    * dependents, in the context of this packaging Model.
    */
    protected void postProcessPackagerEntries()
            throws com.tangosol.dev.packager.PackagerException
        {
        // import Component.Dev.Packager.Element.CDElement;
        // import Component.Dev.Packager.Entry.TransientEntry;
        // import com.tangosol.util.StringTable;
        // import com.tangosol.run.xml.XmlElement;
        // import java.util.Enumeration;
        
        super.postProcessPackagerEntries();
        
        // clean-up the EJB table from deferred but never processed entries
        StringTable tblEjb = getEjbTable();
        for (Enumeration enum = tblEjb.keys(); enum.hasMoreElements();)
            {
            String sKey = (String) enum.nextElement();
            Object oVal = tblEjb.get(sKey);
        
            if (oVal == null)
                {
                getOutputTool().output("Packager",
                    "*** Warning: The class is missing for component: " + sKey);
                }
        
            if (!(oVal instanceof XmlElement))
                {
                tblEjb.remove(sKey);
                }
            }
        
        String sDescriptor = generateWebDescriptor();
        
        TransientEntry descriptor = new TransientEntry();
        descriptor.setPathName(DESCRIPTOR_WEB);
        descriptor.setData(sDescriptor.getBytes());
        
        getPackagerSet().recordEntry(descriptor);

        }
    
    // Declared at the super level
    /**
    * Processes the packaging info adding the root dependency elements and
    * exclusion elements, in the context of this packaging Model.
    */
    protected void processPackageInfo()
            throws com.tangosol.dev.packager.PackagerException
        {
        super.processPackageInfo();
        
        // clear the maps
        getEjbNames()   .clear();
        getEjbTable()   .clear();
        getRouteTable() .clear();
        getServletList().clear();
        getTagLibTable().clear();
        }
    
    /**
    * Record the View children of the specified component to the PackagerSet.
    */
    private void processViews(com.tangosol.dev.component.Component cd, _package.component.dev.compiler.ClassGenerator gen)
        {
        // import com.tangosol.dev.component.Component;
        // import Component.Web.Http.View;
        
        String[] asChildren = cd.getChildren();
        for (int iChild = 0; iChild < asChildren.length; iChild++)
            {
            String    sChildU = asChildren[iChild];
            Component cdChild = cd.getChild(sChildU);
        
            if (cdChild != null &&
                cdChild.isDerivedFrom("Component.Web.Http.View"))
                {
                recordView(cdChild, gen);
                }
            }
        }
    
    /**
    * Record the specified EJB to the PackagerSet.
    */
    protected void recordEjb(com.tangosol.dev.component.Component cd, _package.component.dev.compiler.ClassGenerator gen, _package.component.dev.compiler.remoter.EJB remoter)
        {
        // import Component.Dev.Compiler.Remoter.EJB;
        // import Component.Dev.Packager.PackageInfo;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.run.xml.SimpleElement;
        // import com.tangosol.run.xml.XmlElement;
        
        boolean fSession = remoter.isSessionEJB(gen);
        
        SimpleElement xml = new SimpleElement("ejb-ref");
        
        String sDescr = cd.getText();
        xml.addElement("description").
            setString(sDescr.length() > 0 ? sDescr : "no description");
        
        Object oName    = getPropertyValue(cd, "_DefaultRemoteName");
        String sEjbName = oName instanceof String ? (String) oName : cd.getName();
        xml.addElement("ejb-ref-name").setString("ejb/" + sEjbName);
        
        if (getEjbNames().contains(sEjbName))
            {
            getOutputTool().output("Packager",
                "*** Duplicate EJB name for " + cd.getQualifiedName() +
                " and " + getEjbNames().get(sEjbName));
            }
        else
            {
            getEjbNames().put(sEjbName, cd.getQualifiedName());
            }
        
        xml.addElement("ejb-ref-type").setString(fSession ? "Session" : "Entity");
        
        String sHome = remoter.getEffectiveClass(gen, cd, EJB.PEER_HOME_INTERFACE);
        xml.addElement("home").setString(relocateName(sHome));
        
        String sRemote = remoter.getEffectiveClass(gen, cd, EJB.PEER_REMOTE_INTERFACE);
        xml.addElement("remote").setString(relocateName(sRemote));
        
        // TODO: ejb-link?
        
        getEjbTable().put(cd.getQualifiedName(), xml);
        }
    
    /**
    * Record the specified Http routable element.
    */
    protected void recordHttp(com.tangosol.dev.component.Component cd, _package.component.dev.compiler.ClassGenerator gen)
        {
        // import Component.Web.Http.View;
        // import com.tangosol.dev.component.DataType;
        
        String sRouteClz = relocateName(DataType.getComponentClassName(cd));
        
        getRouteTable().put(cd.getName(), sRouteClz);
        
        if (cd.isDerivedFrom("Component.Web.Http.View"))
            {
            recordView(cd, gen);
            }
        }
    
    // Declared at the super level
    /**
    * Records the specified entry to the PackagerSet.
    * 
    * @return true is the entry is accepted; false otherwise
    * 
    * @throws com.tangosol.dev.packager.PackagerException if an entry cannot be
    * recorded
    */
    protected boolean recordPackagerEntry(com.tangosol.dev.packager.PackagerEntry entry)
            throws com.tangosol.dev.packager.PackagerException
        {
        // import Component.Application.Library.Web;
        // import Component.Ejb;
        // import Component.Dev.Compiler.Remoter;
        // import Component.Dev.Packager.Element.CDElement;
        // import Component.Dev.Packager.Entry.CDEntry;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.packager.PackagerComponentEntry;
        // import Component.Web.Http.Servlet;
        
        boolean fAdded = super.recordPackagerEntry(entry);
        
        if (fAdded && entry instanceof PackagerComponentEntry)
            {
            CDEntry     entryCD = (CDEntry) ((PackagerComponentEntry) entry).getCDEntry();
            CDElement   elemCD  = entryCD.getCDElement();
            Component   cd      = elemCD.getComponent();
        
            if (cd != null && cd.isGlobal() && !cd.isResultAbstract())
                {
                // the main servlet is designed as the FrontServlet property
                // on the Component.Application.Library.Web component
                // and all other servlets are currenty ignored
        
                if (cd.isDerivedFrom("Component.Web.Http.Servlet"))
                    {
                    String sFrontServlet = (String) 
                        getPropertyValue(getApplicationComponent(), "FrontServlet");
                    if (sFrontServlet == null)
                        {
                        sFrontServlet = "Component.Web.Http.Servlet";
                        }
                    if (cd.getQualifiedName().equals(sFrontServlet))
                        {
                        getServletList().add(cd);
                        }
                    }
                else if (cd.isDerivedFrom("Component.Web.Http") &&
                         getRootDependencyElements().contains(elemCD))
                    {
                    recordHttp(cd, elemCD.getClassGenerator());
                    }
                else if (cd.isDerivedFrom("Component.Ejb") && cd.isRemote())
                    {
                    // EJBs could be explicitly specified
                    // or already encountered by the View processing (see #recordView)
                    if (getRootDependencyElements().contains(elemCD) ||
                        getEjbTable().contains(cd.getQualifiedName()))
                        {
                        recordEjb(cd, elemCD.getClassGenerator(), new Remoter.EJB());
                        }
                    else
                        {
                        // defer this element processing for later
                        getEjbTable().put(cd.getQualifiedName(), elemCD);
                        }
                    }
                }
            }
        
        return fAdded;
        }
    
    /**
    * Record the tag library for the specified View component to the
    * PackagerSet.
    * 
    * @return name of the tag library
    */
    protected String recordTagLibrary(com.tangosol.dev.component.Component cd, _package.component.dev.compiler.ClassGenerator gen)
        {
        // import Component.Dev.Packager.Entry.TransientEntry;
        // import com.tangosol.run.xml.SimpleDocument;
        // import com.tangosol.run.xml.XmlElement;
        
        SimpleDocument xml = new SimpleDocument("taglib",
            "http://java.sun.com/j2ee/dtds/web-jsptaglibrary_1_1.dtd",
            "-//Sun Microsystems, Inc.//DTD JSP Tag Library 1.1//EN");
        
        xml.addElement("tlibversion").setString("1.0");
        xml.addElement("jspversion") .setString("1.1");
        xml.addElement("shortname")  .setString(cd.getName());
        
        // TODO: uri?
        
        String sInfo = cd.getTip();
        if (sInfo.length() > 0)
            {
            xml.addElement("info").setString(sInfo);
            }
        
        // do all the tags [recursively]
        recordTags(cd, gen, null, xml);
        
        String sTagLib = cd.getName() + TAGLIB_EXT;
        
        TransientEntry tld = new TransientEntry();
           
        tld.setPathName(TAGLIB_ROOT + sTagLib);
        tld.setData(xml.toString().getBytes());
        
        getPackagerSet().recordEntry(tld);
        
        return sTagLib;
        }
    
    /**
    * Process all the JspTag children of the specified component (View or
    * JspTag)
    * 
    * @param cd  component definition (View or JspTag)
    * @param sPrefix  prefix for the JspTag names
    * @param xmlTaglib  the taglib xml to add the tags info to
    */
    protected void recordTags(com.tangosol.dev.component.Component cd, _package.component.dev.compiler.ClassGenerator gen, String sPrefix, com.tangosol.run.xml.XmlElement xmlTaglib)
        {
        // import Component.Web.Http.JspTag;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.run.xml.XmlElement;
        // import java.beans.Introspector;
        
        String[] asChildren = cd.getChildren();
        for (int iChild = 0; iChild < asChildren.length; iChild++)
            {
            String    sChild  = asChildren[iChild];
            Component cdChild = cd.getChild(sChild);
        
            if (cdChild == null ||
                !cdChild.isDerivedFrom("Component.Web.Http.JspTag"))
                {
                continue;
                }
        
            String sTagName = sPrefix == null ? sChild : sPrefix + '-' + sChild;
        
            XmlElement xmlTag = xmlTaglib.addElement("tag");
        
            Object   oType = getPropertyValue(cdChild, "BodyContentType");
            String   sBody = oType instanceof String ? (String) oType : "JSP";
            DataType dtClz = gen.resolveDataType(         /* could be optimized out */
                                DataType.getComponentType(cdChild.getQualifiedName()));
            String   sTagClz = relocateName(dtClz.getClassName());
            
            xmlTag.addElement("name").setString(sTagName);
            xmlTag.addElement("tagclass").setString(sTagClz);
            // TODO: teiclass?
            xmlTag.addElement("bodycontent").setString(sBody);
        
            String sInfo = cdChild.getTip();
            if (sInfo.length() > 0)
                {
                xmlTag.addElement("info").setString(sInfo);
                }
        
            // attribute*
        
            // property "Parameters" is indexed String virtual constant
            Object oParams = getPropertyValue(cdChild, "Parameters");
            if (oParams instanceof Object[])
                {
                XmlElement xmlAttr = xmlTag.addElement("attribute");
        
                Object[] aoValue = (Object []) oParams;
                for (int i = 0; i < aoValue.length; i++)
                    {
                    String sName = (String) aoValue[i];
                    xmlAttr.addElement("name").
                        setString(Introspector.decapitalize(sName));
                    // TODO: required? , rtexprvalue?
                    }
                }
        
            recordTags(cdChild, gen, sTagName, xmlTaglib);
            }
        }
    
    /**
    * Record the specified View component to the PackagerSet.
    */
    protected void recordView(com.tangosol.dev.component.Component cd, _package.component.dev.compiler.ClassGenerator gen)
        {
        // import Component.Dev.Compiler.Remoter;
        // import Component.Dev.Packager.Element.CDElement;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.run.xml.SimpleElement;
        // import com.tangosol.run.xml.XmlElement;
        
        String[] asEjb = findEjbReferences(cd, gen);
        
        for (int i = 0; i < asEjb.length; i++)
            {
            String sEjb = asEjb[i];
        
            if (Component.isGlobalNameLegal(sEjb))
                {
                if (getEjbTable().contains(sEjb))
                    {
                    Object oEjb = getEjbTable().get(sEjb);
                    if (oEjb instanceof CDElement)
                        {
                        // this EJB was already encountered (see #recordPackagerEntry)
                        CDElement elemCD = (CDElement) oEjb;
                        recordEjb(elemCD.getComponent(), elemCD.getClassGenerator(), new Remoter.EJB());
                        }
                    }
                else
                    {
                    // defer for later processing
                    getEjbTable().put(sEjb, null);
                    }
                }
            }
        
        String sTagLib = recordTagLibrary(cd, gen);
        
        // taglib elements
            {
            SimpleElement xml = new SimpleElement("taglib");
        
            xml.addElement("taglib-uri").setString(sTagLib);
            xml.addElement("taglib-location").setString('/' + TAGLIB_ROOT + sTagLib);
            
            getTagLibTable().put(cd.getQualifiedName(), xml);
            }
        
        // recurse for contained views
        processViews(cd, gen);
        }
    
    // Accessor for the property "EjbNames"
    /**
    * Setter for property EjbNames.<p>
    * Specifies the map of EJB names referred by this web module. It is keyed
    * by an EJB name (as it's put into the ejb-jar.xml) and a corresponding
    * value is the  EJB component name.
    * 
    * @see #recordEJB
    */
    private void setEjbNames(com.tangosol.util.StringTable pEjbNames)
        {
        __m_EjbNames = pEjbNames;
        }
    
    // Accessor for the property "EjbTable"
    /**
    * Setter for property EjbTable.<p>
    * Specifies the map of EJBs referred by this web module. It is keyed by a
    * component name and a corresponding value is an XmlElement object
    * containing the EJB information.
    * Note: the value could be a DependencyElement for deferred processing.
    * 
    * @see #recordPackagerEntry
    * @see #recordEjb
    * @see #generateDescriptor
    */
    private void setEjbTable(com.tangosol.util.StringTable pEjbTable)
        {
        __m_EjbTable = pEjbTable;
        }
    
    // Accessor for the property "RouteTable"
    /**
    * Setter for property RouteTable.<p>
    * Specifies the map of route Http elements included into this web module.
    * It is keyed by a route name and a corresponding value is a class name.
    * 
    * @see #recordHttp
    * @see #generateDescriptor
    */
    private void setRouteTable(com.tangosol.util.StringTable pRouteTable)
        {
        __m_RouteTable = pRouteTable;
        }
    
    // Accessor for the property "ServletList"
    /**
    * Setter for property ServletList.<p>
    * Specifies the list of servlet components included into this web module.
    * 
    * Note: currenty one and only one servlet is supported
    * 
    * @see #recordPackagerEntry
    * @see #generateDescriptor
    */
    private void setServletList(java.util.LinkedList pServletList)
        {
        __m_ServletList = pServletList;
        }
    
    // Accessor for the property "TagLibTable"
    /**
    * Setter for property TagLibTable.<p>
    * Specifies the map of tag libraries included into this web module. It is
    * keyed by a component name and a corresponding value is an XmlElement
    * carrying the taglib description.
    * 
    * @see #recordPackagerEntry
    * @see #generateDescriptor
    */
    private void setTagLibTable(com.tangosol.util.StringTable pTagLibTable)
        {
        __m_TagLibTable = pTagLibTable;
        }
    }
