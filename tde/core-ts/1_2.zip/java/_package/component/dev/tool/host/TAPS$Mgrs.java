/* Class
*     _package.component.dev.tool.host.TAPS$Mgrs
*/

package _package.component.dev.tool.host;

import _package.component.dev.Storage;
import _package.component.dev.Tool;
import _package.component.dev.tool.Compiler;
import _package.component.dev.tool.DocumentChooser;
import _package.component.dev.tool.ResourceDesigner;
import _package.component.dev.tool.host.CDDesigner;
import _package.component.dev.tool.outputTool.Tracer;
import _package.component.dev.util.DocInfo;
import _package.component.gUI.control.container.jComponent.AbstractButton;
import com.tangosol.dev.component.Constants;
import javax.swing.JOptionPane;

/**
* This is a host of CDChooser and other manager tools. The host site of this
* host is a JTabbedPane set by TAPS.configureTools()
*/
public class TAPS$Mgrs
        extends    _package.component.dev.tool.Host
    {
    // Fields declarations
    
    // Default constructor
    public TAPS$Mgrs()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPS$Mgrs(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setTitle("Managers Host");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new TAPS$Mgrs();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/host/TAPS$Mgrs".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    /**
    * Extract and save a Resource SIgnature out of the [externally
    * created/edited] resource binary
    */
    private void commitResource(String sResource)
        {
        // import Component.Dev.Tool.OutputTool.Tracer;
        // import Component.Dev.Tool.ResourceDesigner;
        
        $Docs hostDocs = ($Docs) getHost().getTool("Docs");
        
        ResourceDesigner dsnr = hostDocs.findResourceDesigner(sResource, null);
        if (dsnr == null)
            {
            dsnr = new ResourceDesigner();
            dsnr.setResourceName(sResource);
            dsnr.setStorage(getStorage());
            dsnr.setOutputTool(new Tracer());
            }
        
        dsnr.commitResource();
        dsnr.setOpen(false);
        }
    
    /**
    * Compile the specified component
    */
    private void compileComponent(String sComponent, boolean fDepends, _package.component.gUI.control.container.jComponent.jPanel.ToolSite toolSite)
        {
        // import Component.Dev.Tool;
        // import Component.Dev.Tool.Compiler;
        // import Component.Dev.Tool.DocumentChooser;
        // import Component.Dev.Tool.OutputTool.Tracer;
        // import Component.Dev.Tool.Host.CDDesigner;
        // import Component.GUI.Control.Container.JComponent.AbstractButton;
        // import com.tangosol.dev.component.Constants;
        
        $Docs hostDocs = ($Docs) getHost().getTool("Docs");
        
        CDDesigner dsnr = hostDocs.findCDDesigner(sComponent, null);
        if (dsnr == null)
            {
            Compiler toolCompiler = (Compiler) getTool("Compiler");
            if (toolCompiler == null)
                {
                toolCompiler = new Compiler();
                toolCompiler.setCommandItem(
                    (AbstractButton) toolSite._findName("Context$BuildDepends"));    
                toolCompiler.setStorage(getStorage());
                toolCompiler.setOutputTool(new Tracer());
                toolCompiler.setComponentName(sComponent);
                toolCompiler.setDependencies(fDepends);
                if (fDepends)
                    {
                    Tool toolChooser = getActiveTool();
                    if (toolChooser instanceof DocumentChooser)
                        {
                        int iFilter = ((DocumentChooser) toolChooser).getViewFilter();
                        toolCompiler.setModifiedOnly(
                            (iFilter & Constants.EXISTS_INSERT) != 0);
                        }
                    }
        
                addTool(toolCompiler, "Compiler");
                }
        
            // toggle the compiler's state
            toolCompiler.setOpen(!toolCompiler.isOpen());
            }
        else
            {
            dsnr.setActive(true);
            dsnr.compile(fDepends);
            }
        }
    
    // Declared at the super level
    /**
    * Return true if the specified action fired by the specified host is
    * enabled by this tool; false otherwise.
    * The hosts additionally return true if at least one child tool of this
    * host "enables" this action.
    * 
    * This method is mostly used by host sites' menus to provide a visual clue
    * to the question:
    *  - If this host issues a command (host action), will there be any tool
    * being able to process this command
    * 
    * When the host is specified, the specified action is expected to be fired
    * by that host using fireHostAction(). If the host is null, this action is
    * expected to be fired by this tool itself using fireToolAction().
    * 
    * @param sAction  action name
    * @param host  the source of the action
    * @param  oValue an optional value to be passed along
    */
    public boolean isActionEnabled(String sAction, _package.component.dev.tool.Host host, Object oValue)
        {
        if (sAction.equals(ACTION_VIEW))
            {
            return true;
            }
        else
            {
            return super.isActionEnabled(sAction, host, oValue);
            }
        }
    
    // Declared at the super level
    /**
    * Notification send by one of the containing hosts
    * 
    * @param host  the acted host
    * @param sName  action name
    * @param oValue  associated value
    * 
    * @throws EventDeathException if a tool doesn't want this notification be
    * propagated anymore
    */
    public void onHostAction(_package.component.dev.tool.Host host, String sAction, Object oValue)
        {
        // import Component.Dev.Tool;
        
        if (sAction.equals(ACTION_VIEW))
            {
            Object[] aoValue = (Object[]) oValue;
            
            String  sToolName = ((String)  aoValue[0]);
            boolean fShow     = ((Boolean) aoValue[1]).booleanValue();
        
            Tool tool = getTool(sToolName);
            if (tool != null)
                {
                tool.setOpen(fShow);
        
                if (fShow)
                    {
                    tool.setActive(true);
                    }
                }
            }
        else
            {
            super.onHostAction(host, sAction, oValue);
            }
        }
    
    // Declared at the super level
    /**
    * Notification send by one of the contained tools.
    * 
    * @param tool  the acted tool
    * @param sName  action name
    * @param oValue  associated value
    */
    public void onToolAction(_package.component.dev.Tool tool, String sAction, Object oValue)
        {
        // import Component.Dev.Util.DocInfo;
        
        if (sAction.equals(ACTION_COMPILE)
         || sAction.equals(ACTION_COMPILE_TREE))
            {
            if (oValue instanceof DocInfo)
                {
                DocInfo info  = (DocInfo) oValue;
                String  sType = info.getType();
        
                if (sType.equals("Component") || sType.equals("Signature"))
                    {
                    boolean fDepends = sAction.equals(ACTION_COMPILE_TREE);
                    compileComponent(info.getName(), fDepends, tool.getToolSite());
                    }
                else if (sType.equals("Resource"))
                    {
                    commitResource(info.getName());
                    }
                }
            }
        else if (
            sAction.equals(ACTION_REMOVE))
            {
            if (oValue instanceof DocInfo)
                {
                removeDocument((DocInfo) oValue, tool);
                }    
            }
        else
            {
            super.onToolAction(tool, sAction, oValue);
            }
        }
    
    /**
    * Remove the specified document (Component, Signature or Resource)
    */
    private void removeDocument(_package.component.dev.util.DocInfo info, _package.component.dev.Tool tool)
        {
        // import Component.Dev.Storage;
        // import Component.Dev.Tool.Host.CDDesigner;
        // import Component.Dev.Tool.ResourceDesigner;
        // import javax.swing.JOptionPane;
        
        String  sType      = info.getType();
        Object  oLocator   = info.getStorageLocator();
        Storage storageRaw = getStorage().locatePersistentStorage(null);
        boolean fComponent = sType.equals("Component");
        boolean fSignature = sType.equals("Signature");
        boolean fResource  = sType.equals("Resource");
        
        if (!fComponent && !fSignature && !fResource ||
            (oLocator == null || storageRaw == null ||
                !oLocator.equals(storageRaw.getLocator())))
            {
            _beep();
            return;
            }
        
        $Docs hostDocs = ($Docs) getHost().getTool("Docs");
        
        String     sName    = info.getName();
        CDDesigner designer = hostDocs.findCDDesigner(sName, null);
        if (designer != null)
            {
            // the specified component is open, what to do?
            }
        
        StringBuffer sb = new StringBuffer();
        if ((fComponent || fSignature) && info.getSubLocator() != null)
            {
            sb.append("Removing this component will invalidate any component\n")
              .append("than depends on this component.\n\n");
            }
        
        sb.append("Are you sure you want to remove the ")
          .append(fComponent ? "component\n" :
                  fSignature ? "customization for\n" :
                               "resource\n")
          .append(sName);
        
        Integer intAns = (Integer) getHostSite().msg("Confirm", new Object[]
            {
            sb.toString(),
            "Remove",
            new Integer(JOptionPane.YES_NO_OPTION),
            });
        
        if (intAns.intValue() != JOptionPane.YES_OPTION)
            {
            return;
            }
        
        try
            {
            if (fResource)
                {
                ResourceDesigner dsnr = hostDocs.findResourceDesigner(sName, null);
                if (dsnr != null)
                    {
                    dsnr.setOpen(false);
                    }
                getStorage().removeResourceSignature(sName);
                }
            else
                {
                getStorage().removeComponent(sName);
                }
        
            if (fComponent)
                {
                fireToolAction(ACTION_REFRESH, "Components");
                }
            else if (fSignature)
                {
                fireToolAction(ACTION_REFRESH, "Classes");
                fireToolAction(ACTION_REFRESH, "Libraries");
                }
            else // if (fResource)
                {
                fireToolAction(ACTION_REFRESH, "Resources");
                fireToolAction(ACTION_REFRESH, "Libraries");
                }
            }
        catch (Exception e)
            {
            _trace(e.toString(), 1);
            }
        }
    }
