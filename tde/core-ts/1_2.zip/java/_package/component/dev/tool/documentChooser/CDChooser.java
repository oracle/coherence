/* Class
*     _package.component.dev.tool.documentChooser.CDChooser
*/

package _package.component.dev.tool.documentChooser;

import com.tangosol.dev.component.Constants;

public class CDChooser
        extends    _package.component.dev.tool.DocumentChooser
    {
    // Fields declarations
    
    /**
    * Property RootComponent
    *
    * Specifies a fully qualified Component name that is going to be a root of
    * the selection tree.
    */
    private String __m_RootComponent;
    
    // Default constructor
    public CDChooser()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDChooser(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(3.0F);
            setRootComponent(null);
            setTitle("Components");
            setToolHandleText("Frameworks");
            setToolSiteClass(Class.forName("_package/component/gUI/control/container/jComponent/jPanel/toolSite/documentBrowser/CDBrowser".replace('/', '.')));
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new CDChooser();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/documentChooser/CDChooser".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "RootComponent"
    public String getRootComponent()
        {
        return __m_RootComponent;
        }
    
    // Accessor for the property "RootComponent"
    public void setRootComponent(String pRootComponent)
        {
        __m_RootComponent = pRootComponent;
        }
    
    // Declared at the super level
    protected void setViewFilter(int pViewFilter)
        {
        // import com.tangosol.dev.component.Constants;
        
        // for now, only the EXISTS_INSERT bit is relevant
        int iFilterNew = pViewFilter     & Constants.EXISTS_INSERT;
        int iFilterOld = getViewFilter() & Constants.EXISTS_INSERT;
        
        if (iFilterNew == iFilterOld)
            {
            return;
            }
        
        super.setViewFilter(pViewFilter);

        }
    }
