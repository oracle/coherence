/* Class
*     _package.component.dev.tool.host.cDTool.PackagingTool
*/

package _package.component.dev.tool.host.cDTool;

import _package.component.dev.packager.Model;
import _package.component.dev.packager.PackageInfo$ComponentInfo;
import _package.component.dev.packager.PackageInfo;
import _package.component.dev.tool.OutputTool;
import _package.component.gUI.control.container.jComponent.jPanel.toolSite.Packager;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.Property;
import com.tangosol.dev.component.SubChangeEvent;
import com.tangosol.dev.component.Trait;
import com.tangosol.dev.packager.PackagerException;
import java.beans.PropertyChangeEvent;
import java.util.Date;
import java.util.Map;

public class PackagingTool
        extends    _package.component.dev.tool.host.CDTool
        implements com.tangosol.dev.component.SubChangeListener
    {
    // Fields declarations
    
    // Default constructor
    public PackagingTool()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PackagingTool(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(40.0F);
            setTitle("Packager");
            setToolSiteClass(Class.forName("_package/component/gUI/control/container/jComponent/jPanel/toolSite/Packager".replace('/', '.')));
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new PackagingTool$Worker("Worker", this, true), "Worker");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new PackagingTool();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/host/cDTool/PackagingTool".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    public void makeTarget()
        {
        // lets ask the host (CDDesigner) to save the data into the CD before we proceed
        if (!getHost().save())
            {
            // canceled or (quite unlikely) failed
            return;
            }
        
        $Worker Worker = ($Worker) _findName("Worker");
        
        Worker.start();
        Worker.setNotification(true);
        }
    
    public void makeTargetOnDaemon()
        {
        // import Component.Dev.Tool.OutputTool;
        // import Component.Dev.Packager.Model;
        // import Component.Dev.Packager.PackageInfo;
        // import Component.Dev.Packager.PackageInfo$ComponentInfo;
        // import com.tangosol.dev.packager.PackagerException;
        // import java.util.Date;
        // import java.util.Map;
        
        OutputTool toolOutput = getOutputTool();
        String     sOutTitle  = getTitle();
        
        toolOutput.setActive(true);
        toolOutput.clearOutput(sOutTitle);
        
        PackageInfo info  = new PackageInfo();
        info.load(getGlobalCD());
        
        Model packager = info.getModel();
        if (packager == null)
            {
            toolOutput.output(sOutTitle, "Packaging failed: " +
                "Packaging model " + info.getModelName() + " is not supported.");
            return;
            }
        
        packager.setApplicationComponent(getGlobalCD());
        packager.setStorage(getStorage());
        packager.setOutputTool(toolOutput);
        
        toolOutput.output(sOutTitle, "Packaging started:  " + new Date());
        
        try
            {
            packager.buildPackage();
            toolOutput.output(sOutTitle, "Packaging completed:  " + new Date());
            }
        catch (Throwable e)
            {
            if (e instanceof PackagerException)
                {
                e = ((PackagerException) e).getOriginalException();
                }
            else
                {
                _trace(e);
                }
            toolOutput.output(sOutTitle, "Packaging failed: " + e.toString());
            }

        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets closed<p>
    * Note: this method is called before the host is notified with closeTool(),
    * so no relevant host's destruction has been done yet.
    * 
    * @see #setOpen
    * @see Host#closeTool
    */
    public void onClose()
        {
        super.onClose();
        
        getGlobalCD().removeSubChangeListener(this);
        }
    
    // Declared at the super level
    /**
    * Notification from the CDDesigner host that the global CD has changed
    * 
    * This could happen only in the case when renaming a component causes the
    * Component Definition reference to change
    * 
    * @see CDDesigner#renameComponent()
    * @see CDDesigner#setGlobalCD()
    */
    public void onGlobalCDChanged(com.tangosol.dev.component.Component cdOld)
        {
        // import Component.Dev.Packager.PackageInfo;
        // import com.tangosol.dev.component.Component;
        
        super.onGlobalCDChanged(cdOld);
        
        Component cdNew = getGlobalCD();
        
        if (!isOpen() || cdOld == cdNew)
            {
            return;
            }
        
        if (cdOld != null)
            {
            cdOld.removeSubChangeListener(this);
            }
        
        cdNew.addSubChangeListener(this);
        }
    
    // Declared at the super level
    /**
    * Notification from the CDDesigner host that the local CD has changed
    * 
    * @see CDDesigner#setLocalCD()
    */
    public void onLocalCDChanged(com.tangosol.dev.component.Component cdOld)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.Packager;
        
        super.onLocalCDChanged(cdOld);
        
        if (isOpen())
            {
            ((Packager) getToolSite()).setComponent(getLocalCD());
            }
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets opened.<p>
    * Note: this method is called after the host is notified with openTool(),
    * so all the relevant host's initialization is already done.
    * 
    * @see #setOpen
    * @see Host#openTool
    */
    public void onOpen()
        {
        super.onOpen();
        
        onGlobalCDChanged(null);
        onLocalCDChanged(null);

        }
    
    // From interface: com.tangosol.dev.component.SubChangeListener
    public void subChange(com.tangosol.dev.component.SubChangeEvent evt)
        {
        // import com.tangosol.dev.component.Trait;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.SubChangeEvent;
        // import java.beans.PropertyChangeEvent;
        
        Trait trait = evt.getSubTrait();
        
        if (trait instanceof Property)
            {
            Property prop = (Property) trait;
        
            if (evt.getAction() == SubChangeEvent.SUB_CHANGE)
                {
                PropertyChangeEvent evtChange = (PropertyChangeEvent) evt.getEvent();
        
                if (prop.getName().startsWith("$"))
                    {
                    // since changing those properties by hand is extremely rare case
                    // just reloading the view is the simplest solution
                    getToolSite().load(true);
                    }
                }
            }
        }
    }
