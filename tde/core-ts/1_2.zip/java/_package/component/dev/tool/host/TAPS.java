/* Class
*     _package.component.dev.tool.host.TAPS
*/

package _package.component.dev.tool.host;

import _package.component.dev.Storage;
import _package.component.dev.packager.Model;
import _package.component.dev.packager.PackageInfo;
import _package.component.dev.project.ProjectInfo$Target$Library; // as Library
import _package.component.dev.project.ProjectInfo$Target; // as Target
import _package.component.dev.project.ProjectInfo;
import _package.component.dev.project.StorageFactory;
import _package.component.dev.storage.TAPSStorage;
import _package.component.dev.tool.OutputTool;
import _package.component.dev.tool.TestRun;
import _package.component.dev.tool.documentChooser.CDChooser;
import _package.component.dev.tool.documentChooser.JCSChooser;
import _package.component.dev.tool.documentChooser.LibraryChooser;
import _package.component.dev.tool.documentChooser.ResourceChooser;
import _package.component.dev.util.DocInfo;
import _package.component.gUI.control.container.jComponent.AbstractButton;
import _package.component.gUI.control.container.jComponent.jPanel.TAPSLibrary;
import _package.component.gUI.control.container.jComponent.jPanel.TAPSLogin;
import _package.component.gUI.control.container.jComponent.jPanel.TAPSNewProject;
import _package.component.gUI.control.container.jComponent.jPanel.TAPSProject;
import _package.component.gUI.control.container.jComponent.jPanel.toolSite.HostSite;
import _package.component.gUI.control.container.jComponent.jPanel.wizardPane.IntegrationWizard;
import _package.component.gUI.control.container.window.frame.JFrame;
import _package.component.util.Config;
import _package.component.util.NamedRef;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.Integration;
import com.tangosol.license.DevelopmentEdition;
import com.tangosol.license.LicensedObject$LicenseData; // as LicenseData
import com.tangosol.license.LicensedObject;
import com.tangosol.util.StringTable;
import java.awt.Cursor;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
* The host of this toolset.
*/
public class TAPS
        extends    _package.component.dev.tool.Host
        implements java.lang.Runnable
    {
    // Fields declarations
    
    /**
    * Property LICENSE
    *
    */
    public static final String LICENSE = "Tangosol Server:  Development Edition";
    
    /**
    * Property StorageConfig
    *
    * Configuration info for the Storage
    */
    private _package.component.util.Config __m_StorageConfig;
    
    /**
    * Property UIConfig
    *
    * Configuration info for the UI
    */
    private _package.component.util.Config __m_UIConfig;
    
    // Default constructor
    public TAPS()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPS(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setTitle("Tangosol Server");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new TAPS$Docs("Docs", this, true), "Docs");
        _addChild(new TAPS$Mgrs("Mgrs", this, true), "Mgrs");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new TAPS();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/host/TAPS".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.Dev.Storage.TAPSStorage;
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.HostSite;
        // import Component.GUI.Control.Container.Window.Frame.JFrame;
        // import Component.Util.Config;
        

        }
    
    private void addLibraries(java.io.File[] aFile)
        {
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.GUI.Control.Container.JComponent.JPanel.TAPSLibrary;
        
        TAPSStorage storage = (TAPSStorage) getStorage();
        Target      target  = (Target) getHostSite().dialogBox(new TAPSLibrary(),
            new Object[] {storage, aFile});
        
        if (target != null)
            {
            // force the storage to reload
            storage.close();
            storage.set_Storage(null);
        
            fireHostAction(ACTION_REFRESH, "Classes");
            fireHostAction(ACTION_REFRESH, "Libraries");
            fireHostAction(ACTION_REFRESH, "Resources");
            }

        }
    
    /**
    * Close the current project
    * 
    * @return true if the project has been closed; false if the operation has
    * been canceled
    */
    private boolean closeProject()
        {
        $Mgrs hostMgrs = ($Mgrs) getTool("Mgrs");
        $Docs hostDocs = ($Docs) getTool("Docs");
        
        TAPSStorage storage = (TAPSStorage) getStorage();
        
        if (storage == null)
            {
            return true;
            }
        
        // store the current storage configuration into a property
        Config cfgStorage = new Config();
        storage.saveConfig(cfgStorage, "");
        setStorageConfig(cfgStorage);
        
        // persist the UI configuration for this project
        Config cfgProject = new Config();
        getHostSite().saveConfig(cfgProject, "UI");
        storeConfiguration(cfgProject, storage.getProject());
        
        hostDocs.onHostAction(this, ACTION_CLOSE_ALL, null);
        
        // if all the documents are closed, notify the browsers
        if (!hostDocs.enumTools().hasMoreElements())
            {
            setStorage(null);
            hostMgrs.onHostAction(this, ACTION_PROJECT_CLOSE, null);
            storage.close();
            updateTitle();
        
            return true;
            }
        else
            {
            return false;
            }
        }
    
    private void createProject()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.TAPSLogin;
        // import Component.GUI.Control.Container.JComponent.JPanel.TAPSNewProject;
        // import Component.Dev.Project.ProjectInfo;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        
        TAPSStorage storage = (TAPSStorage) getStorage();
        if (storage == null)
            {
            storage = new TAPSStorage();
        
            Config cfgStorage = getStorageConfig();
            if (cfgStorage != null)
                {
                storage.applyConfig(cfgStorage, "");
                }
        
            while (storage.getProjectFactory() == null)
                {
                storage = (TAPSStorage) getHostSite().dialogBox(
                    new TAPSLogin(), storage);
        
                if (storage == null)
                    {
                    // operation was canceled
                    return;
                    }
                }
            }
        
        String sBasePrj = storage.getQualifiedProject();
        if (sBasePrj == null || sBasePrj.length() == 0)
            {
            String[] asPrj = storage.getProjectFactory().getProjects();
            sBasePrj = asPrj.length == 0 ? "" : asPrj[0];
            }
        
        String sProject = (String) getHostSite().dialogBox(new TAPSNewProject(),
            new Object[] {storage.getProjectFactory(), sBasePrj});
        
        if (sProject != null)
            {
            if (!closeProject())
                {
                // someone refused to close
                return;
                }
        
            storage.setQualifiedProject(sProject);
            setStorage(storage);
            }
        
        updateTitle();
        
        fireHostAction(ACTION_PROJECT_OPEN, null);

        }
    
    /**
    * Configure the UI.
    */
    private void createSite()
        {
        JFrame frame = new JFrame.TAPSFrame();
        frame.moveToCenter();
        
        HostSite site  = (HostSite) frame._findChild(HostSite.MAIN_PANEL);
        setHostSite(site);
        
        openTools();
        
        Config config = loadConfiguration("TDE");
        
        if (config != null)
            {
            setStorageConfig(config.getConfig("Storage"));
        
            frame.applyConfig(config, "UI");
        
            applyConfig(config, "TAPS");
            }
        }
    
    private void exitApplication()
        {
        if (closeProject())
            {
            HostSite site = getHostSite();
            if (site != null)
                {
                Config config = new Config();
        
                // save the last storage configuration
                config.putConfig("Storage", getStorageConfig());
        
                // save the tools configuration
                saveConfig(config, "TAPS");
        
                // save the site configuration
                site.getFrame().saveConfig(config, "UI");
                site.getFrame().dispose();
        
                storeConfiguration(config, "TDE");
                }
            }

        }
    
    // Accessor for the property "StorageConfig"
    /**
    * Getter for property StorageConfig.<p>
    * Configuration info for the Storage
    */
    public _package.component.util.Config getStorageConfig()
        {
        return __m_StorageConfig;
        }
    
    // Accessor for the property "UIConfig"
    /**
    * Getter for property UIConfig.<p>
    * Configuration info for the UI
    */
    public _package.component.util.Config getUIConfig()
        {
        return __m_UIConfig;
        }
    
    private void integrateClasses(java.io.File[] aFile)
        {
        // import Component.Dev.Storage;
        // import Component.GUI.Control.Container.JComponent.JPanel.WizardPane.IntegrationWizard;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.Integration;
        // import com.tangosol.util.StringTable;
        // import java.util.Enumeration;
        
        StringTable tblComponents = (StringTable) getHostSite().dialogBox(new IntegrationWizard(),
                new Object[] {aFile, getStorage()});
        
        if (tblComponents == null)
            {
            return;
            }
        
        Storage storage = getStorage();
        
        for (Enumeration enum = tblComponents.keys(); enum.hasMoreElements();)
            {
            String    sIntegrator   = (String) enum.nextElement();
            Component jcsIntegratee = (Component) tblComponents.get(sIntegrator);
            String    sIntegratee   = jcsIntegratee.getName();
            int       of            = sIntegrator.lastIndexOf('.');
            String    sSuper        = sIntegrator.substring(0, of);
            String    sName         = sIntegrator.substring(of + 1);
            
            Component cd = null;
            try
                {
                // check if this already exists
                cd = storage.loadComponent(sIntegrator, true, null);
                if (cd == null)
                    {
                    Component cdSuper = storage.loadComponent(sSuper, true, null);
        
                    if (cdSuper == null)
                        {
                        throw new ComponentException("Cannot find super component " + sSuper);
                        }
                    cd = cdSuper.createDerivedComponent(sName, storage);
                    }
        
                fireHostAction(ACTION_OPEN, cd);
        
                Integration imap = cd.getIntegration();
                if (imap == null)
                    {
                    imap.setSignature(sIntegratee);
                    }
                }
            // ComponentException, PropertyVetoException
            catch (Exception e)
                {
                getErrorList().addException(e);
                }
            }
        
        reportErrors();
        }
    
    // Declared at the super level
    /**
    * Return true if the specified action fired by the specified host is
    * enabled by this tool; false otherwise.
    * The hosts additionally return true if at least one child tool of this
    * host "enables" this action.
    * 
    * This method is mostly used by host sites' menus to provide a visual clue
    * to the question:
    *  - If this host issues a command (host action), will there be any tool
    * being able to process this command
    * 
    * When the host is specified, the specified action is expected to be fired
    * by that host using fireHostAction(). If the host is null, this action is
    * expected to be fired by this tool itself using fireToolAction().
    * 
    * @param sAction  action name
    * @param host  the source of the action
    * @param  oValue an optional value to be passed along
    */
    public boolean isActionEnabled(String sAction, _package.component.dev.tool.Host host, Object oValue)
        {
        if (sAction.equals(ACTION_PROJECT_NEW)
         || sAction.equals(ACTION_PROJECT_OPEN)
         || sAction.equals(ACTION_EXIT))
            {
            return true;
            }
        else if (
            sAction.equals(ACTION_INTEGRATE)
         || sAction.equals(ACTION_LIBRARY)
         || sAction.equals(ACTION_PROJECT_CLOSE)
         || sAction.equals(ACTION_SERVER_RELOAD))
            {
            return getStorage() != null;
            }
        else
            {
            return super.isActionEnabled(sAction, host, oValue);
            }
        }
    
    /**
    * Load a configuration with the specified name
    * 
    * @param sConfig  the configuration name
    */
    private _package.component.util.Config loadConfiguration(String sName)
        {
        // import java.io.File;
        // import java.io.FileInputStream;
        // import java.io.FileNotFoundException;
        // import java.io.IOException;
        
        Config cfg = null;
        try
            {
            File fileProp = new File(System.getProperty("user.home"),
                sName + ".properties");
            FileInputStream in = new FileInputStream(fileProp.getPath());
        
            cfg = new Config();
            cfg.load(in);
        
            in.close();
            }
        catch (IOException e)
            {
            //++ TODO: remove after version 1.1.1 is shipped
            if (sName.equals("TDE"))
                {
                cfg = loadConfiguration("TAPS");
                if (cfg != null)
                    {
                    new File(System.getProperty("user.home"), "TAPS.properties").delete();
                    }
                }
            //--
        
            if (!(e instanceof FileNotFoundException))
                {
                _trace(e.toString());
                }
            }
        
        return cfg;

        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import javax.swing.SwingUtilities;
        
        super.onInit();
        
        createSite();
        
        // calling "run" on the AWT thread
        SwingUtilities.invokeLater(this);

        }
    
    // Declared at the super level
    /**
    * Notification send by one of the contained tools.
    * 
    * @param tool  the acted tool
    * @param sName  action name
    * @param oValue  associated value
    */
    public void onToolAction(_package.component.dev.Tool tool, String sAction, Object oValue)
        {
        // import Component.Dev.Util.DocInfo;
        // import java.io.File;
        
        if (sAction.equals(ACTION_PROJECT_NEW))
            {
            createProject();
            }
        else if (sAction.equals(ACTION_PROJECT_OPEN))
            {
            openProject(false);
            }
        else if (sAction.equals(ACTION_PROJECT_CLOSE))
            {
            if (getStorage() != null)
                {
                closeProject();
                }
            }
        else if (sAction.equals(ACTION_EXIT))
            {
            exitApplication();
            }
        else if (sAction.equals(ACTION_INTEGRATE))
            {
            if (getStorage() != null)
                {
                File[] aFile = (File[]) oValue;
                integrateClasses(aFile);
                }
            }
        else if (sAction.equals(ACTION_LIBRARY))
            {
            if (getStorage() != null)
                {
                File[] aFile = (File[]) oValue;
                addLibraries(aFile);
                }
            }
        else if (sAction.equals(ACTION_SERVER_RELOAD))
            {
            if (getStorage() != null)
                {
                reloadServer();
                }
            }
        else if (sAction.equals(ACTION_TEST_RUN))
            {
            if (oValue != null)
                {
                DocInfo info = (DocInfo) oValue;
                if (info.getType().equals("Component"))
                    {
                    testRun(info.getName());
                    }
                }
            else
                {
                // let it go and fill in the value
                super.onToolAction(tool, sAction, oValue);
                }
            }
        else
            {
            super.onToolAction(tool, sAction, oValue);
            }
        }
    
    /**
    * Open a project
    * 
    * @param fInit  if true, attempt to open a project without asking the user,
    * utilizing the configuration information available
    */
    private void openProject(boolean fInit)
        {
        // import Component.Dev.Project.StorageFactory;
        // import Component.GUI.Control.Container.JComponent.JPanel.TAPSLogin;
        // import Component.GUI.Control.Container.JComponent.JPanel.TAPSProject;
        
        TAPSStorage storageOld  = (TAPSStorage) getStorage();
        TAPSStorage storageNew  = new TAPSStorage();
        Config      cfgStorage  = getStorageConfig();
        boolean     fForceLogin = false;
        
        if (cfgStorage == null)
            {
            cfgStorage = new Config();
            setStorageConfig(cfgStorage);
            }
        
        if (storageOld != null)
            {
            storageOld.saveConfig(cfgStorage, "");
            }
        storageNew.applyConfig(cfgStorage, "");
        
        if (fInit)
            {
            _assert(storageOld == null);
        
            storageNew.initFromEnvironment();
            storageNew.saveConfig(cfgStorage, "");
        
            fInit = false; // assume failure
            try
                {
                if (storageNew.getProjectFactory() == null ||
                    storageNew.getProjectFactory().getProjects().length == 0)
                    {
                    fForceLogin = true;
                    }
                else if (storageNew.isValid() && !storageNew.getTarget().isLocked())
                    {
                    fInit = true;
                    setStorage(storageNew);
                    }
                }
            catch (Exception e)
                {
                }
            }
        
        if (!fInit)
            {
            getHostSite().getFrame().setVisible(true);
        
            while (fForceLogin || storageNew.getProjectFactory() == null)
                {
                storageNew = (TAPSStorage) getHostSite().dialogBox(
                    new TAPSLogin(), storageNew);
        
                if (storageNew == null)
                    {
                    // operation was canceled
                    return;
                    }
                // we should allow login even there are no projects...
                fForceLogin = false;
                }
        
            while (true)
                {
                storageNew = (TAPSStorage) getHostSite().dialogBox(
                    new TAPSProject(), storageNew);
        
                if (storageNew == null)
                    {
                    // operation was canceled
                    return;
                    }
        
                if (storageNew.isValid())
                    {
                    if (storageNew.equals(storageOld))
                        {
                        // the same storage has been choosen
                        return;
                        }
        
                    if (!closeProject())
                        {
                        // someone refused to close
                        return;
                        }
                    setStorage(storageNew);
                    break;
                    }
                }
            }
        
        updateTitle();
        
        fireHostAction(ACTION_PROJECT_OPEN, null);
        
        Config cfgProject = loadConfiguration(storageNew.getProject());
        if (cfgProject != null)
            {
            getHostSite().applyConfig(cfgProject, "UI");
            }
        }
    
    private void openTools()
        {
        // import Component.Dev.Tool.DocumentChooser.CDChooser;
        // import Component.Dev.Tool.DocumentChooser.JCSChooser;
        // import Component.Dev.Tool.DocumentChooser.LibraryChooser;
        // import Component.Dev.Tool.DocumentChooser.ResourceChooser;
        
        HostSite hostMain = getHostSite();
        
        $Mgrs hostMgrs = ($Mgrs) getTool("Mgrs");
        hostMgrs.setHostSite((HostSite) hostMain._findName("Mgrs"));
        hostMgrs.setOpen(true);
        
        $Docs hostDocs = ($Docs) getTool("Docs");
        hostDocs.setHostSite((HostSite) hostMain._findName("Docs"));
        hostDocs.setOpen(true);
        
        // add the "managing" tools
        // (see also HostSite.TAPSMain$Split$Mgrs#addToolHandle)
        
        // WorkManager toolWork = new WorkManager();
        // hostMgrs.addTool(toolWork, "WorkManager");
        
        JCSChooser toolClasses = new JCSChooser();
        hostMgrs.addTool(toolClasses, "JCSChooser");
        toolClasses.setOpen(true);
        
        ResourceChooser toolResources = new ResourceChooser();
        hostMgrs.addTool(toolResources, "ResourceChooser");
        
        CDChooser toolComponents = new CDChooser();
        hostMgrs.addTool(toolComponents, "CDChooser");
        
        LibraryChooser toolLibraries = new LibraryChooser();
        hostMgrs.addTool(toolLibraries, "LibraryChooser");

        }
    
    private void reloadServer()
        {
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Project.ProjectInfo$Target$Library as Library;
        // import java.io.File;
        // import java.io.IOException;
        // import java.util.Iterator;
        // import java.util.LinkedList;
        // import javax.swing.JOptionPane;
        
        TAPSStorage storage = (TAPSStorage) getStorage();
        Target      target  = storage.getTarget();
        LinkedList  listEar = new LinkedList();
        
        for (Iterator iter = target.getLibraryList().values().iterator(); iter.hasNext();)
            {
            Library lib = (Library) iter.next();
        
            String  sPath = lib.getStorageInfo().getSafeElement("Location").getString();
            boolean fCopy = lib.getStorageInfo().getSafeElement("UseCopy").getBoolean();
        
            int ofPath = sPath.indexOf('!');
            if (ofPath != -1)
                {
                sPath = sPath.substring(0, ofPath);
                }
        
            if (sPath.endsWith(".ear") && !listEar.contains(sPath))
                {
                boolean fDone = false;
                String  sMsg;
        
                if (fCopy)
                    {
                    listEar.add(sPath);
        
                    try
                        {
                        File fileEar = new File(sPath);
                        if (!fileEar.isAbsolute())
                            {
                            String sPrjRoot = target.getProjectInfo().getStorageInfo().
                                getSafeElement("Location").getString();
                            fileEar = new File(sPrjRoot, sPath);
                            }
                        sPath = fileEar.getCanonicalPath();
        
                        // re-package the ear
                        fDone = repackageApplication(fileEar);
                        sMsg  = "Successfully reloaded:\n" + sPath;
                        }
                    catch (Exception e)
                        {
                        String sErr = e.getMessage();
                        if (sErr == null || sErr.length() == 0)
                            {
                            sErr = "see log for details";
                            _trace(e);
                            }
                        sMsg = "Failed to reload the library\n" + sPath +
                            '\n' + sErr;
                        }
                    }
                else
                    {
                    sMsg = "The library \"" + sPath + "\"\nis configured to be used directly\n" +
                           "(\"UseCopy\" element is \"false\") and therefore cannot be reloaded";
                    }
        
                getHostSite().msg("Message", new Object[]
                    {
                    sMsg,
                    getTitle(),
                    new Integer(fDone ? JOptionPane.INFORMATION_MESSAGE :
                                        JOptionPane.ERROR_MESSAGE)
                    });
                }
            }
        
        if (listEar.isEmpty())
            {
            getHostSite().msg("Message", new Object[]
                {
                "There are no libraries to reload.",
                getTitle(),
                new Integer(JOptionPane.INFORMATION_MESSAGE)
                });
            }
        }
    
    private boolean repackageApplication(java.io.File fileEar)
            throws com.tangosol.dev.packager.PackagerException,
                   java.io.IOException
        {
        // import Component.Dev.Packager.Model;
        // import Component.Dev.Packager.PackageInfo;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Project.ProjectInfo$Target$Library as Library;
        // import Component.Dev.Tool.OutputTool;
        // import Component.Util.NamedRef;
        // import java.awt.Cursor;
        // import java.io.File;
        // import java.io.IOException;
        // import java.util.Arrays;
        // import java.util.Collections;
        // import java.util.List;
        // import java.util.LinkedList;
        // import java.util.Iterator;
        
        TAPSStorage storage = (TAPSStorage) getStorage();
        Target      target  = storage.getTarget();
        
        String sProjectRoot = target.getProjectInfo().getStorageInfo().
            getSafeElement("Location").getString();
        String sTargetRoot  = target.getStorageInfo().
            getSafeElement("Location").getString(target.getName());
        
        File dirPrj    = new File(sProjectRoot);
        File dirTarget = new File(dirPrj, sTargetRoot);
        File dirLib    = new File(dirTarget, "lib");
        File fileOrig  = new File(dirLib, fileEar.getName());
        if (!fileOrig.exists())
            {
            throw new IOException("Original copy of the application is missing: " + fileOrig);
            }
        
        // this value could be retrieved from
        // Component.Application.GUI.Desktop.TDE#get$Excludes()
        String[] asExclude = new String[]
            {
            "{java.home}/lib/rt.jar",
            "{java.home}/lib/i18n.jar",
            "package:java",
            "package:javax",
            // the following could be specified as "../../../lib/tangosol.jar"
            "package:com.tangosol.dev",
            "package:com.tangosol.util",
            "package:com.tangosol.run",
            };
        List listExclude = new LinkedList(Arrays.asList(asExclude));
        
        // Note: we could exclude ALL the libraries using storage.collectLibraries()
        for (Iterator iter = target.getLibraryList().values().iterator(); iter.hasNext();)
            {
            Library lib = (Library) iter.next();
        
            String sPath = lib.getStorageInfo().getSafeElement("Location").getString();
        
            if (sPath.indexOf('!') == -1 && sPath.endsWith(".jar") &&
                !listExclude.contains(sPath))
                {
                listExclude.add(sPath);
                }
            }
        
        PackageInfo info = new PackageInfo();
        
        info.setModelName("Customization");
        info.setJavaPackage("");
        info.setTargetPath(fileEar.getPath());
        info.setSuppressManifest(true);
        info.setManifestEntries(Collections.EMPTY_LIST);
        info.setXMLEntries(Collections.EMPTY_LIST);
        info.setApplicationName(fileEar.getName());
        info.setDescription("");
        info.setIncludeComponents(Collections.EMPTY_MAP);
        info.setIncludeResources(Collections.singletonList(
            NamedRef.instantiate(fileOrig.getPath(), "")));
        info.setExcludeResources(listExclude);
        
        Model packager = info.getModel();
        _assert(packager != null);
        
        OutputTool output = new OutputTool.Tracer();
        
        packager.setOutputTool(output);
        packager.setStorage(storage);
        packager.setDynamicCustomization(true);
        
        Cursor _cursor = getHostSite().showHourglass();
        try
            {
            packager.buildPackage();
            }
        finally
            {
            getHostSite().clearHourglass(_cursor);
            }
        
        return true;
        }
    
    // From interface: java.lang.Runnable
    public void run()
        {
        validateLicense();
        
        openProject(true);
        
        getHostSite().getFrame().setVisible(true);
        }
    
    // Accessor for the property "StorageConfig"
    /**
    * Setter for property StorageConfig.<p>
    * Configuration info for the Storage
    */
    public void setStorageConfig(_package.component.util.Config pStorageConfig)
        {
        __m_StorageConfig = pStorageConfig;
        }
    
    // Accessor for the property "UIConfig"
    /**
    * Setter for property UIConfig.<p>
    * Configuration info for the UI
    */
    public void setUIConfig(_package.component.util.Config pUIConfig)
        {
        __m_UIConfig = pUIConfig;
        }
    
    /**
    * Save the specified configuration with the specified name
    * 
    * @param config  configuration component
    * @param sName  the configuration name
    */
    private void storeConfiguration(_package.component.util.Config config, String sName)
        {
        // import java.io.File;
        // import java.io.FileOutputStream;
        // import java.io.IOException;
        
        try
            {
            File fileProp = new File(System.getProperty("user.home"),
                sName + ".properties");
            FileOutputStream out = new FileOutputStream(fileProp.getPath());
        
            config.store(out, "");
        
            out.close();
            }
        catch (IOException e)
            {
            _trace(e.toString());
            }
        }
    
    /**
    * Test run the specified component
    */
    private void testRun(String sComponentName)
        {
        // import Component.Dev.Tool.TestRun;
        // import Component.GUI.Control.Container.JComponent.AbstractButton;
        
        TestRun toolTestRun = (TestRun) getTool("TestRun");
        if (toolTestRun == null)
            {
            toolTestRun = new TestRun();
            addTool(toolTestRun, "TestRun");
        
            toolTestRun.setCommandItem(
                (AbstractButton) getHostSite()._findName("File$TestRun"));
            toolTestRun.setStorage(getStorage());
            toolTestRun.setComponentName(sComponentName);
            }
        
        // toggle the test run state
        toolTestRun.setOpen(!toolTestRun.isOpen());

        }
    
    private void updateTitle()
        {
        String sDash  = " - ";
        String sTitle = getHostSite().getTitle() + sDash;
        
        sTitle = sTitle.substring(0, sTitle.indexOf(sDash));
        
        TAPSStorage storage = (TAPSStorage) getStorage();
        
        if (storage != null)
            {
            sTitle += sDash + storage.getServerURI() + '/' +
                storage.getQualifiedProject();
            }
        getHostSite().setTitle(sTitle);

        }
    
    private void validateLicense()
        {
        // import com.tangosol.license.DevelopmentEdition;
        // import com.tangosol.license.LicensedObject;
        // import com.tangosol.license.LicensedObject$LicenseData as LicenseData;
        // import java.util.List;
        // import java.util.ArrayList;
        
        List    list   = new ArrayList();
        boolean fFound = false;
        
        try
            {
            LicenseData[] aLic = LicensedObject.getLicenseData();
            for (int i = 0, c = aLic.length; i < c; i++)
                {
                LicenseData lic = aLic[i];
        
                if (lic.sSoftware.equals(LICENSE))
                    {
                    fFound = true;
                    
                    System.out.println();
                    System.out.println(lic.toString());
        
                    String sReason = LicensedObject.getLicenseFailure(lic);
                    if (sReason != null)
                        {
                        list.add(sReason);
                        }
                    }
                }
            }
        catch (Throwable e)
            {
            }
        
        try
            {
            new DevelopmentEdition();
            }
        catch (Throwable e)
            {
            System.out.println("License check failed:");
            if (list.isEmpty())
                {
                if (fFound)
                    {
                    System.out.println("  Unknown failure.");
                    }
                else
                    {
                    System.out.println("  Missing license for " + LICENSE);
                    }
                }
            else
                {
                for (int i = 0, c = list.size(); i < c; ++i)
                    {
                    System.out.println("  [" + i + "] " + list.get(i));
                    }
                }
            System.out.println();
            getHostSite().getFrame().dispose();
            }
        }
    }
