/* Class
*     _package.component.dev.tool.host.cDTool.IntegrationTool
*/

package _package.component.dev.tool.host.cDTool;

import _package.component.gUI.control.container.jComponent.jPanel.toolSite.IntegrationMap;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.Integration;
import com.tangosol.dev.component.Interface;
import com.tangosol.dev.component.Property;
import com.tangosol.dev.component.Storage;
import com.tangosol.dev.component.Trait;
import com.tangosol.util.WrapperException;
import java.beans.PropertyVetoException;

public class IntegrationTool
        extends    _package.component.dev.tool.host.CDTool
        implements java.beans.PropertyChangeListener
    {
    // Fields declarations
    
    /**
    * Property Map
    *
    */
    private transient com.tangosol.dev.component.Integration __m_Map;
    
    // Default constructor
    public IntegrationTool()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public IntegrationTool(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(50.0F);
            setOpen(false);
            setTitle("Integration Map");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new IntegrationTool();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/host/cDTool/IntegrationTool".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "Map"
    public com.tangosol.dev.component.Integration getMap()
        {
        return __m_Map;
        }
    
    private void loadMap()
        {
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Interface;
        // import com.tangosol.dev.component.Integration;
        // import com.tangosol.dev.component.Storage;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.util.WrapperException;
        // import java.beans.PropertyVetoException;
        
        Component cd = getGlobalCD();
        if (cd == null)
            {
            setMap(null);
            return;
            }
        
        Integration map = cd.getIntegration();
        if (map == null)
            {
            setMap(null);
            return;
            }
        
        try
            {
            map.loadJcs(getStorage());
            }
        catch (ComponentException ce)
            {
            setMap(null);
            // PJM ??? What should be thrown here ???
            throw new WrapperException(ce);
            }
        
        setMap(map);
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets closed<p>
    * Note: this method is called before the host is notified with closeTool(),
    * so no relevant host's destruction has been done yet.
    * 
    * @see #setOpen
    * @see Host#closeTool
    */
    public void onClose()
        {
        super.onClose();
        
        getGlobalCD().removePropertyChangeListener(this);
        }
    
    // Declared at the super level
    /**
    * Notification from the CDDesigner host that the trait filter has changed
    * 
    * @see CDDesigner#setFilterVisibility()
    */
    public void onFilterChanged()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.IntegrationMap;
        
        super.onFilterChanged();
        
        IntegrationMap site = (IntegrationMap) getToolSite();
        if (site != null)
            {
            site.setFilterVisibility(getCDDesigner().getFilterVisibility());
            }
        }
    
    // Declared at the super level
    /**
    * Notification from the CDDesigner host that the global CD has changed
    * 
    * This could happen only in the case when renaming a component causes the
    * Component Definition reference to change
    * 
    * @see CDDesigner#renameComponent()
    * @see CDDesigner#setGlobalCD()
    */
    public void onGlobalCDChanged(com.tangosol.dev.component.Component cdOld)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.IntegrationMap;
        // import com.tangosol.dev.component.Component;
        
        super.onGlobalCDChanged(cdOld);
        
        Component cdNew = getGlobalCD();
        
        if (cdOld == cdNew)
            {
            return;
            }
        
        if (cdOld != null)
            {
            cdOld.removePropertyChangeListener(this);
            }
        
        loadMap();
        
        if (cdNew != null)
            {
            cdNew.addPropertyChangeListener(this);
            }
        
        IntegrationMap site = (IntegrationMap) getToolSite();
        if (site != null)
            {
            site.setGlobalCDLocalCD(cdNew == getLocalCD());
            }

        }
    
    // Declared at the super level
    /**
    * Notification from the CDDesigner host that the local CD has changed
    * 
    * @see CDDesigner#setLocalCD()
    */
    public void onLocalCDChanged(com.tangosol.dev.component.Component cdOld)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.IntegrationMap;
        // import com.tangosol.dev.component.Component;
        
        super.onLocalCDChanged(cdOld);
        
        Component cdNew = getLocalCD();
        
        if (cdOld == cdNew)
            {
            return;
            }
        
        IntegrationMap site = (IntegrationMap) getToolSite();
        if (site != null)
            {
            site.setGlobalCDLocalCD(cdNew == getGlobalCD());
            }
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets opened.<p>
    * Note: this method is called after the host is notified with openTool(),
    * so all the relevant host's initialization is already done.
    * 
    * @see #setOpen
    * @see Host#openTool
    */
    public void onOpen()
        {
        super.onOpen();
        
        getToolHandle().setEnabled(false);
        
        onGlobalCDChanged(null);
        onFilterChanged();

        }
    
    // From interface: java.beans.PropertyChangeListener
    public void propertyChange(java.beans.PropertyChangeEvent evt)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.IntegrationMap;
        // import com.tangosol.dev.component.Trait;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Integration;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.util.WrapperException;
        
        Object source  = evt.getSource();
        String sAttrib = evt.getPropertyName();
        
        Component cd = getGlobalCD();
        if (source == cd)
            {
            if (sAttrib.equals(Component.ATTR_INTEGRATION))
                {
                loadMap();
                if (cd.getIntegration() != null)
                    {
                    setActive(true);
                    }
                return;
                }
                
            return;
            }
        
        Integration map = getMap();
        
        if (source == map)
            {
            IntegrationMap toolSite = (IntegrationMap) getToolSite();
        
            if (sAttrib.equals(Trait.ATTR_TIP))
                {
                toolSite.onTipModified();
                return;
                }
        
            if (sAttrib.equals(Trait.ATTR_TEXT))
                {
                toolSite.onTextModified();
                return;
                }
        
            if (sAttrib.equals(Integration.ATTR_INTEGRATION_SIGNATURE))
                {
                try
                    {
                    map.loadJcs(getStorage());
                    }
                catch (ComponentException ce)
                    {
                    setMap(null);
                    // PJM ??? What should be thrown here ???
                    throw new WrapperException(ce);
                    }
                toolSite.onSignatureModified();
                return;
                }
        
            if (sAttrib.equals(Integration.ATTR_INTEGRATION_MODEL))
                {
                toolSite.onModelModified();
                return;
                }
        
            if (sAttrib.equals(Integration.ATTR_INTEGRATION_METHOD))
                {
                toolSite.onMethodModified((Behavior) ((Object[]) evt.getOldValue())[0]);
                return;
                }
            
            if (sAttrib.equals(Integration.ATTR_INTEGRATION_FIELD))
                {
                toolSite.onFieldModified((Property) ((Object[]) evt.getOldValue())[0]);
                return;
                }
        
            return;
            }
        }
    
    // Accessor for the property "Map"
    public void setMap(com.tangosol.dev.component.Integration pMap)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.IntegrationMap;
        // import com.tangosol.dev.component.Integration;
        
        Integration mapPrev = getMap();
        Integration mapNew  = pMap;
        
        if (mapPrev == mapNew)
            {
            return;
            }
        
        __m_Map = (pMap);
        
        if (mapPrev != null)
            {
            mapPrev.removePropertyChangeListener(this);
            }
        
        IntegrationMap site = (IntegrationMap) getToolSite();
        
        if (mapNew != null)
            {
            mapNew.addPropertyChangeListener(this);
        
            if (site == null)
                {
                site = new IntegrationMap();
                setToolSite(site);
        
                getHost().openTool(this);
        
                site.setGlobalCDLocalCD(getGlobalCD() == getLocalCD());
                site.setFilterVisibility(getCDDesigner().getFilterVisibility());
                }
            }
        
        if (site != null)
            {
            site.setMap(mapNew);
            }
        }
    }
