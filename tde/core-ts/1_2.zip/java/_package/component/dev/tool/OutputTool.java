/* Class
*     _package.component.dev.tool.OutputTool
*/

package _package.component.dev.tool;

import _package.component.gUI.control.container.jComponent.jPanel.toolSite.OutputPanel;

public class OutputTool
        extends    _package.component.dev.Tool
    {
    // Fields declarations
    
    /**
    * Property Verbose
    *
    * Specifies whether the OutputTool should produce the verbose output
    */
    private boolean __m_Verbose;
    
    // Default constructor
    public OutputTool()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public OutputTool(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(100.0F);
            setTitle("Output");
            setToolSiteClass(Class.forName("_package/component/gUI/control/container/jComponent/jPanel/toolSite/OutputPanel".replace('/', '.')));
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new OutputTool();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/OutputTool".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.OutputPanel;
        
        

        }
    
    /**
    * Clear the named output.
    */
    public void clearOutput(String sName)
        {
        ((OutputPanel) getToolSite()).clearOutput(sName);
        }
    
    // Accessor for the property "Verbose"
    /**
    * Getter for property Verbose.<p>
    * Specifies whether the OutputTool should produce the verbose output
    */
    public boolean isVerbose()
        {
        return __m_Verbose;
        }
    
    // Declared at the super level
    /**
    * Notification send by one of the containing hosts
    * 
    * @param host  the acted host
    * @param sName  action name
    * @param oValue  associated value
    */
    public void onHostAction(Host host, String sAction, Object oValue)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.OutputPanel;
        
        if (sAction.equals(ACTION_LOCATE_ERROR_TAG))
            {
            int iDirection = oValue instanceof Integer ? ((Integer) oValue).intValue() : 1;
            ((OutputPanel) getToolSite()).fireLocateTrait(-1, iDirection);
            }
        else
            {
            super.onHostAction(host, sAction, oValue);
            }
        }
    
    /**
    * Pass the named output up to the viewer.
    */
    public void output(String sName, Object oValue)
        {
        output(sName, oValue, false);
        }
    
    /**
    * Pass the named output up to the viewer.
    * If the viewer is capable of having "verbose" mode, and the fVerbose flag
    * is true, show the specified output only if the current tool's mode is set
    * to allow the verbose output.
    */
    public void output(String sName, Object oValue, boolean fVerbose)
        {
        if (fVerbose && !isVerbose())
            {
            return;
            }
        
        ((OutputPanel) getToolSite()).output(sName, oValue, fVerbose);
        }
    
    // Accessor for the property "Verbose"
    /**
    * Setter for property Verbose.<p>
    * Specifies whether the OutputTool should produce the verbose output
    */
    public void setVerbose(boolean pVerbose)
        {
        __m_Verbose = pVerbose;
        }
    }
