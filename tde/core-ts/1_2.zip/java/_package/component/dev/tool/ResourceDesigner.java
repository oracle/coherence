/* Class
*     _package.component.dev.tool.ResourceDesigner
*/

package _package.component.dev.tool;

import _package.component.dev.Storage;
import java.io.File;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
* This is a tool that is watching a resource (document) that is being processed
* externally
*/
public class ResourceDesigner
        extends    _package.component.dev.Tool
    {
    // Fields declarations
    
    /**
    * Property ExternalCommand
    *
    * Represents the external command that should be used to open the resource
    * specified by ResourceName
    */
    private String __m_ExternalCommand;
    
    /**
    * Property OutputTool
    *
    * Instance of an OutputTool used for error reporting
    */
    private transient OutputTool __m_OutputTool;
    
    /**
    * Property Process
    *
    * Specifies the external process assosiated assosiated with this
    * ResourceWatcher
    */
    private transient Process __m_Process;
    
    /**
    * Property ResourceName
    *
    * Specifies the resource name handled by this ResourceWatcher
    */
    private transient String __m_ResourceName;
    
    // Default constructor
    public ResourceDesigner()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ResourceDesigner(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setTitle("Resource Designer");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new ResourceDesigner$Watcher("Watcher", this, true), "Watcher");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ResourceDesigner();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/ResourceDesigner".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Extract and save a Resource Signature out of the [externally
    * created/edited] resource binary
    */
    public void commitResource()
        {
        // import Component.Dev.Storage;
        // import java.io.IOException;
        
        Storage storage = getStorage();
        String  sName   = getResourceName();
        
        try
            {
            byte[] abRes = storage.loadResource(sName);
        
            storage.storeResourceSignature(sName, abRes);
            }
        catch (IOException e)
            {
            getErrorList().addException(e);
            }
        
        reportErrors();
        
        fireToolAction(ACTION_REFRESH, "Resources");
        fireToolAction(ACTION_REFRESH, "Libraries");
        }
    
    // Accessor for the property "ExternalCommand"
    /**
    * Getter for property ExternalCommand.<p>
    * Represents the external command that should be used to open the resource
    * specified by ResourceName
    */
    public String getExternalCommand()
        {
        return __m_ExternalCommand;
        }
    
    // Accessor for the property "OutputTool"
    /**
    * Getter for property OutputTool.<p>
    * Instance of an OutputTool used for error reporting
    */
    public OutputTool getOutputTool()
        {
        return __m_OutputTool;
        }
    
    // Accessor for the property "Process"
    /**
    * Getter for property Process.<p>
    * Specifies the external process assosiated assosiated with this
    * ResourceWatcher
    */
    public Process getProcess()
        {
        return __m_Process;
        }
    
    // Accessor for the property "ResourceName"
    /**
    * Getter for property ResourceName.<p>
    * Specifies the resource name handled by this ResourceWatcher
    */
    public String getResourceName()
        {
        return __m_ResourceName;
        }
    
    // Declared at the super level
    /**
    * Returns true if the close operation should be canceled. The assumption
    * is, however, that a tool that does cancel the close operation bears
    * responsibility to notify the user. If a tool sees that some modification
    * could be lost if the close operation is allowed to proceed, but does not
    * want to notify the user on its own, it should  instead override
    * <code>isModified</code> method to return "true".
    * 
    * Default implementation forces the tool site to apply any pending UI
    * changes into the model before returning "false" (allowing the close
    * operation to proceed).
    * 
    * @see #isModified
    */
    public boolean isCloseCanceled()
        {
        // import javax.swing.JOptionPane;
        
        String sName = getResourceName();
        String sMsg =
            "Resource may still be open for editing,\n" + 
            "and you may have made changes that have not been committed.\n" +
            "Would you like to commit the current edits to\n\"" + sName + "\" ?";
        
        Integer intAns = (Integer) getHost().getHostSite().msg("Confirm", new Object[]
            {
            sMsg,
            getTitle(),
            new Integer(JOptionPane.YES_NO_CANCEL_OPTION),
            });
        
        switch (intAns.intValue())
            {
            case JOptionPane.YES_OPTION:
                commitResource();
                // fall through
            case JOptionPane.NO_OPTION:
                return false;
            case JOptionPane.CANCEL_OPTION:
            case JOptionPane.CLOSED_OPTION:
            default:
                return true;
            }

        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets closed<p>
    * Note: this method is called before the host is notified with closeTool(),
    * so no relevant host's destruction has been done yet.
    * 
    * @see #setOpen
    * @see Host#closeTool
    */
    public void onClose()
        {
        if (getHost() != null)
            {
            getHost().removeTool(this);
            }
        
        $Watcher Watcher = ($Watcher) _findName("Watcher");
        Watcher.stop();

        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets opened.<p>
    * Note: this method is called after the host is notified with openTool(),
    * so all the relevant host's initialization is already done.
    * 
    * @see #setOpen
    * @see Host#openTool
    */
    public void onOpen()
        {
        // import Component.Dev.Storage;
        // import java.io.IOException;
        // import java.io.File;
        
        // the plan is:
        // - load the resource signature (fully resolved)
        // - extract the resource binary and create a persistent copy of it
        //   to be used by a dedicated tool
        // - start the tool
        // - later on (after the editing is completed) expect a call to
        //   "commit changes" (see TAPS$Mgrs#commitResource)
        
        Storage storage = getStorage();
        String  sName   = getResourceName();
        Process process = null;
        String  sPath   = storage.getClassPath();
        
        int of = sPath.indexOf(File.pathSeparatorChar);
        if (of != -1)
            {
            sPath = sPath.substring(0, of);
            }
        sPath = (sPath + "/" + sName).replace('/', File.separatorChar);
        
        try
            {
            byte[] abResSig = storage.loadResourceSignature(sName);
        
            // TODO: call ResourceResolver
            // for now resource binary == resource signature
            storage.storeResource(sName, abResSig);
        
            String sCmd = getExternalCommand();
            if (sCmd != null && sCmd.length() > 0)
                {
                sCmd += ' ' + sPath;
                }
            else
                {
                sCmd = sPath;
                }
            process = Runtime.getRuntime().exec(sCmd);
        
            try
                {
                // wait a second for a process to kick off
                Thread.currentThread().sleep(1000);
                }
            catch (InterruptedException e) {}
        
            // if the process is gone by this time, it means that
            // an actual (MDI) tool was already up and there is no reason
            // to commit the resource right now -- it will have to be
            // done manually by user later on
            try
                {
                int iStatus = process.exitValue();
                if (iStatus == 0)
                    {
                    // process has succeffully terminated
                    return;
                    }
                process = null;
        
                throw new IOException("Failed to invoke a program assosiated with:\n\n" +
                    sPath + "\n\n(Process exit code: " + iStatus + ')');
                }
            catch (IllegalThreadStateException e)
                {
                // the process is still running
                setProcess(process);
                }
            }
        catch (IOException e)
            {
            getErrorList().addException(e);
            }
        
        reportErrors();
        
        if (process == null)
            {
            setOpen(false);
            }
        else
            {
            $Watcher Watcher = ($Watcher) _findName("Watcher");
        
            // the Watcher will call "commitResource" on a daemon thread
            // when the resource document is closed
            Watcher.start();
            Watcher.setNotification(true);
            }
        }
    
    // Accessor for the property "ExternalCommand"
    /**
    * Setter for property ExternalCommand.<p>
    * Represents the external command that should be used to open the resource
    * specified by ResourceName
    */
    public void setExternalCommand(String pExternalCommand)
        {
        __m_ExternalCommand = pExternalCommand;
        }
    
    // Accessor for the property "OutputTool"
    /**
    * Setter for property OutputTool.<p>
    * Instance of an OutputTool used for error reporting
    */
    public void setOutputTool(OutputTool pOutputTool)
        {
        __m_OutputTool = pOutputTool;
        }
    
    // Accessor for the property "Process"
    /**
    * Setter for property Process.<p>
    * Specifies the external process assosiated assosiated with this
    * ResourceWatcher
    */
    public void setProcess(Process pProcess)
        {
        __m_Process = pProcess;
        }
    
    // Accessor for the property "ResourceName"
    /**
    * Setter for property ResourceName.<p>
    * Specifies the resource name handled by this ResourceWatcher
    */
    public void setResourceName(String pResourceName)
        {
        __m_ResourceName = pResourceName;
        }
    }
