/* Class
*     _package.component.dev.tool.host.cDTool.PropertyTool
*/

package _package.component.dev.tool.host.cDTool;

import _package.component.dev.Design;
import _package.component.dev.Storage;
import _package.component.gUI.control.container.jComponent.jPanel.toolSite.PropertyDesigner;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.Constants;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Implementation;
import com.tangosol.dev.component.Property;
import com.tangosol.dev.component.SubChangeEvent;
import com.tangosol.dev.component.Trait;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;

public class PropertyTool
        extends    _package.component.dev.tool.host.CDTool
        implements com.tangosol.dev.component.SubChangeListener
    {
    // Fields declarations
    
    // Default constructor
    public PropertyTool()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PropertyTool(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(10.0F);
            setTitle("Property Designer");
            setToolSiteClass(Class.forName("_package/component/gUI/control/container/jComponent/jPanel/toolSite/PropertyDesigner".replace('/', '.')));
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new PropertyTool();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/host/cDTool/PropertyTool".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Create a new property of the specified type:
    * 
    * 'J' - Java Constant
    * 'V' - Virtual Constant
    * 'C' - Calculated Property
    * 'F' - Functional Property
    * 'S' - Standard Property
    * 
    * @see PropertyDesigner#createProperty
    */
    public com.tangosol.dev.component.Property createProperty(char chType)
        {
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Constants;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Property;
        // import java.beans.PropertyVetoException;
        
        Component cd   = getLocalCD();
        Property  prop = null;
        
        try
            {
            String   sName;
        
            DataType dt       = DataType.STRING;
            int      nIndexed = Constants.PROP_SINGLE;
            boolean  fStatic  = false;
            boolean  fPersist = false;
            switch (chType)
                {
                case 'J':
                    fStatic = true;
                    sName = generateName("NewJavaConstant", dt, nIndexed, fStatic, fPersist);
                    prop = cd.addJavaConstant(dt, sName, nIndexed, fStatic, Constants.ACCESS_PUBLIC);
                    break;
        
                case 'V':
                    sName = generateName("NewVirtualConstant", dt, nIndexed, fStatic, fPersist);
                    prop = cd.addVirtualConstant(dt, sName, nIndexed, Constants.ACCESS_PUBLIC);
                    break;
        
                case 'C':
                    sName = generateName("NewCalculatedProperty", dt, nIndexed, fStatic, fPersist);
                    prop = cd.addCalculatedProperty(dt, sName, nIndexed, fStatic);
                    break;
        
                case 'F':
                    sName = generateName("NewFunctionalProperty", dt, nIndexed, fStatic, fPersist);
                    prop = cd.addFunctionalProperty(dt, sName, nIndexed, fStatic);
                    break;
        
                case 'S':
                    fPersist = true;
                    sName = generateName("NewProperty", dt, nIndexed, fStatic, fPersist);
                    prop = cd.addProperty(dt, sName, nIndexed, fStatic, fPersist);
                    break;
        
                default:
                    throw new IllegalArgumentException();
                }
        
            if (!prop.isConstant())
                {
                int nAccessorAccess = Constants.ACCESS_PUBLIC;
        
                Behavior[] abhvr = prop.getAccessors();
                for (int i = 0; i < abhvr.length; i++)
                    {
                    Behavior bhvr = abhvr[i];
                    if (bhvr != null)
                        {
                        bhvr.setAccess(nAccessorAccess);
                        }
                    }
                }
            }
        catch (PropertyVetoException e)
            {
            getErrorList().addWarning(e.getMessage());
            reportErrors();
            }
        
        return prop;
        }
    
    /**
    * Duplicate the specified property
    * 
    * @see PropertyDesigner#duplicateCurrentProperty
    */
    public com.tangosol.dev.component.Property duplicateProperty(com.tangosol.dev.component.Property prop)
        {
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.Implementation;
        // import java.beans.PropertyVetoException;
        
        Component cd      = getLocalCD();
        Property  propNew = null;
        
        try
            {
            DataType dt       = prop.getDataType();
            int      nAccess  = prop.getAccess();
            int      nIndexed = prop.getIndexed();
            int      nVisible = prop.getVisible();
            boolean  fStatic  = prop.isStatic();
            boolean  fPersist = prop.isPersistent();
           
            String   sName    = generateName(prop.getName(), dt, nIndexed, fStatic, fPersist);
        
            if (     prop.isJavaConstant())
                {
                propNew = cd.addJavaConstant(dt, sName, nIndexed, fStatic, nAccess);
                }
            else if (prop.isVirtualConstant())
                {
                propNew = cd.addVirtualConstant(dt, sName, nIndexed, nAccess);
                }
            else if (prop.isCalculatedProperty())
                {
                propNew = cd.addCalculatedProperty(dt, sName, nIndexed, fStatic);
                }
            else if (prop.isFunctionalProperty())
                {
                propNew = cd.addFunctionalProperty(dt, sName, nIndexed, fStatic);
                }
            else if (prop.isStandardProperty())
                {
                propNew = cd.addProperty(dt, sName, nIndexed, fStatic, fPersist);
                }
            else
                {
                throw new IllegalStateException("Unknown property type: " + prop);
                }
        
            try
                {
                // dupe the visibility, value and doc
                propNew.setVisible(prop.getVisible());
                propNew.setValue(prop.getValue());
                propNew.setDescription(prop.getDescription());
                propNew.setTip(prop.getTip());
        
                // the accessors
                if (!prop.isConstant())
                    {
                    Behavior[] abhvr    = prop.getAccessors();
                    Behavior[] abhvrNew = propNew.getAccessors();
                    int        cBhvr    = abhvr.length;
                    for (int i = 0; i < cBhvr; i++)
                        {
                        Behavior bhvr    = abhvr[i];
                        Behavior bhvrNew = abhvrNew[i];
                        if (bhvr != null && bhvrNew != null)
                            {
                            bhvrNew.setAccess(bhvr.getAccess());
        
                            int cParam = bhvr.getParameterCount();
                            for (int j = 0; j < cParam; j++)
                                {
                                bhvrNew.getParameter(j).setName(
                                    bhvr.getParameter(j).getName());
                                }
        
                            int cImpl = bhvr.getModifiableImplementationCount();
                            for (int j = 0; j < cImpl; j++)
                                {
                                Implementation impl = bhvr.getImplementation(j);
                                bhvrNew.addImplementation(j,
                                    impl.getLanguage(), impl.getScript());
                                }
                            }
                        }
                    }
                }
            catch (PropertyVetoException e)
                {
                // couldn't dupe something, not a big deal
                getErrorList().addInfo(e.getMessage());
                }
            }
        catch (PropertyVetoException e)
            {
            getErrorList().addError(e.getMessage());
            }
        
        return propNew;
        }
    
    private String generateName(String sPrefix, com.tangosol.dev.component.DataType dtType, int nIndexed, boolean fStatic, boolean fPersist)
        {
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.DataType;
        
        Component cd = getLocalCD();
        _assert(cd.isModifiable());
        
        String sPropName = sPrefix;
        
        for(int i = 1; !cd.isPropertyAddable(dtType, sPropName, nIndexed, fStatic, fPersist); i++)
           {
           sPropName = sPrefix + "_" + i;
           }
        return sPropName;
        }
    
    /**
    * Converts the specified property's value into a displayable text.
    * 
    * @see Component.Dev.Design#getText
    */
    public String getDisplayValue(com.tangosol.dev.component.Property prop)
        {
        // import Component.Dev.Design;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Property;
        
        if (prop.isCalculatedProperty() || prop.getIndexed() == Property.PROP_INDEXEDONLY)
            {
            return "n/a";
            }
        else
            {
            Design designInfo = Design.getDesignInfo(prop);
        
            _assert(designInfo != null);
        
            Object   oValue = prop.getValue();
            DataType dtProp = prop.getDataType();
            String   sValue = designInfo.getText(oValue,
                prop.isSingle() ? dtProp : dtProp.getArrayType());
        
            return sValue == null ? "n/a" : sValue;
            }
        }
    
    /**
    * Converts the specified string into a property value for the specified
    * property
    * 
    * @see Component.Dev.Design#getValue
    */
    public Object getPropertyValue(String sValue, com.tangosol.dev.component.Property prop)
        {
        // import Component.Dev.Design;
        // import Component.Dev.Storage;
        // import com.tangosol.dev.component.DataType;
        
        Design designInfo = Design.getDesignInfo(prop);
        
        _assert(designInfo != null);
        
        DataType dtProp  = prop.getDataType();
        DataType dtValue = prop.isSingle() ? dtProp : dtProp.getArrayType();
        Storage  store   = getStorage();
        
        if (!designInfo.isTextLegal(sValue, dtValue, store))
            {
            throw new IllegalArgumentException("Illegal value " + sValue +
                " for property " + prop + " (" + designInfo + ")");
            }
        
        return designInfo.getValue(sValue, dtValue, store);

        }
    
    public boolean isPropertyShowing(com.tangosol.dev.component.Property prop)
        {
        // import com.tangosol.dev.component.Constants;
        
        int nVisibility = getCDDesigner().getFilterVisibility();
        
        // "View-Declared" option is represented as EXISTS_INSERT bit.
        if ((nVisibility & Constants.EXISTS_INSERT) != 0)
            {
            // When "View-Declared" option is on, show declared at this level,
            // as well as properties with re-defined values
            // except for design-only properties
            if ((prop.isDeclaredAtThisLevel() || !prop.isValueDiscardable())
              && !prop.isDesignOnly())
                {
                return true;
                }
            }
        
        switch (nVisibility & Constants.VIS_MASK)
            {
            default:
            case Constants.VIS_VISIBLE:
                // don't show inherited calculated properties even if marked as VISIBLE
                return prop.getVisible() == Constants.VIS_VISIBLE &&
                     (!prop.isFromSuper() || !prop.isCalculatedProperty());
            case Constants.VIS_ADVANCED:
                return prop.getVisible() == Constants.VIS_VISIBLE ||
                       prop.getVisible() == Constants.VIS_ADVANCED;
            case Constants.VIS_HIDDEN:
                return prop.getVisible() != Constants.VIS_SYSTEM;
            case Constants.VIS_SYSTEM:
                return true;
            }
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets closed<p>
    * Note: this method is called before the host is notified with closeTool(),
    * so no relevant host's destruction has been done yet.
    * 
    * @see #setOpen
    * @see Host#closeTool
    */
    public void onClose()
        {
        // import com.tangosol.dev.component.Component;
        
        super.onClose();
        
        Component cd = getLocalCD();
        if (cd != null)
            {
            cd.removeSubChangeListener(this);
            }
        }
    
    // Declared at the super level
    /**
    * Notification from the CDDesigner host that the trait filter has changed
    * 
    * @see CDDesigner#setFilterVisibility()
    */
    public void onFilterChanged()
        {
        super.onFilterChanged();
        
        getToolSite().load(true);

        }
    
    // Declared at the super level
    /**
    * Notification from the CDDesigner host that the local CD has changed
    * 
    * @see CDDesigner#setLocalCD()
    */
    public void onLocalCDChanged(com.tangosol.dev.component.Component cdOld)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.PropertyDesigner;
        // import com.tangosol.dev.component.Component;
        
        super.onLocalCDChanged(cdOld);
        
        Component cdNew = getLocalCD();
        
        if (!isOpen() || cdOld == cdNew)
            {
            return;
            }
        
        if (cdOld != null)
            {
            cdOld.removeSubChangeListener(this);
            }
        
        PropertyDesigner toolSite = (PropertyDesigner) getToolSite();
        toolSite.setLocalCD(cdNew);
        
        if (cdNew != null)
            {
            cdNew.addSubChangeListener(this);
            }
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets opened.<p>
    * Note: this method is called after the host is notified with openTool(),
    * so all the relevant host's initialization is already done.
    * 
    * @see #setOpen
    * @see Host#openTool
    */
    public void onOpen()
        {
        super.onOpen();
        
        onLocalCDChanged(null);
        }
    
    // From interface: com.tangosol.dev.component.SubChangeListener
    public void subChange(com.tangosol.dev.component.SubChangeEvent evtSub)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.PropertyDesigner;
        // import com.tangosol.dev.component.Trait;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.SubChangeEvent;
        // import java.beans.PropertyChangeEvent;
        
        Trait trait = evtSub.getSubTrait();
        if (!(trait instanceof Property))
            {
            return;
            }
        
        Property prop = (Property) trait;
        
        if (prop.getComponent() != getLocalCD())
            {
            return;
            }
        
        PropertyDesigner site = (PropertyDesigner) getToolSite();
        
        switch (evtSub.getAction())
            {
            case SubChangeEvent.SUB_CHANGE:
                PropertyChangeEvent evtChange = (PropertyChangeEvent) evtSub.getEvent();
                /*
                _trace(get_Name() + ".subChange: " +
                    "property " + prop.getName() + " of " + prop.getComponent() + 
                    " sAttribute " + evtChange.getPropertyName() +
                    "\nold=" + evtChange.getOldValue() + " new=" + evtChange.getNewValue());
                */
                site.onPropertyModified(prop, evtChange.getPropertyName(), evtChange.getOldValue());
                break;
        
            case SubChangeEvent.SUB_UNREMOVE:
            case SubChangeEvent.SUB_ADD:
                // _trace(get_Name() + ".subChange: " + "property added/unremoved=" + prop);
                site.onPropertyAdded(prop);
                break;
        
            case SubChangeEvent.SUB_REMOVE:
                // _trace(get_Name() + ".subChange: " + "property removed=" + prop);
                site.onPropertyRemoved(prop);
                break;
            }
        }
    }
