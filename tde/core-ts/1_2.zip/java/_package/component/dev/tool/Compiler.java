/* Class
*     _package.component.dev.tool.Compiler
*/

package _package.component.dev.tool;

import _package.component.dev.Storage;
import _package.component.dev.compiler.ClassGenerator;
import _package.component.dev.storage.TAPSStorage;
import _package.component.dev.tool.OutputTool;
import _package.component.dev.util.DocInfo;
import _package.component.dev.util.TraitLocator;
import com.tangosol.dev.assembler.ClassFile;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.util.ErrorList$Item; // as ErrorInfo
import com.tangosol.util.ErrorList;
import com.tangosol.util.StringTable;
import com.tangosol.util.WrapperException;
import java.util.Date;
import java.util.Iterator;

public class Compiler
        extends    _package.component.dev.Tool
    {
    // Fields declarations
    
    /**
    * Property COMMAND_PREFIX
    *
    */
    private static final String COMMAND_PREFIX = "Stop ";
    
    /**
    * Property CommandItem
    *
    * A command item (in this case a JMenuItem) that a user controls this tool
    * with. Action event on this item causes the Compiler tool to start or stop
    * the compilation of dependencies. A single component compilation is
    * "non-stoppable".
    */
    private transient _package.component.gUI.control.container.jComponent.AbstractButton __m_CommandItem;
    
    /**
    * Property Component
    *
    * Component Definition to be compiled by this tool
    */
    private transient com.tangosol.dev.component.Component __m_Component;
    
    /**
    * Property ComponentName
    *
    * Fully qualified component name to be compiled by this tool
    */
    private transient String __m_ComponentName;
    
    /**
    * Property Dependencies
    *
    * Specifies whether the component dependencies have to be compiled as well
    */
    private boolean __m_Dependencies;
    
    /**
    * Property GenerateListing
    *
    * Specifies whether the listing should be generated
    */
    private boolean __m_GenerateListing;
    
    /**
    * Property InThread
    *
    * Specifies whether the compilation should be done on the caller's thread
    * (InThread is true) or asynchronously.
    */
    private transient boolean __m_InThread;
    
    /**
    * Property ModifiedOnly
    *
    * Specifies whether the components that have not been modified at the
    * current sub-project should be compiled. This property is only used when
    * the Dependencies property is set to true and the compiled component is
    * not a Signature.
    * 
    * The default value is false, meaning that all the sub-components should be
    * compiled (when the Dependencies property is true).
    */
    private boolean __m_ModifiedOnly;
    
    /**
    * Property OutputTool
    *
    * Instance of the output tool to use for error reporitng.
    */
    private transient OutputTool __m_OutputTool;
    
    /**
    * Property StoreResult
    *
    * Specifies whether the compilation result should be stored
    */
    private boolean __m_StoreResult;
    
    // Default constructor
    public Compiler()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Compiler(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(5.0F);
            setGenerateListing(true);
            setModifiedOnly(false);
            setStoreResult(true);
            setTitle("Compile");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new Compiler$Worker("Worker", this, true), "Worker");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Compiler();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/Compiler".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    public void compile()
        {
        // import Component.Dev.Storage;
        // import Component.Dev.Tool.OutputTool;
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import java.util.Date;
        
        if (!isOpen())
            {
            setInThread(true);
            }
        
        Storage    storage    = getStorage();
        OutputTool toolOutput = getOutputTool();
        String     sOutTitle  = getTitle();
        
        toolOutput.clearOutput(sOutTitle);
        
        Component cd = getComponent();
        if (cd == null)
            {
            try
                {
                cd = storage.loadComponent(getComponentName(), true, getErrorList());
                }
            catch (ComponentException e) {}
        
            if (cd == null)
                {
                toolOutput.output(sOutTitle,
                    new String[] {"*** Failed to load: " + getComponentName()});
                return;
                }
            setComponent(cd);
            }
        
        toolOutput.output(sOutTitle, new String[] {"Compilation started:  " + new Date()});
        
        if (cd.isSignature())
            {
            String    sClz = cd.getQualifiedName();
            ClassFile clsf = null;
            try
                {
                clsf = storage.loadOriginalClass(sClz);
                }
            catch (ComponentException e) {}
        
            if (clsf == null)
                {
                toolOutput.output(sOutTitle,
                    new String[] {"*** Failed to load: " + sClz});
                return;
                }
        
            compileClass(clsf, cd);
            }
        else
            {
            compileComponent(cd, true, isModifiedOnly());
            }
        
        if (isInThread() || isOpen())
            {
            toolOutput.output(sOutTitle,
                new String[] {"Compilation completed:  " + new Date()});
            setOpen(false);
            }
        else
            {
            toolOutput.output(sOutTitle,
                new String[] {"Compilation interrupted!"});
            }
        }
    
    private void compileClass(com.tangosol.dev.assembler.ClassFile clsf, com.tangosol.dev.component.Component cdJCS)
        {
        // import Component.Dev.Compiler.ClassGenerator;
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.util.WrapperException;
        
        if (!isInThread() && !isOpen())
            {
            return;
            }
        
        try
            {
            if (cdJCS.isInterface())
                {
                // create a new JCS that derives from java.lang.Object
                // and implements the specified interface
                Component cdSuper = getStorage().loadSignature("java.lang.Object");
                Component cdStub  = cdSuper.createDerivedComponent(cdJCS.getName(), getStorage());
        
                cdStub.addImplements(cdJCS);
                cdJCS = cdStub;
        
                clsf = new ClassFile(cdStub.getName(), cdSuper.getName(), false);
                }
        
            ClassGenerator gen = new ClassGenerator();
            gen.setCD(cdJCS);
            gen.setClassFile(clsf);
            gen.setStorage(getStorage());
            gen.setErrorList(getErrorList());
            gen.setGenerateListing(false);
            gen.setStoreResult(isStoreResult()); 
        
            gen.updateClass();
            }
        catch (Exception e)
            {
            String sMsg = "Fatal exception occurred during compilation: " +
                 clsf.getName() + " -- " + e.getMessage();
            getErrorList().addFatal(sMsg);
        
            _trace(e);
            }
        
        reportErrors();

        }
    
    /**
    * Recompile the specified component
    * 
    * @param cd Component Definition to compile or recurse
    * @param fCompile if set to true, the specified component should be
    * compiled
    * @param fModifiedOnly if set to true, only modified subcomponents should
    * be compiled
    */
    private void compileComponent(com.tangosol.dev.component.Component cd, boolean fCompile, boolean fModifiedOnly)
        {
        // import Component.Dev.Compiler.ClassGenerator;
        // import Component.Dev.Storage.TAPSStorage;
        // import Component.Dev.Tool.OutputTool;
        // import Component.Dev.Util.DocInfo;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.util.ErrorList;
        // import com.tangosol.util.StringTable;
        
        if (!isInThread() && !isOpen())
            {
            return;
            }
        
        TAPSStorage  storage    = (TAPSStorage) getStorage();
        OutputTool   toolOutput = getOutputTool();
        String       sOutTitle  = getTitle();
        ErrorList    errlist    = getErrorList();
        
        if (fCompile)
            {
            ClassGenerator gen = new ClassGenerator();
            gen.setCD(cd);
            gen.setStorage(storage);
            gen.setErrorList(errlist);
            gen.setGenerateListing(isGenerateListing());
            gen.setStoreResult(isStoreResult());
        
            // use default for the following...
            // gen.setDebugInfo(true);
            // gen.setOptimizePrivateAccessors(false);
        
            try
                {
                gen.compile();
                }
            catch (Exception e)
                {
                String sMsg = "Fatal exception occurred during compilation: " +
                     cd.getName() + " -- " + e.getMessage();
                errlist.addFatal(sMsg);
        
                _trace(e);
                }
        
            reportErrors();
            }
        
        if (isDependencies())
            {
            String      sSuper = cd.getQualifiedName();
            StringTable tblSub = storage.getSubComponents(sSuper, false);
            StringTable tblPkg = null;
            if (tblSub.isEmpty())
                {
                return;
                }
        
            if (fModifiedOnly)
                {
                tblPkg = storage.getComponentPackages(sSuper, false, false);
                }
        
            String[] asSub = tblSub.strings();
            for (int i = 0, cSubs = asSub.length; i < cSubs; i++)
                {
                String  sSubU    = asSub[i];
                String  sSubQ    = sSuper + '.' + sSubU;
                boolean fRecurse = true;
                boolean fCompSub = true;
                boolean fModOnly = fModifiedOnly;
        
                if (fModOnly)
                    {
                    DocInfo info = DocInfo.instantiate(sSubQ, "Component");
                    info.setStorageLocator(tblSub.get(sSubU));
                    info.setSubLocator(tblPkg.get(sSubU));
        
                    // if this component has been modified,
                    // we have to re-compile all the subs as well
                    fCompSub = info.isModifiedAtSubproject(storage.getTarget());
                    if (fCompSub)
                        {
                        fModOnly = false;
                        fRecurse = true;
                        }
                    else
                        {
                        fRecurse = info.isSubModifiedAtSubproject(storage.getTarget());
                        }
                    }
        
                if (fRecurse)
                    {
                    Component cdSub = null;
                    try
                        {
                        cdSub = storage.loadComponent(sSubQ, false, errlist);
                        }
                    catch (ComponentException e) {}
        
                    if (cdSub == null)
                        {
                        toolOutput.output(sOutTitle, "*** Failed to load: " + sSubQ);
                        continue;
                        }
                    
                    if (fCompSub)
                        {
                        toolOutput.output(sOutTitle, new String[] {sSubQ});
                        }
        
                    compileComponent(cdSub, fCompSub, fModOnly);
                    }
                }
            }
        }
    
    // Accessor for the property "CommandItem"
    /**
    * Getter for property CommandItem.<p>
    * A command item (in this case a JMenuItem) that a user controls this tool
    * with. Action event on this item causes the Compiler tool to start or stop
    * the compilation of dependencies. A single component compilation is
    * "non-stoppable".
    */
    public _package.component.gUI.control.container.jComponent.AbstractButton getCommandItem()
        {
        return __m_CommandItem;
        }
    
    // Accessor for the property "Component"
    /**
    * Getter for property Component.<p>
    * Component Definition to be compiled by this tool
    */
    public com.tangosol.dev.component.Component getComponent()
        {
        return __m_Component;
        }
    
    // Accessor for the property "ComponentName"
    /**
    * Getter for property ComponentName.<p>
    * Fully qualified component name to be compiled by this tool
    */
    public String getComponentName()
        {
        return __m_ComponentName;
        }
    
    // Accessor for the property "OutputTool"
    /**
    * Getter for property OutputTool.<p>
    * Instance of the output tool to use for error reporitng.
    */
    public OutputTool getOutputTool()
        {
        return __m_OutputTool;
        }
    
    // Accessor for the property "Dependencies"
    /**
    * Getter for property Dependencies.<p>
    * Specifies whether the component dependencies have to be compiled as well
    */
    public boolean isDependencies()
        {
        return __m_Dependencies;
        }
    
    // Accessor for the property "GenerateListing"
    /**
    * Getter for property GenerateListing.<p>
    * Specifies whether the listing should be generated
    */
    public boolean isGenerateListing()
        {
        return __m_GenerateListing;
        }
    
    // Accessor for the property "InThread"
    /**
    * Getter for property InThread.<p>
    * Specifies whether the compilation should be done on the caller's thread
    * (InThread is true) or asynchronously.
    */
    private boolean isInThread()
        {
        return __m_InThread;
        }
    
    // Accessor for the property "ModifiedOnly"
    /**
    * Getter for property ModifiedOnly.<p>
    * Specifies whether the components that have not been modified at the
    * current sub-project should be compiled. This property is only used when
    * the Dependencies property is set to true and the compiled component is
    * not a Signature.
    * 
    * The default value is false, meaning that all the sub-components should be
    * compiled (when the Dependencies property is true).
    */
    public boolean isModifiedOnly()
        {
        return __m_ModifiedOnly;
        }
    
    // Accessor for the property "StoreResult"
    /**
    * Getter for property StoreResult.<p>
    * Specifies whether the compilation result should be stored
    */
    public boolean isStoreResult()
        {
        return __m_StoreResult;
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets closed<p>
    * Note: this method is called before the host is notified with closeTool(),
    * so no relevant host's destruction has been done yet.
    * 
    * @see #setOpen
    * @see Host#closeTool
    */
    public void onClose()
        {
        super.onClose();
        
        if (getHost() != null)
            {
            getHost().removeTool(this);
            }
        
        if (getCommandItem() != null)
            {
            String sText = getCommandItem().getText();
            if (sText.startsWith(COMMAND_PREFIX))
                {
                getCommandItem().setText(sText.substring(COMMAND_PREFIX.length()));
                }
            }
        
        $Worker Worker = ($Worker) _findName("Worker");
        Worker.stop();

        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets opened.<p>
    * Note: this method is called after the host is notified with openTool(),
    * so all the relevant host's initialization is already done.
    * 
    * @see #setOpen
    * @see Host#openTool
    */
    public void onOpen()
        {
        super.onOpen();
        
        if (isDependencies() && getCommandItem() != null)
            {
            String sText = getCommandItem().getText();
            getCommandItem().setText(COMMAND_PREFIX + sText);
            }
        
        $Worker Worker = ($Worker) _findName("Worker");
        
        // this will call "compile" on a daemon thread
        Worker.start();
        Worker.setNotification(true);
        }
    
    // Declared at the super level
    /**
    * Report the errors out of ErrorList for this tool.
    * 
    * Note: this is just a convinience method that passes the control up to the
    * host.
    */
    public void reportErrors()
        {
        // import Component.Dev.Util.TraitLocator;
        // import com.tangosol.util.ErrorList;
        // import com.tangosol.util.ErrorList$Item as ErrorInfo;
        // import java.util.Iterator;
        
        ErrorList errList = getErrorList();
        int       cErrors = errList.size();
        if (cErrors != 0)
            {
            Object[] aoError = new Object[cErrors];
            Iterator iter    = errList.iterator();
            for (int i = 0; iter.hasNext(); i++)
                {
                ErrorInfo error   = (ErrorInfo) iter.next();
                Object    locator = error.getLocator();
        
                aoError[i] = locator instanceof TraitLocator ? locator : error;
                }
            errList.clear();
        
            getOutputTool().setActive(true);
            getOutputTool().output(getTitle(), aoError);
            _beep();
            }

        }
    
    // Accessor for the property "CommandItem"
    /**
    * Setter for property CommandItem.<p>
    * A command item (in this case a JMenuItem) that a user controls this tool
    * with. Action event on this item causes the Compiler tool to start or stop
    * the compilation of dependencies. A single component compilation is
    * "non-stoppable".
    */
    public void setCommandItem(_package.component.gUI.control.container.jComponent.AbstractButton pCommandItem)
        {
        __m_CommandItem = pCommandItem;
        }
    
    // Accessor for the property "Component"
    /**
    * Setter for property Component.<p>
    * Component Definition to be compiled by this tool
    */
    public void setComponent(com.tangosol.dev.component.Component pComponent)
        {
        __m_Component = pComponent;
        }
    
    // Accessor for the property "ComponentName"
    /**
    * Setter for property ComponentName.<p>
    * Fully qualified component name to be compiled by this tool
    */
    public void setComponentName(String pComponentName)
        {
        __m_ComponentName = pComponentName;
        }
    
    // Accessor for the property "Dependencies"
    /**
    * Setter for property Dependencies.<p>
    * Specifies whether the component dependencies have to be compiled as well
    */
    public void setDependencies(boolean pDependencies)
        {
        __m_Dependencies = pDependencies;
        }
    
    // Accessor for the property "GenerateListing"
    /**
    * Setter for property GenerateListing.<p>
    * Specifies whether the listing should be generated
    */
    public void setGenerateListing(boolean pGenerateListing)
        {
        __m_GenerateListing = pGenerateListing;
        }
    
    // Accessor for the property "InThread"
    /**
    * Setter for property InThread.<p>
    * Specifies whether the compilation should be done on the caller's thread
    * (InThread is true) or asynchronously.
    */
    private void setInThread(boolean pInThread)
        {
        __m_InThread = pInThread;
        }
    
    // Accessor for the property "ModifiedOnly"
    /**
    * Setter for property ModifiedOnly.<p>
    * Specifies whether the components that have not been modified at the
    * current sub-project should be compiled. This property is only used when
    * the Dependencies property is set to true and the compiled component is
    * not a Signature.
    * 
    * The default value is false, meaning that all the sub-components should be
    * compiled (when the Dependencies property is true).
    */
    public void setModifiedOnly(boolean pModifiedOnly)
        {
        __m_ModifiedOnly = pModifiedOnly;
        }
    
    // Accessor for the property "OutputTool"
    /**
    * Setter for property OutputTool.<p>
    * Instance of the output tool to use for error reporitng.
    */
    public void setOutputTool(OutputTool pOutputTool)
        {
        __m_OutputTool = pOutputTool;
        }
    
    // Accessor for the property "StoreResult"
    /**
    * Setter for property StoreResult.<p>
    * Specifies whether the compilation result should be stored
    */
    public void setStoreResult(boolean pStoreResult)
        {
        __m_StoreResult = pStoreResult;
        }
    }
