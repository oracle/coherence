/* Class
*     _package.component.dev.tool.host.CDTool
*/

package _package.component.dev.tool.host;

import _package.component.dev.tool.host.CDDesigner;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Property;

public class CDTool
        extends    _package.component.dev.tool.Host
    {
    // Fields declarations
    
    /**
    * Property CDDesigner
    *
    */
    
    /**
    * Property GlobalCD
    *
    * Specifies the currently designed global Component Definition.
    */
    
    /**
    * Property LocalCD
    *
    * Specifies the currently designed local Component Definition.
    */
    private transient com.tangosol.dev.component.Component __m_LocalCD;
    
    /**
    * Property OutputTool
    *
    * (Calculated) Specifies the OutputTool to use for this tool.
    */
    
    // Default constructor
    public CDTool()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDTool(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new CDTool();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/host/CDTool".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Property;
        // import Component.Dev.Tool.Host.CDDesigner;
        
        
        

        }
    
    // Accessor for the property "CDDesigner"
    public CDDesigner getCDDesigner()
        {
        return (CDDesigner) getHost();
        }
    
    public com.tangosol.dev.component.DataType getDataType(String sType)
        {
        sType = sType.trim();
        
        if (sType.length() == 0)
            return null;
        
        if (sType.endsWith("[]"))
            {
            DataType dt = getDataType(sType.substring(0, sType.length() - 2));
        
            return dt != null ? DataType.getArrayType(dt) : null;
            }
        
        // 1) try the intrinsic types
        
        if (sType.equals("boolean"))
            return DataType.BOOLEAN;
        
        if (sType.equals("char"))
            return DataType.CHAR;
        
        if (sType.equals("byte"))
            return DataType.BYTE;
        
        if (sType.equals("short"))
            return DataType.SHORT;
        
        if (sType.equals("int"))
            return DataType.INT;
        
        if (sType.equals("long"))
            return DataType.LONG;
        
        if (sType.equals("float"))
            return DataType.FLOAT;
        
        if (sType.equals("double"))
            return DataType.DOUBLE;
        
        if (sType.equals("void"))
            return DataType.VOID;
        
        try
            {
            // 2) try a component
            int ofLocal = sType.indexOf('$');
            if (ofLocal == 0)
                {
                // '$' in front of a name could only specify a local child
                Component cdChild = getGlobalCD().getLocal(sType.substring(1));
        
                return cdChild == null ? null :
                    DataType.getComponentType(cdChild.getQualifiedName());
                }
            else if (Component.isQualifiedNameLegal(sType))
                {
                String    sGlobal  = ofLocal > 0 ? sType.substring(0, ofLocal) : sType;
                Component cdGlobal = sGlobal.equals(getGlobalCD().getQualifiedName()) ?
                    getGlobalCD() : getStorage().loadComponent(sGlobal, true, null);
                
                if (cdGlobal != null)
                    {
                    if (ofLocal > 0)
                        {
                        Component cdChild = cdGlobal.getLocal(sType.substring(ofLocal + 1));
                        if (cdChild != null)
                            {
                            return DataType.getComponentType(cdChild.getQualifiedName());
                            }
                        }
                    else
                        {
                        return DataType.getComponentType(sType);
                        }
                    }
                return null;
                }
        
            // 3) finally try a java class (java.lang package is a default)
        
            String className = (sType.indexOf('.') == -1) ?
                "java.lang." + sType : sType;
        
            if (getStorage().loadSignature(className) != null)
                {
                return DataType.getClassType(className);
                }
            }
        catch (ComponentException e)
            {
            }
        
        return null;

        }
    
    public String getDisplayValue(com.tangosol.dev.component.DataType dt)
        {
        String sType = dt.toString();
        
        final String JAVA_PKG = "java.lang.";
        
        if (sType.startsWith(JAVA_PKG) &&
            sType.lastIndexOf('.') == JAVA_PKG.length() - 1)
            {
            sType = sType.substring(JAVA_PKG.length());
            }
        return sType;
        }
    
    // Declared at the super level
    /**
    * Let's have CDTool(s) share the ErrorList with their CDDesigner host.
    */
    public com.tangosol.util.ErrorList getErrorList()
        {
        return getCDDesigner().getErrorList();
        }
    
    // Accessor for the property "GlobalCD"
    public com.tangosol.dev.component.Component getGlobalCD()
        {
        return getCDDesigner().getGlobalCD();
        }
    
    // Accessor for the property "LocalCD"
    public com.tangosol.dev.component.Component getLocalCD()
        {
        return getCDDesigner().getLocalCD();
        }
    
    // Accessor for the property "OutputTool"
    public _package.component.dev.tool.OutputTool getOutputTool()
        {
        return (Component.Dev.Tool.OutputTool) getHost().getTool("Output");
        }
    
    /**
    * Notification from the CDDesigner host that the trait filter has changed
    * 
    * @see CDDesigner#setFilterVisibility()
    */
    public void onFilterChanged()
        {
        }
    
    /**
    * Notification from the CDDesigner host that the global CD has changed
    * 
    * This could happen only in the case when renaming a component causes the
    * Component Definition reference to change
    * 
    * @see CDDesigner#renameComponent()
    * @see CDDesigner#setGlobalCD()
    */
    public void onGlobalCDChanged(com.tangosol.dev.component.Component cdOld)
        {
        }
    
    /**
    * Notification from the CDDesigner host that the local CD has changed
    * 
    * @see CDDesigner#setLocalCD()
    */
    public void onLocalCDChanged(com.tangosol.dev.component.Component cdOld)
        {
        }
    
    // Accessor for the property "LocalCD"
    public void setLocalCD(com.tangosol.dev.component.Component pLocalCD)
        {
        if (pLocalCD != getLocalCD())     
            {                                 
            getCDDesigner().setLocalCD(pLocalCD);         
            }                                 

        }
    }
