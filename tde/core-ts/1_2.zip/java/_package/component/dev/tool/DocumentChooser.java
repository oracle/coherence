/* Class
*     _package.component.dev.tool.DocumentChooser
*/

package _package.component.dev.tool;

import _package.component.dev.Storage;
import _package.component.dev.util.DocInfo;
import _package.component.gUI.control.container.jComponent.AbstractButton;
import _package.component.gUI.control.container.jComponent.jPanel.toolSite.DocumentBrowser;
import javax.swing.SwingUtilities;

public class DocumentChooser
        extends    _package.component.dev.Tool
        implements java.lang.Runnable
    {
    // Fields declarations
    
    /**
    * Property SelectedDocument
    *
    * (Calculated) Specifies the currently selected document.
    */
    
    /**
    * Property ViewFilter
    *
    * Specifies the value of the Filter that is used by the document browsers
    * to filter the tree of the documents to show
    * 
    * @see ToolSite.HostSite.TAPSMain$Menu$View$Show
    */
    private int __m_ViewFilter;
    
    // Default constructor
    public DocumentChooser()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public DocumentChooser(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new DocumentChooser();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/DocumentChooser".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Fires the specified action agians a currently selected document.
    * 
    * @see ToolSite.DocumentBrowser$Tree.onMouseClick
    */
    public void fireSelectedDocumentAction(String sAction)
        {
        // import Component.Dev.Util.DocInfo;
        
        DocInfo infoSelection = getSelectedDocument();
        
        if (infoSelection != null)
            {
            fireToolAction(sAction, infoSelection);
            }
        }
    
    // Accessor for the property "SelectedDocument"
    /**
    * Returns a identification of the currently selected document in a format
    * of String[2], where
    * value at index 0 is a document [fully qualified] name and value at index
    * 1 is a document type (or category)
    */
    protected _package.component.dev.util.DocInfo getSelectedDocument()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.DocumentBrowser;
        
        return ((DocumentBrowser) getToolSite()).getSelectedDocument();
        }
    
    // Accessor for the property "ViewFilter"
    /**
    * Getter for property ViewFilter.<p>
    * Specifies the value of the Filter that is used by the document browsers
    * to filter the tree of the documents to show
    * 
    * @see ToolSite.HostSite.TAPSMain$Menu$View$Show
    */
    public int getViewFilter()
        {
        return __m_ViewFilter;
        }
    
    // Declared at the super level
    /**
    * Return true if the specified action fired by the specified host is
    * enabled by this tool; false otherwise.
    * The hosts additionally return true if at least one child tool of this
    * host "enables" this action.
    * 
    * This method is mostly used by host sites' menus to provide a visual clue
    * to the question:
    *  - If this host issues a command (host action), will there be any tool
    * being able to process this command
    * 
    * When the host is specified, the specified action is expected to be fired
    * by that host using fireHostAction(). If the host is null, this action is
    * expected to be fired by this tool itself using fireToolAction().
    * 
    * @param sAction  action name
    * @param host  the source of the action
    * @param  oValue an optional value to be passed along
    */
    public boolean isActionEnabled(String sAction, Host host, Object oValue)
        {
        // import Component.Dev.Storage;
        // import Component.Dev.Util.DocInfo;
        
        DocInfo infoSelection = getSelectedDocument();
        if (isActive() && infoSelection != null)
            {
            String sType = infoSelection.getType();
        
            if (sAction.equals(ACTION_OPEN))
                {
                return (isEditableType(sType));
                }
            else if (sAction.equals(ACTION_OPEN_WITH))
                {
                return sType.equals("Resource");
                }
            else if (
                sAction.equals(ACTION_REMOVE))
                {
                Object  oLocator = infoSelection.getStorageLocator();
                Storage storage  = getStorage().locatePersistentStorage(null);
        
                return (isEditableType(sType) &&
                        oLocator != null && storage != null &&
                        oLocator.equals(storage.getLocator()));
                }
            else if (
                sAction.equals(ACTION_CREATE)
             || sAction.equals(ACTION_TEST_RUN))
                {
                return infoSelection.getType().equals("Component");
                }
            else if (
                sAction.equals(ACTION_COMPILE)
             || sAction.equals(ACTION_COMPILE_TREE))
                {
                // Compile commands on the Browser's Context menu
                // work with a selected component, while the equivalent
                // commands on the main menu work with the currently open
                // active document which this tool has no clue about
                if (host == null)
                    {
                    // this command comes from the browser itself
                    return (isEditableType(sType));
                    }
                else
                    {
                    // command comes from the main menu
                    return false;
                    }
                }
            }
        else if (
            sAction.equals(ACTION_VIEW_FILTER))
            {
            return getStorage() != null;
            }
        
        return super.isActionEnabled(sAction, host, oValue);

        }
    
    /**
    * Helper method returning true for a document type representing an
    * "editable" document
    */
    protected boolean isEditableType(String sType)
        {
        return (sType.equals("Component") ||
                sType.equals("Signature") ||
                sType.equals("Resource"));

        }
    
    // Declared at the super level
    /**
    * Notification send by one of the containing hosts
    * 
    * @param host  the acted host
    * @param sName  action name
    * @param oValue  associated value
    */
    public void onHostAction(Host host, String sAction, Object oValue)
        {
        // import javax.swing.SwingUtilities;
        
        if (sAction.equals(ACTION_OPEN)
         || sAction.equals(ACTION_CREATE)
         || sAction.equals(ACTION_REMOVE)
         || sAction.equals(ACTION_TEST_RUN))
            {
            if (oValue == null && isActive())
                {
                // Unspecified command -- turn it into the specified one
                fireSelectedDocumentAction(sAction);
                }
            }
        else if (
            sAction.equals(ACTION_PROJECT_OPEN)
         || sAction.equals(ACTION_PROJECT_CLOSE))
            {
            if (isOpen())
                {
                getToolSite().load(false);
                }
            }
        else if (
            sAction.equals(ACTION_REFRESH))
            {
            if (isOpen() &&
                oValue == null || getTitle().equals(oValue))
                {
                // ACTION_REFRESH could be fired by a daemon thread,
                // but must run on the AWT thread
                SwingUtilities.invokeLater(this);
                }
            }
        else if (
            sAction.equals(ACTION_VIEW_FILTER))
            {
            if (oValue instanceof Integer)
                {
                setViewFilter(((Integer) oValue).intValue());
                }
            }
        else
            {
            super.onHostAction(host, sAction, oValue);
            }
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets opened.<p>
    * Note: this method is called after the host is notified with openTool(),
    * so all the relevant host's initialization is already done.
    * 
    * @see #setOpen
    * @see Host#openTool
    */
    public void onOpen()
        {
        // import Component.GUI.Control.Container.JComponent.AbstractButton;
        
        super.onOpen();
        
        getToolSite().load(false);
        
        AbstractButton handle = getToolHandle();
        if (handle != null)
            {
            handle.setSelected(true);
            }
        }
    
    // From interface: java.lang.Runnable
    public void run()
        {
        // see onHostAction: ACTION_REFRESH
        getToolSite().load(true);
        }
    
    // Accessor for the property "ViewFilter"
    /**
    * Setter for property ViewFilter.<p>
    * Specifies the value of the Filter that is used by the document browsers
    * to filter the tree of the documents to show
    * 
    * @see ToolSite.HostSite.TAPSMain$Menu$View$Show
    */
    protected void setViewFilter(int pViewFilter)
        {
        if (pViewFilter == getViewFilter())
            {
            return;
            }
        __m_ViewFilter = (pViewFilter);
        
        if (getToolSite() != null)
            {
            getToolSite().load(true);
            }

        }
    }
