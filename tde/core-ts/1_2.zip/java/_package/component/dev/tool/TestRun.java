/* Class
*     _package.component.dev.tool.TestRun
*/

package _package.component.dev.tool;

import _package.component.dev.storage.TAPSStorage;
import com.tangosol.dev.assembler.ClassFile$Relocator;
import com.tangosol.dev.component.DataType;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

public class TestRun
        extends    _package.component.dev.Tool
        implements java.lang.Runnable
    {
    // Fields declarations
    
    /**
    * Property ClassPath
    *
    */
    
    /**
    * Property COMMAND_PREFIX
    *
    */
    public static final String COMMAND_PREFIX = "Stop ";
    
    /**
    * Property CommandItem
    *
    * A command item (in this case a JMenuItem) that a user controls this tool
    * with. Action event on this item causes the TestRun tool to start or stop.
    */
    private _package.component.gUI.control.container.jComponent.AbstractButton __m_CommandItem;
    
    /**
    * Property ComponentName
    *
    * Fully qualified component name to "test run"
    */
    private transient String __m_ComponentName;
    
    /**
    * Property Process
    *
    * Specifies the process spawned by the TestRun.
    */
    private transient Process __m_Process;
    
    // Default constructor
    public TestRun()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TestRun(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setTitle("Test Run");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new TestRun();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/TestRun".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "ClassPath"
    /**
    * Getter for property ClassPath.<p>
    */
    private String getClassPath()
        {
        // import java.io.File;
        // import java.io.IOException;
        // import java.util.StringTokenizer;
        // import java.util.ArrayList;
        // import java.util.Iterator;
        
        String[] asPath = new String[]
            {
            // the storage classpath is only needed to run in dev mode
            // getStorage().getClassPath(),
            System.getProperty("java.class.path", ""),
            System.getProperty("taps.testrun.path", ""),
            };
        
        ArrayList listPath = new ArrayList();
        for (int i = 0; i < asPath.length; i++)
            {
            StringTokenizer tokenizer =
                new StringTokenizer(asPath[i], File.pathSeparator);
        
            while (tokenizer.hasMoreTokens())
                {
                String sPath = tokenizer.nextToken();
                File   file  = new File(sPath);
        
                if (file.exists())
                    {
                    // make sure there are no duplicates (case sensitive)
                    try
                        {
                        sPath = file.getCanonicalPath();
                        }
                    catch (IOException e)
                        {
                        sPath = file.getAbsolutePath();
                        }
        
                    if (!listPath.contains(sPath))
                        {
                        listPath.add(sPath);
                        }
                    }
                }
            }
        
        StringBuffer sbPath = new StringBuffer();
        for (Iterator iter = listPath.iterator(); iter.hasNext();)
            {
            sbPath.append(File.pathSeparatorChar)
                  .append(iter.next());
            }
        
        return sbPath.substring(1);

        }
    
    // Accessor for the property "CommandItem"
    /**
    * Getter for property CommandItem.<p>
    * A command item (in this case a JMenuItem) that a user controls this tool
    * with. Action event on this item causes the TestRun tool to start or stop.
    */
    public _package.component.gUI.control.container.jComponent.AbstractButton getCommandItem()
        {
        return __m_CommandItem;
        }
    
    // Accessor for the property "ComponentName"
    /**
    * Getter for property ComponentName.<p>
    * Fully qualified component name to "test run"
    */
    public String getComponentName()
        {
        return __m_ComponentName;
        }
    
    private String getEnvironment()
        {
        // import Component.Dev.Storage.TAPSStorage;
        
        TAPSStorage storage = (TAPSStorage) getStorage();
        String      sPrefix = "tangosol.taps.";
        
        return " -D" + sPrefix + "repos=" + storage.getServerUri() +
               " -D" + sPrefix + "prj="   + storage.getQualifiedProject() +
               ' ';
        }
    
    // Accessor for the property "Process"
    /**
    * Getter for property Process.<p>
    * Specifies the process spawned by the TestRun.
    */
    public Process getProcess()
        {
        return __m_Process;
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets closed<p>
    * Note: this method is called before the host is notified with closeTool(),
    * so no relevant host's destruction has been done yet.
    * 
    * @see #setOpen
    * @see Host#closeTool
    */
    public void onClose()
        {
        super.onClose();
        
        if (getProcess() != null)
            {
            getProcess().destroy();
            }
        
        String sText = getCommandItem().getText();
        if (sText.startsWith(COMMAND_PREFIX))
            {
            getCommandItem().setText(sText.substring(COMMAND_PREFIX.length()));
            }
        getHost().removeTool(this);
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets opened.<p>
    * Note: this method is called after the host is notified with openTool(),
    * so all the relevant host's initialization is already done.
    * 
    * @see #setOpen
    * @see Host#openTool
    */
    public void onOpen()
        {
        // import com.tangosol.dev.assembler.ClassFile$Relocator;
        // import com.tangosol.dev.component.DataType;
        
        super.onOpen();
        
        final String APPLICATION = "Component.Application";
        final String CONSOLE     = "Component.Application.Console.TestRun";
        final String DESKTOP     = "Component.Application.GUI.Desktop.TestRun";
        final String FRAME       = "Component.GUI.Control.Container.Window.Frame.JFrame";
        final String WINDOW      = "Component.GUI.Control.Container.Window.JWindow";
        final String PANEL       = "Component.GUI.Control.Container.JComponent.JPanel";
        
        String sName = getComponentName();
        String sEntry;
        String sApp;
        String sTarget;
        
        if (sName.startsWith(APPLICATION + '.'))
            {
            sEntry  = sName;
            sApp    = sName;
            sTarget = "";
            }
        else if (sName.startsWith(FRAME  + '.') || 
                 sName.startsWith(PANEL  + '.') ||
                 sName.startsWith(WINDOW + '.'))
            {
            sEntry   = DESKTOP;
            sApp     = DESKTOP;
            sTarget  = sName;
            }
        else
            {
            sEntry  = CONSOLE;
            sApp    = CONSOLE;
            sTarget = sName;
            }
        
        String sEntryClz = DataType.getComponentClassName(sEntry);
        String sCmdLine  = "com.tangosol.dev.component.ComponentClassLoader " +
             sEntryClz + " -app:" + sApp + " -target:" + sTarget;
        
        (new Thread(this, sCmdLine)).start();
        
        getCommandItem().setText(COMMAND_PREFIX + getCommandItem().getText());
        }
    
    // From interface: java.lang.Runnable
    public void run()
        {
        // import java.io.InputStream;
        // import java.io.IOException;
        
        String sCmdArgs   = Thread.currentThread().getName();
        String sClassPath = getClassPath();
        String sEnv       = getEnvironment();
        String sCmdLine   = "java -cp " + sClassPath + sEnv + sCmdArgs;
        
        _trace('!' + sCmdLine);
        
        try
            {
            Process process = Runtime.getRuntime().exec(sCmdLine);
        
            setProcess(process);
        
            InputStream  stream  = null;
            String       sPrefix = null;
            int          cAvail  = 0;
            StringBuffer sb      = new StringBuffer();
        
            while (true)
                {
                if (stream != null && (cAvail = stream.available()) > 0)
                    {
                    // proceed
                    }
                else if ((cAvail = process.getInputStream().available()) > 0)
                    {
                    stream  = process.getInputStream();
                    sPrefix = "! ";
                    }
                else if ((cAvail = process.getErrorStream().available()) > 0)
                    {
                    stream  = process.getErrorStream();
                    sPrefix = "? ";
                    }
                else
                    {
                    // check if the process has been terminated
                    try
                        {
                        int iExitCode = process.exitValue();
                        _trace("Test run completed with exit code " + iExitCode);
                        break;
                        }
                    catch (IllegalThreadStateException itse)
                        {
                        // not terminated yet -- go to sleep a bit
                        try
                            {
                            Thread.currentThread().sleep(500);
                            }
                        catch (InterruptedException ie)
                            {
                            _trace("Test run aborted");
                            break;
                            }
                        continue;
                        }
                    }
            
                while (cAvail-- > 0)
                    {
                    int ic = stream.read();
                    if ((char) ic != '\n' && (char) ic != '\r')
                        {
                        sb.append((char) ic);
                        }
        
                    if ((char) ic == '\n' || cAvail == 0)
                        {
                        _trace(sPrefix + sb);
                        sb.setLength(0);
                        }
                    }
                }
            }
        catch (IOException e)
            {
            _trace(e);
            }
        
        setProcess(null);
        setOpen(false);
        }
    
    // Accessor for the property "CommandItem"
    /**
    * Setter for property CommandItem.<p>
    * A command item (in this case a JMenuItem) that a user controls this tool
    * with. Action event on this item causes the TestRun tool to start or stop.
    */
    public void setCommandItem(_package.component.gUI.control.container.jComponent.AbstractButton pCommandItem)
        {
        __m_CommandItem = pCommandItem;
        }
    
    // Accessor for the property "ComponentName"
    /**
    * Setter for property ComponentName.<p>
    * Fully qualified component name to "test run"
    */
    public void setComponentName(String pComponentName)
        {
        __m_ComponentName = pComponentName;
        }
    
    // Accessor for the property "Process"
    /**
    * Setter for property Process.<p>
    * Specifies the process spawned by the TestRun.
    */
    private void setProcess(Process pProcess)
        {
        __m_Process = pProcess;
        }
    }
