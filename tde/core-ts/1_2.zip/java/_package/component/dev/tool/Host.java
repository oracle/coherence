/* Class
*     _package.component.dev.tool.Host
*/

package _package.component.dev.tool;

import _package.component.dev.Tool;
import _package.component.gUI.control.container.jComponent.jPanel.ToolSite;
import _package.component.gUI.control.container.jComponent.jPanel.toolSite.HostSite;
import com.tangosol.run.component.EventDeathException;
import com.tangosol.util.ClassFilter;
import com.tangosol.util.ErrorList;
import com.tangosol.util.FilterEnumerator;
import java.util.Enumeration;
import java.util.Iterator;

public class Host
        extends    _package.component.dev.Tool
    {
    // Fields declarations
    
    /**
    * Property ActiveTool
    *
    */
    private transient _package.component.dev.Tool __m_ActiveTool;
    
    /**
    * Property HostSite
    *
    */
    private transient _package.component.gUI.control.container.jComponent.jPanel.toolSite.HostSite __m_HostSite;
    
    // Default constructor
    public Host()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Host(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Host();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/Host".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.Dev.Tool;
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite;
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.HostSite;
        // import java.util.Enumeration;
        
        

        }
    
    /**
    * Add the specified tool to a list of available tools for this host. This
    * method doesn't neceserally cause the corresponding ToolSite becoming
    * visible at this time; the host may choose just to show the appropriate
    * "tool activation" objects (i.e. menu items)
    * 
    * @see openTool()
    */
    public void addTool(_package.component.dev.Tool tool, String name)
        {
        if (name != null)
            {
            name = name.replace('.', '~');
            }
        
        _addChild(tool, name);
        
        HostSite hs = getHostSite();
        if (hs != null)
            {
            hs.addToolHandle(tool);
            }
        }
    
    /**
    * Close the tool. If the tool itself is a host -- close all the hosted
    * tools as well.
    * 
    * @see Tool#setOpen()
    */
    public void closeTool(_package.component.dev.Tool tool)
        {
        if (tool instanceof Host)
            {
            Host host = (Host) tool;
            for (Enumeration enum = host.enumTools(); enum.hasMoreElements();)
                 {
                 ((Tool) enum.nextElement()).setOpen(false);
                 }
            }
        
        HostSite hs = this.getHostSite();
        ToolSite ts = tool.getToolSite();
        if (hs != null && ts != null)
            {
            hs.closeToolSite(ts);
            }
        }
    
    public java.util.Enumeration enumTools()
        {
        // import com.tangosol.util.ClassFilter;
        // import com.tangosol.util.FilterEnumerator;
        
        return new FilterEnumerator(_enumChildren(), new ClassFilter(Tool.class));

        }
    
    /**
    * Notify all the containing tools (which could in turn notify contained
    * tools) that there has been an action at this host that could be of the
    * interest for any of the contained tools.
    * 
    * @param sName  action name
    * @param oValue  associated value
    */
    public void fireHostAction(String sAction, Object oValue)
        {
        // import com.tangosol.run.component.EventDeathException;
        
        try
            {
            fireHostAction(this, sAction, oValue);
            }
        catch (EventDeathException e)
            {
            }
        }
    
    /**
    * Notify all the containing tools (which could in turn notify contained
    * tools) that there has been an action at this (or a higher level) host
    * that could be of the interest for any of the contained tools.
    * 
    * @param host  host that has originated this action
    * @param sAction  action name
    * @param oValue  associated value
    */
    protected void fireHostAction(Host host, String sAction, Object oValue)
        {
        for (Enumeration enum = enumTools(); enum.hasMoreElements();)
             {
             ((Tool) enum.nextElement()).onHostAction(host, sAction, oValue);
             }
        }
    
    // Declared at the super level
    /**
    * Notify the host (which could in turn notify a containing host) that there
    * has been an action at this tool that could be of the interest for any of
    * the containing hosts.
    * 
    * @param sName  action name
    * @param oValue  associated value
    * 
    * @see onToolAction
    */
    public void fireToolAction(String sAction, Object oValue)
        {
        // This ToolAction is fired at the host itself --
        // try to process at this host level first
        onToolAction(this, sAction, oValue);
        }
    
    // Declared at the super level
    /**
    * Notify the host (which could in turn notify a containing host) that there
    * has been an action at the specified tool that could be of the interest
    * for any of the containing hosts.
    * 
    * @param tool  tool that has originated this action
    * @param sName  action name
    * @param oValue  associated value
    * 
    * @see onToolAction
    */
    protected void fireToolAction(_package.component.dev.Tool tool, String sAction, Object oValue)
        {
        Host host = getHost();
        if (host == null)
            {
            // reflect the action down to tools as a host action
            fireHostAction(this, sAction, oValue);
            }
        else
            {
            super.fireToolAction(tool, sAction, oValue);
            }
        }
    
    // Accessor for the property "ActiveTool"
    public _package.component.dev.Tool getActiveTool()
        {
        ToolSite site = getHostSite().getActiveToolSite();
        return site != null ? site.getTool() : null;
        }
    
    // Accessor for the property "HostSite"
    public _package.component.gUI.control.container.jComponent.jPanel.toolSite.HostSite getHostSite()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.HostSite;
        
        HostSite site = __m_HostSite;
        if (site == null)
            {
            // quite often the tool site for a host is the host site as well
            if (getToolSite() instanceof HostSite)
                {
                site = (HostSite) getToolSite();
                setHostSite(site);
                }
            }
        return site;
        }
    
    /**
    * Find a tool with a given name
    */
    public _package.component.dev.Tool getTool(String name)
        {
        return (Tool) _findChild(name.replace('.', '~'));
        }
    
    // Declared at the super level
    /**
    * Return true if the specified action fired by the specified host is
    * enabled by this tool; false otherwise.
    * The hosts additionally return true if at least one child tool of this
    * host "enables" this action.
    * 
    * This method is mostly used by host sites' menus to provide a visual clue
    * to the question:
    *  - If this host issues a command (host action), will there be any tool
    * being able to process this command
    * 
    * When the host is specified, the specified action is expected to be fired
    * by that host using fireHostAction(). If the host is null, this action is
    * expected to be fired by this tool itself using fireToolAction().
    * 
    * @param sAction  action name
    * @param host  the source of the action
    * @param  oValue an optional value to be passed along
    */
    public boolean isActionEnabled(String sAction, Host host, Object oValue)
        {
        if (super.isActionEnabled(sAction, host, oValue))
            {
            return true;
            }
        
        if (host == null && getHost() == null)
            {
            // the tool action is expected and the topmost host reached
            // re-ask all the tools on behalf of the topmost host
            host = this;
            }
        
        if (host != null)
            {
            for (Enumeration enum = enumTools(); enum.hasMoreElements();)
                {
                if (((Tool) enum.nextElement()).isActionEnabled(sAction, host, oValue))
                    {
                    return true;
                    }
                }
            }
        
        return false;
        }
    
    // Declared at the super level
    /**
    * Returns true if the close operation should be canceled. The assumption
    * is, however, that a tool that does cancel the close operation bears
    * responsibility to notify the user. If a tool sees that some modification
    * could be lost if the close operation is allowed to proceed, but does not
    * want to notify the user on its own, it should  instead override
    * <code>isModified</code> method to return "true".
    * 
    * Default implementation forces the tool site to apply any pending UI
    * changes into the model before returning "false" (allowing the close
    * operation to proceed).
    * 
    * @see #isModified
    */
    public boolean isCloseCanceled()
        {
        for (Enumeration enum = enumTools(); enum.hasMoreElements();)
            {
            Tool tool = (Tool) enum.nextElement();
            if (tool.isCloseCanceled())
                {
                return true;
                }
            }
        return super.isCloseCanceled();
        }
    
    // Declared at the super level
    /**
    * Returns true if this tool knows of any changes that have been made to the
    * [persistable] data maintained by this tool. If a tool overrides this
    * method (which by default returns "false") and returns "true", it is the
    * host's resposibility to make sure that the <code>save</code> method is
    * called (unless the changes have to be discarded). It is then the tool's
    * responsibility to return "false" right after the <code>save</code> method
    * is invoked.
    */
    public boolean isModified()
        {
        for (Enumeration enum = enumTools(); enum.hasMoreElements();)
            {
            Tool tool = (Tool) enum.nextElement();
            if (tool.isModified())
                {
                return true;
                }
            }
        return super.isModified();
        }
    
    // Declared at the super level
    /**
    * Notification send by one of the containing hosts
    * 
    * @param host  the acted host
    * @param sName  action name
    * @param oValue  associated value
    * 
    * @throws EventDeathException if a tool doesn't want this notification be
    * propagated anymore
    */
    public void onHostAction(Host host, String sAction, Object oValue)
        {
        super.onHostAction(host, sAction, oValue);
        
        // re-send the action down to the contained tools
        fireHostAction(host, sAction, oValue);
        }
    
    /**
    * Notification send by one of the contained tools.
    * 
    * @param tool  the acted tool
    * @param sName  action name
    * @param oValue  associated value
    */
    public void onToolAction(_package.component.dev.Tool tool, String sAction, Object oValue)
        {
        // re-send the action up to the containing host
        
        fireToolAction(tool, sAction, oValue);
        }
    
    /**
    * Opens the tool (after it has been added to this host).
    * 
    * @see Tool#setOpen()
    */
    public void openTool(_package.component.dev.Tool tool)
        {
        HostSite hs = this.getHostSite();
        ToolSite ts = tool.getToolSite();
        
        if (hs != null && ts != null)
            {
            hs.openToolSite(ts);
            }

        }
    
    /**
    * Removes the specified tool from the list of available tools for this host.
    */
    public void removeTool(_package.component.dev.Tool tool)
        {
        HostSite hs = getHostSite();
        if (hs != null)
            {
            hs.removeToolHandle(tool);
            }
        _removeChild(tool);
        }
    
    // Declared at the super level
    /**
    * Report the errors out of ErrorList for this tool.
    * 
    * Note: this is just a convinience method that passes the control up to the
    * host.
    */
    public void reportErrors()
        {
        reportErrors(this);
        }
    
    /**
    * Report errors for the specified tool. Usually this method is called by a
    * tool that does not have an ability to report errors on its own. A host
    * that finally reports the errors is expected to clear up the error list.
    * 
    * The default implementation is to go up to the outer host (if there is
    * one) or just output it.
    * 
    * @see Tool#reportErrors()
    */
    public void reportErrors(_package.component.dev.Tool tool)
        {
        // import com.tangosol.util.ErrorList;
        // import java.util.Iterator;
        
        Host host = getHost();
        if (host != null)
            {
            host.reportErrors(tool);
            }
        else
            {
            ErrorList errList = tool.getErrorList();
            if (errList.isEmpty())
                {
                return;
                }
            
            StringBuffer sb = new StringBuffer("*** " + tool);
            for (Iterator iter = errList.iterator(); iter.hasNext();)
                {
                sb.append('\n' + iter.next().toString());
                }
            _trace(sb.toString(), 1);
        
            errList.clear();
            }
        }
    
    // Declared at the super level
    /**
    * Forces the tool site to apply all UI changes and saves the persistent
    * data that this tool (model) knows about.
    * 
    * Note: the attempt should be made to save all the data even when the
    * operation in whole is failing
    * 
    * @return true if data was successfully saved or there is nothing to save;
    * false otherwise
    */
    public boolean save()
        {
        // the order of execution is the same as at isCloseCanceled
        
        boolean fSuccess = true;
        
        for (Enumeration enum = enumTools(); enum.hasMoreElements();)
            {
            Tool tool = (Tool) enum.nextElement();
            fSuccess &= tool.save();
            }
        
        return fSuccess & super.save();
        }
    
    // Accessor for the property "ActiveTool"
    /**
    * Activates the tool (openning it if not opened yet).
    * 
    * @see Tool#setOpen()
    */
    public void setActiveTool(_package.component.dev.Tool pActiveTool)
        {
        if (pActiveTool == null)
            {
            throw new IllegalArgumentException(get_Name() + ".setActiveTool: " +
                "Tool is not specified");
            }
        
        if (!pActiveTool.isOpen())
            {
            pActiveTool.setOpen(true);
            }
        
        HostSite hs = this.getHostSite();
        ToolSite ts = pActiveTool.getToolSite();
        
        if (hs != null && ts != null)
            {
            hs.setActiveToolSite(ts);
            }
        }
    
    // Accessor for the property "HostSite"
    public void setHostSite(_package.component.gUI.control.container.jComponent.jPanel.toolSite.HostSite pHostSite)
        {
        __m_HostSite = (pHostSite);
        pHostSite.setHost(this);
        }
    
    // Declared at the super level
    public String toString()
        {
        return "Host: " + get_Name() + " (host site = " + getHostSite() +
            ", tool site=" + getToolSite() + ')';
        }
    }
