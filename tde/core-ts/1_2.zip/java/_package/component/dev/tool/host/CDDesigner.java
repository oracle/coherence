/* Class
*     _package.component.dev.tool.host.CDDesigner
*/

package _package.component.dev.tool.host;

import _package.component.dev.Design;
import _package.component.dev.Storage;
import _package.component.dev.Tool;
import _package.component.dev.tool.Compiler;
import _package.component.dev.tool.Host;
import _package.component.dev.tool.OutputTool;
import _package.component.dev.tool.host.CDTool;
import _package.component.dev.util.TraitLocator;
import _package.component.dev.util.traitLocator.ComponentLocator;
import _package.component.dev.util.traitLocator.componentLocator.behaviorLocator.ImplementationLocator;
import _package.component.gUI.control.Container;
import _package.component.gUI.control.container.jComponent.AbstractButton;
import _package.component.gUI.control.container.jComponent.jPanel.FindText;
import _package.component.gUI.control.container.jComponent.jPanel.ToolSite;
import _package.component.gUI.control.container.jComponent.jPanel.toolSite.HostSite;
import _package.component.util.Config;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.Implementation;
import com.tangosol.util.ErrorList$Item; // as ErrorInfo
import com.tangosol.util.ErrorList;
import com.tangosol.util.LiteSet;
import java.awt.Cursor;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import javax.swing.JOptionPane;

public class CDDesigner
        extends    _package.component.dev.tool.Host
        implements com.tangosol.dev.component.SubChangeListener,
                   java.beans.PropertyChangeListener
    {
    // Fields declarations
    
    /**
    * Property CDModified
    *
    * Specifies whether the Component Definition designed with this CDDesigner
    * has been modified
    */
    private transient boolean __m_CDModified;
    
    /**
    * Property FilterVisibility
    *
    * This property controls the traits to be shown by various tools based on
    * the value of their Visibility and Existence attributes.
    * 
    * The relevant values are:
    * 
    * VIS_VISIBLE = 0x00000000;
    * VIS_ADVANCED = 0x02000000;
    * VIS_HIDDEN = 0x04000000;
    * VIS_SYSTEM = 0x06000000;
    * 
    * EXISTS_UPDATE = 0x00000000;
    * EXISTS_INSERT = 0x00000002;
    * EXISTS_DELETE = 0x00000004;
    * EXISTS_NOT = 0x00000006;
    */
    private int __m_FilterVisibility;
    
    /**
    * Property GlobalCD
    *
    */
    private transient com.tangosol.dev.component.Component __m_GlobalCD;
    
    /**
    * Property LocalCD
    *
    */
    private transient com.tangosol.dev.component.Component __m_LocalCD;
    
    /**
    * Property OutputTool
    *
    * The OutputTool is known by the CDDesigner.
    */
    
    /**
    * Property RenameRequired
    *
    * This property indicates that the component designed by this CDDesigner
    * tool is a new one (with a temporary synthetic name) and should be renamed
    * at the save time
    */
    private transient boolean __m_RenameRequired;
    
    // Default constructor
    public CDDesigner()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CDDesigner(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFilterVisibility(2);
            setTitle("Component Designer");
            setToolSiteClass(Class.forName("_package/component/gUI/control/container/jComponent/jPanel/toolSite/hostSite/ComponentDesigner".replace('/', '.')));
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CDDesigner();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/host/CDDesigner".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.Dev.Tool;
        // import Component.Dev.Tool.Host;
        // import Component.Dev.Tool.Host.CDTool;
        // import Component.Dev.Storage;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        

        }
    
    /**
    * Compiles the component and (optionally) its dependencies. The component
    * is saved before the compilation itself is started (on a different
    * thread).
    * 
    * @param fDepends specifies whether to recompile the components
    * dependencies
    */
    public void compile(boolean fDepends)
        {
        // import Component.Dev.Tool.Compiler;
        // import Component.Dev.Tool.OutputTool;
        // import Component.GUI.Control.Container.JComponent.AbstractButton;
        // import com.tangosol.util.ErrorList;
        
        Storage   storage  = getStorage();
        Component cd       = null;
        
        Compiler toolCompiler = (Compiler) getTool("Compiler");
        if (toolCompiler == null)
            {
            // currently we must save before the compilation, which
            // could return false if the operation was canceled
            // or (quite unlikely) failed
        
            boolean fRefresh = isRenameRequired() || getGlobalCD().isSignature();
            if (save())
                {
                // since we have just saved, we will reload the component for two reasons
                // - save could have discarded something
                // - for JCSs we have added implementation with the "source"
                //   (see loadComponent(cd)) that would have to be removed
                // as an alternative we could "clone()" and "removeJcsImplementations()"
                // prior to passing a component for the compilation
        
                ErrorList errlist = getErrorList();
                try
                    {
                    cd = storage.loadComponent(
                        getGlobalCD().getQualifiedName(), true, errlist);
                    }
                catch (ComponentException e)
                    {
                    errlist.addException(e);
                    }
        
                if (errlist.isSevere())
                    {
                    cd = null;
                    }
                }
        
            reportErrors();
        
            if (cd == null)
                {
                return;
                }
        
            if (fRefresh)
                {
                refreshBrowser();
                }
        
            toolCompiler = new Compiler();
            addTool(toolCompiler, "Compiler");
        
            OutputTool toolOutput = getOutputTool();
            if (!toolOutput.getToolSite().isShowing())
                {
                toolOutput.setActive(true);
                }
        
            toolCompiler.setCommandItem(
                (AbstractButton) getHostSite()._findName("Build$CompileDepends"));    
            toolCompiler.setStorage(storage);
            toolCompiler.setOutputTool(toolOutput);
            toolCompiler.setComponent(cd);
            toolCompiler.setDependencies(fDepends);
            toolCompiler.setModifiedOnly(true);
        
            // classes are only customized by the TAPS at run-time
            toolCompiler.setStoreResult(cd.isComponent());
            }
        
        // toggle the compiler's state
        toolCompiler.setOpen(!toolCompiler.isOpen());

        }
    
    /**
    * Create a new component that is going to be designed by this tool
    * 
    * @param sSuper  fully qualified name of a super component
    * @param sName  non qualified name for the component to be created
    */
    public void createComponent(String sSuper, String sName)
        {
        // import Component.Dev.Design;
        // import java.awt.Cursor;
        
        Component cd   = null;
        Cursor _cursor = getHostSite().showHourglass();
        
        try
            {
            Storage   storage = getStorage();
            Component cdSuper = storage.loadComponent(sSuper, true, getErrorList());
            if (cdSuper != null)
                {
                cd = cdSuper.createDerivedComponent(sName, storage);
                if (cd != null)
                    {
                    Design.getDesignInfo(cd).initializeComponent(cd);
                    loadComponent(cd);
                    setRenameRequired(true);
                    }
                }
            }
        catch (Exception e)
            {
            getErrorList().addException(e);
            }
        finally
            {
            getHostSite().clearHourglass(_cursor);
            }
        
        if (cd == null)
            {
            Host host = getHost();
        
            host.reportErrors(this);
            host.removeTool(this);
            }
        }
    
    private void dump()
        {
        // import java.io.ByteArrayOutputStream;
        // import java.io.PrintWriter;
        // import java.io.FileOutputStream;
        
        if (true)
            {
            ByteArrayOutputStream  stream = new ByteArrayOutputStream();
            PrintWriter            writer = new PrintWriter(stream);
        
            getGlobalCD().dump(writer, "", false);
            writer.close();
            
            getOutputTool().output("Dump", stream.toString());
            getOutputTool().setActive(true);
            }
        else
            {
            try
                {
                String sPath = "Dump.txt";
        
                FileOutputStream file   = new FileOutputStream(sPath);
                PrintWriter      writer = new PrintWriter(file);
        
                _trace("writing to " + file);
                getGlobalCD().dump(writer, "", true);
        
                writer.close();
                file.close();
                }
            catch (Exception e)
                {
                _trace(e);
                }
            }

        }
    
    private void ensureTools()
        {
        // import Component.Dev.Design;
        // import com.tangosol.util.LiteSet;
        // import java.util.Enumeration;
        
        Design.Component designInfo = (Design.Component) Design.getDesignInfo(getGlobalCD());
        
        LiteSet set = new LiteSet();
        
        // first add the tools that are not there yet
        
        Tool[] aTool = designInfo.getDesignTools();
        for (int i = 0; i < aTool.length; i++)
            {
            Tool tool = aTool[i];
            if (tool != null)
                {
                String sName = tool.getTitle();
                if (getTool(sName) == null)
                    {
                    addTool(tool, sName);
        
                    tool.setOpen(true);
                    }
        
                set.add(sName);
                }
            }
        
        // now close the non-applicable tools
        for (Enumeration enum = enumTools(); enum.hasMoreElements();)
            {
            Tool tool = (Tool) enum.nextElement();
            
            if (!set.contains(tool.getTitle()))
                {
                tool.setOpen(false);
                removeTool(tool);
                }
            }
        }
    
    /**
    * Find a child component by name. The name should be a local name, so we
    * just walk down the children tree.
    */
    private com.tangosol.dev.component.Component findComponent(String sName)
        {
        int    ofChild     = sName.indexOf('$');
        String sGlobalName = ofChild < 0 ? sName : sName.substring(0, ofChild);
        
        Component cd = getGlobalCD();
        if (!sGlobalName.equals(cd.getQualifiedName()))
            {
            return null;
            }
        
        while (ofChild >= 0)
            {
            int    ofNext = sName.indexOf('$', ++ofChild);
            String sChild = ofNext < 0 ?
                sName.substring(ofChild) : sName.substring(ofChild, ofNext);
            cd = cd.getChild(sChild);
            ofChild = ofNext;
            }
        
        return cd;
        }
    
    // Accessor for the property "FilterVisibility"
    /**
    * Getter for property FilterVisibility.<p>
    * This property controls the traits to be shown by various tools based on
    * the value of their Visibility and Existence attributes.
    * 
    * The relevant values are:
    * 
    * VIS_VISIBLE = 0x00000000;
    * VIS_ADVANCED = 0x02000000;
    * VIS_HIDDEN = 0x04000000;
    * VIS_SYSTEM = 0x06000000;
    * 
    * EXISTS_UPDATE = 0x00000000;
    * EXISTS_INSERT = 0x00000002;
    * EXISTS_DELETE = 0x00000004;
    * EXISTS_NOT = 0x00000006;
    */
    public int getFilterVisibility()
        {
        return __m_FilterVisibility;
        }
    
    // Accessor for the property "GlobalCD"
    /**
    * Getter for property GlobalCD.<p>
    */
    public com.tangosol.dev.component.Component getGlobalCD()
        {
        return __m_GlobalCD;
        }
    
    // Accessor for the property "LocalCD"
    /**
    * Getter for property LocalCD.<p>
    */
    public com.tangosol.dev.component.Component getLocalCD()
        {
        return __m_LocalCD;
        }
    
    // Accessor for the property "OutputTool"
    /**
    * Getter for property OutputTool.<p>
    * The OutputTool is known by the CDDesigner.
    */
    public _package.component.dev.tool.OutputTool getOutputTool()
        {
        return (Tool.OutputTool) getTool("Output");
        }
    
    // Declared at the super level
    /**
    * Return true if the specified action fired by the specified host is
    * enabled by this tool; false otherwise.
    * The hosts additionally return true if at least one child tool of this
    * host "enables" this action.
    * 
    * This method is mostly used by host sites' menus to provide a visual clue
    * to the question:
    *  - If this host issues a command (host action), will there be any tool
    * being able to process this command
    * 
    * When the host is specified, the specified action is expected to be fired
    * by that host using fireHostAction(). If the host is null, this action is
    * expected to be fired by this tool itself using fireToolAction().
    * 
    * @param sAction  action name
    * @param host  the source of the action
    * @param  oValue an optional value to be passed along
    */
    public boolean isActionEnabled(String sAction, _package.component.dev.tool.Host host, Object oValue)
        {
        Component cd = getGlobalCD();
        
        if (sAction.equals(ACTION_COMPILE)
         || sAction.equals(ACTION_COMPILE_TREE)
         || sAction.equals(ACTION_SAVE))
            {
            return isActive() && cd != null &&
                (cd.isComponent() || cd.isSignature()) &&
                cd.isModifiable();
            }
        else if (
            sAction.equals(ACTION_SAVE_AS))
            {
            return isActive() && cd != null && cd.isComponent();
            }
        else if (
            sAction.equals(ACTION_SAVE_ALL))
            {
            return true;
            }
        else 
            {
            return super.isActionEnabled(sAction, host, oValue);
            }
        }
    
    // Accessor for the property "CDModified"
    /**
    * Getter for property CDModified.<p>
    * Specifies whether the Component Definition designed with this CDDesigner
    * has been modified
    */
    private boolean isCDModified()
        {
        return __m_CDModified;
        }
    
    // Declared at the super level
    /**
    * Returns true if the close operation should be canceled. The assumption
    * is, however, that a tool that does cancel the close operation bears
    * responsibility to notify the user. If a tool sees that some modification
    * could be lost if the close operation is allowed to proceed, but does not
    * want to notify the user on its own, it should  instead override
    * <code>isModified</code> method to return "true".
    * 
    * Default implementation forces the tool site to apply any pending UI
    * changes into the model before returning "false" (allowing the close
    * operation to proceed).
    * 
    * @see #isModified
    */
    public boolean isCloseCanceled()
        {
        // import javax.swing.JOptionPane;
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite;
        
        // Ask the tools (at which point they will apply the latest UI changes into the model),
        // and check whether the component has to be renamed
        
        if (super.isCloseCanceled())
            {
            return true;
            }
        
        // Now check whether the component has been modified
        
        if (isCDModified())
            {
            // there were modifications, but they could have been undone
            Component cdNow    = getGlobalCD();
            Component cdBefore = null;
        
            try
                {
                cdBefore = getStorage().loadComponent(cdNow.getQualifiedName(), true, null);
                }
            catch (ComponentException e) {}
        
            if (cdNow.equals(cdBefore))
                {
                setCDModified(false);
                }
            }
        
        if (isModified())
            {
            getHost().setActiveTool(this);
        
            Integer intAns = (Integer) getHostSite().msg("Confirm", new Object[]
                {
                "Save changes to Component " + getGlobalCD().getName() + "?",
                ToolSite.MSG_TITLE,
                new Integer(JOptionPane.YES_NO_CANCEL_OPTION),
                });
        
            switch (intAns.intValue())
                {
                case JOptionPane.YES_OPTION:
                    save();
                    // if there are still unsaved changes after the save
                    // it's safer to stay open (assuming the user has been notified)
                    return isModified();
        
                case JOptionPane.NO_OPTION:
                    break;
        
                case JOptionPane.CANCEL_OPTION:
                case JOptionPane.CLOSED_OPTION:
                default:
                    return true;
                }
            }
        
        return false;
        }
    
    // Declared at the super level
    /**
    * Returns true if this tool knows of any changes that have been made to the
    * [persistable] data maintained by this tool. If a tool overrides this
    * method (which by default returns "false") and returns "true", it is the
    * host's resposibility to make sure that the <code>save</code> method is
    * called (unless the changes have to be discarded). It is then the tool's
    * responsibility to return "false" right after the <code>save</code> method
    * is invoked.
    */
    public boolean isModified()
        {
        return isCDModified() || isRenameRequired() || super.isModified();
        }
    
    // Accessor for the property "RenameRequired"
    /**
    * Getter for property RenameRequired.<p>
    * This property indicates that the component designed by this CDDesigner
    * tool is a new one (with a temporary synthetic name) and should be renamed
    * at the save time
    */
    private boolean isRenameRequired()
        {
        return __m_RenameRequired;
        }
    
    /**
    * Load the specified Component Definition into this host
    * 
    * @param cd  the Component Definition to be loaded
    */
    public void loadComponent(com.tangosol.dev.component.Component cd)
        {
        if (cd.isSignature())
            {
            try
                {
                Storage storage = getStorage();
                String  sName   = cd.getName();
        
                cd.addJcsImplementations(
                    storage.loadOriginalClass(sName), storage.loadJava(sName));
                }
            catch (Exception e) {}
            }
        
        // the GlobalCD has to be set before the tool is "open"
        setGlobalCD(cd);
        setOpen(true);
        
        reportErrors();
        }
    
    /**
    * Load a component with the specified name into this host
    * 
    * @param sName qualified name for the component to be loaded
    * @param fReadOnly if true, the coomponent should be open in a "read only"
    * mode
    */
    public void loadComponent(String sName, boolean fReadOnly)
        {
        // import java.awt.Cursor;
        
        Component cd   = null;
        Cursor _cursor = getHostSite().showHourglass();
        
        try
            {
            // load component or signature for modifications
            cd = getStorage().loadComponent(sName, fReadOnly, getErrorList());
            if (cd != null)
                {
                loadComponent(cd);
                }
            }
        catch (Exception e)
            {
            getErrorList().addException(e);
            }
        finally
            {
            getHostSite().clearHourglass(_cursor);
            }
        
        if (cd == null)
            {
            Host host = getHost();
        
            host.reportErrors(this);
            host.removeTool(this);
            }
        else
            {
            reportErrors();
            }
        }
    
    /**
    * Moves the component.  This may either be as simple as renaming it (for
    * global components only) or may require replacing the super component and
    * re-resolving the specified component definition.
    * 
    * @return a new component or null if the operation was rejected or failed
    */
    private com.tangosol.dev.component.Component moveComponent(com.tangosol.dev.component.Component cd)
        {
        // import javax.swing.JOptionPane;
        
        String sOldSuper = cd.getGlobalSuperName();
        String sOldName  = cd.getName();
        String sNewSuper;
        String sNewName;
        
        String sName = sOldName;
        while (true)
            {
            sName = (String) getToolSite().msg("Input", new Object[]
                {
                "Please enter component name",
                "Save As",
                new Integer(JOptionPane.QUESTION_MESSAGE),
                sName,
                });
        
            if (sName == null || sName.length() == 0)
                {
                return null;
                }
        
            int iPos = sName.lastIndexOf('.');
            if (iPos == -1)
                {
                sNewSuper = sOldSuper;
                sNewName  = sName;
                }
            else if (iPos > 0 && iPos + 1 < sName.length())
                {
                sNewSuper = sName.substring(0, iPos);
                sNewName  = sName.substring(iPos + 1);
                }
            else
                {
                sNewSuper = null;
                sNewName  = null;
                }
        
            if (!cd.isNameLegal(sNewName))
                {
                _beep();
                continue;
                }
        
            if (sNewSuper.equals(cd.getQualifiedName()))
                {
                getToolSite().msg("Message", new Object[]
                    {
                    "Cannot save component into a sub-component.\n\nUse derivation instead.",
                    "Save As",
                    new Integer(JOptionPane.ERROR_MESSAGE),
                    });
                continue;
                }
        
            Storage store = getStorage();
        
            // check whether the new name already exists
            try
                {
                // TODO: there should be a simpler call just to get the info
                if (store.loadComponent(sNewSuper + '.' + sNewName, true, null) != null)
                    {
                    Integer intAns = (Integer) getToolSite().msg("Confirm", new Object[]
                        {
                        "Component " + sNewName + " already exists.\n" +
                        "Are you sure to override the existing component?",
                        "Rename Component",
                        new Integer(JOptionPane.YES_NO_OPTION),
                        });
        
                    if (intAns.intValue() != JOptionPane.YES_OPTION)
                        {
                        continue;
                        }
                    }
                }
            catch (ComponentException e) {}
        
            try
                {
                if (cd.isGlobal() && sNewSuper.equals(sOldSuper))
                    {
                    // change "short" name
                    if (!sNewName.equals(sOldName))
                        {
                        cd.setName(sNewName);
                        }
                    }
                else
                    {
                    cd = replaceSuper(cd, sNewSuper);
                    cd.setName(sNewName);
                    }
        
                return cd;
                }
            catch (Exception e)
                {
                String sMsg = e.getMessage();
                getToolSite().msg("Message", new Object[]
                    {
                    sMsg.length() > 0 ? sMsg : e.getClass().getName(),
                    "Save As",
                    new Integer(JOptionPane.ERROR_MESSAGE),
                    });
                continue;
                }
            }
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets closed<p>
    * Note: this method is called before the host is notified with closeTool(),
    * so no relevant host's destruction has been done yet.
    * 
    * @see #setOpen
    * @see Host#closeTool
    */
    public void onClose()
        {
        if (isActive())
            {
            // ask the host site to save this tool configuration as "current"
            getHost().getHostSite().saveConfig(null, "");
            }
        
        super.onClose();
        
        Component cd = getGlobalCD();
        if (cd != null)
            {
            cd.removePropertyChangeListener(this);
            cd.removeSubChangeListener(this);
            }

        }
    
    // Declared at the super level
    /**
    * Notification send by one of the containing hosts
    * 
    * @param host  the acted host
    * @param sName  action name
    * @param oValue  associated value
    * 
    * @throws EventDeathException if a tool doesn't want this notification be
    * propagated anymore
    */
    public void onHostAction(_package.component.dev.tool.Host host, String sAction, Object oValue)
        {
        if (sAction.equals(ACTION_COMPILE))
            {
            if (isActive())
                {
                compile(false);
                }
            }
        else if (sAction.equals(ACTION_COMPILE_TREE))
            {
            if (isActive())
                {
                compile(true);
                }
            }
        else if (sAction.equals(ACTION_SAVE))
            {
            if (isActive())
                {
                save();
                refreshBrowser();
                }
            }
        else if (sAction.equals(ACTION_SAVE_ALL))
            {
            save();
            }
        else if (sAction.equals(ACTION_SAVE_AS))
            {
            if (isActive())
                {
                saveAs();
                refreshBrowser();
                }
            }
        else if (sAction.equals("Dump"))
            {
            if (isActive())
                {
                dump();
                }
            }
        else
            {
            super.onHostAction(host, sAction, oValue);
            }
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets opened.<p>
    * Note: this method is called after the host is notified with openTool(),
    * so all the relevant host's initialization is already done.
    * 
    * @see #setOpen
    * @see Host#openTool
    */
    public void onOpen()
        {
        // import Component.GUI.Control.Container;
        // import Component.Util.Config;
        
        ensureTools();
        
        // our tool site has already been added but has not become active yet
        // unless it's the very first one
        Tool toolActive = getHost().getActiveTool();
        _assert(toolActive != null);
        
        // restoring the geometry of children sometimes requires
        // that their parent is already validated (see JInternalFrame#applyConfig)
        getHost().getHostSite().validate();
        
        if (toolActive != this) // !isActive()
            {
            Config cfg = new Config();
            toolActive.getToolSite().saveConfig(cfg, "");
            getToolSite().applyConfig(cfg, "");
            }
        else
            {
            // ask the host site to config the active tool site
            // according to previously persisted data
            // (see Component.Dev.Tool.Host.TAPS$Docs#applyConfig)
            getHost().getHostSite().applyConfig(null, "");
            }
        
        // the OutputTool should be known by the CDDesigner
        // (see reportErrors() method)
        // but we never want it to appear initially -- only as needed
        Tool toolOutput = getTool("Output");
        _assert(toolOutput != null, "Output tool must be specified as a basic tool");
        ((Container) toolOutput.getToolSite().get_Parent()).setVisible(false);
        
        super.onOpen();
        }
    
    // Declared at the super level
    /**
    * Notification send by one of the contained tools.
    * 
    * @param tool  the acted tool
    * @param sName  action name
    * @param oValue  associated value
    */
    public void onToolAction(_package.component.dev.Tool tool, String sAction, Object oValue)
        {
        // import Component.Dev.Util.TraitLocator.ComponentLocator;
        // import Component.Util.Config;
        
        if (sAction.equals(ACTION_LOCATE_TRAIT))
            {
            if (oValue instanceof ComponentLocator)
                {
                Component cd = findComponent(((ComponentLocator) oValue).getComponentName());
                if (cd != null)
                    {
                    setLocalCD(cd);
        
                    // re-send down to the tool that could do more precise job
                    fireHostAction(ACTION_LOCATE_TRAIT, oValue);
                    }
                }
            else
                {
                // let it go ...
                super.onToolAction(tool, sAction, oValue);
                }
            }
        else if (
            sAction.equals(ACTION_SEARCH))
            {
            if (oValue instanceof Config)
                {
                Config  config   = (Config) oValue;
        
                String  sPattern  = config.getString(".Pattern");
                boolean fCaseSens = config.getBoolean(".Case");
                boolean fWords    = config.getBoolean(".Words");
                boolean fRegExpr  = config.getBoolean(".RegExp");
        
                reportSearchResult(sPattern, fWords, fCaseSens, fRegExpr);
                }
            }
        else
            {
            super.onToolAction(tool, sAction, oValue);
            }
        }
    
    /**
    * Perform the search placing the results into the specified list
    */
    private void performSearch(com.tangosol.dev.component.Component cd, String sPattern, boolean fWord, boolean fCaseSens, boolean fRegExpr, java.util.List listResults)
        {
        // import Component.Dev.Util.TraitLocator.ComponentLocator.BehaviorLocator.ImplementationLocator;
        // import Component.GUI.Control.Container.JComponent.JPanel.FindText;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Implementation;
        // import java.util.Enumeration;
        
        for (Enumeration enum = cd.getBehaviors(); enum.hasMoreElements();)
            {
            Behavior bhvr = (Behavior) enum.nextElement();
        
            // we can search through all the implementations
            //      bhvr.getImplementationCount();
            // but that requires moving "locateImplementation()" method
            // from CDScript.Editor up to CDScript
        
            int cImpls = bhvr.getModifiableImplementationCount();
            for (int iImpl = 0; iImpl < cImpls; iImpl++)
                {
                Implementation impl = (Implementation) bhvr.getImplementation(iImpl);
        
                String sScript    = impl.getScript();
                int    cchPattern = sPattern.length();
        
                int ofStart = 0;
                while (true)
                    {
                    int ofHit = FindText.findMatch(sScript, sPattern,
                        ofStart, fCaseSens, fRegExpr, fWord, FindText.DIRECTION_DOWN);
                    if (ofHit < ofStart)
                        {
                        break;
                        }
        
                    int    nLine  = 0;
                    int    ofLine = 0;
                    char[] ach   = sScript.toCharArray();
                    for (int of = 0; of < ofHit; of++)
                        {
                        if (ach[of] == '\n')
                            {
                            nLine++;
                            ofLine = of + 1;
                            }
                        }
                    int ofLineNext = sScript.indexOf('\n', ofLine);
                    if (ofLineNext == -1)
                        {
                        ofLineNext = ach.length;
                        }
        
                    ImplementationLocator locator = ImplementationLocator.newImplementationLocator(impl);
                    locator.setLine(nLine);
                    locator.setOffset(ofHit - ofLine);
                    locator.setLength(cchPattern);
                    locator.setDescription(sScript.substring(ofLine, ofLineNext));
        
                    listResults.add(locator);
        
                    ofStart = ofHit + cchPattern;
                    }
                }
            }
        
        String[] asChild = cd.getChildren();
        for (int i = 0, c = asChild.length; i < c; i++)
            {
            Component cdChild = cd.getChild(asChild[i]);
            if (cdChild != null)
                {
                performSearch(cdChild, sPattern, fWord, fCaseSens, fRegExpr, listResults);
                }
            }
        }
    
    // From interface: java.beans.PropertyChangeListener
    public void propertyChange(java.beans.PropertyChangeEvent evt)
        {
        // something has changed
        setCDModified(true);
        
        String sAttrib = evt.getPropertyName();
        if (sAttrib.equals(Component.ATTR_NAME))
            {
            updateHostSiteTitle();
            }
        }
    
    private void refreshBrowser()
        {
        if (getGlobalCD().isComponent())
            {
            fireToolAction(ACTION_REFRESH, "Components");
            }
        else
            {
            fireToolAction(ACTION_REFRESH, "Classes");
            fireToolAction(ACTION_REFRESH, "Libraries");
            }

        }
    
    /**
    * Replace the super component of the specified component
    * 
    * @return a new component
    * 
    * @exception ComponentException is thrown if an unrecoverable error occurs
    */
    private com.tangosol.dev.component.Component replaceSuper(com.tangosol.dev.component.Component cd, String sSuper)
            throws com.tangosol.dev.component.ComponentException
        {
        // import com.tangosol.util.ErrorList;
        // import javax.swing.JOptionPane;
        
        _assert(sSuper != null);
        
        Storage   store   = getStorage();
        ErrorList errlist = getErrorList();
        
        try
            {
            Component cdNewSuper = store.loadComponent(sSuper, true, errlist);
            if (cdNewSuper == null)
                {
                throw new ComponentException("Super component " + sSuper + " doesn't exist.");
                }
        
            Component cdOldSuper = store.loadComponent(cd.getGlobalSuperName(), true, errlist);
        
            cd = cd.extract(cdOldSuper, store, errlist);
            cd.finalizeExtract(store, errlist);
        
            cd = cdNewSuper.resolve(cd, store, errlist);
            cd.finalizeResolve(store, errlist);
        
            return cd;
            }
        catch (ComponentException e)
            {
            errlist.addException(e);
            throw e;
            }
        finally
            {
            reportErrors();
            }
        }
    
    private void reportCompilationErrors()
        {
        // import Component.Dev.Tool.OutputTool;
        // import Component.Dev.Util.TraitLocator;
        // import com.tangosol.util.ErrorList;
        // import com.tangosol.util.ErrorList$Item as ErrorInfo;
        // import java.util.Iterator;
        
        ErrorList errList = getErrorList();
        int       cErrors = errList.size();
        if (cErrors != 0)
            {
            Object[] aoError = new Object[cErrors];
            Iterator iter    = errList.iterator();
            for (int i = 0; iter.hasNext(); i++)
                {
                ErrorInfo error   = (ErrorInfo) iter.next();
                Object    locator = error.getLocator();
        
                aoError[i] = locator instanceof TraitLocator ? locator : error;
                }
            errList.clear();
        
            OutputTool toolOutput = getOutputTool();
            String     sOutTitle  = "Compile";
        
            toolOutput.setActive(true);
            toolOutput.output(sOutTitle, aoError);
            _beep();
            }

        }
    
    // Declared at the super level
    /**
    * Report errors for the specified tool. Usually this method is called by a
    * tool that does not have an ability to report errors on its own
    * 
    * The default implementation is to go up to the outer host (if there is
    * one) or just output it.
    * 
    * @see Tool#reportErrors()
    */
    public void reportErrors(_package.component.dev.Tool tool)
        {
        // import com.tangosol.util.ErrorList;
        // import com.tangosol.util.ErrorList$Item as ErrorInfo;
        // import java.util.Iterator;
        
        ErrorList errList = tool.getErrorList();
        if (errList.isEmpty())
            {
            return;
            }
        
        StringBuffer sb = new StringBuffer();
        for (Iterator iter = errList.iterator(); iter.hasNext();)
            {
            sb.append(iter.next().toString() + '\n');
            }
        
        getOutputTool().setActive(true);
        getOutputTool().output(tool.getTitle(), sb.toString());
        
        errList.clear();
        }
    
    /**
    * Perform the search and report the results
    */
    private void reportSearchResult(String sPattern, boolean fWord, boolean fCaseSens, boolean fRegExpr)
        {
        // import Component.Dev.Tool.OutputTool;
        // import java.util.Iterator;
        // import java.util.ArrayList;
        
        OutputTool toolOutput = getOutputTool();
        String     sOutTitle  = "Find";
        
        toolOutput.setActive(true);
        toolOutput.clearOutput(sOutTitle);
        toolOutput.output(sOutTitle, new Object[]
            {"Searching for '" + sPattern + "'..."});
        
        ArrayList list = new ArrayList();
        
        performSearch(getGlobalCD(), sPattern, fWord, fCaseSens, fRegExpr, list);
        
        if (list.isEmpty())
            {
            toolOutput.output(sOutTitle, "Cannot find the string '" + sPattern + "'");
            }
        else
            {
            toolOutput.output(sOutTitle, list.toArray());
            toolOutput.output(sOutTitle, list.size() + " occurence(s) have been found");
            }
        }
    
    // Declared at the super level
    /**
    * Forces the tool site to apply all UI changes and saves the persistent
    * data that this tool (model) knows about.
    * 
    * Note: the attempt should be made to save all the data even when the
    * operation in whole is failing
    * 
    * @return true if data was successfully saved or there is nothing to save;
    * false otherwise
    * 
    * +++++++++++++++++++++++
    * 
    * If  the "RenameRequired" property is set CDDesiner has to rename the
    * component first.
    */
    public boolean save()
        {
        boolean fSuccess = super.save();
        
        if (isRenameRequired())
            {
            Component cdOld = getGlobalCD();
            Component cdNew = moveComponent(cdOld);
            if (cdNew == null)
                {
                // operation failed
                return false;
                }
        
            setRenameRequired(false);
            setGlobalCD(cdNew);
            }
        
        fSuccess &= storeComponent(getGlobalCD());
        
        if (fSuccess)
            {
            setCDModified(false);
            }
        return fSuccess;
        }
    
    private void saveAs()
        {
        if (isRenameRequired())
            {
            save();
            }
        else
            {
            setRenameRequired(true);
            save();
            setRenameRequired(false);
            updateHostSiteTitle();
            }

        }
    
    /**
    * Saves the specified component as a global one.
    */
    public void saveGlobalComponent(com.tangosol.dev.component.Component cd)
        {
        Component cdGlobal = moveComponent(cd);
        if (cdGlobal != null)
            {
            // reset "static" attribute; it should be set explicitly
            try
                {
                if (cdGlobal.isStatic())
                    {
                    cdGlobal.setStatic(false);
                    }
                }
            catch (Exception e) {}
        
            storeComponent(cdGlobal);
            refreshBrowser();
            }
        }
    
    // Accessor for the property "CDModified"
    /**
    * Setter for property CDModified.<p>
    * Specifies whether the Component Definition designed with this CDDesigner
    * has been modified
    */
    private void setCDModified(boolean pCDModified)
        {
        if (pCDModified == isCDModified())
            {
            return;
            }
        
        __m_CDModified = (pCDModified);
        
        updateHostSiteTitle();
        }
    
    // Accessor for the property "FilterVisibility"
    /**
    * Setter for property FilterVisibility.<p>
    * This property controls the traits to be shown by various tools based on
    * the value of their Visibility and Existence attributes.
    * 
    * The relevant values are:
    * 
    * VIS_VISIBLE = 0x00000000;
    * VIS_ADVANCED = 0x02000000;
    * VIS_HIDDEN = 0x04000000;
    * VIS_SYSTEM = 0x06000000;
    * 
    * EXISTS_UPDATE = 0x00000000;
    * EXISTS_INSERT = 0x00000002;
    * EXISTS_DELETE = 0x00000004;
    * EXISTS_NOT = 0x00000006;
    */
    public void setFilterVisibility(int pFilterVisibility)
        {
        // import java.util.Enumeration;
        
        if (pFilterVisibility == getFilterVisibility())
            {
            return;
            }
        
        __m_FilterVisibility = (pFilterVisibility);
        
        for (Enumeration enum = enumTools(); enum.hasMoreElements();)
            {
            Tool tool = (Tool) enum.nextElement();
            if (tool.isOpen() && tool instanceof CDTool)
                {
                ((CDTool) tool).onFilterChanged();
                }
            }
        }
    
    // Accessor for the property "GlobalCD"
    /**
    * Setter for property GlobalCD.<p>
    */
    public void setGlobalCD(com.tangosol.dev.component.Component pGlobalCD)
        {
        // import java.util.Enumeration;
        
        Component cdOld = getGlobalCD();
        
        if (cdOld == pGlobalCD)
            {
            return;
            }
        
        if (cdOld != null)
            {
            cdOld.removePropertyChangeListener(this);
            cdOld.removeSubChangeListener(this);
            }
        
        __m_GlobalCD = (pGlobalCD);
        
        pGlobalCD.addPropertyChangeListener(this);
        pGlobalCD.addSubChangeListener(this);
        
        updateHostSiteTitle();
        
        if (isOpen())
            {
            ensureTools();
        
            // notify the tools
            for (Enumeration enum = enumTools(); enum.hasMoreElements();)
                {
                Tool tool = (Tool) enum.nextElement();
                if (tool instanceof CDTool)
                    {
                    ((CDTool) tool).onGlobalCDChanged(cdOld);
                    }
                }
            }
        
        // reset local CD
        setLocalCD(pGlobalCD);
        }
    
    // Accessor for the property "LocalCD"
    /**
    * Setter for property LocalCD.<p>
    */
    public void setLocalCD(com.tangosol.dev.component.Component pLocalCD)
        {
        // import java.util.Enumeration;
        
        Component cdOld = getLocalCD();
        
        __m_LocalCD = (pLocalCD);
        
        for (Enumeration enum = enumTools(); enum.hasMoreElements();)
            {
            Tool tool = (Tool) enum.nextElement();
            if (tool instanceof CDTool)
                {
                ((CDTool) tool).onLocalCDChanged(cdOld);
                }
            }

        }
    
    // Accessor for the property "RenameRequired"
    /**
    * Setter for property RenameRequired.<p>
    * This property indicates that the component designed by this CDDesigner
    * tool is a new one (with a temporary synthetic name) and should be renamed
    * at the save time
    */
    private void setRenameRequired(boolean pRenameRequired)
        {
        __m_RenameRequired = pRenameRequired;
        }
    
    /**
    * Stores the specified component into the storage
    * 
    * @return false if an unrecoverable error has been encountered
    */
    private boolean storeComponent(com.tangosol.dev.component.Component cd)
        {
        // import java.awt.Cursor;
        
        Cursor _cursor = getHostSite().showHourglass();
        
        try
            {
            getStorage().storeComponent(cd, getErrorList());
            }
        catch (ComponentException e)
            {
            getErrorList().addException(e);
            }
        finally
            {
            getHostSite().clearHourglass(_cursor);
            }
        
        reportErrors(); // may contain fatal errors or warnings
        
        return !getErrorList().isSevere();
        }
    
    // From interface: com.tangosol.dev.component.SubChangeListener
    public void subChange(com.tangosol.dev.component.SubChangeEvent evtSub)
        {
        // something has changed
        setCDModified(true);
        }
    
    // Declared at the super level
    public String toString()
        {
        return "CDDesigner: " + getTitle() + " (" + getGlobalCD() + ')';
        }
    
    private void updateHostSiteTitle()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.HostSite;
        
        HostSite site = getHostSite();
        if (site != null)
            {
            Component cd     = getGlobalCD();
            String    sTitle = cd.getName();
        
            // for JCSs show just the short name
            sTitle = sTitle.substring(sTitle.lastIndexOf('.') + 1);
        
            if (!cd.isModifiable())
                {
                sTitle += " (R)";
                }
            else if (isModified())
                {
                sTitle += "*";
                }
            site.setTitle(sTitle);
            site.setToolTipText(cd.getQualifiedName());
            }
        }
    }
