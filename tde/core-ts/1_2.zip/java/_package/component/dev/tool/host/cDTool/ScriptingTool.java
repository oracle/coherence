/* Class
*     _package.component.dev.tool.host.cDTool.ScriptingTool
*/

package _package.component.dev.tool.host.cDTool;

import _package.component.dev.util.traitLocator.componentLocator.BehaviorLocator;
import _package.component.gUI.control.container.jComponent.jPanel.toolSite.ScriptEditor;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.Constants;
import com.tangosol.dev.component.Implementation;
import com.tangosol.dev.component.Integration;
import com.tangosol.dev.component.Interface;
import com.tangosol.dev.component.Parameter;
import com.tangosol.dev.component.Property;
import com.tangosol.dev.component.ReturnValue;
import com.tangosol.dev.component.SubChangeEvent;
import com.tangosol.dev.component.Trait;
import java.beans.PropertyChangeEvent;

public class ScriptingTool
        extends    _package.component.dev.tool.host.CDTool
        implements com.tangosol.dev.component.SubChangeListener,
                   java.beans.PropertyChangeListener
    {
    // Fields declarations
    
    // Default constructor
    public ScriptingTool()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ScriptingTool(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(20.0F);
            setTitle("Script Editor");
            setToolSiteClass(Class.forName("_package/component/gUI/control/container/jComponent/jPanel/toolSite/ScriptEditor".replace('/', '.')));
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ScriptingTool();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/host/cDTool/ScriptingTool".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    public boolean isBehaviorShowing(com.tangosol.dev.component.Behavior bhvr)
        {
        // import com.tangosol.dev.component.Constants;
        
        int     nVisibility = getCDDesigner().getFilterVisibility();
        boolean fShow;
        
        switch (nVisibility & Constants.VIS_MASK)
            {
            default:
            case Constants.VIS_VISIBLE:
                fShow = bhvr.getVisible() == Constants.VIS_VISIBLE;
                break;
            case Constants.VIS_ADVANCED:
                fShow = bhvr.getVisible() == Constants.VIS_VISIBLE ||
                       bhvr.getVisible() == Constants.VIS_ADVANCED;
                break;
            case Constants.VIS_HIDDEN:
                fShow = bhvr.getVisible() != Constants.VIS_SYSTEM;
                break;
            case Constants.VIS_SYSTEM:
                fShow = true;
                break;
            }
        
        // "View-Declared" option is represented as EXISTS_INSERT bit.
        if (!fShow && (nVisibility & Constants.EXISTS_INSERT) != 0)
            {
            // When "View-Declared" option is on, show declared at this level,
            // scripted or abstract behaviors regardless of their visibility
            if (bhvr.isDeclaredAtThisLevel()                ||
                bhvr.getModifiableImplementationCount() > 0 ||
                bhvr.isAbstract())
                {
                return true;
                }
            }
        
        return fShow;
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets closed<p>
    * Note: this method is called before the host is notified with closeTool(),
    * so no relevant host's destruction has been done yet.
    * 
    * @see #setOpen
    * @see Host#closeTool
    */
    public void onClose()
        {
        // import com.tangosol.dev.component.Component;
        
        super.onClose();
        
        Component cd = getLocalCD();
        if (cd != null)
            {
            cd.removePropertyChangeListener(this);
            cd.removeSubChangeListener(this);
            }
        }
    
    // Declared at the super level
    /**
    * Notification from the CDDesigner host that the trait filter has changed
    * 
    * @see CDDesigner#setFilterVisibility()
    */
    public void onFilterChanged()
        {
        super.onFilterChanged();
        
        getToolSite().load(true);
        }
    
    // Declared at the super level
    /**
    * Notification send by one of the containing hosts
    * 
    * @param host  the acted host
    * @param sName  action name
    * @param oValue  associated value
    * 
    * @throws EventDeathException if a tool doesn't want this notification be
    * propagated anymore
    */
    public void onHostAction(_package.component.dev.tool.Host host, String sAction, Object oValue)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.ScriptEditor;
        // import Component.Dev.Util.TraitLocator.ComponentLocator.BehaviorLocator;
        
        if (sAction.equals(ACTION_LOCATE_TRAIT))
            {
            if (oValue instanceof BehaviorLocator)
                {
                ((ScriptEditor) getToolSite()).locateBehavior((BehaviorLocator) oValue);
                }
            }
        super.onHostAction(host, sAction, oValue);

        }
    
    // Declared at the super level
    /**
    * Notification from the CDDesigner host that the local CD has changed
    * 
    * @see CDDesigner#setLocalCD()
    */
    public void onLocalCDChanged(com.tangosol.dev.component.Component cdOld)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.ScriptEditor;
        // import com.tangosol.dev.component.Component;
        
        super.onLocalCDChanged(cdOld);
        
        Component cdNew = getLocalCD();
        
        if (cdOld == cdNew)
            {
            return;
            }
        
        if (cdOld != null)
            {
            cdOld.removePropertyChangeListener(this);
            cdOld.removeSubChangeListener(this);
            }
        
        ScriptEditor toolSite = (ScriptEditor) getToolSite();
        toolSite.setLocalCD(cdNew);
        
        if (cdNew != null)
            {
            cdNew.addPropertyChangeListener(this);
            cdNew.addSubChangeListener(this);
            }
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets opened.<p>
    * Note: this method is called after the host is notified with openTool(),
    * so all the relevant host's initialization is already done.
    * 
    * @see #setOpen
    * @see Host#openTool
    */
    public void onOpen()
        {
        super.onOpen();
        
        onLocalCDChanged(null);

        }
    
    // From interface: java.beans.PropertyChangeListener
    public void propertyChange(java.beans.PropertyChangeEvent evt)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.ScriptEditor;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Integration;
        // import com.tangosol.dev.component.Interface;
        
        ScriptEditor toolSite = (ScriptEditor) getToolSite();
        String       sAttrib  = evt.getPropertyName();
        
        if      (sAttrib.equals(Component.ATTR_INTEGRATION))
            {
            Integration mapNew = (Integration) evt.getNewValue();
            Integration mapOld = (Integration) evt.getOldValue();
            if (mapOld != null)
                {
                toolSite.onIntegrationRemoved(mapOld);
                }
            if (mapNew != null)
                {
                toolSite.onIntegrationAdded(mapNew);
                }
            }
        else if (sAttrib.equals(Component.ATTR_DISPATCHES)  ||
                 sAttrib.equals(Component.ATTR_IMPLEMENTS))
            {
            Interface ifaceNew = (Interface) evt.getNewValue();
            Interface ifaceOld = (Interface) evt.getOldValue();
            if (ifaceOld != null)
                {
                toolSite.onInterfaceRemoved(ifaceOld);
                }
            if (ifaceNew != null)
                {
                toolSite.onInterfaceAdded(ifaceNew);
                }
            }
        else if (sAttrib.equals(Component.ATTR_NAME))
            {
            toolSite.setLocalCD(getLocalCD()); // update call
            }
        }
    
    // From interface: com.tangosol.dev.component.SubChangeListener
    public void subChange(com.tangosol.dev.component.SubChangeEvent evtSub)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.ScriptEditor;
        // import com.tangosol.dev.component.Trait;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Implementation;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.Parameter;
        // import com.tangosol.dev.component.ReturnValue;
        // import com.tangosol.dev.component.SubChangeEvent;
        // import java.beans.PropertyChangeEvent;
        
        Trait trait = evtSub.getSubTrait();
        
        if (trait.getParentComponent() != getLocalCD())
            {
            return;
            }
        
        ScriptEditor toolSite = (ScriptEditor) getToolSite();
        
        switch (evtSub.getAction())
            {
            case SubChangeEvent.SUB_CHANGE:
                PropertyChangeEvent evtChange  = (PropertyChangeEvent) evtSub.getEvent();
                String              sAttribute = evtChange.getPropertyName();
                Object              oOldValue  = evtChange.getOldValue();
        
                if (trait instanceof Behavior)
                    {
                    toolSite.onBehaviorModified((Behavior) trait, sAttribute, oOldValue);
                    }
                else if (trait instanceof Parameter)
                    {
                    toolSite.onBehaviorModified(((Parameter) trait).getBehavior(),
                        Behavior.ATTR_PARAMETER, null);
                    }
                else if (trait instanceof ReturnValue)
                    {
                    toolSite.onBehaviorModified(((ReturnValue) trait).getBehavior(),
                        "ReturnValue", null);
                    }
                else if (trait instanceof Property)
                    {
                    toolSite.onPropertyModified((Property) trait,
                        sAttribute, oOldValue);
                    }
                break;
        
            case SubChangeEvent.SUB_UNREMOVE:
            case SubChangeEvent.SUB_ADD:
                if (trait instanceof Behavior)
                    {
                    Behavior bhvr = (Behavior) trait;
                    if (isBehaviorShowing(bhvr))
                        {
                        toolSite.onBehaviorAdded(bhvr);
                        }
                    }
                else if (trait instanceof Property)
                    {
                    toolSite.onPropertyAdded((Property) trait);
                    }
                else if (trait instanceof Implementation)
                    {
                    toolSite.onImplementationAdded((Implementation) trait);
                    toolSite.onBehaviorModified(((Implementation) trait).getBehavior(),
                        Behavior.ATTR_IMPLEMENTATION, null);
                    }
                else if (trait instanceof Parameter)
                    {
                    toolSite.onBehaviorModified(((Parameter) trait).getBehavior(),
                        Behavior.ATTR_PARAMETER, null);
                    }
                break;
        
            case SubChangeEvent.SUB_REMOVE:
                if (trait instanceof Behavior)
                    {
                    toolSite.onBehaviorRemoved((Behavior) trait);
                    }
                else if (trait instanceof Property)
                    {
                    toolSite.onPropertyRemoved((Property) trait);
                    }
                else if (trait instanceof Implementation)
                    {
                    toolSite.onImplementationRemoved((Implementation) trait);
                    toolSite.onBehaviorModified(((Implementation) trait).getBehavior(),
                        Behavior.ATTR_IMPLEMENTATION, trait);
                    }
               else if (trait instanceof Parameter)
                    {
                    toolSite.onBehaviorModified(((Parameter) trait).getBehavior(),
                        Behavior.ATTR_PARAMETER, trait);
                    }
                break;
            }
        }
    }
