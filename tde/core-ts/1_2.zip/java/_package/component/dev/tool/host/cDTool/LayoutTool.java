/* Class
*     _package.component.dev.tool.host.cDTool.LayoutTool
*/

package _package.component.dev.tool.host.cDTool;

import _package.component.gUI.control.container.jComponent.jPanel.toolSite.LayoutDesigner;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.Implementation;
import com.tangosol.dev.component.Property;
import com.tangosol.dev.component.SubChangeEvent;
import com.tangosol.dev.component.Trait;
import java.beans.PropertyChangeEvent;

public class LayoutTool
        extends    _package.component.dev.tool.host.CDTool
        implements com.tangosol.dev.component.SubChangeListener,
                   java.beans.PropertyChangeListener
    {
    // Fields declarations
    
    // Default constructor
    public LayoutTool()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public LayoutTool(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(40.0F);
            setTitle("Layout Designer");
            setToolSiteClass(Class.forName("_package/component/gUI/control/container/jComponent/jPanel/toolSite/LayoutDesigner".replace('/', '.')));
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new LayoutTool();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/host/cDTool/LayoutTool".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets closed<p>
    * Note: this method is called before the host is notified with closeTool(),
    * so no relevant host's destruction has been done yet.
    * 
    * @see #setOpen
    * @see Host#closeTool
    */
    public void onClose()
        {
        super.onClose();
        
        getGlobalCD().removePropertyChangeListener(this);
        getGlobalCD().removeSubChangeListener(this);
        }
    
    // Declared at the super level
    /**
    * Notification from the CDDesigner host that the global CD has changed
    * 
    * This could happen only in the case when renaming a component causes the
    * Component Definition reference to change
    * 
    * @see CDDesigner#renameComponent()
    * @see CDDesigner#setGlobalCD()
    */
    public void onGlobalCDChanged(com.tangosol.dev.component.Component cdOld)
        {
        // import com.tangosol.dev.component.Component;
        
        super.onGlobalCDChanged(cdOld);
        
        Component cdNew = getGlobalCD();
        
        if (!isOpen() || cdOld == cdNew)
            {
            return;
            }
        
        if (cdOld != null)
            {
            cdOld.removePropertyChangeListener(this);
            cdOld.removeSubChangeListener(this);
            }
        
        getToolSite().load(false);
        
        cdNew.addPropertyChangeListener(this);
        cdNew.addSubChangeListener(this);
        }
    
    // Declared at the super level
    /**
    * Notification from the CDDesigner host that the local CD has changed
    * 
    * @see CDDesigner#setLocalCD()
    */
    public void onLocalCDChanged(com.tangosol.dev.component.Component cdOld)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.LayoutDesigner;
        
        super.onLocalCDChanged(cdOld);
        
        if (isOpen())
            {
            ((LayoutDesigner) getToolSite()).setComponent(getLocalCD());
            }
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets opened.<p>
    * Note: this method is called after the host is notified with openTool(),
    * so all the relevant host's initialization is already done.
    * 
    * @see #setOpen
    * @see Host#openTool
    */
    public void onOpen()
        {
        super.onOpen();
        
        onGlobalCDChanged(null);
        onLocalCDChanged(null);
        }
    
    // From interface: java.beans.PropertyChangeListener
    public void propertyChange(java.beans.PropertyChangeEvent evt)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.LayoutDesigner;
        
        LayoutDesigner toolSite = (LayoutDesigner) getToolSite();
        String         sAttrib  = evt.getPropertyName();
        
        toolSite.onComponentModified(getGlobalCD(), sAttrib, evt.getOldValue());
        }
    
    // From interface: com.tangosol.dev.component.SubChangeListener
    public void subChange(com.tangosol.dev.component.SubChangeEvent evt)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.LayoutDesigner;
        // import com.tangosol.dev.component.Trait;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Implementation;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.SubChangeEvent;
        // import java.beans.PropertyChangeEvent;
        
        LayoutDesigner toolSite = (LayoutDesigner) getToolSite();
        
        Trait trait = evt.getSubTrait();
        
        if (!(trait instanceof Component))
            {
            // we need to track a change that would cause
            // a visual change to the component's presentation in the tool
            // (such as adding an implementation or changing the property value)
            if (trait instanceof Implementation)
                {
                toolSite.onComponentModified(((Implementation) trait).getBehavior().getComponent(), "", null);
                }
            else if (trait instanceof Property)
                {
                toolSite.onComponentModified(((Property) trait).getComponent(), "", null);
                }
            return;
            }
        
        Component cd = (Component) trait;
        
        switch (evt.getAction())
            {
            case SubChangeEvent.SUB_CHANGE:
                PropertyChangeEvent evtChange = (PropertyChangeEvent) evt.getEvent();
        
                toolSite.onComponentModified(cd, evtChange.getPropertyName(), evtChange.getOldValue());
                break;
        
            case SubChangeEvent.SUB_ADD:
                toolSite.onComponentAdded(cd);
                break;
        
            case SubChangeEvent.SUB_REMOVE:
                toolSite.onComponentRemoved(cd);
                break;
        
            case SubChangeEvent.SUB_UNREMOVE:
                toolSite.onComponentUnremoved(cd);
                break;
            }
        }
    }
