/* Class
*     _package.component.dev.tool.host.TAPS$Docs
*/

package _package.component.dev.tool.host;

import _package.component.dev.Tool;
import _package.component.dev.tool.ResourceDesigner;
import _package.component.dev.tool.host.CDDesigner;
import _package.component.dev.tool.outputTool.Tracer;
import _package.component.dev.util.DocInfo;
import _package.component.util.Config;
import com.tangosol.dev.component.Component;
import com.tangosol.util.Base;
import com.tangosol.util.ErrorList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import javax.swing.JOptionPane;

/**
* This is a host of CDDesigner(s) and other tools (like OutputWindow). The host
* site of this host is a JTabbedPane set by TAPS.configureTools()
*/
public class TAPS$Docs
        extends    _package.component.dev.tool.Host
    {
    // Fields declarations
    
    /**
    * Property CommandMap
    *
    * Represents a mapping between a resource file extension and an external
    * "Edit" command
    * 
    * @see #openResource
    */
    private java.util.Hashtable __m_CommandMap;
    
    /**
    * Property ToolCount
    *
    * This property provides a unique number for the life of this component by
    * incrementing itself on every request
    */
    private transient int __m_ToolCount;
    
    // Default constructor
    public TAPS$Docs()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TAPS$Docs(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setCommandMap(new java.util.Hashtable(17));
            setTitle("Documents Host");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new TAPS$Docs();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/host/TAPS$Docs".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        // import Component.Util.Config;
        // import java.util.Hashtable;
        // import java.util.Enumeration;
        
        Hashtable tblCmd = getCommandMap();
        Config    cfgCmd = config.getConfig(sPrefix + ".CmdMap.");
        
        tblCmd.clear();
        for (Enumeration enum = cfgCmd.keys(); enum.hasMoreElements();)
            {
            String sExt = (String) enum.nextElement();
            String sCmd = cfgCmd.getString(sExt);
            
            tblCmd.put(sExt, sCmd);
            }
        
        super.applyConfig(config, sPrefix);
        }
    
    /**
    * Closes the currently active tool
    */
    private boolean closeActiveTool()
        {
        // import Component.Dev.Tool;
        
        Tool toolActive = getActiveTool();
        
        if (toolActive != null && !toolActive.isCloseCanceled())
            {
            toolActive.setOpen(false);
        
            return true;
            }
        else
            {
            return false;
            }

        }
    
    /**
    * Close all the tools.
    * 
    * @return true if all the tools are closed; false otherwise
    */
    private boolean closeAllTools()
        {
        // import Component.Dev.Tool;
        // import java.util.Enumeration;
        
        // first, close all "activatable" tools
        while (getActiveTool() != null)
            {
            if (!closeActiveTool())
                {
                return false;
                }
            }
        
        // second, close all others
        for (Enumeration enum = enumTools(); enum.hasMoreElements();)
            {
            Tool tool = (Tool) enum.nextElement();
        
            if (tool.isCloseCanceled())
                {
                return false;
                }
            tool.setOpen(false);
            }
        
        return true;

        }
    
    // Declared at the super level
    /**
    * Close the tool. If the tool itself is a host -- close all the hosted
    * tools as well.
    * 
    * @see Tool#setOpen()
    */
    public void closeTool(_package.component.dev.Tool tool)
        {
        // all documents should be removed as soon as they are closed
        super.closeTool(tool);
        
        removeTool(tool);
        }
    
    /**
    * Create a new CDDesigner tool.
    * 
    * This method is functionally very similar to the addTool; the problem with
    * addTool, however, is that due to the possible name change (as a reslut of
    * "save as") we cannot just use the component name as a tool name and have
    * to use some other way of generating unique tool names.
    * 
    * @see #findCDDesigner
    */
    private CDDesigner createCDDesigner()
        {
        // import Component.Dev.Tool.Host.CDDesigner;
        
        CDDesigner tool = new CDDesigner();
        addTool(tool, "__" + getToolCount());
        
        tool.setStorage(getStorage());
        
        return tool;
        }
    
    /**
    * Create a new component that is going to be saved using the specified
    * storage. The "Docs" host creates a new CDDesigner tool that latter on
    * will force user to change the component's name using the "Save as"
    * functionality
    * 
    * @param sSuper  fully qualified name of the Component that the new
    * component derives from
    */
    private void createComponent(String sSuper)
        {
        if (sSuper == null || sSuper.length() == 0)
            {
            // don't allow creation of the root component
            return;
            }
        
        String sPrefix = "New" + sSuper.substring(sSuper.lastIndexOf('.') + 1);
        String sName   = sPrefix;
        for (int i = 1; findCDDesigner(sSuper + '.' + sName, getStorage()) != null; i++)
            {
            sName = sPrefix + i;
            }
        
        CDDesigner dsnr = createCDDesigner();
        dsnr.createComponent(sSuper, sName);
        
        // CDDesigner could self destruct on failure
        if (dsnr.isOpen())
            {
            dsnr.setActive(true);
            }
        }
    
    /**
    * Create a new ResourceDesigner tool.
    * 
    * This method is functionally very similar to the addTool; the problem with
    * addTool, however, is that due to the possible name change (as a reslut of
    * "save as") we cannot just use the resource name as a tool name and have
    * to use some other way of generating unique tool names.
    * 
    * @see #findResourceDesigner
    */
    private _package.component.dev.tool.ResourceDesigner createResourceDesigner()
        {
        // import Component.Dev.Tool.ResourceDesigner;
        
        ResourceDesigner tool = new ResourceDesigner();
        addTool(tool, "__" + getToolCount());
        
        tool.setStorage(getStorage());
        
        return tool;
        }
    
    /**
    * Find the CDDesigner tool for the specified Component Definition
    * 
    * This method is functionally very similar to the getTool; the problem with
    * getTool, however, is that due to the possible name change (as a reslut of
    * "save as") we cannot just use the component name as a tool name and have
    * to use some other way of generating unique tool names.
    * 
    * @param store  component storage that the specified Component Definition
    * might have been loaded from; if null is passed, any storage will fit
    * @param sName  fully qualified name of the Component Definition that we
    * are looking a CDDesigner tool for.
    * 
    * @see #createCDDesigner
    * @see $Mgrs#compileComponent
    */
    public CDDesigner findCDDesigner(String sName, _package.component.dev.Storage store)
        {
        // import Component.Dev.Tool;
        // import Component.Dev.Tool.Host.CDDesigner;
        // import com.tangosol.dev.component.Component;
        // import java.util.Enumeration;
        
        for (Enumeration enum = enumTools(); enum.hasMoreElements();)
            {
            Tool tool = (Tool) enum.nextElement();
            if (tool instanceof CDDesigner)
                {
                CDDesigner dsnr = (CDDesigner) tool;
                Component  cd   = dsnr.getGlobalCD();
        
                if ((store == null || store.equals(dsnr.getStorage())) &&
                    cd != null && sName.equals(cd.getQualifiedName()))
                    {
                    return dsnr;
                    }
                }
            }
        return null;
        }
    
    /**
    * Find the ResourceDesigner tool for the specified Resource Signature
    * 
    * @param store  component storage that the specified Resource Signature
    * might have been loaded from; if null is passed, any storage will fit
    * @param sName  fully qualified name of the Resource Signature that we are
    * looking a ResourceDesigner tool for.
    * 
    * @see #createResourceDesigner
    * 
    */
    public _package.component.dev.tool.ResourceDesigner findResourceDesigner(String sName, _package.component.dev.Storage store)
        {
        // import Component.Dev.Tool;
        // import Component.Dev.Tool.ResourceDesigner;
        // import java.util.Enumeration;
        
        for (Enumeration enum = enumTools(); enum.hasMoreElements();)
            {
            Tool tool = (Tool) enum.nextElement();
            if (tool instanceof ResourceDesigner)
                {
                ResourceDesigner dsnr = (ResourceDesigner) tool;
        
                if ((store == null || store.equals(dsnr.getStorage())) &&
                    sName.equals(dsnr.getResourceName()))
                    {
                    return dsnr;
                    }
                }
            }
        return null;
        }
    
    // Accessor for the property "CommandMap"
    /**
    * Getter for property CommandMap.<p>
    * Represents a mapping between a resource file extension and an external
    * "Edit" command
    * 
    * @see #openResource
    */
    public java.util.Hashtable getCommandMap()
        {
        return __m_CommandMap;
        }
    
    // Accessor for the property "ToolCount"
    /**
    * Getter for property ToolCount.<p>
    * This property provides a unique number for the life of this component by
    * incrementing itself on every request
    */
    private int getToolCount()
        {
        int iCount = __m_ToolCount + 1;
        setToolCount(iCount);
        return iCount;

        }
    
    // Declared at the super level
    /**
    * Return true if the specified action fired by the specified host is
    * enabled by this tool; false otherwise.
    * The hosts additionally return true if at least one child tool of this
    * host "enables" this action.
    * 
    * This method is mostly used by host sites' menus to provide a visual clue
    * to the question:
    *  - If this host issues a command (host action), will there be any tool
    * being able to process this command
    * 
    * When the host is specified, the specified action is expected to be fired
    * by that host using fireHostAction(). If the host is null, this action is
    * expected to be fired by this tool itself using fireToolAction().
    * 
    * @param sAction  action name
    * @param host  the source of the action
    * @param  oValue an optional value to be passed along
    */
    public boolean isActionEnabled(String sAction, _package.component.dev.tool.Host host, Object oValue)
        {
        if (sAction.equals(ACTION_CLOSE))
            {
            return getActiveTool() != null;
            }
        else if 
           (sAction.equals(ACTION_CLOSE_ALL))
            {
            return enumTools().hasMoreElements();
            }
        else
            {
            return super.isActionEnabled(sAction, host, oValue);
            }
        }
    
    // Declared at the super level
    /**
    * Notification send by one of the containing hosts
    * 
    * @param host  the acted host
    * @param sName  action name
    * @param oValue  associated value
    * 
    * @throws EventDeathException if a tool doesn't want this notification be
    * propagated anymore
    */
    public void onHostAction(_package.component.dev.tool.Host host, String sAction, Object oValue)
        {
        // import Component.Dev.Util.DocInfo;
        // import com.tangosol.dev.component.Component;
        
        if (sAction.equals(ACTION_CLOSE))
            {
            closeActiveTool();
            }
        else if (sAction.equals(ACTION_CLOSE_ALL))
            {
            closeAllTools();
            }
        else if (sAction.equals(ACTION_CREATE))
            {
            if (oValue instanceof DocInfo)
                {
                DocInfo info  = (DocInfo) oValue;
                String  sName = info.getName();
                String  sType = info.getType();
        
                if (sType.equals("Component"))
                    {
                    createComponent(sName);
                    }
                }
            }
        else if (sAction.equals(ACTION_OPEN))
            {
            if (oValue instanceof DocInfo)
                {
                DocInfo info      = (DocInfo) oValue;
                String  sName     = info.getName();
                String  sType     = info.getType();
                boolean fReadOnly = !info.isCustomizable() ||
                                    getStorage().isReadOnly();
        
                if (sType.equals("Component")
                 || sType.equals("Signature"))
                    {
                    openComponent(sName, fReadOnly);
                    }
                else if (sType.equals("Resource"))
                    {
                    openResource(sName, fReadOnly, false);
                    }
                }
            else if (oValue instanceof Component)
                {
                openComponent((Component) oValue);
                }
            }
        else if (sAction.equals(ACTION_OPEN_WITH))
            {
            if (oValue instanceof DocInfo)
                {
                DocInfo info      = (DocInfo) oValue;
                String  sName     = info.getName();
                String  sType     = info.getType();
                boolean fReadOnly = !info.isCustomizable() ||
                                    getStorage().isReadOnly();
        
                if (sType.equals("Resource"))
                    {
                    openResource(sName, fReadOnly, true);
                    }
                }
            }
        else
            {
            super.onHostAction(host, sAction, oValue);
            }
        }
    
    /**
    * Open the specified component definition at a given storage
    * 
    * @param cd  global Component Definition to open
    */
    private void openComponent(com.tangosol.dev.component.Component cd)
        {
        // import Component.Dev.Tool.Host.CDDesigner;
        
        CDDesigner dsnr = findCDDesigner(cd.getQualifiedName(), getStorage());
        
        if (dsnr == null)
            {
            dsnr = createCDDesigner();
            dsnr.loadComponent(cd);
            }
        else
            {
            if (dsnr.getGlobalCD() != cd)
                {
                throw new IllegalStateException("Another component is open with identical name");
                }
            }
        
        // CDDesigner could self destruct on failure
        if (dsnr.isOpen())
            {
            dsnr.setActive(true);
            }
        }
    
    /**
    * Open a component at the given storage with a given fully qualified name
    * 
    * @param fReadOnly if true, the coomponent should be open in a "read only"
    * mode
    * @param sName  fully qualified name of the Component to open
    */
    private void openComponent(String sName, boolean fReadOnly)
        {
        // import Component.Dev.Tool.Host.CDDesigner;
        
        CDDesigner dsnr = findCDDesigner(sName, getStorage());
        
        if (dsnr == null)
            {
            dsnr = createCDDesigner();
            dsnr.loadComponent(sName, fReadOnly);
            }
        
        // CDDesigner could self destruct on failure
        if (dsnr.isOpen())
            {
            dsnr.setActive(true);
            }
        }
    
    /**
    * Open a Resource Signature at the current storage with a given fully
    * qualified name
    * 
    * @param sName  fully qualified name of the resource to open
    * @param fReadOnly  if true, the resource should be open in a read-only
    * mode
    * @param fPrompt  if true, prompt the user with the command line to run the
    * external tool
    */
    private void openResource(String sName, boolean fReadOnly, boolean fPrompt)
        {
        // import Component.Dev.Tool.ResourceDesigner;
        // import Component.Dev.Tool.OutputTool.Tracer;
        // import javax.swing.JOptionPane;
        
        if (fReadOnly)
            {
            getHostSite().msg("Message", new Object[]
                {
                "Opening a read-only resource is currently not supported.",
                "Open Resource",
                new Integer(JOptionPane.ERROR_MESSAGE),
                });
            return;
            }
        
        ResourceDesigner dsnr = findResourceDesigner(sName, getStorage());
        String sShortName     = sName.substring(sName.lastIndexOf('/') + 1);
        
        if (dsnr != null)
            {
            String sMsg =
                "Resource \"" + sShortName +  "\" may already be open for editing,\n" + 
                "and you may have made changes that have not been committed.\n\n" +
                "Would you like to commit the current edits to\n\"" +
                sShortName + "\" before re-opening the resource?";
        
            Integer IAnswer = (Integer) getHostSite().msg("Confirm", new Object[]
                {
                sMsg,
                dsnr.getTitle(),
                new Integer(JOptionPane.YES_NO_CANCEL_OPTION)
                });
        
            switch (IAnswer.intValue())
                {
                case JOptionPane.YES_OPTION:
                    dsnr.commitResource();
                    // break through
                    
                case JOptionPane.NO_OPTION:
                    dsnr.setOpen(false);
                    dsnr = null;
                    break;
        
                case JOptionPane.CANCEL_OPTION:
                case JOptionPane.CLOSED_OPTION:
                default:
                    return;
                }
            }
        
        int    ofExt = sShortName.lastIndexOf('.');
        String sExt;
        
        if (0 <= ofExt && ofExt < sShortName.length() - 1)
            {
            sExt = sShortName.substring(ofExt + 1);
            }
        else
            {
            sExt = "."; // no extension
            }
        
        String CMD_DEFAULT = System.getProperty("os.name", "").startsWith("Windows") ?
            "cmd start /c" : "dtpad";
        
        String sCmd = (String) getCommandMap().get(sExt);
        if (sCmd == null)
            {
            sCmd = CMD_DEFAULT;
            }
        
        while (true)
            {
            dsnr = createResourceDesigner();
            dsnr.setResourceName(sName);
            dsnr.setOutputTool(new Tracer());
        
            if (fPrompt)
                {
                String sMsg = "Choose the program you want to use to open the resource:\n\n" +
                    sName + "\n\n";
                sCmd = (String) getHostSite().msg("Input", new Object[]
                    {
                    sMsg,
                    dsnr.getTitle(),
                    new Integer(JOptionPane.QUESTION_MESSAGE),
                    sCmd,
                    });
        
                if (sCmd == null)
                    {
                    // operation was canceled
                    removeTool(dsnr);
                    dsnr = null;
                    break;
                    }
        
                if (sCmd.length() == 0)
                    {
                    sCmd = CMD_DEFAULT;
                    }
                }
        
            dsnr.setExternalCommand(sCmd);
            dsnr.setOpen(true);
        
            if (dsnr.isOpen())
                {
                if (sCmd.equals(CMD_DEFAULT))
                    {
                    getCommandMap().remove(sExt);
                    }
                else
                    {
                    getCommandMap().put(sExt, sCmd);
                    }
                break;
                }
            else
                {
                fPrompt = true;
                }
            }
        }
    
    // Declared at the super level
    /**
    * Report errors for the specified tool. Usually this method is called by a
    * tool that does not have an ability to report errors on its own
    * 
    * The default implementation is to go up to the outer host (if there is
    * one) or just output it.
    * 
    * @see Tool#reportErrors()
    */
    public void reportErrors(_package.component.dev.Tool tool)
        {
        // import com.tangosol.util.Base;
        // import com.tangosol.util.ErrorList;
        // import java.util.Iterator;
        // import javax.swing.JOptionPane;
        
        ErrorList errList = tool.getErrorList();
        int       cErrs   = errList.size();
        if (cErrs > 0)
            {
            // TODO: route to the output panel instead of the message box
            boolean fSevere = errList.isSevere();
            String  sMsg    = Base.breakLines(errList.get(0).toString(), 80, "");
        
            if (cErrs > 1)
                {
                sMsg += "\n\n(see log for details)";
                }
            else
                {
                errList.clear();
                }
        
            getHostSite().msg("Message", new Object[]
                {
                sMsg,
                tool.getTitle(),
                new Integer(fSevere ?
                    JOptionPane.ERROR_MESSAGE : JOptionPane.INFORMATION_MESSAGE),
                });
            }
        
        super.reportErrors(tool);
        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        // import Component.Util.Config;
        // import java.util.Hashtable;
        // import java.util.Enumeration;
        
        Hashtable tblCmd = getCommandMap();
        Config    cfgCmd = new Config();
        
        for (Enumeration enum = tblCmd.keys(); enum.hasMoreElements();)
            {
            String sExt = (String) enum.nextElement();
            String sCmd = (String) tblCmd.get(sExt);
        
            cfgCmd.putString(sExt, sCmd);
            }
        config.putConfig(sPrefix + ".CmdMap.", cfgCmd);
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "CommandMap"
    /**
    * Setter for property CommandMap.<p>
    * Represents a mapping between a resource file extension and an external
    * "Edit" command
    * 
    * @see #openResource
    */
    public void setCommandMap(java.util.Hashtable pCommandMap)
        {
        __m_CommandMap = pCommandMap;
        }
    
    // Accessor for the property "ToolCount"
    /**
    * Setter for property ToolCount.<p>
    * This property provides a unique number for the life of this component by
    * incrementing itself on every request
    */
    private void setToolCount(int pToolCount)
        {
        __m_ToolCount = pToolCount;
        }
    }
