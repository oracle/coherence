/* Class
*     _package.component.dev.tool.host.cDTool.ContainmentTool
*/

package _package.component.dev.tool.host.cDTool;

import _package.component.dev.Design;
import _package.component.dev.Storage;
import _package.component.gUI.control.container.jComponent.jPanel.toolSite.ContainmentManager;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.Constants;
import com.tangosol.dev.component.Implementation;
import com.tangosol.dev.component.Property;
import com.tangosol.dev.component.SubChangeEvent;
import com.tangosol.dev.component.Trait;
import com.tangosol.util.ErrorList;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyVetoException;
import java.util.Enumeration;
import javax.swing.JOptionPane;

public class ContainmentTool
        extends    _package.component.dev.tool.host.CDTool
        implements com.tangosol.dev.component.SubChangeListener,
                   java.beans.PropertyChangeListener
    {
    // Fields declarations
    
    // Default constructor
    public ContainmentTool()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ContainmentTool(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(30.0F);
            setTitle("Containment Manager");
            setToolSiteClass(Class.forName("_package/component/gUI/control/container/jComponent/jPanel/toolSite/ContainmentManager".replace('/', '.')));
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ContainmentTool();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/tool/host/cDTool/ContainmentTool".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite.ContainmentManager;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        

        }
    
    /**
    * Creates a new child of the specified descent for the specified Component
    * Definition.
    * 
    * @param cdParent  the parent of a newly created child
    * @param sSuper  component name that a newly created child will derive from
    * 
    * @return the child Component Definition; null if the child could not be
    * created
    */
    public com.tangosol.dev.component.Component addComponent(com.tangosol.dev.component.Component cdParent, String sSuper)
        {
        // import Component.Dev.Design;
        
        Component cdChild = Design.getDesignInfo(cdParent).
                                addChildComponent(cdParent, sSuper, getStorage());
        if (cdChild != null)
            {
            Design.getDesignInfo(cdChild).initializeComponent(cdChild);
            }
        
        return cdChild;
        }
    
    /**
    * Copies or moves the specified child to the specfied parent.
    * 
    * @param cdParent  parent component to adopt the child
    * @param cdChild  child component to copy or move
    * @param fCopy  specifies the operation: true means copy; false means move.
    * 
    * @return  the copied or moved component
    */
    public com.tangosol.dev.component.Component copyComponent(com.tangosol.dev.component.Component cdParent, com.tangosol.dev.component.Component cdChild, boolean fCopy)
        {
        // import java.beans.PropertyVetoException;
        
        _assert(!cdChild.isGlobal());
        
        if (!fCopy && cdChild.getParent() == cdParent)
            {
            // cannot move within the same parent
            return null;
            }
        
        Component cdCopy = null;
        try
            {
            String    sSuper  = cdChild.getGlobalSuperName();
            Component cdSuper = getStorage().loadComponent(sSuper, true, null);
            String    sChild  = cdChild.getName();
            if (cdParent.isChild(sChild))
                {
                int    of      = sChild.lastIndexOf("_");
                String sPrefix = of < 0 ? sChild : sChild.substring(0, of);
                for (int i = 1; true; i++)
                    {
                    sChild = sPrefix + "_" + i;
                    if (cdParent.getChild(sChild) == null &&
                       !cdParent.isChildUnremovable(sChild))
                        {
                        break;
                        }
                    }
                }
            
            if (fCopy)
                {
                cdCopy = cdParent.copyChild(cdSuper, sChild, cdChild, getStorage(), getErrorList());
                }
            else
                {
                cdCopy = cdParent.moveChild(cdSuper, sChild, cdChild, getStorage(), getErrorList());
                }
            }
        // ComponentException, PropertyVetoException
        catch (Exception e)
            {
            getErrorList().addException(e);
            }
        
        reportErrors();
        
        return cdCopy;
        }
    
    public boolean isChildShowing(com.tangosol.dev.component.Component cdChild)
        {
        // import com.tangosol.dev.component.Constants;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Property;
        // import java.util.Enumeration;
        
        int     nVisibility = getCDDesigner().getFilterVisibility();
        boolean fShow;
        
        switch (nVisibility & Constants.VIS_MASK)
            {
            default:
            case Constants.VIS_VISIBLE:
                fShow = cdChild.getVisible() == Constants.VIS_VISIBLE;
                break;
            case Constants.VIS_ADVANCED:
                fShow = cdChild.getVisible() == Constants.VIS_VISIBLE ||
                       cdChild.getVisible() == Constants.VIS_ADVANCED;
                break;
            case Constants.VIS_HIDDEN:
                fShow = cdChild.getVisible() != Constants.VIS_SYSTEM;
                break;
            case Constants.VIS_SYSTEM:
                fShow = true;
                break;
            }
        
        // "View-Declared" option is represented as EXISTS_INSERT bit.
        if (!fShow && (nVisibility & Constants.EXISTS_INSERT) != 0)
            {
            // When "View-Declared" option is on, show declared at this level,
            // abstract or "delta" components regardless of their visibility
            if (cdChild.isDeclaredAtThisLevel() ||
                cdChild.isAbstract())
                {
                return true;
                }
        
            for (Enumeration enum = cdChild.getBehaviors(); enum.hasMoreElements();)
                {
                Behavior bhvr = (Behavior) enum.nextElement();
                if (bhvr.getModifiableImplementationCount() > 0)
                    {
                    return true;
                    }
                }
        
            for (Enumeration enum = cdChild.getProperties(); enum.hasMoreElements();)
                {
                Property prop = (Property) enum.nextElement();
                if (!prop.isValueDiscardable())
                    {
                    return true;
                    }
                }
            }
        
        return fShow;
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets closed<p>
    * Note: this method is called before the host is notified with closeTool(),
    * so no relevant host's destruction has been done yet.
    * 
    * @see #setOpen
    * @see Host#closeTool
    */
    public void onClose()
        {
        super.onClose();
        
        getGlobalCD().removePropertyChangeListener(this);
        getGlobalCD().removeSubChangeListener(this);
        }
    
    // Declared at the super level
    /**
    * Notification from the CDDesigner host that the trait filter has changed
    * 
    * @see CDDesigner#setFilterVisibility()
    */
    public void onFilterChanged()
        {
        super.onFilterChanged();
        
        getToolSite().load(true);
        }
    
    // Declared at the super level
    /**
    * Notification from the CDDesigner host that the global CD has changed
    * 
    * This could happen only in the case when renaming a component causes the
    * Component Definition reference to change
    * 
    * @see CDDesigner#renameComponent()
    * @see CDDesigner#setGlobalCD()
    */
    public void onGlobalCDChanged(com.tangosol.dev.component.Component cdOld)
        {
        super.onGlobalCDChanged(cdOld);
        
        Component cdNew = getGlobalCD();
        
        if (!isOpen() || cdOld == cdNew)
            {
            return;
            }
        
        if (cdOld != null)
            {
            cdOld.removePropertyChangeListener(this);
            cdOld.removeSubChangeListener(this);
            }
        
        getToolSite().load(false);
        
        cdNew.addPropertyChangeListener(this);
        cdNew.addSubChangeListener(this);

        }
    
    // Declared at the super level
    /**
    * Notification from the CDDesigner host that the local CD has changed
    * 
    * @see CDDesigner#setLocalCD()
    */
    public void onLocalCDChanged(com.tangosol.dev.component.Component cdOld)
        {
        super.onLocalCDChanged(cdOld);
        
        if (isOpen())
            {
            ((ContainmentManager) getToolSite()).setComponent(getLocalCD());
            }
        }
    
    // Declared at the super level
    /**
    * Notification sent when the tool gets opened.<p>
    * Note: this method is called after the host is notified with openTool(),
    * so all the relevant host's initialization is already done.
    * 
    * @see #setOpen
    * @see Host#openTool
    */
    public void onOpen()
        {
        super.onOpen();
        
        onGlobalCDChanged(null);
        onLocalCDChanged(null);
        }
    
    // From interface: java.beans.PropertyChangeListener
    public void propertyChange(java.beans.PropertyChangeEvent evt)
        {
        ContainmentManager toolSite = (ContainmentManager) getToolSite();
        Component          cd       = (Component) evt.getSource();
        String             sAttrib  = evt.getPropertyName();
        
        // we listen to the PropertyChange only on the GlobalCD
        _assert(cd == getGlobalCD());
        
        toolSite.onComponentModified(cd, sAttrib, evt.getOldValue());
        }
    
    /**
    * Copies or moves the specified child to the specfied parent.
    * 
    * @param cdParent  parent component to adopt the child
    * @param cdChild  child component to copy or move
    * @param fCopy  specifies the operation: true means copy; false means move.
    * 
    * @return  the copied or moved component
    */
    public com.tangosol.dev.component.Component replaceChildSuper(com.tangosol.dev.component.Component cd, String sSuper)
        {
        // import Component.Dev.Storage;
        // import com.tangosol.util.ErrorList;
        // import javax.swing.JOptionPane;
        
        _assert(!cd.isGlobal());
        
        Storage   store   = getStorage();
        ErrorList errlist = getErrorList();
        
        if (sSuper == null)
            {
            sSuper = (String) getToolSite().msg("Input", new Object[]
                {
                "Please enter component name",
                "Replace Super",
                new Integer(JOptionPane.QUESTION_MESSAGE),
                cd.getGlobalSuperName(),
                });
        
            if (sSuper == null || sSuper.length() == 0)
                {
                return null;
                }
            }
        
        try
            {
            Component cdNewSuper = store.loadComponent(sSuper, true, errlist);
            if (cdNewSuper == null)
                {
                throw new ComponentException("Super component " + sSuper + " doesn't exist.");
                }
        
            Component cdOldSuper = store.loadComponent(cd.getGlobalSuperName(), true, errlist);
        
            return cd.getParent().replaceChildSuper(cd.getName(), cdOldSuper, cdNewSuper, store, errlist);
            }
        catch (Exception e)
            {
            String sMsg = e.getMessage();
            getToolSite().msg("Message", new Object[]
                {
                sMsg.length() > 0 ? sMsg : e.getClass().getName(),
                "Replace Super",
                new Integer(JOptionPane.ERROR_MESSAGE),
                });
            return null;
            }
        finally
            {
            reportErrors();
            }
        }
    
    // From interface: com.tangosol.dev.component.SubChangeListener
    public void subChange(com.tangosol.dev.component.SubChangeEvent evt)
        {
        // import com.tangosol.dev.component.Trait;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Implementation;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.SubChangeEvent;
        // import java.beans.PropertyChangeEvent;
        
        ContainmentManager toolSite = (ContainmentManager) getToolSite();
        
        Trait trait = evt.getSubTrait();
        
        if (!(trait instanceof Component))
            {
            // we need to track a change that would cause
            // a visual change to the component's presentation in the tool
            // (such as adding an implementation or changing the property value)
            if (trait instanceof Implementation)
                {
                toolSite.onComponentModified(((Implementation) trait).getBehavior().getComponent(), "", null);
                }
            else if (trait instanceof Property)
                {
                toolSite.onComponentModified(((Property) trait).getComponent(), "", null);
                }
            return;
            }
        
        Component cd = (Component) trait;
        
        switch (evt.getAction())
            {
            case SubChangeEvent.SUB_CHANGE:
                PropertyChangeEvent evtChange = (PropertyChangeEvent) evt.getEvent();
                Object              oValueOld = evtChange == null ? null : evtChange.getOldValue();
                String              sAttrib   = evtChange == null ? null : evtChange.getPropertyName();
        
                toolSite.onComponentModified(cd, sAttrib, oValueOld);
                break;
        
            case SubChangeEvent.SUB_ADD:
                toolSite.onComponentAdded(cd);
                break;
        
            case SubChangeEvent.SUB_REMOVE:
                toolSite.onComponentRemoved(cd);
                break;
        
            case SubChangeEvent.SUB_UNREMOVE:
                toolSite.onComponentUnremoved(cd);
                break;
            }
        }
    }
