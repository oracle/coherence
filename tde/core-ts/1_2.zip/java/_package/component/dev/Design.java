/* Class
*     _package.component.dev.Design
*/

package _package.component.dev;

import _package.component.dev.Design;
import _package.component.dev.design.Array;
import _package.component.dev.design.Component; // as ComponentInfo
import com.tangosol.dev.assembler.Constant;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Property;
import java.lang.reflect.Method;
import java.util.Hashtable;

public abstract class Design
        extends    _package.component.Dev
    {
    // Fields declarations
    
    /**
    * Property Choice
    *
    * Specifies whether there is a preset collection of text choices for this
    * design unit.
    * 
    * Note: if the value of this property is true, the value of TextChoices
    * property must be set as well.
    * 
    * @see #TextChoices
    */
    
    /**
    * Property DesignBase
    *
    * (Calculated) For data types that persist into the Component Definition in
    * the same manner as another (base) data type, the DesignBase property
    * specifies an appropriate Design component. For example, the DesignBase of
    * Component.Dev.Design.Class.java.lang.Integer is
    * Component.Dev.Design.Intrinsic.Integer.
    * 
    * @see #isTextLegal
    * @see #convertText
    * @see #getValue
    */
    
    /**
    * Property DesignInfoCache
    *
    * Privately used cache of Design components
    * 
    * @see #getDesignInfo
    */
    private static transient java.util.Hashtable __s_DesignInfoCache;
    
    /**
    * Property PROPERTY_DESIGN_PREFIX
    *
    * Prefix used for properties that specify the name of the Design component
    * holding the design information for the specified property for the
    * specified component.
    * 
    * All properties that have their names prefixed with this string are
    * supposed to be public Virtual Constants of String data type.
    * 
    * @see #getDesignInfo
    */
    public static final String PROPERTY_DESIGN_PREFIX = "PD_";
    
    /**
    * Property TEXT_NO_VALUE
    *
    * String value for the "no value" value.
    */
    protected static final String TEXT_NO_VALUE = "[none]";
    
    /**
    * Property TEXT_NULL
    *
    * String value for the "null" value.
    */
    protected static final String TEXT_NULL = "[null]";
    
    /**
    * Property TextChoices
    *
    * Preset collection of text choices for this design unit. Ususally the
    * order of the text choices is important.
    * 
    * Note: all the values of this array must pass isTextLegal test and must be
    * convertable by getValue
    */
    private static final String[] __s_TextChoices;
    
    /**
    * Property VALUE_UNKNOWN
    *
    * This is an internally used value that indicates that a text conversion is
    * not available.
    */
    protected static final Object VALUE_UNKNOWN;
    
    // Static initializer
    static
        {
        try
            {
            __s_TextChoices = null;
            VALUE_UNKNOWN = new java.lang.Object();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // state initialization: static properties
        try
            {
            __s_DesignInfoCache = new java.util.Hashtable();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Initializing constructor
    public Design(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant Choice
    public boolean isChoice()
        {
        return false;
        }
    
    // Getter for virtual constant TextChoices
    public String[] getTextChoices()
        {
        return null;
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/Design".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Generates Java class byte codes for a constant value initialization
    * 
    * @param gen ClassGenerator producing a Java class
    * @param oValue value to generate an initializer for
    * @param dtType data type of the specified value
    * 
    * @throws IllegalArgumentException if the code generation is not possible
    * due to an unknown value [data type]
    * 
    * @see #getValue
    * @see Component.Dev.Compiler.ClassGenerator#addConstantInitializer
    * @see Component.Dev.Compiler.ClassGenerator#addPropertyInitializer
    */
    protected void addConstantInitializer(_package.component.dev.compiler.ClassGenerator gen, Object oValue, com.tangosol.dev.component.DataType dtType)
        {
        // import Component.Dev.Design.Array;
        // import com.tangosol.dev.assembler.Constant;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Property;
        
        if (oValue == null || dtType.isExtendedSimple())
            {
            Constant constValue = gen.getConstant(oValue, dtType);
        
            gen.getCode().add(gen.getLoadConstOp(constValue));
        
            gen.print(gen.formatConstant(constValue, dtType));
            }
        else if (dtType.isArray())
            {
            throw new IllegalStateException(".addConstantInitializer: must be overriden for " + dtType);
            }
        else // not an intrinsic+ property
            {
            throw new UnsupportedOperationException("!!TODO: init non intrinsic type " + dtType);
        
            // 1) serialize the property value into a String
            // 2) add the String to the class constant pool
            // 3) add code that loads the String from the pool and
            //    deserializes a property value from it
            }
        }
    
    /**
    * Generates Java class byte codes for a constant value initialization
    * 
    * @param gen ClassGenerator producing a Java class
    * @param oValue value to generate an initializer for
    * @param dtType data type of the specified value
    * 
    * @throws IllegalArgumentException if the code generation is not possible
    * due to an unknown value [data type]
    * 
    * @see #getValue
    * @see Component.Dev.Compiler.ClassGenerator#addConstantInitializer
    * @see Component.Dev.Compiler.ClassGenerator#addPropertyInitializer
    */
    public void addConstantInitializer(_package.component.dev.compiler.ClassGenerator gen, Object oValue, com.tangosol.dev.component.DataType dtType, String sPrefix, String sPostfix)
        {
        gen.print(sPrefix);
        addConstantInitializer(gen, oValue, dtType);
        gen.print(sPostfix);

        }
    
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, Storage storage)
        {
        // import com.tangosol.dev.component.Property;
        
        Design designBase = getDesignBase();
        if (designBase != null)
            {
            return designBase.convertText(sText, dtValue, storage);
            }
        
        return sText.equals(TEXT_NO_VALUE) ? Property.NO_VALUE : VALUE_UNKNOWN;
        }
    
    /**
    * Instantiates a component that has an information needed to design the
    * specified Component Definition.
    * 
    * @param sName  name of designable Component Definition
    * 
    * @return a component of Component.Dev.Design.Component type
    */
    protected static _package.component.dev.design.Component getComponentInfo(String sName)
        {
        // import Component.Dev.Design.Component as ComponentInfo;
        // import java.util.Hashtable;
        
        Hashtable     tbl        = getDesignInfoCache();
        ComponentInfo designInfo = null;
        
        int ofPos = sName.length();
        while (ofPos > 0)
            {
            String sInfoName = sName.substring(0, ofPos);
            
            designInfo = (ComponentInfo) getDesignInfo(sInfoName);
            if (designInfo != null)
                {
                break;
                }
        
            ofPos = sName.lastIndexOf('.', ofPos - 1);
            }
        
        if (designInfo == null)
            {
            // this could only happend for the Root component
            designInfo = new ComponentInfo();
            }
        
        tbl.put(sName, designInfo);
        
        return designInfo;
        }
    
    // Accessor for the property "DesignBase"
    public Design getDesignBase()
        {
        return null;
        }
    
    /**
    * Instantiates a component of Component.Dev.Design type that has an
    * information needed to design the specified Component Definition.
    * 
    * @param cd  a designable component
    * 
    * @return a component of Component.Dev.Design.Component type
    */
    public static _package.component.dev.design.Component getDesignInfo(com.tangosol.dev.component.Component cd)
        {
        // import Component.Dev.Design.Component as ComponentInfo;
        
        // TODO: if the component is global we could consider a flag forcing to return
        // Design.Component.A (instead of Design.Component.A.B) for Component.A.B
        // (For example, that would disallow designing JPanel itself with LayoutDesigner)
        
        if (cd.isComponent())
            {
            String sName = cd.isGlobal() ? cd.getQualifiedName() : cd.getGlobalSuperName();
            return getComponentInfo(sName);
            }
        else
            {
            // temporarily class signatures as Root Component
            return new ComponentInfo();
            }
        }
    
    /**
    * Instantiates a component of Component.Dev.Design type that has an
    * information needed to design a Property of the specified DataType. This
    * is going to be an instance of Design.Component (for Complex Properties),
    * Design.Class (for Properties of reference data types), Design.Array (for
    * Properties of array data types) or Design.Intrinsic (for Properties of
    * intrinsic data type).
    * 
    * @param dt  data type of a designable property
    * 
    * @return a newly instantiated component of Component.Dev.Design type
    */
    protected static Design getDesignInfo(com.tangosol.dev.component.DataType dt)
        {
        // import Component.Dev.Design;
        // import java.util.Hashtable;
        
        if (dt.isComponent())
            {
            return getComponentInfo(dt.getComponentName());
            }
        else if (dt.isClass())
            {
            return Design.Class.getClassInfo(dt.getClassName());
            }
        else // array or intrinsic
            {
            Hashtable tbl        = getDesignInfoCache();
            String    sInfoName  = dt.toString();
            Design    designInfo = (Design) tbl.get(sInfoName);
            
            if (designInfo != null)
                {
                return designInfo;
                }
        
            if (dt.isArray())
                {
                designInfo = new Design.Array();
                ((Design.Array) designInfo).setElementDesign(
                    getDesignInfo(dt.getElementType()));
                }
            else
                {
                _assert(dt.isPrimitive());
        
                switch (dt.getTypeString().charAt(0))
                    {
                    case 'Z':
                        designInfo = new Design.Intrinsic.Boolean();
                        break;
                    case 'B':
                        designInfo = new Design.Intrinsic.Byte();
                        break;
                    case 'C':
                        designInfo = new Design.Intrinsic.Character();
                        break;
                    case 'S':
                        designInfo = new Design.Intrinsic.Short();
                        break;
                    case 'I':
                        designInfo = new Design.Intrinsic.Integer();
                        break;
                    case 'J':
                        designInfo = new Design.Intrinsic.Long();
                        break;
                    case 'F':
                        designInfo = new Design.Intrinsic.Float();
                        break;
                    case 'D':
                        designInfo = new Design.Intrinsic.Double();
                        break;
                    default:
                        throw new IllegalArgumentException("Unknown data type" + dt);
                    }
                }
            
            tbl.put(sInfoName, designInfo);
            return designInfo;
            }
        }
    
    /**
    * Instantiates a component of Component.Dev.Design type that has an
    * information needed to design the specified Property. This is going to be
    * an instance of Design.Component (for Complex Properties),
    * Design.Intrinsic (for Properties of intrinsic data type) or Design.Class
    * (for Properties of reference data types)
    * 
    * @param property  a designable property
    * 
    * @return a component of Component.Dev.Design type
    */
    public static Design getDesignInfo(com.tangosol.dev.component.Property prop)
        {
        // import Component.Dev.Design;
        // import com.tangosol.dev.component.DataType;
        // import java.util.Hashtable;
        
        Hashtable tbl = getDesignInfoCache();
        
        String sInfoName  = prop.getComponent().getQualifiedName() + '#' + prop.getName();
        Design designInfo = (Design) tbl.get(sInfoName);
        
        if (designInfo != null)
            {
            return designInfo;
            }
        
        // First ask the design component for the component itself
        
        designInfo = getDesignInfo(prop.getComponent()).getPropertyInfo(prop);
        
        if (designInfo != null)
            {
            tbl.put(sInfoName, designInfo);
            return designInfo;
            }
        
        // Secondly, get the design info for the property's data type
        // Note that we don't cache the answer here, because it's cached
        // internaly by the callee (and the property type can change)
        
        DataType dtProp = prop.getDataType();
        return getDesignInfo(prop.isSingle() ? dtProp : dtProp.getArrayType());
        }
    
    /**
    * Instantiates a component of that has an information needed to design the
    * specified design unit.
    * 
    * @param sName  name of designable unit.
    * 
    * @return a component of Component.Dev.Design type
    */
    protected static Design getDesignInfo(String sName)
        {
        // import java.util.Hashtable;
        
        Hashtable  tbl        = getDesignInfoCache();
        Design     designInfo = (Design) tbl.get(sName);
        
        if (designInfo != null)
            {
            return designInfo;
            }
        
        designInfo = (Design) _newInstance("Component.Dev.Design." + sName);
        
        if (designInfo != null)
            {
            tbl.put(sName, designInfo);
            }
        return designInfo;
        }
    
    // Accessor for the property "DesignInfoCache"
    protected static java.util.Hashtable getDesignInfoCache()
        {
        return __s_DesignInfoCache;
        }
    
    /**
    * Tries to instantiates a component of Component.Dev.Design type that has
    * an information needed to design the specified Property. 
    * 
    * @param property  a designable property
    * 
    * @return a component of Component.Dev.Design type or null if no
    * inforamtion available
    * 
    * @see #getDesignInfo(Property)
    */
    public Design getPropertyInfo(com.tangosol.dev.component.Property prop)
        {
        // import Component.Dev.Design;
        // import java.lang.reflect.Method;
        
        // First, use reflection to get a value of the property that is the same as our
        // property prefixed by the "PD_" and the data type of String
        
        Design designInfo = null;
        String sInfoName  = PROPERTY_DESIGN_PREFIX + prop.getName();
        try
            {
            Method methodGet = this.getClass().getMethod("get" + sInfoName, null);
            String sPropInfo = (String) methodGet.invoke(this, null);
        
            if (sPropInfo != null)
                {
                designInfo = getDesignInfo(sPropInfo);
                }
            }
        catch (Exception e) {}
        
        // Secondly try to get a child component with the same name
        
        if (designInfo == null)
            {
            designInfo = (Design) _findChild(sInfoName);
            }
        
        return designInfo;
        }
    
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        // import com.tangosol.dev.component.Property;
        
        Design designBase = getDesignBase();
        if (designBase != null)
            {
            return designBase.getText(oValue, dtValue);
            }
        
        return oValue == Property.NO_VALUE ? TEXT_NO_VALUE : null;
        }
    
    /**
    * Converts a string (which is usually the string representing a property
    * value typed in by the user in the Property Sheet) into a value stored by
    * the component definition. This value will be converted back to
    * displayable string by the method "getText()" and used to generate a Java
    * class by "addPropertyInitializer()". This convertion  and "getText"
    * conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * 
    * Note: Component Definition has a specific knowledge of the data type of
    * the returned value (i.e. complex property), it is only capable of storing
    * values of data types that are serializable (implement
    * java.io.Serializable interface).
    * 
    * @param sText string to convert
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return the "serializable" value of the specified value
    * 
    * @throws IllegalArgumentException if the conversion is not possible
    * 
    * @see #getText
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getPropertyValue
    */
    public Object getValue(String sText, com.tangosol.dev.component.DataType dtValue, Storage storage)
        {
        if (!isTextLegal(sText, dtValue, storage))
            {
            throw new IllegalArgumentException(get_Name() +
                ".getValue: " + "Illegal text to convert: " + sText);    
            }
        
        Object oValue = convertText(sText, dtValue, storage);
        
        if (oValue == VALUE_UNKNOWN)
            {
            throw new IllegalArgumentException(get_Name() +
                ".getValue: " + "Unable to convert: " + sText);
            }
        
        return oValue;
        }
    
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, Storage storage)
        {
        Design designBase = getDesignBase();
        if (designBase != null && designBase.isTextLegal(sText, dtValue, storage))
            {
            return true;
            }
        
        if (isChoice())
            {
            String[] asChoice = getTextChoices();
            if (asChoice != null)
                {
                for (int i = 0; i < asChoice.length; i++)
                    {
                    if (sText.equals(asChoice[i]))
                        {
                        return true;
                        }
                    }
                }
            }
        
        return sText.equals(TEXT_NO_VALUE);
        }
    
    // Accessor for the property "DesignInfoCache"
    private static void setDesignInfoCache(java.util.Hashtable pDesignInfoCache)
        {
        __s_DesignInfoCache = pDesignInfoCache;
        }
    }
