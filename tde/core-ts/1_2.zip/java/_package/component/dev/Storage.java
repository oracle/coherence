/* Class
*     _package.component.dev.Storage
*/

package _package.component.dev;

import com.tangosol.dev.component.BaseStorage;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.Storage; // as _Storage
import com.tangosol.util.StringTable;
import java.util.Enumeration;

/*
* Integrates
*     com.tangosol.dev.component.Storage
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class Storage
        extends    _package.component.Dev
        implements com.tangosol.dev.component.Storage
    {
    // Fields declarations
    
    /**
    * Property _Storage
    *
    */
    private transient com.tangosol.dev.component.Storage __m__Storage;
    
    /**
    * Property ClassPath
    *
    * (Calculated) Specifies the path that have to be added to the CLASSPATH
    * (System property "java.class.path") in order to be able to access classes
    * managed by this Storage.
    */
    
    /**
    * Property Locator
    *
    * The locator object assosiated with this storage. Note: this property is
    * only applicable to persistent (non-synthetic) storages.
    */
    private transient Object __m_Locator;
    
    /**
    * Property PackageDir
    *
    * (Calculated) Specifies the directory to use by the packager to put the
    * produced packages
    */
    
    /**
    * Property ReadOnly
    *
    * Specifies whether this storage is a read only.
    */
    
    // Default constructor
    public Storage()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Storage(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Storage();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/Storage".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ com.tangosol.dev.component.Storage integration
    // Access optimization
    // properties integration
    // methods integration
    public com.tangosol.util.StringTable getComponentPackages(String sPackage, boolean fQualify, boolean fSubs)
        {
        return get_Storage().getComponentPackages(sPackage, fQualify, fSubs);
        }
    public com.tangosol.util.StringTable getPackageComponents(String sPackage, boolean fQualify)
        {
        return get_Storage().getPackageComponents(sPackage, fQualify);
        }
    public com.tangosol.util.StringTable getPackageResources(String sName, boolean fQualified)
        {
        return get_Storage().getPackageResources(sName, fQualified);
        }
    public com.tangosol.util.StringTable getPackageSignatures(String sPackage, boolean fQualify)
        {
        return get_Storage().getPackageSignatures(sPackage, fQualify);
        }
    public com.tangosol.util.StringTable getResourcePackages(String sName, boolean fQualified, boolean fSubs)
        {
        return get_Storage().getResourcePackages(sName, fQualified, fSubs);
        }
    public com.tangosol.util.StringTable getSignaturePackages(String sPackage, boolean fQualify, boolean fSubs)
        {
        return get_Storage().getSignaturePackages(sPackage, fQualify, fSubs);
        }
    public com.tangosol.util.StringTable getSubComponents(String sComponent, boolean fQualify)
        {
        return get_Storage().getSubComponents(sComponent, fQualify);
        }
    public com.tangosol.dev.assembler.ClassFile loadClass(String sName)
            throws com.tangosol.dev.component.ComponentException
        {
        return get_Storage().loadClass(sName);
        }
    public com.tangosol.dev.component.Component loadComponent(String sName, boolean fReadOnly, com.tangosol.util.ErrorList errlist)
            throws com.tangosol.dev.component.ComponentException
        {
        return get_Storage().loadComponent(sName, fReadOnly, errlist);
        }
    public String loadJava(String sName)
            throws java.io.IOException
        {
        return get_Storage().loadJava(sName);
        }
    public com.tangosol.dev.assembler.ClassFile loadOriginalClass(String sName)
            throws com.tangosol.dev.component.ComponentException
        {
        return get_Storage().loadOriginalClass(sName);
        }
    public byte[] loadOriginalResource(String sName)
            throws java.io.IOException
        {
        return get_Storage().loadOriginalResource(sName);
        }
    public byte[] loadResource(String sName)
            throws java.io.IOException
        {
        return get_Storage().loadResource(sName);
        }
    public byte[] loadResourceSignature(String sName)
            throws java.io.IOException
        {
        return get_Storage().loadResourceSignature(sName);
        }
    public com.tangosol.dev.component.Component loadSignature(String sName)
            throws com.tangosol.dev.component.ComponentException
        {
        return get_Storage().loadSignature(sName);
        }
    public void removeComponent(String sName)
            throws com.tangosol.dev.component.ComponentException
        {
        get_Storage().removeComponent(sName);
        }
    public void removeResourceSignature(String sName)
            throws java.io.IOException
        {
        get_Storage().removeResourceSignature(sName);
        }
    public void storeClass(com.tangosol.dev.assembler.ClassFile clz, String sListing)
            throws com.tangosol.dev.component.ComponentException
        {
        get_Storage().storeClass(clz, sListing);
        }
    public void storeComponent(com.tangosol.dev.component.Component cd, com.tangosol.util.ErrorList errlist)
            throws com.tangosol.dev.component.ComponentException
        {
        get_Storage().storeComponent(cd, errlist);
        }
    public void storeResource(String sName, byte[] abData)
            throws java.io.IOException
        {
        get_Storage().storeResource(sName, abData);
        }
    public void storeResourceSignature(String sName, byte[] abData)
            throws java.io.IOException
        {
        get_Storage().storeResourceSignature(sName, abData);
        }
    public void storeSignature(com.tangosol.dev.component.Component jcs)
            throws com.tangosol.dev.component.ComponentException
        {
        get_Storage().storeSignature(jcs);
        }
    //-- com.tangosol.dev.component.Storage integration
    
    // Declared at the super level
    public void _imports()
        {
        // import com.tangosol.dev.component.Storage as _Storage;
        
        

        }
    
    /**
    * Close this storage and releas all resources.
    * 
    * TODO: add this method to the Storage interface -- right now it's used by
    * JarStorage to release the jar file
    */
    public void close()
        {
        set_Storage(null);
        }
    
    /**
    * Helper method collecting all the "Library" substorages for this storage
    * at the specified list.
    */
    public void collectLibraries(java.util.List list)
        {
        _Storage _storage = get_Storage();
        if (_storage instanceof Storage)
            {
            ((Storage) _storage).collectLibraries(list);
            }

        }
    
    /**
    * Copy the specified component and all its subcomponents to the destination
    * storage.
    * 
    * @param sName the name of the component to start copying from
    * @param destination the destination storage to copy the components to
    * @param errlist an error list used to accumulate any resolution/extraction
    * errors
    */
    public void copyAllComponents(String sName, Storage destination, com.tangosol.util.ErrorList errlist)
            throws com.tangosol.dev.component.ComponentException
        {
        // import com.tangosol.util.StringTable;
        
        copyComponent(sName, destination, errlist);
        
        StringTable tblSubs = getSubComponents(sName, true);
        if (!tblSubs.isEmpty())
            {
            String[] asSub = tblSubs.strings();
            int      cSubs = asSub.length;
            for (int i = 0; i < cSubs; i++)
                {
                copyComponent(asSub[i], destination, errlist);
                }
            }
        }
    
    /**
    * Copy the specified component to the destination storage.
    * 
    * @param sName the name of the component to start copying from
    * @param destination the destination storage to copy the components to
    * @param errlist an error list used to accumulate any resolution/extraction
    * errors
    */
    private void copyComponent(String sName, Storage destination, com.tangosol.util.ErrorList errlist)
            throws com.tangosol.dev.component.ComponentException
        {
        // import com.tangosol.dev.component.Component;
        
        Component cd = loadComponent(sName, true, errlist);
        if (cd != null)
            {
            destination.storeComponent(cd, errlist);
            }
        }
    
    // Accessor for the property "_Storage"
    /**
    * Getter for property _Storage.<p>
    */
    public com.tangosol.dev.component.Storage get_Storage()
        {
        _Storage _storage = __m__Storage;
        if (_storage == null)
            {
            _storage = instantiate_Storage();
            set_Storage(_storage);
            }
        return _storage;
        }
    
    /**
    * Returns a StringTable with qualified names for the entire tree of
    * sub-components for the specified component.
    * 
    * @param sName  fully qualified component name
    */
    public com.tangosol.util.StringTable getAllSubComponents(String sName)
        {
        // import com.tangosol.util.StringTable;
        // import java.util.Enumeration;
        
        StringTable tblTree = getSubComponents(sName, true);
        if (!tblTree.isEmpty())
            {
            StringTable tblOrg = (StringTable) tblTree.clone();
            for (Enumeration enum = tblOrg.keys(); enum.hasMoreElements();)
                {
                String sSub = (String) enum.nextElement();
                tblTree.addAll(getAllSubComponents(sSub));
                }
            }
        return tblTree;

        }
    
    // Accessor for the property "ClassPath"
    /**
    * Returns the path that have to be added to the CLASSPATH (System property
    * "java.class.path") in order to be able to access classes managed by this
    * Storage. Subclasses should implement this method accordingly.
    */
    public String getClassPath()
        {
        return null;
        }
    
    /**
    * Get the exist flag for the specified Component at this storage. The
    * values are:
    * (see com.tangosol.dev.component.Constants)
    * 
    * EXISTS_UPDATE - the specified component has the modification or
    * derivation stored at this storage
    * EXISTS_INSERT - the specified component doesn't have neither modification
    * nor derivation stored at this storage, but there is a storage that
    * belongs to the same project (domain) that does have
    * EXISTS_NOT - none of the storages that belong to this project (domain)
    * have any modification nor derivation for the specified component, but one
    * of the base projects does
    * EXISTS_DELETE - this component has been deleted (not implemented yet)
    * 
    * @param sName fully qualified component name
    */
    public void getExists(String sName)
        {
        throw new UnsupportedOperationException("TODO: do we need this");
        }
    
    // Accessor for the property "Locator"
    /**
    * Getter for property Locator.<p>
    * The locator object assosiated with this storage. Note: this property is
    * only applicable to persistent (non-synthetic) storages.
    */
    public Object getLocator()
        {
        // import com.tangosol.dev.component.BaseStorage;
        
        _Storage _storage = get_Storage();
        
        if (_storage instanceof BaseStorage)
            {
            return ((BaseStorage) _storage).getLocator();
            }
        else if (_storage instanceof Storage)
            {
            return ((Storage) _storage).getLocator();
            }
        else
            {
            throw new UnsupportedOperationException(
                "getLocator: " + this);
            }

        }
    
    // Accessor for the property "PackageDir"
    /**
    * Getter for property PackageDir.<p>
    * (Calculated) Specifies the directory to use by the packager to put the
    * produced packages
    */
    public java.io.File getPackageDir()
        {
        return null;
        }
    
    protected com.tangosol.dev.component.Storage instantiate_Storage()
        {
        return null;
        }
    
    // Accessor for the property "ReadOnly"
    /**
    * Getter for property ReadOnly.<p>
    * Specifies whether this storage is a read only.
    */
    public boolean isReadOnly()
        {
        _Storage _storage = get_Storage();
        return _storage instanceof Storage ? ((Storage) _storage).isReadOnly() : false;

        }
    
    /**
    * Walk the storage tree (right to left) and find a persistent storage (Jar
    * or OS) that has the specified locator
    * 
    * @param oLocator locator object to look for. If null then any persistent
    * storage should match
    * 
    * @return the Storage that has the locator matching the specified locator;
    * null if such a storage could not be found
    */
    public Storage locatePersistentStorage(Object oLocator)
        {
        // import com.tangosol.dev.component.BaseStorage;
        
        _Storage _storage = get_Storage();
        
        if (_storage instanceof BaseStorage)
            {
            Object oLocatorThis = ((BaseStorage) _storage).getLocator();
            return oLocator == null || oLocator.equals(oLocatorThis) ? this : null;
            }
        else if (_storage instanceof Storage)
            {
            return ((Storage) _storage).locatePersistentStorage(oLocator);
            }
        else
            {
            throw new UnsupportedOperationException("locateStorage: " + this);
            }

        }
    
    // Accessor for the property "_Storage"
    /**
    * Setter for property _Storage.<p>
    */
    public void set_Storage(com.tangosol.dev.component.Storage p_Storage)
        {
        __m__Storage = p_Storage;
        }
    
    // Accessor for the property "Locator"
    /**
    * Setter for property Locator.<p>
    * The locator object assosiated with this storage. Note: this property is
    * only applicable to persistent (non-synthetic) storages.
    */
    public void setLocator(Object pLocator)
        {
        // import com.tangosol.dev.component.BaseStorage;
        
        _Storage _storage = get_Storage();
        
        if (_storage instanceof BaseStorage)
            {
            ((BaseStorage) _storage).setLocator(pLocator);
            }
        else if (_storage instanceof Storage)
            {
            ((Storage) _storage).setLocator(pLocator);
            }
        else
            {
            throw new UnsupportedOperationException(
                "setLocator: " + this);
            }

        }
    
    // Declared at the super level
    public String toString()
        {
        _Storage _storage = get_Storage();
        
        return _storage == null ?
            super.toString() : _storage.toString();
        }
    }
