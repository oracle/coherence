/* Class
*     _package.component.dev.project.ProjectInfo$Target
*/

package _package.component.dev.project;

import com.tangosol.run.xml.SimpleElement;
import com.tangosol.run.xml.XmlElement;
import com.tangosol.util.ListMap;
import java.util.ArrayList;
import java.util.Iterator;

/**
* Target represents a point (version, customization, localization) in
* multi-dimensional space of project targets.
*/
public class ProjectInfo$Target
        extends    _package.Component
        implements com.tangosol.run.xml.XmlSerializable
    {
    // Fields declarations
    
    /**
    * Property BaseTargets
    *
    * Array of qualified target names for the base projects
    */
    private String[] __m_BaseTargets;
    
    /**
    * Property Customization
    *
    * Name of the Customization for this project target
    */
    private String __m_Customization;
    
    /**
    * Property CustomizationRef
    *
    */
    private transient PointInfo __m_CustomizationRef;
    
    /**
    * Property Description
    *
    * Description for this project target
    */
    private String __m_Description;
    
    /**
    * Property LibraryList
    *
    * List of Library components defined for this project target
    */
    private com.tangosol.util.ListMap __m_LibraryList;
    
    /**
    * Property Localization
    *
    * Name of the Localization for this target
    */
    private String __m_Localization;
    
    /**
    * Property LocalizationRef
    *
    */
    private transient PointInfo __m_LocalizationRef;
    
    /**
    * Property Locked
    *
    * Specifies whether or not this target is closed to modifications
    */
    private boolean __m_Locked;
    
    /**
    * Property Name
    *
    * Name of this project target
    */
    private String __m_Name;
    
    /**
    * Property ProjectInfo
    *
    * Helper property returning the parent ProjectInfo component
    */
    
    /**
    * Property QualifiedName
    *
    * Fully qualified name of this target in the following format:
    * <ProjectName> : <TargetName>
    */
    
    /**
    * Property StorageInfo
    *
    * Storage info for this target [module]
    */
    private com.tangosol.run.xml.XmlElement __m_StorageInfo;
    
    /**
    * Property Version
    *
    * Name of the Version for this target
    */
    private String __m_Version;
    
    /**
    * Property VersionRef
    *
    */
    private transient PointInfo __m_VersionRef;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Library", ProjectInfo$Target$Library.get_CLASS());
        }
    
    // Default constructor
    public ProjectInfo$Target()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ProjectInfo$Target(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        
        // state initialization: private properties
        try
            {
            __m_LibraryList = new com.tangosol.util.ListMap();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ProjectInfo$Target();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/project/ProjectInfo$Target".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof $Target)
            {
            $Target that = ($Target) obj;
        
            return this.getQualifiedName().equals(that.getQualifiedName());
            }
        return false;
        }
    
    // From interface: com.tangosol.run.xml.XmlSerializable
    public void fromXml(com.tangosol.run.xml.XmlElement xml)
        {
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.util.ListMap;
        // import java.util.ArrayList;
        // import java.util.Iterator;
        
        _assert(xml.getName().equals(get_Name()));
        
        setName         (xml.getSafeElement("Name")         .getString());
        setDescription  (xml.getSafeElement("Description")  .getString());
        setVersion      (xml.getSafeElement("Version")      .getString());
        setCustomization(xml.getSafeElement("Customization").getString());
        setLocalization (xml.getSafeElement("Localization") .getString());
        setLocked       (xml.getSafeElement("Locked")       .getBoolean());
        
        XmlElement xmlBaseTargets = xml.getSafeElement("BaseTargets");
        ArrayList  listTargets    = new ArrayList();
        for (Iterator iter = xmlBaseTargets.getElements("TargetRef"); iter.hasNext();)
            {
            XmlElement elTargetRef = (XmlElement) iter.next();
            String     sTargetRef  = elTargetRef.getString();
            if (sTargetRef.length() > 0)
                {
                listTargets.add(sTargetRef);
                }
            }
        setBaseTargets((String[]) listTargets.toArray(new String[listTargets.size()]));
        
        setStorageInfo((XmlElement) xml.getSafeElement("StorageInfo").clone());
        
        ListMap listLib = getLibraryList();
        listLib.clear();
        for (Iterator iter = xml.getElements("Library"); iter.hasNext();)
            {
            $Library lib = ($Library) _newChild("Library");
            lib.fromXml((XmlElement) iter.next());
        
            listLib.put(lib.getName(), lib);
            }
        }
    
    // Accessor for the property "BaseTargets"
    /**
    * Getter for property BaseTargets.<p>
    * Array of qualified target names for the base projects
    */
    public String[] getBaseTargets()
        {
        return __m_BaseTargets;
        }
    
    // Accessor for the property "BaseTargets"
    /**
    * Getter for property BaseTargets.<p>
    * Array of qualified target names for the base projects
    */
    public String getBaseTargets(int pIndex)
        {
        return getBaseTargets()[pIndex];
        }
    
    // Accessor for the property "Customization"
    /**
    * Getter for property Customization.<p>
    * Name of the Customization for this project target
    */
    public String getCustomization()
        {
        return __m_Customization;
        }
    
    // Accessor for the property "CustomizationRef"
    /**
    * Getter for property CustomizationRef.<p>
    */
    public PointInfo getCustomizationRef()
        {
        return __m_CustomizationRef;
        }
    
    // Accessor for the property "Description"
    /**
    * Getter for property Description.<p>
    * Description for this project target
    */
    public String getDescription()
        {
        return __m_Description;
        }
    
    // Accessor for the property "LibraryList"
    /**
    * Getter for property LibraryList.<p>
    * List of Library components defined for this project target
    */
    public com.tangosol.util.ListMap getLibraryList()
        {
        return __m_LibraryList;
        }
    
    // Accessor for the property "Localization"
    /**
    * Getter for property Localization.<p>
    * Name of the Localization for this target
    */
    public String getLocalization()
        {
        return __m_Localization;
        }
    
    // Accessor for the property "LocalizationRef"
    /**
    * Getter for property LocalizationRef.<p>
    */
    public PointInfo getLocalizationRef()
        {
        return __m_LocalizationRef;
        }
    
    // Accessor for the property "Name"
    /**
    * Getter for property Name.<p>
    * Name of this project target
    */
    public String getName()
        {
        return __m_Name;
        }
    
    // Accessor for the property "ProjectInfo"
    /**
    * Getter for property ProjectInfo.<p>
    * Helper property returning the parent ProjectInfo component
    */
    public ProjectInfo getProjectInfo()
        {
        return (ProjectInfo) get_Parent();
        }
    
    // Accessor for the property "QualifiedName"
    /**
    * Getter for property QualifiedName.<p>
    * Fully qualified name of this target in the following format:
    * <ProjectName> : <TargetName>
    */
    public String getQualifiedName()
        {
        ProjectInfo project = getProjectInfo();
        
        String sPrj = project == null ? "" : project.getName();
        
        return sPrj + ':' + getName();
        }
    
    // Accessor for the property "StorageInfo"
    /**
    * Getter for property StorageInfo.<p>
    * Storage info for this target [module]
    */
    public com.tangosol.run.xml.XmlElement getStorageInfo()
        {
        // import com.tangosol.run.xml.SimpleElement;
        // import com.tangosol.run.xml.XmlElement;
        
        XmlElement info = __m_StorageInfo;
        if (info == null)
            {
            info = new SimpleElement("StorageInfo");
            setStorageInfo(info);
            }
        return info;
        }
    
    // Accessor for the property "Version"
    /**
    * Getter for property Version.<p>
    * Name of the Version for this target
    */
    public String getVersion()
        {
        return __m_Version;
        }
    
    // Accessor for the property "VersionRef"
    /**
    * Getter for property VersionRef.<p>
    */
    public PointInfo getVersionRef()
        {
        return __m_VersionRef;
        }
    
    // Accessor for the property "Locked"
    /**
    * Getter for property Locked.<p>
    * Specifies whether or not this target is closed to modifications
    */
    public boolean isLocked()
        {
        return __m_Locked;
        }
    
    // Accessor for the property "BaseTargets"
    /**
    * Setter for property BaseTargets.<p>
    * Array of qualified target names for the base projects
    */
    public void setBaseTargets(String[] pBaseTargets)
        {
        __m_BaseTargets = pBaseTargets;
        }
    
    // Accessor for the property "BaseTargets"
    /**
    * Setter for property BaseTargets.<p>
    * Array of qualified target names for the base projects
    */
    public void setBaseTargets(int pIndex, String pBaseTargets)
        {
        getBaseTargets()[pIndex] = pBaseTargets;
        }
    
    // Accessor for the property "Customization"
    /**
    * Setter for property Customization.<p>
    * Name of the Customization for this project target
    */
    public void setCustomization(String pCustomization)
        {
        __m_Customization = pCustomization;
        }
    
    // Accessor for the property "CustomizationRef"
    /**
    * Setter for property CustomizationRef.<p>
    */
    public void setCustomizationRef(PointInfo pCustomizationRef)
        {
        __m_CustomizationRef = pCustomizationRef;
        }
    
    // Accessor for the property "Description"
    /**
    * Setter for property Description.<p>
    * Description for this project target
    */
    public void setDescription(String pDescription)
        {
        __m_Description = pDescription;
        }
    
    // Accessor for the property "LibraryList"
    /**
    * Setter for property LibraryList.<p>
    * List of Library components defined for this project target
    */
    private void setLibraryList(com.tangosol.util.ListMap pLibraryList)
        {
        __m_LibraryList = pLibraryList;
        }
    
    // Accessor for the property "Localization"
    /**
    * Setter for property Localization.<p>
    * Name of the Localization for this target
    */
    public void setLocalization(String pLocalization)
        {
        __m_Localization = pLocalization;
        }
    
    // Accessor for the property "LocalizationRef"
    /**
    * Setter for property LocalizationRef.<p>
    */
    public void setLocalizationRef(PointInfo pLocalizationRef)
        {
        __m_LocalizationRef = pLocalizationRef;
        }
    
    // Accessor for the property "Locked"
    /**
    * Setter for property Locked.<p>
    * Specifies whether or not this target is closed to modifications
    */
    public void setLocked(boolean pLocked)
        {
        __m_Locked = pLocked;
        }
    
    // Accessor for the property "Name"
    /**
    * Setter for property Name.<p>
    * Name of this project target
    */
    public void setName(String pName)
        {
        __m_Name = pName;
        }
    
    // Accessor for the property "StorageInfo"
    /**
    * Setter for property StorageInfo.<p>
    * Storage info for this target [module]
    */
    public void setStorageInfo(com.tangosol.run.xml.XmlElement pStorageInfo)
        {
        __m_StorageInfo = pStorageInfo;
        }
    
    // Accessor for the property "Version"
    /**
    * Setter for property Version.<p>
    * Name of the Version for this target
    */
    public void setVersion(String pVersion)
        {
        __m_Version = pVersion;
        }
    
    // Accessor for the property "VersionRef"
    /**
    * Setter for property VersionRef.<p>
    */
    public void setVersionRef(PointInfo pVersionRef)
        {
        __m_VersionRef = pVersionRef;
        }
    
    /**
    * Helper method returning the HTML description for this target
    */
    public String toHTML()
        {
        // import java.util.Iterator;
        
        StringBuffer sb = new StringBuffer("<html>");
        
        sb.append("SubProject: <b>")
          .append(getName());
        
        if (isLocked())
            {
            sb.append(" -- Locked");
            }  
        
        $Version version = ($Version) getVersionRef();
        
        sb.append("</b><p>")
          .append(getDescription())
          .append("<p><p>Version: <b>")
          .append(getVersion())
          .append("</b><p>Customization: <b>")
          .append(getCustomization())
          .append("</b><p>Localization: <b>")
          .append(getLocalization())
          .append("</b><p>BaseVersion: <b>")
          .append(version.getBaseName())
          .append("</b><p>BaseProject: <b>");
        
        String[] asBase = getBaseTargets();
        for (int i = 0; i < asBase.length; i++)
            {
            if (i > 0)
                {
                sb.append(", ");
                }
            sb.append(asBase[i]);
            }
        
        sb.append("</b><p>Library: <b>");
        
        Iterator iter = getLibraryList().keySet().iterator(); 
        for (int i = 0; iter.hasNext(); i++)
            {
            if (i > 0)
                {
                sb.append(", ");
                }
            sb.append((String) iter.next());
            }
        
        sb.append("</b><p>");
        
        return sb.toString();

        }
    
    // From interface: com.tangosol.run.xml.XmlSerializable
    public com.tangosol.run.xml.XmlElement toXml()
        {
        // import com.tangosol.run.xml.SimpleElement;
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.util.ListMap;
        // import java.util.Iterator;
        
        SimpleElement xml = new SimpleElement(get_Name());
        
        xml.addElement("Name")         .setString(getName());
        xml.addElement("Description")  .setString(getDescription());
        xml.addElement("Version")      .setString(getVersion());
        xml.addElement("Customization").setString(getCustomization());
        xml.addElement("Localization") .setString(getLocalization());
        xml.addElement("Locked")       .setBoolean(isLocked());
        
        String[] asBaseTargets = getBaseTargets();
        if (asBaseTargets != null)
            {
            XmlElement xmlBaseTargets = xml.addElement("BaseTargets");
            
            for (int i = 0; i < asBaseTargets.length; i++)
                {
                xmlBaseTargets.addElement("TargetRef").setString(asBaseTargets[i]);
                }
            }
        
        xml.getElementList().add(getStorageInfo());
        
        ListMap listLib = getLibraryList();
        if (!listLib.isEmpty())
            {
            for (Iterator iter = listLib.values().iterator(); iter.hasNext();)
                {
                xml.getElementList().add((($Library) iter.next()).toXml());
                }
            }
        
        return xml;

        }
    }
