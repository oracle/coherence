/* Class
*     _package.component.dev.project.StorageFactory
*/

package _package.component.dev.project;

import _package.component.dev.Storage;
import _package.component.dev.project.PointInfo;
import _package.component.dev.project.ProjectInfo$Target$Library; // as Library
import _package.component.dev.project.ProjectInfo$Target; // as Target
import _package.component.dev.project.ProjectInfo$Version; // as Version
import _package.component.dev.project.ProjectInfo;
import _package.component.dev.project.ProjectInfo; // as Project
import _package.component.dev.project.storageFactory.OSFactory;
import _package.component.dev.storage.ChainStorage;
import _package.component.dev.storage.DeltaStorage;
import _package.component.dev.storage.NullStorage;
import com.tangosol.util.ListMap;
import java.net.PasswordAuthentication; // as User
import java.net.URL;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
* StorageFactory is a factory for Storage implementations
*/
public abstract class StorageFactory
        extends    _package.component.dev.Project
    {
    // Fields declarations
    
    /**
    * Property HomeUrl
    *
    * The home URL for this storage factory
    */
    private java.net.URL __m_HomeUrl;
    
    /**
    * Property Projects
    *
    */
    
    /**
    * Property User
    *
    */
    private java.net.PasswordAuthentication __m_User;
    
    // Initializing constructor
    public StorageFactory(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/project/StorageFactory".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Create a new project with the specified name and base-line version
    * 
    * @exception WrapperException wrapping an original exception (IOException)
    * is thrown if operation fails
    */
    public ProjectInfo createProject(String sProject, String sBaseVersion)
        {
        // import Component.Dev.Project.ProjectInfo as Project;
        // import Component.Dev.Project.ProjectInfo$Target  as Target;
        // import Component.Dev.Project.ProjectInfo$Version as Version;
        // import java.util.Date;
        
        boolean fExists = false;
        try
            {
            fExists = loadProjectInfo(sProject) != null;
            }
        catch (Exception e) {}
        
        if (fExists)
            {
            throw new IllegalStateException("Project already exists: " + sProject);
            }
        
        String sBaseTarget = sBaseVersion;
        
        Project project = new ProjectInfo();
        
        Version version = project.addVersion(sBaseVersion, "");
        Target  target  = project.addTarget(sBaseTarget, version, null, null);
        
        version.setDescription("Base-line version");
        target .setDescription("Base-line subproject created on " + new Date());
        
        project.setName(sProject);
        project.setDefaultTargetName(target.getName());
        
        return project;
        }
    
    /**
    * Get the chained storage for the specifed project name
    * 
    * @param sProject  project identifier in a format <ProjectName> (':'
    * <TargetName>)
    * @param fReadOnly  if true, the storage could be optimized out for write
    * operations
    */
    protected _package.component.dev.Storage getChainedStorage(String sProject, boolean fReadOnly)
        {
        // import Component.Dev.Project.PointInfo;
        // import Component.Dev.Project.ProjectInfo;
        // import Component.Dev.Project.ProjectInfo$Target as Target;
        // import Component.Dev.Storage;
        // import Component.Dev.Storage.ChainStorage;
        
        // <Project> ::= <ProjectName> ':' <TargetName>
         
        int    of      = sProject.indexOf(':');
        String sDomain = of < 0 ? sProject : sProject.substring(0, of);
        String sTarget = of < 0 ? ""       : sProject.substring(of + 1);
        
        ProjectInfo info = loadProjectInfo(sDomain);
        if (info == null)
            {
            throw new IllegalArgumentException("Invalid project: " + sDomain);
            }
        
        // find the target
        Target targetTop = info.getTarget(sTarget);
        if (targetTop == null)
            {
            throw new IllegalArgumentException("Invalid sub-project: " + sProject);
            }
        
        // build the chain of the module storages for this project
        Storage storeTop   = getTargetStorage(targetTop, true, fReadOnly);
        Storage storeCurr  = storeTop;
        Target  targetCurr = targetTop;
        
        while (true)
            {
            Target targetPrev = info.getPreviousTarget(targetCurr, targetTop);
            if (targetPrev == null)
                {
                break;
                }
        
            PointInfo cCurr = targetCurr.getCustomizationRef();
            PointInfo lCurr = targetCurr.getLocalizationRef();
            PointInfo cPrev = targetPrev.getCustomizationRef();
            PointInfo lPrev = targetPrev.getLocalizationRef();
            
            Storage storePrev = getTargetStorage(targetPrev, false, true);
            boolean fOverride = (cPrev == null ? cCurr == null : cPrev.equals(cCurr)) &&
                                (lPrev == null ? lCurr == null : lPrev.equals(lCurr));
        
            ChainStorage storeChain = new ChainStorage();
            storeChain.setBase(storePrev);
            storeChain.setDelta(storeCurr);
            storeChain.setOverride(fOverride);
        
            storeCurr  = storeChain;
            targetCurr = targetPrev;
            }
        
        // link to the base projects
        String[] asBaseProject = targetTop.getBaseTargets();
        int      cBaseProjects = asBaseProject == null ? 0 : asBaseProject.length;
        
        for (int i = 0; i < cBaseProjects; i++)
            {
            String  sBase = asBaseProject[i];
            _assert(!sBase.equals(sProject) && sBase.length() > 0);
        
            Storage storePrev = getChainedStorage(sBase, true);
            boolean fOverride = false;
        
            ChainStorage storeChain  = new ChainStorage();
            storeChain.setBase(storePrev);
            storeChain.setDelta(storeCurr);
            storeChain.setOverride(fOverride);
        
            storeCurr = storeChain;
            }
        
        return storeCurr;

        }
    
    // Accessor for the property "HomeUrl"
    public java.net.URL getHomeUrl()
        {
        return __m_HomeUrl;
        }
    
    /**
    * Get the module (atomic unit of) storage for the specifed project target
    * and the specified library.
    * If the library is not specified, the target location is used; otherwise
    * the library location is.
    * 
    * Note: location could represent one of:
    *     - url
    *     - absolute path
    *     - relative path
    *    - composite path (!-delimited)
    * It could also contain substitutable parameters in parenthesis (i.e.
    * {java.home}/lib/rt.jar)
    * 
    * @param target  project target info
    * @param library  external library design info (or null for the Component
    * storage)
    * @param fReadOnly  if true, the storage could be optimized out for write
    * operations
    * 
    * @return storage for the target module or null if the storage could be
    * optimized out
    */
    protected _package.component.dev.Storage getModuleStorage(ProjectInfo$Target target, ProjectInfo$Target$Library library, boolean fReadOnly)
        {
        return null;
        }
    
    // Accessor for the property "Projects"
    /**
    * Get all available project names for this factory
    */
    public String[] getProjects()
        {
        return null;
        }
    
    // Accessor for the property "Projects"
    public String getProjects(int pIndex)
        {
        return getProjects()[pIndex];
        }
    
    /**
    * Get the project storage for the specifed project name
    * 
    * @param sProject  project identifier in a format <ProjectName> (':'
    * <TargetName>)
    * 
    * 
    * @exception WrapperException wrapping an original exception is thrown if
    * the operation fails
    */
    public _package.component.dev.Storage getProjectStorage(String sProject)
        {
        // import Component.Dev.Storage.DeltaStorage;
        
        // wrap the chained storage with a delta resolver/extractor
        DeltaStorage delta = new DeltaStorage();
        delta.setActualStorage(getChainedStorage(sProject, false));
        
        return delta;

        }
    
    /**
    * Get the storage for the specifed project target
    * 
    * @param target  project target info
    * @param fTop true if the target specifies the top level target; false
    * otherwis
    * @param fReadOnly  if true, the storage could be optimized out for write
    * operations
    */
    protected _package.component.dev.Storage getTargetStorage(ProjectInfo$Target target, boolean fTop, boolean fReadOnly)
        {
        // import Component.Dev.Project.ProjectInfo$Target$Library as Library;
        // import Component.Dev.Storage;
        // import Component.Dev.Storage.ChainStorage;
        // import Component.Dev.Storage.NullStorage;
        // import com.tangosol.util.ListMap;
        // import java.util.Iterator;
        // import java.util.LinkedList;
        // import java.util.List;
        
        LinkedList listStores = new LinkedList();
        ListMap    listLibs   = target.getLibraryList();
        
        // libraries are processed only for the top level target
        if (fTop)
            {
            for (Iterator iter = listLibs.values().iterator(); iter.hasNext();)
                {
                Library lib = (Library) iter.next();
        
                listStores.add(getModuleStorage(target, lib, true));
                }
            }
        
        // components
            {
            listStores.add(getModuleStorage(target, null, fReadOnly));
            }
        
        Storage storeTarget = null;
        
        for (Iterator iter = listStores.iterator(); iter.hasNext();)
            {
            Storage store = (Storage) iter.next();
        
            if (store != null)
                {
                if (storeTarget == null)
                    {
                    storeTarget = store;
                    }
                else
                    {
                    ChainStorage storeChain = new ChainStorage();
                    storeChain.setBase(storeTarget);
                    storeChain.setDelta(store);
                    storeChain.setOverride(false);
        
                    storeTarget = storeChain;
                    }
                }
            }
        
        return storeTarget == null ? new NullStorage() : storeTarget;
        }
    
    // Accessor for the property "User"
    public java.net.PasswordAuthentication getUser()
        {
        return __m_User;
        }
    
    /**
    * Instantates a new project storage factory for the specified URL and user.
    */
    public static StorageFactory instantiate(String sUrl, String sPrincipal, char[] acCredentials)
            throws java.io.IOException
        {
        // import Component.Dev.Project.StorageFactory.OSFactory;
        // import java.net.PasswordAuthentication as User;
        // import java.net.URL;
        
        StorageFactory factory = null;
        
        URL  url  = new URL(sUrl);
        User user = new User(sPrincipal, acCredentials);
        
        if (url.getProtocol().equals("file"))
            {
            // local
            factory = new OSFactory();
            }
        else if (url.getProtocol().equals("jar"))
            {
            // jar file
            }
        else
            {
            // remote
            }
        
        if (factory != null)
            {
            factory.setHomeUrl(url);
            factory.setUser(user);
            }
        
        return factory;
        }
    
    /**
    * Loads the project info for the specified project name
    * 
    * @param sProject project name
    * 
    * @return the project info
    * 
    * @exception WrapperException wrapping an original exception (IOException
    * or SAXException) is thrown if the operation fails
    */
    public ProjectInfo loadProjectInfo(String sProject)
        {
        return null;
        }
    
    // Accessor for the property "HomeUrl"
    protected void setHomeUrl(java.net.URL pHomeUrl)
            throws java.io.IOException
        {
        __m_HomeUrl = pHomeUrl;
        }
    
    // Accessor for the property "User"
    protected void setUser(java.net.PasswordAuthentication pUser)
        {
        __m_User = pUser;
        }
    
    /**
    * Saves the specified project info
    * 
    * @exception WrapperException wrapping an original exception (IOException)
    * is thrown if the operation fails
    */
    public void storeProjectInfo(ProjectInfo info)
        {
        }
    }
