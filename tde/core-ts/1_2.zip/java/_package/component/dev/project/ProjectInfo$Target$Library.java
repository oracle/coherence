/* Class
*     _package.component.dev.project.ProjectInfo$Target$Library
*/

package _package.component.dev.project;

import com.tangosol.dev.component.Constants;
import com.tangosol.run.xml.SimpleElement;
import com.tangosol.run.xml.XmlElement;

/**
* Library component carries the information about the input library used by the
* [parent] project target
*/
public class ProjectInfo$Target$Library
        extends    _package.Component
        implements com.tangosol.run.xml.XmlSerializable
    {
    // Fields declarations
    
    /**
    * Property Customizable
    *
    * Specifies the library customizability attribute. Value of false means
    * that the classes that belong to this library may not be open for the
    * customization.
    */
    private boolean __m_Customizable;
    
    /**
    * Property Description
    *
    * Library description
    */
    private String __m_Description;
    
    /**
    * Property Name
    *
    * Library name
    */
    private String __m_Name;
    
    /**
    * Property StorageInfo
    *
    * Storage information for this library
    */
    private com.tangosol.run.xml.XmlElement __m_StorageInfo;
    
    /**
    * Property TargetInfo
    *
    * Helper property returning the parent Target component
    */
    
    /**
    * Property Visibility
    *
    * Specifies the library visibility attribute.
    * Valid values of the visbility attribute are defined by
    * com.tangosol.dev.component.Constants:
    * 
    * Constants.VIS_SYSTEM
    * Constants.VIS_HIDDEN
    * Constants.VIS_ADVANCED
    * Constants.VIS_VISIBLE
    */
    private int __m_Visibility;
    
    // Default constructor
    public ProjectInfo$Target$Library()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ProjectInfo$Target$Library(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ProjectInfo$Target$Library();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/project/ProjectInfo$Target$Library".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent();
        }
    
    public static String convertVisibility(int nVisible)
        {
        // import com.tangosol.dev.component.Constants;
        
        switch (nVisible)
            {
            case Constants.VIS_SYSTEM:
                return "system";
            case Constants.VIS_HIDDEN:
                return "hidden";
            case Constants.VIS_ADVANCED:
                return "advanced";
            case Constants.VIS_VISIBLE:
            default:
                return "standard";
            }
        }
    
    public static int convertVisibility(String sVisible)
        {
        // import com.tangosol.dev.component.Constants;
        
        if (sVisible.equalsIgnoreCase("system"))
            {
            return Constants.VIS_SYSTEM;
            }
        else if (
            sVisible.equalsIgnoreCase("hidden"))
            {
            return Constants.VIS_HIDDEN;
            }
        else if (
            sVisible.equalsIgnoreCase("advanced"))
            {
            return Constants.VIS_ADVANCED;
            }
        else // sVisible.equalsIgnoreCase("standard")
            {
            return Constants.VIS_VISIBLE;
            }
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof $Library)
            {
            $Library that = ($Library) obj;
        
            return this.getName().equals(that.getName()) &&
                   this.getTargetInfo().equals(that.getTargetInfo());
            }
        return false;
        }
    
    // From interface: com.tangosol.run.xml.XmlSerializable
    public void fromXml(com.tangosol.run.xml.XmlElement xml)
        {
        // import com.tangosol.run.xml.XmlElement;
        
        _assert(xml.getName().equals(get_Name()));
        
        setName        (xml.getSafeElement("Name")        .getString());
        setDescription (xml.getSafeElement("Description") .getString());
        setCustomizable(xml.getSafeElement("Customizable").getBoolean(true));
        setVisibility  (convertVisibility(
                        xml.getSafeElement("Visibility")  .getString()));
        setStorageInfo((XmlElement) xml.getSafeElement("StorageInfo").clone());
        }
    
    // Accessor for the property "Description"
    public String getDescription()
        {
        return __m_Description;
        }
    
    // Accessor for the property "Name"
    public String getName()
        {
        return __m_Name;
        }
    
    // Accessor for the property "StorageInfo"
    public com.tangosol.run.xml.XmlElement getStorageInfo()
        {
        // import com.tangosol.run.xml.SimpleElement;
        // import com.tangosol.run.xml.XmlElement;
        
        XmlElement info = __m_StorageInfo;
        if (info == null)
            {
            info = new SimpleElement("StorageInfo");
            setStorageInfo(info);
            }
        return info;
        }
    
    // Accessor for the property "TargetInfo"
    public ProjectInfo$Target getTargetInfo()
        {
        return ($Target) get_Parent();
        }
    
    // Accessor for the property "Visibility"
    public int getVisibility()
        {
        return __m_Visibility;
        }
    
    // Accessor for the property "Customizable"
    public boolean isCustomizable()
        {
        return __m_Customizable;
        }
    
    // Accessor for the property "Customizable"
    public void setCustomizable(boolean pCustomizable)
        {
        __m_Customizable = pCustomizable;
        }
    
    // Accessor for the property "Description"
    public void setDescription(String pDescription)
        {
        __m_Description = pDescription;
        }
    
    // Accessor for the property "Name"
    public void setName(String pName)
        {
        __m_Name = pName;
        }
    
    // Accessor for the property "StorageInfo"
    public void setStorageInfo(com.tangosol.run.xml.XmlElement pStorageInfo)
        {
        __m_StorageInfo = pStorageInfo;
        }
    
    // Accessor for the property "Visibility"
    public void setVisibility(int pVisibility)
        {
        __m_Visibility = pVisibility;
        }
    
    // From interface: com.tangosol.run.xml.XmlSerializable
    public com.tangosol.run.xml.XmlElement toXml()
        {
        // import com.tangosol.run.xml.SimpleElement;
        // import com.tangosol.run.xml.XmlElement;
        
        SimpleElement xml = new SimpleElement(get_Name());
        
        xml.addElement("Name")        .setString (getName());
        xml.addElement("Description") .setString (getDescription());
        xml.addElement("Customizable").setBoolean(isCustomizable());
        xml.addElement("Visibility")  .setString (convertVisibility(getVisibility()));
        xml.getElementList().add(getStorageInfo());
        
        return xml;
        }
    }
