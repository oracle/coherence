/* Class
*     _package.component.dev.project.ProjectInfo
*/

package _package.component.dev.project;

import _package.component.dev.project.PointInfo;
import com.tangosol.run.xml.SimpleElement;
import com.tangosol.run.xml.XmlElement;
import com.tangosol.util.ListMap;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
* This component represents the model for the Project definition that is used
* by the StorageFactory and project management tools
*/
public class ProjectInfo
        extends    _package.component.dev.Project
        implements com.tangosol.run.xml.XmlSerializable
    {
    // Fields declarations
    
    /**
    * Property CustomizationList
    *
    * List of Customizations objects for this project
    */
    private com.tangosol.util.ListMap __m_CustomizationList;
    
    /**
    * Property DefaultTarget
    *
    * Helper property specifying the default project target.
    */
    
    /**
    * Property DefaultTargetName
    *
    * The name of the project target to be taken if it's not explicitely
    * specified.
    */
    private String __m_DefaultTargetName;
    
    /**
    * Property Description
    *
    * Project description
    */
    private String __m_Description;
    
    /**
    * Property LocalizationList
    *
    * List of Localization objects for this project
    */
    private com.tangosol.util.ListMap __m_LocalizationList;
    
    /**
    * Property Name
    *
    * Project (domain) name
    */
    private String __m_Name;
    
    /**
    * Property StorageInfo
    *
    * Transient StorageInfo for this project (used by StorageFactory)
    */
    private transient com.tangosol.run.xml.XmlElement __m_StorageInfo;
    
    /**
    * Property TargetList
    *
    * List of Target objects for this project
    */
    private com.tangosol.util.ListMap __m_TargetList;
    
    /**
    * Property VersionList
    *
    * List of Version objects for this project
    */
    private com.tangosol.util.ListMap __m_VersionList;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Customization", ProjectInfo$Customization.get_CLASS());
        __mapChildren.put("Localization", ProjectInfo$Localization.get_CLASS());
        __mapChildren.put("Target", ProjectInfo$Target.get_CLASS());
        __mapChildren.put("Version", ProjectInfo$Version.get_CLASS());
        }
    
    // Default constructor
    public ProjectInfo()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ProjectInfo(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        
        // state initialization: private properties
        try
            {
            __m_CustomizationList = new com.tangosol.util.ListMap();
            __m_LocalizationList = new com.tangosol.util.ListMap();
            __m_TargetList = new com.tangosol.util.ListMap();
            __m_VersionList = new com.tangosol.util.ListMap();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ProjectInfo();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/project/ProjectInfo".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    /**
    * Helper method adding a new Customization object to the customization list.
    */
    public ProjectInfo$Customization addCustomization(String sName, String sBaseName)
        {
        // import com.tangosol.util.ListMap;
        
        ListMap list = getCustomizationList();
        
        if (sBaseName.length() != 0 && !list.containsKey(sBaseName))
            {
            throw new IllegalArgumentException("Customization doesn't exists: " + sBaseName);
            }
        
        if (list.containsKey(sName))
            {
            throw new IllegalArgumentException("Customization already exists: " + sName);
            }
        
        $Customization c = ($Customization) _newChild("Customization");
        c.setName(sName);
        c.setBaseName(sBaseName);
        
        list.put(sName, c);
        
        validateDimension(list);
        
        return c;

        }
    
    /**
    * Helper method adding a new Localization object to the localization list.
    */
    public ProjectInfo$Localization addLocalization(String sName, String sBaseName)
        {
        // import com.tangosol.util.ListMap;
        
        ListMap list = getLocalizationList();
        
        if (sBaseName.length() != 0 && !list.containsKey(sBaseName))
            {
            throw new IllegalArgumentException("Localization doesn't exists: " + sBaseName);
            }
        
        if (list.containsKey(sName))
            {
            throw new IllegalArgumentException("Localization already exists: " + sName);
            }
        
        $Localization l = ($Localization) _newChild("Localization");
        l.setName(sName);
        l.setBaseName(sBaseName);
        
        list.put(sName, l);
        
        validateDimension(list);
        
        return l;

        }
    
    /**
    * Helper method adding a new Target object for the specified version,
    * customization and localization to the target list
    */
    public ProjectInfo$Target addTarget(String sName, PointInfo version, PointInfo customization, PointInfo localization)
        {
        // import com.tangosol.run.xml.XmlElement;
        // import java.util.Date;
        // import java.util.Iterator;
        
        $Target target = getTarget(version, customization, localization);
        
        _assert(target == null, "Target already exists " + target);
        _assert(version != null, "Version must be specified");
        
        target = ($Target) _newChild("Target");
        
        target.setName(sName);
        target.setVersion(version.getName());
        target.setCustomization(customization == null ? "" : customization.getName());
        target.setLocalization (localization  == null ? "" : localization .getName());
        
        getTargetList().put(sName, target);
        
        validateTargets();
        
        $Target targetPrev = getPreviousTarget(target, target);
        if (targetPrev != null)
            {
            // copy the base targets
            target.setBaseTargets(targetPrev.getBaseTargets());
            
            // copy all the libraries
            for (Iterator iter = targetPrev.getLibraryList().values().iterator(); iter.hasNext();)
                {
                $Library libPrev = ($Library) iter.next();
                $Library lib     = ($Library) target._newChild("Library");
        
                lib.setName       (libPrev.getName());
                lib.setDescription(libPrev.getDescription());
                lib.setStorageInfo((XmlElement) libPrev.getStorageInfo().clone());
        
                target.getLibraryList().put(lib.getName(), lib);
                }    
            }
        return target;

        }
    
    /**
    * Helper method adding a new Version object to the version list.
    */
    public ProjectInfo$Version addVersion(String sName, String sBaseName)
        {
        // import com.tangosol.util.ListMap;
        
        ListMap list = getVersionList();
        
        if (sBaseName.length() == 0)
            {
            if (!list.isEmpty())
                {
                throw new IllegalArgumentException("Base-line version already exists");
                }
            }
        else
            {
            if (!list.containsKey(sBaseName))
                {
                throw new IllegalArgumentException("Version doesn't exists: " + sBaseName);
                }
            }
        
        if (list.containsKey(sName))
            {
            throw new IllegalArgumentException("Version already exists: " + sName);
            }
        
        $Version v = ($Version) _newChild("Version");
        v.setName(sName);
        v.setBaseName(sBaseName);
        
        list.put(v.getName(), v);
        
        validateDimension(list);
        
        return v;

        }
    
    // From interface: com.tangosol.run.xml.XmlSerializable
    public void fromXml(com.tangosol.run.xml.XmlElement xml)
        {
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.util.ListMap;
        // import java.util.Iterator;
        
        if (!xml.getName().equals("Project"))
            {
            throw new IllegalStateException("Invalid XmlElement name " + xml.getName());
            }
        
        setName             (xml.getSafeElement("Name")         .getString());
        setDescription      (xml.getSafeElement("Description")  .getString());
        setDefaultTargetName(xml.getSafeElement("DefaultTarget").getString());
        
        setStorageInfo((XmlElement) xml.getSafeElement("StorageInfo").clone());
        
        // TargetList
            {
            XmlElement xmlList = xml.getElement("TargetList");
            ListMap    list    = getTargetList();
        
            list.clear();
            for (Iterator iter = xmlList.getElements("Target"); iter.hasNext();)
                {
                $Target target = ($Target) _newChild("Target");
                target.fromXml((XmlElement) iter.next());
        
                list.put(target.getName(), target);
                }
            if (list.isEmpty())
                {
                // throw new IllegalStateException("Missing Target elements");
                }
            }
        
        // VersionList
            {
            XmlElement xmlList = xml.getElement("VersionList");
            ListMap    list    = getVersionList();
        
            list.clear();
            for (Iterator iter = xmlList.getElements("Version"); iter.hasNext();)
                {
                $Version version = ($Version) _newChild("Version");
                version.fromXml((XmlElement) iter.next());
        
                list.put(version.getName(), version);
                }
        
            if (list.isEmpty())
                {
                throw new IllegalStateException("Missing Version elements");
                }
            }
        
        // CustomizationList
            {
            XmlElement xmlList = xml.getElement("CustomizationList");
            ListMap    list    = getCustomizationList();
        
            list.clear();
            for (Iterator iter = xmlList.getElements("Customization"); iter.hasNext();)
                {
                $Customization customization = ($Customization) _newChild("Customization");
                customization.fromXml((XmlElement) iter.next());
        
                list.put(customization.getName(), customization);
                }
            }
        
        // LocalizationList
            {
            XmlElement xmlList = xml.getElement("LocalizationList");
            ListMap   list     = getLocalizationList();
        
            for (Iterator iter = xmlList.getElements("Localization"); iter.hasNext();)
                {
                $Localization localization = ($Localization) _newChild("Localization");
                localization.fromXml((XmlElement) iter.next());
        
                list.put(localization.getName(), localization);
                }
            }
        
        validateTargets();
        }
    
    /**
    * Helper method
    */
    public ProjectInfo$Customization getCustomization(String sName)
        {
        // import java.util.Iterator;
        
        for (Iterator iter = getCustomizationList().values().iterator(); iter.hasNext();)
            {
            $Customization c = ($Customization) iter.next();
            
            if (c.getName().equals(sName))
                {
                return c;
                }
            }
        
        return null;
        }
    
    // Accessor for the property "CustomizationList"
    public com.tangosol.util.ListMap getCustomizationList()
        {
        return __m_CustomizationList;
        }
    
    // Accessor for the property "DefaultTarget"
    public ProjectInfo$Target getDefaultTarget()
        {
        return getTarget(null);
        }
    
    // Accessor for the property "DefaultTargetName"
    public String getDefaultTargetName()
        {
        return __m_DefaultTargetName;
        }
    
    // Accessor for the property "Description"
    public String getDescription()
        {
        return __m_Description;
        }
    
    /**
    * Helper method
    */
    public ProjectInfo$Localization getLocalization(String sName)
        {
        // import java.util.Iterator;
        
        for (Iterator iter = getLocalizationList().values().iterator(); iter.hasNext();)
            {
            $Localization l = ($Localization) iter.next();
            
            if (l.getName().equals(sName))
                {
                return l;
                }
            }
        
        return null;
        }
    
    // Accessor for the property "LocalizationList"
    public com.tangosol.util.ListMap getLocalizationList()
        {
        return __m_LocalizationList;
        }
    
    // Accessor for the property "Name"
    public String getName()
        {
        return __m_Name;
        }
    
    /**
    * For the point in the multi-dimensional space of projects defined by the
    * specified target get the project that immediately preceeds that point
    * (toward lower version number), given the specified top target
    */
    public ProjectInfo$Target getPreviousTarget(ProjectInfo$Target target, ProjectInfo$Target targetTop)
        {
        // import Component.Dev.Project.PointInfo;
        
        PointInfo l = target.getLocalizationRef();
        PointInfo c = target.getCustomizationRef();
        PointInfo v = target.getVersionRef();
        
        boolean fSkip = true;
        
        while (true)
            {
            while (true)
                {
                while (true)
                    {
                    if (fSkip)
                        {
                        fSkip = false;
                        }
                    else
                        {
                        $Target targetPrev = getTarget(v, c, l);
                        if (targetPrev != null)
                            {
                            return targetPrev;
                            }
                        }
        
                    v = v.getBasePoint();
                    if (v == null)
                        {
                        v = targetTop.getVersionRef();
                        break;
                        }
                    }
        
                if (c == null)
                    {
                    c = targetTop.getCustomizationRef();
                    break;
                    }
                c = c.getBasePoint();
                }
        
            if (l == null)
                {
                break;
                }
            l = l.getBasePoint();
            }
        
        return null;
        }
    
    // Accessor for the property "StorageInfo"
    public com.tangosol.run.xml.XmlElement getStorageInfo()
        {
        // import com.tangosol.run.xml.SimpleElement;
        // import com.tangosol.run.xml.XmlElement;
        
        XmlElement info = __m_StorageInfo;
        if (info == null)
            {
            info = new SimpleElement("StorageInfo");
            setStorageInfo(info);
            }
        return info;
        }
    
    /**
    * Helper method
    */
    public ProjectInfo$Target getTarget(String sName)
        {
        // import java.util.Iterator;
        
        if (sName == null || sName.length() == 0)
            {
            sName = getDefaultTargetName();
            }
        
        for (Iterator iter = getTargetList().values().iterator(); iter.hasNext();)
            {
            $Target target = ($Target) iter.next();
            
            if (target.getName().equals(sName))
                {
                return target;
                }
            }
        
        return null;
        }
    
    /**
    * Get project target for the specified version, customization and
    * localization
    */
    public ProjectInfo$Target getTarget(PointInfo version, PointInfo customization, PointInfo localization)
        {
        // import Component.Dev.Project.PointInfo;
        // import java.util.Iterator;
        
        for (Iterator iter = getTargetList().values().iterator(); iter.hasNext();)
            {
            $Target target = ($Target) iter.next();
        
            PointInfo v = target.getVersionRef();
            PointInfo c = target.getCustomizationRef();
            PointInfo l = target.getLocalizationRef();
            
            if (v.equals(version)
             && (c == null ? customization == null : c.equals(customization))
             && (l == null ? localization  == null : l.equals(localization))
                )
                {
                return target;
                }
            }
        
        return null;
        }
    
    // Accessor for the property "TargetList"
    public com.tangosol.util.ListMap getTargetList()
        {
        return __m_TargetList;
        }
    
    /**
    * Helper method
    */
    public ProjectInfo$Version getVersion(String sName)
        {
        // import java.util.Iterator;
        
        for (Iterator iter = getVersionList().values().iterator(); iter.hasNext();)
            {
            $Version V = ($Version) iter.next();
            
            if (V.getName().equals(sName))
                {
                return V;
                }
            }
        
        return null;
        }
    
    // Accessor for the property "VersionList"
    public com.tangosol.util.ListMap getVersionList()
        {
        return __m_VersionList;
        }
    
    // Accessor for the property "CustomizationList"
    private void setCustomizationList(com.tangosol.util.ListMap pCustomizationList)
        {
        __m_CustomizationList = pCustomizationList;
        }
    
    // Accessor for the property "DefaultTargetName"
    public void setDefaultTargetName(String pDefaultTargetName)
        {
        __m_DefaultTargetName = pDefaultTargetName;
        }
    
    // Accessor for the property "Description"
    public void setDescription(String pDescription)
        {
        __m_Description = pDescription;
        }
    
    // Accessor for the property "LocalizationList"
    private void setLocalizationList(com.tangosol.util.ListMap pLocalizationList)
        {
        __m_LocalizationList = pLocalizationList;
        }
    
    // Accessor for the property "Name"
    public void setName(String pName)
        {
        __m_Name = pName;
        }
    
    // Accessor for the property "StorageInfo"
    public void setStorageInfo(com.tangosol.run.xml.XmlElement pStorageInfo)
        {
        __m_StorageInfo = pStorageInfo;
        }
    
    // Accessor for the property "TargetList"
    private void setTargetList(com.tangosol.util.ListMap pTargetList)
        {
        __m_TargetList = pTargetList;
        }
    
    // Accessor for the property "VersionList"
    private void setVersionList(com.tangosol.util.ListMap pVersionList)
        {
        __m_VersionList = pVersionList;
        }
    
    /**
    * Helper method returning the HTML description for this project
    */
    public String toHTML()
        {
        StringBuffer sb = new StringBuffer("<html>");
        
        sb.append("Project: <b>")
          .append(getName())
          .append("</b><p>")
          .append(getDescription())
          .append("<p><p>Default SubProject:<p><b>")
          .append(getDefaultTargetName());
        
        $Target target = getDefaultTarget();
        if (target == null)
            {
            sb.append(" -- Invalid");
            }
        else if (target.isLocked())
            {
            sb.append(" -- Locked");
            }
        sb.append("</b>");
          
        return sb.toString();
        }
    
    // From interface: com.tangosol.run.xml.XmlSerializable
    public com.tangosol.run.xml.XmlElement toXml()
        {
        // import com.tangosol.run.xml.SimpleElement;
        // import com.tangosol.run.xml.XmlElement;
        // import java.util.Iterator;
        // import java.util.List;
        
        SimpleElement xml = new SimpleElement("Project");
        
        xml.addElement("Name")         .setString(getName());
        xml.addElement("Description")  .setString(getDescription());
        xml.addElement("DefaultTarget").setString(getDefaultTargetName());
        
        xml.getElementList().add(getStorageInfo());
        
        // TargetList
            {
            List listEl = xml.addElement("TargetList").getElementList();
            for (Iterator iter = getTargetList().values().iterator(); iter.hasNext();)
                {
                listEl.add((($Target) iter.next()).toXml());
                }
            }
        
        // VersionList
            {
            List listEl = xml.addElement("VersionList").getElementList();
            for (Iterator iter = getVersionList().values().iterator(); iter.hasNext();)
                {
                listEl.add((($Version) iter.next()).toXml());
                }
            }
        
        // CustomizationList
            {
            List listEl = xml.addElement("CustomizationList").getElementList();
            for (Iterator iter = getCustomizationList().values().iterator(); iter.hasNext();)
                {
                listEl.add((($Customization) iter.next()).toXml());
                }
            }
        
        // LocalizationList
            {
            List listEl = xml.addElement("LocalizationList").getElementList();
            for (Iterator iter = getLocalizationList().values().iterator(); iter.hasNext();)
                {
                listEl.add((($Localization) iter.next()).toXml());
                }
            }
        
        return xml;

        }
    
    /**
    * Validates the structure of the dimension tree represented a list-map of
    * named references
    */
    protected void validateDimension(com.tangosol.util.ListMap list)
        {
        // import Component.Dev.Project.PointInfo;
        // import com.tangosol.util.ListMap;
        // import java.util.Iterator;
        
        if (!list.isEmpty())
            {
            for (Iterator iter = list.values().iterator(); iter.hasNext();)
                {
                PointInfo point = (PointInfo) iter.next();
        
                String sBase = point.getBaseName();
                if (sBase.length() > 0)
                    {
                    PointInfo pointBase = (PointInfo) list.get(sBase);
                    if (pointBase == null)
                        {
                        throw new IllegalStateException("Invalid base for point " + point);
                        }
                    point.setBasePoint(pointBase);
                    }
                }
            }
        }
    
    /**
    * Validates the data retrived from an Xml descriptor
    */
    protected void validateTargets()
        {
        // import com.tangosol.util.ListMap;
        // import java.util.Iterator;
        
        // walk the Version, Customization and Localization list to validate
        // and put the "BasePoint" references
        
        ListMap listV = getVersionList();
        ListMap listC = getCustomizationList();
        ListMap listL = getLocalizationList();
        
        validateDimension(listV);
        validateDimension(listC);
        validateDimension(listL);
        
        // walk the Target list to validate 
        ListMap listRef = getTargetList();
        for (Iterator iter = listRef.values().iterator(); iter.hasNext();)
            {
            $Target ref = ($Target) iter.next();
        
            String sV = ref.getVersion();
            String sC = ref.getCustomization();
            String sL = ref.getLocalization();
            
            $Version       v = ($Version)       listV.get(sV);
            $Customization c = ($Customization) listC.get(sC);
            $Localization  l = ($Localization)  listL.get(sL);
        
            if (v == null ||
                sC.length() > 0 && c == null ||
                sL.length() > 0 && l == null)
                {
                throw new IllegalStateException("Invalid reference " + ref);
                }
        
            ref.setVersionRef      (v);
            ref.setCustomizationRef(c);
            ref.setLocalizationRef (l);
            }

        }
    }
