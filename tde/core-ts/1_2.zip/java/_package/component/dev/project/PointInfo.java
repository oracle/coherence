/* Class
*     _package.component.dev.project.PointInfo
*/

package _package.component.dev.project;

import com.tangosol.run.xml.SimpleElement;

/**
* This component represents a model for a point on one of the axis (version,
* customization and localization) in multi-dimensional space of project targets.
*/
public class PointInfo
        extends    _package.component.dev.Project
        implements com.tangosol.run.xml.XmlSerializable
    {
    // Fields declarations
    
    /**
    * Property BaseName
    *
    * Base point name
    */
    private String __m_BaseName;
    
    /**
    * Property BasePoint
    *
    * Base point
    */
    private transient PointInfo __m_BasePoint;
    
    /**
    * Property Description
    *
    * Point description
    */
    private String __m_Description;
    
    /**
    * Property DimensionName
    *
    * Name of the dimensional axis that this point "lies" along. Currently this
    * value is one of "Version", "Customization" or "Localization"
    */
    
    /**
    * Property DimensionOrder
    *
    * Priority of this point's dimension indicates the order in which order the
    * targets are chained together.
    */
    
    /**
    * Property DimensionOverrideRule
    *
    * If true, the points of this dimension are overriding the base targets; if
    * false - they supplement them
    */
    
    /**
    * Property Name
    *
    * Point name
    */
    private String __m_Name;
    
    // Default constructor
    public PointInfo()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PointInfo(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant DimensionOverrideRule
    public boolean isDimensionOverrideRule()
        {
        return false;
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new PointInfo();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/project/PointInfo".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof PointInfo)
            {
            PointInfo that = (PointInfo) obj;
            return this.getDimensionName().equals(that.getDimensionName()) &&
                   this.getName()         .equals(that.getName());
            }
        return false;
        }
    
    // From interface: com.tangosol.run.xml.XmlSerializable
    public void fromXml(com.tangosol.run.xml.XmlElement xml)
        {
        _assert(xml.getName().equals(getDimensionName()));
        
        setName       (xml.getSafeElement("Name")       .getString());
        setDescription(xml.getSafeElement("Description").getString());
        setBaseName   (xml.getSafeElement("BaseName")   .getString());

        }
    
    // Accessor for the property "BaseName"
    public String getBaseName()
        {
        return __m_BaseName;
        }
    
    // Accessor for the property "BasePoint"
    public PointInfo getBasePoint()
        {
        return __m_BasePoint;
        }
    
    // Accessor for the property "Description"
    public String getDescription()
        {
        return __m_Description;
        }
    
    // Accessor for the property "DimensionName"
    public String getDimensionName()
        {
        return get_Name();
        }
    
    // Accessor for the property "DimensionOrder"
    public float getDimensionOrder()
        {
        return get_Order();
        }
    
    // Accessor for the property "Name"
    public String getName()
        {
        return __m_Name;
        }
    
    // Accessor for the property "BaseName"
    public void setBaseName(String pBaseName)
        {
        __m_BaseName = pBaseName;
        }
    
    // Accessor for the property "BasePoint"
    public void setBasePoint(PointInfo pBasePoint)
        {
        __m_BasePoint = pBasePoint;
        }
    
    // Accessor for the property "Description"
    public void setDescription(String pDescription)
        {
        __m_Description = pDescription;
        }
    
    // Accessor for the property "Name"
    public void setName(String pName)
        {
        __m_Name = pName;
        }
    
    // From interface: com.tangosol.run.xml.XmlSerializable
    public com.tangosol.run.xml.XmlElement toXml()
        {
        // import com.tangosol.run.xml.SimpleElement;
        
        SimpleElement xml = new SimpleElement(getDimensionName());
        
        xml.addElement("Name")       .setString(getName());
        xml.addElement("Description").setString(getDescription());
        xml.addElement("BaseName")   .setString(getBaseName());
        
        return xml;
        }
    }
