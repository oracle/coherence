/* Class
*     _package.component.dev.Tool
*/

package _package.component.dev;

import _package.component.dev.Storage;
import _package.component.dev.tool.Host;
import _package.component.gUI.control.container.jComponent.jPanel.ToolSite;
import com.tangosol.util.ErrorList;

public class Tool
        extends    _package.component.Dev
    {
    // Fields declarations
    
    /**
    * Property ACTION_CLOSE
    *
    * Action name for "Close currently active document" command. Assosiated
    * value is not specified.
    */
    public static final String ACTION_CLOSE = "Close";
    
    /**
    * Property ACTION_CLOSE_ALL
    *
    * Action name for "Close all open documents" command. Assosiated value is
    * not specified.
    */
    public static final String ACTION_CLOSE_ALL = "CloseAll";
    
    /**
    * Property ACTION_COMPILE
    *
    * Action name for "Compile currently active document" command. Assosiated
    * value is not specified.
    */
    public static final String ACTION_COMPILE = "Compile";
    
    /**
    * Property ACTION_COMPILE_TREE
    *
    * Action name for "Compile currently active document and all its
    * dependencies" command. Assosiated value is not specified.
    */
    public static final String ACTION_COMPILE_TREE = "CompileTree";
    
    /**
    * Property ACTION_CREATE
    *
    * Action name for "Create a document" command. Assosiated value (if
    * specified) is a Component.Dev.Util.DocInfo component that is assumed to
    * have the properties Name and Type set accordingly.
    * 
    * Examples:
    * To create a new Component Definition deriving from Control
    *     docInfo.setName("Component.GUI.Control");
    *     dosInfo.setType("Component");
    * 
    * To create a new Integration Map for CoolBean
    *     docInfo.setName("com.thirdparty.CoolBean");
    *     docInfo.setType("Integration");
    */
    public static final String ACTION_CREATE = "Create";
    
    /**
    * Property ACTION_EXIT
    *
    * Action name for "Application Exit" command. Assosiated value is not
    * specified.
    */
    public static final String ACTION_EXIT = "Exit";
    
    /**
    * Property ACTION_INTEGRATE
    *
    * Action name for "Integrate class file(s)" command. Assosiated value (if
    * specified) is an array of java.io.File objects for classes, directories
    * or jars.
    */
    public static final String ACTION_INTEGRATE = "Integrate";
    
    /**
    * Property ACTION_LIBRARY
    *
    * Action name for "Manage Library(s)" command. Assosiated value (if
    * specified) is an array of java.io.File objects for java archives (.jar,
    * .ear, .war)
    */
    public static final String ACTION_LIBRARY = "Library";
    
    /**
    * Property ACTION_LOCATE_ERROR_TAG
    *
    * Action name for "Goto to an error or tag" command. Assosiated value is an
    * Integer with a value of -1, 0 or 1 to specify the previous, current and
    * next error accordingly.
    */
    public static final String ACTION_LOCATE_ERROR_TAG = "LocateErrorTag";
    
    /**
    * Property ACTION_LOCATE_TRAIT
    *
    * Action name for "Locate a Trait" command. Assosiated value is a
    * Component.Dev.Util.TraitLocator object.
    */
    public static final String ACTION_LOCATE_TRAIT = "LocateTrait";
    
    /**
    * Property ACTION_OPEN
    *
    * Action name for "Open a document" command. Assosiated value (if
    * specified) is either DocInfo component that is assumed to have the
    * properties Name and Type set accordingly or a "document" object itself
    * (i.e. Component Definition).
    */
    public static final String ACTION_OPEN = "Open";
    
    /**
    * Property ACTION_OPEN_WITH
    *
    * Action name for "Open a resource with..." command. Assosiated value (if
    * specified) is either DocInfo component that is assumed to have the
    * properties Name and Type set accordingly or a "document" object itself
    * (i.e. Resource Signature).
    */
    public static final String ACTION_OPEN_WITH = "OpenWith";
    
    /**
    * Property ACTION_PACKAGE
    *
    * Action name for "Package an application" command. Assosiated value is not
    * specified. 
    */
    public static final String ACTION_PACKAGE = "Package";
    
    /**
    * Property ACTION_PROJECT_CLOSE
    *
    * Action name for "Close the current Project" command. Assosiated value is
    * not specified.
    */
    public static final String ACTION_PROJECT_CLOSE = "CloseProject";
    
    /**
    * Property ACTION_PROJECT_NEW
    *
    * Action name for "Open a new project" command. Assosiated value is not
    * specified.
    */
    public static final String ACTION_PROJECT_NEW = "NewProject";
    
    /**
    * Property ACTION_PROJECT_OPEN
    *
    * Action name for "Open a new project" command. Assosiated value is not
    * specified.
    */
    public static final String ACTION_PROJECT_OPEN = "OpenProject";
    
    /**
    * Property ACTION_REFRESH
    *
    * Action name for "Refresh a view" command. The assosiated value could be
    * equal to "Components" (to refresh the Components view) or "Classes" (to
    * refresh the Classes view)
    */
    public static final String ACTION_REFRESH = "Refresh";
    
    /**
    * Property ACTION_REMOVE
    *
    * Action name for "Remove a document" command. Assosiated value (if
    * specified) is either DocInfo component that is assumed to have the
    * properties Name and Type set accordingly or a "document" object itself
    * (i.e. Component Definition).
    */
    public static final String ACTION_REMOVE = "Remove";
    
    /**
    * Property ACTION_SAVE
    *
    * Action name for "Save currently active document" command. Assosiated
    * value is not specified.
    */
    public static final String ACTION_SAVE = "Save";
    
    /**
    * Property ACTION_SAVE_ALL
    *
    * Action name for "Save all currently open documents" command. Assosiated
    * value is not specified.
    */
    public static final String ACTION_SAVE_ALL = "SaveAll";
    
    /**
    * Property ACTION_SAVE_AS
    *
    * Action name for "Rename and save currently active document" command.
    * Assosiated value (if specified) is a DocInfo component that is assumed to
    * have the properties Name and Type set accordingly.
    */
    public static final String ACTION_SAVE_AS = "SaveAs";
    
    /**
    * Property ACTION_SEARCH
    *
    * Action name for "Search for a pattern" command. Assosiated value is a
    * Config object containing at least the following attributes:
    *     - "Pattern"
    *     - "Words" (for word search)
    *     - "Case" (for case sensitive search)
    *     - "RegExp" (for regular expressions)
    * 
    * @see JPanel.FindText#saveConfig
    */
    public static final String ACTION_SEARCH = "Search";
    
    /**
    * Property ACTION_SERVER_RELOAD
    *
    * Action name for "Reload Application to a Server" command. Assosiated
    * value is not specified.
    */
    public static final String ACTION_SERVER_RELOAD = "ReloadServer";
    
    /**
    * Property ACTION_TEST_RUN
    *
    * Action name for "TestRun a component" command. Assosiated value (if
    * specified) is a DocInfo component that is assumed to have the properties
    * Name and Type set accordingly.
    */
    public static final String ACTION_TEST_RUN = "TestRun";
    
    /**
    * Property ACTION_VIEW
    *
    * Action name for "View a tool" command. Assosiated value is an array of
    * two Objects:
    * value[0] = (String) ToolName (assumed to be unique)
    * value[1] = (Boolean) ShowFlag
    */
    public static final String ACTION_VIEW = "View";
    
    /**
    * Property ACTION_VIEW_FILTER
    *
    * Action name for "Change a View Filter" command. Assosiated value is an
    * Integer object holding on the new filter value, which is a bitwise "OR"
    * of the following constants (com.tangosol.dev.component.Constants):
    *     - VIS_VISIBLE
    *     - VIS_ADVANCED
    *     - VIS_HIDDEN
    *     - VIS_SYSTEM
    *     - EXISTS_INSERT
    */
    public static final String ACTION_VIEW_FILTER = "ViewFilter";
    
    /**
    * Property Active
    *
    * Specifies whether this tool is currently active or makes it active.
    */
    private transient boolean __m_Active;
    
    /**
    * Property CloseCanceled
    *
    * (Calculated) Specifies whether the close operation should be canceled.
    */
    
    /**
    * Property ErrorList
    *
    * List of errors for this tool.
    */
    private transient com.tangosol.util.ErrorList __m_ErrorList;
    
    /**
    * Property Host
    *
    * (Calculated) Specifies this tool's host.
    */
    
    /**
    * Property Modified
    *
    * (Calculated) Specifies whether this tool knows of any changes that have
    * been made to the [persistable] data maintained by this tool.
    */
    
    /**
    * Property Open
    *
    * Specifies whether this tool is currently open or opens it.
    */
    private transient boolean __m_Open;
    
    /**
    * Property Storage
    *
    */
    private transient Storage __m_Storage;
    
    /**
    * Property Title
    *
    * Specifies this tool's title.
    */
    private String __m_Title;
    
    /**
    * Property ToolHandle
    *
    * Specifies a MenuItem or JButton component that controls the "active"
    * state of the tool (tool site)
    * 
    * @see Host#addTool
    * @see ComponentDesigner#addToolHandle
    */
    private transient _package.component.gUI.control.container.jComponent.AbstractButton __m_ToolHandle;
    
    /**
    * Property ToolHandleText
    *
    * Specifies the text to be used on a tool handle for this tool. If not
    * specified, the Title of the tool will be used.
    */
    private String __m_ToolHandleText;
    
    /**
    * Property ToolSite
    *
    * Specifies this tool's "view".
    */
    private transient _package.component.gUI.control.container.jComponent.jPanel.ToolSite __m_ToolSite;
    
    /**
    * Property ToolSiteClass
    *
    */
    private transient Class __m_ToolSiteClass;
    
    // Default constructor
    public Tool()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Tool(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Tool();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/Tool".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.Dev.Tool.Host;
        // import Component.Dev.Storage;
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite;
        

        }
    
    /**
    * Notify the host (which could in turn notify a containing host) that there
    * has been an action at this tool that could be of the interest for any of
    * the containing hosts.
    * 
    * @param sName  action name
    * @param oValue  associated value
    * 
    * @see onToolAction
    */
    public void fireToolAction(String sAction, Object oValue)
        {
        fireToolAction(this, sAction, oValue);
        }
    
    /**
    * Notify the host (which could in turn notify a containing host) that there
    * has been an action at the specified tool that could be of the interest
    * for any of the containing hosts.
    * 
    * @param tool  tool that has originated this action
    * @param sName  action name
    * @param oValue  associated value
    * 
    * @see onToolAction
    */
    protected void fireToolAction(Tool tool, String sAction, Object oValue)
        {
        Host host = getHost();
        if (host != null)
            {
            host.onToolAction(tool, sAction, oValue);
            }
        }
    
    // Accessor for the property "ErrorList"
    /**
    * Getter for property ErrorList.<p>
    * List of errors for this tool.
    */
    public com.tangosol.util.ErrorList getErrorList()
        {
        // import com.tangosol.util.ErrorList;
        
        ErrorList errList = __m_ErrorList;
        if (errList == null)
            {
            setErrorList(errList = new ErrorList());
            }
        return errList;
        }
    
    // Accessor for the property "Host"
    /**
    * Getter for property Host.<p>
    * (Calculated) Specifies this tool's host.
    */
    public _package.component.dev.tool.Host getHost()
        {
        return (Host) get_Parent();
        }
    
    // Accessor for the property "Storage"
    /**
    * Getter for property Storage.<p>
    */
    public Storage getStorage()
        {
        Storage store = __m_Storage;
        
        if (store == null)
            {
            Host host = getHost();
            return host == null ? null : host.getStorage();
            }
        else
            {
            return store;
            }
        }
    
    // Accessor for the property "Title"
    /**
    * Getter for property Title.<p>
    * Specifies this tool's title.
    */
    public String getTitle()
        {
        return __m_Title;
        }
    
    // Accessor for the property "ToolHandle"
    /**
    * Getter for property ToolHandle.<p>
    * Specifies a MenuItem or JButton component that controls the "active"
    * state of the tool (tool site)
    * 
    * @see Host#addTool
    * @see ComponentDesigner#addToolHandle
    */
    public _package.component.gUI.control.container.jComponent.AbstractButton getToolHandle()
        {
        return __m_ToolHandle;
        }
    
    // Accessor for the property "ToolHandleText"
    /**
    * Getter for property ToolHandleText.<p>
    * Specifies the text to be used on a tool handle for this tool. If not
    * specified, the Title of the tool will be used.
    */
    public String getToolHandleText()
        {
        String sText = __m_ToolHandleText;
        return sText == null ? getTitle() : sText;
        }
    
    // Accessor for the property "ToolSite"
    /**
    * Getter for property ToolSite.<p>
    * Specifies this tool's "view".
    */
    public _package.component.gUI.control.container.jComponent.jPanel.ToolSite getToolSite()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ToolSite;
        
        ToolSite site = __m_ToolSite;
        if (site == null)
            {
            Class clzSite = getToolSiteClass();
            if (clzSite != null)
                {
                try
                    {
                    site = (ToolSite) clzSite.newInstance();
                    }
                catch (RuntimeException e)
                    {
                    throw e;
                    }
                catch (Exception e) //InstantiationException, IllegalAccessException
                    {
                    _trace("Cannot instantiate the tool site for " + getTitle() +
                        ": " + e);
                    }
                setToolSite(site);
                }
            }
        return site;
        }
    
    // Accessor for the property "ToolSiteClass"
    /**
    * Getter for property ToolSiteClass.<p>
    */
    public Class getToolSiteClass()
        {
        return __m_ToolSiteClass;
        }
    
    /**
    * Return true if the specified action fired by the specified host is
    * enabled by this tool; false otherwise.
    * The hosts additionally return true if at least one child tool of this
    * host "enables" this action.
    * 
    * This method is mostly used by host sites' menus to provide a visual clue
    * to the question:
    *  - If this host issues a command (host action), will there be any tool
    * being able to process this command
    * 
    * When the host is specified, the specified action is expected to be fired
    * by that host using fireHostAction(). If the host is null, this action is
    * expected to be fired by this tool itself using fireToolAction().
    * 
    * @param sAction  action name
    * @param host  the source of the action
    * @param  oValue an optional value to be passed along
    */
    public boolean isActionEnabled(String sAction, _package.component.dev.tool.Host host, Object oValue)
        {
        // if the tool action anticipated and there is a host, ask it in turn
        return host == null && getHost() != null ?
            getHost().isActionEnabled(sAction, host, oValue) : false;

        }
    
    // Accessor for the property "Active"
    /**
    * @return true is this tool is currently active
    */
    public boolean isActive()
        {
        Host host = getHost();
        
        return host == null ? false : host.getActiveTool() == this;
        }
    
    // Accessor for the property "CloseCanceled"
    /**
    * Returns true if the close operation should be canceled. The assumption
    * is, however, that a tool that does cancel the close operation bears
    * responsibility to notify the user. If a tool sees that some modification
    * could be lost if the close operation is allowed to proceed, but does not
    * want to notify the user on its own, it should  instead override
    * <code>isModified</code> method to return "true".
    * 
    * Default implementation forces the tool site to apply any pending UI
    * changes into the model before returning "false" (allowing the close
    * operation to proceed).
    * 
    * @see #isModified
    */
    public boolean isCloseCanceled()
        {
        // ask the tool site to apply any changes and respond with "I don't mind"
        ToolSite site = getToolSite();
        if (site != null)
            {
            site.apply();
            }
        return false;
        }
    
    // Accessor for the property "Modified"
    /**
    * Returns true if this tool knows of any changes that have been made to the
    * [persistable] data maintained by this tool. If a tool overrides this
    * method (which by default returns "false") and returns "true", it is the
    * host's resposibility to make sure that the <code>save</code> method is
    * called (unless the changes have to be discarded). It is then the tool's
    * responsibility to return "false" right after the <code>save</code> method
    * is invoked.
    */
    public boolean isModified()
        {
        return false;
        }
    
    // Accessor for the property "Open"
    /**
    * Getter for property Open.<p>
    * Specifies whether this tool is currently open or opens it.
    */
    public boolean isOpen()
        {
        return __m_Open;
        }
    
    /**
    * Notification sent when the tool gets closed<p>
    * Note: this method is called before the host is notified with closeTool(),
    * so no relevant host's destruction has been done yet.
    * 
    * @see #setOpen
    * @see Host#closeTool
    */
    public void onClose()
        {
        }
    
    /**
    * Notification send by one of the containing hosts
    * 
    * @param host  the acted host
    * @param sName  action name
    * @param oValue  associated value
    */
    public void onHostAction(_package.component.dev.tool.Host host, String sAction, Object oValue)
        {
        }
    
    /**
    * Notification sent when the tool gets opened.<p>
    * Note: this method is called after the host is notified with openTool(),
    * so all the relevant host's initialization is already done.
    * 
    * @see #setOpen
    * @see Host#openTool
    */
    public void onOpen()
        {
        }
    
    /**
    * Report the errors out of ErrorList for this tool.
    * 
    * Note: this is just a convinience method that passes the control up to the
    * host.
    */
    public void reportErrors()
        {
        Host host = getHost();
        if (host != null)
            {
            host.reportErrors(this);
            }
        }
    
    /**
    * Forces the tool site to apply all UI changes and saves the persistent
    * data that this tool (model) knows about.
    * 
    * Note: the attempt should be made to save all the data even when the
    * operation in whole is failing
    * 
    * @return true if data was successfully saved or there is nothing to save;
    * false otherwise
    */
    public boolean save()
        {
        ToolSite site = getToolSite();
        if (site != null)
            {
            site.apply();
            }
        return true;
        }
    
    // Accessor for the property "Active"
    /**
    * Makes this tool currently active
    */
    public void setActive(boolean pActive)
        {
        Host host = getHost();
        
        if (host != null && pActive)
            {
            host.setActiveTool(this);
            }
        }
    
    // Accessor for the property "ErrorList"
    /**
    * Setter for property ErrorList.<p>
    * List of errors for this tool.
    */
    public void setErrorList(com.tangosol.util.ErrorList pErrorList)
        {
        __m_ErrorList = pErrorList;
        }
    
    // Accessor for the property "Open"
    /**
    * Opens or closes this tool.
    */
    public void setOpen(boolean pOpen)
        {
        if (pOpen == isOpen())
            {
            return;
            }
        
        __m_Open = (pOpen);
        
        if (pOpen)
            {
            if (getHost() != null)
                {
                getHost().openTool(this);
                }
            onOpen();
            }
        else
            {
            onClose();
            if (getHost() != null)
                {
                getHost().closeTool(this);
                }
            }
        }
    
    // Accessor for the property "Storage"
    /**
    * Setter for property Storage.<p>
    */
    public void setStorage(Storage pStorage)
        {
        __m_Storage = pStorage;
        }
    
    // Accessor for the property "Title"
    /**
    * Setter for property Title.<p>
    * Specifies this tool's title.
    */
    public void setTitle(String pName)
        {
        __m_Title = pName;
        }
    
    // Accessor for the property "ToolHandle"
    /**
    * Setter for property ToolHandle.<p>
    * Specifies a MenuItem or JButton component that controls the "active"
    * state of the tool (tool site)
    * 
    * @see Host#addTool
    * @see ComponentDesigner#addToolHandle
    */
    public void setToolHandle(_package.component.gUI.control.container.jComponent.AbstractButton pToolHandle)
        {
        __m_ToolHandle = pToolHandle;
        }
    
    // Accessor for the property "ToolHandleText"
    /**
    * Setter for property ToolHandleText.<p>
    * Specifies the text to be used on a tool handle for this tool. If not
    * specified, the Title of the tool will be used.
    */
    public void setToolHandleText(String pToolHandleText)
        {
        __m_ToolHandleText = pToolHandleText;
        }
    
    // Accessor for the property "ToolSite"
    /**
    * Setter for property ToolSite.<p>
    * Specifies this tool's "view".
    */
    public void setToolSite(_package.component.gUI.control.container.jComponent.jPanel.ToolSite pToolSite)
        {
        __m_ToolSite = (pToolSite);
        pToolSite.setTool(this);
        }
    
    // Accessor for the property "ToolSiteClass"
    /**
    * Setter for property ToolSiteClass.<p>
    */
    public void setToolSiteClass(Class pTToolSite)
        {
        __m_ToolSiteClass = pTToolSite;
        }
    
    // Declared at the super level
    public String toString()
        {
        return "Tool: " + getTitle() + " (" + get_Name() + ')';
        }
    }
