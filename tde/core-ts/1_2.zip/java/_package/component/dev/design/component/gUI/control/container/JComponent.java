/* Class
*     _package.component.dev.design.component.gUI.control.container.JComponent
*/

package _package.component.dev.design.component.gUI.control.container;

import _package.component.gUI.Border;
import _package.component.gUI.Control;
import _package.component.gUI.control.container.JComponent;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.Property;

/**
* +++++++
* 
* This component represents a Component.GUI.Control.Container.JComponent type
* of Component Definition. It is aware of such property of the corresponding
* Component Definition as Border, Opaque.
*/
public class JComponent
        extends    _package.component.dev.design.component.gUI.control.Container
    {
    // Fields declarations
    
    /**
    * Property PD_HorizontalScrollBarPolicy
    *
    */
    
    /**
    * Property PD_VerticalScrollBarPolicy
    *
    */
    
    // Default constructor
    public JComponent()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JComponent(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setRemotable(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant PD_HorizontalScrollBarPolicy
    public String getPD_HorizontalScrollBarPolicy()
        {
        return "Intrinsic.Integer.ScrollBarPolicy.Horizontal";
        }
    
    // Getter for virtual constant PD_VerticalScrollBarPolicy
    public String getPD_VerticalScrollBarPolicy()
        {
        return "Intrinsic.Integer.ScrollBarPolicy.Vertical";
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JComponent();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/component/gUI/control/container/JComponent".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Updates attributes of the specified component holder based on the state
    * of the designee [Component Definition].  Subclasses should overwrite this
    * method extracting and applying values of relevant properties either to
    * the holder itself or to its renderer.
    */
    protected void updateComponentHolder(_package.component.gUI.control.container.jComponent.jPanel.CDHolder holder)
        {
        // import Component.GUI.Border;
        // import Component.GUI.Control;
        // import Component.GUI.Control.Container.JComponent;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Property;
        
        super.updateComponentHolder(holder);
        
        Component cd = holder.getComponent();
        
        Control renderer = holder.getRenderer();
        
        Object oBorder = getPropertyValue(cd, "TBorder");
        if (oBorder != Property.NO_VALUE)
            {
            JComponent jr = renderer instanceof JComponent ? (JComponent) renderer :
                            renderer == null ? holder : null;
        
            if (jr != null)
                {
                JComponent temp = new JComponent();
                temp.setTBorder((String) oBorder);
        
                Border border = temp.getBorder();
                boolean fSame = border == null ? jr.getBorder() == null :
                    border.equals(jr.getBorder());
                if (!fSame)
                    {
                    jr.setBorder(border);
                    }
                }
            }
        
        if (renderer instanceof JComponent)
            {
            Object oOpaque = getPropertyValue(cd, "Opaque");
            ((JComponent) renderer).setOpaque(oOpaque == Property.NO_VALUE ||
                ((Boolean) oOpaque).booleanValue());
            }
        }
    }
