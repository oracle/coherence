/* Class
*     _package.component.dev.design.intrinsic.integer.DnDAction
*/

package _package.component.dev.design.intrinsic.integer;

import java.awt.dnd.DnDConstants;

/**
* @see Component.GUI.Control
*/
public class DnDAction
        extends    _package.component.dev.design.intrinsic.Integer
    {
    // Fields declarations
    private static final String[] __s_TextChoices;
    
    // Static initializer
    static
        {
        try
            {
            String[] a0 = new String[4];
                {
                a0[0] = "None";
                a0[1] = "Copy";
                a0[2] = "Move";
                a0[3] = "Copy&Move";
                }
            __s_TextChoices = a0;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public DnDAction()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public DnDAction(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant Choice
    public boolean isChoice()
        {
        return true;
        }
    
    // Getter for virtual constant TextChoices
    public String[] getTextChoices()
        {
        return (String[]) __s_TextChoices.clone();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new DnDAction();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/intrinsic/integer/DnDAction".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        // import java.awt.dnd.DnDConstants;
        
        Object oValue = super.convertText(sText, dtValue, storage);
        
        if (oValue == VALUE_UNKNOWN)
            {
            String[] asText = getTextChoices();
        
            if (sText.equals(asText[0]))
                {
                oValue = new Integer(DnDConstants.ACTION_NONE);
                }
            else if (sText.equals(asText[1]))
                {
                oValue = new Integer(DnDConstants.ACTION_COPY);
                }
            else if (sText.equals(asText[2]))
                {
                oValue = new Integer(DnDConstants.ACTION_MOVE);
                }
            else if (sText.equals(asText[3]))
                {
                oValue = new Integer(DnDConstants.ACTION_COPY | DnDConstants.ACTION_MOVE);
                }
            }
        
        return oValue;
        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        // import java.awt.dnd.DnDConstants;
        
        if (oValue instanceof Integer)
            {
            String[] asText = getTextChoices();
            
            switch (((Integer) oValue).intValue())
                {
                case DnDConstants.ACTION_NONE:
                    return asText[0];
                case DnDConstants.ACTION_COPY:
                    return asText[1];
                case DnDConstants.ACTION_MOVE:
                    return asText[2];
                case DnDConstants.ACTION_COPY | DnDConstants.ACTION_MOVE:
                    return asText[3];
                }
            }
        
        return super.getText(oValue, dtValue);
        }
    }
