/* Class
*     _package.component.dev.design.intrinsic.Long
*/

package _package.component.dev.design.intrinsic;

public class Long
        extends    _package.component.dev.design.Intrinsic
    {
    // Fields declarations
    
    // Default constructor
    public Long()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Long(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Long();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/intrinsic/Long".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        Object oValue = super.convertText(sText, dtValue, storage);
        
        if (oValue == VALUE_UNKNOWN)
            {
            try
                {
                long lValue = sText.startsWith("0x") ?
                    Long.parseLong(sText.substring(2), 16) : Long.parseLong(sText);
                oValue = new Long(lValue);
                }
            catch (NumberFormatException e) {}
            }
        return oValue;
        }
    
    // Declared at the super level
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        if (super.isTextLegal(sText, dtValue, storage))
            {
            return true;
            }
        
        try
            {
            if (sText.startsWith("0x"))
                {
                Long.parseLong(sText.substring(2), 16);
                }
            else
                {
                Long.parseLong(sText);
                }
            return true;
            }
        catch (NumberFormatException e)
            {
            return false;
            }
        }
    }
