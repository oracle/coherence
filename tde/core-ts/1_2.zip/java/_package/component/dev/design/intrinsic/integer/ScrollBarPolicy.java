/* Class
*     _package.component.dev.design.intrinsic.integer.ScrollBarPolicy
*/

package _package.component.dev.design.intrinsic.integer;

public abstract class ScrollBarPolicy
        extends    _package.component.dev.design.intrinsic.Integer
    {
    // Fields declarations
    private static final String[] __s_TextChoices;
    
    // Static initializer
    static
        {
        try
            {
            String[] a0 = new String[3];
                {
                a0[0] = "As Needed";
                a0[1] = "Never";
                a0[2] = "Always";
                }
            __s_TextChoices = a0;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Initializing constructor
    public ScrollBarPolicy(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant Choice
    public boolean isChoice()
        {
        return true;
        }
    
    // Getter for virtual constant TextChoices
    public String[] getTextChoices()
        {
        return (String[]) __s_TextChoices.clone();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/intrinsic/integer/ScrollBarPolicy".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    }
