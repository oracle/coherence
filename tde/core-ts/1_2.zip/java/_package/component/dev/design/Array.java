/* Class
*     _package.component.dev.design.Array
*/

package _package.component.dev.design;

import _package.component.dev.Design;
import com.tangosol.dev.assembler.CodeAttribute;
import com.tangosol.dev.assembler.Constant;
import com.tangosol.dev.assembler.Dup;
import com.tangosol.dev.assembler.Iconst;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Property;

public class Array
        extends    _package.component.dev.Design
    {
    // Fields declarations
    
    /**
    * Property ArrayDimension
    *
    * (Calculated) Dimension of the design element for this array. (0 means a
    * simple array).
    * 
    */
    
    /**
    * Property DELIMITERS
    *
    * Set of delimiters for element values in the text conversion. A delimiter
    * as position i serves as a delimiter for an appropriate dimension.
    * For example: the value ,;! means that a value of type String[][][] couldl
    * be text formatted as:
    * 
    * a11,a12,a13;a21,a22,a23!b11,b12;b21,b22
    */
    protected static final String DELIMITERS = ",;!";
    
    /**
    * Property ElementDesign
    *
    */
    private _package.component.dev.Design __m_ElementDesign;
    
    // Default constructor
    public Array()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Array(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Array();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/Array".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Generates Java class byte codes for a constant value initialization
    * 
    * @param gen ClassGenerator producing a Java class
    * @param oValue value to generate an initializer for
    * @param dtType data type of the specified value
    * 
    * @throws IllegalArgumentException if the code generation is not possible
    * due to an unknown value [data type]
    * 
    * @see #getValue
    * @see Component.Dev.Compiler.ClassGenerator#addConstantInitializer
    * @see Component.Dev.Compiler.ClassGenerator#addPropertyInitializer
    */
    protected void addArrayConstantInitializer(_package.component.dev.compiler.ClassGenerator gen, Object[] aoValue, com.tangosol.dev.component.DataType dtArray, String sPrefix, String sPostfix)
        {
        // import Component.Dev.Design;
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.Constant;
        // import com.tangosol.dev.assembler.Dup;
        // import com.tangosol.dev.assembler.Iconst;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Property;
        
        CodeAttribute code = gen.getCode();
        
        dtArray = gen.resolveDataType(dtArray);
        
        DataType dtElement  = dtArray.getElementType();
        String   sClass     = gen.formatType(dtArray);
        Object   oDefValue  = gen.getDefaultValue(dtElement);
        Design   designInfo = getElementDesign();
        int      nArraySize = aoValue.length;
        
        // first determine if we will be needing to set any
        // of the array elements
        boolean fSetElements = false;
        for (int i = 0; i < nArraySize; ++i)
            {
            Object oValue = aoValue[i];
            if (oValue != Property.NO_VALUE &&
                oValue != null && !oValue.equals(oDefValue))
                {
                fSetElements = true;
                break;
                }
            }
        
        String sArray = null;
        
        if (!fSetElements)
            {
            gen.print(sPrefix);
            }
        else
            {
            sArray = "a" + gen.getNextTempVariableNumber();
            gen.print(sClass + " " + sArray + " = ");
            }
        
        // size of array to create
        code.add(new Iconst(nArraySize));
        
        // array creation
        code.add(gen.getNewArrayOp(dtElement));
        
        int ofBracket = sClass.indexOf(']');
        gen.print("new " + sClass.substring(0, ofBracket) + nArraySize +
            sClass.substring(ofBracket));
        
        if (!fSetElements)
            {
            gen.print(sPostfix);
            return;
            }
        
        gen.println(";");
        
        gen.BeginScope();
            {
            for (int i = 0; i < nArraySize; ++i)
                {
                Object oValue = aoValue[i];
                if (oValue != Property.NO_VALUE &&
                    oValue != null && !oValue.equals(oDefValue))
                    {
                    // set oValue at index <i>
                    code.add(new Dup());
                    code.add(new Iconst(i));
        
                    designInfo.addConstantInitializer(gen, oValue, dtElement,
                            sArray + "[" + i + "] = ", ";");
        
                    code.add(gen.getArrayOp(dtElement, false));
        
                    gen.println();
                    }
                }
            }
        gen.EndScope();
        
        gen.print(sPrefix + sArray + sPostfix);
        }
    
    /**
    * Converts the specified array of values of a given dimension to a String
    * (usually to be displayed by the Property Sheet) and adds it to the
    * specified StringBuffer.
    * 
    * @param sb  StringBuffer to add the result of conversion to
    * @param aoValue  array of values
    * @param nDim dimension of the specified array
    * @param dtValue  data type of the values
    * 
    * @return true if the convertion is successful; false otherwise
    * 
    * @see #getText
    */
    protected boolean addArrayText(StringBuffer sb, Object[] aoValue, int nDim, com.tangosol.dev.component.DataType dtValue)
        {
        // import Component.Dev.Design;
        // import com.tangosol.dev.component.Property;
        
        if (aoValue == null)
            {
            sb.append(TEXT_NULL);
            return true;
            }
        
        if (aoValue.length == 0)
            {
            return false;
            }
        
        Design designInfo = getElementDesign();
        char   chDelim    = DELIMITERS.charAt(nDim);
        
        dtValue = dtValue.getElementType();
        
        for (int i = 0; i < aoValue.length; i++)
            {
            Object oValue = aoValue[i];
        
            if (oValue == Property.NO_VALUE)
                {
                return false;
                }
        
            if (designInfo instanceof Array)
                {
                if (oValue != null && !(oValue instanceof Object[]))
                    {
                    return false;
                    }
        
                Array arrayInfo = (Array) designInfo;
                if (!arrayInfo.addArrayText(sb, (Object[]) oValue, nDim - 1, dtValue))
                    {
                    return false;
                    }
                }
            else
                {
                sb.append(designInfo.getText(oValue, dtValue));
                }
            sb.append(chDelim);
            }
        
        sb.setLength(sb.length() - 1);
        
        return true;
        }
    
    // Declared at the super level
    /**
    * Generates Java class byte codes for a constant value initialization
    * 
    * @param gen ClassGenerator producing a Java class
    * @param oValue value to generate an initializer for
    * @param dtType data type of the specified value
    * 
    * @throws IllegalArgumentException if the code generation is not possible
    * due to an unknown value [data type]
    * 
    * @see #getValue
    * @see Component.Dev.Compiler.ClassGenerator#addConstantInitializer
    * @see Component.Dev.Compiler.ClassGenerator#addPropertyInitializer
    */
    public void addConstantInitializer(_package.component.dev.compiler.ClassGenerator gen, Object oValue, com.tangosol.dev.component.DataType dtType, String sPrefix, String sPostfix)
        {
        if (oValue == null)
            {
            super.addConstantInitializer(gen, oValue, dtType, sPrefix, sPostfix);
            }
        else
            {
            _assert(dtType.isArray() && oValue instanceof Object[]);
            addArrayConstantInitializer(gen, (Object[]) oValue, dtType, sPrefix, sPostfix);
            }
        }
    
    /**
    * Converts the specified text into an array of values of the specified
    * dimension.
    * 
    * @param sText  text to convert
    * @param nDim  dimention of the array
    * @param dtArray  data type of the array
    * @param store  storage that should be used if necessary
    * 
    * @return a converted array or VALUE_UNKNOWN
    * 
    * @see #convertText
    */
    protected Object convertArrayText(String sText, int nDim, com.tangosol.dev.component.DataType dtArray, _package.component.dev.Storage store)
        {
        // import Component.Dev.Design;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Property;
        
        Design   designInfo = getElementDesign();
        DataType dtValue    = dtArray.getElementType();
        char[]   achText    = sText.toCharArray();
        int      nLen       = achText.length;
        char     chDelim    = DELIMITERS.charAt(nDim);
        int      cnt        = achText.length > 0 ? 1 : 0;
        
        for (int i = 0; i < nLen; i++)
            {
            if (achText[i] == chDelim)
                {
                cnt++;
                }
            }        
        
        Object[] aoValue = new Object[cnt];
        
        int ofStart = 0;
        for (int i = 0; i < cnt; i++)
            {
            int ofEnd = sText.indexOf(chDelim, ofStart);
            if (ofEnd == -1)
                {
                ofEnd = nLen;
                }
        
            String sElement = sText.substring(ofStart, ofEnd);
            Object oElement = designInfo instanceof Array
                ? sElement.equals(TEXT_NULL)
                    ? null
                    : ((Array) designInfo).convertArrayText(sElement, nDim - 1, dtValue, store)
                : designInfo.getValue(sElement, dtValue, store);
        
            if (oElement == VALUE_UNKNOWN || oElement == Property.NO_VALUE)
                {
                return VALUE_UNKNOWN;
                }
        
            aoValue[i] = oElement;
        
            ofStart = ofEnd + 1;
            }
        
        return aoValue;
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        Object oValue = super.convertText(sText, dtValue, storage);
        
        if (oValue == VALUE_UNKNOWN)
            {
            if (sText.equals(TEXT_NULL))
                {
                oValue = null;
                }
            else
                {
                int nDim = getArrayDimension();
                if (nDim < DELIMITERS.length());
                    {
                    oValue = convertArrayText(sText, nDim, dtValue, storage);
                    }
                }
            }
        
        return oValue;
        }
    
    // Accessor for the property "ArrayDimension"
    /**
    * Returns the dimension of the ElementDesign for this array (0 meaning the
    * simple array)
    */
    protected int getArrayDimension()
        {
        // import Component.Dev.Design;
        
        int nDim = 0;
        
        Design designInfo = getElementDesign();
        
        while (designInfo instanceof Array)
            {
            nDim++;
            designInfo = ((Array) designInfo).getElementDesign();
            }
        
        return nDim;
        }
    
    // Accessor for the property "ElementDesign"
    public _package.component.dev.Design getElementDesign()
        {
        return __m_ElementDesign;
        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        String sText = oValue == null ? TEXT_NULL : super.getText(oValue, dtValue);
        
        if (sText == null)
            {
            // in order for us to be able to do something reasonable
            // we assume that the value array is homegeneous
        
            int cDim = getArrayDimension();
            if (cDim < DELIMITERS.length() && oValue instanceof Object[] &&
                cDim == getValueDimension((Object[]) oValue))
                {
                Object[] aoValue = (Object[]) oValue;
                StringBuffer sb = new StringBuffer();
        
                if (addArrayText(sb, aoValue, cDim, dtValue))
                    {
                    sText = sb.toString();
                    }
                }
            }
        
        return sText;
        }
    
    /**
    * Returns the dimension of the specified array (0 meaning the simple array).
    */
    protected int getValueDimension(Object[] aoValue)
        {
        int nDim = 0;
        
        while (aoValue != null && aoValue.length > 0 &&
               aoValue[0] instanceof Object[])
            {
            nDim++;
            aoValue = (Object[]) aoValue[0];
            }
        
        return nDim;
        }
    
    /**
    * Tests whether or not  the specified text could be converted to an array
    * of the specified dimension.
    * 
    * @param sText a string value to test
    * @param nDim dimension of the array to convert into
    * @param dtArray  data type of the array
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #isTextLegal
    */
    protected boolean isArrayTextLegal(String sText, int nDim, com.tangosol.dev.component.DataType dtArray, _package.component.dev.Storage store)
        {
        // import Component.Dev.Design;
        // import com.tangosol.dev.component.DataType;
        
        Design designInfo = getElementDesign();
        _assert(designInfo != null);
        
        DataType dtValue = dtArray.getElementType();
        
        int  nLen    = sText.length();
        char chDelim = DELIMITERS.charAt(nDim);
        int  ofStart = 0;
        do
            {
            int ofEnd = sText.indexOf(chDelim, ofStart);
            if (ofEnd == -1)
                {
                ofEnd = nLen;
                }
            
            String sElementText = sText.substring(ofStart, ofEnd);
        
            if (sElementText.equals(TEXT_NO_VALUE))
                {
                return false;
                }
        
            if (designInfo instanceof Array)
                {
                if (!sElementText.equals(TEXT_NULL) &&
                    !((Array) designInfo).isArrayTextLegal(sElementText, nDim - 1, dtValue, store))
                    {
                    return false;
                    }
                }
            else
                {
                if (!designInfo.isTextLegal(sElementText, dtValue, store))
                    {
                    return false;
                    }
                }
            ofStart = ofEnd + 1;
            } while (ofStart < nLen);
        
        return true;
        }
    
    // Declared at the super level
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        if (super.isTextLegal(sText, dtValue, storage) || sText.equals(TEXT_NULL))
            {
            return true;
            }
        
        int nDim = getArrayDimension();
        
        return nDim < DELIMITERS.length() ?
            isArrayTextLegal(sText, nDim, dtValue, storage) : false;
        }
    
    // Accessor for the property "ElementDesign"
    public void setElementDesign(_package.component.dev.Design pElementDesign)
        {
        __m_ElementDesign = pElementDesign;
        }
    }
