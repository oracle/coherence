/* Class
*     _package.component.dev.design.component.application.gUI.Desktop$PD_MainWindowClass
*/

package _package.component.dev.design.component.application.gUI;

public class Desktop$PD_MainWindowClass
        extends    _package.component.dev.design.class.Ljava_lang_Class
    {
    // Fields declarations
    
    /**
    * Property ComponentBase
    *
    * Specifies the constraint for the component class name.
    */
    
    // Default constructor
    public Desktop$PD_MainWindowClass()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Desktop$PD_MainWindowClass(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant ComponentBase
    public String getComponentBase()
        {
        return "Component.GUI.Control.Container.Window.Frame.JFrame.";
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Desktop$PD_MainWindowClass();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/component/application/gUI/Desktop$PD_MainWindowClass".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        return isTextLegal(getComponentBase() + sText, dtValue, storage) ?
            super.convertText(getComponentBase() + sText, dtValue, storage) :
            super.convertText(sText, dtValue, storage);

        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        String sText = super.getText(oValue, dtValue);
        String sBase = getComponentBase();
        
        return sText.startsWith(sBase) ?
            sText.substring(sBase.length()) : sText;

        }
    
    // Declared at the super level
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        if (super.isTextLegal(sText, dtValue, storage))
            {
            return true;
            }
        
        return super.isTextLegal(getComponentBase() + sText, dtValue, storage);
        }
    }
