/* Class
*     _package.component.dev.design.intrinsic.Character
*/

package _package.component.dev.design.intrinsic;

import com.tangosol.util.Base;

public class Character
        extends    _package.component.dev.design.Intrinsic
    {
    // Fields declarations
    
    // Default constructor
    public Character()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Character(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Character();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/intrinsic/Character".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        Object oValue = super.convertText(sText, dtValue, storage);
        
        if (oValue == VALUE_UNKNOWN)
            {
            try
                {
                oValue = new Character(parseChar(sText));
                }
            catch (NumberFormatException e) {}
            }
        return oValue;
        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        // import com.tangosol.util.Base;
        
        if (oValue instanceof Character)
            {
            char ch = ((Character) oValue).charValue();
            switch (ch)
                {
                // escaped characters
                case '\b':
                    return "\\b";
                case '\t':
                    return "\\t";
                case '\n':
                    return "\\n";
                case '\f':
                    return "\\f";
                case '\r':
                    return "\\r";
                case '\\':
                    return "\\\\";
                default:
                    return ((int) ch & 0xFF00) != 0 ? ("\\u"  + Base.toHexString((int) ch, 4)) :
                           ((int) ch > 0x001F)      ? (String.valueOf(ch)) : // hopefully printable
                                                      ("\\"   + Integer.toOctalString((int) ch));
                }
            }
        
        return super.getText(oValue, dtValue);
        }
    
    // Declared at the super level
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        if (super.isTextLegal(sText, dtValue, storage))
            {
            return true;
            }
        
        try
            {
            parseChar(sText);
            return true;
            }
        catch (NumberFormatException e)
            {
            return false;
            }

        }
    
    private char parseChar(String sText)
            throws java.lang.NumberFormatException
        {
        // import com.tangosol.util.Base;
        
        if (sText.length() == 1)
            {
            return sText.charAt(0);
            }
        
        char[] ach = sText.toCharArray();
        
        if (ach[0] != '\\')
            {
            throw new NumberFormatException();
            }
        
        char chResult;
        int  cValidLength = 2;
        
        switch (ach[1])
            {
            case 'b':
                chResult = '\b';
                break;        
            case 't':
                chResult = '\t';
                break;        
            case 'n':
                chResult = '\n';
                break;        
            case 'f':
                chResult = '\f';
                break;        
            case 'r':
                chResult = '\r';
                break;        
            case 'u':
                {
                if (ach.length != (cValidLength = 6)) // format: \u0000
                    {
                    throw new NumberFormatException();
                    }
        
                int nCharValue = 0;
                for (int i = 2; i < 6; ++i)
                    {
                    char ch = ach[i];
                    if (!Base.isHex(ch))
                        {
                        throw new NumberFormatException();
                        }
                    nCharValue = (nCharValue << 4) + Base.hexValue(ch);
                    }
        
                chResult = (char) nCharValue;
                }
                break;
        
            case '\"':
            case '\'':
            case '\\':
                chResult = ach[1];
                break;        
        
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
                {
                int  ix = 1;
                char ch = ach[ix];
                int  cMaxDigits = (ch > '3' ? 2 : 3);
                int  nChar = 0;
        
                do
                    {
                    nChar = (nChar * 8) + (ch - '0');
                    ix++;
                    ch = ix < ach.length ? ach[ix] : 0;
                    }
                while (ch >= '0' && ch <= '7' && --cMaxDigits > 0);
        
                chResult = (char) nChar;
                cValidLength = ix;
                }
                break;
        
            default:
                throw new NumberFormatException();
            }
        
        if (ach.length != cValidLength)
            {
            throw new NumberFormatException();
            }
        
        return chResult;
        }
    }
