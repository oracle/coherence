/* Class
*     _package.component.dev.design.intrinsic.integer.enum.contextScope.ParameterContextScope
*/

package _package.component.dev.design.intrinsic.integer.enum.contextScope;

public class ParameterContextScope
        extends    _package.component.dev.design.intrinsic.integer.enum.ContextScope
    {
    // Fields declarations
    private static final String[] __s_TextChoices;
    
    // Static initializer
    static
        {
        try
            {
            String[] a0 = new String[5];
                {
                a0[0] = "None";
                a0[1] = "Request";
                a0[2] = "Session";
                a0[3] = "Cookie";
                a0[4] = "Application";
                }
            __s_TextChoices = a0;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public ParameterContextScope()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ParameterContextScope(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant TextChoices
    public String[] getTextChoices()
        {
        return (String[]) __s_TextChoices.clone();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ParameterContextScope();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/intrinsic/integer/enum/contextScope/ParameterContextScope".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    }
