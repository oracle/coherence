/* Class
*     _package.component.dev.design.intrinsic.character.KeyChar
*/

package _package.component.dev.design.intrinsic.character;

import java.awt.event.KeyEvent;

public class KeyChar
        extends    _package.component.dev.design.intrinsic.Character
    {
    // Fields declarations
    
    /**
    * Property CharMap
    *
    * "char <--> String" mapping.
    */
    private static String[] __s_CharMap;
    
    // Default constructor
    public KeyChar()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public KeyChar(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new KeyChar();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/intrinsic/character/KeyChar".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        Object oValue = super.convertText(sText, dtValue, storage);
        
        if (oValue == VALUE_UNKNOWN)
            {
            String[] asChar = getCharMap();
        
            for (int i = 0; i < asChar.length; i++)
                {
                if (sText.equalsIgnoreCase(asChar[i]))
                    {
                    return new Character((char) i);
                    }
                }
            }
        
        return oValue;

        }
    
    // Accessor for the property "CharMap"
    private static String[] getCharMap()
        {
        // import java.awt.event.KeyEvent;
        
        String[] map = __s_CharMap;
        if (map == null)
            {
            final int LAST_CHAR = KeyEvent.VK_F12;
            map = new String[LAST_CHAR + 1];
        
            map[KeyEvent.VK_ENTER     ] = "Enter";
            map[KeyEvent.VK_CANCEL    ] = "Cancel";
            map[KeyEvent.VK_CLEAR     ] = "Clear";
            map[KeyEvent.VK_SHIFT     ] = "Shift";
            map[KeyEvent.VK_CONTROL   ] = "Ctrl";
            map[KeyEvent.VK_ALT       ] = "Alt";
            map[KeyEvent.VK_PAUSE     ] = "Pause";
            map[KeyEvent.VK_CAPS_LOCK ] = "CapsLock";
            map[KeyEvent.VK_ESCAPE    ] = "Esc";
            map[KeyEvent.VK_SPACE     ] = "Space";
            map[KeyEvent.VK_PAGE_UP   ] = "PageUp";
            map[KeyEvent.VK_PAGE_DOWN ] = "PageDown";
            map[KeyEvent.VK_END       ] = "End";
            map[KeyEvent.VK_HOME      ] = "Home";
            map[KeyEvent.VK_LEFT      ] = "Left";
            map[KeyEvent.VK_UP        ] = "Up";
            map[KeyEvent.VK_RIGHT     ] = "Right";
            map[KeyEvent.VK_DOWN      ] = "Down";
        
            map[KeyEvent.VK_F1        ] = "F1";
            map[KeyEvent.VK_F2        ] = "F2";
            map[KeyEvent.VK_F3        ] = "F3";
            map[KeyEvent.VK_F4        ] = "F4";
            map[KeyEvent.VK_F5        ] = "F5";
            map[KeyEvent.VK_F6        ] = "F6";
            map[KeyEvent.VK_F7        ] = "F7";
            map[KeyEvent.VK_F8        ] = "F8";
            map[KeyEvent.VK_F9        ] = "F9";
            map[KeyEvent.VK_F10       ] = "F10";
            map[KeyEvent.VK_F11       ] = "F11";
            map[KeyEvent.VK_F12       ] = "F12";
        
            setCharMap(map);
            }
        return map;
        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        if (oValue instanceof Character)
            {
            char     ch     = ((Character) oValue).charValue();
            String[] asChar = getCharMap();
        
            if ((int) ch < asChar.length)
                {
                String sText = asChar[(int) ch];
                if (sText != null)
                    {
                    return sText;
                    }
                }
            }
        return super.getText(oValue, dtValue);
        }
    
    // Declared at the super level
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        if (super.isTextLegal(sText, dtValue, storage))
            {
            return true;
            }
        
        String[] asChar = getCharMap();
        for (int i = 0; i < asChar.length; i++)
            {
            if (sText.equalsIgnoreCase(asChar[i]))
                {
                return true;
                }
            }
        return false;

        }
    
    // Accessor for the property "CharMap"
    private static void setCharMap(String[] pCharMap)
        {
        __s_CharMap = pCharMap;
        }
    }
