/* Class
*     _package.component.dev.design.component.gUI.control.container.jComponent.abstractButton.JMenuItem
*/

package _package.component.dev.design.component.gUI.control.container.jComponent.abstractButton;

import _package.component.gUI.control.container.jComponent.abstractButton.JButton;
import _package.component.gUI.control.container.jComponent.abstractButton.JMenuItem;

public class JMenuItem
        extends    _package.component.dev.design.component.gUI.control.container.jComponent.AbstractButton
    {
    // Fields declarations
    
    // Default constructor
    public JMenuItem()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JMenuItem(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setRemotable(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JMenuItem();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/component/gUI/control/container/jComponent/abstractButton/JMenuItem".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Instantiates a new renderer used to visually represent "this" type of
    * Component Definition in a visual design tool. Subclasses should overwrite
    * this method (usually NOT calling the super implementation).
    * 
    * @param cd Component Definition to instantiate a renderer for
    * 
    * @return a newly instantiated visual component.
    */
    public _package.component.gUI.Control instantiateComponentRenderer(com.tangosol.dev.component.Component cd)
        {
        // import Component.GUI.Control.Container.JComponent.AbstractButton.JButton;
        
        return new JButton();
        }
    
    // Declared at the super level
    /**
    * Updates attributes of the specified component holder based on the state
    * of the designee [Component Definition].  Subclasses should overwrite this
    * method extracting and applying values of relevant properties either to
    * the holder itself or to its renderer.
    */
    protected void updateComponentHolder(_package.component.gUI.control.container.jComponent.jPanel.CDHolder holder)
        {
        // import Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem;
        
        super.updateComponentHolder(holder);
        

        }
    }
