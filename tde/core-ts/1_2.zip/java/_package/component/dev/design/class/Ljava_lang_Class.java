/* Class
*     _package.component.dev.design.class.Ljava_lang_Class
*/

package _package.component.dev.design.class;

import com.tangosol.dev.assembler.Aconst;
import com.tangosol.dev.assembler.Astore;
import com.tangosol.dev.assembler.Avar;
import com.tangosol.dev.assembler.Begin;
import com.tangosol.dev.assembler.Checkcast;
import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.CodeAttribute;
import com.tangosol.dev.assembler.End;
import com.tangosol.dev.assembler.Field;
import com.tangosol.dev.assembler.Iconst;
import com.tangosol.dev.assembler.Invokestatic;
import com.tangosol.dev.assembler.Invokevirtual;
import com.tangosol.dev.assembler.Method;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.assembler.Return;
import com.tangosol.dev.assembler.StringConstant;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.DataType;

public class Ljava_lang_Class
        extends    _package.component.dev.design.Class
    {
    // Fields declarations
    
    // Default constructor
    public Ljava_lang_Class()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Ljava_lang_Class(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Ljava_lang_Class();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/class/Ljava_lang_Class".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Generates Java class byte codes for a constant value initialization
    * 
    * @param gen ClassGenerator producing a Java class
    * @param oValue value to generate an initializer for
    * @param dtType data type of the specified value
    * 
    * @throws IllegalArgumentException if the code generation is not possible
    * due to an unknown value [data type]
    * 
    * @see #getValue
    * @see Component.Dev.Compiler.ClassGenerator#addConstantInitializer
    * @see Component.Dev.Compiler.ClassGenerator#addPropertyInitializer
    */
    protected void addConstantInitializer(_package.component.dev.compiler.ClassGenerator gen, Object oValue, com.tangosol.dev.component.DataType dtType)
        {
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.Field;
        // import com.tangosol.dev.assembler.Aconst;
        // import com.tangosol.dev.assembler.Iconst;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.StringConstant;
        // import com.tangosol.dev.assembler.Invokestatic;
        // import com.tangosol.dev.assembler.Invokevirtual;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        
        if (oValue == null)
            {
            super.addConstantInitializer(gen, oValue, dtType);
            return;
            }
        
        _assert(oValue instanceof String &&
                dtType.getClassName().equals("java.lang.Class"));
        
        // since this method is called by ClassGenerator#addPropertyInitializer
        // we don't have to catch any exceptions -- it's done by the callee.
        // Except for that, the following code is a cut from ClassGenerator#addClassForName.
        
        CodeAttribute code  = gen.getCode();
        String        sName = (String) oValue;
        String        sClz  = sName;
        
        if (Component.isQualifiedNameLegal(sName))
            {
            // ensure the component
            if (gen.getComponent(sName) == null)
                {
                String sMsg = "Invalid component reference: " + sName;
                gen.addError(sMsg);
        
                super.addConstantInitializer(gen, null, dtType);
                return;
                }
        
            DataType dtComp = gen.resolveDataType(DataType.getComponentType(sName));
        
            sName = dtComp.getComponentName();
            sClz  = dtComp.getClassName().replace('.', '/');
        
            code.add(new Aconst(new StringConstant(sClz)));
            MethodConstant cM_replace = new MethodConstant("java.lang.String",
                "replace", "(CC)Ljava.lang.String;");
            code.add(new Iconst((int) '/'));
            code.add(new Iconst((int) '.'));
            code.add(new Invokevirtual(cM_replace));
        
            gen.print("Class.forName(\"" + sClz + "\".replace('/', '.'))");
            }
        else
            {
            // ensure the class signature
            Component jcs = null;
            try
                {
                jcs = gen.getStorage().loadSignature(sName);
                }
            catch (ComponentException e) {}
        
            if (jcs == null)
                {
                String sMsg = "Invalid class reference: " + sName;
                gen.addError(sMsg);
        
                super.addConstantInitializer(gen, null, dtType);
                return;
                }
        
            code.add(new Aconst(new StringConstant(sClz)));
        
            gen.print("Class.forName(\"" + sClz + "\")");
            }
        
        MethodConstant cM_forName = new MethodConstant("java.lang.Class",
            "forName", "(Ljava.lang.String;)Ljava.lang.Class;");
        code.add(new Invokestatic(cM_forName));
        
        // In order for the packager to automatically pick-up the specified class
        // as a dependency we will generate a synthetic method referring to that class.
        // The better solution would be at the packaging time to enumerate all the
        // properties (with values) and ask for the dependencies (similar to
        // Component#getDependents()).
        // TODO: If there are other reasons to traverse the properties and calculate the
        // dependants, we will move this as well ...
        
        generateClassReference(gen.getClassFile(), sName, sClz);
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        Object oValue = super.convertText(sText, dtValue, storage);
        
        if (oValue == VALUE_UNKNOWN)
            {
            // sText represents the name of a component or class
            // (see #isTextLegal)
            oValue = sText;
            }
        
        return oValue;
        }
    
    private void generateClassReference(com.tangosol.dev.assembler.ClassFile clzf, String sName, String sClz)
        {
        // import com.tangosol.dev.assembler.Method;
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.Begin;
        // import com.tangosol.dev.assembler.End;
        // import com.tangosol.dev.assembler.Avar;
        // import com.tangosol.dev.assembler.Aconst;
        // import com.tangosol.dev.assembler.Checkcast;
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.assembler.Astore;
        // import com.tangosol.dev.assembler.Return;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Component;
        
        String sMethodSig = "__$" + sName.replace('.', '_') + "()V";
        
        if (clzf.getMethod(sMethodSig) == null)
            {
            Method method = clzf.addMethod(sMethodSig);
            
            method.setPrivate();
            method.setStatic(true);
            method.setSynthetic(true);
        
            CodeAttribute code = method.getCode();
            code.add(new Begin());
                {
                Avar vL = new Avar("tmp");
                code.add(vL);
                code.add(new Aconst());
                code.add(new Checkcast(new ClassConstant(sClz)));
                code.add(new Astore(vL));
                code.add(new Return());
        
                // <sClz> tmp = (<sClz)) null;
                }
            code.add(new End());
            }
        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        String sText = super.getText(oValue, dtValue);
        return sText != null ? sText : String.valueOf(oValue);
        }
    
    // Declared at the super level
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        
        if (super.isTextLegal(sText, dtValue, storage))
            {
            return true;
            }
        
        // make sure that there is such a component or class
        try
            {
            if (Component.isQualifiedNameLegal(sText))
                {
                String sGlobalName = Component.getGlobalName(sText);
                String sLocalName  = Component.getLocalName (sText);
        
                Component cd = storage.loadComponent(sGlobalName, true, null);
        
                if (sLocalName != null)
                    {
                    cd = cd.getLocal(sLocalName);
                    }
                return cd != null;
                }
            else
                {
                Component jcs = storage.loadSignature(sText);
        
                return jcs != null;
                }
            }
        catch (ComponentException e)
            {
            return false;
            }
        }
    }
