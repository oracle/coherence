/* Class
*     _package.component.dev.design.component.gUI.control.container.jComponent.JPanel
*/

package _package.component.dev.design.component.gUI.control.container.jComponent;

import _package.component.dev.packager.element.CDElement;
import _package.component.gUI.Dimension;
import com.tangosol.dev.component.Property;
import java.util.LinkedList;
import java.util.List;

/**
* +++++++
* 
* This component represents a Component.GUI.Control.Container.JComponent.JPanel
* type of Component Definition. It is aware of such properties of the
* corresponding Component Definition as Icon, Title, Resizable.
*/
public class JPanel
        extends    _package.component.dev.design.component.gUI.control.container.JComponent
    {
    // Fields declarations
    private static final String[] __s_Tools;
    
    // Static initializer
    static
        {
        try
            {
            String[] a0 = new String[6];
                {
                a0[0] = "OutputTool";
                a0[1] = "Host.CDTool.ContainmentTool";
                a0[2] = "Host.CDTool.PropertyTool";
                a0[3] = "Host.CDTool.ScriptingTool";
                a0[4] = "Host.CDTool.IntegrationTool";
                a0[5] = "Host.CDTool.LayoutTool";
                }
            __s_Tools = a0;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public JPanel()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JPanel(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setRemotable(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant Tools
    protected String[] getTools()
        {
        return (String[]) __s_Tools.clone();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JPanel();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/component/gUI/control/container/jComponent/JPanel".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    protected _package.component.gUI.Dimension getDefaultHolderSize()
        {
        // import Component.GUI.Dimension;
        
        return Dimension.instantiate(400, 300);
        }
    
    // Declared at the super level
    /**
    * Return a list of PackagerDependencyElements for the specified Component
    * Definition (of "this" Component Definition type) that cannot be
    * "calculated" based on the dependency information/class traversal.
    * Subclasses usually override this method returning lists of CDElement or
    * TransientEntry objects.
    * 
    * @param cd  component for which the PackagerDependencyElements should be
    * calculated
    * @param storage  storage to be used to load any necessary components
    * @param info  packaging information used by the current packaging model
    * 
    * @see Packager.Element.CDElement#getDependents
    */
    public java.util.List getDependents(com.tangosol.dev.component.Component cd, _package.component.dev.Storage storage, _package.component.dev.packager.PackageInfo info)
        {
        // import Component.Dev.Packager.Element.CDElement;
        // import com.tangosol.dev.component.Property;
        // import java.util.List;
        // import java.util.LinkedList;
        
        List list = super.getDependents(cd, storage, info);
        
        // TODO: remove when the complex property "Icon" is implemented
        Object oTIcon = getPropertyValue(cd, "TIcon");
        if (oTIcon != null && oTIcon != Property.NO_VALUE)
            {
            String sIcon = "Component.GUI.Image.Icon." + (String) oTIcon;
            if (list == null)
                {
                list = new LinkedList();
                }
            CDElement el = new CDElement();
        
            el.setComponentName(sIcon);
            el.setPackageInfo(info);
            el.setStorage(storage);
        
            list.add(el);
            }
        return list;
        }
    
    // Declared at the super level
    /**
    * Instantiates a new renderer used to visually represent "this" type of
    * Component Definition in a visual design tool. Subclasses should overwrite
    * this method (usually NOT calling the super implementation).
    * 
    * @param cd Component Definition to instantiate a renderer for
    * 
    * @return a newly instantiated visual component.
    */
    public _package.component.gUI.Control instantiateComponentRenderer(com.tangosol.dev.component.Component cd)
        {
        // use the CDHolder itself as the renderer
        return null;
        }
    }
