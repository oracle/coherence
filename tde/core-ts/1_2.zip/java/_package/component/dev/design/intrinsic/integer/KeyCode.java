/* Class
*     _package.component.dev.design.intrinsic.integer.KeyCode
*/

package _package.component.dev.design.intrinsic.integer;

import java.awt.event.KeyEvent;

public class KeyCode
        extends    _package.component.dev.design.intrinsic.Integer
    {
    // Fields declarations
    
    /**
    * Property CodeMap
    *
    * "code <--> String" mapping.
    */
    private static String[] __s_CodeMap;
    
    // Default constructor
    public KeyCode()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public KeyCode(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new KeyCode();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/intrinsic/integer/KeyCode".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        Object oValue = super.convertText(sText, dtValue, storage);
        
        if (oValue == VALUE_UNKNOWN)
            {
            String[] asCode = getCodeMap();
        
            for (int i = 0; i < asCode.length; i++)
                {
                if (sText.equalsIgnoreCase(asCode[i]))
                    {
                    return new Integer(i);
                    }
                }
            }
        
        return oValue;

        }
    
    // Accessor for the property "CodeMap"
    private static String[] getCodeMap()
        {
        // import java.awt.event.KeyEvent;
        
        String[] map = __s_CodeMap;
        if (map == null)
            {
            final int LAST_KEY = KeyEvent.VK_META;
            map = new String[LAST_KEY + 1];
        
            map[KeyEvent.VK_ENTER        ] = "Enter";
            map[KeyEvent.VK_BACK_SPACE   ] = "Bksp";
            map[KeyEvent.VK_TAB          ] = "Tab";
            map[KeyEvent.VK_CANCEL       ] = "Cancel";
            map[KeyEvent.VK_CLEAR        ] = "Clear";
            map[KeyEvent.VK_SHIFT        ] = "Shift";
            map[KeyEvent.VK_CONTROL      ] = "Ctrl";
            map[KeyEvent.VK_ALT          ] = "Alt";
            map[KeyEvent.VK_PAUSE        ] = "Pause";
            map[KeyEvent.VK_CAPS_LOCK    ] = "CapsLock";
            map[KeyEvent.VK_ESCAPE       ] = "Esc";
            map[KeyEvent.VK_SPACE        ] = "Space";
            map[KeyEvent.VK_PAGE_UP      ] = "PageUp";
            map[KeyEvent.VK_PAGE_DOWN    ] = "PageDown";
            map[KeyEvent.VK_END          ] = "End";
            map[KeyEvent.VK_HOME         ] = "Home";
            map[KeyEvent.VK_LEFT         ] = "Left";
            map[KeyEvent.VK_UP           ] = "Up";
            map[KeyEvent.VK_RIGHT        ] = "Right";
            map[KeyEvent.VK_DOWN         ] = "Down";
        
            map[KeyEvent.VK_MULTIPLY     ] = "Mul"; // grey '*'
            map[KeyEvent.VK_ADD          ] = "Add"; // grey '+'
            map[KeyEvent.VK_SUBTRACT     ] = "Sub"; // grey '-'
            map[KeyEvent.VK_DELETE       ] = "Delete";
            map[KeyEvent.VK_NUM_LOCK     ] = "NumLock";
            map[KeyEvent.VK_SCROLL_LOCK  ] = "ScrollLock";
        
            // VK_A thru VK_Z are the same as ASCII 'A' thru 'Z' (0x41 - 0x5A)
            for (int i = KeyEvent.VK_A; i <= KeyEvent.VK_Z; i++)
                {
                map[i] = String.valueOf((char) i);
                }
            map[KeyEvent.VK_OPEN_BRACKET ] = "[";
            map[KeyEvent.VK_BACK_SLASH   ] = "\\";
            map[KeyEvent.VK_CLOSE_BRACKET] = "]";
            
            map[KeyEvent.VK_F1           ] = "F1";
            map[KeyEvent.VK_F2           ] = "F2";
            map[KeyEvent.VK_F3           ] = "F3";
            map[KeyEvent.VK_F4           ] = "F4";
            map[KeyEvent.VK_F5           ] = "F5";
            map[KeyEvent.VK_F6           ] = "F6";
            map[KeyEvent.VK_F7           ] = "F7";
            map[KeyEvent.VK_F8           ] = "F8";
            map[KeyEvent.VK_F9           ] = "F9";
            map[KeyEvent.VK_F10          ] = "F10";
            map[KeyEvent.VK_F11          ] = "F11";
            map[KeyEvent.VK_F12          ] = "F12";
        
            map[KeyEvent.VK_PRINTSCREEN  ] = "PrintScreen";
            map[KeyEvent.VK_INSERT       ] = "Insert";
            map[KeyEvent.VK_HELP         ] = "Help";
            map[KeyEvent.VK_META         ] = "Meta";
        
            setCodeMap(map);
            }
        return map;
        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        if (oValue instanceof Integer)
            {
            int      iCode  = ((Integer) oValue).intValue();
            String[] asCode = getCodeMap();
        
            if (iCode < asCode.length)
                {
                String sText = asCode[iCode];
                if (sText != null)
                    {
                    return sText;
                    }
                }
            }
        return super.getText(oValue, dtValue);
        }
    
    // Declared at the super level
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        if (super.isTextLegal(sText, dtValue, storage))
            {
            return true;
            }
        
        String[] asCode = getCodeMap();
        for (int i = 0; i < asCode.length; i++)
            {
            if (sText.equalsIgnoreCase(asCode[i]))
                {
                return true;
                }
            }
        return false;

        }
    
    // Accessor for the property "CodeMap"
    private static void setCodeMap(String[] pCodeMap)
        {
        __s_CodeMap = pCodeMap;
        }
    }
