/* Class
*     _package.component.dev.design.Class
*/

package _package.component.dev.design;

import _package.component.dev.Storage;
import _package.component.dev.compiler.ClassGenerator;
import _package.component.dev.design.Class; // as ClassInfo
import com.tangosol.dev.assembler.Aconst;
import com.tangosol.dev.assembler.Aload;
import com.tangosol.dev.assembler.Avar;
import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.ClassFile;
import com.tangosol.dev.assembler.CodeAttribute;
import com.tangosol.dev.assembler.Constant;
import com.tangosol.dev.assembler.Dup;
import com.tangosol.dev.assembler.Invokespecial;
import com.tangosol.dev.assembler.Method;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.assembler.New;
import com.tangosol.dev.assembler.Return;
import com.tangosol.dev.assembler.SignatureConstant;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.DataType;
import java.util.Hashtable;

public class Class
        extends    _package.component.dev.Design
    {
    // Fields declarations
    
    /**
    * Property TEXT_INSTANCE
    *
    * String value for the "new instance" value.
    */
    public static final String TEXT_INSTANCE = "[instance]";
    private static final String[] __s_TextChoices;
    
    /**
    * Property VALUE_INSTANCE
    *
    * This is an internally used value that indicates that a property should be
    * initialized to a new instance of the corresponding class.
    */
    private static transient Object __s_VALUE_INSTANCE;
    
    // Static initializer
    static
        {
        try
            {
            String[] a0 = new String[2];
                {
                a0[0] = "[none]";
                a0[1] = "[null]";
                }
            __s_TextChoices = a0;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public Class()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Class(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant TextChoices
    public String[] getTextChoices()
        {
        return (String[]) __s_TextChoices.clone();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Class();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/Class".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Generates Java class byte codes for a constant value initialization
    * 
    * @param gen ClassGenerator producing a Java class
    * @param oValue value to generate an initializer for
    * @param dtType data type of the specified value
    * 
    * @throws IllegalArgumentException if the code generation is not possible
    * due to an unknown value [data type]
    * 
    * @see #getValue
    * @see Component.Dev.Compiler.ClassGenerator#addConstantInitializer
    * @see Component.Dev.Compiler.ClassGenerator#addPropertyInitializer
    */
    protected void addConstantInitializer(_package.component.dev.compiler.ClassGenerator gen, Object oValue, com.tangosol.dev.component.DataType dtType)
        {
        // import Component.Dev.Storage;
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.DataType;
        
        try
            {
            Storage   storage = gen.getStorage();
            String    sType   = dtType.getClassName();
            Component jcsType = storage.loadSignature(sType);
        
            if (oValue == null)
                {
                super.addConstantInitializer(gen, oValue, dtType);
                }
            else if (getVALUE_INSTANCE().equals(oValue) && dtType != DataType.STRING)
                {
                // to be able to instantiate the class
                // the corresponding class must be a Java Bean
                Behavior  bhvr = jcsType.getBehavior("<init>()");
                _assert(bhvr != null && bhvr.getAccess() == Behavior.ACCESS_PUBLIC);
        
                generateNewInstance(gen, dtType.getClassConstant());
                }
            else if (jcsType.isInterface() || jcsType.isAbstract())
                {
                // the specified class must be a Java Bean
                // implementing the interface or subclassing
                // (we assuming the second part still holds true)
                String    sClass   = (String) oValue;
                Component jcsValue = storage.loadSignature(sClass);
                Behavior  bhvr     = jcsValue.getBehavior("<init>()");
        
                _assert(bhvr != null && bhvr.getAccess() == Behavior.ACCESS_PUBLIC);
        
                generateNewInstance(gen, new ClassConstant(sClass));
                }
            else
                {
                // this will throw an exception
                super.addConstantInitializer(gen, oValue, dtType);
                }
            }
        catch (ComponentException e)
            {
            throw new IllegalStateException(e.toString());
            }

        }
    
    /**
    * This method is called by the JavaBean integrator model to adjust the
    * generated feed class.
    * This is currently used to generate a default constructor for the feed (or
    * "exposed" feed) in a case of "special" non-Javabean integration whith
    * parameterized constructors (the corresponding component declares
    * _init(...) behaviors).
    * Default implementation does nothing.
    * 
    * @param gen  ClassGenerator used for class generation
    */
    public void adjustFeed(_package.component.dev.compiler.ClassGenerator gen)
        {
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        Object oValue = super.convertText(sText, dtValue, storage);
        
        if (oValue == VALUE_UNKNOWN)
            {
            if (sText.equals(TEXT_NULL))
                {
                oValue = null;
                }
            else if (sText.equals(TEXT_INSTANCE))
                {
                oValue = getVALUE_INSTANCE();
                }
            else
                {
                oValue = sText; // class name
                }
            }
        
        return oValue;
        }
    
    private static String findClassDesignName(String sSuperDesignName, String sClassName)
        {
        while (sSuperDesignName != null)
            {
            String sDesignName = sSuperDesignName + ".L" + sClassName.replace('.', '_');
            if (getDesignInfo(sDesignName) != null)
                {
                return sDesignName;
                }
        
            // actually we would need a Storage to get the super class name,
            // but for now we'll try to load the class itself
            try
                {
                Class classSuper = Class.forName(sClassName).getSuperclass();
                sSuperDesignName = classSuper == null ? null :
                    findClassDesignName(sSuperDesignName, classSuper.getName());
                }
            catch (Throwable e)
                {
                break;
                }
            }
        
        return null;
        }
    
    /**
    * Helper method that is used by integrators of non-Javabean classes turn
    * them into Javabeans by generating a default constructor that calls into
    * another constructor with specified signature and the specified list of
    * arguments (constants).
    */
    protected void generateDefaultConstructor(_package.component.dev.compiler.ClassGenerator gen, String sSig, com.tangosol.dev.assembler.Constant[] aConst)
        {
        // import Component.Dev.Compiler.ClassGenerator;
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.dev.assembler.Method;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.Constant;
        // import com.tangosol.dev.assembler.Aload;
        // import com.tangosol.dev.assembler.Aconst;
        // import com.tangosol.dev.assembler.Avar;
        // import com.tangosol.dev.assembler.Return;
        // import com.tangosol.dev.assembler.Invokespecial;
        
        ClassFile clzf   = gen.getClassFile();
        String    sClass = clzf.getName();
        Method    method = clzf.addMethod(ClassGenerator.CONSTRUCTOR_NAME, "()V");
        
        method.setPublic();
        
        gen.println();
        gen.println("// default constructor");
        gen.println("public " +
            sClass.substring(sClass.lastIndexOf('/') + 1) + "()");
        
        CodeAttribute code = gen.BeginSegment(method);
        
        Avar vL_this = new Avar("this");
        code.add(vL_this);
        
        gen.print("this(");
        
        code.add(new Aload(vL_this));
        for (int i = 0; i < aConst.length; i++)
            {
            Constant constant = aConst[i];
            code.add(ClassGenerator.getLoadConstOp(constant));
        
            if (i > 0)
                {
                gen.print(", ");
                }
            gen.print(constant == null ? "null" : constant.format());
            }
        MethodConstant cM_this = new MethodConstant(sClass,
            ClassGenerator.CONSTRUCTOR_NAME, sSig);
        code.add(new Invokespecial(cM_this));
        code.add(new Return());
        
        gen.println(");");
        
        gen.EndSegment(method);
        }
    
    /**
    * This method is called by the ClassGenerator to allow a custom method
    * generation for a particular interface.
    * Default implementation does nothing.
    * 
    * @param gen  ClassGenerator used for class generation
    * @param sIface the interface name
    */
    public void generateInterface(_package.component.dev.compiler.ClassGenerator gen, String sIface)
            throws com.tangosol.dev.component.ComponentException
        {
        }
    
    /**
    * Helper method that is used by integrators of non-Javabean classes turn
    * them into Javabeans by generating a default constructor that calls into
    * another constructor with specified signature and the specified list of
    * arguments (constants).
    */
    protected void generateNewInstance(_package.component.dev.compiler.ClassGenerator gen, com.tangosol.dev.assembler.ClassConstant cC_type)
        {
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.SignatureConstant;
        // import com.tangosol.dev.assembler.New;
        // import com.tangosol.dev.assembler.Dup;
        // import com.tangosol.dev.assembler.Invokespecial;
        
        CodeAttribute code = gen.getCode();
        
        code.add(new New(cC_type));
        code.add(new Dup());
        MethodConstant cM_new = new MethodConstant(cC_type,
            new SignatureConstant(gen.CONSTRUCTOR_NAME, "()V"));
        code.add(new Invokespecial(cM_new));
        
        gen.print("new " + cC_type.getJavaName() + "()");

        }
    
    /**
    * Instantiates a component of that has an information needed to design the
    * specified Java Class Signature.
    * 
    * @param sName  name of designable Java Class Signature
    * 
    * @return a component of Component.Dev.Design.Class type
    * 
    * Note: we may need to pass the Storage as an argument to resolve the
    * problem with the super class name (see findClassDesignName), but that
    * would require a change to getComponentInfo(cd) as well.
    */
    public static Class getClassInfo(String sName)
        {
        // import Component.Dev.Design.Class as ClassInfo;
        // import java.util.Hashtable;
        
        Hashtable tbl       = getDesignInfoCache();
        String    sInfoName = sName;
        ClassInfo classInfo = (ClassInfo) tbl.get(sInfoName);
        
        if (classInfo == null)
            {
            String sDesignName = findClassDesignName("Class", sName);
            if (sDesignName != null)
                {
                classInfo = (ClassInfo) getDesignInfo(sDesignName);
                }
        
            if (classInfo == null)
                {
                classInfo = (ClassInfo) getDesignInfo("Class");
                _assert(classInfo != null);
                }
        
            tbl.put(sInfoName, classInfo);
            }
        return classInfo;
        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        String sText = super.getText(oValue, dtValue);
        if (sText == null)
            {
            sText = oValue == null                     ? TEXT_NULL :
                    oValue.equals(getVALUE_INSTANCE()) ? TEXT_INSTANCE :
                                                         (String) oValue;
            }
        return sText;
        }
    
    // Accessor for the property "VALUE_INSTANCE"
    /**
    * Getter for property VALUE_INSTANCE.<p>
    * This is an internally used value that indicates that a property should be
    * initialized to a new instance of the corresponding class.
    */
    protected static Object getVALUE_INSTANCE()
        {
        Object value = __s_VALUE_INSTANCE;
        if (value == null)
            {
            setVALUE_INSTANCE(value = TEXT_INSTANCE);
            }
        return value;
        }
    
    // Declared at the super level
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.DataType;
        
        if (super.isTextLegal(sText, dtValue, storage) ||
            sText.equals(TEXT_NULL))
            {
            return true;
            }
        
        try
            {
            Component jcsType = storage.loadSignature(dtValue.getClassName());
        
            if (sText.equals(TEXT_INSTANCE) && dtValue != DataType.STRING)
                {
                // to be able to instantiate the class
                // the corresponding class must be a Java Bean
                Behavior bhvr = jcsType.getBehavior("<init>()");
                return bhvr != null && bhvr.getAccess() == Behavior.ACCESS_PUBLIC;
                }
        
            if (jcsType.isInterface())
                {
                // the specified class must be a Java Bean
                // implementing this interface
                Component jcsValue = storage.loadSignature(sText);
        
                if (jcsValue.getImplements(jcsType.getName()) != null)
                    {
                    Behavior bhvr = jcsValue.getBehavior("<init>()");
                    return bhvr != null && bhvr.getAccess() == Behavior.ACCESS_PUBLIC;
                    }
                }
        
             if (jcsType.isAbstract())
                {
                // the specified class must be a Java Bean subclass
                Component jcsValue = storage.loadSignature(sText);
        
                Behavior bhvr = jcsValue.getBehavior("<init>()");
                if (bhvr != null && bhvr.getAccess() == Behavior.ACCESS_PUBLIC)
                    {
                    String sType  = jcsType.getName();
                    String sSuper = jcsValue.getSuperName();
                    while (sSuper != null && sSuper.length() != 0)
                        {
                        if (sSuper.equals(sType))
                            {
                            return true;
                            }
                        sSuper = storage.loadSignature(sSuper).getSuperName();
                        }
                    }
                }
            }
        catch (ComponentException e)
            {
            }
        
        return false;
        }
    
    // Accessor for the property "VALUE_INSTANCE"
    /**
    * Setter for property VALUE_INSTANCE.<p>
    * This is an internally used value that indicates that a property should be
    * initialized to a new instance of the corresponding class.
    */
    private static void setVALUE_INSTANCE(Object pVALUE_INSTANCE)
        {
        __s_VALUE_INSTANCE = pVALUE_INSTANCE;
        }
    }
