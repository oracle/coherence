/* Class
*     _package.component.dev.design.component.gUI.Control
*/

package _package.component.dev.design.component.gUI;

import _package.component.dev.packager.element.CDElement;
import _package.component.gUI.Control;
import _package.component.gUI.Dimension;
import _package.component.gUI.Point;
import _package.component.gUI.Rectangle;
import _package.component.gUI.control.container.jComponent.JLabel;
import _package.component.gUI.control.container.jComponent.jPanel.CDHolder;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.Property;
import java.util.LinkedList;
import java.util.List;

/**
* +++++++
* 
* This component  represents Component.GUI.Control type of Component
* Definition. It is aware of such properties of the corresponding Component
* Definition as Background, Bounds, Constraints, Enabled, Font, Foreground,
* Visible.
*/
public class Control
        extends    _package.component.dev.design.component.GUI
    {
    // Fields declarations
    
    /**
    * Property DefaultHolderSize
    *
    * A default hodler size for "this" type of Component Definition. The getter
    * for this property is supposed to be overriden by the [Design] components
    * that know better.
    */
    
    /**
    * Property PD_DragActions
    *
    */
    
    /**
    * Property PD_DropActions
    *
    */
    
    /**
    * Property PD_InvokePopup
    *
    */
    
    // Default constructor
    public Control()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Control(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setRemotable(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant PD_DragActions
    public String getPD_DragActions()
        {
        return "Intrinsic.Integer.DnDAction";
        }
    
    // Getter for virtual constant PD_DropActions
    public String getPD_DropActions()
        {
        return "Intrinsic.Integer.DnDAction";
        }
    
    // Getter for virtual constant PD_InvokePopup
    public String getPD_InvokePopup()
        {
        return "Intrinsic.Integer.InvokePopup";
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Control();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/component/gUI/Control".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "DefaultHolderSize"
    protected _package.component.gUI.Dimension getDefaultHolderSize()
        {
        // import Component.GUI.Dimension;
        
        return Dimension.instantiate(70, 30);
        }
    
    // Declared at the super level
    /**
    * Return a list of PackagerDependencyElements for the specified Component
    * Definition (of "this" Component Definition type) that cannot be
    * "calculated" based on the dependency information/class traversal.
    * Subclasses usually override this method returning lists of CDElement or
    * TransientEntry objects.
    * 
    * @param cd  component for which the PackagerDependencyElements should be
    * calculated
    * @param storage  storage to be used to load any necessary components
    * @param info  packaging information used by the current packaging model
    * 
    * @see Packager.Element.CDElement#getDependents
    */
    public java.util.List getDependents(com.tangosol.dev.component.Component cd, _package.component.dev.Storage storage, _package.component.dev.packager.PackageInfo info)
        {
        // import Component.Dev.Packager.Element.CDElement;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.Property;
        // import java.util.List;
        // import java.util.LinkedList;
        
        List list = super.getDependents(cd, storage, info);
        
        // TODO: remove when the complex property "Font" is implemented
        Object oTFont = getPropertyValue(cd, "TFont");
        if (oTFont != null && oTFont != Property.NO_VALUE)
            {
            String sFont = (String) oTFont;
        
            // Syntax ::= <FontName>-<Style>-<Size>
            int of = sFont.indexOf('-');
            if (of > 0)
                {
                sFont = sFont.substring(0, of);
                }
        
            sFont = "Component.GUI.Font." + sFont;
            try
                {
                if (storage.loadComponent(sFont, true, null) != null)
                    {
                    CDElement el = new CDElement();
        
                    el.setComponentName(sFont);
                    el.setPackageInfo(info);
                    el.setStorage(storage);
        
                    if (list == null)
                        {
                        list = new LinkedList();
                        }
                    list.add(el);
                    }
                }
            catch (ComponentException e) {}
            }
        
        // TODO: remove when the complex property "TConstraints" is implemented
        Object oTConstraints = getPropertyValue(cd, "TConstraints");
        if (oTConstraints != null && oTConstraints != Property.NO_VALUE)
            {
            String sConstraints = (String) oTConstraints;
            if (sConstraints.startsWith("Anchor"))
                {
                sConstraints = "AnchorConstraints." + sConstraints;
                }
            else
                {
                sConstraints = "NamedConstraints." + sConstraints;
                }
        
            sConstraints  = "Component.GUI.Constraints." + sConstraints;
            try
                {
                if (storage.loadComponent(sConstraints, true, null) != null)
                    {
                    CDElement el = new CDElement();
        
                    el.setComponentName(sConstraints);
                    el.setPackageInfo(info);
                    el.setStorage(storage);
        
                    if (list == null)
                        {
                        list = new LinkedList();
                        }
                    list.add(el);
                    }
                }
            catch (ComponentException e) {}
            }
        
        return list;
        }
    
    // Declared at the super level
    /**
    * Initialize the specified ComponentDefinition (of "this" type) at the
    * specified boundaries with default values.
    * 
    * @see #addChildComponent
    */
    public void initializeComponent(com.tangosol.dev.component.Component cd, _package.component.gUI.Rectangle rectBounds)
        {
        super.initializeComponent(cd, rectBounds);
        
        // TODO: layout manager should participate in making a decision
        
        setPropertyValue(cd, "TBounds",
            rectBounds.getX()       + "," +
            rectBounds.getY()       + "," +
            rectBounds.getWidth()   + "," +
            rectBounds.getHeight());
        }
    
    // Declared at the super level
    /**
    * Instantiates a new renderer used to visually represent "this" type of
    * Component Definition in a visual design tool. Subclasses should overwrite
    * this method (usually NOT calling the super implementation).
    * 
    * @param cd Component Definition to instantiate a renderer for
    * 
    * @return a newly instantiated visual component.
    */
    public _package.component.gUI.Control instantiateComponentRenderer(com.tangosol.dev.component.Component cd)
        {
        // import Component.GUI.Control.Container.JComponent.JLabel;
        
        return new JLabel();
        }
    
    // Declared at the super level
    /**
    * Moves the specified holder according to the specified move vector. 
    * Subclasses should overwrite this method changing values of relevant
    * properties.
    */
    public void moveHolder(_package.component.gUI.control.container.jComponent.jPanel.CDHolder holder, _package.component.gUI.Point ptMoveVector)
        {
        // import Component.GUI.Dimension;
        // import Component.GUI.Point;
        
        super.moveHolder(holder, ptMoveVector);
        
        // TODO: layout manager should participate in making a decision
        Point     ptLoc   = holder.getLocation();
        Dimension dimSize = holder.getSize();
        
        ptLoc.add(ptMoveVector);
        
        setPropertyValue(holder.getComponent(), "TBounds",
            ptLoc.getX()       + "," +
            ptLoc.getY()       + "," +
            dimSize.getWidth() + "," +
            dimSize.getHeight()       );

        }
    
    // Declared at the super level
    /**
    * Resizes the specified holder according to the specified resize vector and
    * resize op.  Subclasses should overwrite this method changing values of
    * relevant properties.
    */
    public void resizeHolder(_package.component.gUI.control.container.jComponent.jPanel.CDHolder holder, _package.component.gUI.Point ptSizeVector, int iResizeOp)
        {
        // import Component.GUI.Rectangle;
        
        super.resizeHolder(holder, ptSizeVector, iResizeOp);
        
        // TODO: layout manager should participate in making a decision
        Rectangle rect = holder.getBounds();
        
        int x = rect.getX();
        int y = rect.getY();
        int w = rect.getWidth();
        int h = rect.getHeight();
        
        int dw =  ptSizeVector.getX();
        int dh =  ptSizeVector.getY();
        
        switch (iResizeOp)
            {
            case 0: // NW
            case 3: // W
            case 6: // SW
                x += dw;
                w -= dw;
                break;
            case 2: // NE
            case 5: // E
            case 8: // SE
                w += dw;
                break;
            }
        
        switch (iResizeOp)
            {
            case 0: // NW
            case 1: // N
            case 2: // NE
                y += dh;
                h -= dh;
                break;
            case 6: // SW
            case 7: // S
            case 8: // SE
                h += dh;
                break;
            }
        
        if (w < 0) { w = 0; }
        if (h < 0) { h = 0; }
        
        setPropertyValue(holder.getComponent(), "TBounds",
            x + "," + y + "," + w + "," + h);

        }
    
    // Declared at the super level
    /**
    * Updates attributes of the specified component holder based on the state
    * of the designee [Component Definition].  Subclasses should overwrite this
    * method extracting and applying values of relevant properties either to
    * the holder itself or to its renderer.
    * 
    * Note: we don't specify the type of the holder here to ensure a loose
    * coupling of the Design.Component component with the GUI component tree.
    * More specific knowledge about the type of the holder is asserted at
    * Design.Component.Control level
    * 
    * @see Component.Dev.Design.Component.Control#updateComponentHolder
    */
    public void updateComponentHolder(_package.Component compHolder)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.CDHolder;
        
        super.updateComponentHolder(compHolder);
        
        if (compHolder instanceof CDHolder)
            {
            updateComponentHolder((CDHolder) compHolder);
            }
        }
    
    /**
    * Updates attributes of the specified component holder based on the state
    * of the designee [Component Definition].  Subclasses should overwrite this
    * method extracting and applying values of relevant properties either to
    * the holder itself or to its renderer.
    */
    protected void updateComponentHolder(_package.component.gUI.control.container.jComponent.jPanel.CDHolder holder)
        {
        // import Component.GUI.Control;
        // import Component.GUI.Control.Container.JComponent.JLabel;
        // import Component.GUI.Control.Container.JComponent.JPanel.CDHolder;
        // import Component.GUI.Rectangle;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Property;
        
        Control renderer = holder.getRenderer();
        
        if (renderer instanceof JLabel)
            {
            JLabel label = (JLabel) renderer;
        
            label.setText(holder.getComponent().getName());
            label.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
            label.setVerticalAlignment  (javax.swing.SwingConstants.TOP);
            }
        
        Object oOrder = getPropertyValue(holder.getComponent(), "_Order");
        if (oOrder != Property.NO_VALUE)
            {
            float flOrder = ((Float) oOrder).floatValue();
            if (flOrder != holder.get_Order())
                {
                holder.set_Order(flOrder);
                if (!holder.isRoot() && holder.get_Parent() != null)
                    {
                    ((CDHolder) holder.get_Parent()).update();
                    }
                }
            }
        
        Control.Container temp = new Control.Container();
        
        Component cd = holder.getComponent();
        
        Object oBounds = getPropertyValue(cd, "TBounds");
        if (oBounds != Property.NO_VALUE)
            {
            holder.setTBounds((String) oBounds);
            }
        else if (holder.isRoot())
            {
            holder.setSize(getDefaultHolderSize());
            }
        
        Object oConstraints = getPropertyValue(cd, "TConstraints");
        if (oConstraints != Property.NO_VALUE)
            {
            temp.setTConstraints((String) oConstraints);
            }
        oConstraints = temp.getConstraints();
        boolean fSame = oConstraints == null ? holder.getConstraints() == null :
            oConstraints.equals(holder.getConstraints());
        if (!fSame)
            {
            holder.setConstraints(temp.getConstraints());
            if (!holder.isRoot() && holder.get_Parent() != null)
                {
                ((CDHolder) holder.get_Parent()).update();
                }
            }     
        
        if (renderer != null)
            {
            Object oEnabled = getPropertyValue(cd, "Enabled");
            renderer.setEnabled(oEnabled == Property.NO_VALUE || ((Boolean) oEnabled).booleanValue());
        
            Object oFont = getPropertyValue(cd, "TFont");
            if (oFont != Property.NO_VALUE)
                {
                renderer.setTFont((String) oFont);
                }
            }
        
        Object oVisible = getPropertyValue(cd, "Visible");
        holder.setVisible(oVisible == Property.NO_VALUE || ((Boolean) oVisible).booleanValue());

        }
    }
