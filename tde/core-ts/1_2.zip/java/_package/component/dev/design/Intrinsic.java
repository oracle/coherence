/* Class
*     _package.component.dev.design.Intrinsic
*/

package _package.component.dev.design;

public abstract class Intrinsic
        extends    _package.component.dev.Design
    {
    // Fields declarations
    
    // Initializing constructor
    public Intrinsic(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/Intrinsic".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        String sText = super.getText(oValue, dtValue);
        return sText != null ? sText : String.valueOf(oValue);
        }
    }
