/* Class
*     _package.component.dev.design.component.Application
*/

package _package.component.dev.design.component;

import _package.component.dev.packager.Model;
import _package.component.dev.packager.entry.TransientEntry;
import _package.component.util.Config;
import com.tangosol.dev.component.Property;
import java.beans.PropertyVetoException;
import java.util.LinkedList;
import java.util.List;

public class Application
        extends    _package.component.dev.design.Component
    {
    // Fields declarations
    private static final String[] __s_Tools;
    
    // Static initializer
    static
        {
        try
            {
            String[] a0 = new String[6];
                {
                a0[0] = "OutputTool";
                a0[1] = "Host.CDTool.ContainmentTool";
                a0[2] = "Host.CDTool.PropertyTool";
                a0[3] = "Host.CDTool.ScriptingTool";
                a0[4] = "Host.CDTool.IntegrationTool";
                a0[5] = "Host.CDTool.PackagingTool";
                }
            __s_Tools = a0;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public Application()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Application(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setRemotable(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant Tools
    protected String[] getTools()
        {
        return (String[]) __s_Tools.clone();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Application();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/component/Application".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Return the content of the config ("application.properties") entry for the
    * specified application component.
    * Default implementation creates just one "Application" attribute.
    * Subcomponents override this method if they need to add anything to the
    * configuration file.
    */
    protected String getConfigContent(com.tangosol.dev.component.Component cd)
        {
        return cd.isResultAbstract() ? null : "Application=" + cd.getQualifiedName();
        }
    
    // Declared at the super level
    /**
    * Return the PackagerEntries for the specified Component Definition (of
    * "this" Component Definition type) that cannot be "calculated" based on
    * the dependency information/class traversal. Subclasses usually override
    * this method returning lists of TransientEntry or ResourceEntry objects.
    * 
    * @param cd  component for which the PackagerEntries should be calculated
    * @param storage  storage to be used to load any necessary components
    * @param info  packaging information used by the current packaging model
    * 
    * @see Packager.Element.CDElement#getPackagerEntries
    */
    public java.util.List getPackagerEntries(com.tangosol.dev.component.Component cd, _package.component.dev.Storage storage, _package.component.dev.packager.PackageInfo info)
        {
        // import Component.Dev.Packager.Model;
        // import Component.Dev.Packager.Entry.TransientEntry;
        // import Component.Util.Config;
        // import com.tangosol.dev.component.Property;
        // import java.util.List;
        // import java.util.LinkedList;
        
        List list = super.getPackagerEntries(cd, storage, info);
        
        if (info.getIncludeComponents().containsKey(cd.getQualifiedName()))
            {
            if (list == null)
                {
                list = new LinkedList();
                }
        
            Model packager = info.getModel();
        
            // create "/application.properties"
                {
                String sInitConfig  = (String) getPropertyValue(cd, "FILE_CFG_INITIAL");
                String sPackageName = packager.getConfigPath(sInitConfig);
                String sConfig      = getConfigContent(cd);
        
                if (sConfig != null)
                    {
                    byte[]         abData = sConfig.getBytes();
                    TransientEntry entry  = packager.makeResourceEntry(abData, sPackageName);
        
                    list.add(entry);
                    }
                }
        
            // create "/META-INF/<appName>.properties"
                {
                String sHostConfig = cd.getName();
        
                String sStorageName = Config.resolveName(sHostConfig);
                String sPackageName = packager.getConfigPath(sHostConfig);
        
                TransientEntry entry = packager.makeResourceEntry(sStorageName, sPackageName);
                    
                if (entry != null)
                    {
                    list.add(entry);
                    }
                }
            }
        
        return list;
        }
    
    // Declared at the super level
    /**
    * Initialize the specified ComponentDefinition (of "this" type) with
    * default attributes.
    * 
    * @see #addChildComponent
    */
    public void initializeComponent(com.tangosol.dev.component.Component cd)
        {
        // import java.beans.PropertyVetoException;
        
        boolean fAbstract = cd.isAbstract();
        
        super.initializeComponent(cd);
        
        // implementation attribute suggestion:
        // use the inherited value
        try
            {
            cd.setAbstract(fAbstract);
            }
        catch (PropertyVetoException e) {}
        }
    }
