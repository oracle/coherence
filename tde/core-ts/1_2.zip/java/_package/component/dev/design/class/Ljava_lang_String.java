/* Class
*     _package.component.dev.design.class.Ljava_lang_String
*/

package _package.component.dev.design.class;

import com.tangosol.dev.component.Property;

public class Ljava_lang_String
        extends    _package.component.dev.design.Class
    {
    // Fields declarations
    
    /**
    * Property TEXT_ESCAPE
    *
    */
    public static final String TEXT_ESCAPE = "[esc]";
    
    // Default constructor
    public Ljava_lang_String()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Ljava_lang_String(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Ljava_lang_String();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/class/Ljava_lang_String".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        Object oValue;
        
        if (sText != null && sText.startsWith(TEXT_ESCAPE))
            {
            oValue = sText.substring(TEXT_ESCAPE.length());
            }
        else
            {
            oValue = super.convertText(sText, dtValue, storage);
            if (oValue == VALUE_UNKNOWN)
                {
                oValue = sText;
                }
            }
        
        return oValue;
        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        // import com.tangosol.dev.component.Property;
        
        // super is not called; the net effect of super is "pasted"
        // into this implementation to allow the escaping of "internal"
        // and other values
        
        String sText;
        if (oValue == Property.NO_VALUE)
            {
            sText = TEXT_NO_VALUE;
            }
        else if (oValue == null)
            {
            sText = TEXT_NULL;
            }
        else
            {
            sText = (String) oValue;
            if (requiresEscape(sText))
                {
                sText = TEXT_ESCAPE + sText;
                }
            }
        
        return sText;
        }
    
    // Declared at the super level
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        return true;
        }
    
    private boolean requiresEscape(String s)
        {
        return s.equals(TEXT_NO_VALUE)
            || s.equals(TEXT_NULL)
            || s.startsWith(TEXT_ESCAPE)
            || s.indexOf("\\u") >= 0; // not implemented
        }
    }
