/* Class
*     _package.component.dev.design.class.Ljava_math_BigDecimal
*/

package _package.component.dev.design.class;

import com.tangosol.dev.assembler.Aconst;
import com.tangosol.dev.assembler.CodeAttribute;
import com.tangosol.dev.assembler.Constant;
import com.tangosol.dev.assembler.Dup;
import com.tangosol.dev.assembler.Invokespecial;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.assembler.New;
import com.tangosol.dev.assembler.SignatureConstant;
import com.tangosol.dev.assembler.StringConstant;
import java.math.BigDecimal;

public class Ljava_math_BigDecimal
        extends    _package.component.dev.design.Class
    {
    // Fields declarations
    
    // Default constructor
    public Ljava_math_BigDecimal()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Ljava_math_BigDecimal(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Ljava_math_BigDecimal();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/class/Ljava_math_BigDecimal".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Generates Java class byte codes for a constant value initialization
    * 
    * @param gen ClassGenerator producing a Java class
    * @param oValue value to generate an initializer for
    * @param dtType data type of the specified value
    * 
    * @throws IllegalArgumentException if the code generation is not possible
    * due to an unknown value [data type]
    * 
    * @see #getValue
    * @see Component.Dev.Compiler.ClassGenerator#addConstantInitializer
    * @see Component.Dev.Compiler.ClassGenerator#addPropertyInitializer
    */
    protected void addConstantInitializer(_package.component.dev.compiler.ClassGenerator gen, Object oValue, com.tangosol.dev.component.DataType dtType)
        {
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.Constant;
        // import com.tangosol.dev.assembler.StringConstant;
        // import com.tangosol.dev.assembler.Aconst;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.SignatureConstant;
        // import com.tangosol.dev.assembler.New;
        // import com.tangosol.dev.assembler.Dup;
        // import com.tangosol.dev.assembler.Invokespecial;
        // import java.math.BigDecimal;
        
        if (oValue == null)
            {
            super.addConstantInitializer(gen, oValue, dtType);
            return;
            }
        
        _assert(oValue instanceof BigDecimal &&
            dtType.getClassName().equals("java.math.BigDecimal"));
            
        String        sValue = ((BigDecimal) oValue).toString();
        CodeAttribute code   = gen.getCode();
        
        code.add(new New(dtType.getClassConstant()));
        code.add(new Dup());
        code.add(new Aconst(new StringConstant(sValue)));
        MethodConstant cM_new = new MethodConstant(dtType.getClassConstant(),
            new SignatureConstant(gen.CONSTRUCTOR_NAME, "(Ljava.lang.String;)V"));
        code.add(new Invokespecial(cM_new));
        
        gen.print("new " + dtType.getClassName() + "(\"" + sValue + "\")");
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        // import java.math.BigDecimal;
        
        Object oValue = super.convertText(sText, dtValue, storage);
        
        if (oValue == VALUE_UNKNOWN)
            {
            try
                {
                oValue = new BigDecimal(sText);
                }
            catch (NumberFormatException e) {}
            }
        return oValue;
        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        // import java.math.BigDecimal;
        
        if (oValue instanceof BigDecimal)
            {
            return oValue.toString();
            }
        
        return super.getText(oValue, dtValue);
        }
    
    // Declared at the super level
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        // import java.math.BigDecimal;
        
        if (super.isTextLegal(sText, dtValue, storage))
            {
            return true;
            }
        
        try
            {
            new BigDecimal(sText);
            return true;
            }
        catch (NumberFormatException e)
            {
            return false;
            }
        }
    }
