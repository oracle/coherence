/* Class
*     _package.component.dev.design.component.application.Enterprise
*/

package _package.component.dev.design.component.application;

public class Enterprise
        extends    _package.component.dev.design.component.Application
    {
    // Fields declarations
    
    /**
    * Property PD_ContextCaching
    *
    */
    
    /**
    * Property PD_ContextCachingWeb
    *
    */
    
    /**
    * Property PD_CTXCACHE_GLOBAL
    *
    */
    
    /**
    * Property PD_CTXCACHE_NONE
    *
    */
    
    /**
    * Property PD_CTXCACHE_SERVERDEFAULT
    *
    */
    
    /**
    * Property PD_CTXCACHE_THREAD
    *
    */
    
    // Default constructor
    public Enterprise()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Enterprise(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setRemotable(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant PD_ContextCaching
    public String getPD_ContextCaching()
        {
        return "Intrinsic.Integer.Enum.CacheScope.ApplicationCacheScope";
        }
    
    // Getter for virtual constant PD_ContextCachingWeb
    public String getPD_ContextCachingWeb()
        {
        return "Intrinsic.Integer.Enum.ContextScope.AttributeContextScope";
        }
    
    // Getter for virtual constant PD_CTXCACHE_GLOBAL
    public String getPD_CTXCACHE_GLOBAL()
        {
        return "Intrinsic.Integer.Enum.CacheScope.ApplicationCacheScope";
        }
    
    // Getter for virtual constant PD_CTXCACHE_NONE
    public String getPD_CTXCACHE_NONE()
        {
        return "Intrinsic.Integer.Enum.CacheScope.ApplicationCacheScope";
        }
    
    // Getter for virtual constant PD_CTXCACHE_SERVERDEFAULT
    public String getPD_CTXCACHE_SERVERDEFAULT()
        {
        return "Intrinsic.Integer.Enum.CacheScope.ApplicationCacheScope";
        }
    
    // Getter for virtual constant PD_CTXCACHE_THREAD
    public String getPD_CTXCACHE_THREAD()
        {
        return "Intrinsic.Integer.Enum.CacheScope.ApplicationCacheScope";
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Enterprise();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/component/application/Enterprise".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Return the content of the config ("application.properties") entry for the
    * specified application component.
    * Default implementation creates just one "Application" attribute.
    * Subcomponents override this method if they need to add anything to the
    * configuration file.
    */
    protected String getConfigContent(com.tangosol.dev.component.Component cd)
        {
        String sContent = super.getConfigContent(cd);
        if (sContent != null)
            {
            sContent += "\nApplication.DebugEcho=false";
            }
        return sContent;
        }
    }
