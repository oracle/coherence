/* Class
*     _package.component.dev.design.Component
*/

package _package.component.dev.design;

import _package.component.dev.Design;
import _package.component.dev.Tool;
import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.CodeAttribute;
import com.tangosol.dev.assembler.Dup;
import com.tangosol.dev.assembler.Invokespecial;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.assembler.New;
import com.tangosol.dev.assembler.SignatureConstant;
import com.tangosol.dev.component.Behavior;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.Constants;
import com.tangosol.dev.component.DataType;
import com.tangosol.dev.component.Property;
import com.tangosol.util.LiteSet;
import com.tangosol.util.WrapperException;
import java.beans.PropertyVetoException;
import java.util.Enumeration;

/**
* Component that represents the design information for the corresponding
* Component Definition.
*/
public class Component
        extends    _package.component.dev.Design
    {
    // Fields declarations
    
    /**
    * Property DesignTools
    *
    * Specifies a set of tools used to design "this" type of Component
    * Definition.
    */
    
    /**
    * Property Remotable
    *
    * Boolean value that specifies whether the Remote attribute for "this" type
    * of Component Definition may be set.
    * 
    */
    private boolean __m_Remotable;
    private static final String[] __s_TextChoices;
    
    /**
    * Property Tools
    *
    * Specifies a set of tool class names used to design "this" type of
    * Component Definition. Each class assumed to specify a sub component of
    * Component.Dev.Tool.
    * 
    * Note: we choose to design String names rather then Class directly in
    * order to avoid unneccessary component dependency
    * 
    * @see #getDesignTools
    */
    private static final String[] __s_Tools;
    
    // Static initializer
    static
        {
        try
            {
            String[] a0 = new String[2];
                {
                a0[0] = "[none]";
                a0[1] = "[null]";
                }
            __s_TextChoices = a0;
            String[] a1 = new String[5];
                {
                a1[0] = "OutputTool";
                a1[1] = "Host.CDTool.ContainmentTool";
                a1[2] = "Host.CDTool.PropertyTool";
                a1[3] = "Host.CDTool.ScriptingTool";
                a1[4] = "Host.CDTool.IntegrationTool";
                }
            __s_Tools = a1;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public Component()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Component(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setRemotable(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant TextChoices
    public String[] getTextChoices()
        {
        return (String[]) __s_TextChoices.clone();
        }
    
    // Getter for virtual constant Tools
    protected String[] getTools()
        {
        return (String[]) __s_Tools.clone();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Component();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/Component".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Adds a child Component Definition of the specified heritage (component
    * type) to the specified parent Component Definition (of "this" type).
    * 
    * @see #initializeComponent
    */
    public com.tangosol.dev.component.Component addChildComponent(com.tangosol.dev.component.Component cdParent, String sSuper, _package.component.dev.Storage storage)
        {
        // import com.tangosol.dev.component.Component;
        
        String sPrefix = sSuper.substring(sSuper.lastIndexOf('.') + 1);
        String sChild;
        
        for (int i = 1; true; i++)
            {
            sChild = sPrefix + "_" + i;
            if (cdParent.getChild(sChild) == null &&
               !cdParent.isChildUnremovable(sChild))
                {
                break;
                }
            }
        
        try
            {
            Component cdSuper = storage.loadComponent(sSuper, true, null);
        
            if (isChildAddable(cdParent, cdSuper, sChild))
                {
                // the following adds the child holder and selects it
                return cdParent.addChild(cdSuper, sChild);
                }
            }
        // ComponentException, PropertyVetoException
        catch (Exception e)
            {
            _trace("Failed to insert component " + e.getMessage(), 1);
            }
        
        return null;
        }
    
    /**
    * Adds a child Component Definition of the specified heritage (component
    * type) to the specified parent Component Definition (of "this" type) at
    * the specified boundaries.
    * 
    * @see #initializeComponent
    */
    public com.tangosol.dev.component.Component addChildComponent(com.tangosol.dev.component.Component cdParent, String sSuper, _package.component.dev.Storage storage, _package.component.gUI.Rectangle rectBounds)
        {
        return addChildComponent(cdParent, sSuper, storage);
        }
    
    // Declared at the super level
    /**
    * Generates Java class byte codes for a constant value initialization
    * 
    * @param gen ClassGenerator producing a Java class
    * @param oValue value to generate an initializer for
    * @param dtType data type of the specified value
    * 
    * @throws IllegalArgumentException if the code generation is not possible
    * due to an unknown value [data type]
    * 
    * @see #getValue
    * @see Component.Dev.Compiler.ClassGenerator#addConstantInitializer
    * @see Component.Dev.Compiler.ClassGenerator#addPropertyInitializer
    */
    public void addConstantInitializer(_package.component.dev.compiler.ClassGenerator gen, Object oValue, com.tangosol.dev.component.DataType dtType, String sPrefix, String sPostfix)
        {
        // import Component.Dev.Design;
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.New;
        // import com.tangosol.dev.assembler.Dup;
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.SignatureConstant;
        // import com.tangosol.dev.assembler.Invokespecial;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.Behavior;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.util.LiteSet;
        // import java.util.Enumeration;
        
        if (oValue == null)
            {
            super.addConstantInitializer(gen, oValue, dtType, sPrefix, sPostfix);
            return;
            }
        
        _assert(oValue instanceof Component && dtType.isComponent());
        
        CodeAttribute code      = gen.getCode();
        Component     cdComplex = (Component) oValue;
        
        _assert(cdComplex.isComplex());
        
        Component cd = gen.getComponent(cdComplex.getSuperName());
        
        _assert(cd != null);
        _assert(cd.isStatic() != cd.isGlobal());
        _assert(!cd.isResultAbstract());
        _assert(cd.isDerivedFrom(dtType.getComponentName()));
        
        // determine if we will be setting properties after construction
        LiteSet setSetProperties = null;
        for (Enumeration enum = cdComplex.getProperties(); enum.hasMoreElements();)
            {
            Property propComplex = (Property) enum.nextElement();
            if (!propComplex.isNoValue())
                {
                Property propComponent = cd.getProperty(propComplex.getName());
                _assert(propComponent != null);
                if (!propComponent.isValueEqual(propComplex.getValue()))
                    {
                    if (setSetProperties == null)
                        {
                        setSetProperties = new LiteSet();
                        }
                    setSetProperties.add(propComplex);
                    }
                }
            }
        
        DataType      dtCD   = gen.resolveDataType(DataType.getComponentType(cd.getQualifiedName()));
        String        sClz   = gen.formatClass(dtCD.getClassName());
        ClassConstant cC_clz = dtCD.getClassConstant();
        String        sCD    = null;
        
        if (setSetProperties == null)
            {
            gen.print(sPrefix);
            }
        else
            {
            sCD = "cd" + gen.getNextTempVariableNumber();
            gen.print(sClz + " " + sCD + " = ");
            }
        
        // should we call get_Instance instead of the "new" ?
        code.add(new New(cC_clz));
        code.add(new Dup());
        MethodConstant cM_new = new MethodConstant(cC_clz,
            new SignatureConstant("<init>", "()V"));
        code.add(new Invokespecial(cM_new));
        
        gen.print("new " + sClz + "()");
        
        if (setSetProperties == null)
            {
            gen.print(sPostfix);
            return;
            }
        
        gen.println(";");
        
        gen.BeginScope();
            {
            for (Enumeration enum = setSetProperties.elements(); enum.hasMoreElements();)
                {
                Property propComplex = (Property) enum.nextElement();
                Property prop        = cd.getProperty(propComplex.getName());
                DataType dtProp      = prop.getDataType();
                Behavior bhvrSetter  = gen.getSetter(prop);
        
                code.add(new Dup());
        
                Design designInfo = getDesignInfo(prop);
                designInfo.addConstantInitializer(gen, propComplex.getValue(),
                    prop.isSingle() ? dtProp : dtProp.getArrayType(),
                        sCD + "." + bhvrSetter.getName() + "(", ");");
            
                gen.addMethodCall(bhvrSetter);
                gen.println();
                }
            }
        gen.EndScope();
        
        gen.print(sPrefix + sCD + sPostfix);
        }
    
    /**
    * This is used by both isTextLegal and convertText to process the string
    * text, since they have almost identical processing needs.
    * 
    * @param sText  a string value to process
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to process the string
    * @param fTextLegalCheck  flag if this is an isTextLegal check or not
    * 
    * @return the converted component or VALUE_UNKNOWN if the text is not legal
    * 
    * @see #isTextLegal
    * @see #convertText
    */
    private Object convertComponentText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage, boolean fTextLegalCheck)
        {
        // import Component.Dev.Design;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.ComponentException;
        // import java.beans.PropertyVetoException;
        
        // we will use a url style syntax for now, for example:
        //
        //   MyComponent.SubComponent?Prop1=abc&Prop1=[none]&Prop3=true
        
        // parse out the component name from the text
        String sComponent;
        int of = sText.indexOf('?');
        if (of == -1)
            {
            sComponent = sText;
            sText      = "";
            }
        else
            {
            sComponent = sText.substring(0, of);
            sText      = sText.substring(of + 1);
            }
        
        // make sure that there is a such a component, it's not abstract
        // and derives from the specified data type
        String sBaseType = dtValue.getComponentName();
        
        if (!Component.isQualifiedNameLegal(sComponent))
            {
            // must at least start with the base type's short name
            int    ofShort    = sBaseType.lastIndexOf('.') + 1;
            String sShortName = sBaseType.substring(ofShort);
        
            if (!sComponent.equals(sShortName) && !sComponent.startsWith(sShortName + '.'))
                {
                return VALUE_UNKNOWN;
                }
            sComponent = sBaseType.substring(0, ofShort) + sComponent;
            }
        
        if (!Component.isQualifiedNameLegal(sComponent))
            {
            return VALUE_UNKNOWN;
            }
        
        // load the component from storage
        String sGlobalName = Component.getGlobalName(sComponent);
        String sLocalName  = Component.getLocalName (sComponent);
        
        Component cd = null;
        try
            {
            cd = storage.loadComponent(sGlobalName, true, null);
            }
        catch (ComponentException e) {}
        
        if (cd != null && sLocalName != null)
            {
            cd = cd.getLocal(sLocalName);
            }
        
        if (cd == null)
            {
            return VALUE_UNKNOWN;
            }
        
        // static global components and instance children are not allowed
        if (cd.isStatic() == cd.isGlobal()
            || cd.isResultAbstract()
            || !cd.isDerivedFrom(sBaseType))
            {
            return VALUE_UNKNOWN;
            }
        
        // the component must be able to create complex properties
        cd = cd.createComplexProperty();
        if (cd == null)
            {
            return VALUE_UNKNOWN;
            }
        
        // process all of the specified property name/value pairs
        // specified in the string text
        for (;;)
            {
            // get the length still left in the text
            int iLength = sText.length();
            if (iLength == 0)
                {
                // success, return the complex property value object
                return cd;
                }
        
            // find the end of the property name
            of = sText.indexOf('=');
            if (of == -1)
                {
                return VALUE_UNKNOWN;
                }
            String sName = sText.substring(0, of);
        
            // parse the value, we need to deal with escaped value terminators
            // so that complex property values can be nested
            StringBuffer sb = new StringBuffer();
            for (;;)
                {
                // if we are at the end of the text, we are all done
                if (++of >= iLength)
                    {
                    sText = "";
                    break;
                    }
                // get the next character in the text
                char c = sText.charAt(of);
                switch (c)
                    {
                    case '&':
                        // found the end, set up the remaining text
                        sText = sText.substring(of + 1);
                        break;
                    case '\\':
                        // the escape character, first make sure there
                        // is another character and then use that character
                        // in the value
                        if (++of >= iLength)
                            {
                            sText = "";
                            break;
                            }
                        c = sText.charAt(of);
                        // fall into default
                    default:
                        sb.append(c);
                        continue;
                    }
                break;
                }
            String sValue = sb.toString();
        
            // get the Property that is being set and
            // it's associated data type and design info
            Property prop = cd.getProperty(sName);
            if (prop == null)
                {
                return VALUE_UNKNOWN;
                }
            Design   designInfo = getDesignInfo(prop);
            DataType dtProp     = prop.getDataType();
            DataType dtPropVal  = prop.isSingle() ? dtProp : dtProp.getArrayType();
        
            // check if we just need to check if the text is legal
            // or if we are converting the text to a value
            if (fTextLegalCheck)
                {
                // check if the value is legal for the property
                if (!designInfo.isTextLegal(sValue, dtPropVal, storage))
                    {
                    return VALUE_UNKNOWN;
                    }
                }
            else
                {
                // convert the text to a value object
                Object oValue = designInfo.getValue(sValue, dtPropVal, storage);
                if (oValue == VALUE_UNKNOWN)
                    {
                    return VALUE_UNKNOWN;
                    }
                // set the value into the property
                try
                    {
                    prop.setValue(oValue);
                    }
                catch (PropertyVetoException pve)
                    {
                    return VALUE_UNKNOWN;
                    }
                }
        
            // loop back to process the next property name/value pair
            }
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        Object oValue = super.convertText(sText, dtValue, storage);
        if (oValue != VALUE_UNKNOWN)
            {
            return oValue;
            }
        
        if (sText.equals(TEXT_NULL))
            {
            return null;
            }
        
        return convertComponentText(sText, dtValue, storage, false);
        }
    
    /**
    * Return a list of PackagerDependencyElements for the specified Component
    * Definition (of "this" Component Definition type) that cannot be
    * "calculated" based on the dependency information/class traversal.
    * Subclasses usually override this method returning lists of CDElement or
    * TransientEntry objects.
    * 
    * @param cd  component for which the PackagerDependencyElements should be
    * calculated
    * @param storage  storage to be used to load any necessary components
    * @param info  packaging information used by the current packaging model
    * 
    * @see Packager.Element.CDElement#getDependents
    */
    public java.util.List getDependents(com.tangosol.dev.component.Component cd, _package.component.dev.Storage storage, _package.component.dev.packager.PackageInfo info)
        {
        return null;
        }
    
    // Accessor for the property "DesignTools"
    /**
    * Returns a set of classes for tools used to design this component.
    * 
    * The base tools are:
    * 
    * Component.Dev.Tool.OutputTool
    * Component.Dev.Tool.Host.CDTool.ContainmentTool,
    * Component.Dev.Tool.Host.CDTool.PropertyTool,
    * Component.Dev.Tool.Host.CDTool.ScriptingTool,
    * Component.Dev.Tool.Host.CDTool.IntegrationTool
    */
    public _package.component.dev.Tool[] getDesignTools()
        {
        // import Component.Dev.Tool;
        
        String[]  asTool = getTools();
        int      cTools  = asTool.length;
        Tool[]   aTool   = new Tool[cTools];
        
        for (int i = 0; i < cTools; i++)
            {
            String sTool = asTool[i];
        
            if (!sTool.startsWith("Component.Dev.Tool."))
                {
                sTool = "Component.Dev.Tool." + sTool;
                }
            
            try
                {
                aTool[i] = (Tool) _newInstance(sTool);
                }
            catch (Exception e)
                {
                _trace(e);
                }
            }
        
        return aTool;
        }
    
    // Accessor for the property "DesignTools"
    /**
    * Getter for property DesignTools.<p>
    * Specifies a set of tools used to design "this" type of Component
    * Definition.
    */
    public _package.component.dev.Tool getDesignTools(int pIndex)
        {
        return getDesignTools()[pIndex];
        }
    
    /**
    * Return the PackagerEntries for the specified Component Definition (of
    * "this" Component Definition type) that cannot be "calculated" based on
    * the dependency information/class traversal. Subclasses usually override
    * this method returning lists of TransientEntry or ResourceEntry objects.
    * 
    * @param cd  component for which the PackagerEntries should be calculated
    * @param storage  storage to be used to load any necessary components
    * @param info  packaging information used by the current packaging model
    * 
    * @see Packager.Element.CDElement#getPackagerEntries
    */
    public java.util.List getPackagerEntries(com.tangosol.dev.component.Component cd, _package.component.dev.Storage storage, _package.component.dev.packager.PackageInfo info)
        {
        return null;
        }
    
    /**
    * Gets a value of the specified property for the specified Component
    * Definition (of "this" Component Definition type)
    */
    public Object getPropertyValue(com.tangosol.dev.component.Component cd, String sProp)
        {
        // import com.tangosol.dev.component.Property;
        
        Property prop = cd.getProperty(sProp);
        if (prop == null)
            {
            throw new IllegalArgumentException("Non-existing property: " + sProp);
            }
        
        return prop.getValue();
        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Constants;
        // import com.tangosol.dev.component.DataType;
        // import com.tangosol.dev.component.Property;
        // import java.util.Enumeration;
        
        String sText = super.getText(oValue, dtValue);
        if (sText != null || !dtValue.isComponent())
            {
            return sText;
            }
        
        if (oValue == null)
            {
            return TEXT_NULL;
            }
        
        Component cd = (Component) oValue;
        _assert(cd.isComplex());
        String sBaseType  = dtValue.getComponentName();
        String sComponent = cd.getQualifiedName();
        
        if (sComponent.equals(sBaseType) || sComponent.startsWith(sBaseType + '.'))
            {
            int    ofShort    = sBaseType.lastIndexOf('.') + 1;
            String sShortName = sBaseType.substring(ofShort);
        
            sComponent = sShortName + sComponent.substring(sBaseType.length());
            }
        
        StringBuffer sb = new StringBuffer(sComponent);
        char cDelimiter = '?';
        
        for (Enumeration enum = cd.getProperties(); enum.hasMoreElements();)
            {
            Property prop = (Property) enum.nextElement();
        
            if (prop.getVisible() == Constants.VIS_VISIBLE)
                {
                sb.append(cDelimiter)
                  .append(prop.getName())
                  .append('=');
        
                DataType dtProp = prop.getDataType();
                String   sValue = getDesignInfo(prop).getText(prop.getValue(),
                    prop.isSingle() ? dtProp : dtProp.getArrayType());
        
                char[] ac  = sValue.toCharArray();
                int    cnt = ac.length;
                for (int i = 0; i < cnt; ++i)
                    {
                    char c = ac[i];
                    switch (c)
                        {
                        case '&':
                        case '\\':
                            sb.append('\\');
                        }
                    sb.append(c);
                    }
                cDelimiter = '&';
                }
            }
        
        return sb.toString();
        }
    
    /**
    * Initialize the specified ComponentDefinition (of "this" type) with
    * default attributes.
    * 
    * @see #addChildComponent
    */
    public void initializeComponent(com.tangosol.dev.component.Component cd)
        {
        // import com.tangosol.dev.component.Component;
        // import java.beans.PropertyVetoException;
        
        // scope attribute suggestion:
        if (!cd.isGlobal())
            {
            // try to make the best friendly suggestion for the child's scope by
            // a) starting with the parent's scope
            // b) suggesting the scope of any sibling of the same category
        
            Component cdParent  = cd.getParent();
            String    sCategory = cd.getCategory();
            boolean   fStatic   = cdParent.isStatic();
            String[]  asSibling = cdParent.getChildren();
        
            for (int i = 0; i < asSibling.length; i++)
                {
                String sSibling = asSibling[i];
                if (cdParent.getChild(sSibling) == cd)
                    {
                    continue;
                    }
                Component cdSibling = cdParent.getChild(sSibling);
                if (cdSibling != null && cdSibling.isDerivedFrom(sCategory))
                    {
                    fStatic = cdSibling.isStatic();
                    break;
                    }
                }
        
            if (fStatic)
                {
                try
                    {
                    cd.setStatic(true);
                    }
                catch (PropertyVetoException e) {}
                }
            }
        
        // implementation attribute suggestion:
        // always try to "un-abstract" the component
        try
            {
            cd.setAbstract(false);
            }
        catch (PropertyVetoException e) {}

        }
    
    /**
    * Initialize the specified ComponentDefinition (of "this" type) at the
    * specified boundaries with default values.
    * 
    * @see #addChildComponent
    */
    public void initializeComponent(com.tangosol.dev.component.Component cd, _package.component.gUI.Rectangle rectBounds)
        {
        initializeComponent(cd);
        }
    
    /**
    * Instantiates a new renderer used to visually represent "this" type of
    * Component Definition in a visual design tool. Subclasses should overwrite
    * this method (usually NOT calling the super implementation).
    * 
    * @param cd Component Definition to instantiate a renderer for
    * 
    * @return a newly instantiated visual component.
    */
    public _package.component.gUI.Control instantiateComponentRenderer(com.tangosol.dev.component.Component cd)
        {
        return null;
        }
    
    /**
    * Return true if the specified parent (of "this" Component Definition type)
    * allows adding a child of the specified heritage and name.
    * 
    * This method is supposed to be overriden by subclasses that know better
    * (for example not allowing to insert a JRadioButton into anything but
    * ButtonGroupPanel)
    */
    protected boolean isChildAddable(com.tangosol.dev.component.Component cdParent, com.tangosol.dev.component.Component cdSuper, String sChild)
        {
        return cdParent.isChildAddable(cdSuper, sChild);
        }
    
    // Accessor for the property "Remotable"
    /**
    * Getter for property Remotable.<p>
    * Boolean value that specifies whether the Remote attribute for "this" type
    * of Component Definition may be set.
    * 
    */
    public boolean isRemotable()
        {
        return __m_Remotable;
        }
    
    // Declared at the super level
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        if (super.isTextLegal(sText, dtValue, storage) || sText.equals(TEXT_NULL))
            {
            return true;
            }
        
        return convertComponentText(sText, dtValue, storage, true) != VALUE_UNKNOWN;

        }
    
    /**
    * Moves the specified holder according to the specified move vector. 
    * Subclasses should overwrite this method changing values of relevant
    * properties.
    */
    public void moveHolder(_package.component.gUI.control.container.jComponent.jPanel.CDHolder holder, _package.component.gUI.Point ptMoveVector)
        {
        }
    
    /**
    * Resizes the specified holder according to the specified resize vector and
    * resize op.  Subclasses should overwrite this method changing values of
    * relevant properties.
    */
    public void resizeHolder(_package.component.gUI.control.container.jComponent.jPanel.CDHolder holder, _package.component.gUI.Point ptSizeVector, int iResizeOp)
        {
        }
    
    /**
    * Sets the specified property to the specified value for the specified
    * component (of "this" Component Definition type)
    */
    public void setPropertyValue(com.tangosol.dev.component.Component cd, String sProp, Object oValue)
        {
        // import com.tangosol.dev.component.Property;
        // import com.tangosol.util.WrapperException;
        // import java.beans.PropertyVetoException;
        
        Property prop = cd.getProperty(sProp);
        if (prop == null)
            {
            throw new IllegalArgumentException("Non-existing property: " + sProp);
            }
        
        try
            {
            prop.setValue(oValue);
            }
        catch (PropertyVetoException e)
            {
            throw new WrapperException(e);
            }
        }
    
    // Accessor for the property "Remotable"
    /**
    * Setter for property Remotable.<p>
    * Boolean value that specifies whether the Remote attribute for "this" type
    * of Component Definition may be set.
    * 
    */
    public void setRemotable(boolean pRemotable)
        {
        __m_Remotable = pRemotable;
        }
    
    /**
    * Updates attributes of the specified component holder based on the state
    * of the designee [Component Definition].  Subclasses should overwrite this
    * method extracting and applying values of relevant properties either to
    * the holder itself or to its renderer.
    * 
    * Note: we don't specify the type of the holder here to ensure a loose
    * coupling of the Design.Component component with the GUI component tree.
    * More specific knowledge about the type of the holder is asserted at
    * Design.Component.Control level
    * 
    * @see Component.Dev.Design.Component.Control#updateComponentHolder
    */
    public void updateComponentHolder(_package.Component compHolder)
        {
        }
    }
