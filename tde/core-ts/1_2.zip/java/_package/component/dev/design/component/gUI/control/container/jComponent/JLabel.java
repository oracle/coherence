/* Class
*     _package.component.dev.design.component.gUI.control.container.jComponent.JLabel
*/

package _package.component.dev.design.component.gUI.control.container.jComponent;

import _package.component.dev.packager.element.CDElement;
import _package.component.gUI.Control;
import _package.component.gUI.control.container.jComponent.JLabel;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.Property;
import java.util.LinkedList;
import java.util.List;
import javax.swing.SwingConstants; // as Constants

/**
* +++++++
* 
* This component represents a Component.GUI.Control.Container.JComponent.JLabel
* type of Component Definition. It is aware of such properties of the
* corresponding Component Definition as DisplayedMnemonic, Icon, Text,
* HorizontalAlignment, VerticalAlignment, HorizontalTextPosition,
* VerticalTextPosition.
*/
public class JLabel
        extends    _package.component.dev.design.component.gUI.control.container.JComponent
    {
    // Fields declarations
    
    /**
    * Property PD_HorizontalAlignment
    *
    */
    
    /**
    * Property PD_HorizontalTextPosition
    *
    */
    
    /**
    * Property PD_VerticalAlignment
    *
    */
    
    /**
    * Property PD_VerticalTextPosition
    *
    */
    
    // Default constructor
    public JLabel()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JLabel(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setRemotable(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant PD_HorizontalAlignment
    public String getPD_HorizontalAlignment()
        {
        return "Intrinsic.Integer.Position.HorizontalAlignment";
        }
    
    // Getter for virtual constant PD_HorizontalTextPosition
    public String getPD_HorizontalTextPosition()
        {
        return "Intrinsic.Integer.Position.HorizontalTextPosition";
        }
    
    // Getter for virtual constant PD_VerticalAlignment
    public String getPD_VerticalAlignment()
        {
        return "Intrinsic.Integer.Position.VerticalAlignment";
        }
    
    // Getter for virtual constant PD_VerticalTextPosition
    public String getPD_VerticalTextPosition()
        {
        return "Intrinsic.Integer.Position.VerticalTextPosition";
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JLabel();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/component/gUI/control/container/jComponent/JLabel".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Return a list of PackagerDependencyElements for the specified Component
    * Definition (of "this" Component Definition type) that cannot be
    * "calculated" based on the dependency information/class traversal.
    * Subclasses usually override this method returning lists of CDElement or
    * TransientEntry objects.
    * 
    * @param cd  component for which the PackagerDependencyElements should be
    * calculated
    * @param storage  storage to be used to load any necessary components
    * @param info  packaging information used by the current packaging model
    * 
    * @see Packager.Element.CDElement#getDependents
    */
    public java.util.List getDependents(com.tangosol.dev.component.Component cd, _package.component.dev.Storage storage, _package.component.dev.packager.PackageInfo info)
        {
        // import Component.Dev.Packager.Element.CDElement;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.Property;
        // import java.util.List;
        // import java.util.LinkedList;
        
        List list = super.getDependents(cd, storage, info);
        
        // TODO: remove when the complex property "Icon" is implemented
        Object oTIcon = getPropertyValue(cd, "TIcon");
        if (oTIcon != null && oTIcon != Property.NO_VALUE)
            {
            String sIcon = "Component.GUI.Image.Icon." + (String) oTIcon;
            try
                {
                if (storage.loadComponent(sIcon, true, null) != null)
                    {
                    if (list == null)
                        {
                        list = new LinkedList();
                        }
                    CDElement el = new CDElement();
        
                    el.setComponentName(sIcon);
                    el.setPackageInfo(info);
                    el.setStorage(storage);
        
                    list.add(el);
                    }
                }
             catch (ComponentException e) {}
            }
        return list;
        }
    
    // Declared at the super level
    /**
    * Initialize the specified ComponentDefinition (of "this" type) at the
    * specified boundaries with default values.
    * 
    * @see #addChildComponent
    */
    public void initializeComponent(com.tangosol.dev.component.Component cd, _package.component.gUI.Rectangle rectBounds)
        {
        // import com.tangosol.dev.component.Property;
        
        super.initializeComponent(cd, rectBounds);
        
        Object oText = getPropertyValue(cd, "Text");
        if (oText == Property.NO_VALUE || oText == null)
            {
            setPropertyValue(cd, "Text", "Label:");
            }

        }
    
    // Declared at the super level
    /**
    * Updates attributes of the specified component holder based on the state
    * of the designee [Component Definition].  Subclasses should overwrite this
    * method extracting and applying values of relevant properties either to
    * the holder itself or to its renderer.
    */
    protected void updateComponentHolder(_package.component.gUI.control.container.jComponent.jPanel.CDHolder holder)
        {
        // import Component.GUI.Control;
        // import Component.GUI.Control.Container.JComponent.JLabel;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.Property;
        // import javax.swing.SwingConstants as Constants;
        
        super.updateComponentHolder(holder);
        
        Component cd = holder.getComponent();
        
        Control renderer = holder.getRenderer();
        if (renderer instanceof JLabel)
            {
            JLabel label = (JLabel) renderer;
            
            Object oMnemonic = getPropertyValue(cd, "DisplayedMnemonic");
            label.setDisplayedMnemonic(oMnemonic == Property.NO_VALUE ?
                '\0' : ((Character) oMnemonic).charValue());
            
            Object oAlignH = getPropertyValue(cd, "HorizontalAlignment");
            label.setHorizontalAlignment(oAlignH == Property.NO_VALUE ?
                Constants.LEADING : ((Integer) oAlignH).intValue());
        
            Object oAlignV = getPropertyValue(cd, "VerticalAlignment");
            label.setVerticalAlignment(oAlignV == Property.NO_VALUE ?
                Constants.CENTER : ((Integer) oAlignV).intValue());
        
            Object oPosH = getPropertyValue(cd, "HorizontalTextPosition");
            label.setHorizontalTextPosition(oPosH == Property.NO_VALUE ?
                Constants.TRAILING : ((Integer) oPosH).intValue());
        
            Object oPosV = getPropertyValue(cd, "VerticalTextPosition");
            label.setVerticalTextPosition(oPosV == Property.NO_VALUE ?
                Constants.CENTER : ((Integer) oPosV).intValue());
        
            Object oText = getPropertyValue(cd, "Text");
            label.setText(oText == Property.NO_VALUE || oText == null ?
                "" : (String) oText);
        
            // TODO: replace with Icon property when the complex properties are done
            Object oTIcon = getPropertyValue(cd, "TIcon");
            if (oTIcon != Property.NO_VALUE)
                {
                label.setTIcon((String) oTIcon);
                }
        
            label.setOpaque(true);
            }
        }
    }
