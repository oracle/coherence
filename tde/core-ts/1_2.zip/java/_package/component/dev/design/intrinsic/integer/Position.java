/* Class
*     _package.component.dev.design.intrinsic.integer.Position
*/

package _package.component.dev.design.intrinsic.integer;

import javax.swing.SwingConstants; // as Constants

public class Position
        extends    _package.component.dev.design.intrinsic.Integer
    {
    // Fields declarations
    private static final String[] __s_TextChoices;
    
    /**
    * Property TextChoicesExtended
    *
    * The set of all known positions. The TextChoices property must be a subset
    * of this set. All that the subclasses of Integer.Position have to do is to
    * specify the corresponding subset of TextChoicesExtended into TextChoices
    * property.
    */
    private static final String[] __s_TextChoicesExtended;
    
    // Static initializer
    static
        {
        try
            {
            String[] a0 = new String[7];
                {
                a0[0] = "Center";
                a0[1] = "Top";
                a0[2] = "Left";
                a0[3] = "Bottom";
                a0[4] = "Right";
                a0[5] = "Leading";
                a0[6] = "Trailing";
                }
            __s_TextChoices = a0;
            String[] a1 = new String[7];
                {
                a1[0] = "Center";
                a1[1] = "Top";
                a1[2] = "Left";
                a1[3] = "Bottom";
                a1[4] = "Right";
                a1[5] = "Leading";
                a1[6] = "Trailing";
                }
            __s_TextChoicesExtended = a1;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public Position()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Position(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant Choice
    public boolean isChoice()
        {
        return true;
        }
    
    // Getter for virtual constant TextChoices
    public String[] getTextChoices()
        {
        return (String[]) __s_TextChoices.clone();
        }
    
    // Getter for virtual constant TextChoicesExtended
    public String[] getTextChoicesExtended()
        {
        return (String[]) __s_TextChoicesExtended.clone();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Position();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/intrinsic/integer/Position".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        // import javax.swing.SwingConstants as Constants;
        
        Object oValue = super.convertText(sText, dtValue, storage);
        
        if (oValue == VALUE_UNKNOWN)
            {
            String[] asText = getTextChoicesExtended();
        
            if     (sText.equals(asText[0]))
                {
                oValue = new Integer(Constants.CENTER);
                }
            else if (sText.equals(asText[1]))
                {
                oValue = new Integer(Constants.TOP);
                }
            else if (sText.equals(asText[2]))
                {
                oValue = new Integer(Constants.LEFT);
                }
            else if (sText.equals(asText[3]))
                {
                oValue = new Integer(Constants.BOTTOM);
                }
            else if (sText.equals(asText[4]))
                {
                oValue = new Integer(Constants.RIGHT);
                }
            else if (sText.equals(asText[5]))
                {
                oValue = new Integer(Constants.LEADING);
                }
            else if (sText.equals(asText[6]))
                {
                oValue = new Integer(Constants.TRAILING);
                }
            }
        
        return oValue;
        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        // import javax.swing.SwingConstants as Constants;
        
        if (oValue instanceof Integer)
            {
            String[] asText = getTextChoicesExtended();
            
            switch (((Integer) oValue).intValue())
                {
                case Constants.CENTER:
                    return asText[0];
                case Constants.TOP:
                    return asText[1];
                case Constants.LEFT:
                    return asText[2];
                case Constants.BOTTOM:
                    return asText[3];
                case Constants.RIGHT:
                    return asText[4];
                case Constants.LEADING:
                    return asText[5];
                case Constants.TRAILING:
                    return asText[6];
                }
            }
        
        return super.getText(oValue, dtValue);
        }
    }
