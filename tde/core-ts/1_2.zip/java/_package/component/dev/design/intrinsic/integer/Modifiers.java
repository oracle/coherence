/* Class
*     _package.component.dev.design.intrinsic.integer.Modifiers
*/

package _package.component.dev.design.intrinsic.integer;

import java.awt.Event;

public class Modifiers
        extends    _package.component.dev.design.intrinsic.Integer
    {
    // Fields declarations
    
    // Default constructor
    public Modifiers()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Modifiers(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Modifiers();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/intrinsic/integer/Modifiers".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        // import java.awt.Event;
        
        Object oValue = super.convertText(sText, dtValue, storage);
        
        if (oValue == VALUE_UNKNOWN)
            {
            int iModifiers = 0;
        
            if (sText.indexOf("Shift") >= 0)
                {
                iModifiers |= Event.SHIFT_MASK;
                }
            if (sText.indexOf("Ctrl") >= 0)
                {
                iModifiers |= Event.CTRL_MASK;
                }
            if (sText.indexOf("Meta") >= 0)
                {
                iModifiers |= Event.META_MASK;
                }
            if (sText.indexOf("Alt") >= 0)
                {
                iModifiers |= Event.ALT_MASK;
                }
        
            oValue = new Integer(iModifiers);
            }
        
        return oValue;
        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        // import java.awt.Event;
        
        if (oValue instanceof Integer)
            {
            int  iModifiers = ((Integer) oValue).intValue();
            StringBuffer sb = new StringBuffer();
            
            if ((iModifiers & Event.SHIFT_MASK) != 0)
                {
                sb.append(" Shift");
                }
            if ((iModifiers & Event.CTRL_MASK) != 0)
                {
                sb.append(" Ctrl");
                }
            if ((iModifiers & Event.META_MASK) != 0)
                {
                sb.append(" Meta");
                }
            if ((iModifiers & Event.ALT_MASK) != 0)
                {
                sb.append(" Alt");
                }
        
            if (sb.length() > 0)
                {
                return sb.substring(1);
                }
            }
        
        return super.getText(oValue, dtValue);
        }
    
    // Declared at the super level
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        if (super.isTextLegal(sText, dtValue, storage))
            {
            return true;
            }
        
        int iPos = -1;
        
        if ((iPos = sText.indexOf("Shift")) >= 0)
            {
            sText = sText.substring(0, iPos) + sText.substring(iPos + "Shift".length());
            }
        if ((iPos = sText.indexOf("Ctrl")) >= 0)
            {
            sText = sText.substring(0, iPos) + sText.substring(iPos + "Ctrl".length());
            }
        if ((iPos = sText.indexOf("Meta")) >= 0)
            {
            sText = sText.substring(0, iPos) + sText.substring(iPos + "Meta".length());
            }
        if ((iPos = sText.indexOf("Alt")) >= 0)
            {
            sText = sText.substring(0, iPos) + sText.substring(iPos + "Alt".length());
            }
        
        for (int i = 0; i < sText.length(); i++)
            {
            if (sText.charAt(i) != ' ')
                {
                return false;
                }
            }
        return true;
        }
    }
