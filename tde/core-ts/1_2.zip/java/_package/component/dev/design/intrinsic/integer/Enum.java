/* Class
*     _package.component.dev.design.intrinsic.integer.Enum
*/

package _package.component.dev.design.intrinsic.integer;

/**
* Zero-based enumeration of type int.  Only the TextChoices property needs to
* be set.
*/
public class Enum
        extends    _package.component.dev.design.intrinsic.Integer
    {
    // Fields declarations
    
    // Default constructor
    public Enum()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Enum(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant Choice
    public boolean isChoice()
        {
        return true;
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Enum();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/intrinsic/integer/Enum".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * This is the protected implementation of the public method getValue. The
    * only difference is that in a case when there is no conversion available
    * this method returns VALUE_UNKNOWN object (which is not exposed).
    * 
    * @see #getValue
    */
    protected Object convertText(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        Object oValue = super.convertText(sText, dtValue, storage);
        
        if (oValue == VALUE_UNKNOWN)
            {
            String[] asText = getTextChoices();
            for (int i = 0, c = asText.length; i < c; ++i)
                {
                if (sText.equals(asText[i]))
                    {
                    return new Integer(i);
                    }
                }
            }
        
        return oValue;
        }
    
    // Declared at the super level
    /**
    * Converts the specified value [of the specified data type] to a String
    * (usually to be displayed by the Property Sheet). This convertion  and
    * "getValue" conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * as well as
    *     isTextLegal(getText(o));
    * 
    * @param oValue value to convert to a displayable string
    * @param dtValue  data type of the value
    * 
    * @return the diplayable string representation of the specified value or
    * null if there is no conversion for this value.
    * 
    * @see #getValue
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getDisplayValue
    */
    public String getText(Object oValue, com.tangosol.dev.component.DataType dtValue)
        {
        if (oValue instanceof Integer)
            {
            String[] asText = getTextChoices();
            int      i      = ((Integer) oValue).intValue();
            if (i >= 0 && i < asText.length)
                {
                return asText[i];
                }
            }
        
        return super.getText(oValue, dtValue);
        }
    
    // Declared at the super level
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        if (!super.isTextLegal(sText, dtValue, storage))
            {
            return false;
            }
        
        Object o = convertText(sText, dtValue, storage);
        if (o instanceof Integer)
            {
            int n = ((Integer) o).intValue();
            return n >= 0 && n < getTextChoices().length;
            }
        
        return true;

        }
    }
