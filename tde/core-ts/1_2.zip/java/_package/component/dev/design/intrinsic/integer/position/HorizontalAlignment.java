/* Class
*     _package.component.dev.design.intrinsic.integer.position.HorizontalAlignment
*/

package _package.component.dev.design.intrinsic.integer.position;

public class HorizontalAlignment
        extends    _package.component.dev.design.intrinsic.integer.Position
    {
    // Fields declarations
    private static final String[] __s_TextChoices;
    
    // Static initializer
    static
        {
        try
            {
            String[] a0 = new String[5];
                {
                a0[0] = "Center";
                a0[1] = "Left";
                a0[2] = "Right";
                a0[3] = "Leading";
                a0[4] = "Trailing";
                }
            __s_TextChoices = a0;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public HorizontalAlignment()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public HorizontalAlignment(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant TextChoices
    public String[] getTextChoices()
        {
        return (String[]) __s_TextChoices.clone();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new HorizontalAlignment();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/intrinsic/integer/position/HorizontalAlignment".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    }
