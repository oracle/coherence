/* Class
*     _package.component.dev.design.class.Ljava_lang_Float
*/

package _package.component.dev.design.class;

import com.tangosol.dev.assembler.ClassConstant;
import com.tangosol.dev.assembler.CodeAttribute;
import com.tangosol.dev.assembler.Constant;
import com.tangosol.dev.assembler.Dup;
import com.tangosol.dev.assembler.Fconst;
import com.tangosol.dev.assembler.FloatConstant;
import com.tangosol.dev.assembler.Invokespecial;
import com.tangosol.dev.assembler.MethodConstant;
import com.tangosol.dev.assembler.New;
import com.tangosol.dev.component.DataType;

public class Ljava_lang_Float
        extends    _package.component.dev.design.Class
    {
    // Fields declarations
    
    // Default constructor
    public Ljava_lang_Float()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Ljava_lang_Float(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Ljava_lang_Float();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/class/Ljava_lang_Float".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Generates Java class byte codes for a constant value initialization
    * 
    * @param gen ClassGenerator producing a Java class
    * @param oValue value to generate an initializer for
    * @param dtType data type of the specified value
    * 
    * @throws IllegalArgumentException if the code generation is not possible
    * due to an unknown value [data type]
    * 
    * @see #getValue
    * @see Component.Dev.Compiler.ClassGenerator#addConstantInitializer
    * @see Component.Dev.Compiler.ClassGenerator#addPropertyInitializer
    */
    protected void addConstantInitializer(_package.component.dev.compiler.ClassGenerator gen, Object oValue, com.tangosol.dev.component.DataType dtType)
        {
        // import com.tangosol.dev.assembler.CodeAttribute;
        // import com.tangosol.dev.assembler.Constant;
        // import com.tangosol.dev.assembler.FloatConstant;
        // import com.tangosol.dev.assembler.Fconst;
        // import com.tangosol.dev.assembler.ClassConstant;
        // import com.tangosol.dev.assembler.MethodConstant;
        // import com.tangosol.dev.assembler.New;
        // import com.tangosol.dev.assembler.Dup;
        // import com.tangosol.dev.assembler.Invokespecial;
        // import com.tangosol.dev.component.DataType;
        
        if (oValue == null)
            {
            super.addConstantInitializer(gen, oValue, dtType);
            return;
            }
        
        _assert(oValue instanceof Float);
        
        final String  PROP_CLASS = "java.lang.Float";
        float         fValue     = ((Float) oValue).floatValue();
        FloatConstant constValue = new FloatConstant(fValue);
        CodeAttribute code       = gen.getCode();
        
        code.add(new New(new ClassConstant(PROP_CLASS)));
        code.add(new Dup());
        code.add(new Fconst(constValue));
        MethodConstant cM_new = new MethodConstant(PROP_CLASS,
            gen.CONSTRUCTOR_NAME, "(F)V");
        code.add(new Invokespecial(cM_new));
        
        gen.print("new " + PROP_CLASS + '(' +
            gen.formatConstant(constValue, DataType.FLOAT) + ')');
        }
    
    // Declared at the super level
    public _package.component.dev.Design getDesignBase()
        {
        return getDesignInfo("Intrinsic.Float");
        }
    }
