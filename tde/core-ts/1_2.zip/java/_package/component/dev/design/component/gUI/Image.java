/* Class
*     _package.component.dev.design.component.gUI.Image
*/

package _package.component.dev.design.component.gUI;

import _package.component.dev.packager.entry.TransientEntry;
import com.tangosol.dev.component.Property;
import java.util.LinkedList;
import java.util.List;

public class Image
        extends    _package.component.dev.design.component.GUI
    {
    // Fields declarations
    
    // Default constructor
    public Image()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Image(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setRemotable(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Image();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/component/gUI/Image".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Return the PackagerEntries for the specified Component Definition (of
    * "this" Component Definition type) that cannot be "calculated" based on
    * the dependency information/class traversal. Subclasses usually override
    * this method returning lists of TransientEntry or ResourceEntry objects.
    * 
    * @param cd  component for which the PackagerEntries should be calculated
    * @param storage  storage to be used to load any necessary components
    * @param info  packaging information used by the current packaging model
    * 
    * @see Packager.Element.CDElement#getPackagerEntries
    */
    public java.util.List getPackagerEntries(com.tangosol.dev.component.Component cd, _package.component.dev.Storage storage, _package.component.dev.packager.PackageInfo info)
        {
        // import Component.Dev.Packager.Entry.TransientEntry;
        // import com.tangosol.dev.component.Property;
        // import java.util.List;
        // import java.util.LinkedList;
        
        List list = super.getPackagerEntries(cd, storage, info);
        
        Object oPath = getPropertyValue(cd, "ImagePath");
        if (oPath != null && oPath != Property.NO_VALUE)
            {
            String         sPath = (String) oPath;
            TransientEntry entry = info.getModel().makeResourceEntry(sPath);
        
            if (entry != null)
                {
                if (list == null)
                    {
                    list = new LinkedList();
                    }
                list.add(entry);
                }
            }
        return list;
        }
    }
