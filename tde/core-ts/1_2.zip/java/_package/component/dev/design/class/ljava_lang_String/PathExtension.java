/* Class
*     _package.component.dev.design.class.ljava_lang_String.PathExtension
*/

package _package.component.dev.design.class.ljava_lang_String;

public class PathExtension
        extends    _package.component.dev.design.class.Ljava_lang_String
    {
    // Fields declarations
    
    // Default constructor
    public PathExtension()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PathExtension(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new PathExtension();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/dev/design/class/ljava_lang_String/PathExtension".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Converts a string (which is usually the string representing a property
    * value typed in by the user in the Property Sheet) into a value stored by
    * the component definition. This value will be converted back to
    * displayable string by the method "getText()" and used to generate a Java
    * class by "addPropertyInitializer()". This convertion  and "getText"
    * conversion are inverse; generally speaking, it holds that:
    *     o.equals(getValue(getText(o)))
    * and
    *     s.equals(getText(getValue(s)))
    * 
    * Note: Component Definition has a specific knowledge of the data type of
    * the returned value (i.e. complex property), it is only capable of storing
    * values of data types that are serializable (implement
    * java.io.Serializable interface).
    * 
    * @param sText string to convert
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return the "serializable" value of the specified value
    * 
    * @throws IllegalArgumentException if the conversion is not possible
    * 
    * @see #getText
    * @see #addPropertyInitializer
    * @see Component.Dev.Tool.Host.CDTool.PropertyTool#getPropertyValue
    */
    public Object getValue(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        Object oValue = super.getValue(sText, dtValue, storage);
        if (oValue instanceof String)
            {
            String sValue = (String) oValue;
            if (sValue.length() > 0 && sValue.charAt(0) != '.')
                {
                oValue = '.' + sValue;
                }
            }
        return oValue;
        }
    
    // Declared at the super level
    /**
    * Tests whether or not  the specified text could be converted to a value by
    * getValue() method.
    * 
    * @param sText a string value to test
    * @param dtValue  data type of the resulting value
    * @param store  storage that should be used to validate the string
    * 
    * @return true if the conversion is possible; false otherwise
    * 
    * @see #getValue
    */
    public boolean isTextLegal(String sText, com.tangosol.dev.component.DataType dtValue, _package.component.dev.Storage storage)
        {
        if (!super.isTextLegal(sText, dtValue, storage))
            {
            return false;
            }
        
        Object oValue = convertText(sText, dtValue, storage);
        if (oValue == VALUE_UNKNOWN)
            {
            return false;
            }
        
        if (!(oValue instanceof String))
            {
            return true;
            }
        
        char[] ach = ((String) oValue).toCharArray();
        int    cch = ach.length;
        if (cch == 0)
            {
            return false;
            }
        
        int ofStart = 0;
        if (ach[0] == '.')
            {
            ofStart = 1;
            }
        if (cch <= ofStart)
            {
            return false;
            }
        
        for (int of = ofStart; of < cch; ++of)
            {
            // only allow 8-bit letters/digits for a path extension
            char ch = ach[of];
            if (!(ch <= 0xFF && Character.isLetterOrDigit(ch)))
                {
                return false;
                }
            }
        
        return true;
        }
    }
