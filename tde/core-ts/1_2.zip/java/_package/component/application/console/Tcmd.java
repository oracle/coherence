/* Class
*     _package.component.application.console.Tcmd
*/

package _package.component.application.console;

import _package.component.application.console.Tcmd;
import _package.component.dev.Storage;
import _package.component.dev.compiler.ClassGenerator$ClassInfo; // as ClassInfo
import _package.component.dev.compiler.ClassGenerator;
import _package.component.dev.packager.Model;
import _package.component.dev.packager.PackageInfo;
import _package.component.dev.storage.ChainStorage;
import _package.component.dev.storage.DeltaStorage;
import _package.component.dev.storage.OSStorage;
import _package.component.dev.storage.TAPSStorage;
import _package.component.dev.tool.Compiler;
import _package.component.dev.tool.outputTool.Tracer;
import _package.component.dev.util.DocInfo;
import com.tangosol.dev.assembler.ClassFile;
import com.tangosol.dev.component.Component;
import com.tangosol.dev.component.ComponentException;
import com.tangosol.dev.component.Integration;
import com.tangosol.util.ErrorList;
import com.tangosol.util.StringTable;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
* Tangosol command line tool
*/
public class Tcmd
        extends    _package.component.application.Console
    {
    // Fields declarations
    
    /**
    * Property Dependents
    *
    */
    private transient boolean __m_Dependents;
    
    /**
    * Property DestinationStorage
    *
    */
    private transient _package.component.dev.Storage __m_DestinationStorage;
    
    /**
    * Property ExposeName
    *
    */
    private String __m_ExposeName;
    
    /**
    * Property ExposePackage
    *
    */
    private transient String __m_ExposePackage;
    
    /**
    * Property ExposeType
    *
    */
    private transient int __m_ExposeType;
    
    /**
    * Property FILTER_ALL
    *
    * Filter type that processes all components
    */
    private static final int FILTER_ALL = 0;
    
    /**
    * Property FILTER_INTEGRATED
    *
    * Filter type that processes only integrated components
    */
    private static final int FILTER_INTEGRATED = 1;
    
    /**
    * Property FILTER_MODIFIED
    *
    * Filter type that processes only integrated components
    */
    private static final int FILTER_MODIFIED = 2;
    
    /**
    * Property FilterType
    *
    * Specifies the type of the components to be processed
    */
    private int __m_FilterType;
    
    /**
    * Property Operation
    *
    */
    private transient int __m_Operation;
    
    /**
    * Property OPERATION_COMPILE
    *
    */
    public static final int OPERATION_COMPILE = 1;
    
    /**
    * Property OPERATION_DUMP
    *
    */
    public static final int OPERATION_DUMP = 3;
    
    /**
    * Property OPERATION_EXPOSE
    *
    */
    public static final int OPERATION_EXPOSE = 2;
    
    /**
    * Property OPERATION_LOAD
    *
    */
    public static final int OPERATION_LOAD = 6;
    
    /**
    * Property OPERATION_NONE
    *
    */
    public static final int OPERATION_NONE = 0;
    
    /**
    * Property OPERATION_PACKAGE
    *
    */
    public static final int OPERATION_PACKAGE = 7;
    
    /**
    * Property OPERATION_RAWDUMP
    *
    */
    public static final int OPERATION_RAWDUMP = 4;
    
    /**
    * Property OPERATION_REMOVE
    *
    */
    public static final int OPERATION_REMOVE = 9;
    
    /**
    * Property OPERATION_REWRITE
    *
    */
    public static final int OPERATION_REWRITE = 5;
    
    /**
    * Property OPERATION_ROLLUP
    *
    */
    public static final int OPERATION_ROLLUP = 8;
    
    /**
    * Property RawStorage
    *
    */
    private transient _package.component.dev.Storage __m_RawStorage;
    
    /**
    * Property Signatures
    *
    */
    private transient boolean __m_Signatures;
    
    /**
    * Property SourceStorage
    *
    */
    private transient _package.component.dev.Storage __m_SourceStorage;
    
    /**
    * Property Storage
    *
    */
    private transient _package.component.dev.Storage __m_Storage;
    
    /**
    * Property Store
    *
    */
    private boolean __m_Store;
    
    /**
    * Property TraceLevel
    *
    */
    private transient int __m_TraceLevel;
    
    /**
    * Property Verbose
    *
    */
    private boolean __m_Verbose;
    
    // Default constructor
    public Tcmd()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Tcmd(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // singleton initialization
        if (__singleton != null)
            {
            throw new IllegalStateException("A singleton for \"Tcmd\" has already been set");
            }
        __singleton = this;
        
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setDependents(false);
            setOperation(0);
            setSignatures(false);
            setStore(true);
            setTraceLevel(0);
            setVerbose(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Instantiate an Application component or return the previously
    * instantiated singleton.
    * 
    * The implementation of the get_Instance accessor on the Application
    * component is more complex than that of most other singleton components. 
    * First, it must be able to determine what application to instantiate. 
    * Secondly, it works with the _Reference property of the root component to
    * maintain a reference to the resulting application component until the
    * very last component instance is garbage-collected.
    * 
    * 1)  The _Reference property is static and located on the root component.
    * 2)  The accessor and mutator for the _Reference property are protected
    * and thus the property value can be obtained or modified by any component.
    *  (Specifically, it is set initially by Component.<init>, obtained by
    * Application.get_Instance, and set by Application.onInit.)
    * 3)  Component.<init> (the constructor of the root component) sets the
    * _Reference property to the instance of the component being constructed if
    * and only if the _Reference property is null; this guarantees that a
    * reference to the very first component to be instantiated is initially
    * stored in the _Reference property.
    * 4)  When an application component is instantiated, the Application.onInit
    * method stores a reference to that application in the _Reference property;
    * this ensures that a reference to the application will exist as long as
    * any component instance exists (because the root component class will not
    * be garbage-collectable until all component instances are determined to be
    * garbage-collectable and until all of its sub-classes are determined to be
    * garbage-collectable).  Since Application is a singleton, it is not
    * possible for a second instance of Application to exist, so once an
    * Application component has been instantiated, the _Reference property's
    * value will refer to that application until the root component class is
    * garbage-collected.
    * 5)  When Application.get_Instance() is invoked, if no singleton
    * application (Application.__singleton) has been created, then
    * Application.get_Instance is responsible for instantiating an application,
    * which will result in _Reference being set to the application instance (by
    * way of Application.onInit).
    * 
    * The implementation of Application.get_Instance is expected to take the
    * the following steps in order to instantiate the correct application
    * component:
    * 1) If the value of the _Reference property is non-null, it cannot be an
    * instance of Component.Application, because the __init method of an
    * Application component would have set the Application.__singleton field to
    * reference itself.  Application thus assumes that a non-null _Reference
    * value refers to the first component to be instantiated, and invokes the
    * _makeApplication instance method of that component.  If the return value
    * from _makeApplication is non-null, then it is returned by
    * Application.get_Instance.
    * 2)  Application.get_Instance is now in a catch-22.  No instance of
    * Component.Application exists, which means that the entry point (the
    * initially instantiated) component was not an application component, and
    * the component that was the entry point has denied knowledge of what
    * application should be instantiated.  At this point, the
    * Application.get_Instance method must determine the name of the
    * application component to instantiate without any help.  So it drops back
    * and punts.  First, it checks for an environment setting, then it checks
    * for a properties file setting, and if either one exists, then it
    * instantiates the component specified by that setting and returns it.
    * 3)  Finally, without so much as a clue telling Application.get_Instance
    * what to instantiate, it instantiates the default application context.
    * 
    * Note that in any of the above scenarios, by the time the value is
    * returned by Application.get_Instance, the value of the _Reference
    * property would have been set to the application instance by
    * Application.onInit, thus fulfilling the goal of holding a reference to
    * the application.
    * 
    * Any other case in which a reference must be maintained should be done by
    * having the application hold that reference.  In other words, as long as
    * the application doesn't go away, any reference that it holds won't go
    * away either.
    * 
    * @see Component#_Reference
    */
    public static _package.Component get_Instance()
        {
        _package.Component singleton = __singleton;
        
        if (singleton == null)
            {
            singleton = new Tcmd();
            }
        else if (!(singleton instanceof Tcmd))
            {
            throw new IllegalStateException("A singleton for \"Tcmd\" has already been set to a different type");
            }
        return singleton;
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/application/console/Tcmd".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    private void configureStorage()
        {
        // import Component.Dev.Storage.TAPSStorage;
        // import Component.Dev.Storage.DeltaStorage;
        // import Component.Dev.Storage.ChainStorage;
        // import Component.Dev.Storage;
        
        TAPSStorage tapsStorage = new TAPSStorage();
        tapsStorage.initFromEnvironment();
        if (!tapsStorage.isValid())
            {
            throw new IllegalArgumentException("Failed to configure storage " + tapsStorage);
            }
        setStorage(tapsStorage);
        
        Storage storage = tapsStorage;
        while (true)
            {
            if (storage instanceof DeltaStorage)
                {
                storage = ((DeltaStorage) storage).getActualStorage();
                setSourceStorage(storage);
                continue;
                }
            if (storage instanceof ChainStorage)
                {
                storage = ((ChainStorage) storage).getDelta();
                continue;
                }
            break;
            }
        
        setRawStorage(storage);
        }
    
    // Accessor for the property "DestinationStorage"
    /**
    * Getter for property DestinationStorage.<p>
    */
    public _package.component.dev.Storage getDestinationStorage()
        {
        return __m_DestinationStorage;
        }
    
    // Accessor for the property "ExposeName"
    /**
    * Getter for property ExposeName.<p>
    */
    public String getExposeName()
        {
        return __m_ExposeName;
        }
    
    // Accessor for the property "ExposePackage"
    /**
    * Getter for property ExposePackage.<p>
    */
    public String getExposePackage()
        {
        return __m_ExposePackage;
        }
    
    // Accessor for the property "ExposeType"
    /**
    * Getter for property ExposeType.<p>
    */
    public int getExposeType()
        {
        return __m_ExposeType;
        }
    
    // Accessor for the property "FilterType"
    /**
    * Getter for property FilterType.<p>
    * Specifies the type of the components to be processed
    */
    public int getFilterType()
        {
        return __m_FilterType;
        }
    
    // Accessor for the property "Operation"
    /**
    * Getter for property Operation.<p>
    */
    public int getOperation()
        {
        return __m_Operation;
        }
    
    // Accessor for the property "RawStorage"
    /**
    * Getter for property RawStorage.<p>
    */
    public _package.component.dev.Storage getRawStorage()
        {
        return __m_RawStorage;
        }
    
    // Accessor for the property "SourceStorage"
    /**
    * Getter for property SourceStorage.<p>
    */
    public _package.component.dev.Storage getSourceStorage()
        {
        return __m_SourceStorage;
        }
    
    // Accessor for the property "Storage"
    /**
    * Getter for property Storage.<p>
    */
    public _package.component.dev.Storage getStorage()
        {
        return __m_Storage;
        }
    
    // Accessor for the property "TraceLevel"
    /**
    * Getter for property TraceLevel.<p>
    */
    public int getTraceLevel()
        {
        return __m_TraceLevel;
        }
    
    // Accessor for the property "Dependents"
    /**
    * Getter for property Dependents.<p>
    */
    public boolean isDependents()
        {
        return __m_Dependents;
        }
    
    // Accessor for the property "Signatures"
    /**
    * Getter for property Signatures.<p>
    */
    public boolean isSignatures()
        {
        return __m_Signatures;
        }
    
    // Accessor for the property "Store"
    /**
    * Getter for property Store.<p>
    */
    public boolean isStore()
        {
        return __m_Store;
        }
    
    // Accessor for the property "Verbose"
    /**
    * Getter for property Verbose.<p>
    */
    public boolean isVerbose()
        {
        return __m_Verbose;
        }
    
    // Declared at the super level
    /**
    * This method is the entry point for executable Java applications.
    * 
    * Certain types of Java applications are started by the JVM invoking the
    * main() method of the entry point class.  The Application component
    * assists in building these types of applications by providing a default
    * implementation for the main() method.  Unfortunately, main() is not
    * virtual (it must be static) so an application must either override main()
    * or provide configuration information so that the default main()
    * implementation can determine the identity of the entry point class.  For
    * example, the following is a script that an application
    * (Component.Application.Console.HelloWorld) could use to ensure that the
    * HelloWorld application is instantiated:
    * 
    *     // instantiate HelloWorld
    *     get_Instance();
    *     // use the default main() implementation provided by
    * Component.Application
    *     super.main(asArgs);
    * 
    * To avoid creating the script on HelloWorld.main(), and if the application
    * were jar'd, the META-INF directory in the .jar file would contain the
    * following:
    * 
    *     # -- contents of META-INF/MANIFEST.MF
    *     Main-Class:_package.Component.Application.Console.HelloWorld
    * 
    *     # -- contents of META-INF/application.properties --
    *     app=Console.HelloWorld
    * 
    * The application identity could alternatively be provided on the command
    * line, for example if the application has not been jar'd:
    * 
    *     java _package.Component.Application.Console.HelloWorld
    * -app=Console.HelloWorld
    * 
    * The default implementation (Application.main) stores the arguments for
    * later use in the indexed Argument property, instantiates the application
    * (if an instance does not already exist), and invokes the run() method of
    * the application instance.  It is expected that application implementors
    * will provide an implementation for run() and not for main().
    * 
    * Note that "_package." is a place-holder for a deployer-specified package
    * name, for example "com.mycompany.myapplication".  The Packaging Wizard
    * allows the deployer to specify the package into which the application
    * will be deployed.  The above examples would have to be changed
    * accordingly.
    * 
    * @param asArgs  an array of string arguments
    * 
    * @see #get_Instance
    */
    public static void main(String[] asArgs)
        {
        // import Component.Application.Console.Tcmd;
        
        Tcmd commander = (Tcmd) get_Instance();
        commander.setArgument(asArgs);
        commander.run();

        }
    
    private _package.component.dev.Storage parseStorage(String argument)
        {
        // import Component.Dev.Storage.TAPSStorage;
        // import Component.Dev.Storage.DeltaStorage;
        // import Component.Dev.Storage.ChainStorage;
        // import Component.Dev.Storage.OSStorage;
        // import Component.Dev.Storage;
        // import java.io.File;
        
        String sStorage = parseValue(argument);
        if (sStorage == null)
            {
            _trace("Storage name expected after \"" + argument + "\"");
            return null;
            }
        
        Storage storage = (Storage) ((TAPSStorage) getStorage()).get_Storage();
        for (;;)
            {
            if (storage instanceof DeltaStorage)
                {
                storage = ((DeltaStorage) storage).getActualStorage();
                continue;
                }
            if (storage instanceof ChainStorage)
                {
                Storage base = ((ChainStorage) storage).getBase();
                if (base instanceof OSStorage)
                    {
                    String sName = ((OSStorage) base).getRootDir().getName();
                    if (sName.equals(sStorage))
                        {
                        return storage;
                        }            
                    }
                storage = ((ChainStorage) storage).getDelta();
                continue;
                }
            break;
            }
        
        if (storage instanceof OSStorage)
            {
            String sName = ((OSStorage) storage).getRootDir().getName();
            if (sName.equals(sStorage))
                {
                return storage;
                }
            }
        
        _trace("Unable to locate storage \"" + argument + "\"");
        return null;

        }
    
    private String parseValue(String argument)
        {
        int of = argument.indexOf('=');
        if (of == -1)
            {
            of  = argument.indexOf(':');
            if (of == -1)
                {
                return null;
                }
            }
        return argument.substring(of + 1);

        }
    
    public void process(String sComponent)
        {
        // import Component.Dev.Util.DocInfo;
        // import Component.Dev.Storage.TAPSStorage;
        // import com.tangosol.util.StringTable;
        
        try
            {
            processSub(sComponent);
            }
        catch (Throwable t)
            {
            t.printStackTrace();
            }
        
        if (!isDependents() || getOperation() == OPERATION_COMPILE)
            {
            return;
            }
        
        String sName = sComponent;
        if (sName.equals("Root"))
            {
            sName = null;
            }
        
        TAPSStorage storage = (TAPSStorage) getStorage();
        if (isSignatures())
            {
            String[] asSub = storage.getPackageSignatures(sName, true).strings();
            if (asSub != null)
                {
                for (int i = 0; i < asSub.length; i++)
                    {
                    processSub(asSub[i]);
                    }
                }
            asSub = storage.getSignaturePackages(sName, true, false).strings();
            if (asSub != null)
                {
                for (int i = 0; i < asSub.length; i++)
                    {
                    process(asSub[i]);
                    }
                }
            }
        else
            {
            StringTable tblSub = storage.getSubComponents(sName, true);
            StringTable tblPkg = null;
            if (tblSub.isEmpty())
                {
                return;
                }
        
            boolean fModOnly = (getFilterType() & FILTER_MODIFIED) != 0;
            if (fModOnly)
                {
                tblPkg = storage.getComponentPackages(sName, true, false);
                }
        
            String[] asSub = tblSub.strings();
            for (int i = 0, cSubs = asSub.length; i < cSubs; i++)
                {
                String  sSub     = asSub[i];
                boolean fRecurse = true;
        
                if (fModOnly)
                    {
                    DocInfo info = DocInfo.instantiate(sSub, "Component");
                    info.setStorageLocator(tblSub.get(sSub));
                    info.setSubLocator(tblPkg.get(sSub));
        
                    fRecurse = info.isSubModifiedAtSubproject(storage.getTarget());
                    }
        
                if (fRecurse)
                    {
                    process(asSub[i]);
                    }
                }
            }

        }
    
    public void processSub(String sComponent)
        {
        // import Component.Dev.Compiler.ClassGenerator;
        // import Component.Dev.Compiler.ClassGenerator$ClassInfo as ClassInfo;
        // import Component.Dev.Packager.PackageInfo;
        // import Component.Dev.Packager.Model;
        // import Component.Dev.Storage;
        // import Component.Dev.Tool.Compiler;
        // import Component.Dev.Tool.OutputTool.Tracer;
        // import com.tangosol.dev.component.Component;
        // import com.tangosol.dev.component.ComponentException;
        // import com.tangosol.dev.component.Integration;
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.util.ErrorList;
        // import java.io.File;
        // import java.io.FileOutputStream;
        // import java.io.DataOutputStream;
        // import java.io.PrintWriter;
        // import java.util.Enumeration;
        // import java.util.Iterator;
        // import java.util.Date;
        // import java.util.List;
        // import java.util.Map;
        
        Storage storage = getStorage();
        int nOperation = getOperation();
        
        switch (nOperation)
            {
            case OPERATION_NONE:
                {
                _trace("Operation has not been specified for " + sComponent + "!!!");
                _beep();
                }
            break;
            case OPERATION_COMPILE:
                {
                _trace("Compiling " + sComponent + "...");
                }
            break;
            case OPERATION_EXPOSE:
                {
                _trace("Exposing " + sComponent + "...");
                }
            break;
            case OPERATION_DUMP:
                {
                _trace("Dumping " + sComponent + "...");
                }
            break;
            case OPERATION_RAWDUMP:
                {
                _trace("Raw Dumping " + sComponent + "...");
                storage = getRawStorage();
                }
            break;
            case OPERATION_REWRITE:
                {
                _trace("Rewriting " + sComponent + "...");
                }
            break;
            case OPERATION_LOAD:
                {
                _trace("Loading " + sComponent + "...");
                }
            break;
            case OPERATION_PACKAGE:
                {
                if (!sComponent.startsWith("Component.Application."))
                    {
                    sComponent = "Component.Application." + sComponent;
                    }
                _trace("Packaging " + sComponent + "...");
                }
            break;
            case OPERATION_ROLLUP:
                {
                _trace("Rolling up " + sComponent + "...");
                storage = getSourceStorage();
                }
            break;
            case OPERATION_REMOVE:
                {
                _trace("Removing " + sComponent + "...");
                try
                    {
                    storage.removeComponent(sComponent);
                    }
                catch (ComponentException ce)
                    {
                    _trace(ce);
                    }
                return;
                }
            }
        
        Component cd = null;
        ErrorList errList = new ErrorList();
        try
            {
            String sName = sComponent;
            if (sName.equals("Root"))
                {
                sName = "";
                }
            if (isSignatures())
                {
                cd = storage.loadSignature(sName);
                }
            else
                {
                cd = storage.loadComponent(sName, false, errList);
                }
            }
        catch (ComponentException ce)
            {
            _trace(ce);
            return;
            }
        
        if (cd == null)
            {
            _trace("The component " + sComponent + " does not exist.");
            _beep();
            return;
            }
        
        if (!errList.isEmpty())
            {
            errList.print();
            errList.clear();
            }
        
        if ((getFilterType() & FILTER_INTEGRATED) != 0)
            {
            Integration integration = cd.getIntegration();
            if (integration == null || !integration.isNewIntegration())
                {
                _trace("skipping ...");
                return;
                }
            }
        
        try
            {
            switch (getOperation())
                {
                case OPERATION_COMPILE:
                    {
                    Tracer tracer = new Tracer();
                    tracer.setVerbose(isVerbose());
        
                    Compiler compiler = new Compiler();
        
                    compiler.setStorage(storage);
                    compiler.setOutputTool(tracer);
                    compiler.setComponent(cd);
                    compiler.setDependencies(isDependents());
                    compiler.setStoreResult(isStore());
                    compiler.setModifiedOnly((getFilterType() & FILTER_MODIFIED) != 0);
        
                    // use default for the following...
                    // compiler.setGenerateListing(true);
                    // TODO: compiler.setTraceLevel(getTraceLevel());
                    // TODO: compiler.setDebugInfo(true);
                    // TODO: compiler.setOptimizePrivateAccessors(false);
                    compiler.compile();
                    }
                break;
                case OPERATION_EXPOSE:
                    {
                    ClassGenerator gen = new ClassGenerator();
                    gen.setCD(cd);
                    gen.setErrorList(errList);
                    gen.setStorage(storage);
                    gen.setTraceLevel(getTraceLevel());
                    // use default for the following...
                    // gen.setDebugInfo(true);
                    // gen.setGenerateListing(true);
                    // gen.setOptimizePrivateAccessors(false);
        
                    List list = gen.generateExposedClasses(
                        getExposePackage(), getExposeName(), getExposeType(), isStore());
        
                    if (list == null || list.isEmpty())
                        {
                        _trace("No generated classes!", 1);
                        }
                    else
                        {
                        for (Iterator iter = list.iterator(); iter.hasNext();)
                            {
                            ClassInfo info = (ClassInfo) iter.next();
                            
                            _trace("*** Class " + info.getClassFile().getName() + ":");
                             if (!isStore())
                                {
                                _trace(info.getClassListing());
                                }
                            }
                        }
                    }
                break;
                case OPERATION_DUMP:
                    {
                    cd.dump();
                    }
                break;
                case OPERATION_RAWDUMP:
                    {
                    cd.dump();
                    }
                break;
                case OPERATION_REWRITE:
                    {
                    try
                        {
                        if (isSignatures())
                            {
                            storage.storeSignature(cd);
                            }
                        else
                            {
                            storage.storeComponent(cd, errList);
                            }
                        }
                    catch (ComponentException ce)
                        {
                        _trace(ce);
                        return;
                        }
                    }
                break;
                case OPERATION_PACKAGE:
                    {
                    PackageInfo info = new PackageInfo();
                    info.load(cd);
        
                    Model packager = info.getModel();
                    if (packager == null)
                        {
                        _trace("Packaging failed: Packaging model " + info.getModelName() + " is not supported.");
                        }
                    else
                        {
                        Tracer tracer = new Tracer();
                        tracer.setVerbose(isVerbose());
        
                        packager.setApplicationComponent(cd);
                        packager.setOutputTool(tracer);
                        packager.setStorage(storage);
                        packager.buildPackage();
                        }
                    }
                break;
                case OPERATION_ROLLUP:
                    {
                    Storage destination = getDestinationStorage();
                    if (destination == null)
                        {
                        _trace("Destination storage has not been specified.");
                        break;
                        }
                    String sName = sComponent;
                    if (sName.equals("Root"))
                        {
                        sName = null;
                        }
                    storage.copyAllComponents(sName, destination, errList);
                    }
                break;
                }
            }
        catch (Exception e) // ComponentException
            {
            errList.addException(e);
            if (!(e instanceof ComponentException))
                {
                _trace(e);
                }
            }
        
        cd = null;
        
        if (!errList.isEmpty())
            {
            errList.print();
            errList = null;
            }
        }
    
    private void rollupPackage(String sPackage, _package.component.dev.Storage storeStorage)
        {
        }
    
    // Declared at the super level
    public void run()
        {
        // import Component.Dev.Compiler.ClassGenerator;
        // import Component.Dev.Storage;
        // import Component.Dev.Storage.TAPSStorage;
        // import Component.Dev.Storage.OSStorage;
        // import java.io.File;
        
        configureStorage();
        
        String[] arguments  = getArgument();
        setExposeType(ClassGenerator.EXPOSE_AUTO);
        setTraceLevel(ClassGenerator.TRACE_LEVEL_NONE);
        
        for (int i = 0; i < arguments.length; ++i)
             {
            String argument = arguments[i];
            if (argument.charAt(0) == '-')
                {
                if (argument.startsWith("-depend"))
                    {
                    setDependents(true);
                    }
                else if (argument.startsWith("-compile"))
                    {
                    setOperation(OPERATION_COMPILE);
                    setSignatures(false);
                    }
                else if (argument.startsWith("-expose"))
                    {
                    setOperation(OPERATION_EXPOSE);
                    if (i + 1 < arguments.length)
                        {
                        if (!arguments[i+1].startsWith("-"))
                            {
                            setExposePackage(arguments[++i]);
                            }
                        }
                    if (i + 1 < arguments.length)
                        {
                        if (!arguments[i+1].startsWith("-"))
                            {
                            setExposeName(arguments[++i]);
                            }
                        }
                    setSignatures(false);
                    }
                else if (argument.startsWith("-filter"))
                    {
                    String sFilter = parseValue(argument);
                    if (sFilter == null)
                        {
                        throw new IllegalArgumentException("Filter value is not specified");
                        }
                    if (sFilter.indexOf("integrated") != -1)
                        {
                        setFilterType(getFilterType() | FILTER_INTEGRATED);
                        }
                    if (sFilter.indexOf("modified") != -1)
                        {
                        setFilterType(getFilterType() | FILTER_MODIFIED);
                        }
                    }
                else if (argument.startsWith("-dump"))
                    {
                    setOperation(OPERATION_DUMP);
                    }
                else if (argument.startsWith("-rawstor"))
                    {
                    setRawStorage((Storage) parseStorage(argument));
                    }
                else if (argument.startsWith("-rawdump"))
                    {
                    setOperation(OPERATION_RAWDUMP);
                    }
                else if (argument.startsWith("-rewrite")
                         || argument.startsWith("rollup"))
                    {
                    setOperation(OPERATION_REWRITE);
                    }
                else if (argument.startsWith("-load"))
                    {
                    setOperation(OPERATION_LOAD);
                    }
                else if (argument.startsWith("-package"))
                    {
                    setOperation(OPERATION_PACKAGE);
                    }
                else if (argument.startsWith("-auto"))
                    {
                    setExposeType(ClassGenerator.EXPOSE_AUTO);
                    }
                else if (argument.startsWith("-component"))
                    {
                    setExposeType(ClassGenerator.EXPOSE_COMPONENT);
                    }
                else if (argument.startsWith("-feed"))
                    {
                    setExposeType(ClassGenerator.EXPOSE_FEED);
                    }
                else if (argument.startsWith("-remote"))
                    {
                    setExposeType(ClassGenerator.EXPOSE_REMOTE);
                    }
                else if (argument.startsWith("-store"))
                    {
                    setStore(true);
                    }
                else if (argument.startsWith("-nostore"))
                    {
                    setStore(false);
                    }
                else if (argument.startsWith("-trace"))
                    {
                    setTraceLevel(ClassGenerator.TRACE_LEVEL_LOW);
                    }
                else if (argument.startsWith("-notrace"))
                    {
                    setTraceLevel(ClassGenerator.TRACE_LEVEL_NONE);
                    }
                else if (argument.startsWith("-sig"))
                    {
                    switch (getOperation())
                        {
                        case OPERATION_COMPILE:
                        case OPERATION_EXPOSE:
                            setOperation(OPERATION_LOAD);
                        }
                    setSignatures(true);
                    }
                else if (argument.startsWith("-nosig"))
                    {
                    setSignatures(false);
                    }
                else if (argument.startsWith("-source"))
                    {
                    setSourceStorage(parseStorage(argument));
                    }
                else if (argument.startsWith("-dest"))
                    {
                    String sDestination = parseValue(argument);
                    if (sDestination == null)
                        {
                        _trace("Destination storage name expected after \"" + argument + "\"");
                        break;
                        }
                    String sRepository = ((TAPSStorage) getStorage()).getServerUri();
                    File module = new File(sRepository, sDestination);
                    OSStorage storage = new OSStorage();
                    storage.setRootDir(module);
                    setDestinationStorage(storage);
                    }
                else if (argument.startsWith("-rollup"))
                    {
                    setOperation(OPERATION_ROLLUP);
                    }
                else if (argument.startsWith("-remove"))
                    {
                    setOperation(OPERATION_REMOVE);
                    }
                else if (argument.startsWith("-verbose"))
                    {
                    setVerbose(true);
                    }
                }
            else
                {
                process(argument);
                }
            }
        
        getStorage().close();

        }
    
    // Accessor for the property "Dependents"
    /**
    * Setter for property Dependents.<p>
    */
    public void setDependents(boolean pDependents)
        {
        __m_Dependents = pDependents;
        }
    
    // Accessor for the property "DestinationStorage"
    /**
    * Setter for property DestinationStorage.<p>
    */
    public void setDestinationStorage(_package.component.dev.Storage pDestinationStorage)
        {
        __m_DestinationStorage = pDestinationStorage;
        }
    
    // Accessor for the property "ExposeName"
    /**
    * Setter for property ExposeName.<p>
    */
    public void setExposeName(String pExposeName)
        {
        __m_ExposeName = pExposeName;
        }
    
    // Accessor for the property "ExposePackage"
    /**
    * Setter for property ExposePackage.<p>
    */
    public void setExposePackage(String pExposePackage)
        {
        __m_ExposePackage = pExposePackage;
        }
    
    // Accessor for the property "ExposeType"
    /**
    * Setter for property ExposeType.<p>
    */
    public void setExposeType(int pExposeType)
        {
        __m_ExposeType = pExposeType;
        }
    
    // Accessor for the property "FilterType"
    /**
    * Setter for property FilterType.<p>
    * Specifies the type of the components to be processed
    */
    public void setFilterType(int pFilterType)
        {
        __m_FilterType = pFilterType;
        }
    
    // Accessor for the property "Operation"
    /**
    * Setter for property Operation.<p>
    */
    public void setOperation(int pOperation)
        {
        __m_Operation = pOperation;
        }
    
    // Accessor for the property "RawStorage"
    /**
    * Setter for property RawStorage.<p>
    */
    public void setRawStorage(_package.component.dev.Storage pRawStorage)
        {
        __m_RawStorage = pRawStorage;
        }
    
    // Accessor for the property "Signatures"
    /**
    * Setter for property Signatures.<p>
    */
    public void setSignatures(boolean pSignatures)
        {
        __m_Signatures = pSignatures;
        }
    
    // Accessor for the property "SourceStorage"
    /**
    * Setter for property SourceStorage.<p>
    */
    public void setSourceStorage(_package.component.dev.Storage pSourceStorage)
        {
        __m_SourceStorage = pSourceStorage;
        }
    
    // Accessor for the property "Storage"
    /**
    * Setter for property Storage.<p>
    */
    public void setStorage(_package.component.dev.Storage pStorage)
        {
        __m_Storage = pStorage;
        }
    
    // Accessor for the property "Store"
    /**
    * Setter for property Store.<p>
    */
    public void setStore(boolean pStore)
        {
        __m_Store = pStore;
        }
    
    // Accessor for the property "TraceLevel"
    /**
    * Setter for property TraceLevel.<p>
    */
    public void setTraceLevel(int pTraceLevel)
        {
        __m_TraceLevel = pTraceLevel;
        }
    
    // Accessor for the property "Verbose"
    /**
    * Setter for property Verbose.<p>
    */
    public void setVerbose(boolean pVerbose)
        {
        __m_Verbose = pVerbose;
        }
    }
