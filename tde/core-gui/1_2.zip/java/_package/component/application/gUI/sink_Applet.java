/* Class
*      sink_Applet
*
* automatically generated "Sink" which
* represents a footprint of the class
*      java.applet.Applet
* when used as a component callback by 
*      Component.Application.GUI.Applet
*/

package _package.component.application.gUI;

public class sink_Applet
       extends com.tangosol.run.component.CallbackSink
    {
    private jb_Applet __peer;
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_Applet()
        {
        }
    
    // this (protected) constructor is used by the feed
    protected sink_Applet(jb_Applet feed)
        {
        super();
        __peer = feed;
        }
    
    // Retrieves the feed object for this sink
    public Object get_Feed()
        {
        return __peer;
        }
    
    // methods integrated and/or remoted
    public void add(java.awt.Component Param_1, Object Param_2, int Param_3)
        {
        __peer.super$add(Param_1, Param_2, Param_3);
        }
    public void remove(java.awt.Component comp)
        {
        __peer.super$remove(comp);
        }
    public void addFocusListener(java.awt.event.FocusListener l)
        {
        __peer.super$addFocusListener(l);
        }
    public void addKeyListener(java.awt.event.KeyListener Param_1)
        {
        __peer.super$addKeyListener(Param_1);
        }
    public void addMouseListener(java.awt.event.MouseListener Param_1)
        {
        __peer.super$addMouseListener(Param_1);
        }
    public void addMouseMotionListener(java.awt.event.MouseMotionListener Param_1)
        {
        __peer.super$addMouseMotionListener(Param_1);
        }
    public void addNotify()
        {
        __peer.super$addNotify();
        }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener listener)
        {
        __peer.super$addPropertyChangeListener(listener);
        }
    public void destroy()
        {
        __peer.super$destroy();
        }
    public void doLayout()
        {
        __peer.super$doLayout();
        }
    public java.awt.Color getBackground()
        {
        return __peer.super$getBackground();
        }
    public java.awt.Rectangle getBounds()
        {
        return __peer.super$getBounds();
        }
    public java.awt.Cursor getCursor()
        {
        return __peer.super$getCursor();
        }
    public java.awt.Font getFont()
        {
        return __peer.super$getFont();
        }
    public java.awt.Color getForeground()
        {
        return __peer.super$getForeground();
        }
    public java.awt.Insets getInsets()
        {
        return __peer.super$getInsets();
        }
    public java.awt.LayoutManager getLayout()
        {
        return __peer.super$getLayout();
        }
    public java.awt.Point getLocation()
        {
        return __peer.super$getLocation();
        }
    public java.awt.Point getLocationOnScreen()
        {
        return __peer.super$getLocationOnScreen();
        }
    public java.awt.Dimension getSize()
        {
        return __peer.super$getSize();
        }
    public java.applet.AppletContext getAppletContext()
        {
        return __peer.super$getAppletContext();
        }
    public String getAppletInfo()
        {
        return __peer.super$getAppletInfo();
        }
    public java.applet.AudioClip getAudioClip(java.net.URL url)
        {
        return __peer.super$getAudioClip(url);
        }
    public java.applet.AudioClip getAudioClip(java.net.URL url, String name)
        {
        return __peer.super$getAudioClip(url, name);
        }
    public java.net.URL getCodeBase()
        {
        return __peer.super$getCodeBase();
        }
    public java.net.URL getDocumentBase()
        {
        return __peer.super$getDocumentBase();
        }
    public java.awt.Image getImage(java.net.URL url)
        {
        return __peer.super$getImage(url);
        }
    public java.awt.Image getImage(java.net.URL url, String name)
        {
        return __peer.super$getImage(url, name);
        }
    public String getParameter(String Param_1)
        {
        return __peer.super$getParameter(Param_1);
        }
    public String[][] getParameterInfo()
        {
        return __peer.super$getParameterInfo();
        }
    public void init()
        {
        __peer.super$init();
        }
    public boolean isActive()
        {
        return __peer.super$isActive();
        }
    public boolean isEnabled()
        {
        return __peer.super$isEnabled();
        }
    public boolean isFocusTraversable()
        {
        return __peer.super$isFocusTraversable();
        }
    public boolean isShowing()
        {
        return __peer.super$isShowing();
        }
    public boolean isVisible()
        {
        return __peer.super$isVisible();
        }
    public void paint(java.awt.Graphics g)
        {
        __peer.super$paint(g);
        }
    public void play(java.net.URL url)
        {
        __peer.super$play(url);
        }
    public void play(java.net.URL url, String name)
        {
        __peer.super$play(url, name);
        }
    public void removeFocusListener(java.awt.event.FocusListener l)
        {
        __peer.super$removeFocusListener(l);
        }
    public void removeKeyListener(java.awt.event.KeyListener Param_1)
        {
        __peer.super$removeKeyListener(Param_1);
        }
    public void removeMouseListener(java.awt.event.MouseListener Param_1)
        {
        __peer.super$removeMouseListener(Param_1);
        }
    public void removeMouseMotionListener(java.awt.event.MouseMotionListener Param_1)
        {
        __peer.super$removeMouseMotionListener(Param_1);
        }
    public void removeNotify()
        {
        __peer.super$removeNotify();
        }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener listener)
        {
        __peer.super$removePropertyChangeListener(listener);
        }
    public void requestFocus()
        {
        __peer.super$requestFocus();
        }
    public void setBackground(java.awt.Color Param_1)
        {
        __peer.super$setBackground(Param_1);
        }
    public void setBounds(java.awt.Rectangle Param_1)
        {
        __peer.super$setBounds(Param_1);
        }
    public void setCursor(java.awt.Cursor Param_1)
        {
        __peer.super$setCursor(Param_1);
        }
    public void setFont(java.awt.Font Param_1)
        {
        __peer.super$setFont(Param_1);
        }
    public void setForeground(java.awt.Color Param_1)
        {
        __peer.super$setForeground(Param_1);
        }
    public void setLayout(java.awt.LayoutManager Param_1)
        {
        __peer.super$setLayout(Param_1);
        }
    public void setLocation(java.awt.Point Param_1)
        {
        __peer.super$setLocation(Param_1);
        }
    public void setSize(java.awt.Dimension Param_1)
        {
        __peer.super$setSize(Param_1);
        }
    public void setEnabled(boolean Param_1)
        {
        __peer.super$setEnabled(Param_1);
        }
    public void showStatus(String msg)
        {
        __peer.super$showStatus(msg);
        }
    public void setVisible(boolean Param_1)
        {
        __peer.super$setVisible(Param_1);
        }
    public void start()
        {
        __peer.super$start();
        }
    public void stop()
        {
        __peer.super$stop();
        }
    public void validate()
        {
        __peer.super$validate();
        }
    }
