/* Class
*     _package.component.application.gUI.Applet
*/

package _package.component.application.gUI;

import _package.component.gUI.control.container.jComponent.JPanel;

/*
* Integrates
*     java.applet.Applet
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class Applet
        extends    _package.component.application.GUI
    {
    // Fields declarations
    
    /**
    * Property MainPanel
    *
    */
    private transient String __m_MainPanel;
    
    // fields used by the integration model:
    private sink_Applet __sink;
    private java.applet.Applet __feed;
    
    // Default constructor
    public Applet()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Applet(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // singleton initialization
        if (__singleton != null)
            {
            throw new IllegalStateException("A singleton for \"Applet\" has already been set");
            }
        __singleton = this;
        
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_Applet.__tloPeer.setObject(this);
            new jb_Applet(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Instantiate an Application component or return the previously
    * instantiated singleton.
    * 
    * The implementation of the get_Instance accessor on the Application
    * component is more complex than that of most other singleton components. 
    * First, it must be able to determine what application to instantiate. 
    * Secondly, it works with the _Reference property of the root component to
    * maintain a reference to the resulting application component until the
    * very last component instance is garbage-collected.
    * 
    * 1)  The _Reference property is static and located on the root component.
    * 2)  The accessor and mutator for the _Reference property are protected
    * and thus the property value can be obtained or modified by any component.
    *  (Specifically, it is set initially by Component.<init>, obtained by
    * Application.get_Instance, and set by Application.onInit.)
    * 3)  Component.<init> (the constructor of the root component) sets the
    * _Reference property to the instance of the component being constructed if
    * and only if the _Reference property is null; this guarantees that a
    * reference to the very first component to be instantiated is initially
    * stored in the _Reference property.
    * 4)  When an application component is instantiated, the Application.onInit
    * method stores a reference to that application in the _Reference property;
    * this ensures that a reference to the application will exist as long as
    * any component instance exists (because the root component class will not
    * be garbage-collectable until all component instances are determined to be
    * garbage-collectable and until all of its sub-classes are determined to be
    * garbage-collectable).  Since Application is a singleton, it is not
    * possible for a second instance of Application to exist, so once an
    * Application component has been instantiated, the _Reference property's
    * value will refer to that application until the root component class is
    * garbage-collected.
    * 5)  When Application.get_Instance() is invoked, if no singleton
    * application (Application.__singleton) has been created, then
    * Application.get_Instance is responsible for instantiating an application,
    * which will result in _Reference being set to the application instance (by
    * way of Application.onInit).
    * 
    * The implementation of Application.get_Instance is expected to take the
    * the following steps in order to instantiate the correct application
    * component:
    * 1) If the value of the _Reference property is non-null, it cannot be an
    * instance of Component.Application, because the __init method of an
    * Application component would have set the Application.__singleton field to
    * reference itself.  Application thus assumes that a non-null _Reference
    * value refers to the first component to be instantiated, and invokes the
    * _makeApplication instance method of that component.  If the return value
    * from _makeApplication is non-null, then it is returned by
    * Application.get_Instance.
    * 2)  Application.get_Instance is now in a catch-22.  No instance of
    * Component.Application exists, which means that the entry point (the
    * initially instantiated) component was not an application component, and
    * the component that was the entry point has denied knowledge of what
    * application should be instantiated.  At this point, the
    * Application.get_Instance method must determine the name of the
    * application component to instantiate without any help.  So it drops back
    * and punts.  First, it checks for an environment setting, then it checks
    * for a properties file setting, and if either one exists, then it
    * instantiates the component specified by that setting and returns it.
    * 3)  Finally, without so much as a clue telling Application.get_Instance
    * what to instantiate, it instantiates the default application context.
    * 
    * Note that in any of the above scenarios, by the time the value is
    * returned by Application.get_Instance, the value of the _Reference
    * property would have been set to the application instance by
    * Application.onInit, thus fulfilling the goal of holding a reference to
    * the application.
    * 
    * Any other case in which a reference must be maintained should be done by
    * having the application hold that reference.  In other words, as long as
    * the application doesn't go away, any reference that it holds won't go
    * away either.
    * 
    * @see Component#_Reference
    */
    public static _package.Component get_Instance()
        {
        _package.Component singleton = __singleton;
        
        if (singleton == null)
            {
            singleton = new Applet();
            }
        else if (!(singleton instanceof Applet))
            {
            throw new IllegalStateException("A singleton for \"Applet\" has already been set to a different type");
            }
        return singleton;
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/application/gUI/Applet".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.applet.Applet integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_Applet) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (java.applet.Applet) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public void _add(java.awt.Component Param_1, Object Param_2, int Param_3)
        {
        __sink.add(Param_1, Param_2, Param_3);
        }
    public void addFocusListener(java.awt.event.FocusListener l)
        {
        __sink.addFocusListener(l);
        }
    public void addKeyListener(java.awt.event.KeyListener Param_1)
        {
        __sink.addKeyListener(Param_1);
        }
    public void addMouseListener(java.awt.event.MouseListener Param_1)
        {
        __sink.addMouseListener(Param_1);
        }
    public void addMouseMotionListener(java.awt.event.MouseMotionListener Param_1)
        {
        __sink.addMouseMotionListener(Param_1);
        }
    public void addNotify()
        {
        __sink.addNotify();
        }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener listener)
        {
        __sink.addPropertyChangeListener(listener);
        }
    public void destroy()
        {
        __sink.destroy();
        }
    public void doLayout()
        {
        __sink.doLayout();
        }
    public java.applet.AppletContext getAppletContext()
        {
        return __sink.getAppletContext();
        }
    public String getAppletInfo()
        {
        return __sink.getAppletInfo();
        }
    public java.applet.AudioClip getAudioClip(java.net.URL url)
        {
        return __sink.getAudioClip(url);
        }
    public java.applet.AudioClip getAudioClip(java.net.URL url, String name)
        {
        return __sink.getAudioClip(url, name);
        }
    public java.awt.Color get_Background()
        {
        return __sink.getBackground();
        }
    public java.awt.Rectangle get_Bounds()
        {
        return __sink.getBounds();
        }
    public java.net.URL getCodeBase()
        {
        return __sink.getCodeBase();
        }
    public java.awt.Cursor get_Cursor()
        {
        return __sink.getCursor();
        }
    public java.net.URL getDocumentBase()
        {
        return __sink.getDocumentBase();
        }
    public java.awt.Font get_Font()
        {
        return __sink.getFont();
        }
    public java.awt.Color get_Foreground()
        {
        return __sink.getForeground();
        }
    public java.awt.Image getImage(java.net.URL url)
        {
        return __sink.getImage(url);
        }
    public java.awt.Image getImage(java.net.URL url, String name)
        {
        return __sink.getImage(url, name);
        }
    public java.awt.Insets get_Insets()
        {
        return __sink.getInsets();
        }
    public java.awt.LayoutManager get_Layout()
        {
        return __sink.getLayout();
        }
    public java.awt.Point get_Location()
        {
        return __sink.getLocation();
        }
    public java.awt.Point get_LocationOnScreen()
        {
        return __sink.getLocationOnScreen();
        }
    public String getParameter(String Param_1)
        {
        return __sink.getParameter(Param_1);
        }
    public String[][] getParameterInfo()
        {
        return __sink.getParameterInfo();
        }
    public java.awt.Dimension get_Size()
        {
        return __sink.getSize();
        }
    public void init()
        {
        __sink.init();
        }
    public boolean isActive()
        {
        return __sink.isActive();
        }
    public boolean isEnabled()
        {
        return __sink.isEnabled();
        }
    public boolean isFocusTraversable()
        {
        return __sink.isFocusTraversable();
        }
    public boolean isShowing()
        {
        return __sink.isShowing();
        }
    public boolean isVisible()
        {
        return __sink.isVisible();
        }
    public void paint(java.awt.Graphics g)
        {
        __sink.paint(g);
        }
    public void play(java.net.URL url)
        {
        __sink.play(url);
        }
    public void play(java.net.URL url, String name)
        {
        __sink.play(url, name);
        }
    public void _remove(java.awt.Component comp)
        {
        __sink.remove(comp);
        }
    public void removeFocusListener(java.awt.event.FocusListener l)
        {
        __sink.removeFocusListener(l);
        }
    public void removeKeyListener(java.awt.event.KeyListener Param_1)
        {
        __sink.removeKeyListener(Param_1);
        }
    public void removeMouseListener(java.awt.event.MouseListener Param_1)
        {
        __sink.removeMouseListener(Param_1);
        }
    public void removeMouseMotionListener(java.awt.event.MouseMotionListener Param_1)
        {
        __sink.removeMouseMotionListener(Param_1);
        }
    public void removeNotify()
        {
        __sink.removeNotify();
        }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener listener)
        {
        __sink.removePropertyChangeListener(listener);
        }
    public void requestFocus()
        {
        __sink.requestFocus();
        }
    public void set_Background(java.awt.Color Param_1)
        {
        __sink.setBackground(Param_1);
        }
    public void set_Bounds(java.awt.Rectangle Param_1)
        {
        __sink.setBounds(Param_1);
        }
    public void set_Cursor(java.awt.Cursor Param_1)
        {
        __sink.setCursor(Param_1);
        }
    public void setEnabled(boolean Param_1)
        {
        __sink.setEnabled(Param_1);
        }
    public void set_Font(java.awt.Font Param_1)
        {
        __sink.setFont(Param_1);
        }
    public void set_Foreground(java.awt.Color Param_1)
        {
        __sink.setForeground(Param_1);
        }
    public void set_Layout(java.awt.LayoutManager Param_1)
        {
        __sink.setLayout(Param_1);
        }
    public void set_Location(java.awt.Point Param_1)
        {
        __sink.setLocation(Param_1);
        }
    public void set_Size(java.awt.Dimension Param_1)
        {
        __sink.setSize(Param_1);
        }
    public void setVisible(boolean Param_1)
        {
        __sink.setVisible(Param_1);
        }
    public void setStatus(String msg)
        {
        __sink.showStatus(msg);
        }
    private void start$Router()
        {
        __sink.start();
        }
    public void start()
        {
        _trace("starting applet");
        start$Router();

        }
    private void stop$Router()
        {
        __sink.stop();
        }
    public void stop()
        {
        _trace(">>>>>stoping applet");
        stop$Router();
        }
    public void validate()
        {
        __sink.validate();
        }
    //-- java.applet.Applet integration
    
    // Declared at the super level
    /**
    * Prints out the specified message according to the Application context. 
    * Derived applications should provide an appropriate implementation for
    * this method if the output should not be sent to the standard output and
    * error output.  For example, if an application wanted to log output, this
    * would be the method to override.
    * 
    * @param message  the text message to display
    * @param severity  0 for informational, ascending for more serious output
    * (the default implementation assumes anything not 0 is an error and should
    * be printed to the system error stream)
    */
    public void debugOutput(String message, int severity)
        {
        // TO DO: what to do?
        setStatus(message);
        debugSound();
        }
    
    // Accessor for the property "MainPanel"
    public String getMainPanel()
        {
        return __m_MainPanel;
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel;
        
        super.onInit();
        
        // this is a transparent (kind of non-visual) component
        
        JPanel panel = (JPanel) _newInstance("Component.GUI.Control.Container.JComponent.JPanel." +
            getMainPanel());
        _add((java.awt.Component) panel.get_Feed(), "Center", 0);
        }
    
    // Accessor for the property "MainPanel"
    public void setMainPanel(String pMainPanel)
        {
        __m_MainPanel = pMainPanel;
        }
    }
