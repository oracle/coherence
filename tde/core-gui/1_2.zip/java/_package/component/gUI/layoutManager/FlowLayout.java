/* Class
*     _package.component.gUI.layoutManager.FlowLayout
*/

package _package.component.gUI.layoutManager;

/*
* Integrates
*     java.awt.FlowLayout
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class FlowLayout
        extends    _package.component.gUI.LayoutManager
    {
    // Fields declarations
    
    /**
    * Property ALIGN_CENTER
    *
    */
    public static final int ALIGN_CENTER = 1; // java.awt.FlowLayout.CENTER;
    
    /**
    * Property ALIGN_LEADING
    *
    */
    public static final int ALIGN_LEADING = 3; // java.awt.FlowLayout.LEADING;
    
    /**
    * Property ALIGN_LEFT
    *
    */
    public static final int ALIGN_LEFT = 0; // java.awt.FlowLayout.LEFT;
    
    /**
    * Property ALIGN_RIGHT
    *
    */
    public static final int ALIGN_RIGHT = 2; // java.awt.FlowLayout.RIGHT;
    
    /**
    * Property ALIGN_TRAILING
    *
    */
    public static final int ALIGN_TRAILING = 4; // java.awt.FlowLayout.TRAILING;
    
    /**
    * Property Alignment
    *
    */
    private transient int __m_Alignment;
    
    /**
    * Property Hgap
    *
    */
    private transient int __m_Hgap;
    
    /**
    * Property Vgap
    *
    */
    private transient int __m_Vgap;
    
    // Default constructor
    public FlowLayout()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public FlowLayout(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAlignment(1);
            setHgap(10);
            setVgap(10);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new FlowLayout();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/layoutManager/FlowLayout".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.FlowLayout integration
    // Access optimization
    // properties integration
    // methods integration
    public int getAlignment()
        {
        return ((java.awt.FlowLayout) get_Layout()).getAlignment();
        }
    public int getHgap()
        {
        return ((java.awt.FlowLayout) get_Layout()).getHgap();
        }
    public int getVgap()
        {
        return ((java.awt.FlowLayout) get_Layout()).getVgap();
        }
    public void setAlignment(int pAlignment)
        {
        ((java.awt.FlowLayout) get_Layout()).setAlignment(pAlignment);
        }
    public void setHgap(int pHgap)
        {
        ((java.awt.FlowLayout) get_Layout()).setHgap(pHgap);
        }
    public void setVgap(int pVgap)
        {
        ((java.awt.FlowLayout) get_Layout()).setVgap(pVgap);
        }
    //-- java.awt.FlowLayout integration
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof FlowLayout)
            {
            FlowLayout that = (FlowLayout) obj;
            return this.getHGap()     == that.getHGap() &&
                   this.getVGap()     == that.getVGap() &&
                   this.getAlignment() == that.getAlignment();
            }
        else
            {
            return super.equals(obj);
            }
        }
    
    // Declared at the super level
    public java.awt.LayoutManager get_Layout()
        {
        java.awt.LayoutManager _layout = super.get_Layout();
        if (_layout == null)
            {
            _layout = new java.awt.FlowLayout();
            set_Layout(_layout);
            }
        return _layout;
        }
    }
