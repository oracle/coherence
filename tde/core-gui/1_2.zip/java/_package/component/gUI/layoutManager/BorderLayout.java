/* Class
*     _package.component.gUI.layoutManager.BorderLayout
*/

package _package.component.gUI.layoutManager;

/*
* Integrates
*     java.awt.BorderLayout
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class BorderLayout
        extends    _package.component.gUI.LayoutManager
    {
    // Fields declarations
    
    /**
    * Property AFTER_LAST_LINE
    *
    */
    public static final String AFTER_LAST_LINE = "Last"; // java.awt.BorderLayout.AFTER_LAST_LINE;
    
    /**
    * Property AFTER_LINE_ENDS
    *
    */
    public static final String AFTER_LINE_ENDS = "After"; // java.awt.BorderLayout.AFTER_LINE_ENDS;
    
    /**
    * Property BEFORE_FIRST_LINE
    *
    */
    public static final String BEFORE_FIRST_LINE = "First"; // java.awt.BorderLayout.BEFORE_FIRST_LINE;
    
    /**
    * Property BEFORE_LINE_BEGINS
    *
    */
    public static final String BEFORE_LINE_BEGINS = "Before"; // java.awt.BorderLayout.BEFORE_LINE_BEGINS;
    
    /**
    * Property CENTER
    *
    */
    public static final String CENTER = "Center"; // java.awt.BorderLayout.CENTER;
    
    /**
    * Property EAST
    *
    */
    public static final String EAST = "East"; // java.awt.BorderLayout.EAST;
    
    /**
    * Property Hgap
    *
    */
    private int __m_Hgap;
    
    /**
    * Property NORTH
    *
    */
    public static final String NORTH = "North"; // java.awt.BorderLayout.NORTH;
    
    /**
    * Property SOUTH
    *
    */
    public static final String SOUTH = "South"; // java.awt.BorderLayout.SOUTH;
    
    /**
    * Property Vgap
    *
    */
    private int __m_Vgap;
    
    /**
    * Property WEST
    *
    */
    public static final String WEST = "West"; // java.awt.BorderLayout.WEST;
    
    // Default constructor
    public BorderLayout()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public BorderLayout(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new BorderLayout();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/layoutManager/BorderLayout".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.BorderLayout integration
    // Access optimization
    // properties integration
    // methods integration
    public int getHgap()
        {
        return ((java.awt.BorderLayout) get_Layout()).getHgap();
        }
    public int getVgap()
        {
        return ((java.awt.BorderLayout) get_Layout()).getVgap();
        }
    public void setHgap(int pHGap)
        {
        ((java.awt.BorderLayout) get_Layout()).setHgap(pHGap);
        }
    public void setVgap(int pVGap)
        {
        ((java.awt.BorderLayout) get_Layout()).setVgap(pVGap);
        }
    //-- java.awt.BorderLayout integration
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof BorderLayout)
            {
            BorderLayout that = (BorderLayout) obj;
            return this.getHGap() == that.getHGap() &&
                   this.getVGap() == that.getVGap();
            }
        else
            {
            return super.equals(obj);
            }
        }
    
    // Declared at the super level
    public java.awt.LayoutManager get_Layout()
        {
        java.awt.LayoutManager _layout = super.get_Layout();
        if (_layout == null)
            {
            _layout = new java.awt.BorderLayout();
            set_Layout(_layout);
            }
        return _layout;
        }
    }
