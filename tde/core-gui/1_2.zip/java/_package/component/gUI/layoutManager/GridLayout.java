/* Class
*     _package.component.gUI.layoutManager.GridLayout
*/

package _package.component.gUI.layoutManager;

/**
* This component integrates the <code>java.awt.GridLayout</code> layout manager
* that lays out a container's components in a rectangular grid.
* <p>
* The container is divided into equal-sized rectangles, and one component is
* placed in each rectangle.
*/
/*
* Integrates
*     java.awt.GridLayout
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class GridLayout
        extends    _package.component.gUI.LayoutManager
    {
    // Fields declarations
    
    /**
    * Property Columns
    *
    * Specifies the number of columns in this layout.
    */
    private transient int __m_Columns;
    
    /**
    * Property Hgap
    *
    * Specifies the horizontal gap between components.
    */
    private transient int __m_Hgap;
    
    /**
    * Property Rows
    *
    * Specifies the number of rows in this layout.
    */
    private transient int __m_Rows;
    
    /**
    * Property Vgap
    *
    * Specifies the vertical gap between components.
    */
    private transient int __m_Vgap;
    
    // Default constructor
    public GridLayout()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public GridLayout(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new GridLayout();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/layoutManager/GridLayout".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.GridLayout integration
    // Access optimization
    // properties integration
    // methods integration
    public int getColumns()
        {
        return ((java.awt.GridLayout) get_Layout()).getColumns();
        }
    public int getHgap()
        {
        return ((java.awt.GridLayout) get_Layout()).getHgap();
        }
    public int getRows()
        {
        return ((java.awt.GridLayout) get_Layout()).getRows();
        }
    public int getVgap()
        {
        return ((java.awt.GridLayout) get_Layout()).getVgap();
        }
    public void setColumns(int pColumns)
        {
        ((java.awt.GridLayout) get_Layout()).setColumns(pColumns);
        }
    public void setHgap(int pHgap)
        {
        ((java.awt.GridLayout) get_Layout()).setHgap(pHgap);
        }
    public void setRows(int pRows)
        {
        ((java.awt.GridLayout) get_Layout()).setRows(pRows);
        }
    public void setVgap(int pVgap)
        {
        ((java.awt.GridLayout) get_Layout()).setVgap(pVgap);
        }
    //-- java.awt.GridLayout integration
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof GridLayout)
            {
            GridLayout that = (GridLayout) obj;
            return this.getHGap()    == that.getHGap() &&
                   this.getVGap()    == that.getVGap() &&
                   this.getColumns() == that.getColumns() &&
                   this.getRows()    == that.getRows();
            }
        else
            {
            return super.equals(obj);
            }
        }
    
    // Declared at the super level
    public java.awt.LayoutManager get_Layout()
        {
        java.awt.LayoutManager _layout = super.get_Layout();
        if (_layout == null)
            {
            _layout = new java.awt.GridLayout();
            set_Layout(_layout);
            }
        return _layout;
        }
    }
