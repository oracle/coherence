/* Class
*     _package.component.gUI.layoutManager.GridBagLayout
*/

package _package.component.gUI.layoutManager;

/**
* This component integrates the <code>java.awt.GridBagLayout</code> layout
* manager that aligns components vertically and horizontally, without requiring
* that the components be of the same size.
* Each <code>GridBagLayout</code> object maintains a dynamic rectangular grid
* of cells, with each component occupying one or more cells, called its
* <em>display area</em>.
*/
/*
* Integrates
*     java.awt.GridBagLayout
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class GridBagLayout
        extends    _package.component.gUI.LayoutManager
    {
    // Fields declarations
    
    /**
    * Property ColumnWeights
    *
    * This field holds the overrides to the column weights.  If this field is
    * non-null the values are applied to the gridbag after all of the columns
    * weights have been calculated.
    */
    
    /**
    * Property ColumnWidths
    *
    * This field holds the overrides to the column minimum width.  If this
    * field is non-null the values are applied to the gridbag after all of the
    * minimum columns widths have been calculated.
    */
    
    /**
    * Property RowHeights
    *
    * This field holds the overrides to the row minimum heights.  If this field
    * is non-null the values are applied to the gridbag after all of the
    * minimum row heights have been calculated.
    */
    
    /**
    * Property RowWeights
    *
    * This field holds the overrides to the row weights.  If this field is
    * non-null the values are applied to the gridbag after all of the rows
    * weights have been calculated.
    */
    
    // Default constructor
    public GridBagLayout()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public GridBagLayout(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new GridBagLayout();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/layoutManager/GridBagLayout".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.GridBagLayout integration
    // Access optimization
    // properties integration
    private double[] getColumnWeights()
        {
        return ((java.awt.GridBagLayout) get_Layout()).columnWeights;
        }
    private void setColumnWeights(double[] pColumnWeights)
        {
        ((java.awt.GridBagLayout) get_Layout()).columnWeights = pColumnWeights;
        }
    private int[] getColumnWidths()
        {
        return ((java.awt.GridBagLayout) get_Layout()).columnWidths;
        }
    private void setColumnWidths(int[] pColumnWidths)
        {
        ((java.awt.GridBagLayout) get_Layout()).columnWidths = pColumnWidths;
        }
    private int[] getRowHeights()
        {
        return ((java.awt.GridBagLayout) get_Layout()).rowHeights;
        }
    private void setRowHeights(int[] pRowHeights)
        {
        ((java.awt.GridBagLayout) get_Layout()).rowHeights = pRowHeights;
        }
    private double[] getRowWeights()
        {
        return ((java.awt.GridBagLayout) get_Layout()).rowWeights;
        }
    private void setRowWeights(double[] pRowWeights)
        {
        ((java.awt.GridBagLayout) get_Layout()).rowWeights = pRowWeights;
        }
    // methods integration
    //-- java.awt.GridBagLayout integration
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof GridBagLayout)
            {
            GridBagLayout that = (GridBagLayout) obj;
            return this.getColumnWeights().equals(that.getColumnWeights()) &&
                   this.getColumnWidths() .equals(that.getColumnWidths()) &&
                   this.getRowWeights()   .equals(that.getRowWeights()) &&
                   this.getRowHeights()   .equals(that.getRowHeights());
            }
        else
            {
            return super.equals(obj);
            }
        }
    
    // Declared at the super level
    public java.awt.LayoutManager get_Layout()
        {
        java.awt.LayoutManager _layout = super.get_Layout();
        if (_layout == null)
            {
            _layout = new java.awt.GridBagLayout();
            set_Layout(_layout);
            }
        return _layout;
        }
    }
