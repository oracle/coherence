/* Class
*     _package.component.gUI.layoutManager.AnchorLayout
*/

package _package.component.gUI.layoutManager;

import _package.component.gUI.Control;
import _package.component.gUI.constraints.AnchorConstraints;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.Enumeration;
import java.util.Hashtable;

/**
* 
* +++++++++++++++++++++++++++
* 
* AnchorLayout lays out a container, arranging and resizing its child
* components according to any combination of algorithms:
* 
* ANCHOR_NONE: does nothing
* ANCHOR_LEFT: moves the child component in such a way that the distance from
* the Left side of the component to the Right side of the container stays
* constant
* ANCHOR_TOP: moves the child component in such a way that the distance from
* the Top side of the component to the Bottom side of the container stays
* constant
* ANCHOR_RIGHT: resizes the child component in such a way that the distance
* from the Right side of the component to the Right side of the container stays
* constant
* ANCHOR_BOTTOM: moves the child component in such a way that the distance from
* the Bottom side of the component to the Bottom side of the container stays
* constant
* 
* @see Component.GUI.Constraints.AnchorConstraints
*/
public class AnchorLayout
        extends    _package.component.gUI.LayoutManager
    {
    // Fields declarations
    
    /**
    * Property LAYOUT_MINIMUM
    *
    */
    protected static final int LAYOUT_MINIMUM = 1;
    
    /**
    * Property LAYOUT_PREFERRED
    *
    */
    protected static final int LAYOUT_PREFERRED = 0;
    
    /**
    * Property LayoutCache
    *
    */
    private java.util.Hashtable __m_LayoutCache;
    
    // Default constructor
    public AnchorLayout()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public AnchorLayout(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setLayoutCache(new java.util.Hashtable(11));
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new AnchorLayout();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/layoutManager/AnchorLayout".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Constraints.AnchorConstraints;
        

        }
    
    // Declared at the super level
    /**
    * Adds the specified component to the layout, using the specified
    * constraint object.
    */
    public void addLayoutComponent(java.awt.Component _comp, Object _constraints)
        {
        // import Component.GUI.Constraints.AnchorConstraints;
        // import Component.GUI.Control;
        // import java.awt.Component;
        // import java.awt.Container;
        // import java.awt.Dimension;
        // import java.awt.Point;
        
        super.addLayoutComponent(_comp, _constraints);
        
        if (!(_constraints instanceof AnchorConstraints))
            {
            // same as ANCHOR_NONE -- ignore
            return;
            }
        
        AnchorConstraints constraints = (AnchorConstraints) _constraints;
        
        Container _parent   = _comp.getParent();
        Dimension dimParent = _parent.getSize();
        Point     ptChild   = _comp.getLocation();
        Dimension dimChild  = _comp.getSize();
        
        constraints.setAnchorLeft  (dimParent.width  - ptChild.x);
        constraints.setAnchorRight (dimParent.width  - ptChild.x - dimChild.width);
        constraints.setAnchorTop   (dimParent.height - ptChild.y);
        constraints.setAnchorBottom(dimParent.height - ptChild.y - dimChild.height);
        
        getLayoutCache().put(_comp, constraints);
        }
    
    /**
    * Calculates the size dimensions for the specified container for the
    * specified mode.
    * 
    * @param _parent the component to be laid out
    * @param iMode  the layout mode -- one of LAYOUT_PREFERRED, LAYOUT_MINIMUM
    */
    protected java.awt.Dimension calculateLayout(java.awt.Container _parent, int iMode)
        {
        // TODO: calculate the layout size such that none of the components are forced
        // to have degenerated bounds
        
        return new java.awt.Dimension(0, 0);
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (!(obj instanceof AnchorLayout))
            {
            return false;
            }
        
        return true;
        }
    
    // Accessor for the property "LayoutCache"
    protected java.util.Hashtable getLayoutCache()
        {
        return __m_LayoutCache;
        }
    
    // Declared at the super level
    /**
    * Lays out the container in the specified container.
    * 
    * @param _parent the container which needs to be laid out.
    */
    public void layoutContainer(java.awt.Container _parent)
        {
        // import Component.GUI.Constraints.AnchorConstraints;
        // import java.awt.Component;
        // import java.awt.Dimension;
        // import java.awt.Rectangle;
        // import java.util.Enumeration;
        // import java.util.Hashtable;
        
        Hashtable cache = getLayoutCache();
        
        for (Enumeration enum = cache.keys(); enum.hasMoreElements();)
            {
            Component _child = (Component) enum.nextElement();
        
            AnchorConstraints constraints = (AnchorConstraints) cache.get(_child);
            int               iPolicy     = constraints.getAnchorPolicy();
        
            if (iPolicy == AnchorConstraints.ANCHOR_NONE)
                {
                continue;
                }
        
            Dimension dimParent = _parent.getSize();
            Rectangle rectChild = _child.getBounds();
        
            if ((iPolicy & AnchorConstraints.ANCHOR_LEFT) != 0)
                {
                rectChild.x = dimParent.width - constraints.getAnchorLeft();
                }
            if ((iPolicy & AnchorConstraints.ANCHOR_TOP) != 0)
                {
                rectChild.y = dimParent.height - constraints.getAnchorTop();
                }
            if ((iPolicy & AnchorConstraints.ANCHOR_RIGHT) != 0)
                {
                int w = dimParent.width - rectChild.x - constraints.getAnchorRight();
                rectChild.width = Math.max(w, 0);
                }
            if ((iPolicy & AnchorConstraints.ANCHOR_BOTTOM) != 0)
                {
                int h = dimParent.height - rectChild.y - constraints.getAnchorBottom();
                rectChild.height = Math.max(h, 0);
                }
        
            _child.setBounds(rectChild);
            }
        }
    
    // Declared at the super level
    public java.awt.Dimension minimumLayoutSize(java.awt.Container _parent)
        {
        return calculateLayout(_parent, LAYOUT_MINIMUM);
        }
    
    // Declared at the super level
    /**
    * Calculates the preferred size dimensions for the specified container
    * given the components in the specified parent container.
    * 
    * @param _parent the component to be laid out
    */
    public java.awt.Dimension preferredLayoutSize(java.awt.Container _parent)
        {
        return calculateLayout(_parent, LAYOUT_PREFERRED);
        }
    
    // Declared at the super level
    /**
    * Removes the specified component from the layout.
    * 
    * @param _comp the component to be removed
    */
    public void removeLayoutComponent(java.awt.Component _comp)
        {
        getLayoutCache().remove(_comp);
        }
    
    // Accessor for the property "LayoutCache"
    protected void setLayoutCache(java.util.Hashtable pLayoutCache)
        {
        __m_LayoutCache = pLayoutCache;
        }
    }
