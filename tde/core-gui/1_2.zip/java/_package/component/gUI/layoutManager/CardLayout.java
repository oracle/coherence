/* Class
*     _package.component.gUI.layoutManager.CardLayout
*/

package _package.component.gUI.layoutManager;

/**
* This component integrates the <code>java.awt.CardLayout</code> layout
* manager.  It treats each component in the container as a card. Only one card
* is visible at a time, and the container acts as a stack of cards.
*/
/*
* Integrates
*     java.awt.CardLayout
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class CardLayout
        extends    _package.component.gUI.LayoutManager
    {
    // Fields declarations
    
    /**
    * Property Hgap
    *
    */
    private transient int __m_Hgap;
    
    /**
    * Property Vgap
    *
    */
    private transient int __m_Vgap;
    
    // Default constructor
    public CardLayout()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CardLayout(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new CardLayout();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/layoutManager/CardLayout".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.CardLayout integration
    // Access optimization
    // properties integration
    // methods integration
    public int getHgap()
        {
        return ((java.awt.CardLayout) get_Layout()).getHgap();
        }
    public int getVgap()
        {
        return ((java.awt.CardLayout) get_Layout()).getVgap();
        }
    public void setHgap(int pHgap)
        {
        ((java.awt.CardLayout) get_Layout()).setHgap(pHgap);
        }
    public void setVgap(int pVgap)
        {
        ((java.awt.CardLayout) get_Layout()).setVgap(pVgap);
        }
    //-- java.awt.CardLayout integration
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof CardLayout)
            {
            CardLayout that = (CardLayout) obj;
            return this.getHGap() == that.getHGap() &&
                   this.getVGap() == that.getVGap();
            }
        else
            {
            return super.equals(obj);
            }
        }
    
    // Declared at the super level
    public java.awt.LayoutManager get_Layout()
        {
        java.awt.LayoutManager _layout = super.get_Layout();
        if (_layout == null)
            {
            _layout = new java.awt.CardLayout();
            set_Layout(_layout);
            }
        return _layout;
        }
    }
