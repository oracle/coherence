/* Class
*      jb_FileFilter
*
* automatically generated "Feed" which
* a) extends an external bean:
*      javax.swing.filechooser.FileFilter
* b) delegates to the peer component:
*      Component.GUI.FileFilter
*/

package _package.component.gUI;

public class jb_FileFilter
        extends    javax.swing.filechooser.FileFilter
        implements com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected FileFilter __peer;
    
    private static FileFilter __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            FileFilter peer = (FileFilter)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // default (JavaBean) constructor
    public jb_FileFilter()
        {
        this(FileFilter.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_FileFilter(Class clzPeer)
        {
        this(__createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_FileFilter(FileFilter peer, boolean fInit)
        {
        super();
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private FileFilter __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (FileFilter) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_FileFilter(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    public boolean accept(java.io.File file)
        {
        FileFilter peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.accept(file);
        }
    boolean super$accept(java.io.File file)
        {
        return false;
        }
    public String getDescription()
        {
        FileFilter peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Description();
        }
    String super$getDescription()
        {
        return null;
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
