/* Class
*     _package.component.gUI.renderer.icon.Choice
*/

package _package.component.gUI.renderer.icon;

/**
* This component represents an icon used to indicate an availability of a
* choice. The drawing logic is copied from
* javax.swing.plaf.metal.MetalComboBoxButton.
* 
* A possible way to implement PLAF would be to override get_Instance() and try
* to call _newInstance() based on the current PLAF (using
* javax.swing.UIManager.getLookAndFeel().getName())
*/
public class Choice
        extends    _package.component.gUI.renderer.Icon
    {
    // Fields declarations
    
    // Default constructor
    public Choice()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Choice(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setIconHeight(5);
            setIconWidth(10);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Choice();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/renderer/icon/Choice".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void paintIcon(java.awt.Component comp, java.awt.Graphics g, int x, int y)
        {
        int iWidth = getIconWidth();
        
        x = comp.getWidth() - iWidth - 3;
        
        g.translate(x, y);
        
        g.setColor(comp.isEnabled() ?
            java.awt.Color.black : new java.awt.Color(153, 153, 153));
        g.drawLine(0, 0, iWidth - 1,       0);
        g.drawLine(1, 1, 1 + (iWidth - 3), 1);
        g.drawLine(2, 2, 2 + (iWidth - 5), 2);
        g.drawLine(3, 3, 3 + (iWidth - 7), 3);
        g.drawLine(4, 4, 4 + (iWidth - 9), 4);
        
        g.translate(-x, -y);
        }
    }
