/* Class
*     _package.component.gUI.renderer.Icon
*/

package _package.component.gUI.renderer;

/**
* This component represents an "programmable" icon. In contrast to
* GUI.Image.Icon component which integrates javax.swing.ImageIcon this
* component just implements javax.swing.Icon.
*/
public class Icon
        extends    _package.component.gUI.Renderer
        implements javax.swing.Icon
    {
    // Fields declarations
    
    /**
    * Property IconHeight
    *
    */
    private int __m_IconHeight;
    
    /**
    * Property IconWidth
    *
    */
    private int __m_IconWidth;
    
    // Default constructor
    public Icon()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Icon(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Icon();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/renderer/Icon".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: javax.swing.Icon
    // Accessor for the property "IconHeight"
    public int getIconHeight()
        {
        return __m_IconHeight;
        }
    
    // From interface: javax.swing.Icon
    // Accessor for the property "IconWidth"
    public int getIconWidth()
        {
        return __m_IconWidth;
        }
    
    // From interface: javax.swing.Icon
    public void paintIcon(java.awt.Component comp, java.awt.Graphics g, int x, int y)
        {
        }
    
    // Accessor for the property "IconHeight"
    public void setIconHeight(int pIconHeight)
        {
        __m_IconHeight = pIconHeight;
        }
    
    // Accessor for the property "IconWidth"
    public void setIconWidth(int pIconWidth)
        {
        __m_IconWidth = pIconWidth;
        }
    }
