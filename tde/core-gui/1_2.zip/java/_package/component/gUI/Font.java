/* Class
*     _package.component.gUI.Font
*/

package _package.component.gUI;

/*
* Integrates
*     java.awt.Font
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class Font
        extends    _package.component.GUI
    {
    // Fields declarations
    
    /**
    * Property _Font
    *
    */
    private java.awt.Font __m__Font;
    
    /**
    * Property Bold
    *
    */
    private boolean __m_Bold;
    
    /**
    * Property Italic
    *
    */
    private boolean __m_Italic;
    
    /**
    * Property Name
    *
    */
    private String __m_Name;
    
    /**
    * Property Size
    *
    */
    private int __m_Size;
    
    /**
    * Property Style
    *
    */
    private int __m_Style;
    
    /**
    * Property STYLE_BOLD
    *
    */
    public static final int STYLE_BOLD = 1; // java.awt.Font.BOLD;
    
    /**
    * Property STYLE_ITALIC
    *
    */
    public static final int STYLE_ITALIC = 2; // java.awt.Font.ITALIC;
    
    /**
    * Property STYLE_PLAIN
    *
    */
    public static final int STYLE_PLAIN = 0; // java.awt.Font.PLAIN;
    
    // Default constructor
    public Font()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Font(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Font();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/Font".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.Font integration
    // Access optimization
    // properties integration
    // methods integration
    public java.util.Map getAttributes()
        {
        return get_Font().getAttributes();
        }
    public java.text.AttributedCharacterIterator$Attribute[] getAvailableAttributes()
        {
        return get_Font().getAvailableAttributes();
        }
    public String getFamily()
        {
        return get_Font().getFamily();
        }
    public String getFontName()
        {
        return get_Font().getFontName();
        }
    public int getNumGlyphs()
        {
        return get_Font().getNumGlyphs();
        }
    public String getPSName()
        {
        return get_Font().getPSName();
        }
    public java.awt.geom.AffineTransform getTransform()
        {
        return get_Font().getTransform();
        }
    public boolean isBold()
        {
        return get_Font().isBold();
        }
    public boolean isItalic()
        {
        return get_Font().isItalic();
        }
    public boolean isPlain()
        {
        return get_Font().isPlain();
        }
    //-- java.awt.Font integration
    
    // Accessor for the property "_Font"
    public java.awt.Font get_Font()
        {
        java.awt.Font _font = __m__Font;
        if (_font == null)
            {
            _font = new java.awt.Font(getName(), getStyle(), getSize());
            set_Font(_font);
            }
        return _font;

        }
    
    // Accessor for the property "Name"
    public String getName()
        {
        return __m_Name;
        }
    
    // Accessor for the property "Size"
    public int getSize()
        {
        return __m_Size;
        }
    
    // Accessor for the property "Style"
    protected int getStyle()
        {
        return __m_Style;
        }
    
    // Accessor for the property "_Font"
    public void set_Font(java.awt.Font p_Font)
        {
        if (p_Font != null)
            {
            setName (p_Font.getName());
            setStyle(p_Font.getStyle());
            setSize (p_Font.getSize());
            }
        __m__Font = (p_Font);
        }
    
    // Accessor for the property "Bold"
    public void setBold(boolean fBold)
        {
        if (fBold)
            {
            setStyle(getStyle() | STYLE_BOLD);
            }
        else
            {
            setStyle(getStyle() & ~STYLE_BOLD);
            }
        }
    
    // Accessor for the property "Italic"
    public void setItalic(boolean fItalic)
        {
        if (fItalic)
            {
            setStyle(getStyle() | STYLE_ITALIC);
            }
        else
            {
            setStyle(getStyle() & ~STYLE_ITALIC);
            }
        }
    
    // Accessor for the property "Name"
    public void setName(String pName)
        {
        __m_Name = (pName);
        
        set_Font(null);
        }
    
    // Accessor for the property "Size"
    public void setSize(int pSize)
        {
        __m_Size = (pSize);
        
        set_Font(null);
        }
    
    // Accessor for the property "Style"
    public void setStyle(int pStyle)
        {
        __m_Style = (pStyle);
        
        set_Font(null);
        }
    }
