/* Class
*     _package.component.gUI.KeyAction
*/

package _package.component.gUI;

import _package.component.gUI.KeyStroke;
import _package.component.gUI.control.container.JComponent;
import com.tangosol.run.component.EventDeathException;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import javax.swing.JComponent; // as _JComponent

/**
* This component allows designing a keystroke action as a "child" of
* JComponent.  In turn, it contains one or more KeyStroke components describing
* the key being typed on the keyboard.  KeyAction component binds an action
* fired as a result of typing one of those kees to a corresponding visual
* [swing] component.
* If a parent component dispatches or implements the
* java.awt.event.ActionListener interface, the action will be re-delivered to
* the parent component.
* 
* @see #actionPerformed
*/
public class KeyAction
        extends    _package.component.GUI
        implements java.awt.event.ActionListener
    {
    // Fields declarations
    
    /**
    * Property ActionName
    *
    * Specifies the name of the action. If not specified, this component's name
    * is used.
    * 
    * @see #bind
    */
    private String __m_ActionName;
    
    /**
    * Property Condition
    *
    * Specifies the invokation condition. Valid values are:
    * 
    * WHEN_FOCUSED (0) -- means that the command should be invoked when the
    * component has the focus.
    * WHEN_IN_FOCUSED_WINDOW (1) -- means that the comand should be invoked
    * when the receiving component is an ancestor of the focused component or
    * is itself the focused component.
    * WHEN_ANCESTOR_OF_FOCUSED_COMPONENT (2) -- means that the command should
    * be invoked when the receiving component is in the window that has the
    * focus or is itself the focused component.
    * 
    * Note: if this property is set programmatically, it should be unbound
    * first with a call to <code>unbind</code> method and rebound afterwards
    * with a call to <code>bind</code> method.
    */
    private int __m_Condition;
    
    /**
    * Property WHEN_ANCESTOR_OF_FOCUSED
    *
    */
    public static final int WHEN_ANCESTOR_OF_FOCUSED = 1;
    
    /**
    * Property WHEN_FOCUSED
    *
    */
    public static final int WHEN_FOCUSED = 0;
    
    /**
    * Property WHEN_IN_FOCUSED_WINDOW
    *
    */
    public static final int WHEN_IN_FOCUSED_WINDOW = 2;
    
    // Default constructor
    public KeyAction()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public KeyAction(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setCondition(0);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new KeyAction$KeyStroke1("KeyStroke1", this, true), "KeyStroke1");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new KeyAction();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/KeyAction".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent;
        // import Component.GUI.KeyStroke;
        // import javax.swing.JComponent as _JComponent;
        
        
        

        }
    
    // From interface: java.awt.event.ActionListener
    public void actionPerformed(java.awt.event.ActionEvent e)
        {
        // import com.tangosol.run.component.EventDeathException;
        // import java.awt.event.ActionListener;
        
        try
            {
            onTyped();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        Component parent = get_Parent();
        if (parent instanceof ActionListener)
            {
            ((ActionListener) parent).actionPerformed(e);
            }
        }
    
    /**
    * Registers this KeyStroke's action with the parent [JComponent].
    */
    public void bind()
        {
        Component parent = get_Parent();
        
        if (parent instanceof JComponent)
            {
            bind((JComponent) parent);
            }
        }
    
    /**
    * Registers this KeyStroke's action with the specified JComponent.
    */
    public void bind(_package.component.gUI.control.container.JComponent comp)
        {
        // import java.util.Enumeration;
        
        _JComponent _jcomp     = (_JComponent) comp.get_Feed();
        String      sAction    = getActionName();
        int         iCondition = getCondition();
        
        for (Enumeration enum = _enumChildren(); enum.hasMoreElements();)
            {
            KeyStroke key = (KeyStroke) enum.nextElement();
            
            _jcomp.registerKeyboardAction(this, sAction, key.get_KeyStroke(), iCondition);
            }
        }
    
    // Accessor for the property "ActionName"
    public String getActionName()
        {
        String sActionName = __m_ActionName;
        
        if (sActionName == null)
            {
            sActionName = get_Name();
            }
        
        return sActionName;
        }
    
    // Accessor for the property "Condition"
    public int getCondition()
        {
        return __m_Condition;
        }
    
    /**
    * Event-notification sent when a key corresponding to this KeyStroke has
    * been typed on the keyboard.
    */
    public void onTyped()
        {
        }
    
    // Accessor for the property "ActionName"
    public void setActionName(String pActionName)
        {
        __m_ActionName = pActionName;
        }
    
    // Accessor for the property "Condition"
    public void setCondition(int pCondition)
        {
        __m_Condition = pCondition;
        }
    
    // Declared at the super level
    public String toString()
        {
        // import java.util.Enumeration;
        
        StringBuffer sb = new StringBuffer(get_Name() + " (");
        boolean      f  = true;
        for (Enumeration enum = _enumChildren(); enum.hasMoreElements();)
            {
            KeyStroke key = (KeyStroke) enum.nextElement();
            if (f)
                {
                f = false;
                }
            else
                {
                sb.append(", ");
                }
            sb.append(key.toString());
            }
        sb.append(')');
        
        return sb.toString();
        }
    
    /**
    * Unregisters this KeyStroke's action from the parent [JComponent].
    */
    public void unbind()
        {
        Component parent = get_Parent();
        
        if (parent instanceof JComponent)
            {
            unbind((JComponent) parent);
            }
        }
    
    /**
    * Unregisters this KeyStroke's action from the specified JComponent.
    */
    public void unbind(_package.component.gUI.control.container.JComponent comp)
        {
        // import java.util.Enumeration;
        
        _JComponent _jcomp = (_JComponent) comp.get_Feed();
        
        for (Enumeration enum = _enumChildren(); enum.hasMoreElements();)
            {
            KeyStroke key = (KeyStroke) enum.nextElement();
            
            _jcomp.unregisterKeyboardAction(key.get_KeyStroke());
            }
        }
    }
