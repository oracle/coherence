/* Class
*     _package.component.gUI.Point
*/

package _package.component.gUI;

/*
* Integrates
*     java.awt.Point
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class Point
        extends    _package.component.GUI
    {
    // Fields declarations
    
    /**
    * Property _Point
    *
    */
    private java.awt.Point __m__Point;
    
    /**
    * Property Trivial
    *
    */
    
    /**
    * Property X
    *
    */
    
    /**
    * Property Y
    *
    */
    
    // Default constructor
    public Point()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Point(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Point();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/Point".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.Point integration
    // Access optimization
    // properties integration
    public int getX()
        {
        return get_Point().x;
        }
    public void setX(int pX)
        {
        get_Point().x = pX;
        }
    public int getY()
        {
        return get_Point().y;
        }
    public void setY(int pY)
        {
        get_Point().y = pY;
        }
    // methods integration
    public void move(int x, int y)
        {
        get_Point().move(x, y);
        }
    public void setLocation(int x, int y)
        {
        get_Point().setLocation(x, y);
        }
    public void translate(int x, int y)
        {
        get_Point().translate(x, y);
        }
    //-- java.awt.Point integration
    
    public void add(Point point)
        {
        translate(point.getX(), point.getY());
        

        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        setX(config.getInt(sPrefix + ".X", getX()));
        setY(config.getInt(sPrefix + ".Y", getY()));
        
        super.applyConfig(config, sPrefix);
        }
    
    // Declared at the super level
    public Object clone()
        {
        // TODO: this won't work conventionally for subclasses of Point
        return instantiate(getX(), getY());
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        return obj instanceof Point ?
            get_Point().equals(((Point) obj).get_Point()) :
            super.equals(obj);
        }
    
    // Accessor for the property "_Point"
    public java.awt.Point get_Point()
        {
        java.awt.Point pt = (java.awt.Point) get_Sink();
        if (pt == null)
            {
            pt = new java.awt.Point();
            set_Point(pt);
            }
        return pt;
        }
    
    public static Point instantiate(int x, int y)
        {
        return instantiate(new java.awt.Point(x, y));
        }
    
    public static Point instantiate(java.awt.Point _point)
        {
        Point point = new Point();
        point.set_Point(_point);
        return point;

        }
    
    // Accessor for the property "Trivial"
    public boolean isTrivial()
        {
        return getX() == 0 && getY() == 0;
        }
    
    /**
    * Negates this point's coordinates
    */
    public void neg()
        {
        setX(-getX());
        setY(-getY());
        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        config.putInt(sPrefix + ".X",  getX());
        config.putInt(sPrefix + ".Y" , getY());
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "_Point"
    public void set_Point(java.awt.Point p_Point)
        {
        set_Sink(p_Point);
        }
    
    public void sub(Point point)
        {
        translate(-point.getX(), -point.getY());
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_Name() + " [x=" + getX() + ", y=" + getY() + ']';
        }
    }
