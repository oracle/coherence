/* Class
*      sink_FileFilter
*
* automatically generated "Sink" which
* represents a footprint of the class
*      javax.swing.filechooser.FileFilter
* when used as a component callback by 
*      Component.GUI.FileFilter
*/

package _package.component.gUI;

public class sink_FileFilter
       extends com.tangosol.run.component.CallbackSink
    {
    private jb_FileFilter __peer;
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_FileFilter()
        {
        }
    
    // this (protected) constructor is used by the feed
    protected sink_FileFilter(jb_FileFilter feed)
        {
        super();
        __peer = feed;
        }
    
    // Retrieves the feed object for this sink
    public Object get_Feed()
        {
        return __peer;
        }
    
    // methods integrated and/or remoted
    public boolean accept(java.io.File file)
        {
        return __peer.super$accept(file);
        }
    public String getDescription()
        {
        return __peer.super$getDescription();
        }
    }
