/* Class
*     _package.component.gUI.Insets
*/

package _package.component.gUI;

/*
* Integrates
*     java.awt.Insets
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class Insets
        extends    _package.component.GUI
    {
    // Fields declarations
    
    /**
    * Property _Insets
    *
    */
    private transient java.awt.Insets __m__Insets;
    
    /**
    * Property Bottom
    *
    */
    
    /**
    * Property Left
    *
    */
    
    /**
    * Property Right
    *
    */
    
    /**
    * Property Top
    *
    */
    
    // Default constructor
    public Insets()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Insets(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Insets();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/Insets".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.Insets integration
    // Access optimization
    // properties integration
    /**
    * Getter for property Bottom.<p>
    */
    public int getBottom()
        {
        return get_Insets().bottom;
        }
    /**
    * Setter for property Bottom.<p>
    */
    public void setBottom(int pBottom)
        {
        get_Insets().bottom = pBottom;
        }
    /**
    * Getter for property Left.<p>
    */
    public int getLeft()
        {
        return get_Insets().left;
        }
    /**
    * Setter for property Left.<p>
    */
    public void setLeft(int pLeft)
        {
        get_Insets().left = pLeft;
        }
    /**
    * Getter for property Right.<p>
    */
    public int getRight()
        {
        return get_Insets().right;
        }
    /**
    * Setter for property Right.<p>
    */
    public void setRight(int pRight)
        {
        get_Insets().right = pRight;
        }
    /**
    * Getter for property Top.<p>
    */
    public int getTop()
        {
        return get_Insets().top;
        }
    /**
    * Setter for property Top.<p>
    */
    public void setTop(int pTop)
        {
        get_Insets().top = pTop;
        }
    // methods integration
    //-- java.awt.Insets integration
    
    // Declared at the super level
    public Object clone()
        {
        // TODO: this won't work conventionally for subclasses of Insets
        Insets insets = new Insets();
        insets.set_Insets(new java.awt.Insets(getLeft(), getTop(), getRight(), getBottom()));
        return insets;
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        return obj instanceof Insets ?
            get_Insets().equals(((Insets) obj).get_Insets()) :
            super.equals(obj);
        }
    
    // Accessor for the property "_Insets"
    /**
    * Getter for property _Insets.<p>
    */
    public java.awt.Insets get_Insets()
        {
        java.awt.Insets insets = (java.awt.Insets) get_Sink();
        if (insets == null)
            {
            insets = new java.awt.Insets(0, 0, 0, 0);
            set_Insets(insets);
            }
        return insets;
        }
    
    public static Insets instantiate(int iTop, int iLeft, int iBottom, int iRight)
        {
        Insets insets = new Insets();
        insets.set_Insets(new java.awt.Insets(iTop, iLeft, iBottom, iRight));
        return insets;
        }
    
    public static Insets instantiate(java.awt.Insets _insets)
        {
        Insets insets = new Insets();
        insets.set_Insets(_insets);
        return insets;
        }
    
    // Accessor for the property "_Insets"
    /**
    * Setter for property _Insets.<p>
    */
    public void set_Insets(java.awt.Insets p_Insets)
        {
        set_Sink(p_Insets);
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_Name() +
            "[Top=" + getTop() + ", Left=" + getLeft() +
            ", Bottom=" + getBottom() + ", Right=" + getRight() + ']';
        }
    }
