/* Class
*     _package.component.gUI.Rectangle
*/

package _package.component.gUI;

import _package.component.gUI.Dimension;
import _package.component.gUI.Point;

/*
* Integrates
*     java.awt.Rectangle
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class Rectangle
        extends    _package.component.GUI
    {
    // Fields declarations
    
    /**
    * Property _Rectangle
    *
    */
    private transient java.awt.Rectangle __m__Rectangle;
    
    /**
    * Property Empty
    *
    */
    
    /**
    * Property Height
    *
    */
    
    /**
    * Property Location
    *
    */
    private transient Point __m_Location;
    
    /**
    * Property Size
    *
    */
    private transient Dimension __m_Size;
    
    /**
    * Property Width
    *
    */
    
    /**
    * Property X
    *
    */
    
    /**
    * Property Y
    *
    */
    
    // Default constructor
    public Rectangle()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Rectangle(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Rectangle();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/Rectangle".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.Rectangle integration
    // Access optimization
    // properties integration
    public int getHeight()
        {
        return get_Rectangle().height;
        }
    public void setHeight(int pH)
        {
        get_Rectangle().height = pH;
        }
    public int getWidth()
        {
        return get_Rectangle().width;
        }
    public void setWidth(int pW)
        {
        get_Rectangle().width = pW;
        }
    public int getX()
        {
        return get_Rectangle().x;
        }
    public void setX(int pX)
        {
        get_Rectangle().x = pX;
        }
    public int getY()
        {
        return get_Rectangle().y;
        }
    public void setY(int pY)
        {
        get_Rectangle().y = pY;
        }
    // methods integration
    public void add(int x, int y)
        {
        get_Rectangle().add(x, y);
        }
    public void add(java.awt.Point _point)
        {
        get_Rectangle().add(_point);
        }
    public void add(java.awt.Rectangle _rect)
        {
        get_Rectangle().add(_rect);
        }
    public boolean contains(int x, int y)
        {
        return get_Rectangle().contains(x, y);
        }
    public boolean contains(int x, int y, int w, int h)
        {
        return get_Rectangle().contains(x, y, w, h);
        }
    public boolean contains(java.awt.Point _point)
        {
        return get_Rectangle().contains(_point);
        }
    public boolean contains(java.awt.Rectangle _rect)
        {
        return get_Rectangle().contains(_rect);
        }
    public java.awt.Rectangle get_Bounds()
        {
        return get_Rectangle().getBounds();
        }
    public java.awt.Point get_Location()
        {
        return get_Rectangle().getLocation();
        }
    public java.awt.Dimension get_Size()
        {
        return get_Rectangle().getSize();
        }
    public void grow(int w, int h)
        {
        get_Rectangle().grow(w, h);
        }
    public java.awt.Rectangle intersection(java.awt.Rectangle _rect)
        {
        return get_Rectangle().intersection(_rect);
        }
    public boolean intersects(java.awt.Rectangle _rect)
        {
        return get_Rectangle().intersects(_rect);
        }
    public boolean isEmpty()
        {
        return get_Rectangle().isEmpty();
        }
    public void setBounds(int x, int y, int w, int h)
        {
        get_Rectangle().setBounds(x, y, w, h);
        }
    public void set_Bounds(java.awt.Rectangle _rect)
        {
        get_Rectangle().setBounds(_rect);
        }
    public void setLocation(int x, int y)
        {
        get_Rectangle().setLocation(x, y);
        }
    public void set_Location(java.awt.Point _point)
        {
        get_Rectangle().setLocation(_point);
        }
    public void set_Size(int w, int h)
        {
        get_Rectangle().setSize(w, h);
        }
    public void translate(int x, int y)
        {
        get_Rectangle().translate(x, y);
        }
    public java.awt.Rectangle union(java.awt.Rectangle _rect)
        {
        return get_Rectangle().union(_rect);
        }
    //-- java.awt.Rectangle integration
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Dimension;
        // import Component.GUI.Point;
        

        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        setX     (config.getInt(sPrefix + ".X"     , getX()     ));
        setY     (config.getInt(sPrefix + ".Y"     , getY()     ));
        setHeight(config.getInt(sPrefix + ".Height", getHeight()));
        setWidth (config.getInt(sPrefix + ".Width" , getWidth ()));
        
        super.applyConfig(config, sPrefix);
        }
    
    // Declared at the super level
    protected Object clone()
            throws java.lang.CloneNotSupportedException
        {
        return instantiate(getX(), getY(), getWidth(), getHeight());
        }
    
    public boolean contains(Point point)
        {
        return contains(point.get_Point());
        }
    
    public boolean contains(Rectangle rect)
        {
        // Compensate for Bug Id 4191600
        return rect.isEmpty() ? contains(rect.getLocation()) : contains(rect.get_Rectangle());
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        return obj instanceof Rectangle ?
            get_Rectangle().equals(((Rectangle) obj).get_Rectangle()) :
            super.equals(obj);
        }
    
    // Accessor for the property "_Rectangle"
    public java.awt.Rectangle get_Rectangle()
        {
        java.awt.Rectangle _rect = __m__Rectangle;
        if (_rect == null)
            {
            _rect = new java.awt.Rectangle();
            set_Rectangle(_rect);
            }
        return _rect;
        }
    
    // Accessor for the property "Location"
    public Point getLocation()
        {
        return Point.instantiate(getX(), getY());
        }
    
    // Accessor for the property "Size"
    public Dimension getSize()
        {
        return Dimension.instantiate(getWidth(), getHeight());
        }
    
    public static Rectangle instantiate(int x, int y, int w, int h)
        {
        return instantiate(new java.awt.Rectangle(x, y, w, h));
        }
    
    public static Rectangle instantiate(java.awt.Rectangle _rect)
        {
        Rectangle rect = new Rectangle();
        rect.set_Rectangle(_rect);
        return rect;

        }
    
    public static Rectangle instantiate(Point ptLoc, Dimension dimSize)
        {
        return instantiate(new java.awt.Rectangle(
            ptLoc.getX(), ptLoc.getY(), dimSize.getWidth(), dimSize.getHeight()));
        }
    
    public Rectangle intersection(Rectangle rect)
        {
        return instantiate(intersection(rect.get_Rectangle()));
        }
    
    public boolean intersects(Rectangle rect)
        {
        return intersects(rect.get_Rectangle());
        }
    
    /**
    * Creates a new Rectangle component that have the specified points as
    * opposite corners and has non negative width and height.
    */
    public static Rectangle makeValidRectangle(Point pt1, Point pt2)
        {
        Rectangle rect = new Rectangle();
        
        int x1 = pt1.getX();
        int y1 = pt1.getY();
        int x2 = pt2.getX();
        int y2 = pt2.getY();
        
        if (x1 <= x2)
            {
            rect.setX(x1);
            rect.setWidth(x2 - x1);
            }
        else
            {
            rect.setX(x2);
            rect.setWidth(x1 - x2);
            }
        
        if (y1 <= y2)
            {
            rect.setY(y1);
            rect.setHeight(y2 - y1);
            }
        else
            {
            rect.setY(y2);
            rect.setHeight(y1 - y2);
            }
        
        return rect;
        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        config.putInt(sPrefix + ".X"     , getX()     );
        config.putInt(sPrefix + ".Y"     , getY()     );
        config.putInt(sPrefix + ".Height", getHeight());
        config.putInt(sPrefix + ".Width" , getWidth ());
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "_Rectangle"
    public void set_Rectangle(java.awt.Rectangle rect)
        {
        __m__Rectangle = rect;
        }
    
    // Accessor for the property "Location"
    public void setLocation(Point pLocation)
        {
        setX(pLocation.getX());
        setY(pLocation.getY());
        }
    
    // Accessor for the property "Size"
    public void setSize(Dimension pSize)
        {
        setWidth(pSize.getWidth());
        setHeight(pSize.getHeight());
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_Name() +
            "[x=" + getX() + ", y=" + getY() + ", width=" + getWidth() +
            ",height=" + getHeight() + ']';

        }
    
    public void translate(Point point)
        {
        translate(point.getX(), point.getY());
        }
    
    public Rectangle union(Rectangle rect)
        {
        return instantiate(union(rect.get_Rectangle()));
        }
    }
