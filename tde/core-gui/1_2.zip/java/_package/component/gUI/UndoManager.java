/* Class
*     _package.component.gUI.UndoManager
*/

package _package.component.gUI;

import javax.swing.undo.UndoManager;

/*
* Integrates
*     javax.swing.undo.UndoManager
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class UndoManager
        extends    _package.component.GUI
        implements javax.swing.event.UndoableEditListener
    {
    // Fields declarations
    
    /**
    * Property _UndoManager
    *
    */
    private transient javax.swing.undo.UndoManager __m__UndoManager;
    
    /**
    * Property Limit
    *
    * Specifies the maximum number of edits this UndoManager will hold. Default
    * value is 100.
    */
    private transient int __m_Limit;
    
    /**
    * Property PresentationName
    *
    */
    
    /**
    * Property Redoable
    *
    */
    
    /**
    * Property RedoPresentationName
    *
    */
    
    /**
    * Property Significant
    *
    */
    
    /**
    * Property Undoable
    *
    */
    
    /**
    * Property UndoPresentationName
    *
    */
    
    // Default constructor
    public UndoManager()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public UndoManager(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new UndoManager();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/UndoManager".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.undo.UndoManager integration
    // Access optimization
    // properties integration
    // methods integration
    public boolean isRedoable()
        {
        return get_UndoManager().canRedo();
        }
    public boolean isUndoable()
        {
        return get_UndoManager().canUndo();
        }
    public void discardAllEdits()
        {
        get_UndoManager().discardAllEdits();
        }
    public int getLimit()
        {
        return get_UndoManager().getLimit();
        }
    public String getPresentationName()
        {
        return get_UndoManager().getPresentationName();
        }
    public String getRedoPresentationName()
        {
        return get_UndoManager().getRedoPresentationName();
        }
    public String getUndoPresentationName()
        {
        return get_UndoManager().getUndoPresentationName();
        }
    public boolean isSignificant()
        {
        return get_UndoManager().isSignificant();
        }
    public void redo()
            throws javax.swing.undo.CannotRedoException
        {
        get_UndoManager().redo();
        }
    public void setLimit(int pLimit)
        {
        get_UndoManager().setLimit(pLimit);
        }
    public void undo()
            throws javax.swing.undo.CannotUndoException
        {
        get_UndoManager().undo();
        }
    //-- javax.swing.undo.UndoManager integration
    
    // Accessor for the property "_UndoManager"
    public javax.swing.undo.UndoManager get_UndoManager()
        {
        // import javax.swing.undo.UndoManager;
        
        UndoManager _mgr = __m__UndoManager;
        if (_mgr == null)
            {
            _mgr = new UndoManager();
            set_UndoManager(_mgr);
            }
        return _mgr;
        }
    
    // Accessor for the property "_UndoManager"
    public void set_UndoManager(javax.swing.undo.UndoManager p_UndoManager)
        {
        __m__UndoManager = p_UndoManager;
        }
    
    // From interface: javax.swing.event.UndoableEditListener
    public void undoableEditHappened(javax.swing.event.UndoableEditEvent e)
        {
        get_UndoManager().addEdit(e.getEdit());
        }
    }
