/* Class
*     _package.component.gUI.treeNode.SimpleNode
*/

package _package.component.gUI.treeNode;

/**
* SimpleNode is a TreeNode that represents a string stored in the  Name
* property.
*/
public class SimpleNode
        extends    _package.component.gUI.TreeNode
    {
    // Fields declarations
    
    /**
    * Property Name
    *
    * Specifies the name of this node. This value is used to draw this node.
    * 
    * @see #toString
    */
    private transient String __m_Name;
    
    /**
    * Property Reference
    *
    * Specifies an arbitrary object assosiated with this SimpleNode. This
    * property is analogous to the UserObject property for
    * DefaultMutableTreeNode.
    */
    private Object __m_Reference;
    
    // Default constructor
    public SimpleNode()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public SimpleNode(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAllowsChildren(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new SimpleNode();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/treeNode/SimpleNode".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof String)
            {
            String sNameThis = getName();
            String sNameThat = (String) obj;
        
            return sNameThis == null ?
                sNameThat == null : sNameThis.equals(sNameThat);
            }
        else if (obj instanceof SimpleNode)
            {
            SimpleNode that = (SimpleNode) obj;
            
            String sNameThis = this.getName();
            String sNameThat = that.getName();
            Object oRefThis  = this.getReference();
            Object oRefThat  = that.getReference();
        
            boolean fEqual = sNameThis == null ?
                sNameThat == null : sNameThis.equals(sNameThat);
            
            if (fEqual)
                {
                fEqual = oRefThis == null ?
                    oRefThat == null : oRefThis.equals(oRefThat);
                }
            return fEqual;
            }
        else
            {
            return false;
            }
        }
    
    // Accessor for the property "Name"
    public String getName()
        {
        return __m_Name;
        }
    
    // Accessor for the property "Reference"
    public Object getReference()
        {
        return __m_Reference;
        }
    
    public static SimpleNode instantiate(String sName, Object oRef)
        {
        SimpleNode node = new SimpleNode();
        
        node.setName(sName);
        node.setReference(oRef);
        
        return node;
        }
    
    // Declared at the super level
    public void setMutableNode(javax.swing.tree.DefaultMutableTreeNode pMutableNode)
        {
        super.setMutableNode(pMutableNode);
        
        if (pMutableNode != null)
            {
            setUserObject(this);
            }
        }
    
    // Accessor for the property "Name"
    public void setName(String pName)
        {
        __m_Name = pName;
        }
    
    // Accessor for the property "Reference"
    public void setReference(Object pReference)
        {
        __m_Reference = pReference;
        }
    
    // Declared at the super level
    public String toString()
        {
        return getName();
        }
    }
