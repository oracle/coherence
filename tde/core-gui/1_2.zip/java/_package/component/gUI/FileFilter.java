/* Class
*     _package.component.gUI.FileFilter
*/

package _package.component.gUI;

import _package.component.gUI.control.container.jComponent.JFileChooser;

/**
* This component integrates the javax.swing.filechooser.FIleFilter and is used
* by JFileChooser component. A FileFilter can be added to a JFileChooser to
* keep unwanted files from appearing in the directory listing.
*/
/*
* Integrates
*     javax.swing.filechooser.FileFilter
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*
* The integratee is an abstract class that the feed will implement.
* 
* @see javax.swing.filechooser.FileFilter
*
*/
public class FileFilter
        extends    _package.component.GUI
    {
    // Fields declarations
    
    /**
    * Property Active
    *
    * Specifies whether this filter is a currently active one.
    */
    private boolean __m_Active;
    
    /**
    * Property Description
    *
    */
    private String __m_Description;
    
    // fields used by the integration model:
    private sink_FileFilter __sink;
    private javax.swing.filechooser.FileFilter __feed;
    
    // Default constructor
    public FileFilter()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public FileFilter(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_FileFilter.__tloPeer.setObject(this);
            new jb_FileFilter(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new FileFilter();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/FileFilter".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.filechooser.FileFilter integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_FileFilter) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.filechooser.FileFilter) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    private boolean accept$Router(java.io.File file)
        {
        return __sink.accept(file);
        }
    /**
    * Specifies whether the given file is accepted by this filter. This method
    * is integration of the abstract method.
    * 
    * @see  javax.swing.filechooser.FileFilter
    */
    public boolean accept(java.io.File file)
        {
        return false;
        }
    private String get_Description$Router()
        {
        return __sink.getDescription();
        }
    /**
    * Returns the description of this filter. This method is integration of the
    * abstract method.
    * 
    * @see  javax.swing.filechooser.FileFilter
    */
    public String get_Description()
        {
        return getDescription();
        }
    //-- javax.swing.filechooser.FileFilter integration
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent.JFileChooser;
        
        
        

        }
    
    // Accessor for the property "Description"
    public String getDescription()
        {
        return __m_Description;
        }
    
    // Accessor for the property "Active"
    public boolean isActive()
        {
        Component parent = get_Parent();
        
        if (is_Constructed() && parent instanceof JFileChooser)
            {
            return ((JFileChooser) parent).getFileFilter() == this;
            }
        else
            {
            return __m_Active;
            }
        }
    
    // Accessor for the property "Active"
    public void setActive(boolean pActive)
        {
        Component parent = get_Parent();
        
        if (is_Constructed() && parent instanceof JFileChooser)
            {
            ((JFileChooser) parent).setFileFilter(this);
            }
        else
            {
            __m_Active = (pActive);
            }
        }
    
    // Accessor for the property "Description"
    public void setDescription(String pDescription)
        {
        __m_Description = pDescription;
        }
    }
