/* Class
*     _package.component.gUI.Timer
*/

package _package.component.gUI;

import com.tangosol.run.component.EventDeathException;
import javax.swing.Timer;

/**
* This component integrates the javax.swing.Timer object. This component is put
* into the GUI tree, because the main purpose of the Timer object is to invoke
* an Action event on the AWT thread after a specified time interval elapses.
*/
/*
* Integrates
*     javax.swing.Timer
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class Timer
        extends    _package.component.GUI
        implements java.awt.event.ActionListener
    {
    // Fields declarations
    
    /**
    * Property _Timer
    *
    */
    private transient javax.swing.Timer __m__Timer;
    
    /**
    * Property AutoStart
    *
    * Specifies whether the timer should start automatically at the
    * initialization time.
    * 
    * @see #onInit
    */
    private boolean __m_AutoStart;
    
    /**
    * Property Coalesce
    *
    * Specifies whether the Timer coalesces multiple pending ActionEvent
    * firings. A busy application may not be able to keep up with a Timer's
    * message generation, causing multiple <b>actionPerformed()</b> message
    * sends to be queued.  When processed, the application sends these messages
    * one after the other, causing the Timer's listeners to receive a sequence
    * of <b>actionPerformed()</b> messages with no delay between them.
    * Coalescing avoids this situation by reducing multiple pending messages to
    * a single message send.
    * Default value is true.
    */
    private transient boolean __m_Coalesce;
    
    /**
    * Property Delay
    *
    * Specifiess the Timer's delay, the number of milliseconds between
    * successive <b>onTimer()</b> event notifications.
    * 
    * @see #InitialDelay
    */
    private transient int __m_Delay;
    
    /**
    * Property InitialDelay
    *
    * Specifies the Timer's initial delay.  This will be used for the first
    * "ringing" of the Timer only.  Subsequent ringings will be spaced using
    * the delay property.
    * 
    * @see #Delay
    */
    private transient int __m_InitialDelay;
    
    /**
    * Property Repeats
    *
    * Specifies whether or not the Timer sends <b>actionPerformed()</b> (and
    * therefor onTimer event) to its listeners only once, and then stops.
    * Default value is true.
    */
    private transient boolean __m_Repeats;
    
    /**
    * Property Running
    *
    * (Calculated) Specifies whether the Timer is running.
    */
    
    // Default constructor
    public Timer()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Timer(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        addActionListener(this);
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Timer();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/Timer".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ ActionListener dispatcher
    private com.tangosol.util.Listeners __ActionListeners;
    private void addActionListener$Router(java.awt.event.ActionListener l)
        {
        get_Timer().addActionListener(l);
        }
    public void addActionListener(java.awt.event.ActionListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __ActionListeners;
        if (_listeners == null)
            {
            __ActionListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addActionListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeActionListener$Router(java.awt.event.ActionListener l)
        {
        get_Timer().removeActionListener(l);
        }
    public void removeActionListener(java.awt.event.ActionListener l)
        {
        com.tangosol.util.Listeners _listeners = __ActionListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeActionListener$Router(this);
            }
        }
    private void actionPerformed$Dispatch(java.awt.event.ActionEvent e)
        {
        java.util.EventListener[] targets = __ActionListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.ActionListener target = (java.awt.event.ActionListener) targets[i];
            if (target != this)
                {
                target.actionPerformed(e);
                }
            }
        }
    public void actionPerformed(java.awt.event.ActionEvent e)
        {
        // import com.tangosol.run.component.EventDeathException;
        
        try
            {
            onTimer();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        actionPerformed$Dispatch(e);
        }
    //-- ActionListener dispatcher
    
    //++ javax.swing.Timer integration
    // Access optimization
    // properties integration
    // methods integration
    public int getDelay()
        {
        return get_Timer().getDelay();
        }
    public int getInitialDelay()
        {
        return get_Timer().getInitialDelay();
        }
    public boolean isCoalesce()
        {
        return get_Timer().isCoalesce();
        }
    public boolean isRepeats()
        {
        return get_Timer().isRepeats();
        }
    public boolean isRunning()
        {
        return get_Timer().isRunning();
        }
    public void restart()
        {
        get_Timer().restart();
        }
    public void setCoalesce(boolean pCoalesce)
        {
        get_Timer().setCoalesce(pCoalesce);
        }
    public void setDelay(int pDelay)
        {
        get_Timer().setDelay(pDelay);
        }
    public void setInitialDelay(int pInitialDelay)
        {
        get_Timer().setInitialDelay(pInitialDelay);
        }
    public void setRepeats(boolean pRepeats)
        {
        get_Timer().setRepeats(pRepeats);
        }
    public void start()
        {
        get_Timer().start();
        }
    public void stop()
        {
        get_Timer().stop();
        }
    //-- javax.swing.Timer integration
    
    // Accessor for the property "_Timer"
    public javax.swing.Timer get_Timer()
        {
        // import javax.swing.Timer;
        
        Timer _timer = __m__Timer;
        if (_timer == null)
            {
            _timer = new Timer(0, null);
            set_Timer(_timer);
            }
        return _timer;
        }
    
    // Accessor for the property "AutoStart"
    public boolean isAutoStart()
        {
        return __m_AutoStart;
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        super.onInit();
        
        if (isAutoStart())
            {
            start();
            }
        }
    
    /**
    * Timer event notification.
    */
    public void onTimer()
        {
        }
    
    // Accessor for the property "_Timer"
    public void set_Timer(javax.swing.Timer p_Timer)
        {
        __m__Timer = p_Timer;
        }
    
    // Accessor for the property "AutoStart"
    public void setAutoStart(boolean pAutoStart)
        {
        __m_AutoStart = pAutoStart;
        }
    }
