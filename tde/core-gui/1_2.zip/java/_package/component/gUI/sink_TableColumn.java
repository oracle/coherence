/* Class
*      sink_TableColumn
*
* automatically generated "Sink" which
* represents a footprint of the class
*      javax.swing.table.TableColumn
* when used as a component callback by 
*      Component.GUI.TableColumn
*/

package _package.component.gUI;

public class sink_TableColumn
       extends com.tangosol.run.component.CallbackSink
    {
    private jb_TableColumn __peer;
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_TableColumn()
        {
        }
    
    // this (protected) constructor is used by the feed
    protected sink_TableColumn(jb_TableColumn feed)
        {
        super();
        __peer = feed;
        }
    
    // Retrieves the feed object for this sink
    public Object get_Feed()
        {
        return __peer;
        }
    
    // methods integrated and/or remoted
    public javax.swing.table.TableCellEditor getCellEditor()
        {
        return __peer.super$getCellEditor();
        }
    public javax.swing.table.TableCellRenderer getCellRenderer()
        {
        return __peer.super$getCellRenderer();
        }
    public javax.swing.table.TableCellRenderer getHeaderRenderer()
        {
        return __peer.super$getHeaderRenderer();
        }
    public Object getHeaderValue()
        {
        return __peer.super$getHeaderValue();
        }
    public Object getIdentifier()
        {
        return __peer.super$getIdentifier();
        }
    public int getMaxWidth()
        {
        return __peer.super$getMaxWidth();
        }
    public int getMinWidth()
        {
        return __peer.super$getMinWidth();
        }
    public int getModelIndex()
        {
        return __peer.super$getModelIndex();
        }
    public int getPreferredWidth()
        {
        return __peer.super$getPreferredWidth();
        }
    public int getWidth()
        {
        return __peer.super$getWidth();
        }
    public boolean getResizable()
        {
        return __peer.super$getResizable();
        }
    public void setCellEditor(javax.swing.table.TableCellEditor p_CellEditor)
        {
        __peer.super$setCellEditor(p_CellEditor);
        }
    public void setCellRenderer(javax.swing.table.TableCellRenderer p_CellRenderer)
        {
        __peer.super$setCellRenderer(p_CellRenderer);
        }
    public void setHeaderRenderer(javax.swing.table.TableCellRenderer p_HeaderRenderer)
        {
        __peer.super$setHeaderRenderer(p_HeaderRenderer);
        }
    public void setHeaderValue(Object pHeaderValue)
        {
        __peer.super$setHeaderValue(pHeaderValue);
        }
    public void setIdentifier(Object pIdentifier)
        {
        __peer.super$setIdentifier(pIdentifier);
        }
    public void setMaxWidth(int pMaxWidth)
        {
        __peer.super$setMaxWidth(pMaxWidth);
        }
    public void setMinWidth(int pMinWidth)
        {
        __peer.super$setMinWidth(pMinWidth);
        }
    public void setModelIndex(int pModelIndex)
        {
        __peer.super$setModelIndex(pModelIndex);
        }
    public void setPreferredWidth(int pPreferredWidth)
        {
        __peer.super$setPreferredWidth(pPreferredWidth);
        }
    public void setResizable(boolean pResizable)
        {
        __peer.super$setResizable(pResizable);
        }
    public void setWidth(int pWidth)
        {
        __peer.super$setWidth(pWidth);
        }
    public void sizeWidthToFit()
        {
        __peer.super$sizeWidthToFit();
        }
    }
