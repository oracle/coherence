/* Class
*      jb_TableColumn
*
* automatically generated "Feed" which
* a) extends an external bean:
*      javax.swing.table.TableColumn
* b) delegates to the peer component:
*      Component.GUI.TableColumn
*/

package _package.component.gUI;

public class jb_TableColumn
        extends    javax.swing.table.TableColumn
        implements com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected TableColumn __peer;
    
    private static TableColumn __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            TableColumn peer = (TableColumn)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // default (JavaBean) constructor
    public jb_TableColumn()
        {
        this(TableColumn.get_CLASS());
        }
    
    // parameterized constructor
    public jb_TableColumn(int Param_1)
        {
        this(Param_1, TableColumn.get_CLASS());
        }
    
    // parameterized constructor
    public jb_TableColumn(int Param_1, int Param_2)
        {
        this(Param_1, Param_2, TableColumn.get_CLASS());
        }
    
    // parameterized constructor
    public jb_TableColumn(int Param_1, int Param_2, javax.swing.table.TableCellRenderer Param_3, javax.swing.table.TableCellEditor Param_4)
        {
        this(Param_1, Param_2, Param_3, Param_4, TableColumn.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_TableColumn(Class clzPeer)
        {
        this(__createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_TableColumn(int Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_TableColumn(int Param_1, int Param_2, Class clzPeer)
        {
        this(Param_1, Param_2, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_TableColumn(int Param_1, int Param_2, javax.swing.table.TableCellRenderer Param_3, javax.swing.table.TableCellEditor Param_4, Class clzPeer)
        {
        this(Param_1, Param_2, Param_3, Param_4, __createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_TableColumn(TableColumn peer, boolean fInit)
        {
        super();
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_TableColumn(int Param_1, TableColumn peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_TableColumn(int Param_1, int Param_2, TableColumn peer, boolean fInit)
        {
        super(Param_1, Param_2);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_TableColumn(int Param_1, int Param_2, javax.swing.table.TableCellRenderer Param_3, javax.swing.table.TableCellEditor Param_4, TableColumn peer, boolean fInit)
        {
        super(Param_1, Param_2, Param_3, Param_4);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private TableColumn __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (TableColumn) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_TableColumn(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    public javax.swing.table.TableCellEditor getCellEditor()
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_CellEditor();
        }
    javax.swing.table.TableCellEditor super$getCellEditor()
        {
        return super.getCellEditor();
        }
    public javax.swing.table.TableCellRenderer getCellRenderer()
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_CellRenderer();
        }
    javax.swing.table.TableCellRenderer super$getCellRenderer()
        {
        return super.getCellRenderer();
        }
    public javax.swing.table.TableCellRenderer getHeaderRenderer()
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_HeaderRenderer();
        }
    javax.swing.table.TableCellRenderer super$getHeaderRenderer()
        {
        return super.getHeaderRenderer();
        }
    public Object getHeaderValue()
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getHeaderValue();
        }
    Object super$getHeaderValue()
        {
        return super.getHeaderValue();
        }
    public Object getIdentifier()
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getIdentifier();
        }
    Object super$getIdentifier()
        {
        return super.getIdentifier();
        }
    public int getMaxWidth()
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getMaxWidth();
        }
    int super$getMaxWidth()
        {
        return super.getMaxWidth();
        }
    public int getMinWidth()
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getMinWidth();
        }
    int super$getMinWidth()
        {
        return super.getMinWidth();
        }
    public int getModelIndex()
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getModelIndex();
        }
    int super$getModelIndex()
        {
        return super.getModelIndex();
        }
    public int getPreferredWidth()
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getPreferredWidth();
        }
    int super$getPreferredWidth()
        {
        return super.getPreferredWidth();
        }
    public int getWidth()
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getWidth();
        }
    int super$getWidth()
        {
        return super.getWidth();
        }
    public boolean getResizable()
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isResizable();
        }
    boolean super$getResizable()
        {
        return super.getResizable();
        }
    public void setCellEditor(javax.swing.table.TableCellEditor p_CellEditor)
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_CellEditor(p_CellEditor);
        }
    void super$setCellEditor(javax.swing.table.TableCellEditor p_CellEditor)
        {
        super.setCellEditor(p_CellEditor);
        }
    public void setCellRenderer(javax.swing.table.TableCellRenderer p_CellRenderer)
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_CellRenderer(p_CellRenderer);
        }
    void super$setCellRenderer(javax.swing.table.TableCellRenderer p_CellRenderer)
        {
        super.setCellRenderer(p_CellRenderer);
        }
    public void setHeaderRenderer(javax.swing.table.TableCellRenderer p_HeaderRenderer)
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_HeaderRenderer(p_HeaderRenderer);
        }
    void super$setHeaderRenderer(javax.swing.table.TableCellRenderer p_HeaderRenderer)
        {
        super.setHeaderRenderer(p_HeaderRenderer);
        }
    public void setHeaderValue(Object pHeaderValue)
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setHeaderValue(pHeaderValue);
        }
    void super$setHeaderValue(Object pHeaderValue)
        {
        super.setHeaderValue(pHeaderValue);
        }
    public void setIdentifier(Object pIdentifier)
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setIdentifier(pIdentifier);
        }
    void super$setIdentifier(Object pIdentifier)
        {
        super.setIdentifier(pIdentifier);
        }
    public void setMaxWidth(int pMaxWidth)
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setMaxWidth(pMaxWidth);
        }
    void super$setMaxWidth(int pMaxWidth)
        {
        super.setMaxWidth(pMaxWidth);
        }
    public void setMinWidth(int pMinWidth)
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setMinWidth(pMinWidth);
        }
    void super$setMinWidth(int pMinWidth)
        {
        super.setMinWidth(pMinWidth);
        }
    public void setModelIndex(int pModelIndex)
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setModelIndex(pModelIndex);
        }
    void super$setModelIndex(int pModelIndex)
        {
        super.setModelIndex(pModelIndex);
        }
    public void setPreferredWidth(int pPreferredWidth)
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setPreferredWidth(pPreferredWidth);
        }
    void super$setPreferredWidth(int pPreferredWidth)
        {
        super.setPreferredWidth(pPreferredWidth);
        }
    public void setResizable(boolean pResizable)
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setResizable(pResizable);
        }
    void super$setResizable(boolean pResizable)
        {
        super.setResizable(pResizable);
        }
    public void setWidth(int pWidth)
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setWidth(pWidth);
        }
    void super$setWidth(int pWidth)
        {
        super.setWidth(pWidth);
        }
    public void sizeWidthToFit()
        {
        TableColumn peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.sizeWidthToFit();
        }
    void super$sizeWidthToFit()
        {
        super.sizeWidthToFit();
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
