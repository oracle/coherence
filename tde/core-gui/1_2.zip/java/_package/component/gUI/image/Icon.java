/* Class
*     _package.component.gUI.image.Icon
*/

package _package.component.gUI.image;

import java.awt.Image; // as _Image
import javax.swing.ImageIcon; // as _ImageIcon

/*
* Integrates
*     javax.swing.ImageIcon
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class Icon
        extends    _package.component.gUI.Image
        implements javax.swing.Icon
    {
    // Fields declarations
    
    /**
    * Property _Icon
    *
    */
    private transient javax.swing.ImageIcon __m__Icon;
    
    /**
    * Property Description
    *
    */
    private transient String __m_Description;
    
    /**
    * Property IconHeight
    *
    */
    
    /**
    * Property IconWidth
    *
    */
    
    // Default constructor
    public Icon()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Icon(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Icon();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/image/Icon".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.ImageIcon integration
    // Access optimization
    // properties integration
    // methods integration
    public String getDescription()
        {
        return get_Icon().getDescription();
        }
    public int getIconHeight()
        {
        return get_Icon().getIconHeight();
        }
    public int getIconWidth()
        {
        return get_Icon().getIconWidth();
        }
    public int getImageLoadStatus()
        {
        return get_Icon().getImageLoadStatus();
        }
    private void paintIcon$Router(java.awt.Component comp, java.awt.Graphics g, int x, int y)
        {
        get_Icon().paintIcon(comp, g, x, y);
        }
    public void paintIcon(java.awt.Component comp, java.awt.Graphics g, int x, int y)
        {
        if (get_Icon().getImage() != null)
            {
            paintIcon$Router(comp, g, x, y);
            }
        }
    public void setDescription(String pDescription)
        {
        get_Icon().setDescription(pDescription);
        }
    //-- javax.swing.ImageIcon integration
    
    // Accessor for the property "_Icon"
    public javax.swing.ImageIcon get_Icon()
        {
        // import javax.swing.ImageIcon as _ImageIcon;
        // import java.awt.Image        as _Image;
        
        _ImageIcon _icon = __m__Icon;
        if (_icon == null)
            {
            _icon = new _ImageIcon();
            _icon.setImageObserver(this);
        
            _Image _image = get_Image();
            if (_image != null)
                {
                _icon.setImage(_image);
                }
            set_Icon(_icon);
            }
        return _icon;
        }
    
    // Accessor for the property "_Icon"
    public void set_Icon(javax.swing.ImageIcon p_Icon)
        {
        __m__Icon = p_Icon;
        }
    
    // Declared at the super level
    public String toString()
        {
        return "Icon " + get_Name() +
            "[url=" + getImageURL() + ", path=" + getImagePath() + ", img=" + get_Image() + ", icon=" + get_Icon() + "]";
        }
    }
