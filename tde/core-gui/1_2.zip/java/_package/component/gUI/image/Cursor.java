/* Class
*     _package.component.gUI.image.Cursor
*/

package _package.component.gUI.image;

public class Cursor
        extends    _package.component.gUI.Image
    {
    // Fields declarations
    
    /**
    * Property _Cursor
    *
    */
    private java.awt.Cursor __m__Cursor;
    
    /**
    * Property HotSpot
    *
    * HotSpot for a custom cursor
    */
    private _package.component.gUI.Point __m_HotSpot;
    
    /**
    * Property Type
    *
    * Type of the cursor. Allowed values are in a range from 0 to 13
    * 
    * DEFAULT_CURSOR = 0
    * CROSSHAIR_CURSOR = 1
    * TEXT_CURSOR = 2
    * WAIT_CURSOR = 3
    * SW_RESIZE_CURSOR = 4
    * SE_RESIZE_CURSOR = 5
    * NW_RESIZE_CURSOR = 6
    * NE_RESIZE_CURSOR = 7
    * N_RESIZE_CURSOR = 8
    * S_RESIZE_CURSOR = 9
    * W_RESIZE_CURSOR = 10
    * E_RESIZE_CURSOR = 11
    * HAND_CURSOR = 12
    * MOVE_CURSOR = 13
    * 
    * Value -1 is used for custom cursors
    * 
    * @see java.awt.Cursor
    */
    private int __m_Type;
    
    // Default constructor
    public Cursor()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Cursor(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Cursor();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/image/Cursor".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "_Cursor"
    public java.awt.Cursor get_Cursor()
        {
        java.awt.Cursor _cursor = __m__Cursor;
        if (_cursor == null)
            {
            int iType = getType();
            if (iType >= 0)
                {
                _cursor = new java.awt.Cursor(iType);
                }
            else
                {
                _cursor = java.awt.Toolkit.getDefaultToolkit().
                    createCustomCursor(get_Image(), getHotSpot().get_Point(), get_Name());
                }
            set_Cursor(_cursor);
            }
        return _cursor;
        }
    
    // Accessor for the property "HotSpot"
    public _package.component.gUI.Point getHotSpot()
        {
        return __m_HotSpot;
        }
    
    // Accessor for the property "Type"
    public int getType()
        {
        return __m_Type;
        }
    
    public static Cursor instantiate(java.awt.Cursor _cursor)
        {
        Cursor cursor = new Cursor();
        cursor.set_Cursor(_cursor);
        return cursor;

        }
    
    // Accessor for the property "_Cursor"
    public void set_Cursor(java.awt.Cursor p_Cursor)
        {
        __m__Cursor = p_Cursor;
        }
    
    // Accessor for the property "HotSpot"
    public void setHotSpot(_package.component.gUI.Point pHotSpot)
        {
        __m_HotSpot = (pHotSpot);
        
        if (getType() < 0)
            {
            set_Cursor(null);
            }
        }
    
    // Accessor for the property "Type"
    public void setType(int pType)
        {
        if (pType != getType())
            {
            __m_Type = (pType);
            set_Cursor(null);
            }
        }
    }
