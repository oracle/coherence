/* Class
*     _package.component.gUI.color.Blue
*/

package _package.component.gUI.color;

public final class Blue
        extends    _package.component.gUI.Color
    {
    // Fields declarations
    
    // Default constructor
    public Blue()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Blue(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Blue();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/color/Blue".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Getter for property _Color.<p>
    */
    public java.awt.Color get_Color()
        {
        return java.awt.Color.blue;
        }
    
    // Declared at the super level
    /**
    * Getter for property RGB.<p>
    */
    public int getRGB()
        {
        return get_Color().getRGB();
        }
    
    // Declared at the super level
    /**
    * Setter for property RGB.<p>
    */
    public void setRGB(int pRGB)
        {
        throw new UnsupportedOperationException();
        }
    }
