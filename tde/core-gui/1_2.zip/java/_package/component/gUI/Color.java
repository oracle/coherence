/* Class
*     _package.component.gUI.Color
*/

package _package.component.gUI;

import _package.component.gUI.Color;

/*
* Integrates
*     java.awt.Color
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class Color
        extends    _package.component.GUI
    {
    // Fields declarations
    
    /**
    * Property _Color
    *
    */
    private java.awt.Color __m__Color;
    
    /**
    * Property black
    *
    */
    protected static final java.awt.Color black;
    
    /**
    * Property cyan
    *
    */
    protected static final java.awt.Color cyan;
    
    /**
    * Property darkGray
    *
    */
    protected static final java.awt.Color darkGray;
    
    /**
    * Property gray
    *
    */
    protected static final java.awt.Color gray;
    
    /**
    * Property lightGray
    *
    */
    protected static final java.awt.Color lightGray;
    
    /**
    * Property magenta
    *
    */
    protected static final java.awt.Color magenta;
    
    /**
    * Property orange
    *
    */
    protected static final java.awt.Color orange;
    
    /**
    * Property pink
    *
    */
    protected static final java.awt.Color pink;
    
    /**
    * Property RGB
    *
    */
    private int __m_RGB;
    
    /**
    * Property white
    *
    */
    protected static final java.awt.Color white;
    
    /**
    * Property yellow
    *
    */
    protected static final java.awt.Color yellow;
    
    // Static initializer
    static
        {
        try
            {
            black = java.awt.Color.black;
            cyan = java.awt.Color.cyan;
            darkGray = java.awt.Color.darkGray;
            gray = java.awt.Color.gray;
            lightGray = java.awt.Color.lightGray;
            magenta = java.awt.Color.magenta;
            orange = java.awt.Color.orange;
            pink = java.awt.Color.pink;
            white = java.awt.Color.white;
            yellow = java.awt.Color.yellow;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public Color()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Color(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Color();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/Color".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.Color integration
    // Access optimization
    // properties integration
    // methods integration
    public int getAlpha()
        {
        return get_Color().getAlpha();
        }
    public int getBlue()
        {
        return get_Color().getBlue();
        }
    public int getGreen()
        {
        return get_Color().getGreen();
        }
    public int getRed()
        {
        return get_Color().getRed();
        }
    public int getTransparency()
        {
        return get_Color().getTransparency();
        }
    //-- java.awt.Color integration
    
    public Color darker()
        {
        // import Component.GUI.Color;
        Color c = new Color();
        c.set_Color(get_Color().darker());
        return c;
        }
    
    // Accessor for the property "_Color"
    public java.awt.Color get_Color()
        {
        java.awt.Color _color = __m__Color;
        if (_color == null)
            {
            _color = new java.awt.Color(getRGB());
            set_Color(_color);
            }
        return _color;

        }
    
    // Accessor for the property "RGB"
    public int getRGB()
        {
        return __m_RGB;
        }
    
    // Accessor for the property "_Color"
    public void set_Color(java.awt.Color p_Color)
        {
        if (p_Color != null)
            {
            setRGB(p_Color.getRGB());
            }
        __m__Color = (p_Color);
        }
    
    // Accessor for the property "RGB"
    public void setRGB(int pRGB)
        {
        set_Color(null); // invalidate
        __m_RGB = (pRGB);
        }
    
    // Declared at the super level
    public String toString()
        {
        return "Color " + get_Name() + " (" + get_Color().toString() + ')';
        }
    }
