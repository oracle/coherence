/* Class
*     _package.component.gUI.fileFilter.ExtensionFileFilter
*/

package _package.component.gUI.fileFilter;

import javax.swing.UIManager;

/**
* 
* +++++++++++++++++++++++++++++++++++++++
* 
* The ExtensionFIleFilter is a convenience implementation of FileFilter that
* filters out all files except for those type extensions that it knows about. 
* The default implementation is "AcceptAllFilesFIlter".
* 
* @see javax.swing.plaf.basic.BasicFIleChooser
* 
* TODO: the code here is copied from
* demo.jfc.FileChooserDemo.ExampleFileFilter. Sun promised to move this
* implementation to the swing set. When it's done we should just integrate it
* instead.
*/
public class ExtensionFileFilter
        extends    _package.component.gUI.FileFilter
    {
    // Fields declarations
    
    /**
    * Property ExtensionListInDescription
    *
    * Specifies whether the extension list (.jpg, .gif, etc) should show up in
    * the human readable description.
    */
    private boolean __m_ExtensionListInDescription;
    
    /**
    * Property Extensions
    *
    * Specifies an array of file types that this file filter will accept.
    * 
    * Note that the "." before the extension is not needed.
    */
    private String[] __m_Extensions;
    
    // Default constructor
    public ExtensionFileFilter()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ExtensionFileFilter(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setExtensionListInDescription(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ExtensionFileFilter();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/fileFilter/ExtensionFileFilter".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Specifies whether the given file is accepted by this filter. This method
    * is integration of the abstract method.
    * 
    * @see  javax.swing.filechooser.FileFilter
    */
    public boolean accept(java.io.File file)
        {
        if (file == null)
            {
            return false;
            }
        
        String[] asExt = getExtensions();
        if (asExt == null || file.isDirectory())
            {
            return true;
            }
        else
            {
            String sExt  = null;
            String sName = file.getName();
            int    of    = sName.lastIndexOf('.');
            if (of > 0 && of < sName.length() - 1)
                {
                sExt = sName.substring(of + 1);
                }
        
            if (sExt != null)
                {
                for (int i = 0; i < asExt.length; i++)
                    {
                    if (asExt[i].equalsIgnoreCase(sExt))
                        {
                        return true;
                        }
                    }
                }
            return false;
            }
        }
    
    // Declared at the super level
    public String getDescription()
        {
        // import javax.swing.UIManager;
        
        String sDescr = super.getDescription();
        
        if (sDescr == null)
            {
            if (getExtensions() == null)
                {
                sDescr = UIManager.getString("FileChooser.acceptAllFileFilterText");
                }
            else
                {
                sDescr = makeExtensionList();
                }
            }
        else
            {
            if (isExtensionListInDescription())
                {
                sDescr += " " + makeExtensionList();
                }
            }
        
        return sDescr;
        }
    
    // Accessor for the property "Extensions"
    public String[] getExtensions()
        {
        return __m_Extensions;
        }
    
    // Accessor for the property "Extensions"
    public String getExtensions(int pIndex)
        {
        return getExtensions()[pIndex];
        }
    
    // Accessor for the property "ExtensionListInDescription"
    public boolean isExtensionListInDescription()
        {
        return __m_ExtensionListInDescription;
        }
    
    protected String makeExtensionList()
        {
        String[] asExt = getExtensions();
        
        if (asExt == null)
            {
            return "";
            }
        else
            {
            StringBuffer sbList = new StringBuffer("(");
        
            for (int i = 0; i < asExt.length; i++)
                {
                if (i > 0)
                    {
                    sbList.append(", ");
                    }
                sbList.append("*.")
                      .append(asExt[i]);
                }
        
            sbList.append(")");
            return sbList.toString();
            }
        }
    
    // Accessor for the property "ExtensionListInDescription"
    public void setExtensionListInDescription(boolean pExtensionListInDescription)
        {
        __m_ExtensionListInDescription = pExtensionListInDescription;
        }
    
    // Accessor for the property "Extensions"
    public void setExtensions(String[] pExtensions)
        {
        __m_Extensions = pExtensions;
        }
    
    // Accessor for the property "Extensions"
    public void setExtensions(int pIndex, String pExtensions)
        {
        getExtensions()[pIndex] = pExtensions;
        }
    }
