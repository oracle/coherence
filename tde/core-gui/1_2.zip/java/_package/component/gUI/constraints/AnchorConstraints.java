/* Class
*     _package.component.gUI.constraints.AnchorConstraints
*/

package _package.component.gUI.constraints;

/**
* AnchorConstarints component specifies the constraints for components that are
* laid out using the <code>AnchorLayout</code> layout manager.
* 
* @see Component.GUI.LayoutManager.AnchorLayout
*/
public class AnchorConstraints
        extends    _package.component.gUI.Constraints
    {
    // Fields declarations
    
    /**
    * Property ANCHOR_BOTTOM
    *
    */
    public static final int ANCHOR_BOTTOM = 8;
    
    /**
    * Property ANCHOR_LEFT
    *
    */
    public static final int ANCHOR_LEFT = 1;
    
    /**
    * Property ANCHOR_NONE
    *
    */
    public static final int ANCHOR_NONE = 0;
    
    /**
    * Property ANCHOR_RIGHT
    *
    */
    public static final int ANCHOR_RIGHT = 4;
    
    /**
    * Property ANCHOR_TOP
    *
    */
    public static final int ANCHOR_TOP = 2;
    
    /**
    * Property AnchorBottom
    *
    * If the AnchorPolicy includes ANCHOR_TOP, this value specifies the
    * distance from the Bottom side of the component to the Bottom side of the
    * container.
    */
    private int __m_AnchorBottom;
    
    /**
    * Property AnchorLeft
    *
    * If the AnchorPolicy includes ANCHOR_LEFT, this value specifies the
    * distance from the Left side of the component to the Right side of the
    * container.
    */
    private int __m_AnchorLeft;
    
    /**
    * Property AnchorPolicy
    *
    * Specifies the anchoring policy. The value of this property is a bitwise
    * concatenation of any of the values:
    * 
    * ANCHOR_NONE (0x0), ANCHOR_LEFT(0x1), ANCHOR_TOP(0x2), ANCHOR_RIGHT(0x4),
    * ANCHOR_BOTTOM(0x8)
    * 
    * The actions for the policy values are:
    * 
    * ANCHOR_NONE: does nothing
    * ANCHOR_LEFT: moves the child component in such a way that the distance
    * from the Left side of the component to the Right side of the container
    * stays constant
    * ANCHOR_TOP: moves the child component in such a way that the distance
    * from the Top side of the component to the Bottom side of the container
    * stays constant
    * ANCHOR_RIGHT: resizes the child component in such a way that the distance
    * from the Right side of the component to the Right side of the container
    * stays constant
    * ANCHOR_BOTTOM: moves the child component in such a way that the distance
    * from the Bottom side of the component to the Bottom side of the container
    * stays constant
    * 
    * @see Component.GUI.LayoutManager.AnchorLayout
    */
    private int __m_AnchorPolicy;
    
    /**
    * Property AnchorRight
    *
    * If the AnchorPolicy includes ANCHOR_RIGHT, this value specifies the
    * distance from the Right side of the component to the Right side of the
    * container.
    */
    private int __m_AnchorRight;
    
    /**
    * Property AnchorTop
    *
    * If the AnchorPolicy includes ANCHOR_TOP, this value specifies the
    * distance from the Top side of the component to the Bottom side of the
    * container.
    */
    private int __m_AnchorTop;
    
    // Default constructor
    public AnchorConstraints()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public AnchorConstraints(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new AnchorConstraints();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/constraints/AnchorConstraints".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (!(obj instanceof AnchorConstraints))
            {
            return false;
            }
            
        AnchorConstraints that = (AnchorConstraints) obj;
        return this.getAnchorPolicy() == that.getAnchorPolicy();
        /* &&
               this.getAnchorLeft()   == that.getAnchorLeft()   &&
               this.getAnchorRight()  == that.getAnchorRight()  &&
               this.getAnchorTop()    == that.getAnchorTop()    &&
               this.getAnchorBottom() == that.getAnchorBottom();
        */
        }
    
    // Declared at the super level
    public Object get_Constraints()
        {
        return this;
        }
    
    // Accessor for the property "AnchorBottom"
    public int getAnchorBottom()
        {
        return __m_AnchorBottom;
        }
    
    // Accessor for the property "AnchorLeft"
    public int getAnchorLeft()
        {
        return __m_AnchorLeft;
        }
    
    // Accessor for the property "AnchorPolicy"
    public int getAnchorPolicy()
        {
        return __m_AnchorPolicy;
        }
    
    // Accessor for the property "AnchorRight"
    public int getAnchorRight()
        {
        return __m_AnchorRight;
        }
    
    // Accessor for the property "AnchorTop"
    public int getAnchorTop()
        {
        return __m_AnchorTop;
        }
    
    // Declared at the super level
    public void set_Constraints(Object p_Constraints)
        {
        throw new UnsupportedOperationException();
        }
    
    // Accessor for the property "AnchorBottom"
    public void setAnchorBottom(int pAnchorBottom)
        {
        __m_AnchorBottom = pAnchorBottom;
        }
    
    // Accessor for the property "AnchorLeft"
    public void setAnchorLeft(int pAnchorLeft)
        {
        __m_AnchorLeft = pAnchorLeft;
        }
    
    // Accessor for the property "AnchorPolicy"
    public void setAnchorPolicy(int pAnchorPolicy)
        {
        __m_AnchorPolicy = pAnchorPolicy;
        }
    
    // Accessor for the property "AnchorRight"
    public void setAnchorRight(int pAnchorRight)
        {
        __m_AnchorRight = pAnchorRight;
        }
    
    // Accessor for the property "AnchorTop"
    public void setAnchorTop(int pAnchorTop)
        {
        __m_AnchorTop = pAnchorTop;
        }
    
    // Declared at the super level
    public String toString()
        {
        StringBuffer sb = new StringBuffer("AnchorConstraints [");
        
        int iPolicy = getAnchorPolicy();
        
        if (iPolicy == ANCHOR_NONE)
            {
            sb.append("none ");
            }
        else
            {
            if ((iPolicy & ANCHOR_LEFT) != 0)
                {
                sb.append("left=" + getAnchorLeft() + ",");
                }
            if ((iPolicy & ANCHOR_TOP) != 0)
                {
                sb.append("top=" + getAnchorTop() + ",");
                }
            if ((iPolicy & ANCHOR_RIGHT) != 0)
                {
                sb.append("right=" + getAnchorRight() + ",");
                }
            if ((iPolicy & ANCHOR_BOTTOM) != 0)
                {
                sb.append("bottom=" + getAnchorBottom() + ",");
                }
            }
        sb.setCharAt(sb.length() - 1, ']');
        return sb.toString();

        }
    }
