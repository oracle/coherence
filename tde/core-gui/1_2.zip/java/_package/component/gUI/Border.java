/* Class
*     _package.component.gUI.Border
*/

package _package.component.gUI;

import javax.swing.border.Border; // as _Border

/*
* Integrates
*     javax.swing.border.Border
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class Border
        extends    _package.component.GUI
    {
    // Fields declarations
    
    /**
    * Property _Border
    *
    */
    private javax.swing.border.Border __m__Border;
    
    // Default constructor
    public Border()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Border(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Border();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/Border".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.border.Border integration
    // Access optimization
    // properties integration
    // methods integration
    public boolean isBorderOpaque()
        {
        return get_Border().isBorderOpaque();
        }
    //-- javax.swing.border.Border integration
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        // import javax.swing.border.Border as _Border;
        
        _Border _borderThis = get_Border();
        _Border _borderThat = obj != null ? ((Border) obj).get_Border() : null;
        
        return _borderThis == null ? _borderThat == null : _borderThis.equals(_borderThat);
        }
    
    // Accessor for the property "_Border"
    public javax.swing.border.Border get_Border()
        {
        return (javax.swing.border.Border) get_Sink();
        }
    
    // Accessor for the property "_Border"
    public void set_Border(javax.swing.border.Border p_Border)
        {
        set_Sink(p_Border);
        }
    }
