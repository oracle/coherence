/* Class
*     _package.component.gUI.LayoutManager
*/

package _package.component.gUI;

import java.awt.Dimension;
import java.awt.LayoutManager2; // as _LayoutManager2
import java.awt.LayoutManager; // as _LayoutManager

/**
* LayoutManager is either wrapper or implementor for the java.awt.LayoutManager
* or java.awt.LayoutManager2 interfaces.
*/
public class LayoutManager
        extends    _package.component.GUI
        implements java.awt.LayoutManager,
                   java.awt.LayoutManager2
    {
    // Fields declarations
    
    /**
    * Property _Layout
    *
    */
    private java.awt.LayoutManager __m__Layout;
    
    // Default constructor
    public LayoutManager()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public LayoutManager(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new LayoutManager();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/LayoutManager".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import java.awt.LayoutManager  as _LayoutManager;
        // import java.awt.LayoutManager2 as _LayoutManager2;
        

        }
    
    // From interface: java.awt.LayoutManager2
    /**
    * Adds the specified component to the layout, using the specified
    * constraint object.
    */
    public void addLayoutComponent(java.awt.Component _comp, Object _constraints)
        {
        _LayoutManager _mgr = get_Layout();
        
        if (_mgr instanceof _LayoutManager2)
            {
            ((_LayoutManager2) _mgr).addLayoutComponent(_comp, _constraints);
            }
        }
    
    // From interface: java.awt.LayoutManager
    // From interface: java.awt.LayoutManager2
    /**
    * @deprecated  replaced by <code>addLayoutComponent(java.awt.Component,
    * Object)</code>
    */
    public void addLayoutComponent(String name, java.awt.Component _comp)
        {
        _LayoutManager _mgr = get_Layout();
        
        if (_mgr != null)
            {
            _mgr.addLayoutComponent(name, _comp);
            }
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        // import java.awt.LayoutManager as _LayoutManager;
        
        _LayoutManager _layoutThis = get_Layout();
        _LayoutManager _layoutThat = obj != null ? ((LayoutManager) obj).get_Layout() : null;
        
        return _layoutThis == null ? _layoutThat == null : _layoutThis.equals(_layoutThat);
        }
    
    // Accessor for the property "_Layout"
    public java.awt.LayoutManager get_Layout()
        {
        return __m__Layout;
        }
    
    // From interface: java.awt.LayoutManager2
    public float getLayoutAlignmentX(java.awt.Container _parent)
        {
        _LayoutManager _mgr = get_Layout();
        
        return _mgr instanceof _LayoutManager2 ?
            ((_LayoutManager2) _mgr).getLayoutAlignmentX(_parent) :
            0.0f;
        }
    
    // From interface: java.awt.LayoutManager2
    public float getLayoutAlignmentY(java.awt.Container _parent)
        {
        _LayoutManager _mgr = get_Layout();
        
        return _mgr instanceof _LayoutManager2 ?
            ((_LayoutManager2) _mgr).getLayoutAlignmentY(_parent) :
            0.0f;
        }
    
    // From interface: java.awt.LayoutManager2
    public void invalidateLayout(java.awt.Container _parent)
        {
        _LayoutManager _mgr = get_Layout();
        
        if (_mgr instanceof _LayoutManager2)
            {
            ((_LayoutManager2) _mgr).invalidateLayout(_parent);
            }
        }
    
    // From interface: java.awt.LayoutManager
    // From interface: java.awt.LayoutManager2
    /**
    * Lays out the container in the specified container.
    * 
    * @param _parent the container which needs to be laid out.
    */
    public void layoutContainer(java.awt.Container _parent)
        {
        _LayoutManager _mgr = get_Layout();
        
        if (_mgr != null)
            {
            _mgr.layoutContainer(_parent);
            }
        }
    
    // From interface: java.awt.LayoutManager2
    public java.awt.Dimension maximumLayoutSize(java.awt.Container _parent)
        {
        // import java.awt.Dimension;
        
        _LayoutManager _mgr = get_Layout();
        
        return _mgr instanceof _LayoutManager2 ?
            ((_LayoutManager2) _mgr).maximumLayoutSize(_parent) :
            new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE);
        }
    
    // From interface: java.awt.LayoutManager
    // From interface: java.awt.LayoutManager2
    public java.awt.Dimension minimumLayoutSize(java.awt.Container _parent)
        {
        // import java.awt.Dimension;
        
        _LayoutManager _mgr = get_Layout();
        
        return _mgr != null ?
            _mgr.minimumLayoutSize(_parent) : new Dimension(0, 0);
        }
    
    // From interface: java.awt.LayoutManager
    // From interface: java.awt.LayoutManager2
    /**
    * Calculates the preferred size dimensions for the specified container
    * given the components in the specified parent container.
    * 
    * @param _parent the component to be laid out
    */
    public java.awt.Dimension preferredLayoutSize(java.awt.Container _parent)
        {
        // import java.awt.Dimension;
        
        _LayoutManager _mgr = get_Layout();
        
        return _mgr != null ?
            _mgr.preferredLayoutSize(_parent) : new Dimension(0, 0);
        }
    
    // From interface: java.awt.LayoutManager
    // From interface: java.awt.LayoutManager2
    /**
    * Removes the specified component from the layout.
    * 
    * @param _comp the component to be removed
    */
    public void removeLayoutComponent(java.awt.Component _comp)
        {
        _LayoutManager _mgr = get_Layout();
        
        if (_mgr != null)
            {
            _mgr.removeLayoutComponent(_comp);
            }
        }
    
    // Accessor for the property "_Layout"
    public void set_Layout(java.awt.LayoutManager p_Layout)
        {
        __m__Layout = p_Layout;
        }
    }
