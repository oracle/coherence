/* Class
*     _package.component.gUI.Dimension
*/

package _package.component.gUI;

/*
* Integrates
*     java.awt.Dimension
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class Dimension
        extends    _package.component.GUI
    {
    // Fields declarations
    
    /**
    * Property _Dimension
    *
    */
    private java.awt.Dimension __m__Dimension;
    
    /**
    * Property Height
    *
    */
    
    /**
    * Property Width
    *
    */
    
    // Default constructor
    public Dimension()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Dimension(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Dimension();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/Dimension".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.Dimension integration
    // Access optimization
    // properties integration
    public int getHeight()
        {
        return get_Dimension().height;
        }
    public void setHeight(int pHeight)
        {
        get_Dimension().height = pHeight;
        }
    public int getWidth()
        {
        return get_Dimension().width;
        }
    public void setWidth(int pWidth)
        {
        get_Dimension().width = pWidth;
        }
    // methods integration
    public void setSize(double dWidth, double dHeight)
        {
        get_Dimension().setSize(dWidth, dHeight);
        }
    public void setSize(int iWidth, int iHeight)
        {
        get_Dimension().setSize(iWidth, iHeight);
        }
    //-- java.awt.Dimension integration
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        setHeight(config.getInt(sPrefix + ".Height", getHeight()));
        setWidth (config.getInt(sPrefix + ".Width" , getWidth ()));
        
        super.applyConfig(config, sPrefix);
        }
    
    // Declared at the super level
    public Object clone()
            throws java.lang.CloneNotSupportedException
        {
        return instantiate(getWidth(), getHeight());
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        return obj instanceof Dimension ?
            get_Dimension().equals(((Dimension) obj).get_Dimension()) :
            super.equals(obj);
        }
    
    // Accessor for the property "_Dimension"
    public java.awt.Dimension get_Dimension()
        {
        java.awt.Dimension dim = (java.awt.Dimension) get_Sink();
        if (dim == null)
            {
            dim = new java.awt.Dimension();
            set_Dimension(dim);
            }
        return dim;
        }
    
    /**
    * Resizes the Dimension according to the specified values.
    */
    public void grow(int iWidth, int iHeight)
        {
        setSize(getWidth() + iWidth, getHeight() + iHeight);
        }
    
    /**
    * Resizes the Dimension according to the specified Dimension.
    */
    public void grow(Dimension dim)
        {
        grow(dim.getWidth(), dim.getHeight());
        }
    
    /**
    * Resizes the Dimension according to the specified vector.
    */
    public void grow(Point ptVector)
        {
        grow(ptVector.getX(), ptVector.getY());
        }
    
    public static Dimension instantiate(int w, int h)
        {
        return instantiate(new java.awt.Dimension(w, h));
        }
    
    public static Dimension instantiate(java.awt.Dimension _dim)
        {
        Dimension dim = new Dimension();
        dim.set_Dimension(_dim);
        return dim;

        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        config.putInt(sPrefix + ".Height", getHeight());
        config.putInt(sPrefix + ".Width" , getWidth ());
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "_Dimension"
    public void set_Dimension(java.awt.Dimension p_Dimension)
        {
        set_Sink(p_Dimension);

        }
    
    // Declared at the super level
    public String toString()
        {
        return get_Name() + " [Width=" + getWidth() + ", Height=" + getHeight() + ']';
        }
    }
