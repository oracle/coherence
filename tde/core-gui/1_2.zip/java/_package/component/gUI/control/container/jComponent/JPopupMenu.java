/* Class
*     _package.component.gUI.control.container.jComponent.JPopupMenu
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.application.GUI;
import _package.component.gUI.Control;
import _package.component.gUI.Dimension;
import _package.component.gUI.Point;
import _package.component.gUI.control.container.JComponent;
import com.tangosol.run.component.EventDeathException;
import java.awt.Component; // as _Control
import java.awt.Event;
import java.awt.event.KeyEvent;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu; // as _JPopupMenu
import javax.swing.MenuElement;
import javax.swing.MenuSelectionManager;

/*
* Integrates
*     javax.swing.JPopupMenu
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JPopupMenu
        extends    _package.component.gUI.control.container.JComponent
        implements javax.swing.event.PopupMenuListener
    {
    // Fields declarations
    
    /**
    * Property _Invoker
    *
    */
    private transient java.awt.Component __m__Invoker;
    
    /**
    * Property _OrigFocusOwner
    *
    * Privately used property holding the "previously focused" component.
    * 
    * @see setVisible
    */
    private transient java.awt.Component __m__OrigFocusOwner;
    
    /**
    * Property AutoTrigger
    *
    * If this property is set to true, the popup menu will listen to the
    * invoker's mousePressed event and pop itself up appropriately.
    * 
    * @see #setInvoker
    */
    private boolean __m_AutoTrigger;
    
    /**
    * Property BorderPainted
    *
    * Specifies whether the border should be painted. Default value is true.
    */
    private transient boolean __m_BorderPainted;
    
    /**
    * Property Invoker
    *
    * Specifies the component which is the "invoker" of this popup menu -- the
    * component in which the popup menu is to be displayed. This property is
    * not meant to be designed -- it's set during intialization.
    * 
    * @see #onInit
    */
    private _package.component.gUI.Control __m_Invoker;
    
    /**
    * Property Label
    *
    * Specifies the popup menu's label.  Different Look and Feels may choose to
    * display or not display this.
    */
    private transient String __m_Label;
    
    /**
    * Property SelectedItem
    *
    * Specifies the currently selected menu item.
    * 
    * @see JMenuItem
    */
    private transient _package.component.gUI.control.container.jComponent.abstractButton.JMenuItem __m_SelectedItem;
    
    // fields used by the integration model:
    private sink_JPopupMenu __sink;
    private javax.swing.JPopupMenu __feed;
    
    // Default constructor
    public JPopupMenu()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JPopupMenu(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JPopupMenu.__tloPeer.setObject(this);
            new jb_JPopupMenu(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        super.__initEvents();
        
        addPopupMenuListener(this);
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JPopupMenu();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JPopupMenu".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ PopupMenuListener dispatcher
    private com.tangosol.util.Listeners __PopupMenuListeners;
    private void addPopupMenuListener$Router(javax.swing.event.PopupMenuListener l)
        {
        __sink.addPopupMenuListener(l);
        }
    public void addPopupMenuListener(javax.swing.event.PopupMenuListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __PopupMenuListeners;
        if (_listeners == null)
            {
            __PopupMenuListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addPopupMenuListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removePopupMenuListener$Router(javax.swing.event.PopupMenuListener l)
        {
        __sink.removePopupMenuListener(l);
        }
    public void removePopupMenuListener(javax.swing.event.PopupMenuListener l)
        {
        com.tangosol.util.Listeners _listeners = __PopupMenuListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removePopupMenuListener$Router(this);
            }
        }
    private void popupMenuCanceled$Dispatch(javax.swing.event.PopupMenuEvent e)
        {
        java.util.EventListener[] targets = __PopupMenuListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.PopupMenuListener target = (javax.swing.event.PopupMenuListener) targets[i];
            if (target != this)
                {
                target.popupMenuCanceled(e);
                }
            }
        }
    public void popupMenuCanceled(javax.swing.event.PopupMenuEvent e)
        {
        concedeFocus();
        
        try
            {
            onPopupCanceled();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        popupMenuCanceled$Dispatch(e);
        }
    private void popupMenuWillBecomeInvisible$Dispatch(javax.swing.event.PopupMenuEvent e)
        {
        java.util.EventListener[] targets = __PopupMenuListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.PopupMenuListener target = (javax.swing.event.PopupMenuListener) targets[i];
            if (target != this)
                {
                target.popupMenuWillBecomeInvisible(e);
                }
            }
        }
    public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent e)
        {
        concedeFocus();
        
        try
            {
            onPopupInvisible();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        popupMenuWillBecomeInvisible$Dispatch(e);
        }
    private void popupMenuWillBecomeVisible$Dispatch(javax.swing.event.PopupMenuEvent e)
        {
        java.util.EventListener[] targets = __PopupMenuListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.PopupMenuListener target = (javax.swing.event.PopupMenuListener) targets[i];
            if (target != this)
                {
                target.popupMenuWillBecomeVisible(e);
                }
            }
        }
    public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent e)
        {
        setSelectedItem(null);
        
        try
            {
            onPopupVisible();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        popupMenuWillBecomeVisible$Dispatch(e);
        }
    //-- PopupMenuListener dispatcher
    
    //++ javax.swing.JPopupMenu integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JPopupMenu) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JPopupMenu) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public void _add(java.awt.Component comp, Object constraints, int index)
        {
        _JPopupMenu _popup = (_JPopupMenu) get_Feed();
        
        if (index >= 0 && index < _popup.getComponentCount())
            {
            _popup.insert(comp, index);
            }
        else
            {
            super._add(comp, constraints, index);
            }
        }
    public void setVisible(boolean pVisible)
        {
        if (pVisible == isVisible())
            {
            return;
            }
        
        super.setVisible(pVisible);
        
        if (pVisible)
            {
            // work-around swing bug -- no keyboard support for popup menu
            // TODO: remove when fixed
            set_OrigFocusOwner(get_FocusOwner());
            requestFocus();
            }
        else
            {
            concedeFocus();
            }
        }
    public java.awt.Component get_Invoker()
        {
        return __sink.getInvoker();
        }
    public String getLabel()
        {
        return __sink.getLabel();
        }
    public boolean isBorderPainted()
        {
        return __sink.isBorderPainted();
        }
    public void setBorderPainted(boolean pBorderPainted)
        {
        __sink.setBorderPainted(pBorderPainted);
        }
    public void set_Invoker(java.awt.Component p_Invoker)
        {
        __sink.setInvoker(p_Invoker);
        }
    public void setLabel(String pLabel)
        {
        __sink.setLabel(pLabel);
        }
    //-- javax.swing.JPopupMenu integration
    
    // Declared at the super level
    public void _imports()
        {
        // import javax.swing.JPopupMenu as _JPopupMenu;
        // import com.tangosol.run.component.EventDeathException;
        

        }
    
    /**
    * @see #setVisible
    */
    private void concedeFocus()
        {
        // import java.awt.Component as _Control;
        
        _Control focusOwner = get_OrigFocusOwner();
        if (focusOwner != null && focusOwner.isEnabled())
            {
            focusOwner.requestFocus();
            set_OrigFocusOwner(null);
            }
        }
    
    // Declared at the super level
    public java.awt.Component get_FocusOwner()
        {
        // import Component.GUI.Control;
        
        Control invoker = getInvoker();
        return invoker != null ?
            invoker.get_FocusOwner() : super.get_FocusOwner();
        }
    
    // Accessor for the property "_OrigFocusOwner"
    private java.awt.Component get_OrigFocusOwner()
        {
        return __m__OrigFocusOwner;
        }
    
    // Declared at the super level
    /**
    * This method is called by  Component.Control.Container#addControl() as a
    * last chance to intervene during the construction/integration cycle.
    * A Control would override this if more than one AWT components should be
    * created for one Control or if the component should not be added to the
    * container (see Component...Window or Component...TabbedPanel).
    * This method can also be used to make sure that the parent is of the
    * allowed type (i.e. TabbedPanel is only allowed to be added into the
    * JTabbedPane).
    *  
    * @param  fAdd is true <b>only</b> when this is the frist call (from
    * addControl()) and an override is supposed to tie all the pieces together;
    * false in all other situations
    * 
    * @return AWT component that is added to a container [integratee].
    * 
    * @see Component.Control.Container.Window
    * @see Component.GUI.Control.Container.JComponent
    * @see
    * Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem.JMenu
    * @see Component.GUI.Control.Container.JComponent.JPanel.ButtonGroupPanel
    */
    public java.awt.Component getAWTContainee(boolean fAdd)
        {
        // JPopupMenu should not be inserted into a container component
        // it gets activated using "setVisible(true)" instead
        return null;
        }
    
    // Accessor for the property "Invoker"
    public _package.component.gUI.Control getInvoker()
        {
        return __m_Invoker;
        }
    
    // Declared at the super level
    public _package.component.gUI.Point getLocation()
        {
        // import Component.GUI.Control;
        // import Component.GUI.Point;
        
        // Location property (see Component.GUI.Control#get/setLocation())
        // We will make it relative to the invoker
        
        Point   location = super.getLocation();
        Control invoker  = getInvoker();
        
        if (invoker != null)
            {
            location.sub(invoker.getLocationOnScreen());
            }
        return location;
        }
    
    // Accessor for the property "SelectedItem"
    public _package.component.gUI.control.container.jComponent.abstractButton.JMenuItem getSelectedItem()
        {
        /* the following is not working
        
        import Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem;
        import javax.swing.JMenuItem as _JMenuItem;
        
        JMenuItem   item   = null;
        _JPopupMenu _popup = (_JPopupMenu) get_Feed();
        int         ix     = _popup.getSelectionModel().getSelectedIndex();
        
        if (ix >= 0)
            {
            item = (JMenuItem) _findFeed(_popup.getComponent(ix));
            }
        
        return item;
        */
        
        return __m_SelectedItem;

        }
    
    // Accessor for the property "AutoTrigger"
    public boolean isAutoTrigger()
        {
        return __m_AutoTrigger;
        }
    
    // Declared at the super level
    public void mousePressed(java.awt.event.MouseEvent e)
        {
        // import Component.GUI.Control;
        // import Component.GUI.Point;
        // import java.awt.Event;
        // import java.awt.Component as _Control;
        
        Control invoker = getInvoker();
        
        if (!isVisible() && isAutoTrigger() && invoker != null &&
            e.getSource() == invoker.get_Feed() &&
            (e.isPopupTrigger() || (e.getModifiers() & Event.META_MASK) != 0))
            {
            setLocation(Point.instantiate(e.getX(), e.getY()));
            setVisible(true);
        
            // don't call into the "super",
            // if we did the popup would be closed right away
            }
        else
            {
            super.mousePressed(e);
            }
        }
    
    /**
    * A notification event that gets by the onAction event of a contained
    * JMenuItem.
    * 
    * @see JMenuItem#onAction
    */
    public void onAction(String action, int modifiers, String param)
        {
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import Component.GUI.Control;
        
        super.onInit();
        
        setInvoker((Control) get_Parent());

        }
    
    // Declared at the super level
    public void onKeyPressed(char keyChar, int keyCode, int modifiers)
        {
        // import java.awt.Event;
        // import java.awt.event.KeyEvent;
        // import javax.swing.MenuElement;
        // import javax.swing.JMenuItem;
        // import javax.swing.MenuSelectionManager;
        
        super.onKeyPressed(keyChar, keyCode, modifiers);
        
        // Swing's bug -- registered keyboard action are not respected
        // TODO: remove the entire thing when the bug is fixed
        switch (keyCode)
            {
            case KeyEvent.VK_ESCAPE:
                MenuSelectionManager.defaultManager().clearSelectedPath();
                setVisible(false);
                break;
        
            case KeyEvent.VK_ENTER:
                {
                MenuElement[] me = MenuSelectionManager.defaultManager().getSelectedPath();
                if (me != null && me.length > 0 &&
                    me[me.length - 1] instanceof JMenuItem)
                    {
                    ((JMenuItem) me[me.length - 1]).doClick();
                    MenuSelectionManager.defaultManager().clearSelectedPath();
                    setVisible(false);
                    }
                break;
                }
            }
        }
    
    /**
    * Method notification sent when this popup menu is canceled.
    */
    public void onPopupCanceled()
        {
        }
    
    /**
    * Method notification sent when this popup menu is about to become
    * invisible.
    */
    public void onPopupInvisible()
        {
        }
    
    /**
    * Method notification sent when this popup menu is about to become visible.
    */
    public void onPopupVisible()
        {
        }
    
    // Accessor for the property "_OrigFocusOwner"
    private void set_OrigFocusOwner(java.awt.Component p_OrigFocusOwner)
        {
        __m__OrigFocusOwner = p_OrigFocusOwner;
        }
    
    // Accessor for the property "AutoTrigger"
    public void setAutoTrigger(boolean pAutoTrigger)
        {
        __m_AutoTrigger = pAutoTrigger;
        }
    
    // Accessor for the property "Invoker"
    public void setInvoker(_package.component.gUI.Control pInvoker)
        {
        // import Component.GUI.Control;
        // import java.awt.Component as _Control;
        
        Control invokerOld = getInvoker();
        Control invokerNew = pInvoker;
        boolean fAuto      = isAutoTrigger();
        
        if (invokerNew == invokerOld)
            {
            return;
            }
        
        if (fAuto && invokerOld != null)
            {
            invokerOld.removeMouseListener(this);
            }
        
        __m_Invoker = (invokerNew);
        set_Invoker(invokerNew == null ? null : (_Control) invokerNew.get_Feed());
        
        if (fAuto && invokerNew != null)
            {
            invokerNew.addMouseListener(this);
            }
        }
    
    // Declared at the super level
    /**
    * Sets the location of the popup menu relative to the invoker's
    * coordinates. This method is usually called out of invoker's mousePressed
    * event, passing the mouse coordinates as the popup location. In case of
    * scrollable components (JTree, JList, etc.) those coordinates are relative
    * to the scrollpane view and will be adjusted accordingly.
    */
    public void setLocation(_package.component.gUI.Point pLocation)
        {
        // import Component.Application.GUI;
        // import Component.GUI.Control;
        // import Component.GUI.Control.Container.JComponent;
        // import Component.GUI.Dimension;
        // import Component.GUI.Point;
        
        Point     ptPopup  = (Point) pLocation.clone();
        Dimension dimPopup = getPreferredSize();
        
        Control invoker = getInvoker();
        if (invoker != null)
            {
            if (invoker instanceof JComponent)
                {
                JComponent jc = (JComponent) invoker;
                if (jc.isScrollable())
                    {
                    ptPopup.sub(jc.getViewPosition());
                    }
                }
            
            Point     ptInvoker  = invoker.getLocationOnScreen();
            Dimension dimInvoker = invoker.getSize();
        
            if (ptPopup.getX() + dimPopup.getWidth() > dimInvoker.getWidth())
                {
                ptPopup.setX(dimInvoker.getWidth() - dimPopup.getWidth());
                }
            if (ptPopup.getY() + dimPopup.getHeight() > dimInvoker.getHeight())
                {
                ptPopup.setY(dimInvoker.getHeight() - dimPopup.getHeight());
                }
        
            // popup is working in absolute (screen) coordinates
            ptPopup.add(ptInvoker);
            }
        
        Dimension dimScreen = ((GUI) GUI.get_Instance()).getScreenSize();
        
        if (ptPopup.getX() < 0)
            {
            ptPopup.setX(0);
            }
        else if (ptPopup.getX() + dimPopup.getWidth() > dimScreen.getWidth())
            {
            ptPopup.setX(dimScreen.getWidth() - dimPopup.getWidth());
            }
        if (ptPopup.getY() < 0)
            {
            ptPopup.setY(0);
            }
        else if (ptPopup.getY() + dimPopup.getHeight() > dimScreen.getHeight())
            {
            ptPopup.setY(dimScreen.getHeight() - dimPopup.getHeight());
            }
        super.setLocation(ptPopup);
        }
    
    // Accessor for the property "SelectedItem"
    public void setSelectedItem(_package.component.gUI.control.container.jComponent.abstractButton.JMenuItem pSelectedItem)
        {
        /* the following is not working
        
        import Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem;
        import javax.swing.JMenuItem as _JMenuItem;
        
        _JPopupMenu _popup = (_JPopupMenu) get_Feed();
        int         ix     = _popup.getComponentIndex(
                                (_JMenuItem) pSelectedItem.get_Feed());
        if (ix >= 0)
            {
            _popup.getSelectionModel().setSelectedIndex(ix);
            }
        else
            {
            _popup.getSelectionModel().clearSelection();
            }
        */
        
        __m_SelectedItem = (pSelectedItem);
        }
    }
