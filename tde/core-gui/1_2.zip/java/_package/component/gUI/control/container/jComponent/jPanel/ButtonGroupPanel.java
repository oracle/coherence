/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.ButtonGroupPanel
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.gUI.control.container.jComponent.abstractButton.JToggleButton;
import java.util.Enumeration;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JToggleButton; // as _JToggleButton

public class ButtonGroupPanel
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property Group
    *
    */
    private javax.swing.ButtonGroup __m_Group;
    
    /**
    * Property Selection
    *
    */
    private _package.component.gUI.control.container.jComponent.abstractButton.JToggleButton __m_Selection;
    
    /**
    * Property Value
    *
    */
    private transient String __m_Value;
    
    // Default constructor
    public ButtonGroupPanel()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ButtonGroupPanel(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setLayout(null);
            setOpaque(false);
            setResizable(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ButtonGroupPanel();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/ButtonGroupPanel".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent.AbstractButton.JToggleButton;
        

        }
    
    // Declared at the super level
    /**
    * Adds the visual feed of the specified child component to the visual feed
    * of this container. Having this functionality separate from _addChild
    * allows it to be overwritten by containers that know better.
    * 
    * @see #_addChild
    */
    public void addControl(_package.component.gUI.Control child)
        {
        // import javax.swing.JToggleButton as _JToggleButton;
        
        super.addControl(child);
        
        if (child instanceof JToggleButton)
            {
            java.awt.Component _containee = child.getAWTContainee(false); // it was already called from super.addControl()
            if (_containee instanceof _JToggleButton)
                {
                getGroup().add((_JToggleButton) _containee);
                }
            }
        }
    
    // Accessor for the property "Group"
    public javax.swing.ButtonGroup getGroup()
        {
        // import javax.swing.ButtonGroup;
        
        ButtonGroup _group = __m_Group;
        if (_group == null)
            {
            setGroup(_group = new ButtonGroup());
            }
        return _group;
        }
    
    // Accessor for the property "Selection"
    public _package.component.gUI.control.container.jComponent.abstractButton.JToggleButton getSelection()
        {
        // import java.util.Enumeration;
        // import javax.swing.ButtonModel;
        // import javax.swing.JToggleButton as _JToggleButton;
        
        ButtonModel selModel = getGroup().getSelection();
        
        for (Enumeration enum = _enumChildren(); enum.hasMoreElements();)
            {
            try
                {
                JToggleButton b = (JToggleButton) enum.nextElement();
                if (((_JToggleButton) b.get_Feed()).getModel() == selModel)
                    {
                    return b;
                    }
                }
            catch (ClassCastException e)
                {
                }
            }
        return null;
        }
    
    // Accessor for the property "Value"
    public String getValue()
        {
        return getSelection().getValue();
        }
    
    /**
    * Method-notification called when an selection is made.
    * 
    * @see JToggleButton#onItemStateChabged
    */
    public void onItemSelected(_package.component.gUI.control.container.jComponent.abstractButton.JToggleButton comp)
        {
        }
    
    // Declared at the super level
    public void setEnabled(boolean pEnabled)
        {
        // import Component.GUI.Control.Container.JComponent.AbstractButton.JToggleButton;
        // import java.util.Enumeration;
        
        // propagate the setting to all the children
        
        super.setEnabled(pEnabled);
        
        for (Enumeration enum = _enumChildren(); enum.hasMoreElements();)
            {
            try
                {
                JToggleButton b = (JToggleButton) enum.nextElement();
                b.setEnabled(pEnabled);
                }
            catch (ClassCastException e)
                {
                }
            }
        }
    
    // Accessor for the property "Group"
    public void setGroup(javax.swing.ButtonGroup pGroup)
        {
        __m_Group = pGroup;
        }
    
    // Accessor for the property "Selection"
    public void setSelection(_package.component.gUI.control.container.jComponent.abstractButton.JToggleButton pSelection)
        {
        // import javax.swing.JToggleButton as _JToggleButton;
        
        if (pSelection != null)
            {
            getGroup().setSelected(
                ((_JToggleButton) pSelection.get_Feed()).getModel(), true);
            }
        else
            {
            // unselect all
            // Note: ButtonGroup doesn't allow to do this directly!
            pSelection = getSelection();
            if (pSelection != null)
                {
                getGroup().remove((_JToggleButton) pSelection.get_Feed());
                pSelection.setSelected(false);
                getGroup().add   ((_JToggleButton) pSelection.get_Feed());
                }
            }
        repaint();
        }
    
    // Accessor for the property "Value"
    public void setValue(String pValue)
        {
        // import java.util.Enumeration;
        
        for (Enumeration enum = _enumChildren(); enum.hasMoreElements();)
            {
            try
                {
                JToggleButton b = (JToggleButton) enum.nextElement();
                if (b.getValue().equals(pValue))
                    {
                    setSelection(b);
                    return;
                    }
                }
            catch (ClassCastException e)
                {
                }
            }
        }
    }
