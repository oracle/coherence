/* Class
*      sink_JTextComponent
*
* automatically generated "Sink" which
* represents a footprint of the class
*      javax.swing.text.JTextComponent
* when used as a component callback by 
*      Component.GUI.Control.Container.JComponent.JTextComponent
*/

package _package.component.gUI.control.container.jComponent;

public abstract class sink_JTextComponent
       extends _package.component.gUI.control.container.sink_JComponent
    {
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_JTextComponent()
        {
        }
    
    // methods integrated and/or remoted
    public abstract void add(java.awt.Component comp, Object constraints, int index);
    public abstract void remove(java.awt.Component comp);
    public abstract void addCaretListener(javax.swing.event.CaretListener l);
    public abstract void addFocusListener(java.awt.event.FocusListener l);
    public abstract void addInputMethodListener(java.awt.event.InputMethodListener l);
    public abstract void addKeyListener(java.awt.event.KeyListener l);
    public abstract void addMouseListener(java.awt.event.MouseListener l);
    public abstract void addMouseMotionListener(java.awt.event.MouseMotionListener l);
    public abstract void addNotify();
    public abstract void addPropertyChangeListener(java.beans.PropertyChangeListener l);
    public abstract void addVetoableChangeListener(java.beans.VetoableChangeListener l);
    public abstract void copy();
    public abstract javax.swing.JToolTip createToolTip();
    public abstract void cut();
    public abstract void doLayout();
    public abstract java.awt.Color getBackground();
    public abstract javax.swing.border.Border getBorder();
    public abstract java.awt.Rectangle getBounds();
    public abstract java.awt.Cursor getCursor();
    public abstract java.awt.Color getDisabledTextColor();
    public abstract javax.swing.text.Document getDocument();
    public abstract java.awt.Font getFont();
    public abstract java.awt.Color getForeground();
    public abstract java.awt.Insets getInsets();
    public abstract java.awt.LayoutManager getLayout();
    public abstract java.awt.Point getLocation();
    public abstract java.awt.Point getLocationOnScreen();
    public abstract java.awt.Dimension getMaximumSize();
    public abstract java.awt.Dimension getMinimumSize();
    public abstract java.awt.Dimension getPreferredSize();
    public abstract java.awt.Dimension getSize();
    public abstract int getCaretPosition();
    public abstract char getFocusAccelerator();
    public abstract String getSelectedText();
    public abstract int getSelectionEnd();
    public abstract int getSelectionStart();
    public abstract String getText();
    public abstract java.awt.Point getToolTipLocation(java.awt.event.MouseEvent e);
    public abstract String getToolTipText();
    public abstract String getToolTipText(java.awt.event.MouseEvent e);
    public abstract boolean getAutoscrolls();
    public abstract boolean isEditable();
    public abstract boolean isEnabled();
    public abstract boolean isFocusTraversable();
    public abstract boolean isOpaque();
    public abstract boolean isShowing();
    public abstract boolean isVisible();
    public abstract void paint(java.awt.Graphics g);
    public abstract void paintBorder(java.awt.Graphics g);
    public abstract void paintChildren(java.awt.Graphics g);
    public abstract void paintComponent(java.awt.Graphics g);
    public abstract void paste();
    public abstract void removeCaretListener(javax.swing.event.CaretListener l);
    public abstract void removeFocusListener(java.awt.event.FocusListener l);
    public abstract void removeInputMethodListener(java.awt.event.InputMethodListener l);
    public abstract void removeKeyListener(java.awt.event.KeyListener l);
    public abstract void removeMouseListener(java.awt.event.MouseListener l);
    public abstract void removeMouseMotionListener(java.awt.event.MouseMotionListener l);
    public abstract void removeNotify();
    public abstract void removePropertyChangeListener(java.beans.PropertyChangeListener l);
    public abstract void removeVetoableChangeListener(java.beans.VetoableChangeListener l);
    public abstract void replaceSelection(String sContent);
    public abstract void requestFocus();
    public abstract void select(int ofStart, int ofEnd);
    public abstract void selectAll();
    public abstract void setBackground(java.awt.Color p_Background);
    public abstract void setBorder(javax.swing.border.Border p_Border);
    public abstract void setBounds(java.awt.Rectangle p_Bounds);
    public abstract void setCursor(java.awt.Cursor p_Cursor);
    public abstract void setDisabledTextColor(java.awt.Color p_DisabledTextColor);
    public abstract void setDocument(javax.swing.text.Document p_Document);
    public abstract void setFont(java.awt.Font p_Font);
    public abstract void setForeground(java.awt.Color p_Foreground);
    public abstract void setLayout(java.awt.LayoutManager p_Layout);
    public abstract void setLocation(java.awt.Point p_Location);
    public abstract void setMaximumSize(java.awt.Dimension p_MaximumSize);
    public abstract void setMinimumSize(java.awt.Dimension p_MinimumSize);
    public abstract void setPreferredSize(java.awt.Dimension p_PreferredSize);
    public abstract void setSize(java.awt.Dimension p_Size);
    public abstract void setAutoscrolls(boolean pAutoscrolls);
    public abstract void setCaretPosition(int pCaretPosition);
    public abstract void setEditable(boolean pEditable);
    public abstract void setEnabled(boolean pEnabled);
    public abstract void setFocusAccelerator(char pFocusAccelerator);
    public abstract void setOpaque(boolean pOpaque);
    public abstract void setSelectionEnd(int pSelectionEnd);
    public abstract void setSelectionStart(int pSelectionStart);
    public abstract void setText(String pText);
    public abstract void setToolTipText(String pToolTipText);
    public abstract void setVisible(boolean pVisible);
    public abstract void updateUI();
    public abstract void validate();
    }
