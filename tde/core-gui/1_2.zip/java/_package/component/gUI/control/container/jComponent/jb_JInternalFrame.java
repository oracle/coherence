/* Class
*      jb_JInternalFrame
*
* automatically generated "Feed" which
* a) extends an external bean:
*      javax.swing.JInternalFrame
* b) delegates to the peer component:
*      Component.GUI.Control.Container.JComponent.JInternalFrame
*/

package _package.component.gUI.control.container.jComponent;

public class jb_JInternalFrame
        extends    javax.swing.JInternalFrame
        implements com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected JInternalFrame __peer;
    
    private static JInternalFrame __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            JInternalFrame peer = (JInternalFrame)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // default (JavaBean) constructor
    public jb_JInternalFrame()
        {
        this(JInternalFrame.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JInternalFrame(String Param_1)
        {
        this(Param_1, JInternalFrame.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JInternalFrame(String Param_1, boolean Param_2)
        {
        this(Param_1, Param_2, JInternalFrame.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JInternalFrame(String Param_1, boolean Param_2, boolean Param_3)
        {
        this(Param_1, Param_2, Param_3, JInternalFrame.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JInternalFrame(String Param_1, boolean Param_2, boolean Param_3, boolean Param_4)
        {
        this(Param_1, Param_2, Param_3, Param_4, JInternalFrame.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JInternalFrame(String Param_1, boolean Param_2, boolean Param_3, boolean Param_4, boolean Param_5)
        {
        this(Param_1, Param_2, Param_3, Param_4, Param_5, JInternalFrame.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JInternalFrame(Class clzPeer)
        {
        this(__createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JInternalFrame(String Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JInternalFrame(String Param_1, boolean Param_2, Class clzPeer)
        {
        this(Param_1, Param_2, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JInternalFrame(String Param_1, boolean Param_2, boolean Param_3, Class clzPeer)
        {
        this(Param_1, Param_2, Param_3, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JInternalFrame(String Param_1, boolean Param_2, boolean Param_3, boolean Param_4, Class clzPeer)
        {
        this(Param_1, Param_2, Param_3, Param_4, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JInternalFrame(String Param_1, boolean Param_2, boolean Param_3, boolean Param_4, boolean Param_5, Class clzPeer)
        {
        this(Param_1, Param_2, Param_3, Param_4, Param_5, __createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JInternalFrame(JInternalFrame peer, boolean fInit)
        {
        super();
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JInternalFrame(String Param_1, JInternalFrame peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JInternalFrame(String Param_1, boolean Param_2, JInternalFrame peer, boolean fInit)
        {
        super(Param_1, Param_2);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JInternalFrame(String Param_1, boolean Param_2, boolean Param_3, JInternalFrame peer, boolean fInit)
        {
        super(Param_1, Param_2, Param_3);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JInternalFrame(String Param_1, boolean Param_2, boolean Param_3, boolean Param_4, JInternalFrame peer, boolean fInit)
        {
        super(Param_1, Param_2, Param_3, Param_4);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JInternalFrame(String Param_1, boolean Param_2, boolean Param_3, boolean Param_4, boolean Param_5, JInternalFrame peer, boolean fInit)
        {
        super(Param_1, Param_2, Param_3, Param_4, Param_5);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private JInternalFrame __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (JInternalFrame) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_JInternalFrame(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    public void add(java.awt.Component comp, Object constraints, int index)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._add(comp, constraints, index);
        }
    void super$add(java.awt.Component comp, Object constraints, int index)
        {
        super.add(comp, constraints, index);
        }
    public void remove(java.awt.Component comp)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._remove(comp);
        }
    void super$remove(java.awt.Component comp)
        {
        super.remove(comp);
        }
    public void addFocusListener(java.awt.event.FocusListener l)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addFocusListener(l);
        }
    void super$addFocusListener(java.awt.event.FocusListener l)
        {
        super.addFocusListener(l);
        }
    public void addInternalFrameListener(javax.swing.event.InternalFrameListener l)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addInternalFrameListener(l);
        }
    void super$addInternalFrameListener(javax.swing.event.InternalFrameListener l)
        {
        super.addInternalFrameListener(l);
        }
    public void addKeyListener(java.awt.event.KeyListener l)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addKeyListener(l);
        }
    void super$addKeyListener(java.awt.event.KeyListener l)
        {
        super.addKeyListener(l);
        }
    public void addMouseListener(java.awt.event.MouseListener l)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseListener(l);
        }
    void super$addMouseListener(java.awt.event.MouseListener l)
        {
        super.addMouseListener(l);
        }
    public void addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseMotionListener(l);
        }
    void super$addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.addMouseMotionListener(l);
        }
    public void addNotify()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addNotify();
        }
    void super$addNotify()
        {
        super.addNotify();
        }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addPropertyChangeListener(l);
        }
    void super$addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.addPropertyChangeListener(l);
        }
    public void addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addVetoableChangeListener(l);
        }
    void super$addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.addVetoableChangeListener(l);
        }
    public javax.swing.JToolTip createToolTip()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.createToolTip();
        }
    javax.swing.JToolTip super$createToolTip()
        {
        return super.createToolTip();
        }
    public void dispose()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.dispose();
        }
    void super$dispose()
        {
        super.dispose();
        }
    public void doLayout()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.doLayout();
        }
    void super$doLayout()
        {
        super.doLayout();
        }
    public java.awt.Color getBackground()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Background();
        }
    java.awt.Color super$getBackground()
        {
        return super.getBackground();
        }
    public javax.swing.border.Border getBorder()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Border();
        }
    javax.swing.border.Border super$getBorder()
        {
        return super.getBorder();
        }
    public java.awt.Rectangle getBounds()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Bounds();
        }
    java.awt.Rectangle super$getBounds()
        {
        return super.getBounds();
        }
    public java.awt.Cursor getCursor()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Cursor();
        }
    java.awt.Cursor super$getCursor()
        {
        return super.getCursor();
        }
    public java.awt.Font getFont()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Font();
        }
    java.awt.Font super$getFont()
        {
        return super.getFont();
        }
    public java.awt.Color getForeground()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Foreground();
        }
    java.awt.Color super$getForeground()
        {
        return super.getForeground();
        }
    public javax.swing.Icon getFrameIcon()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_FrameIcon();
        }
    javax.swing.Icon super$getFrameIcon()
        {
        return super.getFrameIcon();
        }
    public java.awt.Insets getInsets()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Insets();
        }
    java.awt.Insets super$getInsets()
        {
        return super.getInsets();
        }
    public java.awt.LayoutManager getLayout()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Layout();
        }
    java.awt.LayoutManager super$getLayout()
        {
        return super.getLayout();
        }
    public java.awt.Point getLocation()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Location();
        }
    java.awt.Point super$getLocation()
        {
        return super.getLocation();
        }
    public java.awt.Point getLocationOnScreen()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_LocationOnScreen();
        }
    java.awt.Point super$getLocationOnScreen()
        {
        return super.getLocationOnScreen();
        }
    public java.awt.Dimension getMaximumSize()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MaximumSize();
        }
    java.awt.Dimension super$getMaximumSize()
        {
        return super.getMaximumSize();
        }
    public java.awt.Dimension getMinimumSize()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MinimumSize();
        }
    java.awt.Dimension super$getMinimumSize()
        {
        return super.getMinimumSize();
        }
    public java.awt.Dimension getPreferredSize()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_PreferredSize();
        }
    java.awt.Dimension super$getPreferredSize()
        {
        return super.getPreferredSize();
        }
    public java.awt.Dimension getSize()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Size();
        }
    java.awt.Dimension super$getSize()
        {
        return super.getSize();
        }
    public int getLayer()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getLayer();
        }
    int super$getLayer()
        {
        return super.getLayer();
        }
    public String getTitle()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getTitle();
        }
    String super$getTitle()
        {
        return super.getTitle();
        }
    public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent e)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipLocation(e);
        }
    java.awt.Point super$getToolTipLocation(java.awt.event.MouseEvent e)
        {
        return super.getToolTipLocation(e);
        }
    public String getToolTipText()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText();
        }
    String super$getToolTipText()
        {
        return super.getToolTipText();
        }
    public String getToolTipText(java.awt.event.MouseEvent e)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText(e);
        }
    String super$getToolTipText(java.awt.event.MouseEvent e)
        {
        return super.getToolTipText(e);
        }
    public boolean getAutoscrolls()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isAutoscrolls();
        }
    boolean super$getAutoscrolls()
        {
        return super.getAutoscrolls();
        }
    public boolean isClosable()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isClosable();
        }
    boolean super$isClosable()
        {
        return super.isClosable();
        }
    public boolean isClosed()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isClosed();
        }
    boolean super$isClosed()
        {
        return super.isClosed();
        }
    public boolean isEnabled()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isEnabled();
        }
    boolean super$isEnabled()
        {
        return super.isEnabled();
        }
    public boolean isFocusTraversable()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isFocusTraversable();
        }
    boolean super$isFocusTraversable()
        {
        return super.isFocusTraversable();
        }
    public boolean isIconifiable()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isIconifiable();
        }
    boolean super$isIconifiable()
        {
        return super.isIconifiable();
        }
    public boolean isIcon()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isIconified();
        }
    boolean super$isIcon()
        {
        return super.isIcon();
        }
    public boolean isMaximizable()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isMaximizable();
        }
    boolean super$isMaximizable()
        {
        return super.isMaximizable();
        }
    public boolean isMaximum()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isMaximized();
        }
    boolean super$isMaximum()
        {
        return super.isMaximum();
        }
    public boolean isOpaque()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isOpaque();
        }
    boolean super$isOpaque()
        {
        return super.isOpaque();
        }
    public boolean isResizable()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isResizable();
        }
    boolean super$isResizable()
        {
        return super.isResizable();
        }
    public boolean isSelected()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isSelected();
        }
    boolean super$isSelected()
        {
        return super.isSelected();
        }
    public boolean isShowing()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isShowing();
        }
    boolean super$isShowing()
        {
        return super.isShowing();
        }
    public boolean isVisible()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isVisible();
        }
    boolean super$isVisible()
        {
        return super.isVisible();
        }
    public void moveToBack()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.moveToBack();
        }
    void super$moveToBack()
        {
        super.moveToBack();
        }
    public void moveToFront()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.moveToFront();
        }
    void super$moveToFront()
        {
        super.moveToFront();
        }
    public void paint(java.awt.Graphics g)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paint(g);
        }
    void super$paint(java.awt.Graphics g)
        {
        super.paint(g);
        }
    protected void paintBorder(java.awt.Graphics g)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintBorder(g);
        }
    void super$paintBorder(java.awt.Graphics g)
        {
        super.paintBorder(g);
        }
    protected void paintChildren(java.awt.Graphics g)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintChildren(g);
        }
    void super$paintChildren(java.awt.Graphics g)
        {
        super.paintChildren(g);
        }
    protected void paintComponent(java.awt.Graphics g)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintComponent(g);
        }
    void super$paintComponent(java.awt.Graphics g)
        {
        super.paintComponent(g);
        }
    public void removeFocusListener(java.awt.event.FocusListener l)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeFocusListener(l);
        }
    void super$removeFocusListener(java.awt.event.FocusListener l)
        {
        super.removeFocusListener(l);
        }
    public void removeInternalFrameListener(javax.swing.event.InternalFrameListener l)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeInternalFrameListener(l);
        }
    void super$removeInternalFrameListener(javax.swing.event.InternalFrameListener l)
        {
        super.removeInternalFrameListener(l);
        }
    public void removeKeyListener(java.awt.event.KeyListener l)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeKeyListener(l);
        }
    void super$removeKeyListener(java.awt.event.KeyListener l)
        {
        super.removeKeyListener(l);
        }
    public void removeMouseListener(java.awt.event.MouseListener l)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseListener(l);
        }
    void super$removeMouseListener(java.awt.event.MouseListener l)
        {
        super.removeMouseListener(l);
        }
    public void removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseMotionListener(l);
        }
    void super$removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.removeMouseMotionListener(l);
        }
    public void removeNotify()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeNotify();
        }
    void super$removeNotify()
        {
        super.removeNotify();
        }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removePropertyChangeListener(l);
        }
    void super$removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.removePropertyChangeListener(l);
        }
    public void removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeVetoableChangeListener(l);
        }
    void super$removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.removeVetoableChangeListener(l);
        }
    public void requestFocus()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.requestFocus();
        }
    void super$requestFocus()
        {
        super.requestFocus();
        }
    public void setBackground(java.awt.Color p_Background)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Background(p_Background);
        }
    void super$setBackground(java.awt.Color p_Background)
        {
        super.setBackground(p_Background);
        }
    public void setBorder(javax.swing.border.Border p_Border)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Border(p_Border);
        }
    void super$setBorder(javax.swing.border.Border p_Border)
        {
        super.setBorder(p_Border);
        }
    public void setBounds(java.awt.Rectangle p_Bounds)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Bounds(p_Bounds);
        }
    void super$setBounds(java.awt.Rectangle p_Bounds)
        {
        super.setBounds(p_Bounds);
        }
    public void setCursor(java.awt.Cursor p_Cursor)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Cursor(p_Cursor);
        }
    void super$setCursor(java.awt.Cursor p_Cursor)
        {
        super.setCursor(p_Cursor);
        }
    public void setFont(java.awt.Font p_Font)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Font(p_Font);
        }
    void super$setFont(java.awt.Font p_Font)
        {
        super.setFont(p_Font);
        }
    public void setForeground(java.awt.Color p_Foreground)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Foreground(p_Foreground);
        }
    void super$setForeground(java.awt.Color p_Foreground)
        {
        super.setForeground(p_Foreground);
        }
    public void setFrameIcon(javax.swing.Icon p_FrameIcon)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_FrameIcon(p_FrameIcon);
        }
    void super$setFrameIcon(javax.swing.Icon p_FrameIcon)
        {
        super.setFrameIcon(p_FrameIcon);
        }
    public void setLayer(Integer p_Layer)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Layer(p_Layer);
        }
    void super$setLayer(Integer p_Layer)
        {
        super.setLayer(p_Layer);
        }
    public void setLayout(java.awt.LayoutManager p_Layout)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Layout(p_Layout);
        }
    void super$setLayout(java.awt.LayoutManager p_Layout)
        {
        super.setLayout(p_Layout);
        }
    public void setLocation(java.awt.Point p_Location)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Location(p_Location);
        }
    void super$setLocation(java.awt.Point p_Location)
        {
        super.setLocation(p_Location);
        }
    public void setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MaximumSize(p_MaximumSize);
        }
    void super$setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        super.setMaximumSize(p_MaximumSize);
        }
    public void setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MinimumSize(p_MinimumSize);
        }
    void super$setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        super.setMinimumSize(p_MinimumSize);
        }
    public void setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_PreferredSize(p_PreferredSize);
        }
    void super$setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        super.setPreferredSize(p_PreferredSize);
        }
    public void setSize(java.awt.Dimension p_Size)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Size(p_Size);
        }
    void super$setSize(java.awt.Dimension p_Size)
        {
        super.setSize(p_Size);
        }
    public void setAutoscrolls(boolean pAutoscrolls)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setAutoscrolls(pAutoscrolls);
        }
    void super$setAutoscrolls(boolean pAutoscrolls)
        {
        super.setAutoscrolls(pAutoscrolls);
        }
    public void setClosable(boolean pClosable)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setClosable(pClosable);
        }
    void super$setClosable(boolean pClosable)
        {
        super.setClosable(pClosable);
        }
    public void setClosed(boolean pClosed)
            throws java.beans.PropertyVetoException
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setClosed(pClosed);
        }
    void super$setClosed(boolean pClosed)
            throws java.beans.PropertyVetoException
        {
        super.setClosed(pClosed);
        }
    public void setEnabled(boolean pEnabled)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setEnabled(pEnabled);
        }
    void super$setEnabled(boolean pEnabled)
        {
        super.setEnabled(pEnabled);
        }
    public void setIconifiable(boolean pIconizable)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setIconifiable(pIconizable);
        }
    void super$setIconifiable(boolean pIconizable)
        {
        super.setIconifiable(pIconizable);
        }
    public void setIcon(boolean pIconified)
            throws java.beans.PropertyVetoException
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setIconified(pIconified);
        }
    void super$setIcon(boolean pIconified)
            throws java.beans.PropertyVetoException
        {
        super.setIcon(pIconified);
        }
    public void setMaximizable(boolean pMaximizable)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setMaximizable(pMaximizable);
        }
    void super$setMaximizable(boolean pMaximizable)
        {
        super.setMaximizable(pMaximizable);
        }
    public void setMaximum(boolean pMaximized)
            throws java.beans.PropertyVetoException
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setMaximized(pMaximized);
        }
    void super$setMaximum(boolean pMaximized)
            throws java.beans.PropertyVetoException
        {
        super.setMaximum(pMaximized);
        }
    public void setOpaque(boolean pOpaque)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setOpaque(pOpaque);
        }
    void super$setOpaque(boolean pOpaque)
        {
        super.setOpaque(pOpaque);
        }
    public void setResizable(boolean pResizable)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setResizable(pResizable);
        }
    void super$setResizable(boolean pResizable)
        {
        super.setResizable(pResizable);
        }
    public void setSelected(boolean pSelected)
            throws java.beans.PropertyVetoException
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setSelected(pSelected);
        }
    void super$setSelected(boolean pSelected)
            throws java.beans.PropertyVetoException
        {
        super.setSelected(pSelected);
        }
    public void setTitle(String pTitle)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setTitle(pTitle);
        }
    void super$setTitle(String pTitle)
        {
        super.setTitle(pTitle);
        }
    public void setToolTipText(String pToolTipText)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setToolTipText(pToolTipText);
        }
    void super$setToolTipText(String pToolTipText)
        {
        super.setToolTipText(pToolTipText);
        }
    public void setVisible(boolean pVisible)
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVisible(pVisible);
        }
    void super$setVisible(boolean pVisible)
        {
        super.setVisible(pVisible);
        }
    public void toBack()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.toBack();
        }
    void super$toBack()
        {
        super.toBack();
        }
    public void toFront()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.toFront();
        }
    void super$toFront()
        {
        super.toFront();
        }
    public void updateUI()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.updateUI();
        }
    void super$updateUI()
        {
        super.updateUI();
        }
    public void validate()
        {
        JInternalFrame peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.validate();
        }
    void super$validate()
        {
        super.validate();
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
