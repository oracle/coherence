/* Class
*     _package.component.gUI.control.container.jComponent.jTree.SimpleTree
*/

package _package.component.gUI.control.container.jComponent.jTree;

import _package.component.gUI.TreeNode;
import javax.swing.tree.DefaultMutableTreeNode;

public class SimpleTree
        extends    _package.component.gUI.control.container.jComponent.JTree
    {
    // Fields declarations
    
    /**
    * Property RootName
    *
    */
    private transient String __m_RootName;
    
    // Default constructor
    public SimpleTree()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public SimpleTree(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setEditable(false);
            setFocusable(true);
            setHorizontalScrollBarPolicy(30);
            setLargeModel(false);
            setRedraw(true);
            setRootName(null);
            setRootVisible(false);
            setRowHeight(16);
            setScrollable(true);
            setScrollsOnExpand(true);
            setSelectionMode(1);
            setSeparator('.');
            setShowsRootHandles(true);
            setTBounds("100,10,50,1000");
            setTFont("DefaultProportional");
            setVerticalScrollBarPolicy(20);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new _package.component.gUI.control.container.jComponent.JTree$KeyCollapse("KeyCollapse", this, true), "KeyCollapse");
        _addChild(new _package.component.gUI.control.container.jComponent.JTree$KeyExpand("KeyExpand", this, true), "KeyExpand");
        _addChild(new _package.component.gUI.control.container.jComponent.JTree$KeyExpandAll("KeyExpandAll", this, true), "KeyExpandAll");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new SimpleTree();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jTree/SimpleTree".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.TreeNode;
        // import javax.swing.tree.DefaultMutableTreeNode;
        
        

        }
    
    /**
    * Add a node.
    * 
    * @param sParentId  parent's composite name (id)
    * @param sChildName  child's simple name
    * 
    * @return inserted node
    * 
    * @throws IllegalArgumentException  if a node <code>sParentId</code> cannot
    * be found
    */
    public _package.component.gUI.TreeNode addNode(String sParentId, String sChildName)
        {
        TreeNode nodeParent = findNodeId(sParentId);
        if (nodeParent == null)
            {
            throw new IllegalArgumentException("Invalid parent's id " + sParentId);
            }
        
        return addNode(nodeParent, sChildName);
        }
    
    /**
    * Add a node.
    * 
    * @param nodeParent  parent node
    * @param sChildName  child's simple name
    * 
    * @return inserted node
    */
    public _package.component.gUI.TreeNode addNode(_package.component.gUI.TreeNode nodeParent, String sChildName)
        {
        TreeNode nodeChild = makeNode(sChildName);
        
        if (nodeParent == null)
            {
            nodeParent = getRoot();
            }
        nodeParent.add(nodeChild);
        
        return nodeChild;
        }
    
    // Accessor for the property "RootName"
    public String getRootName()
        {
        return __m_RootName;
        }
    
    /**
    * Insert a node at the specified position.
    * 
    * @param sParentId  parent's composite name (id)
    * @param sChildName  child's simple name
    * @param index  the index in this node's child array where this node is to
    * be inserted
    * 
    * @return inserted node
    * 
    * @throws IllegalArgumentException  if a node <code>sParentId</code> cannot
    * be found
    */
    public _package.component.gUI.TreeNode insertNode(String sParentId, String sChildName, int index)
        {
        TreeNode nodeParent = findNodeId(sParentId);
        if (nodeParent == null)
            {
            throw new IllegalArgumentException("Invalid parent's id " + sParentId);
            }
        
        return insertNode(nodeParent, sChildName, index);

        }
    
    /**
    * Insert a node at the specified position.
    * 
    * @param nodeParent  parent node
    * @param sChildName  child's simple name
    * @param index  the index in this node's child array where this node is to
    * be inserted
    * 
    * @return inserted node
    */
    public _package.component.gUI.TreeNode insertNode(_package.component.gUI.TreeNode nodeParent, String sChildName, int index)
        {
        TreeNode nodeChild = makeNode(sChildName);
        
        if (nodeParent == null)
            {
            nodeParent = getRoot();
            }
        nodeParent.insert(nodeChild, index);
        
        return nodeChild;

        }
    
    // Declared at the super level
    public _package.component.gUI.TreeNode makeNode(Object path)
        {
        if (path instanceof String || path == null)
            {
            TreeNode.SimpleNode node = new TreeNode.SimpleNode();
            node.setTree(this);
            node.setEditable(isEditable());
            node.setSorted(isSorted());
            node.setCaseSensitive(isCaseSensitive());
            node.setCollator(getCollator());
            node.setName((String) path);
            return node;
            }
        else
            {
            return super.makeNode(path);
            }
        }
    
    // Declared at the super level
    /**
    * Makes a root node for this tree
    */
    protected _package.component.gUI.TreeNode makeRoot()
        {
        DefaultMutableTreeNode _root = (DefaultMutableTreeNode) getModel().getRoot();
        _root.setUserObject(null);
        
        TreeNode.SimpleNode simpleRoot = (TreeNode.SimpleNode) makeNode(getRootName());
        
        // the following in turn sets the UserObject of the _root
        // (see SimpleNode#setMutableNode)
        simpleRoot.setMutableNode(_root);
        
        return simpleRoot;
        }
    
    // Declared at the super level
    /**
    * Notification message called when editing process gets ended for the
    * specified node.
    * 
    * Derived classes are responsible for pulling the new value out of
    * "node.getUserObject()" and setting the corresponding values of derived
    * TreeNode(s). Otherwise the new value will be lost.
    * 
    * @see #editingStoped
    */
    public void onEditingStopped(_package.component.gUI.TreeNode node, Object oNewValue)
        {
        super.onEditingStopped(node, oNewValue);
        
        if (node instanceof TreeNode.SimpleNode)
            {
            ((TreeNode.SimpleNode) node).setName(oNewValue.toString());
            }
        }
    
    /**
    * Rename the specified child node.
    */
    public void renameNode(String sOldChildId, String sNewChildName)
        {
        TreeNode nodeChild = findNodeId(sOldChildId);
        if (nodeChild instanceof TreeNode.SimpleNode)
            {
            ((TreeNode.SimpleNode) nodeChild).setName(sNewChildName);
            }
        }
    
    // Accessor for the property "RootName"
    public void setRootName(String pRootName)
        {
        __m_RootName = (pRootName);
        
        if (is_Constructed())
            {
            TreeNode root = getRoot();
            if (root instanceof TreeNode.SimpleNode)
                {
                ((TreeNode.SimpleNode) root).setName(pRootName);
                }
            else
                {
                setRoot(makeRoot());
                }
            }
        }
    }
