/* Class
*      sink_JComboBox
*
* automatically generated "Sink" which
* represents a footprint of the class
*      javax.swing.JComboBox
* when used as a component callback by 
*      Component.GUI.Control.Container.JComponent.JComboBox
*/

package _package.component.gUI.control.container.jComponent;

public class sink_JComboBox
       extends _package.component.gUI.control.container.sink_JComponent
    {
    private jb_JComboBox __peer;
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_JComboBox()
        {
        }
    
    // this (protected) constructor is used by the feed
    protected sink_JComboBox(jb_JComboBox feed)
        {
        super();
        __peer = feed;
        }
    
    // Retrieves the feed object for this sink
    public Object get_Feed()
        {
        return __peer;
        }
    
    // methods integrated and/or remoted
    public void add(java.awt.Component comp, Object constraints, int index)
        {
        __peer.super$add(comp, constraints, index);
        }
    public void remove(java.awt.Component comp)
        {
        __peer.super$remove(comp);
        }
    public void addActionListener(java.awt.event.ActionListener l)
        {
        __peer.super$addActionListener(l);
        }
    public void addFocusListener(java.awt.event.FocusListener l)
        {
        __peer.super$addFocusListener(l);
        }
    public void addItem(Object item)
        {
        __peer.super$addItem(item);
        }
    public void addItemListener(java.awt.event.ItemListener l)
        {
        __peer.super$addItemListener(l);
        }
    public void addKeyListener(java.awt.event.KeyListener l)
        {
        __peer.super$addKeyListener(l);
        }
    public void addMouseListener(java.awt.event.MouseListener l)
        {
        __peer.super$addMouseListener(l);
        }
    public void addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        __peer.super$addMouseMotionListener(l);
        }
    public void addNotify()
        {
        __peer.super$addNotify();
        }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        __peer.super$addPropertyChangeListener(l);
        }
    public void addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        __peer.super$addVetoableChangeListener(l);
        }
    public javax.swing.JToolTip createToolTip()
        {
        return __peer.super$createToolTip();
        }
    public void doLayout()
        {
        __peer.super$doLayout();
        }
    public java.awt.Color getBackground()
        {
        return __peer.super$getBackground();
        }
    public javax.swing.border.Border getBorder()
        {
        return __peer.super$getBorder();
        }
    public java.awt.Rectangle getBounds()
        {
        return __peer.super$getBounds();
        }
    public java.awt.Cursor getCursor()
        {
        return __peer.super$getCursor();
        }
    public java.awt.Font getFont()
        {
        return __peer.super$getFont();
        }
    public java.awt.Color getForeground()
        {
        return __peer.super$getForeground();
        }
    public java.awt.Insets getInsets()
        {
        return __peer.super$getInsets();
        }
    public java.awt.LayoutManager getLayout()
        {
        return __peer.super$getLayout();
        }
    public java.awt.Point getLocation()
        {
        return __peer.super$getLocation();
        }
    public java.awt.Point getLocationOnScreen()
        {
        return __peer.super$getLocationOnScreen();
        }
    public java.awt.Dimension getMaximumSize()
        {
        return __peer.super$getMaximumSize();
        }
    public java.awt.Dimension getMinimumSize()
        {
        return __peer.super$getMinimumSize();
        }
    public java.awt.Dimension getPreferredSize()
        {
        return __peer.super$getPreferredSize();
        }
    public java.awt.Dimension getSize()
        {
        return __peer.super$getSize();
        }
    public Object getItemAt(int index)
        {
        return __peer.super$getItemAt(index);
        }
    public int getItemCount()
        {
        return __peer.super$getItemCount();
        }
    public int getMaximumRowCount()
        {
        return __peer.super$getMaximumRowCount();
        }
    public int getSelectedIndex()
        {
        return __peer.super$getSelectedIndex();
        }
    public Object getSelectedItem()
        {
        return __peer.super$getSelectedItem();
        }
    public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent e)
        {
        return __peer.super$getToolTipLocation(e);
        }
    public String getToolTipText()
        {
        return __peer.super$getToolTipText();
        }
    public String getToolTipText(java.awt.event.MouseEvent e)
        {
        return __peer.super$getToolTipText(e);
        }
    public void insertItemAt(Object item, int index)
        {
        __peer.super$insertItemAt(item, index);
        }
    public boolean getAutoscrolls()
        {
        return __peer.super$getAutoscrolls();
        }
    public boolean isEditable()
        {
        return __peer.super$isEditable();
        }
    public boolean isEnabled()
        {
        return __peer.super$isEnabled();
        }
    public boolean isFocusTraversable()
        {
        return __peer.super$isFocusTraversable();
        }
    public boolean isLightWeightPopupEnabled()
        {
        return __peer.super$isLightWeightPopupEnabled();
        }
    public boolean isOpaque()
        {
        return __peer.super$isOpaque();
        }
    public boolean isPopupVisible()
        {
        return __peer.super$isPopupVisible();
        }
    public boolean isShowing()
        {
        return __peer.super$isShowing();
        }
    public boolean isVisible()
        {
        return __peer.super$isVisible();
        }
    public void paint(java.awt.Graphics g)
        {
        __peer.super$paint(g);
        }
    public void paintBorder(java.awt.Graphics g)
        {
        __peer.super$paintBorder(g);
        }
    public void paintChildren(java.awt.Graphics g)
        {
        __peer.super$paintChildren(g);
        }
    public void paintComponent(java.awt.Graphics g)
        {
        __peer.super$paintComponent(g);
        }
    public void removeActionListener(java.awt.event.ActionListener l)
        {
        __peer.super$removeActionListener(l);
        }
    public void removeAllItems()
        {
        __peer.super$removeAllItems();
        }
    public void removeFocusListener(java.awt.event.FocusListener l)
        {
        __peer.super$removeFocusListener(l);
        }
    public void removeItemAt(int index)
        {
        __peer.super$removeItemAt(index);
        }
    public void removeItemListener(java.awt.event.ItemListener l)
        {
        __peer.super$removeItemListener(l);
        }
    public void removeKeyListener(java.awt.event.KeyListener l)
        {
        __peer.super$removeKeyListener(l);
        }
    public void removeMouseListener(java.awt.event.MouseListener l)
        {
        __peer.super$removeMouseListener(l);
        }
    public void removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        __peer.super$removeMouseMotionListener(l);
        }
    public void removeNotify()
        {
        __peer.super$removeNotify();
        }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        __peer.super$removePropertyChangeListener(l);
        }
    public void removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        __peer.super$removeVetoableChangeListener(l);
        }
    public void requestFocus()
        {
        __peer.super$requestFocus();
        }
    public void setBackground(java.awt.Color p_Background)
        {
        __peer.super$setBackground(p_Background);
        }
    public void setBorder(javax.swing.border.Border p_Border)
        {
        __peer.super$setBorder(p_Border);
        }
    public void setBounds(java.awt.Rectangle p_Bounds)
        {
        __peer.super$setBounds(p_Bounds);
        }
    public void setCursor(java.awt.Cursor p_Cursor)
        {
        __peer.super$setCursor(p_Cursor);
        }
    public void setFont(java.awt.Font p_Font)
        {
        __peer.super$setFont(p_Font);
        }
    public void setForeground(java.awt.Color p_Foreground)
        {
        __peer.super$setForeground(p_Foreground);
        }
    public void setLayout(java.awt.LayoutManager p_Layout)
        {
        __peer.super$setLayout(p_Layout);
        }
    public void setLocation(java.awt.Point p_Location)
        {
        __peer.super$setLocation(p_Location);
        }
    public void setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        __peer.super$setMaximumSize(p_MaximumSize);
        }
    public void setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        __peer.super$setMinimumSize(p_MinimumSize);
        }
    public void setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        __peer.super$setPreferredSize(p_PreferredSize);
        }
    public void setSize(java.awt.Dimension p_Size)
        {
        __peer.super$setSize(p_Size);
        }
    public void setAutoscrolls(boolean pAutoscrolls)
        {
        __peer.super$setAutoscrolls(pAutoscrolls);
        }
    public void setEditable(boolean pEditable)
        {
        __peer.super$setEditable(pEditable);
        }
    public void setEnabled(boolean pEnabled)
        {
        __peer.super$setEnabled(pEnabled);
        }
    public void setLightWeightPopupEnabled(boolean pLightWeightPopupEnabled)
        {
        __peer.super$setLightWeightPopupEnabled(pLightWeightPopupEnabled);
        }
    public void setMaximumRowCount(int pMaximumRowCount)
        {
        __peer.super$setMaximumRowCount(pMaximumRowCount);
        }
    public void setOpaque(boolean pOpaque)
        {
        __peer.super$setOpaque(pOpaque);
        }
    public void setPopupVisible(boolean pPopupVisible)
        {
        __peer.super$setPopupVisible(pPopupVisible);
        }
    public void setSelectedIndex(int pSelectedIndex)
        {
        __peer.super$setSelectedIndex(pSelectedIndex);
        }
    public void setSelectedItem(Object pSelectedItem)
        {
        __peer.super$setSelectedItem(pSelectedItem);
        }
    public void setToolTipText(String pToolTipText)
        {
        __peer.super$setToolTipText(pToolTipText);
        }
    public void setVisible(boolean pVisible)
        {
        __peer.super$setVisible(pVisible);
        }
    public void updateUI()
        {
        __peer.super$updateUI();
        }
    public void validate()
        {
        __peer.super$validate();
        }
    }
