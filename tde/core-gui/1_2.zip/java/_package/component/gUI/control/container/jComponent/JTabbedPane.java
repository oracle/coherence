/* Class
*     _package.component.gUI.control.container.jComponent.JTabbedPane
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.Rectangle;
import _package.component.gUI.control.container.jComponent.jPanel.TabbedPanel;
import _package.component.gUI.image.Icon;
import com.tangosol.run.component.EventDeathException;
import java.awt.Component; // as _Control
import java.util.Enumeration;
import javax.swing.JPanel; // as _JPanel
import javax.swing.JTabbedPane; // as _JTabbedPane
import javax.swing.plaf.TabbedPaneUI;

/*
* Integrates
*     javax.swing.JTabbedPane
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JTabbedPane
        extends    _package.component.gUI.control.container.JComponent
        implements javax.swing.event.ChangeListener
    {
    // Fields declarations
    
    /**
    * Property SelectedTab
    *
    * Specifies the currently selected tab (TabbedPanel).
    */
    private transient _package.component.gUI.control.container.jComponent.jPanel.TabbedPanel __m_SelectedTab;
    
    /**
    * Property TabCount
    *
    * (Calculated) Specifies the total tab count.
    */
    
    /**
    * Property TabPlacement
    *
    * Specifies the tabs placement mode:
    * 
    * TOP = 1
    * LEFT = 2
    * BOTTOM  = 3
    * RIGHT = 4
    */
    private transient int __m_TabPlacement;
    
    /**
    * Property TabRunCount
    *
    * (Calculated) Specifies the number of "runs" that the tabs are arranged in.
    */
    
    // fields used by the integration model:
    private sink_JTabbedPane __sink;
    private javax.swing.JTabbedPane __feed;
    
    // Default constructor
    public JTabbedPane()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JTabbedPane(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setTabPlacement(1);
            setTConstraints("Center");
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JTabbedPane.__tloPeer.setObject(this);
            new jb_JTabbedPane(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        super.__initEvents();
        
        addChangeListener(this);
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JTabbedPane();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JTabbedPane".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ ChangeListener dispatcher
    private com.tangosol.util.Listeners __ChangeListeners;
    private void addChangeListener$Router(javax.swing.event.ChangeListener l)
        {
        __sink.addChangeListener(l);
        }
    public void addChangeListener(javax.swing.event.ChangeListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __ChangeListeners;
        if (_listeners == null)
            {
            __ChangeListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addChangeListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeChangeListener$Router(javax.swing.event.ChangeListener l)
        {
        __sink.removeChangeListener(l);
        }
    public void removeChangeListener(javax.swing.event.ChangeListener l)
        {
        com.tangosol.util.Listeners _listeners = __ChangeListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeChangeListener$Router(this);
            }
        }
    private void stateChanged$Dispatch(javax.swing.event.ChangeEvent e)
        {
        java.util.EventListener[] targets = __ChangeListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.ChangeListener target = (javax.swing.event.ChangeListener) targets[i];
            if (target != this)
                {
                target.stateChanged(e);
                }
            }
        }
    public void stateChanged(javax.swing.event.ChangeEvent e)
        {
        // import com.tangosol.run.component.EventDeathException;
        
        try
            {
            if (is_Constructed())
                {
                onSelectionChanged();
                }
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        stateChanged$Dispatch(e);
        }
    //-- ChangeListener dispatcher
    
    //++ javax.swing.JTabbedPane integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JTabbedPane) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JTabbedPane) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    /**
    * Returns the string to be used as the tooltip for <i>event</i>.  By
    * default this returns a value of ToolTipText property.  If a component
    * provides more extensive API to support differing tooltips at different
    * locations, this method should be overridden.
    */
    public String getToolTipText(java.awt.event.MouseEvent e)
        {
        // to work around swing's bug that assumes that assureRectsCreated
        // was called before the call to getToolTipText(e)
        // we force javax.swing.plaf.basic.BasicTabbedPaneUI.assureRectsCreated()
        // by calling doLayout()...
        // TODO: remove when swing is fixed!
        doLayout();
        return super.getToolTipText(e);
        }
    public int getTabCount()
        {
        return __sink.getTabCount();
        }
    public int getTabPlacement()
        {
        return __sink.getTabPlacement();
        }
    public int getTabRunCount()
        {
        return __sink.getTabRunCount();
        }
    public void setTabPlacement(int pTabPlacement)
        {
        __sink.setTabPlacement(pTabPlacement);
        }
    //-- javax.swing.JTabbedPane integration
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.TabbedPanel;
        // import javax.swing.JTabbedPane as _JTabbedPane;

        }
    
    // Declared at the super level
    /**
    * Adds the visual feed of the specified child component to the visual feed
    * of this container. Having this functionality separate from _addChild
    * allows it to be overwritten by containers that know better.
    * 
    * @see #_addChild
    */
    public void addControl(_package.component.gUI.Control child)
        {
        // import Component.GUI.Image.Icon;
        
        if (child instanceof TabbedPanel)
            {
            TabbedPanel         tab = (TabbedPanel) child;
            java.awt.Component _tab = tab.getAWTContainee(true);
        
            if (_tab != null)
                {
                Icon    icon     = tab.getIcon();
                String  title    = tab.getTitle();
                String  tip      = tab.getToolTipText();
                int     index    = tab.getIndex();
                boolean fEnabled = tab.isEnabled();
        
                _JTabbedPane _feed = (_JTabbedPane) get_Feed();
        
                if (index < 0 || index >= _feed.getTabCount())
                    {
                    _feed.addTab(title, icon, _tab, tip);
                    }
                else
                    {
                    _feed.insertTab(title, icon, _tab, tip, index);
                    }
        
                if (!fEnabled)
                    {
                    // "Enabled" property works correctly only after
                    // a tab is added to the tabbed pane
                    tab.setEnabled(false);
                    }
                }
            }
        else
            {
            super.addControl(child);
            }
        }
    
    // Accessor for the property "SelectedTab"
    public _package.component.gUI.control.container.jComponent.jPanel.TabbedPanel getSelectedTab()
        {
        // import java.awt.Component as _Control;
        // import java.util.Enumeration;
        
        _Control _sel = ((_JTabbedPane) get_Feed()).getSelectedComponent();
        
        for (Enumeration enum = _enumChildren(); enum.hasMoreElements();)
            {
            try
                {
                TabbedPanel tab = (TabbedPanel) enum.nextElement();
        
                if (tab.get_Feed() == _sel)
                    {
                    return tab;
                    }
                }
            catch (ClassCastException e) {}
            }
        return null;

        }
    
    /**
    * Returns a tab (TabbedPanel) at the specified index.
    * 
    * @param iTab index of the tab
    * @return TabbedPanel component for the specified index
    * 
    * @throw ArrayIndexOutOfBoundsException if iTab is an invalid tab index.
    */
    public _package.component.gUI.control.container.jComponent.jPanel.TabbedPanel getTabAt(int iTab)
        {
        // import java.awt.Component as _Control;
        
        _Control _tab = ((_JTabbedPane) get_Feed()).getComponentAt(iTab);
        
        return (TabbedPanel) _findFeed(_tab);
        }
    
    /**
    * Gets the rectangular bounds for the specified tab.
    * 
    * @param iTab tab index to get the bounds for
    * @return Rectangle component for the specified tab.
    * 
    * @throw ArrayIndexOutOfBoundsException if iTab is an invalid tab index.
    */
    public _package.component.gUI.Rectangle getTabBounds(int iTab)
        {
        // import Component.GUI.Rectangle;
        // import javax.swing.plaf.TabbedPaneUI;
        
        _JTabbedPane _pane = (_JTabbedPane) get_Feed();
        TabbedPaneUI _ui   = (TabbedPaneUI) _pane.getUI();
        
        return Rectangle.instantiate(_ui.getTabBounds(_pane, iTab));
        }
    
    /**
    * Moves a tab from position iTabFrom to a position iTabTo.
    */
    public void moveTab(int iTabFrom, int iTabTo)
        {
        int cTabs = getTabCount();
        if (iTabFrom >= cTabs || iTabFrom < 0 || iTabTo >= cTabs)
            {
            throw new IllegalArgumentException("Illegal tab positions");
            }
        
        if (iTabTo < 0)
            {
            iTabTo = cTabs - 1;
            }
        
        if (iTabTo == iTabFrom)
            {
            return;
            }
        
        _JTabbedPane _pane = (_JTabbedPane) get_Feed();
        
        TabbedPanel tabFrom = getTabAt(iTabFrom);
        
        _pane.removeTabAt(iTabFrom);
        
        // compensate fo the swing.JTabbedPane bug that gets confused if the
        // newly inserted tab will have an index of the currently selected one
        // TODO: remove when the bug is fixed
        
        int iSelected = _pane.getSelectedIndex();
        
        _pane.insertTab(tabFrom.getTitle(), tabFrom.getIcon(),
            (javax.swing.JPanel) tabFrom.get_Feed(), tabFrom.getToolTipText(),
            iTabTo);
        
        if (iTabTo == iSelected)
            {
            _pane.setSelectedIndex(iSelected + 1);
            }
        }
    
    /**
    * Notification specifying the change of current selection.
    * 
    * @see #stateChanged
    */
    public void onSelectionChanged()
        {
        TabbedPanel tab = getSelectedTab();
        if (tab != null)
            {
            tab.onSelected();
            }
        }
    
    // Declared at the super level
    /**
    * Prepares to transfer something at the specified location for the
    * specified action
    * 
    * @return true if transfer is going to be accepted; false otherwise
    * 
    * @see dragOver()
    */
    protected boolean prepareTransferAtLocation(_package.component.gUI.Point point, int iAction, java.util.List listFlavors)
        {
        // if something gets dragged into an inactive tab -- select it
        
        TabbedPanel tab = tabForLocation(point);
        
        if (tab != null && tab.isEnabled() && !tab.isSelected())
            {
            tab.setSelected(true);
            }
        
        return false;
        }
    
    // Declared at the super level
    /**
    * @see #_removeChild
    */
    public void removeControl(_package.component.gUI.Control child)
        {
        if (child instanceof TabbedPanel)
            {
            TabbedPanel tab = (TabbedPanel) child;
            ((_JTabbedPane) get_Feed()).removeTabAt(tab.getIndex());
            }
        else
            {
            super.removeControl(child);
            }
        }
    
    // Accessor for the property "SelectedTab"
    public void setSelectedTab(_package.component.gUI.control.container.jComponent.jPanel.TabbedPanel pSelectedTab)
        {
        // import javax.swing.JPanel as _JPanel;
        
        ((_JTabbedPane) get_Feed()).
            setSelectedComponent((_JPanel) pSelectedTab.get_Feed());
        }
    
    /**
    * Finds a tab (TabbedPanel) at the specified location.
    * 
    * @param point coordinates to look at
    * 
    * @return TabbedPanel component at the specified coordinates or null if not
    * found
    */
    public _package.component.gUI.control.container.jComponent.jPanel.TabbedPanel tabForLocation(_package.component.gUI.Point point)
        {
        // import javax.swing.plaf.TabbedPaneUI;
        
        _JTabbedPane _pane = (_JTabbedPane) get_Feed();
        TabbedPaneUI _ui   = (TabbedPaneUI) _pane.getUI();
        
        int iTab = _ui.tabForCoordinate(_pane, point.getX(), point.getY());
        return iTab >= 0 ? getTabAt(iTab) : null;
        }
    }
