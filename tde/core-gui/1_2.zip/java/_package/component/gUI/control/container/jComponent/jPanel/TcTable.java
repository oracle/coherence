/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.TcTable
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.gUI.control.container.jComponent.JTable;

/**
* This is an extended JTable "custom control" that incorporates the Table, the
* Label and the Toolbar
*/
public class TcTable
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property Addable
    *
    */
    private boolean __m_Addable;
    
    /**
    * Property AllowRemoveNoneditable
    *
    */
    private boolean __m_AllowRemoveNoneditable;
    
    /**
    * Property Removable
    *
    */
    private boolean __m_Removable;
    
    /**
    * Property Table
    *
    * Helper property that gives an easy access to the table
    */
    
    /**
    * Property Toolbar
    *
    * Helper property that gives an easy access to the toolbar
    */
    
    // Default constructor
    public TcTable()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TcTable(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(true);
            setTBounds("0,90,200,120");
            setTConstraints("Center");
            setTLayout("BorderLayout");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new TcTable$Header("Header", this, true), "Header");
        _addChild(new TcTable$Table("Table", this, true), "Table");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new TcTable();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/TcTable".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent.JTable;
        

        }
    
    /**
    * Add a new row to the table.
    */
    public void addRow()
        {
        JTable table = getTable();
        if (table.isEnabled())
            {
            int iRow = table.getRowCount();
            table.addRow(table.getDefaultRowValues());
            table.requestFocus();
            table.setSelectedRow(iRow);
        
            int cColumns = table.getColumnCount();
            for (int iCol = 0; iCol < cColumns; iCol++)
                {
                if (table.getColumn(iCol).isEditable())
                    {
                    table.editCellAt(iRow, iCol);
                    break;
                    }
                }
            }
        else
            {
            _beep();
            }
        }
    
    // Accessor for the property "Table"
    public _package.component.gUI.control.container.jComponent.JTable getTable()
        {
        return (JTable) _findChild("Table");
        }
    
    // Accessor for the property "Toolbar"
    public _package.component.gUI.control.container.jComponent.JPanel getToolbar()
        {
        return (Component.GUI.Control.Container.JComponent.JPanel)
            _findName("Header$Toolbar");
        }
    
    // Accessor for the property "Addable"
    public boolean isAddable()
        {
        return __m_Addable;
        }
    
    // Accessor for the property "AllowRemoveNoneditable"
    public boolean isAllowRemoveNoneditable()
        {
        return __m_AllowRemoveNoneditable;
        }
    
    // Accessor for the property "Removable"
    public boolean isRemovable()
        {
        return __m_Removable;
        }
    
    public boolean isRowRemovable(int iRow)
        {
        JTable table = getTable();
        
        if (iRow < 0 || iRow >= table.getRowCount() || !table.isEnabled())
            {
            return false;
            }
        
        if (!isAllowRemoveNoneditable())
            {
            int cCol = table.getColumnCount();
            for (int iCol = 0; iCol < cCol; iCol++)
                {
                if (!table.isCellEditable(iRow, iCol))
                    {
                    return false;
                    }
                }
            }
        return true;
        }
    
    /**
    * Remove a selected row from the table.
    */
    public void removeRow()
        {
        JTable  table = getTable();
        int     iRow  = table.getSelectedRow();
        
        if (iRow >= 0 && isRowRemovable(iRow))
            {
            table.removeRow(iRow);
            }
        else
            {
            _beep();
            }
        }
    
    // Accessor for the property "Addable"
    public void setAddable(boolean pAddable)
        {
        __m_Addable = (pAddable);
        
        (($Header$Toolbar$Add) _findName("Header$Toolbar$Add")).
            setEnabled(pAddable);
        }
    
    // Accessor for the property "AllowRemoveNoneditable"
    public void setAllowRemoveNoneditable(boolean pAllowRemoveNoneditable)
        {
        __m_AllowRemoveNoneditable = pAllowRemoveNoneditable;
        }
    
    // Declared at the super level
    public void setEnabled(boolean pEnabled)
        {
        super.setEnabled(pEnabled);
        
        getTable()  .setEnabled(pEnabled);
        getToolbar().setEnabled(pEnabled);
        }
    
    // Accessor for the property "Removable"
    public void setRemovable(boolean pRemovable)
        {
        __m_Removable = (pRemovable);
        
        (($Header$Toolbar$Remove) _findName("Header$Toolbar$Remove")).
            setEnabled(pRemovable);
        }
    }
