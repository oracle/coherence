/* Class
*      jb_JTextArea
*
* automatically generated "Feed" which
* a) extends an external bean:
*      javax.swing.JTextArea
* b) delegates to the peer component:
*      Component.GUI.Control.Container.JComponent.JTextComponent.JTextArea
*/

package _package.component.gUI.control.container.jComponent.jTextComponent;

public class jb_JTextArea
        extends    javax.swing.JTextArea
        implements com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected JTextArea __peer;
    
    private static JTextArea __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            JTextArea peer = (JTextArea)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // default (JavaBean) constructor
    public jb_JTextArea()
        {
        this(JTextArea.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTextArea(int Param_1, int Param_2)
        {
        this(Param_1, Param_2, JTextArea.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTextArea(String Param_1)
        {
        this(Param_1, JTextArea.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTextArea(String Param_1, int Param_2, int Param_3)
        {
        this(Param_1, Param_2, Param_3, JTextArea.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTextArea(javax.swing.text.Document Param_1)
        {
        this(Param_1, JTextArea.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTextArea(javax.swing.text.Document Param_1, String Param_2, int Param_3, int Param_4)
        {
        this(Param_1, Param_2, Param_3, Param_4, JTextArea.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTextArea(Class clzPeer)
        {
        this(__createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTextArea(int Param_1, int Param_2, Class clzPeer)
        {
        this(Param_1, Param_2, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTextArea(String Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTextArea(String Param_1, int Param_2, int Param_3, Class clzPeer)
        {
        this(Param_1, Param_2, Param_3, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTextArea(javax.swing.text.Document Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTextArea(javax.swing.text.Document Param_1, String Param_2, int Param_3, int Param_4, Class clzPeer)
        {
        this(Param_1, Param_2, Param_3, Param_4, __createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTextArea(JTextArea peer, boolean fInit)
        {
        super();
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTextArea(int Param_1, int Param_2, JTextArea peer, boolean fInit)
        {
        super(Param_1, Param_2);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTextArea(String Param_1, JTextArea peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTextArea(String Param_1, int Param_2, int Param_3, JTextArea peer, boolean fInit)
        {
        super(Param_1, Param_2, Param_3);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTextArea(javax.swing.text.Document Param_1, JTextArea peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTextArea(javax.swing.text.Document Param_1, String Param_2, int Param_3, int Param_4, JTextArea peer, boolean fInit)
        {
        super(Param_1, Param_2, Param_3, Param_4);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private JTextArea __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (JTextArea) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_JTextArea(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    public void add(java.awt.Component comp, Object constraints, int index)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._add(comp, constraints, index);
        }
    void super$add(java.awt.Component comp, Object constraints, int index)
        {
        super.add(comp, constraints, index);
        }
    public void remove(java.awt.Component comp)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._remove(comp);
        }
    void super$remove(java.awt.Component comp)
        {
        super.remove(comp);
        }
    public void addCaretListener(javax.swing.event.CaretListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addCaretListener(l);
        }
    void super$addCaretListener(javax.swing.event.CaretListener l)
        {
        super.addCaretListener(l);
        }
    public void addFocusListener(java.awt.event.FocusListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addFocusListener(l);
        }
    void super$addFocusListener(java.awt.event.FocusListener l)
        {
        super.addFocusListener(l);
        }
    public void addInputMethodListener(java.awt.event.InputMethodListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addInputMethodListener(l);
        }
    void super$addInputMethodListener(java.awt.event.InputMethodListener l)
        {
        super.addInputMethodListener(l);
        }
    public void addKeyListener(java.awt.event.KeyListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addKeyListener(l);
        }
    void super$addKeyListener(java.awt.event.KeyListener l)
        {
        super.addKeyListener(l);
        }
    public void addMouseListener(java.awt.event.MouseListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseListener(l);
        }
    void super$addMouseListener(java.awt.event.MouseListener l)
        {
        super.addMouseListener(l);
        }
    public void addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseMotionListener(l);
        }
    void super$addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.addMouseMotionListener(l);
        }
    public void addNotify()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addNotify();
        }
    void super$addNotify()
        {
        super.addNotify();
        }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addPropertyChangeListener(l);
        }
    void super$addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.addPropertyChangeListener(l);
        }
    public void addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addVetoableChangeListener(l);
        }
    void super$addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.addVetoableChangeListener(l);
        }
    public void copy()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.copy();
        }
    void super$copy()
        {
        super.copy();
        }
    public javax.swing.JToolTip createToolTip()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.createToolTip();
        }
    javax.swing.JToolTip super$createToolTip()
        {
        return super.createToolTip();
        }
    public void cut()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.cut();
        }
    void super$cut()
        {
        super.cut();
        }
    public void doLayout()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.doLayout();
        }
    void super$doLayout()
        {
        super.doLayout();
        }
    public java.awt.Color getBackground()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Background();
        }
    java.awt.Color super$getBackground()
        {
        return super.getBackground();
        }
    public javax.swing.border.Border getBorder()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Border();
        }
    javax.swing.border.Border super$getBorder()
        {
        return super.getBorder();
        }
    public java.awt.Rectangle getBounds()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Bounds();
        }
    java.awt.Rectangle super$getBounds()
        {
        return super.getBounds();
        }
    public java.awt.Cursor getCursor()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Cursor();
        }
    java.awt.Cursor super$getCursor()
        {
        return super.getCursor();
        }
    public java.awt.Color getDisabledTextColor()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_DisabledTextColor();
        }
    java.awt.Color super$getDisabledTextColor()
        {
        return super.getDisabledTextColor();
        }
    public javax.swing.text.Document getDocument()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Document();
        }
    javax.swing.text.Document super$getDocument()
        {
        return super.getDocument();
        }
    public java.awt.Font getFont()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Font();
        }
    java.awt.Font super$getFont()
        {
        return super.getFont();
        }
    public java.awt.Color getForeground()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Foreground();
        }
    java.awt.Color super$getForeground()
        {
        return super.getForeground();
        }
    public java.awt.Insets getInsets()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Insets();
        }
    java.awt.Insets super$getInsets()
        {
        return super.getInsets();
        }
    public java.awt.LayoutManager getLayout()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Layout();
        }
    java.awt.LayoutManager super$getLayout()
        {
        return super.getLayout();
        }
    public java.awt.Point getLocation()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Location();
        }
    java.awt.Point super$getLocation()
        {
        return super.getLocation();
        }
    public java.awt.Point getLocationOnScreen()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_LocationOnScreen();
        }
    java.awt.Point super$getLocationOnScreen()
        {
        return super.getLocationOnScreen();
        }
    public java.awt.Dimension getMaximumSize()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MaximumSize();
        }
    java.awt.Dimension super$getMaximumSize()
        {
        return super.getMaximumSize();
        }
    public java.awt.Dimension getMinimumSize()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MinimumSize();
        }
    java.awt.Dimension super$getMinimumSize()
        {
        return super.getMinimumSize();
        }
    public java.awt.Dimension getPreferredSize()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_PreferredSize();
        }
    java.awt.Dimension super$getPreferredSize()
        {
        return super.getPreferredSize();
        }
    public java.awt.Dimension getSize()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Size();
        }
    java.awt.Dimension super$getSize()
        {
        return super.getSize();
        }
    public int getCaretPosition()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getCaretPosition();
        }
    int super$getCaretPosition()
        {
        return super.getCaretPosition();
        }
    public char getFocusAccelerator()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getFocusAccelerator();
        }
    char super$getFocusAccelerator()
        {
        return super.getFocusAccelerator();
        }
    public int getLineCount()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getLineCount();
        }
    int super$getLineCount()
        {
        return super.getLineCount();
        }
    protected int getRowHeight()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getRowHeight();
        }
    int super$getRowHeight()
        {
        return super.getRowHeight();
        }
    public String getSelectedText()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectedText();
        }
    String super$getSelectedText()
        {
        return super.getSelectedText();
        }
    public int getSelectionEnd()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectionEnd();
        }
    int super$getSelectionEnd()
        {
        return super.getSelectionEnd();
        }
    public int getSelectionStart()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectionStart();
        }
    int super$getSelectionStart()
        {
        return super.getSelectionStart();
        }
    public int getTabSize()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getTabSize();
        }
    int super$getTabSize()
        {
        return super.getTabSize();
        }
    public String getText()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getText();
        }
    String super$getText()
        {
        return super.getText();
        }
    public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent e)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipLocation(e);
        }
    java.awt.Point super$getToolTipLocation(java.awt.event.MouseEvent e)
        {
        return super.getToolTipLocation(e);
        }
    public String getToolTipText()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText();
        }
    String super$getToolTipText()
        {
        return super.getToolTipText();
        }
    public String getToolTipText(java.awt.event.MouseEvent e)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText(e);
        }
    String super$getToolTipText(java.awt.event.MouseEvent e)
        {
        return super.getToolTipText(e);
        }
    public int getRows()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getVisibleRows();
        }
    int super$getRows()
        {
        return super.getRows();
        }
    public boolean getAutoscrolls()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isAutoscrolls();
        }
    boolean super$getAutoscrolls()
        {
        return super.getAutoscrolls();
        }
    public boolean isEditable()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isEditable();
        }
    boolean super$isEditable()
        {
        return super.isEditable();
        }
    public boolean isEnabled()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isEnabled();
        }
    boolean super$isEnabled()
        {
        return super.isEnabled();
        }
    public boolean isFocusTraversable()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isFocusTraversable();
        }
    boolean super$isFocusTraversable()
        {
        return super.isFocusTraversable();
        }
    public boolean getLineWrap()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isLineWrap();
        }
    boolean super$getLineWrap()
        {
        return super.getLineWrap();
        }
    public boolean isOpaque()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isOpaque();
        }
    boolean super$isOpaque()
        {
        return super.isOpaque();
        }
    public boolean isShowing()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isShowing();
        }
    boolean super$isShowing()
        {
        return super.isShowing();
        }
    public boolean isVisible()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isVisible();
        }
    boolean super$isVisible()
        {
        return super.isVisible();
        }
    public boolean getWrapStyleWord()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isWrapStyleWord();
        }
    boolean super$getWrapStyleWord()
        {
        return super.getWrapStyleWord();
        }
    public void paint(java.awt.Graphics g)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paint(g);
        }
    void super$paint(java.awt.Graphics g)
        {
        super.paint(g);
        }
    protected void paintBorder(java.awt.Graphics g)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintBorder(g);
        }
    void super$paintBorder(java.awt.Graphics g)
        {
        super.paintBorder(g);
        }
    protected void paintChildren(java.awt.Graphics g)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintChildren(g);
        }
    void super$paintChildren(java.awt.Graphics g)
        {
        super.paintChildren(g);
        }
    protected void paintComponent(java.awt.Graphics g)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintComponent(g);
        }
    void super$paintComponent(java.awt.Graphics g)
        {
        super.paintComponent(g);
        }
    public void paste()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paste();
        }
    void super$paste()
        {
        super.paste();
        }
    public void removeCaretListener(javax.swing.event.CaretListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeCaretListener(l);
        }
    void super$removeCaretListener(javax.swing.event.CaretListener l)
        {
        super.removeCaretListener(l);
        }
    public void removeFocusListener(java.awt.event.FocusListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeFocusListener(l);
        }
    void super$removeFocusListener(java.awt.event.FocusListener l)
        {
        super.removeFocusListener(l);
        }
    public void removeInputMethodListener(java.awt.event.InputMethodListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeInputMethodListener(l);
        }
    void super$removeInputMethodListener(java.awt.event.InputMethodListener l)
        {
        super.removeInputMethodListener(l);
        }
    public void removeKeyListener(java.awt.event.KeyListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeKeyListener(l);
        }
    void super$removeKeyListener(java.awt.event.KeyListener l)
        {
        super.removeKeyListener(l);
        }
    public void removeMouseListener(java.awt.event.MouseListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseListener(l);
        }
    void super$removeMouseListener(java.awt.event.MouseListener l)
        {
        super.removeMouseListener(l);
        }
    public void removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseMotionListener(l);
        }
    void super$removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.removeMouseMotionListener(l);
        }
    public void removeNotify()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeNotify();
        }
    void super$removeNotify()
        {
        super.removeNotify();
        }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removePropertyChangeListener(l);
        }
    void super$removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.removePropertyChangeListener(l);
        }
    public void removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeVetoableChangeListener(l);
        }
    void super$removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.removeVetoableChangeListener(l);
        }
    public void replaceSelection(String sContent)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.replaceSelection(sContent);
        }
    void super$replaceSelection(String sContent)
        {
        super.replaceSelection(sContent);
        }
    public void requestFocus()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.requestFocus();
        }
    void super$requestFocus()
        {
        super.requestFocus();
        }
    public void select(int ofStart, int ofEnd)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.select(ofStart, ofEnd);
        }
    void super$select(int ofStart, int ofEnd)
        {
        super.select(ofStart, ofEnd);
        }
    public void selectAll()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.selectAll();
        }
    void super$selectAll()
        {
        super.selectAll();
        }
    public void setBackground(java.awt.Color p_Background)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Background(p_Background);
        }
    void super$setBackground(java.awt.Color p_Background)
        {
        super.setBackground(p_Background);
        }
    public void setBorder(javax.swing.border.Border p_Border)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Border(p_Border);
        }
    void super$setBorder(javax.swing.border.Border p_Border)
        {
        super.setBorder(p_Border);
        }
    public void setBounds(java.awt.Rectangle p_Bounds)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Bounds(p_Bounds);
        }
    void super$setBounds(java.awt.Rectangle p_Bounds)
        {
        super.setBounds(p_Bounds);
        }
    public void setCursor(java.awt.Cursor p_Cursor)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Cursor(p_Cursor);
        }
    void super$setCursor(java.awt.Cursor p_Cursor)
        {
        super.setCursor(p_Cursor);
        }
    public void setDisabledTextColor(java.awt.Color p_DisabledTextColor)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_DisabledTextColor(p_DisabledTextColor);
        }
    void super$setDisabledTextColor(java.awt.Color p_DisabledTextColor)
        {
        super.setDisabledTextColor(p_DisabledTextColor);
        }
    public void setDocument(javax.swing.text.Document p_Document)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Document(p_Document);
        }
    void super$setDocument(javax.swing.text.Document p_Document)
        {
        super.setDocument(p_Document);
        }
    public void setFont(java.awt.Font p_Font)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Font(p_Font);
        }
    void super$setFont(java.awt.Font p_Font)
        {
        super.setFont(p_Font);
        }
    public void setForeground(java.awt.Color p_Foreground)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Foreground(p_Foreground);
        }
    void super$setForeground(java.awt.Color p_Foreground)
        {
        super.setForeground(p_Foreground);
        }
    public void setLayout(java.awt.LayoutManager p_Layout)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Layout(p_Layout);
        }
    void super$setLayout(java.awt.LayoutManager p_Layout)
        {
        super.setLayout(p_Layout);
        }
    public void setLocation(java.awt.Point p_Location)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Location(p_Location);
        }
    void super$setLocation(java.awt.Point p_Location)
        {
        super.setLocation(p_Location);
        }
    public void setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MaximumSize(p_MaximumSize);
        }
    void super$setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        super.setMaximumSize(p_MaximumSize);
        }
    public void setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MinimumSize(p_MinimumSize);
        }
    void super$setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        super.setMinimumSize(p_MinimumSize);
        }
    public void setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_PreferredSize(p_PreferredSize);
        }
    void super$setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        super.setPreferredSize(p_PreferredSize);
        }
    public void setSize(java.awt.Dimension p_Size)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Size(p_Size);
        }
    void super$setSize(java.awt.Dimension p_Size)
        {
        super.setSize(p_Size);
        }
    public void setAutoscrolls(boolean pAutoscrolls)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setAutoscrolls(pAutoscrolls);
        }
    void super$setAutoscrolls(boolean pAutoscrolls)
        {
        super.setAutoscrolls(pAutoscrolls);
        }
    public void setCaretPosition(int pCaretPosition)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setCaretPosition(pCaretPosition);
        }
    void super$setCaretPosition(int pCaretPosition)
        {
        super.setCaretPosition(pCaretPosition);
        }
    public void setEditable(boolean pEditable)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setEditable(pEditable);
        }
    void super$setEditable(boolean pEditable)
        {
        super.setEditable(pEditable);
        }
    public void setEnabled(boolean pEnabled)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setEnabled(pEnabled);
        }
    void super$setEnabled(boolean pEnabled)
        {
        super.setEnabled(pEnabled);
        }
    public void setFocusAccelerator(char pFocusAccelerator)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setFocusAccelerator(pFocusAccelerator);
        }
    void super$setFocusAccelerator(char pFocusAccelerator)
        {
        super.setFocusAccelerator(pFocusAccelerator);
        }
    public void setLineWrap(boolean pLineWrap)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setLineWrap(pLineWrap);
        }
    void super$setLineWrap(boolean pLineWrap)
        {
        super.setLineWrap(pLineWrap);
        }
    public void setOpaque(boolean pOpaque)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setOpaque(pOpaque);
        }
    void super$setOpaque(boolean pOpaque)
        {
        super.setOpaque(pOpaque);
        }
    public void setSelectionEnd(int pSelectionEnd)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setSelectionEnd(pSelectionEnd);
        }
    void super$setSelectionEnd(int pSelectionEnd)
        {
        super.setSelectionEnd(pSelectionEnd);
        }
    public void setSelectionStart(int pSelectionStart)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setSelectionStart(pSelectionStart);
        }
    void super$setSelectionStart(int pSelectionStart)
        {
        super.setSelectionStart(pSelectionStart);
        }
    public void setTabSize(int pTabSize)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setTabSize(pTabSize);
        }
    void super$setTabSize(int pTabSize)
        {
        super.setTabSize(pTabSize);
        }
    public void setText(String pText)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setText(pText);
        }
    void super$setText(String pText)
        {
        super.setText(pText);
        }
    public void setToolTipText(String pToolTipText)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setToolTipText(pToolTipText);
        }
    void super$setToolTipText(String pToolTipText)
        {
        super.setToolTipText(pToolTipText);
        }
    public void setVisible(boolean pVisible)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVisible(pVisible);
        }
    void super$setVisible(boolean pVisible)
        {
        super.setVisible(pVisible);
        }
    public void setRows(int pVisibleRows)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVisibleRows(pVisibleRows);
        }
    void super$setRows(int pVisibleRows)
        {
        super.setRows(pVisibleRows);
        }
    public void setWrapStyleWord(boolean pWrapStyleWord)
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setWrapStyleWord(pWrapStyleWord);
        }
    void super$setWrapStyleWord(boolean pWrapStyleWord)
        {
        super.setWrapStyleWord(pWrapStyleWord);
        }
    public void updateUI()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.updateUI();
        }
    void super$updateUI()
        {
        super.updateUI();
        }
    public void validate()
        {
        JTextArea peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.validate();
        }
    void super$validate()
        {
        super.validate();
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
