/* Class
*     _package.component.gUI.control.container.jComponent.abstractButton.JMenuItem
*/

package _package.component.gUI.control.container.jComponent.abstractButton;

import _package.component.gUI.control.container.jComponent.JMenuBar;
import _package.component.gUI.control.container.jComponent.JPopupMenu;
import _package.component.gUI.control.container.jComponent.abstractButton.jMenuItem.JMenu;
import com.tangosol.run.component.EventDeathException;
import javax.swing.JMenuItem; // as _JMenuItem

/*
* Integrates
*     javax.swing.JMenuItem
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*
* We don't map the MenuDragMouseListener and MenuKeyListener dispatches because
* they are basically identical to MouseListener and KeyListener dispatches.
* 
* @see javax.swing.JMenuItem#processMouseEvent
* @see javax.swing.JMenuItem#processKeyEvent
*
*/
public class JMenuItem
        extends    _package.component.gUI.control.container.jComponent.AbstractButton
    {
    // Fields declarations
    
    /**
    * Property Armed
    *
    * Specifies whether the menu item is "armed". If the mouse button is
    * released while it is over this item, the menu's action event will fire.
    * If the mouse button is released elsewhere, the event will not fire and
    * the menu item will be disarmed.
    */
    private transient boolean __m_Armed;
    
    // fields used by the integration model:
    private sink_JMenuItem __sink;
    private javax.swing.JMenuItem __feed;
    
    // Default constructor
    public JMenuItem()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JMenuItem(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setTFont("DefaultMenu");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JMenuItem.__tloPeer.setObject(this);
            new jb_JMenuItem(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JMenuItem();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/abstractButton/JMenuItem".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JMenuItem integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JMenuItem) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JMenuItem) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public boolean isArmed()
        {
        return __sink.isArmed();
        }
    public void setArmed(boolean pArmed)
        {
        __sink.setArmed(pArmed);
        }
    //-- javax.swing.JMenuItem integration
    
    // Declared at the super level
    public void _imports()
        {
        // import javax.swing.JMenuItem as _JMenuItem;
        // import com.tangosol.run.component.EventDeathException;
        
        

        }
    
    // Declared at the super level
    public void actionPerformed(java.awt.event.ActionEvent e)
        {
        // import Component.GUI.Control.Container.JComponent.JPopupMenu;
        
        // If the menu item belongs to a Popup menu, the relative location of the mouse
        // pointer could change (due to swing's re-porsitioning of the popup)
        // causing an undesired action.
        //
        // To fix that, we register the selected item with the parent popup
        // on "stateChange" and don't fire the action if there was no "selection"
        //
        // Related problem was reported (bug id 4362997: Inconvenient displaying of pop-up menu)
        // but is said to be of a tool...
        
        Component parent = get_Parent();
        if (parent instanceof JPopupMenu)
            {
            JPopupMenu popup = (JPopupMenu) parent;
            if (popup.getSelectedItem() != this)
                {
                // _trace("Ignoring the action " + e.getActionCommand());
                return;
                }
            }
        
        super.actionPerformed(e);
        }
    
    // Declared at the super level
    public void mousePressed(java.awt.event.MouseEvent e)
        {
        registerSelection();
        
        super.mousePressed(e);
        }
    
    // Declared at the super level
    /**
    * This notification (called by actionPerformed) is sent when an armed item
    * (Armed == true) gets unpressed (Pressed == false). This also could be a
    * result of an "accelerator key" action.
    * 
    * Note: setting the Selected property to true (calling setSelected(true))
    * does not trigger an Action event. However, calling doClick() does.
    * 
    * @param action  content of this component's ActionComand property
    * @param modifiers  the key modifier that was selected, and is used to
    * determine the state of the selected key
    * @param param  currently not used (intended for for event-logging and for
    * debugging)
    * 
    * @see #onItemStateChanged
    * @see #onStateChanged
    * @see javax.swing.DefaultButtonModel#setPressed
    */
    public void onAction(String action, int modifiers, String param)
        {
        // import Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem.JMenu;
        // import Component.GUI.Control.Container.JComponent.JMenuBar;
        // import Component.GUI.Control.Container.JComponent.JPopupMenu;
        
        super.onAction(action, modifiers, param);
        
        // if the parent is a JMenu, JMenuBar or JPopupMenu let them know as well
        
        Component parent = get_Parent();
        
        if (parent instanceof JMenu)
            {
            ((JMenu) parent).onAction(action, modifiers, param);
            }
        else if (parent instanceof JMenuBar)
            {
            ((JMenuBar) parent).onAction(action, modifiers, param);
            }
        else if (parent instanceof JPopupMenu)
            {
            ((JPopupMenu) parent).onAction(action, modifiers, param);
            }
        }
    
    // Declared at the super level
    /**
    * Method notification (called by itemStateChanged) is sent when the
    * Selected property of an item changes its value
    * 
    * @param item  an AbstractButton item that originated the event
    * @param state  STATE_SELECTED if the Selected property value has changed
    * to true; STATE_DESELECTED otherwise
    * 
    * @see #onStateChanged
    */
    public void onItemStateChanged(_package.component.gUI.control.container.jComponent.AbstractButton item, int state)
        {
        // import Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem.JMenu;
        // import Component.GUI.Control.Container.JComponent.JMenuBar;
        
        super.onItemStateChanged(item, state);
        
        // if the parent is a JMenu, let it know that a child item
        // has changed its state
        
        Component parent = get_Parent();
        if (parent instanceof JMenu)
            {
            ((JMenu) parent).onItemStateChanged(item, state | JMenu.STATE_CHILD);
            }
        else if (parent instanceof JMenuBar)
            {
            ((JMenuBar) parent).onItemStateChanged(item, state | JMenu.STATE_CHILD);
            }

        }
    
    private void registerSelection()
        {
        // import Component.GUI.Control.Container.JComponent.JPopupMenu;
        
        Component parent = get_Parent();
        if (parent instanceof JPopupMenu)
            {
            JPopupMenu popup = (JPopupMenu) parent;
            if (popup.isVisible())
                {
                // see actionPerformed
                popup.setSelectedItem(this);
                }
            }

        }
    
    // Declared at the super level
    public void stateChanged(javax.swing.event.ChangeEvent e)
        {
        if (isArmed())
            {
            registerSelection();
            }
        
        super.stateChanged(e);
        }
    }
