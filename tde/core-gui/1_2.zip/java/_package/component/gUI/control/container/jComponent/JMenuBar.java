/* Class
*     _package.component.gUI.control.container.jComponent.JMenuBar
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.Insets;

/*
* Integrates
*     javax.swing.JMenuBar
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JMenuBar
        extends    _package.component.gUI.control.container.JComponent
    {
    // Fields declarations
    
    /**
    * Property _Margin
    *
    */
    private java.awt.Insets __m__Margin;
    
    /**
    * Property BorderPainted
    *
    */
    private transient boolean __m_BorderPainted;
    
    /**
    * Property Margin
    *
    * Specifies the margin between the menubar's border and its menus. Setting
    * to null will cause the menubar to use the default margins.
    */
    private transient _package.component.gUI.Insets __m_Margin;
    
    /**
    * Property Selected
    *
    */
    
    // fields used by the integration model:
    private sink_JMenuBar __sink;
    private javax.swing.JMenuBar __feed;
    
    // Default constructor
    public JMenuBar()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JMenuBar(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JMenuBar.__tloPeer.setObject(this);
            new jb_JMenuBar(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JMenuBar();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JMenuBar".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JMenuBar integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JMenuBar) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JMenuBar) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public java.awt.Insets get_Margin()
        {
        return __sink.getMargin();
        }
    public boolean isBorderPainted()
        {
        return __sink.isBorderPainted();
        }
    public boolean isSelected()
        {
        return __sink.isSelected();
        }
    public void setBorderPainted(boolean pBorderPainted)
        {
        __sink.setBorderPainted(pBorderPainted);
        }
    public void set_Margin(java.awt.Insets p_Margin)
        {
        __sink.setMargin(p_Margin);
        }
    //-- javax.swing.JMenuBar integration
    
    // Accessor for the property "Margin"
    public _package.component.gUI.Insets getMargin()
        {
        // import Component.GUI.Insets;
        Insets margin = new Insets();
        margin.set_Insets(get_Margin());
        return margin;
        }
    
    /**
    * A notification that gets called by the onAction event of a contained
    * JMenuItem.
    * 
    * @see JMenuItem#onAction
    */
    public void onAction(String action, int modifiers, String param)
        {
        }
    
    /**
    * A notification that gets called by the onItemStateChanged event of a
    * contained JMenuItem.
    * 
    * @see JMenuItem#onItemStateChanged
    */
    public void onItemStateChanged(AbstractButton item, int state)
        {
        }
    
    // Accessor for the property "Margin"
    public void setMargin(_package.component.gUI.Insets pMargin)
        {
        set_Margin(pMargin.get_Insets());
        }
    }
