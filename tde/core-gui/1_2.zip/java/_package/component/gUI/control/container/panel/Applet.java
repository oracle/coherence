/* Class
*     _package.component.gUI.control.container.panel.Applet
*/

package _package.component.gUI.control.container.panel;

/*
* Integrates
*     java.applet.Applet
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class Applet
        extends    _package.component.gUI.control.container.Panel
    {
    // Fields declarations
    
    /**
    * Property Active
    *
    */
    
    /**
    * Property AppletInfo
    *
    */
    
    /**
    * Property ParameterInfo
    *
    */
    
    /**
    * Property Status
    *
    */
    
    // fields used by the integration model:
    private sink_Applet __sink;
    private java.applet.Applet __feed;
    
    // Default constructor
    public Applet()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Applet(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_Applet.__tloPeer.setObject(this);
            new jb_Applet(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Applet();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/panel/Applet".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.applet.Applet integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_Applet) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (java.applet.Applet) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    private void destroy$Router()
        {
        __sink.destroy();
        }
    public void destroy()
        {
        System.out.println(">>>> destroying applet...");
        destroy$Router();
        }
    public java.applet.AppletContext getAppletContext()
        {
        return __sink.getAppletContext();
        }
    public String getAppletInfo()
        {
        return __sink.getAppletInfo();
        }
    public java.applet.AudioClip getAudioClip(java.net.URL url)
        {
        return __sink.getAudioClip(url);
        }
    public java.applet.AudioClip getAudioClip(java.net.URL url, String name)
        {
        return __sink.getAudioClip(url, name);
        }
    public java.net.URL getCodeBase()
        {
        return __sink.getCodeBase();
        }
    public java.net.URL getDocumentBase()
        {
        return __sink.getDocumentBase();
        }
    public java.awt.Image getImage(java.net.URL url)
        {
        return __sink.getImage(url);
        }
    public java.awt.Image getImage(java.net.URL url, String name)
        {
        return __sink.getImage(url, name);
        }
    public String getParameter(String name)
        {
        return __sink.getParameter(name);
        }
    public String[][] getParameterInfo()
        {
        return __sink.getParameterInfo();
        }
    private void init$Router()
        {
        __sink.init();
        }
    public void init()
        {
        System.out.println(">>>> initing applet");
        init$Router();
        }
    public boolean isActive()
        {
        return __sink.isActive();
        }
    public void play(java.net.URL url)
        {
        __sink.play(url);
        }
    public void play(java.net.URL url, String name)
        {
        __sink.play(url, name);
        }
    public void setStatus(String pStatus)
        {
        __sink.showStatus(pStatus);
        }
    private void start$Router()
        {
        __sink.start();
        }
    public void start()
        {
        System.out.println(">>>> starting applet...");
        start$Router();
        }
    private void stop$Router()
        {
        __sink.stop();
        }
    public void stop()
        {
        System.out.println(">>>> stopping applet...");
        stop$Router();
        }
    //-- java.applet.Applet integration
    }
