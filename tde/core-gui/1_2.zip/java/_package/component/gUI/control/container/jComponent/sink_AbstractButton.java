/* Class
*      sink_AbstractButton
*
* automatically generated "Sink" which
* represents a footprint of the class
*      javax.swing.AbstractButton
* when used as a component callback by 
*      Component.GUI.Control.Container.JComponent.AbstractButton
*/

package _package.component.gUI.control.container.jComponent;

public abstract class sink_AbstractButton
       extends _package.component.gUI.control.container.sink_JComponent
    {
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_AbstractButton()
        {
        }
    
    // methods integrated and/or remoted
    public abstract void add(java.awt.Component comp, Object constraints, int index);
    public abstract void remove(java.awt.Component comp);
    public abstract void addActionListener(java.awt.event.ActionListener l);
    public abstract void addChangeListener(javax.swing.event.ChangeListener l);
    public abstract void addFocusListener(java.awt.event.FocusListener l);
    public abstract void addItemListener(java.awt.event.ItemListener l);
    public abstract void addKeyListener(java.awt.event.KeyListener l);
    public abstract void addMouseListener(java.awt.event.MouseListener l);
    public abstract void addMouseMotionListener(java.awt.event.MouseMotionListener l);
    public abstract void addNotify();
    public abstract void addPropertyChangeListener(java.beans.PropertyChangeListener l);
    public abstract void addVetoableChangeListener(java.beans.VetoableChangeListener l);
    public abstract javax.swing.JToolTip createToolTip();
    public abstract void doClick();
    public abstract void doClick(int iPressTime);
    public abstract void doLayout();
    public abstract java.awt.Color getBackground();
    public abstract javax.swing.border.Border getBorder();
    public abstract java.awt.Rectangle getBounds();
    public abstract java.awt.Cursor getCursor();
    public abstract javax.swing.Icon getDisabledIcon();
    public abstract javax.swing.Icon getDisabledSelectedIcon();
    public abstract java.awt.Font getFont();
    public abstract java.awt.Color getForeground();
    public abstract javax.swing.Icon getIcon();
    public abstract java.awt.Insets getInsets();
    public abstract java.awt.LayoutManager getLayout();
    public abstract java.awt.Point getLocation();
    public abstract java.awt.Point getLocationOnScreen();
    public abstract java.awt.Insets getMargin();
    public abstract java.awt.Dimension getMaximumSize();
    public abstract java.awt.Dimension getMinimumSize();
    public abstract int getMnemonic();
    public abstract java.awt.Dimension getPreferredSize();
    public abstract javax.swing.Icon getPressedIcon();
    public abstract javax.swing.Icon getRolloverIcon();
    public abstract javax.swing.Icon getRolloverSelectedIcon();
    public abstract javax.swing.Icon getSelectedIcon();
    public abstract java.awt.Dimension getSize();
    public abstract String getActionCommand();
    public abstract int getHorizontalAlignment();
    public abstract int getHorizontalTextPosition();
    public abstract String getText();
    public abstract java.awt.Point getToolTipLocation(java.awt.event.MouseEvent e);
    public abstract String getToolTipText();
    public abstract String getToolTipText(java.awt.event.MouseEvent e);
    public abstract int getVerticalAlignment();
    public abstract int getVerticalTextPosition();
    public abstract boolean getAutoscrolls();
    public abstract boolean isEnabled();
    public abstract boolean isFocusPainted();
    public abstract boolean isFocusTraversable();
    public abstract boolean isOpaque();
    public abstract boolean isRolloverEnabled();
    public abstract boolean isSelected();
    public abstract boolean isShowing();
    public abstract boolean isVisible();
    public abstract void paint(java.awt.Graphics g);
    public abstract void paintBorder(java.awt.Graphics g);
    public abstract void paintChildren(java.awt.Graphics g);
    public abstract void paintComponent(java.awt.Graphics g);
    public abstract void removeActionListener(java.awt.event.ActionListener l);
    public abstract void removeChangeListener(javax.swing.event.ChangeListener l);
    public abstract void removeFocusListener(java.awt.event.FocusListener l);
    public abstract void removeItemListener(java.awt.event.ItemListener l);
    public abstract void removeKeyListener(java.awt.event.KeyListener l);
    public abstract void removeMouseListener(java.awt.event.MouseListener l);
    public abstract void removeMouseMotionListener(java.awt.event.MouseMotionListener l);
    public abstract void removeNotify();
    public abstract void removePropertyChangeListener(java.beans.PropertyChangeListener l);
    public abstract void removeVetoableChangeListener(java.beans.VetoableChangeListener l);
    public abstract void requestFocus();
    public abstract void setBackground(java.awt.Color p_Background);
    public abstract void setBorder(javax.swing.border.Border p_Border);
    public abstract void setBounds(java.awt.Rectangle p_Bounds);
    public abstract void setCursor(java.awt.Cursor p_Cursor);
    public abstract void setDisabledIcon(javax.swing.Icon p_DisabledIcon);
    public abstract void setDisabledSelectedIcon(javax.swing.Icon p_DisabledSelectedIcon);
    public abstract void setFont(java.awt.Font p_Font);
    public abstract void setForeground(java.awt.Color p_Foreground);
    public abstract void setIcon(javax.swing.Icon p_Icon);
    public abstract void setLayout(java.awt.LayoutManager p_Layout);
    public abstract void setLocation(java.awt.Point p_Location);
    public abstract void setMargin(java.awt.Insets p_Margin);
    public abstract void setMaximumSize(java.awt.Dimension p_MaximumSize);
    public abstract void setMinimumSize(java.awt.Dimension p_MinimumSize);
    public abstract void setMnemonic(int p_Mnemonic);
    public abstract void setPreferredSize(java.awt.Dimension p_PreferredSize);
    public abstract void setPressedIcon(javax.swing.Icon p_PressedIcon);
    public abstract void setRolloverIcon(javax.swing.Icon p_RolloverIcon);
    public abstract void setRolloverSelectedIcon(javax.swing.Icon p_RolloverSelectedIcon);
    public abstract void setSelectedIcon(javax.swing.Icon p_SelectedIcon);
    public abstract void setSize(java.awt.Dimension p_Size);
    public abstract void setActionCommand(String pActionCommand);
    public abstract void setAutoscrolls(boolean pAutoscrolls);
    public abstract void setEnabled(boolean pEnabled);
    public abstract void setFocusPainted(boolean pFocusPainted);
    public abstract void setHorizontalAlignment(int pHorizontalAlignment);
    public abstract void setHorizontalTextPosition(int pHorizontalTextPosition);
    public abstract void setMnemonic(char pMnemonic);
    public abstract void setOpaque(boolean pOpaque);
    public abstract void setRolloverEnabled(boolean pRolloverEnabled);
    public abstract void setSelected(boolean pSelected);
    public abstract void setText(String pText);
    public abstract void setToolTipText(String pToolTipText);
    public abstract void setVerticalAlignment(int pVerticalAlignment);
    public abstract void setVerticalTextPosition(int pVerticalTextPosition);
    public abstract void setVisible(boolean pVisible);
    public abstract void updateUI();
    public abstract void validate();
    }
