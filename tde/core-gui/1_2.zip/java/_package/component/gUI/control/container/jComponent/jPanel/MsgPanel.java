/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.MsgPanel
*/

package _package.component.gUI.control.container.jComponent.jPanel;

/**
* The entire concept has to be re-thought and possibly re-done
*/
public class MsgPanel
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property MsgText
    *
    * Text of the message
    */
    private String __m_MsgText;
    
    /**
    * Property MsgType
    *
    * Type of the message (temporary?).
    * 
    * The possible values are:
    * DEFAULT_OPTION = -1;
    * YES_NO_OPTION = 0;
    * YES_NO_CANCEL_OPTION = 1;
    * OK_CANCEL_OPTION = 2;
    * 
    * @see javax.swing.JOption
    */
    private int __m_MsgType;
    
    // Default constructor
    public MsgPanel()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public MsgPanel(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAutoscrolls(false);
            setFocusable(true);
            setLayout(null);
            setResizable(false);
            setTConstraints("Center");
            setTLayout("BorderLayout");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new MsgPanel$JL_Msg("JL_Msg", this, true), "JL_Msg");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new MsgPanel();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/MsgPanel".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "MsgText"
    public String getMsgText()
        {
        return __m_MsgText;
        }
    
    // Accessor for the property "MsgType"
    public int getMsgType()
        {
        return __m_MsgType;
        }
    
    // Declared at the super level
    /**
    * The "component has been added to a containing component"
    * method-notification.
    * 
    * Note: this notification is not sent during the component's state
    * initialization (deserialization)
    * 
    * @see _addChild
    */
    public void onAdd()
        {
        super.onAdd();
        
        Object[] dlgPrm = (Object[]) getDialogParam();
        
        switch (dlgPrm.length)
            {
            default:
            case 3:
                Integer intMsgType = (Integer) dlgPrm[2];
                if (intMsgType != null)
                    {
                    setMsgType(intMsgType.intValue());
                    }
                // fall through
            case 2:
                String sTitle = (String) dlgPrm[1];
                if (sTitle != null)
                    {
                    setTitle(sTitle);
                    }
                // fall through
            case 1:
                String sMsg = (String) dlgPrm[0];
                if (sMsg != null)
                    {   
                    setMsgText(sMsg);
                    }
                // fall through
            case 0:
                break;
            }
        }
    
    // Accessor for the property "MsgText"
    public void setMsgText(String pMsgText)
        {
        __m_MsgText = (pMsgText);
        
        MsgPanel$JL_Msg JL_Msg = (MsgPanel$JL_Msg) _findName("JL_Msg");
        JL_Msg.setText(pMsgText);

        }
    
    // Accessor for the property "MsgType"
    public void setMsgType(int pMsgType)
        {
        __m_MsgType = pMsgType;
        }
    }
