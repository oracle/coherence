/* Class
*     _package.component.gUI.control.container.jComponent.JInternalFrame
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.Dimension;
import _package.component.gUI.Insets;
import _package.component.gUI.Point;
import _package.component.gUI.Rectangle;
import _package.component.gUI.control.container.jComponent.JDesktopPane;
import _package.component.gUI.control.container.jComponent.JPanel;
import _package.component.gUI.control.container.jComponent.jPanel.MsgPanel;
import _package.component.gUI.image.Icon;
import _package.component.util.Config;
import com.tangosol.run.component.EventDeathException;
import java.awt.Component; // as _Component
import java.beans.PropertyVetoException;
import javax.swing.JButton; // as _JButton
import javax.swing.JComponent; // as _JComponent
import javax.swing.JDesktopPane; // as _JDesktopPane
import javax.swing.JInternalFrame; // as _JInternalFrame
import javax.swing.JMenuBar; // as _JMenuBar
import javax.swing.event.InternalFrameEvent;
import javax.swing.plaf.basic.BasicInternalFrameUI;

/*
* Integrates
*     javax.swing.JInternalFrame
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JInternalFrame
        extends    _package.component.gUI.control.container.JComponent
        implements javax.swing.event.InternalFrameListener
    {
    // Fields declarations
    
    /**
    * Property _FrameIcon
    *
    */
    private transient javax.swing.Icon __m__FrameIcon;
    
    /**
    * Property _TitlePane
    *
    */
    private transient javax.swing.JComponent __m__TitlePane;
    
    /**
    * Property AllowClosing
    *
    * This property controls the way setClosed behaves.
    * 
    * @see #setClosed
    */
    private boolean __m_AllowClosing;
    
    /**
    * Property Closable
    *
    * Specifies whether this JInternalFrame can be closed by some user action. 
    */
    private transient boolean __m_Closable;
    
    /**
    * Property Closed
    *
    * Specifies whether this JInternalFrame is currently closed.
    */
    private transient boolean __m_Closed;
    
    /**
    * Property FrameIcon
    *
    * Specifies an image to be displayed in the titlebar of the frame (usually
    * in the top-left corner).
    */
    private transient _package.component.gUI.image.Icon __m_FrameIcon;
    
    /**
    * Property Iconifiable
    *
    * Specifies whether the JInternalFrame can be made an icon by some user
    * action.
    */
    private transient boolean __m_Iconifiable;
    
    /**
    * Property Iconified
    *
    * Specifies whether this JInternalFrame is currently iconified.
    */
    private transient boolean __m_Iconified;
    
    /**
    * Property Layer
    *
    * Specifes the layer of this JInternalFrame.
    */
    private transient int __m_Layer;
    
    /**
    * Property Maximizable
    *
    * Specifies whether the JInternalFrame can be maximized by some user action.
    */
    private transient boolean __m_Maximizable;
    
    /**
    * Property Maximized
    *
    * Specifies whether this JInternalFrame is currently maximized.
    */
    private transient boolean __m_Maximized;
    
    /**
    * Property Resizable
    *
    * Specifies whether the JInternalFrame is resizable.
    */
    private transient boolean __m_Resizable;
    
    /**
    * Property Selected
    *
    * Specifies whether the JInternalFrame is the currently "selected" or
    * active frame.
    */
    private transient boolean __m_Selected;
    
    /**
    * Property Title
    *
    * Specifies the JInternalFrame title.
    */
    private transient String __m_Title;
    
    // fields used by the integration model:
    private sink_JInternalFrame __sink;
    private javax.swing.JInternalFrame __feed;
    
    // Default constructor
    public JInternalFrame()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JInternalFrame(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAllowClosing(true);
            setClosable(true);
            setFocusable(true);
            setIconifiable(true);
            setMaximizable(true);
            setResizable(true);
            setVisible(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JInternalFrame.__tloPeer.setObject(this);
            new jb_JInternalFrame(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        super.__initEvents();
        
        addInternalFrameListener(this);
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new JInternalFrame();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JInternalFrame".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ InternalFrameListener dispatcher
    private com.tangosol.util.Listeners __InternalFrameListeners;
    private void addInternalFrameListener$Router(javax.swing.event.InternalFrameListener l)
        {
        __sink.addInternalFrameListener(l);
        }
    public void addInternalFrameListener(javax.swing.event.InternalFrameListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __InternalFrameListeners;
        if (_listeners == null)
            {
            __InternalFrameListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addInternalFrameListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeInternalFrameListener$Router(javax.swing.event.InternalFrameListener l)
        {
        __sink.removeInternalFrameListener(l);
        }
    public void removeInternalFrameListener(javax.swing.event.InternalFrameListener l)
        {
        com.tangosol.util.Listeners _listeners = __InternalFrameListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeInternalFrameListener$Router(this);
            }
        }
    private void internalFrameActivated$Dispatch(javax.swing.event.InternalFrameEvent e)
        {
        java.util.EventListener[] targets = __InternalFrameListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.InternalFrameListener target = (javax.swing.event.InternalFrameListener) targets[i];
            if (target != this)
                {
                target.internalFrameActivated(e);
                }
            }
        }
    public void internalFrameActivated(javax.swing.event.InternalFrameEvent e)
        {
        try
            {
            onInternalFrameActivated();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        internalFrameActivated$Dispatch(e);
        }
    private void internalFrameClosed$Dispatch(javax.swing.event.InternalFrameEvent e)
        {
        java.util.EventListener[] targets = __InternalFrameListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.InternalFrameListener target = (javax.swing.event.InternalFrameListener) targets[i];
            if (target != this)
                {
                target.internalFrameClosed(e);
                }
            }
        }
    public void internalFrameClosed(javax.swing.event.InternalFrameEvent e)
        {
        try
            {
            onInternalFrameClosed();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        internalFrameClosed$Dispatch(e);
        }
    private void internalFrameClosing$Dispatch(javax.swing.event.InternalFrameEvent e)
        {
        java.util.EventListener[] targets = __InternalFrameListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.InternalFrameListener target = (javax.swing.event.InternalFrameListener) targets[i];
            if (target != this)
                {
                target.internalFrameClosing(e);
                }
            }
        }
    public void internalFrameClosing(javax.swing.event.InternalFrameEvent e)
        {
        try
            {
            onInternalFrameClosing();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        internalFrameClosing$Dispatch(e);
        }
    private void internalFrameDeactivated$Dispatch(javax.swing.event.InternalFrameEvent e)
        {
        java.util.EventListener[] targets = __InternalFrameListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.InternalFrameListener target = (javax.swing.event.InternalFrameListener) targets[i];
            if (target != this)
                {
                target.internalFrameDeactivated(e);
                }
            }
        }
    public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent e)
        {
        try
            {
            onInternalFrameDeactivated();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        internalFrameDeactivated$Dispatch(e);
        }
    private void internalFrameDeiconified$Dispatch(javax.swing.event.InternalFrameEvent e)
        {
        java.util.EventListener[] targets = __InternalFrameListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.InternalFrameListener target = (javax.swing.event.InternalFrameListener) targets[i];
            if (target != this)
                {
                target.internalFrameDeiconified(e);
                }
            }
        }
    public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent e)
        {
        try
            {
            onInternalFrameDeiconified();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        internalFrameDeiconified$Dispatch(e);
        }
    private void internalFrameIconified$Dispatch(javax.swing.event.InternalFrameEvent e)
        {
        java.util.EventListener[] targets = __InternalFrameListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.InternalFrameListener target = (javax.swing.event.InternalFrameListener) targets[i];
            if (target != this)
                {
                target.internalFrameIconified(e);
                }
            }
        }
    public void internalFrameIconified(javax.swing.event.InternalFrameEvent e)
        {
        try
            {
            onInternalFrameIconified();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        internalFrameIconified$Dispatch(e);
        }
    private void internalFrameOpened$Dispatch(javax.swing.event.InternalFrameEvent e)
        {
        java.util.EventListener[] targets = __InternalFrameListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.InternalFrameListener target = (javax.swing.event.InternalFrameListener) targets[i];
            if (target != this)
                {
                target.internalFrameOpened(e);
                }
            }
        }
    public void internalFrameOpened(javax.swing.event.InternalFrameEvent e)
        {
        try
            {
            onInternalFrameOpened();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        internalFrameOpened$Dispatch(e);
        }
    //-- InternalFrameListener dispatcher
    
    //++ javax.swing.JInternalFrame integration
    // Access optimization
    /**
    * Setter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JInternalFrame) pSink;
        super.set_Sink(pSink);
        }
    /**
    * Setter for property _Feed.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JInternalFrame) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public void _add(java.awt.Component comp, Object constraints, int index)
        {
        ((_JInternalFrame) get_Feed()).getContentPane().add(comp, constraints, index);
        }
    /**
    * Getter for property _Layout.<p>
    */
    public java.awt.LayoutManager get_Layout()
        {
        return ((_JInternalFrame) get_Feed()).getContentPane().getLayout();
        }
    public void updateUI()
        {
        // import java.awt.Component     as _Component;
        // import javax.swing.JButton    as _JButton;
        // import javax.swing.JComponent as _JComponent;
        // import javax.swing.JMenuBar   as _JMenuBar;
        
        // we want to listen to mouse events for the title bar,
        // and the title bar changes when the "look and feel" changes
        
        _JComponent _titlePane = get_TitlePane();
        if (_titlePane != null)
            {
            _titlePane.removeMouseListener(this);
            _titlePane.removeMouseMotionListener(this);
            }
        
        super.updateUI();
        
        _titlePane = get_TitlePane();
        if (_titlePane != null)
            {
            _titlePane.addMouseListener(this);
            _titlePane.addMouseMotionListener(this);
            }
        
        // there is no public access to the System Menu
        // so the only reasonable way to override the JInternalFrameTitlePane
        // functionality is to create and use our own TitlePane component
        
        // the following could be done conditionally, i.e.
        // if (!isAllowSystemMenu())
            {
            _Component[] _components = _titlePane.getComponents();
            for (int i = 0; i < _components.length; i++)
                {
                _Component _c = _components[i];
                if (_c instanceof _JMenuBar)
                    {
                    _JMenuBar _systemMenu = (_JMenuBar) _c;
                    // Windows "look and feel"
                    _systemMenu.removeAll();
                    break;
                    }
                else if (_c instanceof _JButton &&
                         _c.getClass().getName().indexOf("SystemButton") != -1)
                    {
                    // Motiff "look and feel"
                    // TODO: insert a JLabel using the FrameIcon?
                    _titlePane.remove(_c);
                    break;
                    }
                }
            }
        }
    public void dispose()
        {
        __sink.dispose();
        }
    /**
    * Getter for property _FrameIcon.<p>
    */
    public javax.swing.Icon get_FrameIcon()
        {
        return __sink.getFrameIcon();
        }
    /**
    * Getter for property Layer.<p>
    * Specifes the layer of this JInternalFrame.
    */
    public int getLayer()
        {
        return __sink.getLayer();
        }
    /**
    * Getter for property Title.<p>
    * Specifies the JInternalFrame title.
    */
    public String getTitle()
        {
        return __sink.getTitle();
        }
    /**
    * Getter for property Closable.<p>
    * Specifies whether this JInternalFrame can be closed by some user action. 
    */
    public boolean isClosable()
        {
        return __sink.isClosable();
        }
    /**
    * Getter for property Closed.<p>
    * Specifies whether this JInternalFrame is currently closed.
    */
    public boolean isClosed()
        {
        return __sink.isClosed();
        }
    /**
    * Getter for property Iconified.<p>
    * Specifies whether this JInternalFrame is currently iconified.
    */
    public boolean isIconified()
        {
        return __sink.isIcon();
        }
    /**
    * Getter for property Iconifiable.<p>
    * Specifies whether the JInternalFrame can be made an icon by some user
    * action.
    */
    public boolean isIconifiable()
        {
        return __sink.isIconifiable();
        }
    /**
    * Getter for property Maximizable.<p>
    * Specifies whether the JInternalFrame can be maximized by some user action.
    */
    public boolean isMaximizable()
        {
        return __sink.isMaximizable();
        }
    /**
    * Getter for property Maximized.<p>
    * Specifies whether this JInternalFrame is currently maximized.
    */
    public boolean isMaximized()
        {
        return __sink.isMaximum();
        }
    /**
    * Getter for property Resizable.<p>
    * Specifies whether the JInternalFrame is resizable.
    */
    public boolean isResizable()
        {
        return __sink.isResizable();
        }
    /**
    * Getter for property Selected.<p>
    * Specifies whether the JInternalFrame is the currently "selected" or
    * active frame.
    */
    public boolean isSelected()
        {
        return __sink.isSelected();
        }
    public void moveToBack()
        {
        __sink.moveToBack();
        }
    public void moveToFront()
        {
        __sink.moveToFront();
        }
    /**
    * Setter for property Closable.<p>
    * Specifies whether this JInternalFrame can be closed by some user action. 
    */
    public void setClosable(boolean pClosable)
        {
        __sink.setClosable(pClosable);
        }
    private void setClosed$Router(boolean pClosed)
        {
        try
            {
            __sink.setClosed(pClosed);
            }
        catch (java.beans.PropertyVetoException e)
            {
            // re-throw as a runtime exception
            throw new RuntimeException(e.getMessage());
            }
        }
    /**
    * As of JDK 1.2, the only way to dynamically stop "closing" is to intercept
    * "setClosed()" (by not calling super.setClosed(true)) or throw a
    * PropertyVetoException from VetoableChange event (property
    * JInternalFrame.IS_CLOSED_PROPERTY value Bolean.TRUE)
    * 
    * Setting the "Closeable" property doesn't help much, because it prevents
    * the InternalFrameClosing event from being sent.
    * 
    * To overcoome the problem we introduced a new property "AllowClosing" that
    * controls the way "setClosed" behaves. If AllowClosing is not set, the
    * frame is not closed automatically, but instead, the InternalFrameClosing
    * event is invoked that could in turn set the property and call
    * setClosed(true) itself.
    * 
    * Note: the super (integrated class) declares an exception, but we shield
    * it for the ease of use (no one cares anyway -- see
    * javax.swing.plaf.basic.BasicInternalFrameUI)
    */
    public void setClosed(boolean pClosed)
        {
        // import javax.swing.event.InternalFrameEvent;
        
        if (pClosed && !isAllowClosing())
            {
            InternalFrameEvent e = new InternalFrameEvent(
                (javax.swing.JInternalFrame) get_Feed(),
                InternalFrameEvent.INTERNAL_FRAME_CLOSING);
            internalFrameClosing(e);
            }
        else
            {
            setClosed$Router(pClosed);
            }
        }
    /**
    * Setter for property _FrameIcon.<p>
    */
    public void set_FrameIcon(javax.swing.Icon p_FrameIcon)
        {
        __sink.setFrameIcon(p_FrameIcon);
        }
    /**
    * Note: the super (integrated class) declares an exception, but we shield
    * it for the ease of use (no one cares anyway -- see
    * javax.swing.plaf.basic.BasicInternalFrameUI)
    */
    public void setIconified(boolean pIconified)
        {
        try
            {
            __sink.setIcon(pIconified);
            }
        catch (java.beans.PropertyVetoException e)
            {
            // re-throw as a runtime exception
            throw new RuntimeException(e.getMessage());
            }
        }
    /**
    * Setter for property Iconifiable.<p>
    * Specifies whether the JInternalFrame can be made an icon by some user
    * action.
    */
    public void setIconifiable(boolean pIconizable)
        {
        __sink.setIconifiable(pIconizable);
        }
    public void set_Layer(Integer p_Layer)
        {
        __sink.setLayer(p_Layer);
        }
    /**
    * Setter for property Maximizable.<p>
    * Specifies whether the JInternalFrame can be maximized by some user action.
    */
    public void setMaximizable(boolean pMaximizable)
        {
        __sink.setMaximizable(pMaximizable);
        }
    /**
    * Note: the super (integrated class) declares an exception, but we shield
    * it for the ease of use (no one cares anyway -- see
    * javax.swing.plaf.basic.BasicInternalFrameUI)
    */
    public void setMaximized(boolean pMaximized)
        {
        try
            {
            __sink.setMaximum(pMaximized);
            }
        catch (java.beans.PropertyVetoException e)
            {
            // re-throw as a runtime exception
            throw new RuntimeException(e.getMessage());
            }
        }
    /**
    * Setter for property Resizable.<p>
    * Specifies whether the JInternalFrame is resizable.
    */
    public void setResizable(boolean pResizable)
        {
        __sink.setResizable(pResizable);
        }
    private void setSelected$Router(boolean pSelected)
        {
        try
            {
            __sink.setSelected(pSelected);
            }
        catch (java.beans.PropertyVetoException e)
            {
            // re-throw as a runtime exception
            throw new RuntimeException(e.getMessage());
            }
        }
    /**
    * Note: the super (integrated class) declares an exception, but we shield
    * it for the ease of use (no one cares anyway -- see
    * javax.swing.plaf.basic.BasicInternalFrameUI)
    */
    public void setSelected(boolean pSelected)
        {
        // import java.beans.PropertyVetoException;
        // import javax.swing.JDesktopPane as _JDesktopPane;
        
        if (pSelected && !isEnabled())
            {
            // the frame is disabled -- select the topmost one if enabled
        
            _JDesktopPane   _desktop = (_JDesktopPane) get_Parent().get_Feed();
            _JInternalFrame _frame   = _desktop.getAllFrames()[0];
        
            if (_frame.isEnabled())
                {
                try
                    {
                    _frame.setSelected(true);
                    _beep();
                    }
                catch (PropertyVetoException e) {}
                }
            }
        else
            {
            setSelected$Router(pSelected);
            }
        }
    /**
    * Setter for property Title.<p>
    * Specifies the JInternalFrame title.
    */
    public void setTitle(String pTitle)
        {
        __sink.setTitle(pTitle);
        }
    public void toBack()
        {
        __sink.toBack();
        }
    public void toFront()
        {
        __sink.toFront();
        }
    //-- javax.swing.JInternalFrame integration
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent.JDesktopPane;
        // import Component.GUI.Control.Container.JComponent.JPanel;
        // import Component.GUI.Image.Icon;
        // import Component.GUI.Insets;
        // import com.tangosol.run.component.EventDeathException;
        // import javax.swing.JInternalFrame as _JInternalFrame;
        
        

        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        // import Component.GUI.Rectangle;
        // import Component.Util.Config;
        
        JDesktopPane desktop = (JDesktopPane) get_Parent();
        Rectangle    rect    = desktop.getBounds();
        boolean      fValid  = rect.getWidth() > 0 && rect.getHeight() > 0;
        
        if (fValid && config.getBoolean(sPrefix + ".Maximized"))
            {
            setMaximized(true);
            }
        else if (fValid && config.getBoolean(sPrefix + ".Iconified"))
            {
            setIconified(true);
            }
        else
            {
            Config cfgBounds = config.getConfig(sPrefix + ".Bounds");
        
            if (!cfgBounds.isEmpty())
                {
                rect = new Rectangle();
                rect.applyConfig(cfgBounds, "");
                setBounds(rect);
                }
            }
        
        if (config.containsKey(sPrefix + ".Visible"))
            {
            setVisible(config.getBoolean(sPrefix + ".Visible"));
            }
        
        if (config.getBoolean(sPrefix + ".Selected"))
            {
            setSelected(true);
            }
        
        super.applyConfig(config, sPrefix);
        }
    
    // Declared at the super level
    /**
    * Bring up the specified dialog box.
    * 
    * @param panel  the dialog's main panel
    * @param oDialogPrm  dialog parameter (often an array of objects)
    * 
    * @return result of the dialog's execution (value of dialog main panel's
    * property DialogResult)
    * 
    * @see Window#dialogBox
    * @see JDesktopPane#dialogBox
    */
    public Object dialogBox(JPanel panel, Object oDialogPrm)
        {
        return ((JDesktopPane) get_Parent()).dialogBox(this, panel, oDialogPrm);
        }
    
    // Accessor for the property "_TitlePane"
    /**
    * Getter for property _TitlePane.<p>
    */
    public javax.swing.JComponent get_TitlePane()
        {
        // import javax.swing.plaf.basic.BasicInternalFrameUI;
        
        _JInternalFrame      _frame = (_JInternalFrame) get_Feed();
        BasicInternalFrameUI ui     = (BasicInternalFrameUI) _frame.getUI();
        
        return ui != null ? ui.getNorthPane() : null;
        }
    
    // Accessor for the property "FrameIcon"
    /**
    * Getter for property FrameIcon.<p>
    * Specifies an image to be displayed in the titlebar of the frame (usually
    * in the top-left corner).
    */
    public _package.component.gUI.image.Icon getFrameIcon()
        {
        javax.swing.Icon _icon = get_FrameIcon();
        return _icon instanceof Icon ? (Icon) _icon : null;
        }
    
    // Declared at the super level
    /**
    * Getter for property Insets.<p>
    */
    public _package.component.gUI.Insets getInsets()
        {
        Insets insets = super.getInsets();
        
        javax.swing.JComponent titlePane = get_TitlePane();
        if (titlePane != null)
            {
            int height = titlePane.getPreferredSize().height;
        
            // clone the original Insets component before modifying it
            Insets insetsNew = (Insets) insets.clone();
            insetsNew.setTop(insetsNew.getTop() + height);
            insets = insetsNew;
            }
        return insets;
        }
    
    // Declared at the super level
    /**
    * Hosts (adds as a child) the specified JPanel and make the client area of
    * this container equal to the size of the hosted panel.
    * 
    * @see #getHostedPanel
    */
    public void hostPanel(JPanel panel)
        {
        setFrameIcon(panel.getIcon());
        setLocation (panel.getLocation());
        setResizable(panel.isResizable());
        setTitle    (panel.getTitle());
        
        super.hostPanel(panel);
        }
    
    // Accessor for the property "AllowClosing"
    /**
    * Getter for property AllowClosing.<p>
    * This property controls the way setClosed behaves.
    * 
    * @see #setClosed
    */
    public boolean isAllowClosing()
        {
        return __m_AllowClosing;
        }
    
    // Declared at the super level
    public void mouseClicked(java.awt.event.MouseEvent e)
        {
        if (e.getSource() == get_TitlePane())
            {
            // we just listen to the title pane's event
            // and should not dispatch them
            try
                {
                onTitleMouseClicked(e.getX(), e.getY(),
                                    e.getModifiers(), e.getClickCount());
                }
            catch (EventDeathException ex)
                {
                e.consume();
                }
            return;
            }
        
        super.mouseClicked(e);
        }
    
    // Declared at the super level
    public void mouseDragged(java.awt.event.MouseEvent e)
        {
        // see mousePressed() and mouseReleased()
        if (e.getSource() == get_TitlePane())
            {
            // we just listen to the title pane's event
            // and should not dispatch them
            return;
            }
        
        super.mouseDragged(e);
        }
    
    // Declared at the super level
    public void mouseEntered(java.awt.event.MouseEvent e)
        {
        if (e.getSource() == get_TitlePane())
            {
            // we just listen to the title pane's event
            // and should not dispatch them
            return;
            }
        
        super.mouseEntered(e);
        }
    
    // Declared at the super level
    public void mouseExited(java.awt.event.MouseEvent e)
        {
        if (e.getSource() == get_TitlePane())
            {
            // we just listen to the title pane's event
            // and should not dispatch them
            return;
            }
        
        super.mouseExited(e);
        }
    
    // Declared at the super level
    public void mouseMoved(java.awt.event.MouseEvent e)
        {
        if (e.getSource() == get_TitlePane())
            {
            // we just listen to the title pane's event
            // and should not dispatch them
            return;
            }
        
        super.mouseMoved(e);
        }
    
    // Declared at the super level
    public void mousePressed(java.awt.event.MouseEvent e)
        {
        if (e.getSource() == get_TitlePane())
            {
            // we just listen to the title pane's event
            // and should not dispatch them
            try
                {
                onTitleMousePressed(e.getX(), e.getY(), e.getModifiers(),
                                    e.getClickCount(), e.isPopupTrigger());
                }
            catch (EventDeathException ex)
                {
                e.consume();
                }
            return;
            }
        
        super.mousePressed(e);
        }
    
    // Declared at the super level
    public void mouseReleased(java.awt.event.MouseEvent e)
        {
        if (e.getSource() == get_TitlePane())
            {
            // we just listen to the title pane's event
            // and should not dispatch them
        
            try
               {
                onTitleMouseReleased(e.getX(), e.getY(), e.getModifiers(),
                                     e.getClickCount(), e.isPopupTrigger());
                }
            catch (EventDeathException ex)
                {
                e.consume();
                }
            return;
            }
        
        super.mouseReleased(e);
        }
    
    public void moveToView()
        {
        // import Component.GUI.Dimension;
        // import Component.GUI.Point;
        // import Component.GUI.Rectangle;
        
        // ensures that the frame is fully visible in the embracing JDesktopPane
        
        JDesktopPane desktop    = (JDesktopPane) get_Parent();
        Point        ptDesktop  = desktop.getLocation(); // desktop is not scrollable...
        Dimension    dimDesktop = desktop.getSize();
        Point        ptFrame    = this.getLocation();
        Dimension    dimFrame   = this.getSize();
        boolean      fMove      = false;
        
        if (ptFrame.getX() + dimFrame.getWidth() > dimDesktop.getWidth())
            {
            ptFrame.setX(dimDesktop.getWidth() - dimFrame.getWidth());
            fMove = true;
            }
        if (ptFrame.getY() + dimFrame.getHeight() > dimDesktop.getHeight())
            {
            ptFrame.setY(dimDesktop.getHeight() - dimFrame.getHeight());
            fMove = true;
            }
        if (ptFrame.getX() < ptDesktop.getX())
            {
            ptFrame.setX(ptDesktop.getX());
            fMove = true;
            }
        if (ptFrame.getY() < 0)
            {
            ptFrame.setY(ptDesktop.getY());
            fMove = true;
            }
        
        if (fMove)
            {
            this.setLocation(ptFrame);
            }
        }
    
    // Declared at the super level
    /**
    * Brings up a message box specified by the panel name.
    * 
    * @see JFrame#msg
    * @see JDesktopPane#msg
    * The reason we don't implement the "msg" and "dialogBox" at this level but
    * delegate it to the "JDesktopPane" is that under some circumstances, there
    * is no JInternalFrame to own a message (a dialog box)
    */
    public Object msg(String sMsgId, Object oMsgPrm)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.MsgPanel;
        
        if (true) // TODO: temorary hack until I know what to do
            {
            return super.msg(sMsgId, oMsgPrm);
            }
        
        final String MSG_PANEL = "Component.GUI.Control.Container.JComponent.JPanel.MsgPanel.";
        if (!sMsgId.startsWith(MSG_PANEL))
            {
            sMsgId = MSG_PANEL + sMsgId;
            }
        
        return ((JDesktopPane) get_Parent()).dialogBox(this, (MsgPanel) _newInstance(sMsgId), oMsgPrm);
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        super.onInit();
        
        // TODO: fixed in JDK 1.3 -- remove when 1.2 is no longer supported
        // "Closing" event is supposed to be explicitly
        // handled by the "onInternalFrameClosing()" event handler
        // bugID -- http://developer.java.sun.com/developer/bugParade/bugs/4096227.html
        
        _JInternalFrame _frame = (_JInternalFrame) get_Feed();
        _frame.setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        
        
        // regression in JDK 1.3:
        // glass pane is not made visible on initialization
        _frame.getGlassPane().setVisible(true);

        }
    
    /**
    * Method notification invoked when an internal frame is activated.
    */
    public void onInternalFrameActivated()
        {
        }
    
    /**
    * Method notification invoked when an internal frame has been closed.
    * 
    * @see comments to setClosed()
    */
    public void onInternalFrameClosed()
        {
        // it could have already be (or in a process of being)
        // removed or closed
        if (get_Parent() != null && !isClosed())
            {
            get_Parent()._removeChild(this);
            }
        }
    
    /**
    * Method notification invoked when an internal frame is in the process of
    * being closed.
    * 
    * @see comments to setClosed()
    */
    public void onInternalFrameClosing()
        {
        }
    
    /**
    * Method notification invoked when an internal frame is de-activated
    */
    public void onInternalFrameDeactivated()
        {
        }
    
    /**
    * Method notification invoked when an internal frame is restored
    */
    public void onInternalFrameDeiconified()
        {
        }
    
    /**
    * Method notification invoked when an internal frame is minimized
    */
    public void onInternalFrameIconified()
        {
        }
    
    /**
    * Method notification invoked when an internal frame has been opened
    */
    public void onInternalFrameOpened()
        {
        }
    
    public void onTitleMouseClicked(int x, int y, int modifiers, int clickCount)
        {
        }
    
    public void onTitleMousePressed(int x, int y, int modifiers, int clickCount, boolean popupTrigger)
        {
        }
    
    public void onTitleMouseReleased(int x, int y, int modifiers, int clickCount, boolean popupTrigger)
        {
        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        // Note: the PreviousBounds property for DefaultDesktopManger
        // is no accessable (see javax.swing.DefaultDesktopManger#getPreviousBounds)
        
        config.putBoolean(sPrefix + ".Maximized", isMaximized());
        config.putBoolean(sPrefix + ".Iconified", isIconified());
        config.putBoolean(sPrefix + ".Visible",   isVisible());
        config.putBoolean(sPrefix + ".Selected",  isSelected());
        
        getBounds().saveConfig(config, sPrefix + ".Bounds");
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "_TitlePane"
    /**
    * Setter for property _TitlePane.<p>
    */
    public void set_TitlePane(javax.swing.JComponent p_TitlePane)
        {
        _JInternalFrame _frame = (_JInternalFrame) get_Feed();
        
        ((javax.swing.plaf.basic.BasicInternalFrameUI) _frame.getUI()).
            setNorthPane(p_TitlePane);
        }
    
    // Accessor for the property "AllowClosing"
    /**
    * Setter for property AllowClosing.<p>
    * This property controls the way setClosed behaves.
    * 
    * @see #setClosed
    */
    public void setAllowClosing(boolean pAllowClosing)
        {
        __m_AllowClosing = pAllowClosing;
        }
    
    // Accessor for the property "FrameIcon"
    /**
    * Setter for property FrameIcon.<p>
    * Specifies an image to be displayed in the titlebar of the frame (usually
    * in the top-left corner).
    */
    public void setFrameIcon(_package.component.gUI.image.Icon pFrameIcon)
        {
        if (pFrameIcon != null)
            {
            set_FrameIcon(pFrameIcon);
            }
        }
    
    // Accessor for the property "Layer"
    /**
    * Setter for property Layer.<p>
    * Specifes the layer of this JInternalFrame.
    */
    public void setLayer(int pLayer)
        {
        set_Layer(new Integer(pLayer));
        }
    
    // Declared at the super level
    /**
    * Setter for property Layout.<p>
    */
    public void setLayout(_package.component.gUI.LayoutManager pLayout)
        {
        ((_JInternalFrame) get_Feed()).getContentPane().setLayout(pLayout);
        }
    }
