/* Class
*     _package.component.gUI.control.container.jComponent.JTextComponent
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.Color;
import _package.component.gUI.UndoManager;
import _package.component.gUI.control.container.jComponent.jTextComponent.JTextField;
import com.tangosol.run.component.EventDeathException;
import java.awt.Event;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DnDConstants;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.JTextComponent; // as _JTextComponent

/*
* Integrates
*     javax.swing.text.JTextComponent
*     using Component.Dev.Compiler.Integrator.AbstractBean
*/
public abstract class JTextComponent
        extends    _package.component.gUI.control.container.JComponent
        implements java.awt.event.InputMethodListener,
                   javax.swing.event.CaretListener
    {
    // Fields declarations
    
    /**
    * Property _DisabledTextColor
    *
    */
    private transient java.awt.Color __m__DisabledTextColor;
    
    /**
    * Property _Document
    *
    */
    private transient javax.swing.text.Document __m__Document;
    
    /**
    * Property AltDown
    *
    * Temporary property used to workaround bugs 4135578, 4186905, 4248949
    * (Mnemonic character appear in JTextComponents).  Fixed in 1.3.
    * 
    * @see #onKeyPressed
    * @see #onInputTextChanged
    * 
    * TODO: remove when we no longer support 1.2
    */
    private transient boolean __m_AltDown;
    
    /**
    * Property CaretPosition
    *
    * Specifies the position of the text insertion caret for the text component.
    */
    private transient int __m_CaretPosition;
    
    /**
    * Property DisabledTextColor
    *
    * Specifies the current color used to render the disabled text.
    */
    private transient _package.component.gUI.Color __m_DisabledTextColor;
    
    /**
    * Property Editable
    *
    * Specifies whether or not this TextComponent is editable.
    */
    private transient boolean __m_Editable;
    
    /**
    * Property FocusAccelerator
    *
    * Specifies the key accelerator that will cause the receiving text
    * component to get the focus.  The accelerator will be the  key combination
    * of the <em>Alt</em> key and the character given (converted to upper case).
    */
    private transient char __m_FocusAccelerator;
    
    /**
    * Property SelectedText
    *
    * (Calculated) Specifies the selected text contained in this TextComponent.
    */
    
    /**
    * Property SelectionEnd
    *
    * Specifies the selected text's end position.  Returns 0 for an empty
    * document, or the value of dot if there is no selection.
    */
    private transient int __m_SelectionEnd;
    
    /**
    * Property SelectionStart
    *
    * Specifies the selected text's start position.  Returns 0 for an empty
    * document, or the value of dot if there is no selection.
    */
    private transient int __m_SelectionStart;
    
    /**
    * Property Text
    *
    * Specifies the text contained in this TextComponent.
    */
    private transient String __m_Text;
    
    /**
    * Property TextLength
    *
    * The length of the text contained in this TextComponent.
    */
    
    /**
    * Property UndoLimit
    *
    * Specifies the maximum number of edits a corresponding  UndoManager will
    * hold. Value 0 means that there is no UndoManager for this JTextComponent.
    */
    private int __m_UndoLimit;
    
    /**
    * Property UndoManager
    *
    * UndoManager for this component.
    * 
    * @see #setUndoLimit
    */
    private _package.component.gUI.UndoManager __m_UndoManager;
    
    // fields used by the integration model:
    private sink_JTextComponent __sink;
    private javax.swing.text.JTextComponent __feed;
    
    // Initializing constructor
    public JTextComponent(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        super.__initEvents();
        
        addInputMethodListener(this);
        addCaretListener(this);
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JTextComponent".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ InputMethodListener dispatcher
    private com.tangosol.util.Listeners __InputMethodListeners;
    private void addInputMethodListener$Router(java.awt.event.InputMethodListener l)
        {
        __sink.addInputMethodListener(l);
        }
    public void addInputMethodListener(java.awt.event.InputMethodListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __InputMethodListeners;
        if (_listeners == null)
            {
            __InputMethodListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addInputMethodListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeInputMethodListener$Router(java.awt.event.InputMethodListener l)
        {
        __sink.removeInputMethodListener(l);
        }
    public void removeInputMethodListener(java.awt.event.InputMethodListener l)
        {
        com.tangosol.util.Listeners _listeners = __InputMethodListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeInputMethodListener$Router(this);
            }
        }
    private void caretPositionChanged$Dispatch(java.awt.event.InputMethodEvent e)
        {
        java.util.EventListener[] targets = __InputMethodListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.InputMethodListener target = (java.awt.event.InputMethodListener) targets[i];
            if (target != this)
                {
                target.caretPositionChanged(e);
                }
            }
        }
    public void caretPositionChanged(java.awt.event.InputMethodEvent e)
        {
        try
            {
            onCaretPositionChanged();
            }
        catch (EventDeathException x)
            {
            e.consume();
            return;
            }
        
        caretPositionChanged$Dispatch(e);

        }
    private void inputMethodTextChanged$Dispatch(java.awt.event.InputMethodEvent e)
        {
        java.util.EventListener[] targets = __InputMethodListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.InputMethodListener target = (java.awt.event.InputMethodListener) targets[i];
            if (target != this)
                {
                target.inputMethodTextChanged(e);
                }
            }
        }
    public void inputMethodTextChanged(java.awt.event.InputMethodEvent e)
        {
        try
            {
            // TODO: process the AttributedCharacterIterator and
            // pass as a parameter into the event
            onInputTextChanged();
            }
        catch (EventDeathException x)
            {
            e.consume();
            return;
            }
        
        inputMethodTextChanged$Dispatch(e);
        }
    //-- InputMethodListener dispatcher
    
    //++ CaretListener dispatcher
    private com.tangosol.util.Listeners __CaretListeners;
    private void addCaretListener$Router(javax.swing.event.CaretListener l)
        {
        __sink.addCaretListener(l);
        }
    public void addCaretListener(javax.swing.event.CaretListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __CaretListeners;
        if (_listeners == null)
            {
            __CaretListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addCaretListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeCaretListener$Router(javax.swing.event.CaretListener l)
        {
        __sink.removeCaretListener(l);
        }
    public void removeCaretListener(javax.swing.event.CaretListener l)
        {
        com.tangosol.util.Listeners _listeners = __CaretListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeCaretListener$Router(this);
            }
        }
    private void caretUpdate$Dispatch(javax.swing.event.CaretEvent e)
        {
        java.util.EventListener[] targets = __CaretListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.CaretListener target = (javax.swing.event.CaretListener) targets[i];
            if (target != this)
                {
                target.caretUpdate(e);
                }
            }
        }
    public void caretUpdate(javax.swing.event.CaretEvent e)
        {
        try
            {
            onCaretUpdate(e.getDot(), e.getMark());
            }
        catch (EventDeathException x)
            {
            return;
            }
        
        caretUpdate$Dispatch(e);
        }
    //-- CaretListener dispatcher
    
    //++ javax.swing.text.JTextComponent integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JTextComponent) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.text.JTextComponent) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    /**
    * Returns the value of a flag that indicates whether this component can be
    * traversed using Tab or Shift-Tab keyboard focus traversal. If this method
    * returns "false", this component may still request the keyboard focus
    * using <code>requestFocus()</code>, but it will not automatically be
    * assigned focus during tab traversal.
    * 
    * @see #Focusable property
    */
    public boolean isFocusTraversable()
        {
        // TODO: this belongs to swing. Check for a fix.
        return isEditable() ? super.isFocusTraversable() : false;
        }
    public void copy()
        {
        __sink.copy();
        }
    public void cut()
        {
        __sink.cut();
        }
    public int getCaretPosition()
        {
        return __sink.getCaretPosition();
        }
    public java.awt.Color get_DisabledTextColor()
        {
        return __sink.getDisabledTextColor();
        }
    public javax.swing.text.Document get_Document()
        {
        return __sink.getDocument();
        }
    public char getFocusAccelerator()
        {
        return __sink.getFocusAccelerator();
        }
    private String getSelectedText$Router()
        {
        return __sink.getSelectedText();
        }
    public String getSelectedText()
        {
        String sSelection = getSelectedText$Router();
        return sSelection == null ? "" : sSelection;
        }
    public int getSelectionEnd()
        {
        return __sink.getSelectionEnd();
        }
    public int getSelectionStart()
        {
        return __sink.getSelectionStart();
        }
    public String getText()
        {
        return __sink.getText();
        }
    public boolean isEditable()
        {
        return __sink.isEditable();
        }
    public void paste()
        {
        __sink.paste();
        }
    public void replaceSelection(String sContent)
        {
        __sink.replaceSelection(sContent);
        }
    public void select(int ofStart, int ofEnd)
        {
        __sink.select(ofStart, ofEnd);
        }
    public void selectAll()
        {
        __sink.selectAll();
        }
    public void setCaretPosition(int pCaretPosition)
        {
        __sink.setCaretPosition(pCaretPosition);
        }
    public void set_DisabledTextColor(java.awt.Color p_DisabledTextColor)
        {
        __sink.setDisabledTextColor(p_DisabledTextColor);
        }
    public void set_Document(javax.swing.text.Document p_Document)
        {
        __sink.setDocument(p_Document);
        }
    public void setEditable(boolean pEditable)
        {
        __sink.setEditable(pEditable);
        }
    public void setFocusAccelerator(char pFocusAccelerator)
        {
        __sink.setFocusAccelerator(pFocusAccelerator);
        }
    public void setSelectionEnd(int pSelectionEnd)
        {
        __sink.setSelectionEnd(pSelectionEnd);
        }
    public void setSelectionStart(int pSelectionStart)
        {
        __sink.setSelectionStart(pSelectionStart);
        }
    private void setText$Router(String pText)
        {
        __sink.setText(pText);
        }
    public void setText(String pText)
        {
        setText$Router(pText);
        
        UndoManager mgr = getUndoManager();
        if (mgr != null)
            {
            mgr.discardAllEdits();
            }

        }
    //-- javax.swing.text.JTextComponent integration
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.UndoManager;
        // import com.tangosol.run.component.EventDeathException;
        // import javax.swing.text.Document;
        // import javax.swing.text.BadLocationException;
        // import javax.swing.text.JTextComponent as _JTextComponent;
        
        

        }
    
    /**
    * Appends the given text to the end of the document.  Does nothing if  the
    * model is null or the string is null or empty.
    * This method is thread safe, although most Swing methods are not.
    * 
    * @param sText the text to append
    * 
    * @see #insert
    */
    public void append(String sText)
        {
        Document doc = get_Document();
        if (doc != null)
            {
            try
                {
                doc.insertString(doc.getLength(), sText, null);
                }
            catch (BadLocationException e)
                {
                throw new IllegalArgumentException(e.getMessage());
                }
            }
        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        int ofStart = config.getInt(sPrefix + ".SelectionStart", 0);
        int ofEnd   = config.getInt(sPrefix + ".SelectionEnd"  , 0);
        int cLen    = getTextLength();
        
        if (ofStart > cLen)
            {
            ofStart = cLen;
            }
        if (ofEnd < ofStart)
            {
            ofEnd = ofStart;
            }
        select(ofStart, ofEnd);
        
        super.applyConfig(config, sPrefix);
        }
    
    // Accessor for the property "DisabledTextColor"
    public _package.component.gUI.Color getDisabledTextColor()
        {
        // import Component.GUI.Color;
        
        Color color = new Color();
        color.set_Color(get_DisabledTextColor());
        return color;
        }
    
    /**
    * Converts the given place in the view coordinate system to the nearest
    * representative location in the model.
    * The component must have a positive size for this translation to be
    * computed (i.e. layout cannot be computed until the component has been
    * sized).  The component does not have to be visible or painted.
    * 
    * @param pt the location in the view to translate
    * 
    * @return the offset >= 0 from the start of the document, or -1 if the
    * component does not yet have a positive size.
    */
    public int getOffsetAtPoint(_package.component.gUI.Point pt)
        {
        return ((_JTextComponent) get_Feed()).viewToModel(pt.get_Point());
        }
    
    // Accessor for the property "TextLength"
    public int getTextLength()
        {
        // should we instead do:
        // return get_Document().getLength();
        
        return getText().length();
        }
    
    // Accessor for the property "UndoLimit"
    public int getUndoLimit()
        {
        return __m_UndoLimit;
        }
    
    // Accessor for the property "UndoManager"
    public _package.component.gUI.UndoManager getUndoManager()
        {
        return __m_UndoManager;
        }
    
    /**
    * Inserts the specified text at the specified position.  Does nothing if
    * the model is null or if the text is null or empty. This method is thread
    * safe, although most Swing methods are not.
    * 
    * @param sText the text to insert            
    * @param ofPos the position at which to insert >= 0
    * 
    * @exception IllegalArgumentException  if pos is an invalid position in the
    * model
    * 
    * @see #replaceRange
    */
    public void insert(String sText, int ofPos)
        {
        Document doc = get_Document();
        if (doc != null)
            {
            try
                {
                doc.insertString(ofPos, sText, null);
                }
            catch (BadLocationException e)
                {
                throw new IllegalArgumentException(e.getMessage());
                }
            }
        }
    
    // Accessor for the property "AltDown"
    private boolean isAltDown()
        {
        return __m_AltDown;
        }
    
    /**
    * Method-notification invoked when the caret within composed text has
    * changed.
    * 
    * @see #caretPositionChanged
    * @see java.awt.im.InputMethodRequests
    */
    public void onCaretPositionChanged()
        {
        }
    
    /**
    * Method notification specifying that the text caret has changed in the
    * text component.
    * 
    * @param iDot  the location of the caret (>= 0)
    * @param iMark  the location of other end of a logical selection (>= 0). 
    * If there is no selection, this will be the same as dot.
    */
    public void onCaretUpdate(int iDot, int iMark)
        {
        }
    
    /**
    * Method-notification invoked when the text entered through an input method
    * has changed.
    * 
    * @see #inputMehtodTextChanged
    * @see java.awt.im.InputMethodRequests
    */
    public void onInputTextChanged()
        {
        // TODO: Work around JDK bug 4135578 -- fixed in 1.3
        // remove when we no longer support 1.2
        if (isAltDown())
            {
            throw new EventDeathException();
            }
        }
    
    // Declared at the super level
    public void onKeyPressed(char keyChar, int keyCode, int modifiers)
        {
        // import java.awt.Event;
        
        super.onKeyPressed(keyChar, keyCode, modifiers);
        
        // TODO: Work around JDK bug 4135578 -- fixed in 1.3
        // remove when we no longer support 1.2
        String sVersion = System.getProperty("java.version");
        if (sVersion.startsWith("1.2"))
            {
            setAltDown((modifiers & Event.ALT_MASK) != 0);
            }
        }
    
    // Declared at the super level
    /**
    * Prepares to transfer something at the specified location for the
    * specified action
    * 
    * @return true if transfer is going to be accepted; false otherwise
    * 
    * @see dragOver()
    */
    protected boolean prepareTransferAtLocation(_package.component.gUI.Point point, int iAction, java.util.List listFlavors)
        {
        return isEnabled() && isEditable() && getOffsetAtPoint(point) >= 0;
        }
    
    // Declared at the super level
    /**
    * Puts (drops) the specified Transferable object at the specified location
    * for the specified action
    * 
    * @return true if transfer is accepted; false otherwise
    * 
    * @see drop()
    */
    protected boolean putTransferAtLocation(java.awt.datatransfer.Transferable transfer, _package.component.gUI.Point point, int iAction)
        {
        // import Component.GUI.Control.Container.JComponent.JTextComponent.JTextField;
        // import java.awt.datatransfer.DataFlavor;
        // import java.awt.dnd.DnDConstants;
        
        String sValue = null;
        try
            {
            DataFlavor flavor;
            if (transfer.isDataFlavorSupported(DataFlavor.stringFlavor))
                {
                flavor = DataFlavor.stringFlavor;
                }
            else
                {
                flavor = transfer.getTransferDataFlavors()[0];
                }
            sValue = String.valueOf(transfer.getTransferData(flavor));
            }
        // UnsupportedFlavorException, IOException
        catch (Exception e)
            {
            _trace("transfer failed " + e, 1);
            return false;
            }
        
        if (sValue != null)
            {
            int ofPos = getOffsetAtPoint(point);
        
            if (this instanceof JTextField &&
                    iAction == DnDConstants.ACTION_MOVE)
                {
                // replace the content
                setText(sValue);
                }
            else
                {
                // insert the trasfered value at the current location
                if (ofPos < 0)
                    {
                    append(sValue);
                    }
                else
                    {
                    insert(sValue, ofPos);
                    }
                }
            }
        
        return true;
        }
    
    /**
    * Redo the last significant UndoableEdit.
    */
    public void redo()
        {
        UndoManager mgr = getUndoManager();
        if (mgr != null && mgr.isRedoable())
            {
            mgr.redo();
            }
        else
            {
            _beep();
            }

        }
    
    /**
    * Replaces text from the indicated start to end position with the new text 
    * specified.  Does nothing if the model is null. Simply does a delete if 
    * the new string is null or empty. This method is thread safe, although
    * most Swing methods are not.
    * 
    * @param sContent the text to use as the replacement
    * @param ofStart the start position >= 0
    * @param ofEnd the end position >= ofStart
    * 
    * @exception IllegalArgumentException  if part of the range is an  invalid
    * position in the model
    *  
    * @see #insert
    */
    public void replaceRange(String sContent, int ofStart, int ofEnd)
        {
        if (ofStart > ofEnd)
            {
            throw new IllegalArgumentException("ofStart=" + ofStart + " ofEnd=" + ofEnd);
            }
        
        Document doc = get_Document();
        if (doc != null)
            {
            try {
                doc.remove(ofStart, ofEnd - ofStart);
                doc.insertString(ofStart, sContent, null);
                }
            catch (BadLocationException e)
                {
                throw new IllegalArgumentException(e.getMessage());
                }
            }
        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        config.putInt(sPrefix + ".SelectionStart", getSelectionStart());
        config.putInt(sPrefix + ".SelectionEnd"  , getSelectionEnd()  );
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "AltDown"
    private void setAltDown(boolean pAltDown)
        {
        __m_AltDown = pAltDown;
        }
    
    // Accessor for the property "DisabledTextColor"
    public void setDisabledTextColor(_package.component.gUI.Color pDisabledTextColor)
        {
        set_DisabledTextColor(pDisabledTextColor != null ?
            pDisabledTextColor.get_Color() : null);
        }
    
    // Accessor for the property "UndoLimit"
    public void setUndoLimit(int pUndoLimit)
        {
        __m_UndoLimit = (pUndoLimit);
        
        UndoManager mgr = getUndoManager();
        
        if (pUndoLimit > 0)
            {
            if (mgr == null)
                {
                setUndoManager(mgr = new UndoManager());
                get_Document().addUndoableEditListener(mgr);
                }
            mgr.setLimit(pUndoLimit);
            }
        else
            {
            if (mgr != null)
                {
                get_Document().removeUndoableEditListener(mgr);
                mgr.discardAllEdits();
                setUndoManager(mgr = null);
                }
            }
        }
    
    // Accessor for the property "UndoManager"
    public void setUndoManager(_package.component.gUI.UndoManager pUndoManager)
        {
        __m_UndoManager = pUndoManager;
        }
    
    /**
    * Helper function that requests focus for this text component and
    * highlights the entire text
    */
    public void startEdit()
        {
        requestFocus();
        select(0, getTextLength());
        }
    
    /**
    * Undo the last significant UndoableEdit.
    */
    public void undo()
        {
        UndoManager mgr = getUndoManager();
        if (mgr != null && mgr.isUndoable())
            {
            mgr.undo();
            }
        else
            {
            _beep();
            }

        }
    }
