/* Class
*     _package.component.gUI.control.container.window.Dialog
*/

package _package.component.gUI.control.container.window;

import _package.component.gUI.control.container.Window;

/*
* Integrates
*     java.awt.Dialog
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class Dialog
        extends    _package.component.gUI.control.container.Window
    {
    // Fields declarations
    
    /**
    * Property Modal
    *
    */
    private transient boolean __m_Modal;
    
    /**
    * Property Resizable
    *
    */
    private transient boolean __m_Resizable;
    
    /**
    * Property Title
    *
    */
    private transient String __m_Title;
    
    // fields used by the integration model:
    private sink_Dialog __sink;
    private java.awt.Dialog __feed;
    
    // Default constructor
    public Dialog()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Dialog(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Dialog();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/window/Dialog".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.Dialog integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_Dialog) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (java.awt.Dialog) pFeed;
        super.set_Feed(pFeed);
        }
    private void _initFeed$AutoGen(java.awt.Dialog _ownerDialog)
        {
        jb_Dialog.__tloPeer.setObject(this);
        new jb_Dialog(_ownerDialog, this, false); // this sets the Sink which sets the Feed
        __init();
        }
    public void _initFeed(java.awt.Dialog _ownerDialog)
        {
        // import Component.GUI.Control.Container.Window;
        
        _initFeed$AutoGen(_ownerDialog);
        setOwner((Window) _findFeed(_ownerDialog));

        }
    private void _initFeed$AutoGen(java.awt.Frame _ownerFrame)
        {
        jb_Dialog.__tloPeer.setObject(this);
        new jb_Dialog(_ownerFrame, this, false); // this sets the Sink which sets the Feed
        __init();
        }
    public void _initFeed(java.awt.Frame _ownerFrame)
        {
        // import Component.GUI.Control.Container.Window;
        
        _initFeed$AutoGen(_ownerFrame);
        setOwner((Window) _findFeed(_ownerFrame));

        }
    // properties integration
    // methods integration
    public String getTitle()
        {
        return __sink.getTitle();
        }
    public boolean isModal()
        {
        return __sink.isModal();
        }
    public boolean isResizable()
        {
        return __sink.isResizable();
        }
    public void setModal(boolean pModal)
        {
        __sink.setModal(pModal);
        }
    public void setResizable(boolean pResizable)
        {
        __sink.setResizable(pResizable);
        }
    public void setTitle(String pTitle)
        {
        __sink.setTitle(pTitle);
        }
    //-- java.awt.Dialog integration
    }
