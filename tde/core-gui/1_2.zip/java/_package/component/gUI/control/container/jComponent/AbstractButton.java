/* Class
*     _package.component.gUI.control.container.jComponent.AbstractButton
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.Insets;
import _package.component.gUI.control.container.jComponent.jPanel.ActionGroup;
import _package.component.gUI.image.Icon;
import com.tangosol.run.component.EventDeathException;

/*
* Integrates
*     javax.swing.AbstractButton
*     using Component.Dev.Compiler.Integrator.AbstractBean
*/
public abstract class AbstractButton
        extends    _package.component.gUI.control.container.JComponent
        implements java.awt.event.ActionListener,
                   java.awt.event.ItemListener,
                   javax.swing.event.ChangeListener
    {
    // Fields declarations
    
    /**
    * Property _DisabledIcon
    *
    */
    private transient javax.swing.Icon __m__DisabledIcon;
    
    /**
    * Property _DisabledSelectedIcon
    *
    */
    private transient javax.swing.Icon __m__DisabledSelectedIcon;
    
    /**
    * Property _Icon
    *
    */
    private transient javax.swing.Icon __m__Icon;
    
    /**
    * Property _Margin
    *
    */
    private transient java.awt.Insets __m__Margin;
    
    /**
    * Property _Mnemonic
    *
    */
    private transient int __m__Mnemonic;
    
    /**
    * Property _PressedIcon
    *
    */
    private transient javax.swing.Icon __m__PressedIcon;
    
    /**
    * Property _RolloverIcon
    *
    */
    private transient javax.swing.Icon __m__RolloverIcon;
    
    /**
    * Property _RolloverSelectedIcon
    *
    */
    private transient javax.swing.Icon __m__RolloverSelectedIcon;
    
    /**
    * Property _SelectedIcon
    *
    */
    private transient javax.swing.Icon __m__SelectedIcon;
    
    /**
    * Property ActionCommand
    *
    */
    private transient String __m_ActionCommand;
    
    /**
    * Property DisabledIcon
    *
    */
    private transient _package.component.gUI.image.Icon __m_DisabledIcon;
    
    /**
    * Property DisabledSelectedIcon
    *
    */
    private transient _package.component.gUI.image.Icon __m_DisabledSelectedIcon;
    
    /**
    * Property FocusPainted
    *
    * Specifies whether focus should be painted.
    */
    private transient boolean __m_FocusPainted;
    
    /**
    * Property HorizontalAlignment
    *
    * Specifies the alignment of the button's contents along the X axis.
    * 
    * The valid values are (see javax.swing.SwingConstants):
    * CENTER = 0 (Default)
    * LEFT = 2
    * RIGHT = 4
    * LEADING = 10
    * TRAILING = 11
    */
    private transient int __m_HorizontalAlignment;
    
    /**
    * Property HorizontalTextPosition
    *
    * Specifies the horizontal position of the button's text, relative to its
    * image.
    * 
    * The valid values are (see javax.swing.SwingConstants):
    * CENTER = 0
    * LEFT = 2
    * RIGHT = 4
    * LEADING = 10
    * TRAILING = 11 (Default)
    */
    private transient int __m_HorizontalTextPosition;
    
    /**
    * Property Icon
    *
    */
    private transient _package.component.gUI.image.Icon __m_Icon;
    
    /**
    * Property Margin
    *
    */
    private transient _package.component.gUI.Insets __m_Margin;
    
    /**
    * Property Mnemonic
    *
    */
    private transient char __m_Mnemonic;
    
    /**
    * Property PressedIcon
    *
    */
    private transient _package.component.gUI.image.Icon __m_PressedIcon;
    
    /**
    * Property RolloverEnabled
    *
    */
    private transient boolean __m_RolloverEnabled;
    
    /**
    * Property RolloverIcon
    *
    */
    private transient _package.component.gUI.image.Icon __m_RolloverIcon;
    
    /**
    * Property RolloverSelectedIcon
    *
    */
    private transient _package.component.gUI.image.Icon __m_RolloverSelectedIcon;
    
    /**
    * Property Selected
    *
    * Specifies the state of the button. True if the toggle button is selected,
    * false if it's not.
    * Note: setting the Selected property to true does not trigger an Action
    * event. Call doClick() to perform a programatic action change.
    * 
    * @see #onAction
    * @see #onItemStateChanged
    */
    private transient boolean __m_Selected;
    
    /**
    * Property SelectedIcon
    *
    */
    private transient _package.component.gUI.image.Icon __m_SelectedIcon;
    
    /**
    * Property STATE_DESELECTED
    *
    * This state-change value indicates that an item was un-selected.
    * 
    * @see java.awt.event.ItemEvent#DESELECTED
    * @see #onItemStateChanged
    */
    public static final int STATE_DESELECTED = 2;
    
    /**
    * Property STATE_SELECTED
    *
    * This state-change value indicates that an item was selected.
    * 
    * @see java.awt.event.ItemEvent#SELECTED
    * @see #onItemStateChanged
    */
    public static final int STATE_SELECTED = 1;
    
    /**
    * Property Text
    *
    */
    private transient String __m_Text;
    
    /**
    * Property TIcon
    *
    */
    private transient String __m_TIcon;
    
    /**
    * Property VerticalAlignment
    *
    * Specifies the alignment of the button's contents along the Y axis.
    * 
    * The valid values are (see javax.swing.SwingConstants):
    * CENTER = 0 (Default)
    * TOP = 1
    * BOTTOM = 3
    */
    private transient int __m_VerticalAlignment;
    
    /**
    * Property VerticalTextPosition
    *
    * Specifies the vertical position of the button's text, relative to its
    * image.
    * 
    * The valid values are (see javax.swing.SwingConstants):
    * CENTER = 0 (Default)
    * TOP = 1
    * BOTTOM = 3
    */
    private transient int __m_VerticalTextPosition;
    
    // fields used by the integration model:
    private sink_AbstractButton __sink;
    private javax.swing.AbstractButton __feed;
    
    // Initializing constructor
    public AbstractButton(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        super.__initEvents();
        
        addActionListener(this);
        addItemListener(this);
        addChangeListener(this);
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/AbstractButton".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ ActionListener dispatcher
    private com.tangosol.util.Listeners __ActionListeners;
    private void addActionListener$Router(java.awt.event.ActionListener l)
        {
        __sink.addActionListener(l);
        }
    public void addActionListener(java.awt.event.ActionListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __ActionListeners;
        if (_listeners == null)
            {
            __ActionListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addActionListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeActionListener$Router(java.awt.event.ActionListener l)
        {
        __sink.removeActionListener(l);
        }
    public void removeActionListener(java.awt.event.ActionListener l)
        {
        com.tangosol.util.Listeners _listeners = __ActionListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeActionListener$Router(this);
            }
        }
    private void actionPerformed$Dispatch(java.awt.event.ActionEvent e)
        {
        java.util.EventListener[] targets = __ActionListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.ActionListener target = (java.awt.event.ActionListener) targets[i];
            if (target != this)
                {
                target.actionPerformed(e);
                }
            }
        }
    public void actionPerformed(java.awt.event.ActionEvent e)
        {
        try
            {
            if (is_Constructed())
                {
                onAction(e.getActionCommand(), e.getModifiers(), e.paramString());
                }
            }
        catch (EventDeathException ex)
            {
            return;
            }
        actionPerformed$Dispatch(e);
        }
    //-- ActionListener dispatcher
    
    //++ ItemListener dispatcher
    private com.tangosol.util.Listeners __ItemListeners;
    private void addItemListener$Router(java.awt.event.ItemListener l)
        {
        __sink.addItemListener(l);
        }
    public void addItemListener(java.awt.event.ItemListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __ItemListeners;
        if (_listeners == null)
            {
            __ItemListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addItemListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeItemListener$Router(java.awt.event.ItemListener l)
        {
        __sink.removeItemListener(l);
        }
    public void removeItemListener(java.awt.event.ItemListener l)
        {
        com.tangosol.util.Listeners _listeners = __ItemListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeItemListener$Router(this);
            }
        }
    private void itemStateChanged$Dispatch(java.awt.event.ItemEvent e)
        {
        java.util.EventListener[] targets = __ItemListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.ItemListener target = (java.awt.event.ItemListener) targets[i];
            if (target != this)
                {
                target.itemStateChanged(e);
                }
            }
        }
    public void itemStateChanged(java.awt.event.ItemEvent e)
        {
        try
            {
            if (is_Constructed())
                {
                onItemStateChanged(this, e.getStateChange());
                }
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        itemStateChanged$Dispatch(e);
        }
    //-- ItemListener dispatcher
    
    //++ ChangeListener dispatcher
    private com.tangosol.util.Listeners __ChangeListeners;
    private void addChangeListener$Router(javax.swing.event.ChangeListener l)
        {
        __sink.addChangeListener(l);
        }
    public void addChangeListener(javax.swing.event.ChangeListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __ChangeListeners;
        if (_listeners == null)
            {
            __ChangeListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addChangeListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeChangeListener$Router(javax.swing.event.ChangeListener l)
        {
        __sink.removeChangeListener(l);
        }
    public void removeChangeListener(javax.swing.event.ChangeListener l)
        {
        com.tangosol.util.Listeners _listeners = __ChangeListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeChangeListener$Router(this);
            }
        }
    private void stateChanged$Dispatch(javax.swing.event.ChangeEvent e)
        {
        java.util.EventListener[] targets = __ChangeListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.ChangeListener target = (javax.swing.event.ChangeListener) targets[i];
            if (target != this)
                {
                target.stateChanged(e);
                }
            }
        }
    public void stateChanged(javax.swing.event.ChangeEvent e)
        {
        try
            {
            if (is_Constructed())
                {
                onStateChanged();
                }
            }
        catch (EventDeathException ex)
            {
            return;
            }
        stateChanged$Dispatch(e);
        }
    //-- ChangeListener dispatcher
    
    //++ javax.swing.AbstractButton integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_AbstractButton) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.AbstractButton) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public void doClick()
        {
        __sink.doClick();
        }
    /**
    * Programmatically perform a "click". This does the same thing as if the
    * user had pressed and released the button.
    * The button stays visually "pressed" for <code>iPressTime</code>
    * milliseconds.
    */
    public void doClick(int iPressTime)
        {
        __sink.doClick(iPressTime);
        }
    public String getActionCommand()
        {
        return __sink.getActionCommand();
        }
    public javax.swing.Icon get_DisabledIcon()
        {
        return __sink.getDisabledIcon();
        }
    public javax.swing.Icon get_DisabledSelectedIcon()
        {
        return __sink.getDisabledSelectedIcon();
        }
    public int getHorizontalAlignment()
        {
        return __sink.getHorizontalAlignment();
        }
    public int getHorizontalTextPosition()
        {
        return __sink.getHorizontalTextPosition();
        }
    public javax.swing.Icon get_Icon()
        {
        return __sink.getIcon();
        }
    public java.awt.Insets get_Margin()
        {
        return __sink.getMargin();
        }
    public int get_Mnemonic()
        {
        return __sink.getMnemonic();
        }
    public javax.swing.Icon get_PressedIcon()
        {
        return __sink.getPressedIcon();
        }
    public javax.swing.Icon get_RolloverIcon()
        {
        return __sink.getRolloverIcon();
        }
    public javax.swing.Icon get_RolloverSelectedIcon()
        {
        return __sink.getRolloverSelectedIcon();
        }
    public javax.swing.Icon get_SelectedIcon()
        {
        return __sink.getSelectedIcon();
        }
    public String getText()
        {
        return __sink.getText();
        }
    public int getVerticalAlignment()
        {
        return __sink.getVerticalAlignment();
        }
    public int getVerticalTextPosition()
        {
        return __sink.getVerticalTextPosition();
        }
    public boolean isFocusPainted()
        {
        return __sink.isFocusPainted();
        }
    public boolean isRolloverEnabled()
        {
        return __sink.isRolloverEnabled();
        }
    public boolean isSelected()
        {
        return __sink.isSelected();
        }
    public void setActionCommand(String pActionCommand)
        {
        __sink.setActionCommand(pActionCommand);
        }
    public void set_DisabledIcon(javax.swing.Icon p_DisabledIcon)
        {
        __sink.setDisabledIcon(p_DisabledIcon);
        }
    public void set_DisabledSelectedIcon(javax.swing.Icon p_DisabledSelectedIcon)
        {
        __sink.setDisabledSelectedIcon(p_DisabledSelectedIcon);
        }
    public void setFocusPainted(boolean pFocusPainted)
        {
        __sink.setFocusPainted(pFocusPainted);
        }
    public void setHorizontalAlignment(int pHorizontalAlignment)
        {
        __sink.setHorizontalAlignment(pHorizontalAlignment);
        }
    public void setHorizontalTextPosition(int pHorizontalTextPosition)
        {
        __sink.setHorizontalTextPosition(pHorizontalTextPosition);
        }
    public void set_Icon(javax.swing.Icon p_Icon)
        {
        __sink.setIcon(p_Icon);
        }
    public void set_Margin(java.awt.Insets p_Margin)
        {
        __sink.setMargin(p_Margin);
        }
    public void setMnemonic(char pMnemonic)
        {
        __sink.setMnemonic(pMnemonic);
        }
    public void set_Mnemonic(int p_Mnemonic)
        {
        __sink.setMnemonic(p_Mnemonic);
        }
    public void set_PressedIcon(javax.swing.Icon p_PressedIcon)
        {
        __sink.setPressedIcon(p_PressedIcon);
        }
    public void setRolloverEnabled(boolean pRolloverEnabled)
        {
        __sink.setRolloverEnabled(pRolloverEnabled);
        }
    public void set_RolloverIcon(javax.swing.Icon p_RolloverIcon)
        {
        __sink.setRolloverIcon(p_RolloverIcon);
        }
    public void set_RolloverSelectedIcon(javax.swing.Icon p_RolloverSelectedIcon)
        {
        __sink.setRolloverSelectedIcon(p_RolloverSelectedIcon);
        }
    public void setSelected(boolean pSelected)
        {
        __sink.setSelected(pSelected);
        }
    public void set_SelectedIcon(javax.swing.Icon p_SelectedIcon)
        {
        __sink.setSelectedIcon(p_SelectedIcon);
        }
    public void setText(String pText)
        {
        __sink.setText(pText);
        }
    public void setVerticalAlignment(int pVerticalAlignment)
        {
        __sink.setVerticalAlignment(pVerticalAlignment);
        }
    public void setVerticalTextPosition(int pVerticalTextPosition)
        {
        __sink.setVerticalTextPosition(pVerticalTextPosition);
        }
    //-- javax.swing.AbstractButton integration
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Image.Icon;
        // import com.tangosol.run.component.EventDeathException;
        

        }
    
    // Accessor for the property "DisabledIcon"
    public _package.component.gUI.image.Icon getDisabledIcon()
        {
        javax.swing.Icon _icon = get_DisabledIcon();
        return _icon instanceof Icon ? (Icon) _icon : null;
        }
    
    // Accessor for the property "DisabledSelectedIcon"
    public _package.component.gUI.image.Icon getDisabledSelectedIcon()
        {
        javax.swing.Icon _icon = get_DisabledSelectedIcon();
        return _icon instanceof Icon ? (Icon) _icon : null;
        }
    
    // Accessor for the property "Icon"
    public _package.component.gUI.image.Icon getIcon()
        {
        javax.swing.Icon _icon = get_Icon();
        return _icon instanceof Icon ? (Icon) _icon : null;
        }
    
    // Accessor for the property "Margin"
    public _package.component.gUI.Insets getMargin()
        {
        // import Component.GUI.Insets;
        Insets wrapper = new Insets();
        wrapper.set_Insets(get_Margin());
        return wrapper;
        }
    
    // Accessor for the property "Mnemonic"
    public char getMnemonic()
        {
        return (char) get_Mnemonic();
        }
    
    // Accessor for the property "PressedIcon"
    public _package.component.gUI.image.Icon getPressedIcon()
        {
        javax.swing.Icon _icon = get_PressedIcon();
        return _icon instanceof Icon ? (Icon) _icon : null;
        }
    
    // Accessor for the property "RolloverIcon"
    public _package.component.gUI.image.Icon getRolloverIcon()
        {
        javax.swing.Icon _icon = get_RolloverIcon();
        return _icon instanceof Icon ? (Icon) _icon : null;
        }
    
    // Accessor for the property "RolloverSelectedIcon"
    public _package.component.gUI.image.Icon getRolloverSelectedIcon()
        {
        javax.swing.Icon _icon = get_RolloverSelectedIcon();
        return _icon instanceof Icon ? (Icon) _icon : null;
        }
    
    // Accessor for the property "SelectedIcon"
    public _package.component.gUI.image.Icon getSelectedIcon()
        {
        javax.swing.Icon _icon = get_SelectedIcon();
        return _icon instanceof Icon ? (Icon) _icon : null;
        }
    
    // Accessor for the property "TIcon"
    public String getTIcon()
        {
        return __m_TIcon;
        }
    
    /**
    * This notification (called by actionPerformed) is sent when an armed item
    * (Armed == true) gets unpressed (Pressed == false). This also could be a
    * result of an "accelerator key" action.
    * 
    * Note: setting the Selected property to true (calling setSelected(true))
    * does not trigger an Action event. However, calling doClick() does.
    * 
    * @param action  content of this component's ActionComand property
    * @param modifiers  the key modifier that was selected, and is used to
    * determine the state of the selected key
    * @param param  currently not used (intended for for event-logging and for
    * debugging)
    * 
    * @see #onItemStateChanged
    * @see #onStateChanged
    * @see javax.swing.DefaultButtonModel#setPressed
    */
    public void onAction(String action, int modifiers, String param)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ActionGroup;
        
        Component parent = get_Parent();
        
        if (parent instanceof ActionGroup)
            {
            ((ActionGroup) parent).onAction(action, modifiers, param);
            }

        }
    
    /**
    * Method notification (called by itemStateChanged) is sent when the
    * Selected property of an item changes its value
    * 
    * @param item  an AbstractButton item that originated the event
    * @param state  STATE_SELECTED if the Selected property value has changed
    * to true; STATE_DESELECTED otherwise
    * 
    * @see #onStateChanged
    */
    public void onItemStateChanged(AbstractButton item, int state)
        {
        }
    
    /**
    * onStateChanged notification (called by stateChanged) is sent every time
    * any attribute (Selected, Enabled, Armed or Pressed) of an item changes
    * its value
    * 
    * @see #onItemStateChanged
    */
    public void onStateChanged()
        {
        }
    
    // Accessor for the property "DisabledIcon"
    public void setDisabledIcon(_package.component.gUI.image.Icon pDisabledIcon)
        {
        set_DisabledIcon(pDisabledIcon);
        }
    
    // Accessor for the property "DisabledSelectedIcon"
    public void setDisabledSelectedIcon(_package.component.gUI.image.Icon pDisabledSelectedIcon)
        {
        set_DisabledSelectedIcon(pDisabledSelectedIcon);
        }
    
    // Accessor for the property "Icon"
    public void setIcon(_package.component.gUI.image.Icon pIcon)
        {
        set_Icon(pIcon);
        }
    
    // Accessor for the property "Margin"
    public void setMargin(_package.component.gUI.Insets pMargin)
        {
        set_Margin(pMargin.get_Insets());
        }
    
    // Accessor for the property "PressedIcon"
    public void setPressedIcon(_package.component.gUI.image.Icon pPressedIcon)
        {
        set_PressedIcon(pPressedIcon);
        }
    
    // Accessor for the property "RolloverIcon"
    public void setRolloverIcon(_package.component.gUI.image.Icon pRolloverIcon)
        {
        set_RolloverIcon(pRolloverIcon);
        }
    
    // Accessor for the property "RolloverSelectedIcon"
    public void setRolloverSelectedIcon(_package.component.gUI.image.Icon pRolloverSelectedIcon)
        {
        set_RolloverSelectedIcon(pRolloverSelectedIcon);
        }
    
    // Accessor for the property "SelectedIcon"
    public void setSelectedIcon(_package.component.gUI.image.Icon pSelectedIcon)
        {
        set_SelectedIcon(pSelectedIcon);
        }
    
    // Accessor for the property "TIcon"
    public void setTIcon(String pTIcon)
        {
        if (pTIcon != null)
            {
            Icon icon = (Icon) _newInstance("Component.GUI.Image.Icon." + pTIcon);
            if (icon != null && icon.get_Icon() != null)
                {
                setIcon(icon);
                }
            }
        }
    }
