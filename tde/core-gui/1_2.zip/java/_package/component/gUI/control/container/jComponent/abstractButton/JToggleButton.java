/* Class
*     _package.component.gUI.control.container.jComponent.abstractButton.JToggleButton
*/

package _package.component.gUI.control.container.jComponent.abstractButton;

import _package.component.gUI.control.container.jComponent.jPanel.ButtonGroupPanel;

/*
* Integrates
*     javax.swing.JToggleButton
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JToggleButton
        extends    _package.component.gUI.control.container.jComponent.AbstractButton
    {
    // Fields declarations
    
    /**
    * Property Value
    *
    */
    private String __m_Value;
    
    // fields used by the integration model:
    private sink_JToggleButton __sink;
    private javax.swing.JToggleButton __feed;
    
    // Default constructor
    public JToggleButton()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JToggleButton(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setTBounds("0,0,100,17");
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JToggleButton.__tloPeer.setObject(this);
            new jb_JToggleButton(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JToggleButton();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/abstractButton/JToggleButton".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JToggleButton integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JToggleButton) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JToggleButton) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    //-- javax.swing.JToggleButton integration
    
    // Accessor for the property "Value"
    public String getValue()
        {
        return __m_Value != null ? __m_Value : getText();
        }
    
    // Declared at the super level
    /**
    * Method notification (called by itemStateChanged) is sent when the
    * Selected property of an item changes its value
    * 
    * @param item  an AbstractButton item that originated the event
    * @param state  STATE_SELECTED if the Selected property value has changed
    * to true; STATE_DESELECTED otherwise
    * 
    * @see #onStateChanged
    */
    public void onItemStateChanged(_package.component.gUI.control.container.jComponent.AbstractButton item, int state)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.ButtonGroupPanel;
        
        super.onItemStateChanged(item, state);
        
        if (state == STATE_SELECTED)
            {
            Component parent = get_Parent();
            if (parent instanceof ButtonGroupPanel)
                {
                ((ButtonGroupPanel) parent).onItemSelected(this);
                }
            }
        }
    
    // Accessor for the property "Value"
    public void setValue(String pValue)
        {
        __m_Value = pValue;
        }
    }
