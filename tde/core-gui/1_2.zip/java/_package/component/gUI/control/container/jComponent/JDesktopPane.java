/* Class
*     _package.component.gUI.control.container.jComponent.JDesktopPane
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.control.container.jComponent.JInternalFrame;
import _package.component.gUI.control.container.jComponent.jInternalFrame.InternalDialog;
import java.beans.PropertyVetoException;
import java.util.Enumeration;
import javax.swing.JDesktopPane; // as _JDesktopPane
import javax.swing.JInternalFrame; // as _JInternalFrame

/*
* Integrates
*     javax.swing.JDesktopPane
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JDesktopPane
        extends    _package.component.gUI.control.container.JComponent
    {
    // Fields declarations
    
    /**
    * Property ActiveFrame
    *
    * Specifies the currently active frame.
    */
    private transient JInternalFrame __m_ActiveFrame;
    
    // fields used by the integration model:
    private sink_JDesktopPane __sink;
    private javax.swing.JDesktopPane __feed;
    
    // Default constructor
    public JDesktopPane()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JDesktopPane(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JDesktopPane.__tloPeer.setObject(this);
            new jb_JDesktopPane(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JDesktopPane();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JDesktopPane".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JDesktopPane integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JDesktopPane) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JDesktopPane) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public void doLayout()
        {
        // import javax.swing.JInternalFrame as _JInternalFrame;
        // import javax.swing.JDesktopPane   as _JDesktopPane;
        
        super.doLayout();
        
        // The following is a fix for JDK 1.2 bug, that is fixed in 1.2.2
        // but behaves quite ugly, so our fix is still better
        // TODO: remove if fixed better
        
        // re-maximize maximized frames (if any)
        _JInternalFrame[] _frames = ((_JDesktopPane) get_Feed()).getAllFrames();
        
        for (int i = _frames.length; --i >= 0;)
            {
            _JInternalFrame _frame = _frames[i];
            if (_frame.isMaximum())
                {
                try
                    {
                    _frame.setMaximum(false);
                    _frame.setMaximum(true);
                    }
                catch (java.beans.PropertyVetoException e) {}
                }
            }
        }
    public void setEnabled(boolean pEnabled)
        {
        // import java.util.Enumeration;
        
        // pass the "Enabled" flag on all the children
        for (Enumeration enum = _enumChildren(); enum.hasMoreElements();)
            {
            Object child = enum.nextElement();
            if (child instanceof JInternalFrame)
                {
                ((JInternalFrame) child).setEnabled(pEnabled);
                }
            }
        }
    //-- javax.swing.JDesktopPane integration
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent.JInternalFrame;

        }
    
    private _package.component.gUI.control.container.jComponent.jInternalFrame.InternalDialog createDialogInvisible(JInternalFrame owner, JPanel panel, Object oDialogParam, boolean fModal)
        {
        // import Component.GUI.Control.Container.JComponent.JInternalFrame.InternalDialog;
        
        panel.setDialogParam(oDialogParam);
        
        InternalDialog dlg = panel.makeInternalDialog(this);
        
        dlg.setOwner(owner);
        dlg.setModal(fModal);
        dlg.setSelected(true);
        
        // if dialog is modal     -- the desktop is disabled
        // if dialog is not modal -- the desktop is enabled
        setEnabled(!fModal);
        return dlg;
        }
    
    /**
    * JDesktopPane specific implementation of dialogBox.
    */
    public Object dialogBox(JInternalFrame owner, JPanel panel, Object oDialogParam)
        {
        // import Component.GUI.Control.Container.JComponent.JInternalFrame.InternalDialog;
        
        JInternalFrame frameActive = getActiveFrame();
        
        InternalDialog dlg = createDialogInvisible(owner, panel, oDialogParam, true);
        try
            {
            // the following is a blocking call!
            dlg.setVisible(true);
        
            // the dialog box is hidden now!!
            }
        finally
            {
            setEnabled(true); // re-enable all internal frames (disabled by createDialogInvisible())
            setActiveFrame(frameActive);
            }
        
        return dlg.getHostedPanel().getDialogResult();
        }
    
    // Declared at the super level
    /**
    * Bring up the specified dialog box.
    * 
    * @param panel  the dialog's main panel
    * @param oDialogPrm  dialog parameter (often an array of objects)
    * 
    * @return result of the dialog's execution (value of dialog main panel's
    * property DialogResult)
    * 
    * @see Window#dialogBox
    * @see JDesktopPane#dialogBox
    */
    public Object dialogBox(JPanel panel, Object oDialogPrm)
        {
        return dialogBox(getActiveFrame(), panel, oDialogPrm);
        }
    
    // Accessor for the property "ActiveFrame"
    public JInternalFrame getActiveFrame()
        {
        // import java.beans.PropertyVetoException;
        // import javax.swing.JInternalFrame as _JInternalFrame;
        // import javax.swing.JDesktopPane   as _JDesktopPane;
        
        _JInternalFrame[] _frames = ((_JDesktopPane) get_Feed()).getAllFrames();
        if (_frames.length == 0)
            {
            return null;
            }
        
        for (int i = 0; i < _frames.length; i++)
            {
            _JInternalFrame _frame = _frames[i];
            if (_frame.isSelected())
                {
                return (JInternalFrame) _findFeed(_frame);
                }
            }
        
        // There is no selected frame. This should not happen but it does
        // all the time when a new desktop pane gets visible
        // TODO: remove when Swing fixes this
        try
            {
            _frames[0].setSelected(true);
            }
        catch (PropertyVetoException e) {}
        
        return _frames[0].isSelected() ?
            (JInternalFrame) _findFeed(_frames[0]) : null;
        }
    
    // Declared at the super level
    /**
    * Brings up a message box specified by the panel name.
    * 
    * @see JFrame#msg
    * @see JDesktopPane#msg
    */
    public Object msg(String sMsgId, Object oMsgPrm)
        {
        // import javax.swing.JDesktopPane as _JDesktopPane;
        
        // temorary use of javax.swing.JOptionPane until I know what todo
        
        JInternalFrame frameActive = getActiveFrame();
        boolean        fEnabled    = isEnabled();
        
        setEnabled(false);
        
        try
            {
            if (sMsgId.startsWith("Confirm"))
                {
                Object[] aoMsgPrm  = (Object[]) oMsgPrm;
                String   sMsgText  = (String)   aoMsgPrm[0];
                String   sMsgTitle = (String)   aoMsgPrm[1];
                int      sMsgType  = ((Integer) aoMsgPrm[2]).intValue();
        
                return new Integer(javax.swing.JOptionPane.showInternalConfirmDialog(
                    (_JDesktopPane) get_Feed(), sMsgText, sMsgTitle, sMsgType));
                }
            else if (sMsgId.startsWith("Input"))
                {
                Object[] aoMsgPrm  = (Object[]) oMsgPrm;
                String   sMsgText  = (String)   aoMsgPrm[0];
                String   sMsgTitle = (String)   aoMsgPrm[1];
                int      sMsgType  = ((Integer) aoMsgPrm[2]).intValue();
                String   sMsgInit  = (String)   aoMsgPrm[3];
        
                return javax.swing.JOptionPane.showInternalInputDialog(
                    (_JDesktopPane) get_Feed(), sMsgText, sMsgTitle, sMsgType, null, null, sMsgInit);
                }
            else if (sMsgId.startsWith("Message"))
                {
                Object[] aoMsgPrm  = (Object[]) oMsgPrm;
                String   sMsgText  = (String)   aoMsgPrm[0];
                String   sMsgTitle = (String)   aoMsgPrm[1];
                int      sMsgType  = ((Integer) aoMsgPrm[2]).intValue();
        
                javax.swing.JOptionPane.showInternalMessageDialog(
                    (_JDesktopPane) get_Feed(), sMsgText, sMsgTitle, sMsgType);
                return null;
                }
            else
                {
                return null;
                }
            }
        finally
            {
            setEnabled(fEnabled);
            setActiveFrame(frameActive);
            }
        }
    
    // Declared at the super level
    /**
    * @see #_removeChild
    */
    public void removeControl(_package.component.gUI.Control child)
        {
        if (child instanceof JInternalFrame)
            {
            JInternalFrame frame = (JInternalFrame) child;
        
            // TODO: this could become wrong after the bug #4096227 is fixed
            // (see JInternalFrame#onInit())
        
            // we must allow the closing now
            frame.setAllowClosing(true);
            frame.setClosed(true);
            frame.dispose();
            }
        else
            {
            super.removeControl(child);
            }
        }
    
    // Accessor for the property "ActiveFrame"
    public void setActiveFrame(JInternalFrame pActiveFrame)
        {
        if (pActiveFrame != null)
            {
            pActiveFrame.setSelected(true);
            }
        }
    }
