/* Class
*     _package.component.gUI.control.container.jComponent.JPanel
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.control.container.Window;
import _package.component.gUI.control.container.jComponent.JInternalFrame;
import _package.component.gUI.control.container.jComponent.jInternalFrame.InternalDialog;
import _package.component.gUI.control.container.window.dialog.JDialog;
import _package.component.gUI.control.container.window.frame.JFrame;
import _package.component.gUI.image.Icon;
import _package.component.util.Config;
import com.tangosol.run.xml.XmlElement;
import com.tangosol.run.xml.XmlSerializable;
import java.awt.Dialog; // as _Dialog
import java.awt.Frame; // as _Frame

/*
* Integrates
*     javax.swing.JPanel
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JPanel
        extends    _package.component.gUI.control.container.JComponent
    {
    // Fields declarations
    
    /**
    * Property DialogParam
    *
    * Specifies the parameter passed to the dialogBox() call when this panel is
    * the "main panel" of the dialog box. If this value is instanceof
    * XmlElement or Config, an appropriate intialization is enforced.
    * 
    * @see Control#dialogBox
    * @see Window#dialogBox
    * @see JDesktopPane#dialogBox
    */
    private transient Object __m_DialogParam;
    
    /**
    * Property DialogResult
    *
    * Specifies the result that should be passed back to the caller of
    * dialogBox() when this panel is the "main panel" of the dialog box.
    * Two special values are "nul" for the canceled action and Boolean.TRUE for
    * the default action.
    * 
    * @see #endDialog
    * @see Control#dialogBox
    * @see Window#dialogBox
    * @see JDesktopPane#dialogBox
    */
    private transient Object __m_DialogResult;
    
    /**
    * Property Icon
    *
    * Ambient property used by containing JFrame or JInternalFrame
    * 
    * @see JFrame#hostPanel
    * @see JInternalFrame#hostPanel
    */
    private _package.component.gUI.image.Icon __m_Icon;
    
    /**
    * Property Resizable
    *
    * Ambient property used by containing JFrame or JInternalFrame
    * 
    * @see JFrame#hostPanel
    * @see JInternalFrame#hostPanel
    */
    private boolean __m_Resizable;
    
    /**
    * Property TIcon
    *
    */
    private transient String __m_TIcon;
    
    /**
    * Property Title
    *
    * Ambient property used by containing JFrame, JInternalFrame and
    * JTabbedPane.
    * 
    * @see JFrame#hostPanel
    * @see JInternalFrame#hostPanel
    * @see JTabbedPane#addControl
    */
    private String __m_Title;
    
    // fields used by the integration model:
    private sink_JPanel __sink;
    private javax.swing.JPanel __feed;
    
    // Default constructor
    public JPanel()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JPanel(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(true);
            setTConstraints("Center");
            setTLayout("BorderLayout");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JPanel.__tloPeer.setObject(this);
            new jb_JPanel(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JPanel();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JPanel".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JPanel integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JPanel) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JPanel) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    //-- javax.swing.JPanel integration
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent.JInternalFrame;
        // import Component.GUI.Control.Container.JComponent.JInternalFrame.InternalDialog;
        // import Component.GUI.Control.Container.Window;
        // import Component.GUI.Control.Container.Window.Dialog.JDialog;
        // import Component.GUI.Control.Container.Window.Frame.JFrame;

        }
    
    /**
    * Ends a dialog, setting the specified result of the DailogBox. The
    * conventions for the result value are:
    * Value of null means the canceled action. Value of Boolean.TRUE means the
    * default action and then the DialogBox result value is set as follows:
    * if the panel implements XmlSerializable then the result is set to the
    * appropriate XML value; otherwise the result value is set to the Config
    * object.
    * 
    * @param oResult the result value of the dialiog box with this main panel
    * 
    * @see DialogParam property
    * @see JButton.DefaultButton#onAction
    * @see JButton.EscapeButton#onAction
    */
    public void endDialog(Object oResult)
        {
        // import Component.Util.Config;
        // import com.tangosol.run.xml.XmlSerializable;
        
        if (oResult == Boolean.TRUE)
            {
            if (this instanceof XmlSerializable)
                {
                oResult = ((XmlSerializable) this).toXml();
                }
            else
                {
                Config cfg = new Config();
                this.saveConfig(cfg, "");
                
                oResult = cfg;
                }
            }
        
        setDialogResult(oResult);
        
        Component parent = get_Parent();
        if (parent instanceof JInternalFrame)
            {
            ((JInternalFrame) parent).dispose();
            }
        else if (parent instanceof Window)
            {
            ((Window) parent).dispose();
            }
        else
            {
            throw new IllegalStateException(get_Name() + ".endDialog: " +
                "Invalid dialog box panel");
            }
        }
    
    // Accessor for the property "DialogParam"
    public Object getDialogParam()
        {
        return __m_DialogParam;
        }
    
    // Accessor for the property "DialogResult"
    public Object getDialogResult()
        {
        return __m_DialogResult;
        }
    
    // Accessor for the property "Icon"
    public _package.component.gUI.image.Icon getIcon()
        {
        return __m_Icon;
        }
    
    // Accessor for the property "TIcon"
    public String getTIcon()
        {
        return __m_TIcon;
        }
    
    // Accessor for the property "Title"
    public String getTitle()
        {
        return __m_Title;
        }
    
    /**
    * A subclass of the JPanel could override this method to create a more
    * specific instance of JDialog if needed.
    */
    protected _package.component.gUI.control.container.window.dialog.JDialog instantiateDialog()
        {
        return new JDialog();
        }
    
    /**
    * A subclass of the JPanel could override this method to create a more
    * specific instance of JFrame if needed.
    */
    protected _package.component.gUI.control.container.window.frame.JFrame instantiateFrame()
        {
        return new JFrame();
        }
    
    /**
    * A subclass of the JPanel could override this method to create a more
    * specific instance of JInternalDialog if needed.
    */
    protected _package.component.gUI.control.container.jComponent.jInternalFrame.InternalDialog instantiateInternalDialog()
        {
        return new InternalDialog();
        }
    
    /**
    * A subclass of the JPanel could override this method to create a more
    * specific instance of JInternalFrame if needed.
    */
    protected JInternalFrame instantiateInternalFrame()
        {
        return new JInternalFrame();
        }
    
    // Accessor for the property "Resizable"
    public boolean isResizable()
        {
        return __m_Resizable;
        }
    
    /**
    * Make a dialog for this panel with  the specified owner frame.
    */
    public _package.component.gUI.control.container.window.dialog.JDialog makeDialog(_package.component.gUI.control.container.Window owner)
        {
        // import java.awt.Dialog as _Dialog;
        // import java.awt.Frame as _Frame;
        
        JDialog dlg = instantiateDialog();
        
        if (owner instanceof JFrame)
            {
            dlg._initFeed((_Frame) owner.get_Feed());
            }
        else if (owner instanceof JDialog)
            {
            dlg._initFeed((_Dialog) owner.get_Feed());
            }
        else
            {
            throw new IllegalArgumentException();
            }
        
        dlg.hostPanel(this);
        
        // the caller is supposed to take care of the frame's
        // "Visible" property (that is how "modality" is implemented)
        return dlg;
        }
    
    /**
    * Make a frame for this panel.
    */
    public _package.component.gUI.control.container.window.frame.JFrame makeFrame()
        {
        JFrame frame = instantiateFrame();
        
        frame.hostPanel(this);
        
        // the caller is supposed to take care of the frame's
        // "Visible" property
        return frame;
        }
    
    /**
    * Make an internal dialog for this panel for the specified desktop
    * (JDesktopPane)
    * 
    * @see makeInternalFrame
    */
    public _package.component.gUI.control.container.jComponent.jInternalFrame.InternalDialog makeInternalDialog(JDesktopPane desktop)
        {
        InternalDialog dlg = instantiateInternalDialog();
        dlg.hostPanel(this);
        
        // the caller is supposed to take care of the frame's
        // "Visible" property
        return dlg;
        }
    
    /**
    * Make an internal frame for this panel for the specified desktop
    * (JDesktopPane) at the specified layer
    * 
    * Note: the desktop parameter is not used here, but canl likely be used by
    * the subclasses overriding this method
    * 
    * @see makeInternalDialog
    */
    public JInternalFrame makeInternalFrame(JDesktopPane desktop, int iLayer)
        {
        JInternalFrame frame = instantiateInternalFrame();
        
        frame.setLayer(iLayer);
        frame.hostPanel(this);
        
        // the caller is supposed to take care of the frame's
        // "Visible" property
        return frame;
        }
    
    /**
    * Convenience method that moves this panel to front view in a way that
    * depends on the type of the parent.
    */
    public void moveToFront()
        {
        Component parent = get_Parent();
        
        if (parent == null)
            {
            return;
            }
        
        if (parent instanceof JInternalFrame)
            {
            ((JInternalFrame) parent).setSelected(true); // moveToFront() is not working here
            }
        else if (parent instanceof Window)
            {
            ((Window) parent).toFront();
            }
        else 
            {
            parent = _findAncestor(JPanel.class);
            if (parent != null)
                {
                ((JPanel) parent).moveToFront();
                }
            }
        }
    
    // Accessor for the property "DialogParam"
    public void setDialogParam(Object pDialogParam)
        {
        // import Component.Util.Config;
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.run.xml.XmlSerializable;
        
        __m_DialogParam = (pDialogParam);
        
        if (pDialogParam instanceof Config)
            {
            this.applyConfig((Config) pDialogParam, "");
            }
        
        if (pDialogParam instanceof XmlElement &&
            this instanceof XmlSerializable)
            {
            ((XmlSerializable) this).fromXml((XmlElement) pDialogParam);
            }
        }
    
    // Accessor for the property "DialogResult"
    public void setDialogResult(Object pDialogResult)
        {
        __m_DialogResult = pDialogResult;
        }
    
    // Accessor for the property "Icon"
    public void setIcon(_package.component.gUI.image.Icon pIcon)
        {
        __m_Icon = (pIcon);
        
        Component parent = get_Parent();
        if (parent instanceof JInternalFrame)
            {
            ((JInternalFrame) parent).setFrameIcon(pIcon);
            }
        else if (parent instanceof JFrame)
            {
            ((JFrame) parent).setIconImage(pIcon);
            }

        }
    
    // Accessor for the property "Resizable"
    public void setResizable(boolean pResizable)
        {
        __m_Resizable = pResizable;
        }
    
    // Accessor for the property "TIcon"
    public void setTIcon(String pTIcon)
        {
        // import Component.GUI.Image.Icon;
        
        Icon icon = (Icon) _newInstance("Component.GUI.Image.Icon." + pTIcon);
        if (icon != null && icon.get_Icon() != null)
            {
            setIcon(icon);
            }
        }
    
    // Accessor for the property "Title"
    public void setTitle(String pTitle)
        {
        __m_Title = (pTitle);
        
        Component parent = get_Parent();
        if (parent instanceof JInternalFrame)
            {
            ((JInternalFrame) parent).setTitle(pTitle);
            }
        else if (parent instanceof JDialog)
            {
            ((JDialog) parent).setTitle(pTitle);
            }
        else if (parent instanceof JFrame)
            {
            ((JFrame) parent).setTitle(pTitle);
            }

        }
    }
