/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.FindText$KeyFindSelection
*/

package _package.component.gUI.control.container.jComponent.jPanel;

public class FindText$KeyFindSelection
        extends    _package.component.gUI.KeyAction
    {
    // Fields declarations
    
    // Default constructor
    public FindText$KeyFindSelection()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public FindText$KeyFindSelection(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setCondition(0);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new FindText$KeyFindSelection$KeyStroke1("KeyStroke1", this, true), "KeyStroke1");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new FindText$KeyFindSelection();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/FindText$KeyFindSelection".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    /**
    * Event-notification sent when a key corresponding to this KeyStroke has
    * been typed on the keyboard.
    */
    public void onTyped()
        {
        super.onTyped();
        
        (($Module) get_Module()).doFindSelection();
        }
    }
