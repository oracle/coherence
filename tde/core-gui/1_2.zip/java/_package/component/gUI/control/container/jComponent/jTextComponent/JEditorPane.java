/* Class
*     _package.component.gUI.control.container.jComponent.jTextComponent.JEditorPane
*/

package _package.component.gUI.control.container.jComponent.jTextComponent;

import _package.component.net.URL;
import com.tangosol.run.component.EventDeathException;
import javax.swing.JEditorPane; // as _JEditorPane

/**
* JEditorPane could be customized by inserting an appropriate EditorKit and
* usually adding overriding <code>drawUnselectedText</code> on the View
* component contained by that kit.
*/
/*
* Integrates
*     javax.swing.JEditorPane
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JEditorPane
        extends    _package.component.gUI.control.container.jComponent.JTextComponent
        implements javax.swing.event.HyperlinkListener
    {
    // Fields declarations
    
    /**
    * Property _Page
    *
    */
    private java.net.URL __m__Page;
    
    /**
    * Property ContentType
    *
    * Sets the type of content that this editor handles. The most commonly used
    * types are:
    *     text/html
    *     text/plain
    * 
    * Note: This property should have been integrated, but it's final so we
    * have wrapped it instead.
    * 
    * @see #getContentType
    * @see #setContentType
    */
    private transient String __m_ContentType;
    
    /**
    * Property Page
    *
    */
    private _package.component.net.URL __m_Page;
    
    // fields used by the integration model:
    private sink_JEditorPane __sink;
    private javax.swing.JEditorPane __feed;
    
    // Default constructor
    public JEditorPane()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JEditorPane(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setScrollable(true);
            setTBounds("0,0,100,100");
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new _package.component.gUI.control.container.jComponent.JTextComponent$KeyRedo("KeyRedo", this, true), "KeyRedo");
        _addChild(new _package.component.gUI.control.container.jComponent.JTextComponent$KeyUndo("KeyUndo", this, true), "KeyUndo");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JEditorPane.__tloPeer.setObject(this);
            new jb_JEditorPane(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        super.__initEvents();
        
        addHyperlinkListener(this);
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new JEditorPane();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jTextComponent/JEditorPane".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ HyperlinkListener dispatcher
    private com.tangosol.util.Listeners __HyperlinkListeners;
    private void addHyperlinkListener$Router(javax.swing.event.HyperlinkListener l)
        {
        __sink.addHyperlinkListener(l);
        }
    public void addHyperlinkListener(javax.swing.event.HyperlinkListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __HyperlinkListeners;
        if (_listeners == null)
            {
            __HyperlinkListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addHyperlinkListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeHyperlinkListener$Router(javax.swing.event.HyperlinkListener l)
        {
        __sink.removeHyperlinkListener(l);
        }
    public void removeHyperlinkListener(javax.swing.event.HyperlinkListener l)
        {
        com.tangosol.util.Listeners _listeners = __HyperlinkListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeHyperlinkListener$Router(this);
            }
        }
    private void hyperlinkUpdate$Dispatch(javax.swing.event.HyperlinkEvent e)
        {
        java.util.EventListener[] targets = __HyperlinkListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.HyperlinkListener target = (javax.swing.event.HyperlinkListener) targets[i];
            if (target != this)
                {
                target.hyperlinkUpdate(e);
                }
            }
        }
    public void hyperlinkUpdate(javax.swing.event.HyperlinkEvent e)
        {
        // import Component.Net.URL;
        // import com.tangosol.run.component.EventDeathException;
        
        try
            {
            URL url = new URL();
            url.set_URL(e.getURL());
        
            onHyperlinkUpdate(url, e.getDescription(), String.valueOf(e.getEventType()));
            }
        catch (EventDeathException x)
            {
            return;
            }
        
        hyperlinkUpdate$Dispatch(e);
        }
    //-- HyperlinkListener dispatcher
    
    //++ javax.swing.JEditorPane integration
    // Access optimization
    /**
    * Setter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JEditorPane) pSink;
        super.set_Sink(pSink);
        }
    /**
    * Setter for property _Feed.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JEditorPane) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    /**
    * Getter for property _Page.<p>
    */
    public java.net.URL get_Page()
        {
        return __sink.getPage();
        }
    /**
    * Setter for property _Page.<p>
    */
    public void set_Page(java.net.URL p_Page)
            throws java.io.IOException
        {
        __sink.setPage(p_Page);
        }
    //-- javax.swing.JEditorPane integration
    
    // Declared at the super level
    public void _imports()
        {
        // import javax.swing.JEditorPane as _JEditorPane;
        
        

        }
    
    // Accessor for the property "ContentType"
    /**
    * Getter for property ContentType.<p>
    * Sets the type of content that this editor handles. The most commonly used
    * types are:
    *     text/html
    *     text/plain
    * 
    * Note: This property should have been integrated, but it's final so we
    * have wrapped it instead.
    * 
    * @see #getContentType
    * @see #setContentType
    */
    public String getContentType()
        {
        return ((_JEditorPane) get_Feed()).getContentType();
        }
    
    // Accessor for the property "Page"
    /**
    * // TODO integrate
    */
    public _package.component.net.URL getPage()
        {
        // import Component.Net.URL;
        
        java.net.URL _url = get_Page();
        if (_url != null)
            {
            URL url = new URL();
            url.set_URL(_url);
            return url;
            }
        else
            {
            return null;
            }
        }
    
    /**
    * Notification sent by the JEditorPane when some link activity has been
    * occurred
    * 
    * @param url  the link's URL
    * @param sDescription  description of the link as a string
    * @param  sAction  one of the event types: "ENTERED", "EXITED" or
    * "ACTIVATED"
    */
    public void onHyperlinkUpdate(_package.component.net.URL url, String sDescription, String sAction)
        {
        }
    
    // Accessor for the property "ContentType"
    /**
    * Setter for property ContentType.<p>
    * Sets the type of content that this editor handles. The most commonly used
    * types are:
    *     text/html
    *     text/plain
    * 
    * Note: This property should have been integrated, but it's final so we
    * have wrapped it instead.
    * 
    * @see #getContentType
    * @see #setContentType
    */
    public void setContentType(String pContentType)
        {
        ((_JEditorPane) get_Feed()).setContentType(pContentType);
        }
    
    // Accessor for the property "Page"
    /**
    * // TODO integrate
    */
    public void setPage(_package.component.net.URL pPage)
            throws java.io.IOException
        {
        set_Page(pPage.get_URL());
        }
    }
