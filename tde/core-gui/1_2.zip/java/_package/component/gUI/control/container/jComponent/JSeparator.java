/* Class
*     _package.component.gUI.control.container.jComponent.JSeparator
*/

package _package.component.gUI.control.container.jComponent;

/*
* Integrates
*     javax.swing.JSeparator
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JSeparator
        extends    _package.component.gUI.control.container.JComponent
    {
    // Fields declarations
    
    /**
    * Property Orientation
    *
    */
    private transient int __m_Orientation;
    
    // fields used by the integration model:
    private sink_JSeparator __sink;
    private javax.swing.JSeparator __feed;
    
    // Default constructor
    public JSeparator()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JSeparator(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JSeparator.__tloPeer.setObject(this);
            new jb_JSeparator(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JSeparator();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JSeparator".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JSeparator integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JSeparator) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JSeparator) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public int getOrientation()
        {
        return __sink.getOrientation();
        }
    public void setOrientation(int pOrientation)
        {
        __sink.setOrientation(pOrientation);
        }
    //-- javax.swing.JSeparator integration
    }
