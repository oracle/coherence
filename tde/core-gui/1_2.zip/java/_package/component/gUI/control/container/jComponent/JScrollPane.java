/* Class
*     _package.component.gUI.control.container.jComponent.JScrollPane
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.Constraints;
import _package.component.gUI.Control;
import _package.component.gUI.LayoutManager;
import java.awt.LayoutManager; // as _LayoutManager
import javax.swing.ScrollPaneConstants; // as Constants

/*
* Integrates
*     javax.swing.JScrollPane
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JScrollPane
        extends    _package.component.gUI.control.container.JComponent
    {
    // Fields declarations
    
    /**
    * Property _ColumnHeader
    *
    */
    private transient javax.swing.JViewport __m__ColumnHeader;
    
    /**
    * Property _HorizontalScrollBar
    *
    */
    private transient javax.swing.JScrollBar __m__HorizontalScrollBar;
    
    /**
    * Property _RowHeader
    *
    */
    private transient javax.swing.JViewport __m__RowHeader;
    
    /**
    * Property _VerticalScrollBar
    *
    */
    private transient javax.swing.JScrollBar __m__VerticalScrollBar;
    
    /**
    * Property _Viewport
    *
    */
    private transient javax.swing.JViewport __m__Viewport;
    
    /**
    * Property _ViewportBorder
    *
    */
    private transient javax.swing.border.Border __m__ViewportBorder;
    
    /**
    * Property _ViewportBorderBounds
    *
    */
    
    /**
    * Property View
    *
    */
    private _package.component.gUI.Control __m_View;
    
    // fields used by the integration model:
    private sink_JScrollPane __sink;
    private javax.swing.JScrollPane __feed;
    
    // Default constructor
    public JScrollPane()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JScrollPane(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setScrollable(true);
            setTConstraints("Center");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JScrollPane.__tloPeer.setObject(this);
            new jb_JScrollPane(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JScrollPane();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JScrollPane".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JScrollPane integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JScrollPane) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JScrollPane) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    protected javax.swing.JScrollBar createHorizontalScrollBar()
        {
        return __sink.createHorizontalScrollBar();
        }
    protected javax.swing.JScrollBar createVerticalScrollBar()
        {
        return __sink.createVerticalScrollBar();
        }
    protected javax.swing.JViewport createViewport()
        {
        return __sink.createViewport();
        }
    public javax.swing.JViewport get_ColumnHeader()
        {
        return __sink.getColumnHeader();
        }
    public java.awt.Component get_Corner(String sKey)
        {
        return __sink.getCorner(sKey);
        }
    public javax.swing.JScrollBar get_HorizontalScrollBar()
        {
        return __sink.getHorizontalScrollBar();
        }
    public javax.swing.JViewport get_RowHeader()
        {
        return __sink.getRowHeader();
        }
    public javax.swing.JScrollBar get_VerticalScrollBar()
        {
        return __sink.getVerticalScrollBar();
        }
    public javax.swing.JViewport get_Viewport()
        {
        return __sink.getViewport();
        }
    public javax.swing.border.Border get_ViewportBorder()
        {
        return __sink.getViewportBorder();
        }
    public java.awt.Rectangle get_ViewportBorderBounds()
        {
        return __sink.getViewportBorderBounds();
        }
    public void set_ColumnHeader(javax.swing.JViewport p_ColumnHeader)
        {
        __sink.setColumnHeader(p_ColumnHeader);
        }
    public void set_Corner(String sKey, java.awt.Component p_Corner)
        {
        __sink.setCorner(sKey, p_Corner);
        }
    public void set_HorizontalScrollBar(javax.swing.JScrollBar p_HorizontalScrollBar)
        {
        __sink.setHorizontalScrollBar(p_HorizontalScrollBar);
        }
    public void set_RowHeader(javax.swing.JViewport p_RowHeader)
        {
        __sink.setRowHeader(p_RowHeader);
        }
    public void set_VerticalScrollBar(javax.swing.JScrollBar p_VerticalScrollBar)
        {
        __sink.setVerticalScrollBar(p_VerticalScrollBar);
        }
    public void set_Viewport(javax.swing.JViewport p_Viewport)
        {
        __sink.setViewport(p_Viewport);
        }
    public void set_ViewportBorder(javax.swing.border.Border p_ViewportBorder)
        {
        __sink.setViewportBorder(p_ViewportBorder);
        }
    //-- javax.swing.JScrollPane integration
    
    // Declared at the super level
    /**
    * Adds the visual feed of the specified child component to the visual feed
    * of this container. Having this functionality separate from _addChild
    * allows it to be overwritten by containers that know better.
    * 
    * @see #_addChild
    */
    public void addControl(_package.component.gUI.Control child)
        {
        // import Component.GUI.Constraints;
        // import javax.swing.ScrollPaneConstants as Constants;
        
        java.awt.Component _containee = child.getAWTContainee(true);
        
        if (_containee != null)
            {
            Constraints constraints = child.getConstraints();
            String      sID = constraints == null ? null : constraints.get_Constraints().toString();
        
            if (     Constants.COLUMN_HEADER.equals(sID))
                {
                ((javax.swing.JScrollPane) get_Feed()).setColumnHeaderView(_containee);
                }
            else if (Constants.ROW_HEADER.equals(sID))
                {
                ((javax.swing.JScrollPane) get_Feed()).setRowHeaderView(_containee);
                }
            else if (Constants.LOWER_LEFT_CORNER.equals(sID)  ||
                     Constants.LOWER_RIGHT_CORNER.equals(sID) ||
                     Constants.UPPER_LEFT_CORNER.equals(sID)  ||
                     Constants.UPPER_RIGHT_CORNER.equals(sID))
                {
                set_Corner(sID, _containee);
                }
            else
                { 
                // one and only one "view" child is allowed
                _assert(getView() == null, "Only one view is allowed for " + get_Name());
            
                get_Viewport().setView(_containee);
                setView(child);
                }
            }
        }
    
    // Declared at the super level
    public javax.swing.JScrollPane get_ScrollPane()
        {
        return (javax.swing.JScrollPane) get_Feed();
        }
    
    // Declared at the super level
    /**
    * This method is called by  Component.Control.Container#addControl() as a
    * last chance to intervene during the construction/integration cycle.
    * A Control would override this if more than one AWT components should be
    * created for one Control or if the component should not be added to the
    * container (see Component...Window or Component...TabbedPanel).
    * This method can also be used to make sure that the parent is of the
    * allowed type (i.e. TabbedPanel is only allowed to be added into the
    * JTabbedPane).
    *  
    * @param  fAdd is true <b>only</b> when this is the frist call (from
    * addControl()) and an override is supposed to tie all the pieces together;
    * false in all other situations
    * 
    * @return AWT component that is added to a container [integratee].
    * 
    * @see Component.Control.Container.Window
    * @see Component.GUI.Control.Container.JComponent
    * @see
    * Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem.JMenu
    * @see Component.GUI.Control.Container.JComponent.JPanel.ButtonGroupPanel
    */
    public java.awt.Component getAWTContainee(boolean fAdd)
        {
        return get_ScrollPane();
        }
    
    // Declared at the super level
    public _package.component.gUI.LayoutManager getLayout()
        {
        // import Component.GUI.LayoutManager;
        // import java.awt.LayoutManager as _LayoutManager;
        
        _LayoutManager _mgr = get_Viewport().getLayout();
        
        if (_mgr instanceof LayoutManager)
            {
            return (LayoutManager) _mgr;
            }
        else
            {
            LayoutManager wrapper = new LayoutManager();
            wrapper.set_Layout(_mgr);
            return wrapper;
            }
        }
    
    // Accessor for the property "View"
    public _package.component.gUI.Control getView()
        {
        return __m_View;
        }
    
    // Declared at the super level
    /**
    * @see #_removeChild
    */
    public void removeControl(_package.component.gUI.Control child)
        {
        super.removeControl(child);
        
        setView(null);
        }
    
    // Declared at the super level
    public void setLayout(_package.component.gUI.LayoutManager pLayout)
        {
        get_Viewport().setLayout(pLayout);
        }
    
    // Accessor for the property "View"
    public void setView(_package.component.gUI.Control pView)
        {
        // import Component.GUI.Control;
        
        Control view = getView();
        
        if (view != null && view.get_Parent() == this)
            {
            _removeChild(view);
            }
        
        __m_View = (pView);
        
        if (pView != null && pView.get_Parent() != this)
            {
            _addChild(pView, "View");
            }
        }
    }
