/* Class
*      sink_JToggleButton
*
* automatically generated "Sink" which
* represents a footprint of the class
*      javax.swing.JToggleButton
* when used as a component callback by 
*      Component.GUI.Control.Container.JComponent.AbstractButton.JToggleButton
*/

package _package.component.gUI.control.container.jComponent.abstractButton;

public class sink_JToggleButton
       extends _package.component.gUI.control.container.jComponent.sink_AbstractButton
    {
    private jb_JToggleButton __peer;
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_JToggleButton()
        {
        }
    
    // this (protected) constructor is used by the feed
    protected sink_JToggleButton(jb_JToggleButton feed)
        {
        super();
        __peer = feed;
        }
    
    // Retrieves the feed object for this sink
    public Object get_Feed()
        {
        return __peer;
        }
    
    // methods integrated and/or remoted
    public void add(java.awt.Component comp, Object constraints, int index)
        {
        __peer.super$add(comp, constraints, index);
        }
    public void remove(java.awt.Component comp)
        {
        __peer.super$remove(comp);
        }
    public void addActionListener(java.awt.event.ActionListener l)
        {
        __peer.super$addActionListener(l);
        }
    public void addChangeListener(javax.swing.event.ChangeListener l)
        {
        __peer.super$addChangeListener(l);
        }
    public void addFocusListener(java.awt.event.FocusListener l)
        {
        __peer.super$addFocusListener(l);
        }
    public void addItemListener(java.awt.event.ItemListener l)
        {
        __peer.super$addItemListener(l);
        }
    public void addKeyListener(java.awt.event.KeyListener l)
        {
        __peer.super$addKeyListener(l);
        }
    public void addMouseListener(java.awt.event.MouseListener l)
        {
        __peer.super$addMouseListener(l);
        }
    public void addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        __peer.super$addMouseMotionListener(l);
        }
    public void addNotify()
        {
        __peer.super$addNotify();
        }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        __peer.super$addPropertyChangeListener(l);
        }
    public void addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        __peer.super$addVetoableChangeListener(l);
        }
    public javax.swing.JToolTip createToolTip()
        {
        return __peer.super$createToolTip();
        }
    public void doClick()
        {
        __peer.super$doClick();
        }
    public void doClick(int iPressTime)
        {
        __peer.super$doClick(iPressTime);
        }
    public void doLayout()
        {
        __peer.super$doLayout();
        }
    public java.awt.Color getBackground()
        {
        return __peer.super$getBackground();
        }
    public javax.swing.border.Border getBorder()
        {
        return __peer.super$getBorder();
        }
    public java.awt.Rectangle getBounds()
        {
        return __peer.super$getBounds();
        }
    public java.awt.Cursor getCursor()
        {
        return __peer.super$getCursor();
        }
    public javax.swing.Icon getDisabledIcon()
        {
        return __peer.super$getDisabledIcon();
        }
    public javax.swing.Icon getDisabledSelectedIcon()
        {
        return __peer.super$getDisabledSelectedIcon();
        }
    public java.awt.Font getFont()
        {
        return __peer.super$getFont();
        }
    public java.awt.Color getForeground()
        {
        return __peer.super$getForeground();
        }
    public javax.swing.Icon getIcon()
        {
        return __peer.super$getIcon();
        }
    public java.awt.Insets getInsets()
        {
        return __peer.super$getInsets();
        }
    public java.awt.LayoutManager getLayout()
        {
        return __peer.super$getLayout();
        }
    public java.awt.Point getLocation()
        {
        return __peer.super$getLocation();
        }
    public java.awt.Point getLocationOnScreen()
        {
        return __peer.super$getLocationOnScreen();
        }
    public java.awt.Insets getMargin()
        {
        return __peer.super$getMargin();
        }
    public java.awt.Dimension getMaximumSize()
        {
        return __peer.super$getMaximumSize();
        }
    public java.awt.Dimension getMinimumSize()
        {
        return __peer.super$getMinimumSize();
        }
    public int getMnemonic()
        {
        return __peer.super$getMnemonic();
        }
    public java.awt.Dimension getPreferredSize()
        {
        return __peer.super$getPreferredSize();
        }
    public javax.swing.Icon getPressedIcon()
        {
        return __peer.super$getPressedIcon();
        }
    public javax.swing.Icon getRolloverIcon()
        {
        return __peer.super$getRolloverIcon();
        }
    public javax.swing.Icon getRolloverSelectedIcon()
        {
        return __peer.super$getRolloverSelectedIcon();
        }
    public javax.swing.Icon getSelectedIcon()
        {
        return __peer.super$getSelectedIcon();
        }
    public java.awt.Dimension getSize()
        {
        return __peer.super$getSize();
        }
    public String getActionCommand()
        {
        return __peer.super$getActionCommand();
        }
    public int getHorizontalAlignment()
        {
        return __peer.super$getHorizontalAlignment();
        }
    public int getHorizontalTextPosition()
        {
        return __peer.super$getHorizontalTextPosition();
        }
    public String getText()
        {
        return __peer.super$getText();
        }
    public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent e)
        {
        return __peer.super$getToolTipLocation(e);
        }
    public String getToolTipText()
        {
        return __peer.super$getToolTipText();
        }
    public String getToolTipText(java.awt.event.MouseEvent e)
        {
        return __peer.super$getToolTipText(e);
        }
    public int getVerticalAlignment()
        {
        return __peer.super$getVerticalAlignment();
        }
    public int getVerticalTextPosition()
        {
        return __peer.super$getVerticalTextPosition();
        }
    public boolean getAutoscrolls()
        {
        return __peer.super$getAutoscrolls();
        }
    public boolean isEnabled()
        {
        return __peer.super$isEnabled();
        }
    public boolean isFocusPainted()
        {
        return __peer.super$isFocusPainted();
        }
    public boolean isFocusTraversable()
        {
        return __peer.super$isFocusTraversable();
        }
    public boolean isOpaque()
        {
        return __peer.super$isOpaque();
        }
    public boolean isRolloverEnabled()
        {
        return __peer.super$isRolloverEnabled();
        }
    public boolean isSelected()
        {
        return __peer.super$isSelected();
        }
    public boolean isShowing()
        {
        return __peer.super$isShowing();
        }
    public boolean isVisible()
        {
        return __peer.super$isVisible();
        }
    public void paint(java.awt.Graphics g)
        {
        __peer.super$paint(g);
        }
    public void paintBorder(java.awt.Graphics g)
        {
        __peer.super$paintBorder(g);
        }
    public void paintChildren(java.awt.Graphics g)
        {
        __peer.super$paintChildren(g);
        }
    public void paintComponent(java.awt.Graphics g)
        {
        __peer.super$paintComponent(g);
        }
    public void removeActionListener(java.awt.event.ActionListener l)
        {
        __peer.super$removeActionListener(l);
        }
    public void removeChangeListener(javax.swing.event.ChangeListener l)
        {
        __peer.super$removeChangeListener(l);
        }
    public void removeFocusListener(java.awt.event.FocusListener l)
        {
        __peer.super$removeFocusListener(l);
        }
    public void removeItemListener(java.awt.event.ItemListener l)
        {
        __peer.super$removeItemListener(l);
        }
    public void removeKeyListener(java.awt.event.KeyListener l)
        {
        __peer.super$removeKeyListener(l);
        }
    public void removeMouseListener(java.awt.event.MouseListener l)
        {
        __peer.super$removeMouseListener(l);
        }
    public void removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        __peer.super$removeMouseMotionListener(l);
        }
    public void removeNotify()
        {
        __peer.super$removeNotify();
        }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        __peer.super$removePropertyChangeListener(l);
        }
    public void removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        __peer.super$removeVetoableChangeListener(l);
        }
    public void requestFocus()
        {
        __peer.super$requestFocus();
        }
    public void setBackground(java.awt.Color p_Background)
        {
        __peer.super$setBackground(p_Background);
        }
    public void setBorder(javax.swing.border.Border p_Border)
        {
        __peer.super$setBorder(p_Border);
        }
    public void setBounds(java.awt.Rectangle p_Bounds)
        {
        __peer.super$setBounds(p_Bounds);
        }
    public void setCursor(java.awt.Cursor p_Cursor)
        {
        __peer.super$setCursor(p_Cursor);
        }
    public void setDisabledIcon(javax.swing.Icon p_DisabledIcon)
        {
        __peer.super$setDisabledIcon(p_DisabledIcon);
        }
    public void setDisabledSelectedIcon(javax.swing.Icon p_DisabledSelectedIcon)
        {
        __peer.super$setDisabledSelectedIcon(p_DisabledSelectedIcon);
        }
    public void setFont(java.awt.Font p_Font)
        {
        __peer.super$setFont(p_Font);
        }
    public void setForeground(java.awt.Color p_Foreground)
        {
        __peer.super$setForeground(p_Foreground);
        }
    public void setIcon(javax.swing.Icon p_Icon)
        {
        __peer.super$setIcon(p_Icon);
        }
    public void setLayout(java.awt.LayoutManager p_Layout)
        {
        __peer.super$setLayout(p_Layout);
        }
    public void setLocation(java.awt.Point p_Location)
        {
        __peer.super$setLocation(p_Location);
        }
    public void setMargin(java.awt.Insets p_Margin)
        {
        __peer.super$setMargin(p_Margin);
        }
    public void setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        __peer.super$setMaximumSize(p_MaximumSize);
        }
    public void setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        __peer.super$setMinimumSize(p_MinimumSize);
        }
    public void setMnemonic(int p_Mnemonic)
        {
        __peer.super$setMnemonic(p_Mnemonic);
        }
    public void setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        __peer.super$setPreferredSize(p_PreferredSize);
        }
    public void setPressedIcon(javax.swing.Icon p_PressedIcon)
        {
        __peer.super$setPressedIcon(p_PressedIcon);
        }
    public void setRolloverIcon(javax.swing.Icon p_RolloverIcon)
        {
        __peer.super$setRolloverIcon(p_RolloverIcon);
        }
    public void setRolloverSelectedIcon(javax.swing.Icon p_RolloverSelectedIcon)
        {
        __peer.super$setRolloverSelectedIcon(p_RolloverSelectedIcon);
        }
    public void setSelectedIcon(javax.swing.Icon p_SelectedIcon)
        {
        __peer.super$setSelectedIcon(p_SelectedIcon);
        }
    public void setSize(java.awt.Dimension p_Size)
        {
        __peer.super$setSize(p_Size);
        }
    public void setActionCommand(String pActionCommand)
        {
        __peer.super$setActionCommand(pActionCommand);
        }
    public void setAutoscrolls(boolean pAutoscrolls)
        {
        __peer.super$setAutoscrolls(pAutoscrolls);
        }
    public void setEnabled(boolean pEnabled)
        {
        __peer.super$setEnabled(pEnabled);
        }
    public void setFocusPainted(boolean pFocusPainted)
        {
        __peer.super$setFocusPainted(pFocusPainted);
        }
    public void setHorizontalAlignment(int pHorizontalAlignment)
        {
        __peer.super$setHorizontalAlignment(pHorizontalAlignment);
        }
    public void setHorizontalTextPosition(int pHorizontalTextPosition)
        {
        __peer.super$setHorizontalTextPosition(pHorizontalTextPosition);
        }
    public void setMnemonic(char pMnemonic)
        {
        __peer.super$setMnemonic(pMnemonic);
        }
    public void setOpaque(boolean pOpaque)
        {
        __peer.super$setOpaque(pOpaque);
        }
    public void setRolloverEnabled(boolean pRolloverEnabled)
        {
        __peer.super$setRolloverEnabled(pRolloverEnabled);
        }
    public void setSelected(boolean pSelected)
        {
        __peer.super$setSelected(pSelected);
        }
    public void setText(String pText)
        {
        __peer.super$setText(pText);
        }
    public void setToolTipText(String pToolTipText)
        {
        __peer.super$setToolTipText(pToolTipText);
        }
    public void setVerticalAlignment(int pVerticalAlignment)
        {
        __peer.super$setVerticalAlignment(pVerticalAlignment);
        }
    public void setVerticalTextPosition(int pVerticalTextPosition)
        {
        __peer.super$setVerticalTextPosition(pVerticalTextPosition);
        }
    public void setVisible(boolean pVisible)
        {
        __peer.super$setVisible(pVisible);
        }
    public void updateUI()
        {
        __peer.super$updateUI();
        }
    public void validate()
        {
        __peer.super$validate();
        }
    }
