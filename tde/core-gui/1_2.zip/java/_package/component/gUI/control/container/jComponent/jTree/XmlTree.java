/* Class
*     _package.component.gUI.control.container.jComponent.jTree.XmlTree
*/

package _package.component.gUI.control.container.jComponent.jTree;

import _package.component.gUI.TreeNode;
import _package.component.gUI.treeNode.SimpleNode;
import com.tangosol.run.xml.SimpleElement;
import com.tangosol.run.xml.XmlElement;
import java.util.Iterator;
import javax.swing.tree.DefaultMutableTreeNode;

/**
* JTree component that allows the tree be populated by the content of an
* XmlElement object
*/
public class XmlTree
        extends    _package.component.gUI.control.container.jComponent.JTree
    {
    // Fields declarations
    
    /**
    * Property RootName
    *
    */
    private transient String __m_RootName;
    
    // Default constructor
    public XmlTree()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public XmlTree(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setClosedIcon(null);
            setEditable(false);
            setFocusable(true);
            setHorizontalScrollBarPolicy(30);
            setLargeModel(false);
            setLeafIcon(null);
            setOpenIcon(null);
            setRedraw(true);
            setRootName(null);
            setRootVisible(false);
            setRowHeight(16);
            setScrollable(true);
            setScrollsOnExpand(true);
            setSelectionMode(1);
            setSeparator('.');
            setShowsRootHandles(true);
            setTBounds("100,10,50,1000");
            setTFont("DefaultProportional");
            setVerticalScrollBarPolicy(20);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new _package.component.gUI.control.container.jComponent.JTree$KeyCollapse("KeyCollapse", this, true), "KeyCollapse");
        _addChild(new _package.component.gUI.control.container.jComponent.JTree$KeyExpand("KeyExpand", this, true), "KeyExpand");
        _addChild(new _package.component.gUI.control.container.jComponent.JTree$KeyExpandAll("KeyExpandAll", this, true), "KeyExpandAll");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new XmlTree();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jTree/XmlTree".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.TreeNode;
        // import Component.GUI.TreeNode.SimpleNode;
        // import javax.swing.tree.DefaultMutableTreeNode;
        

        }
    
    /**
    * Add a node.
    * 
    * @param nodeParent  parent node
    * @param xml  child's xml element
    * 
    * @return inserted node
    */
    public _package.component.gUI.TreeNode addNode(_package.component.gUI.TreeNode nodeParent, com.tangosol.run.xml.XmlElement xml)
        {
        TreeNode nodeChild = makeNode(xml);
        
        if (nodeParent == null)
            {
            nodeParent = getRoot();
            }
        nodeParent.add(nodeChild);
        
        return nodeChild;
        }
    
    // Accessor for the property "RootName"
    /**
    * Getter for property RootName.<p>
    */
    public String getRootName()
        {
        return __m_RootName;
        }
    
    /**
    * Insert a node at the specified position.
    * 
    * @param nodeParent  parent node
    * @param xml  child's xml element
    * @param index  the index in this node's child array where this node is to
    * be inserted
    * 
    * @return inserted node
    */
    public _package.component.gUI.TreeNode insertNode(_package.component.gUI.TreeNode nodeParent, com.tangosol.run.xml.XmlElement xml, int index)
        {
        TreeNode nodeChild = makeNode(xml);
        
        if (nodeParent == null)
            {
            nodeParent = getRoot();
            }
        nodeParent.insert(nodeChild, index);
        
        return nodeChild;

        }
    
    // Declared at the super level
    public _package.component.gUI.TreeNode makeNode(Object path)
        {
        // import com.tangosol.run.xml.XmlElement;
        
        if (path instanceof XmlElement)
            {
            SimpleNode node = new SimpleNode();
            node.setTree(this);
            node.setEditable(isEditable());
            node.setSorted(isSorted());
            node.setCaseSensitive(isCaseSensitive());
            node.setCollator(getCollator());
        
            XmlElement el     = (XmlElement) path;
            String     sName  = el.getName();
            String     sValue = el.getString();
        
            if (sValue.trim().length() > 0)
                {
                sName += '=' + sValue;
                }
            node.setName(sName);
            node.setReference(el);
        
            return node;
            }
        else
            {
            return super.makeNode(path);
            }
        }
    
    // Declared at the super level
    /**
    * Makes a root node for this tree
    */
    protected _package.component.gUI.TreeNode makeRoot()
        {
        // import com.tangosol.run.xml.SimpleElement;
        
        DefaultMutableTreeNode _root = (DefaultMutableTreeNode) getModel().getRoot();
        _root.setUserObject(null);
        
        String sRootName = getRootName();
        SimpleNode simpleRoot = (SimpleNode) makeNode(
            new SimpleElement(sRootName == null ? "null" : sRootName));
        
        // the following in turn sets the UserObject of the _root
        // (see SimpleNode#setMutableNode)
        simpleRoot.setMutableNode(_root);
        
        return simpleRoot;
        }
    
    /**
    * Reload the tree, using the specified Xml tree as a data model
    */
    public void reload(com.tangosol.run.xml.XmlElement xml)
        {
        removeAllNodes();
        
        TreeNode node;
        
        if (isRootVisible())
            {
            setRootName(xml.getName());
            node = getRoot();
            }
        else
            {
            node = makeNode(xml);
            getRoot().add(node);
            }
        
        reload(node, xml);
        }
    
    /**
    * Reload the specified node, using the specified Xml element as a data model
    */
    protected void reload(_package.component.gUI.TreeNode node, com.tangosol.run.xml.XmlElement xml)
        {
        // import com.tangosol.run.xml.XmlElement;
        // import java.util.Iterator;
        
        for (Iterator iter = xml.getElementList().iterator(); iter.hasNext();)
            {
            XmlElement el = (XmlElement) iter.next();
        
            TreeNode nodeChild = addNode(node, el);
        
            reload(nodeChild, el);
            }

        }
    
    /**
    * Rename the specified child node.
    */
    public void renameNode(String sOldChildId, String sNewChildName)
        {
        }
    
    // Accessor for the property "RootName"
    /**
    * Setter for property RootName.<p>
    */
    public void setRootName(String pRootName)
        {
        __m_RootName = pRootName;
        }
    }
