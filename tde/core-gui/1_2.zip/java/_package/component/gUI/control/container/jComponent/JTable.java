/* Class
*     _package.component.gUI.control.container.jComponent.JTable
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.Dimension;
import _package.component.gUI.Point;
import _package.component.gUI.TableColumn;
import java.awt.Component;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetListener;
import java.util.Enumeration;
import javax.swing.JTable; // as _JTable
import javax.swing.event.ChangeEvent;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader; // as _JTableHeader
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableColumn; // as _TableColumn
import javax.swing.table.TableModel;
import javax.swing.text.JTextComponent;

/*
* Integrates
*     javax.swing.JTable
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JTable
        extends    _package.component.gUI.control.container.JComponent
        implements javax.swing.event.ListSelectionListener
    {
    // Fields declarations
    
    /**
    * Property _CellEditor
    *
    * Specifoes the current cell editor. This property is only meaningful
    * during cell editing.
    */
    private transient javax.swing.table.TableCellEditor __m__CellEditor;
    
    /**
    * Property _ColumnModel
    *
    */
    private transient javax.swing.table.TableColumnModel __m__ColumnModel;
    
    /**
    * Property _GridColor
    *
    */
    private transient java.awt.Color __m__GridColor;
    
    /**
    * Property _Model
    *
    */
    private transient javax.swing.table.TableModel __m__Model;
    
    /**
    * Property _SelectionBackground
    *
    */
    private transient java.awt.Color __m__SelectionBackground;
    
    /**
    * Property _SelectionForeground
    *
    */
    private transient java.awt.Color __m__SelectionForeground;
    
    /**
    * Property _SelectionModel
    *
    */
    private transient javax.swing.ListSelectionModel __m__SelectionModel;
    
    /**
    * Property _TableHeader
    *
    */
    private transient javax.swing.table.JTableHeader __m__TableHeader;
    
    /**
    * Property AUTO_RESIZE_ALL_COLUMNS
    *
    */
    public static final int AUTO_RESIZE_ALL_COLUMNS = 4; // javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS;
    
    /**
    * Property AUTO_RESIZE_LAST_COLUMN
    *
    */
    public static final int AUTO_RESIZE_LAST_COLUMN = 3; // javax.swing.JTable.AUTO_RESIZE_LAST_COLUMN;
    
    /**
    * Property AUTO_RESIZE_NEXT_COLUMN
    *
    */
    public static final int AUTO_RESIZE_NEXT_COLUMN = 1; // javax.swing.JTable.AUTO_RESIZE_NEXT_COLUMN;
    
    /**
    * Property AUTO_RESIZE_OFF
    *
    */
    public static final int AUTO_RESIZE_OFF = 0; // javax.swing.JTable.AUTO_RESIZE_OFF;
    
    /**
    * Property AUTO_RESIZE_SUBSEQUENT_COLUMNS
    *
    */
    public static final int AUTO_RESIZE_SUBSEQUENT_COLUMNS = 2; // javax.swing.JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS;
    
    /**
    * Property AutoResizeMode
    *
    * One of 5 legal values:
    * 
    * AUTO_RESIZE_OFF = 0
    * AUTO_RESIZE_NEXT_COLUMN = 1
    * AUTO_RESIZE_SUBSEQUENT_COLUMNS = 2
    * AUTO_RESIZE_LAST_COLUMN = 3
    * AUTO_RESIZE_ALL_COLUMNS = 4
    */
    private transient int __m_AutoResizeMode;
    
    /**
    * Property CellSelectionEnabled
    *
    * Specifies whether this table allows both a column selection and a row
    * selection to exist at the same time. When set, this results in a facility
    * to select a rectangular region of cells in the display.
    * This flag over-rides the row and column selection modes ensuring that
    * cell selection is possible whenever this flag is set.
    */
    private transient boolean __m_CellSelectionEnabled;
    
    /**
    * Property ColumnCount
    *
    */
    
    /**
    * Property ColumnMargin
    *
    * Specifies the ColumnMarging in TableColumnModel. Default value is 1,
    * which chops the leftmost pixels (due to changes in JDK 1.3).
    */
    private transient int __m_ColumnMargin;
    
    /**
    * Property ColumnSelectionAllowed
    *
    * Specifies whether the columns in this table can be selected.
    */
    private transient boolean __m_ColumnSelectionAllowed;
    
    /**
    * Property DefaultRowValues
    *
    * This is a convinience [calculated] property that could be used by some
    * generic implementations (like TcTable)  to allow adding an empty row of
    * data.
    * 
    * @see TableColumn.getDefaultValue()
    */
    
    /**
    * Property Editing
    *
    * (Calculated) Specifies whether a cell is being edited.
    */
    
    /**
    * Property EditingColumn
    *
    * (Calculated) Index of the column being edited.
    */
    
    /**
    * Property EditingRow
    *
    * (Calculated) Index of the row being edited.
    */
    
    /**
    * Property HeaderVisible
    *
    * Specifies whether the table header should be visible. Default is true.
    * 
    * Note: the JTable must be Scrollable in order to have the ColumnHeader.
    * 
    * @see javax.swing.JTable#addNotify
    */
    private boolean __m_HeaderVisible;
    
    /**
    * Property ITEM_NOT_FOUND
    *
    */
    public static final int ITEM_NOT_FOUND = -1;
    
    /**
    * Property LastColumnSelected
    *
    * not used
    */
    private int __m_LastColumnSelected;
    
    /**
    * Property LastRowSelected
    *
    * not used
    */
    private int __m_LastRowSelected;
    
    /**
    * Property ReorderingAllowed
    *
    */
    private transient boolean __m_ReorderingAllowed;
    
    /**
    * Property ResizingAllowed
    *
    * Specifies whether the column resizing should be allowed.
    */
    private transient boolean __m_ResizingAllowed;
    
    /**
    * Property RowCount
    *
    */
    
    /**
    * Property RowHeight
    *
    * Specifies the height for rows (in pixels, including the inter-cell
    * spacing).
    * Default value is 16, but with our default font size, RowMargin and
    * ColumnMargin values the height of 17 looks the best.
    */
    private transient int __m_RowHeight;
    
    /**
    * Property RowMargin
    *
    * Specifies the amount of emtpy space between rows (in pixels).
    */
    private transient int __m_RowMargin;
    
    /**
    * Property RowSelectionAllowed
    *
    * Specifies whether the rows in this table can be selected.
    */
    private transient boolean __m_RowSelectionAllowed;
    
    /**
    * Property SelectedColumn
    *
    * Specifies the index of a currently selected column (assuming single
    * selection mode)
    */
    private transient int __m_SelectedColumn;
    
    /**
    * Property SelectedColumnCount
    *
    * (Calculated) Specifies the number of currently selected columns.
    */
    
    /**
    * Property SelectedColumns
    *
    * (Calculated) Specifies the indices of all selected columns.
    */
    
    /**
    * Property SelectedRow
    *
    * Specifies the index of a currently selected row (assuming single
    * selection mode)
    */
    private transient int __m_SelectedRow;
    
    /**
    * Property SelectedRowCount
    *
    * (Calculated) Specifies the number of currently selected rows.
    */
    
    /**
    * Property SelectedRows
    *
    * (Calculated) Specifies the indices of all selected rows.
    */
    
    /**
    * Property SELECTION_MULTIPLE_INTERVAL
    *
    */
    public static final int SELECTION_MULTIPLE_INTERVAL = 2;
    
    /**
    * Property SELECTION_SINGLE
    *
    */
    public static final int SELECTION_SINGLE = 0;
    
    /**
    * Property SELECTION_SINGLE_INTERVAL
    *
    */
    public static final int SELECTION_SINGLE_INTERVAL = 1;
    
    /**
    * Property SelectionMode
    *
    * One of the three legal values:
    * 
    * SINGLE_SELECTION = 0
    * SINGLE_INTERVAL_SELECTION  = 1
    * MULTIPLE_INTERVAL_SELECTION = 2
    */
    private int __m_SelectionMode;
    
    /**
    * Property ShowGrid
    *
    */
    private transient boolean __m_ShowGrid;
    
    /**
    * Property ShowHorizontalLines
    *
    */
    private transient boolean __m_ShowHorizontalLines;
    
    /**
    * Property ShowVerticalLines
    *
    */
    private transient boolean __m_ShowVerticalLines;
    
    /**
    * Property Sorted
    *
    * Specifies whether the table is sorted. If set to true, it is assumed that
    * at least one of the table columns is set to be sorted as well.
    * 
    * @see #addRow
    * @see Component.GUI.TableColumn#Sorted
    */
    private transient boolean __m_Sorted;
    
    // fields used by the integration model:
    private sink_JTable __sink;
    private javax.swing.JTable __feed;
    
    // Default constructor
    public JTable()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JTable(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAutoResizeMode(2);
            setAutoscrolls(true);
            setCellSelectionEnabled(true);
            setColumnMargin(2);
            setColumnSelectionAllowed(false);
            setFocusable(true);
            setHorizontalScrollBarPolicy(30);
            setLastColumnSelected(-1);
            setLastRowSelected(-1);
            setReorderingAllowed(false);
            setResizingAllowed(true);
            setRowHeight(17);
            setRowMargin(1);
            setRowSelectionAllowed(true);
            setScrollable(true);
            setSelectionMode(0);
            setShowGrid(true);
            setShowHorizontalLines(true);
            setShowVerticalLines(true);
            setTFont("DefaultProportional");
            setVerticalScrollBarPolicy(20);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JTable.__tloPeer.setObject(this);
            new jb_JTable(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new JTable();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JTable".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JTable integration
    // Access optimization
    /**
    * Setter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JTable) pSink;
        super.set_Sink(pSink);
        }
    /**
    * Setter for property _Feed.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JTable) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public void clearSelection()
        {
        __sink.clearSelection();
        }
    /**
    * Programmatically starts editing the cell at (iRow, iColumn), if the cell
    * is editable.
    * 
    * Default implementation just calls editCellAt(iRow, iColumn, null)
    */
    public boolean editCellAt(int iRow, int iColumn)
        {
        return __sink.editCellAt(iRow, iColumn);
        }
    /**
    * Programmatically starts editing the cell at (iRow, iColumn), if the cell
    * is editable.
    * 
    * @see #stopCellEditing
    */
    public boolean editCellAt(int iRow, int iColumn, java.util.EventObject event)
        {
        return __sink.editCellAt(iRow, iColumn, event);
        }
    private void editingCanceled$Router(javax.swing.event.ChangeEvent e)
        {
        __sink.editingCanceled(e);
        }
    public void editingCanceled(javax.swing.event.ChangeEvent e)
        {
        int iRow    = getEditingRow();
        int iColumn = getEditingColumn();
        
        editingCanceled$Router(e);
            
        onEditingCanceled(iRow, iColumn);
        }
    private void editingStopped$Router(javax.swing.event.ChangeEvent e)
        {
        __sink.editingStopped(e);
        }
    public void editingStopped(javax.swing.event.ChangeEvent e)
        {
        int iRow     = getEditingRow();
        int iColumn  = getEditingColumn();
        
        // the super call actually applies the changes that have been made
        // to the TableModel, so there is no point in sending the "event"
        // before the changes are applied
        
        editingStopped$Router(e);
        
        onEditingStopped(iRow, iColumn);

        }
    /**
    * Getter for property AutoResizeMode.<p>
    * One of 5 legal values:
    * 
    * AUTO_RESIZE_OFF = 0
    * AUTO_RESIZE_NEXT_COLUMN = 1
    * AUTO_RESIZE_SUBSEQUENT_COLUMNS = 2
    * AUTO_RESIZE_LAST_COLUMN = 3
    * AUTO_RESIZE_ALL_COLUMNS = 4
    */
    public int getAutoResizeMode()
        {
        return __sink.getAutoResizeMode();
        }
    /**
    * Getter for property _CellEditor.<p>
    * Specifoes the current cell editor. This property is only meaningful
    * during cell editing.
    */
    public javax.swing.table.TableCellEditor get_CellEditor()
        {
        return __sink.getCellEditor();
        }
    public javax.swing.table.TableCellEditor getCellEditor(int iRow, int iColumn)
        {
        return __sink.getCellEditor(iRow, iColumn);
        }
    public java.awt.Rectangle getCellRect(int iRow, int iColumn, boolean fIncludeSpacing)
        {
        return __sink.getCellRect(iRow, iColumn, fIncludeSpacing);
        }
    public javax.swing.table.TableCellRenderer getCellRenderer(int iRow, int iColumn)
        {
        return __sink.getCellRenderer(iRow, iColumn);
        }
    /**
    * Getter for property CellSelectionEnabled.<p>
    * Specifies whether this table allows both a column selection and a row
    * selection to exist at the same time. When set, this results in a facility
    * to select a rectangular region of cells in the display.
    * This flag over-rides the row and column selection modes ensuring that
    * cell selection is possible whenever this flag is set.
    */
    public boolean isCellSelectionEnabled()
        {
        return __sink.getCellSelectionEnabled();
        }
    /**
    * Getter for property ColumnCount.<p>
    */
    public int getColumnCount()
        {
        return __sink.getColumnCount();
        }
    /**
    * Getter for property _ColumnModel.<p>
    */
    public javax.swing.table.TableColumnModel get_ColumnModel()
        {
        return __sink.getColumnModel();
        }
    /**
    * Getter for property ColumnSelectionAllowed.<p>
    * Specifies whether the columns in this table can be selected.
    */
    public boolean isColumnSelectionAllowed()
        {
        return __sink.getColumnSelectionAllowed();
        }
    /**
    * Getter for property EditingColumn.<p>
    * (Calculated) Index of the column being edited.
    */
    public int getEditingColumn()
        {
        return __sink.getEditingColumn();
        }
    /**
    * Getter for property EditingRow.<p>
    * (Calculated) Index of the row being edited.
    */
    public int getEditingRow()
        {
        return __sink.getEditingRow();
        }
    /**
    * Getter for property _GridColor.<p>
    */
    public java.awt.Color get_GridColor()
        {
        return __sink.getGridColor();
        }
    /**
    * Getter for property _Model.<p>
    */
    public javax.swing.table.TableModel get_Model()
        {
        return __sink.getModel();
        }
    /**
    * Getter for property RowCount.<p>
    */
    public int getRowCount()
        {
        return __sink.getRowCount();
        }
    /**
    * Getter for property RowHeight.<p>
    * Specifies the height for rows (in pixels, including the inter-cell
    * spacing).
    * Default value is 16, but with our default font size, RowMargin and
    * ColumnMargin values the height of 17 looks the best.
    */
    public int getRowHeight()
        {
        return __sink.getRowHeight();
        }
    /**
    * Getter for property RowMargin.<p>
    * Specifies the amount of emtpy space between rows (in pixels).
    */
    public int getRowMargin()
        {
        return __sink.getRowMargin();
        }
    /**
    * Getter for property RowSelectionAllowed.<p>
    * Specifies whether the rows in this table can be selected.
    */
    public boolean isRowSelectionAllowed()
        {
        return __sink.getRowSelectionAllowed();
        }
    /**
    * Getter for property SelectedColumn.<p>
    * Specifies the index of a currently selected column (assuming single
    * selection mode)
    */
    public int getSelectedColumn()
        {
        return __sink.getSelectedColumn();
        }
    /**
    * Getter for property SelectedColumnCount.<p>
    * (Calculated) Specifies the number of currently selected columns.
    */
    public int getSelectedColumnCount()
        {
        return __sink.getSelectedColumnCount();
        }
    /**
    * Getter for property SelectedColumns.<p>
    * (Calculated) Specifies the indices of all selected columns.
    */
    public int[] getSelectedColumns()
        {
        return __sink.getSelectedColumns();
        }
    /**
    * Getter for property SelectedRow.<p>
    * Specifies the index of a currently selected row (assuming single
    * selection mode)
    */
    public int getSelectedRow()
        {
        return __sink.getSelectedRow();
        }
    /**
    * Getter for property SelectedRowCount.<p>
    * (Calculated) Specifies the number of currently selected rows.
    */
    public int getSelectedRowCount()
        {
        return __sink.getSelectedRowCount();
        }
    /**
    * Getter for property SelectedRows.<p>
    * (Calculated) Specifies the indices of all selected rows.
    */
    public int[] getSelectedRows()
        {
        return __sink.getSelectedRows();
        }
    /**
    * Getter for property _SelectionBackground.<p>
    */
    public java.awt.Color get_SelectionBackground()
        {
        return __sink.getSelectionBackground();
        }
    /**
    * Getter for property _SelectionForeground.<p>
    */
    public java.awt.Color get_SelectionForeground()
        {
        return __sink.getSelectionForeground();
        }
    /**
    * Getter for property _SelectionModel.<p>
    */
    public javax.swing.ListSelectionModel get_SelectionModel()
        {
        return __sink.getSelectionModel();
        }
    /**
    * Getter for property ShowHorizontalLines.<p>
    */
    public boolean isShowHorizontalLines()
        {
        return __sink.getShowHorizontalLines();
        }
    /**
    * Getter for property ShowVerticalLines.<p>
    */
    public boolean isShowVerticalLines()
        {
        return __sink.getShowVerticalLines();
        }
    /**
    * Getter for property _TableHeader.<p>
    */
    public javax.swing.table.JTableHeader get_TableHeader()
        {
        return __sink.getTableHeader();
        }
    public Object getValueAt(int iRow, int iColumn)
        {
        return __sink.getValueAt(iRow, iColumn);
        }
    private boolean isCellEditable$Router(int iRow, int iColumn)
        {
        return __sink.isCellEditable(iRow, iColumn);
        }
    public boolean isCellEditable(int iRow, int iColumn)
        {
        // if the table is enabled and the column is editable, ask the table;
        // otherwise false
        
        return isEnabled() && getColumn(iColumn).isEditable() ?
            isCellEditable$Router(iRow, iColumn) : false;

        }
    public boolean isCellSelected(int iRow, int iColumn)
        {
        return __sink.isCellSelected(iRow, iColumn);
        }
    public boolean isColumnSelected(int pColumnSelected)
        {
        return __sink.isColumnSelected(pColumnSelected);
        }
    /**
    * Getter for property Editing.<p>
    * (Calculated) Specifies whether a cell is being edited.
    */
    public boolean isEditing()
        {
        return __sink.isEditing();
        }
    public boolean isRowSelected(int row)
        {
        return __sink.isRowSelected(row);
        }
    public void moveColumn(int index, int indexNew)
        {
        __sink.moveColumn(index, indexNew);
        }
    private java.awt.Component prepareEditor$Router(javax.swing.table.TableCellEditor editor, int iRow, int iColumn)
        {
        return __sink.prepareEditor(editor, iRow, iColumn);
        }
    /**
    * Prepares the editor by querying the data model for the value and 
    * selection state of the cell at <code>row</code>, <code>column</code>.
    */
    public java.awt.Component prepareEditor(javax.swing.table.TableCellEditor editor, int iRow, int iColumn)
        {
        // import java.awt.Component;
        // import java.awt.dnd.DropTarget;
        // import java.awt.dnd.DropTargetListener;
        // import javax.swing.text.JTextComponent;
        
        Component _editor = prepareEditor$Router(editor, iRow, iColumn);
        
        // this should have been done by JTable itself
        _editor.setFont(get_Font());
        
        if (_editor instanceof JTextComponent)
            {
            // all the following is needed to remove the current content
            // if the editing started by a keystroke
            JTextComponent text = (JTextComponent) _editor;
        
            text.selectAll();
            text.getCaret().setVisible(true);
            if (((_JTable) get_Feed()).isValid())
                {
                // without this the first time change doesn't repaint
                repaint();
                }
        
            if (isDropAllowed())
                {
                DropTarget target = new DropTarget(
                    text, getDropActions(), (DropTargetListener) this, true);
                }
            }
        
        if (_editor instanceof Component)
            {
            _editor.addFocusListener(this);
            }
        return _editor;
        }
    public java.awt.Component prepareRenderer(javax.swing.table.TableCellRenderer renderer, int iRow, int iColumn)
        {
        return __sink.prepareRenderer(renderer, iRow, iColumn);
        }
    private void removeEditor$Router()
        {
        __sink.removeEditor();
        }
    /**
    * Discards the editor object and frees the real estate it used for cell
    * rendering.
    */
    public void removeEditor()
        {
        // import java.awt.Component;
        // import javax.swing.table.TableCellEditor;
        
        // see prepareEditor
        TableCellEditor _editor = get_CellEditor();
        if (_editor instanceof Component)
            {
            ((Component) _editor).removeFocusListener(this);
            }
        
        removeEditor$Router();
        }
    public void selectAll()
        {
        __sink.selectAll();
        }
    /**
    * Setter for property AutoResizeMode.<p>
    * One of 5 legal values:
    * 
    * AUTO_RESIZE_OFF = 0
    * AUTO_RESIZE_NEXT_COLUMN = 1
    * AUTO_RESIZE_SUBSEQUENT_COLUMNS = 2
    * AUTO_RESIZE_LAST_COLUMN = 3
    * AUTO_RESIZE_ALL_COLUMNS = 4
    */
    public void setAutoResizeMode(int pAutoResizeMode)
        {
        __sink.setAutoResizeMode(pAutoResizeMode);
        }
    /**
    * Setter for property _CellEditor.<p>
    * Specifoes the current cell editor. This property is only meaningful
    * during cell editing.
    */
    public void set_CellEditor(javax.swing.table.TableCellEditor p_CellEditor)
        {
        __sink.setCellEditor(p_CellEditor);
        }
    /**
    * Setter for property CellSelectionEnabled.<p>
    * Specifies whether this table allows both a column selection and a row
    * selection to exist at the same time. When set, this results in a facility
    * to select a rectangular region of cells in the display.
    * This flag over-rides the row and column selection modes ensuring that
    * cell selection is possible whenever this flag is set.
    */
    public void setCellSelectionEnabled(boolean pCellSelectionEnabled)
        {
        __sink.setCellSelectionEnabled(pCellSelectionEnabled);
        }
    private void set_ColumnModel$Router(javax.swing.table.TableColumnModel p_ColumnModel)
        {
        __sink.setColumnModel(p_ColumnModel);
        }
    /**
    * Setter for property _ColumnModel.<p>
    */
    public void set_ColumnModel(javax.swing.table.TableColumnModel p_ColumnModel)
        {
        if (get_ColumnModel() != null)
            {
            get_ColumnModel().getSelectionModel().removeListSelectionListener(this);
            }
        
        set_ColumnModel$Router(p_ColumnModel);
        
        if (p_ColumnModel != null)
            {
            p_ColumnModel.getSelectionModel().addListSelectionListener(this);
            }
        }
    /**
    * Setter for property ColumnSelectionAllowed.<p>
    * Specifies whether the columns in this table can be selected.
    */
    public void setColumnSelectionAllowed(boolean pColumnSelectionAllowed)
        {
        __sink.setColumnSelectionAllowed(pColumnSelectionAllowed);
        }
    /**
    * Setter for property _GridColor.<p>
    */
    public void set_GridColor(java.awt.Color p_GridColor)
        {
        __sink.setGridColor(p_GridColor);
        }
    /**
    * Setter for property _Model.<p>
    */
    public void set_Model(javax.swing.table.TableModel p_Model)
        {
        __sink.setModel(p_Model);
        }
    /**
    * Setter for property RowHeight.<p>
    * Specifies the height for rows (in pixels, including the inter-cell
    * spacing).
    * Default value is 16, but with our default font size, RowMargin and
    * ColumnMargin values the height of 17 looks the best.
    */
    public void setRowHeight(int pRowHeight)
        {
        __sink.setRowHeight(pRowHeight);
        }
    /**
    * Setter for property RowMargin.<p>
    * Specifies the amount of emtpy space between rows (in pixels).
    */
    public void setRowMargin(int pRowMargin)
        {
        __sink.setRowMargin(pRowMargin);
        }
    /**
    * Setter for property RowSelectionAllowed.<p>
    * Specifies whether the rows in this table can be selected.
    */
    public void setRowSelectionAllowed(boolean pRowSelectionAllowed)
        {
        __sink.setRowSelectionAllowed(pRowSelectionAllowed);
        }
    /**
    * Setter for property _SelectionBackground.<p>
    */
    public void set_SelectionBackground(java.awt.Color p_SelectionBackground)
        {
        __sink.setSelectionBackground(p_SelectionBackground);
        }
    /**
    * Setter for property _SelectionForeground.<p>
    */
    public void set_SelectionForeground(java.awt.Color p_SelectionForeground)
        {
        __sink.setSelectionForeground(p_SelectionForeground);
        }
    /**
    * Setter for property SelectionMode.<p>
    * One of the three legal values:
    * 
    * SINGLE_SELECTION = 0
    * SINGLE_INTERVAL_SELECTION  = 1
    * MULTIPLE_INTERVAL_SELECTION = 2
    */
    public void setSelectionMode(int pSelectionMode)
        {
        __sink.setSelectionMode(pSelectionMode);
        }
    private void set_SelectionModel$Router(javax.swing.ListSelectionModel p_SelectionModel)
        {
        __sink.setSelectionModel(p_SelectionModel);
        }
    /**
    * Setter for property _SelectionModel.<p>
    */
    public void set_SelectionModel(javax.swing.ListSelectionModel p_SelectionModel)
        {
        if (get_SelectionModel() != null)
            {
            get_SelectionModel().removeListSelectionListener(this);
            }
        
        set_SelectionModel$Router(p_SelectionModel);
        
        if (p_SelectionModel != null)
            {
            p_SelectionModel.addListSelectionListener(this);
            }
        }
    /**
    * Setter for property ShowGrid.<p>
    */
    public void setShowGrid(boolean pShowGrid)
        {
        __sink.setShowGrid(pShowGrid);
        }
    /**
    * Setter for property ShowHorizontalLines.<p>
    */
    public void setShowHorizontalLines(boolean pShowHorizontalLines)
        {
        __sink.setShowHorizontalLines(pShowHorizontalLines);
        }
    /**
    * Setter for property ShowVerticalLines.<p>
    */
    public void setShowVerticalLines(boolean pShowVerticalLines)
        {
        __sink.setShowVerticalLines(pShowVerticalLines);
        }
    /**
    * Setter for property _TableHeader.<p>
    */
    public void set_TableHeader(javax.swing.table.JTableHeader p_TableHeader)
        {
        __sink.setTableHeader(p_TableHeader);
        }
    private void setValueAt$Router(Object oValue, int iRow, int iCol)
        {
        __sink.setValueAt(oValue, iRow, iCol);
        }
    public void setValueAt(Object oValue, int iRow, int iCol)
        {
        TableColumn column = getColumn(iCol);
        
        // give the column a shot to validate and format the new value
        oValue = column.format(oValue, iRow);
        if (oValue == null)
            {
            return;
            }
        
        if (column.isSorted())
            {
            Object[] aoRow = getRowValues(iRow);
            aoRow[iCol]    = oValue;
        
            int iRowNew = locateRow(aoRow);
            if (iRowNew > iRow)
                {
                iRowNew--;
                }
            if (iRowNew != iRow)
                {
                boolean fSelect = isRowSelected(iRow);
                moveRow(iRow, iRow, iRowNew);
                if (fSelect)
                    {
                    setSelectedRow(iRowNew);
                    }
                iRow = iRowNew;
                }
            }
        setValueAt$Router(oValue, iRow, iCol);

        }
    /**
    * This method will resize one or more ot the columns in the table so that
    * the total width of all of the JTable's columns will be equal to the width
    * of the table. <p>
    * When setBounds() is called on the JTable, often as a result of resizing
    * of an enclosing window - 
    * this method is called with <code>iColumn</code> set to -1. This means
    * that resizing has taken place 'outside' the JTable and the change - or
    * 'delta' - should be distributed to all of the columns regardless of the
    * JTable's autoResizeMode mode. <p>
    * If the <code>iColumn</code> is not -1, it is one of the columns in the
    * table that has changed size rather than the table itself. In this case
    * the auto-resize modes govern the way the extra (or defecit) space is
    * distributed amongst the availible columns.
    */
    public void sizeColumnsToFit(int iColumn)
        {
        __sink.sizeColumnsToFit(iColumn);
        }
    //-- javax.swing.JTable integration
    
    // Declared at the super level
    /**
    * Add a child component with the specified name to this component.
    * 
    * @param child  a component to add ti this component as a child
    * @param name  a [unique] name to identify this child. If the name is not
    * specified (null is passed) then a unique child name will be automatically
    * assigned
    * 
    * Note: this method fires onAdd() notification only if the parent (this
    * component) has already been fully constructed.
    * Note2: component containment/aggregation produces children initialization
    * code (see __init()) that is executed while the parent is not flagged as
    * _Constructed yet
    */
    public void _addChild(_package.Component child, String name)
        {
        if (child instanceof TableColumn)
            {
            TableColumn column = (TableColumn) child;
            column.setIdentifier(name);
        
            // creation of "designed" columns is deferred until
            // the end of initialization (see onInit())
            if (is_Constructed())
                {
                int index = column.getIndex(); // desirable view index
                int cCols = getColumnCount();
        
                super._addChild(child, name);
        
                if (index >= 0 && index < cCols)
                    {
                    insertColumn(column, index);
                    }
                else
                    {
                    addColumn(column);
                    }
                }
            else
                {
                super._addChild(child, name);
                }
            }

        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.TableColumn;
        // import javax.swing.JTable as _JTable;
        // import javax.swing.table.JTableHeader as _JTableHeader;
        // import javax.swing.table.TableColumn as _TableColumn;
        

        }
    
    // Declared at the super level
    /**
    * Remove the specified child component.
    */
    public void _removeChild(_package.Component child)
        {
        if (child instanceof TableColumn)
            {
            removeColumn((TableColumn) child);
            }
        super._removeChild(child);
        }
    
    /**
    * Adds a column to the table.
    * 
    * This method is used only internally,  use _addChild to add a TableColumn
    * component.
    */
    protected void addColumn(_package.component.gUI.TableColumn column)
        {
        // import javax.swing.table.DefaultTableModel;
        // import javax.swing.table.TableModel;
        
        _JTable       _table  = (_JTable) get_Feed();
        _TableColumn  _column = (_TableColumn) column.get_Feed();
        TableModel    _tm     = get_Model();
        
        // add the column to the TableColumnModel
        
        int index = column.getModelIndex();
        int cCols = getColumnCount();
        if (index < 0 || index > cCols)
            {
            column.setModelIndex(index = cCols);
            }
        
        // add the column to the TableModel if needed
        if (_tm instanceof DefaultTableModel && index == cCols)
            {
            // we turn off the "AutoCreateColumnsFromModel" because it
            // automatically adds columns when the table model changes
            _table.setAutoCreateColumnsFromModel(false);
        
            ((DefaultTableModel) _tm).addColumn(_column.getIdentifier());
            }
        
        // add columnd to the end
        _table.addColumn(_column);
        _assert(column.getIndex() == cCols, column.getIndex() + " != " + cCols);
        
        if (column.isSorted())
            {
            setSorted(true);
            }
        }
    
    public void addRow(Object[] rowData)
        {
        // import javax.swing.table.DefaultTableModel;
        // import javax.swing.table.TableModel;
        
        TableModel _tm = get_Model();
        if (!(_tm instanceof DefaultTableModel))
            {
            throw new UnsupportedOperationException();
            }
        
        int cColumns = getColumnCount();
        int cRows    = getRowCount();
        
        if (rowData.length != cColumns)
            {
            throw new IllegalArgumentException(get_Name() + 
                ".addRow: " + "Invalid array length");
            }
        
        if (isSorted() && cRows > 0)
            {
            int iRow = locateRow(rowData);
            if (iRow < cRows)
                {
                insertRow(rowData, iRow);
                return;
                }
            }
        ((DefaultTableModel) _tm).addRow(rowData);
        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        // import Component.GUI.Dimension;
        // import Component.GUI.Point;
        
        int iCol = config.getInt(sPrefix + ".SelectedColumn", 0);
        int iRow = config.getInt(sPrefix + ".SelectedRow",    0);
        
        // to have the table behaving consistently lets always select something
        // (whether the config info is present and valid or not)
        
        int cCols = getColumnCount();
        int cRows = getRowCount();
        
        if (cCols > 0 && cRows > 0)
            {
            if (iCol >= cCols)
                {
                iCol = cCols - 1;
                }
            setSelectedColumn(iCol);
        
            if (iRow >= cRows)
                {
                iRow = cRows - 1;
                }
            setSelectedRow(iRow);
            }
        
        Point ptViewPosition = new Point();
        ptViewPosition.applyConfig(config, sPrefix + ".ViewPosition");
        setViewPosition(ptViewPosition);
        
        Dimension dimViewSize = new Dimension();
        dimViewSize.applyConfig(config, sPrefix + ".ViewSize");
        setViewSize(dimViewSize);
        
        super.applyConfig(config, sPrefix);
        }
    
    public int columnAtPoint(_package.component.gUI.Point point)
        {
        return ((_JTable) get_Feed()).columnAtPoint(point.get_Point());

        }
    
    // Declared at the super level
    public void focusLost(java.awt.event.FocusEvent e)
        {
        if (e.getSource() == get_Feed())
            {
            super.focusLost(e);
            }
        else
            {
            // cell editor lost focus
            stopCellEditing();
            }
        }
    
    /**
    * Returns the column with the specified ModelIndex
    */
    public _package.component.gUI.TableColumn getColumn(int index)
        {
        // import java.util.Enumeration;
        
        for (Enumeration enum = _enumChildren(); enum.hasMoreElements();)
            {
            TableColumn column = (TableColumn) enum.nextElement();
            if (column.getModelIndex() == index)
                {
                return column;
                }
            }
        throw new IllegalArgumentException(get_Name() + ".getColumn: " +
            "Invalid Model index " + index);
        }
    
    public _package.component.gUI.TableColumn getColumn(Object identifier)
        {
        _TableColumn _column = ((_JTable) get_Feed()).getColumn(identifier);
        
        return (TableColumn) _findFeed(_column);
        }
    
    // Accessor for the property "ColumnMargin"
    /**
    * Getter for property ColumnMargin.<p>
    * Specifies the ColumnMarging in TableColumnModel. Default value is 1,
    * which chops the leftmost pixels (due to changes in JDK 1.3).
    */
    public int getColumnMargin()
        {
        return ((_JTable) get_Feed()).getColumnModel().getColumnMargin();
        }
    
    public String[] getColumnStrings(int iColumn)
        {
        if (iColumn < 0 || iColumn >= getColumnCount())
            {
            throw new IllegalArgumentException(get_Name() + ".getColumnStrings: " +
                "Invalid column " + iColumn);
            }
        
        int cRows = getRowCount();
        String[] asColumn = new String[cRows];
        for (int iRow = 0; iRow < cRows; iRow++)
            {
            asColumn[iRow] = getValueAt(iRow, iColumn).toString();
            }
        return asColumn;
        }
    
    /**
    * Returns the array of values for the specified column.
    */
    public Object[] getColumnValues(int iColumn)
        {
        if (iColumn < 0 || iColumn >= getColumnCount())
            {
            throw new IllegalArgumentException(get_Name() + ".getColumnValues: " +
                "Invalid column " + iColumn);
            }
        
        int cRows = getRowCount();
        Object[] aoColumn = new Object[cRows];
        for (int iRow = 0; iRow < cRows; iRow++)
            {
            aoColumn[iRow] = getValueAt(iRow, iColumn);
            }
        return aoColumn;
        }
    
    // Accessor for the property "DefaultRowValues"
    /**
    * This is a convinience method that could be used by some generic
    * implementations (like TcTable)  to allow adding an empty row of data.
    * 
    * @see TableColumn.getDefaultValue()
    */
    public Object[] getDefaultRowValues()
        {
        int      cCols   = getColumnCount();
        Object[] aoValue = new Object[cCols];
        
        for (int i = 0; i < cCols; i++)
            {
            aoValue[i] = getColumn(i).getDefaultValue();
            }
        
        return aoValue;
        }
    
    // Accessor for the property "LastColumnSelected"
    /**
    * Getter for property LastColumnSelected.<p>
    * not used
    */
    public int getLastColumnSelected()
        {
        return __m_LastColumnSelected;
        }
    
    // Accessor for the property "LastRowSelected"
    /**
    * Getter for property LastRowSelected.<p>
    * not used
    */
    public int getLastRowSelected()
        {
        return __m_LastRowSelected;
        }
    
    public String[] getRowStrings(int iRow)
        {
        if (iRow < 0 || iRow >= getRowCount())
            {
            throw new IllegalArgumentException(get_Name() + ".getRowStrings: " +
                "Invalid row " + iRow);
            }
        
        int cCols = getColumnCount();
        String[] asRow = new String[cCols];
        for (int iCol = 0; iCol < cCols; iCol++)
            {
            asRow[iCol] = getValueAt(iRow, iCol).toString();
            }
        return asRow;
        }
    
    /**
    * Returns the array of values for the specified row.
    */
    public Object[] getRowValues(int iRow)
        {
        if (iRow < 0 || iRow >= getRowCount())
            {
            throw new IllegalArgumentException(get_Name() + ".getRowValues: " +
                "Invalid row " + iRow);
            }
        
        int cCols = getColumnCount();
        Object[] aoRow = new Object[cCols];
        for (int iCol = 0; iCol < cCols; iCol++)
            {
            aoRow[iCol] = getValueAt(iRow, iCol);
            }
        return aoRow;
        }
    
    // Accessor for the property "SelectionMode"
    /**
    * Getter for property SelectionMode.<p>
    * One of the three legal values:
    * 
    * SINGLE_SELECTION = 0
    * SINGLE_INTERVAL_SELECTION  = 1
    * MULTIPLE_INTERVAL_SELECTION = 2
    */
    public int getSelectionMode()
        {
        // for whatever reason javax.swing.JTable class has "setSelectionMode()"
        // (which we integrate), but doesn't implement "getSelectionMode()"
        return get_SelectionModel().getSelectionMode();
        }
    
    /**
    * Inserts a column to the table.
    * 
    * This method is used only internally,  use _addChild to add a TableColumn
    * component.
    */
    protected void insertColumn(_package.component.gUI.TableColumn column, int index)
        {
        addColumn(column);
        if (index >= 0 && index < getColumnCount())
            {
            column.setIndex(index);
            }
        }
    
    public void insertRow(Object[] rowData, int rowIndex)
        {
        // import javax.swing.table.DefaultTableModel;
        // import javax.swing.table.TableModel;
        
        TableModel _tm = get_Model();
        if (_tm instanceof DefaultTableModel)
            {
            ((DefaultTableModel) _tm).insertRow(rowIndex, rowData);
            }
        else
            {
            throw new UnsupportedOperationException();
            }
        

        }
    
    // Accessor for the property "HeaderVisible"
    /**
    * Getter for property HeaderVisible.<p>
    * Specifies whether the table header should be visible. Default is true.
    * 
    * Note: the JTable must be Scrollable in order to have the ColumnHeader.
    * 
    * @see javax.swing.JTable#addNotify
    */
    public boolean isHeaderVisible()
        {
        return get_TableHeader() != null;
        }
    
    // Accessor for the property "ReorderingAllowed"
    /**
    * Getter for property ReorderingAllowed.<p>
    */
    public boolean isReorderingAllowed()
        {
        _JTableHeader _header = get_TableHeader();
        return _header != null && _header.getReorderingAllowed();
        }
    
    // Accessor for the property "ResizingAllowed"
    /**
    * Getter for property ResizingAllowed.<p>
    * Specifies whether the column resizing should be allowed.
    */
    public boolean isResizingAllowed()
        {
        _JTableHeader _header = get_TableHeader();
        return _header != null && _header.getResizingAllowed();
        }
    
    // Accessor for the property "ShowGrid"
    /**
    * Getter for property ShowGrid.<p>
    */
    public boolean isShowGrid()
        {
        return __m_ShowGrid;
        }
    
    // Accessor for the property "Sorted"
    /**
    * Getter for property Sorted.<p>
    * Specifies whether the table is sorted. If set to true, it is assumed that
    * at least one of the table columns is set to be sorted as well.
    * 
    * @see #addRow
    * @see Component.GUI.TableColumn#Sorted
    */
    public boolean isSorted()
        {
        return __m_Sorted;
        }
    
    /**
    * Locate the position for the specified row such that all the sort
    * requirements are satisfied
    */
    protected int locateRow(Object[] rowData)
        {
        int cRows = getRowCount();
        if (cRows > 0)
            {
            int[] aiRange  = new int[] {0, cRows};
            int   cColumns = getColumnCount();
            for (int iCol = 0; iCol < cColumns; iCol++)
                {
                getColumn(iCol).narrowInsertionRange(rowData[iCol], aiRange);
        
                if (aiRange[0] == aiRange[1])
                    {
                    break;
                    }
                }
            return aiRange[1];
            }
        else
            {
            return 0;
            }
        }
    
    /**
    * Moves one or more rows starting at <i>iStart</i> to <i>iEnd</i>  in the
    * model to the <i>iTo</i>.    This method will send a  tableChanged()
    * notification message to all the listeners. <p>
    * 
    * Examples of moves:<p>
    *     1. moveRow(1,3,5);<p>
    *          a|B|C|D|e|f|g|h|i|j|k   - before<p>
    *          a|e|f|B|C|D|g|h|i|j|k   - after<p>
    *     2. moveRow(6,7,1);<p>
    *          a|b|c|d|e|f|G|H|i|j|k   - before<p>
    *          a|G|H|b|c|d|e|f|i|j|k   - after<p>
    * 
    * @param   iStart       the starting row index to be moved
    * @param   iEnd         the ending row index to be moved
    * @param   iTo          the destination of the rows to be moved
    * @exception  ArrayIndexOutOfBoundsException  if any of the indices are out
    * of           range.  Or if endIndex is less than startIndex.
    * 
    * @see DefaultTableModel#moveRow()
    */
    public void moveRow(int iStart, int iEnd, int iTo)
        {
        // import javax.swing.table.DefaultTableModel;
        // import javax.swing.table.TableModel;
        
        TableModel _tm = get_Model();
        if (!(_tm instanceof DefaultTableModel))
            {
            throw new UnsupportedOperationException();
            }
        
        stopCellEditing();
        ((DefaultTableModel) _tm).moveRow(iStart, iEnd, iTo);

        }
    
    /**
    * Notification message called when editing process gets canceled.
    * 
    * @see #editingCanceled
    */
    public void onEditingCanceled(int iRow, int iColumn)
        {
        }
    
    /**
    * Notification message called when editing process gets ended.
    * 
    * @see #editingStopped
    */
    public void onEditingStopped(int iRow, int iColumn)
        {
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import java.util.Enumeration;
        
        super.onInit();
        
        // creation of the TableModel has been deferred till now
        // (see _addChild())
        
        int index = 0;
        for (Enumeration enum = _enumChildrenInOrder(); enum.hasMoreElements();)
            {
            Object child = enum.nextElement();
            if (child instanceof TableColumn)
                {
                TableColumn column = (TableColumn) child;
                column.setModelIndex(index++);
                addColumn(column);
                }
            }
        
        if (index > 0 && getAutoResizeMode() != AUTO_RESIZE_OFF)
            {
            sizeColumnsToFit(-1);
            }
        }
    
    /**
    * Event notification sent when the current selection changes. This method
    * could be called twice -- once for row selection change and once for
    * column selection change. Properties LastColumnSelected and
    * LastRowSelected could be used to filter this out.
    * 
    * @see #valueChanged
    */
    public void onSelected(int iRow, int iColumn)
        {
        }
    
    // Declared at the super level
    /**
    * Prepares to transfer something at the specified location for the
    * specified action
    * 
    * @return true if transfer is going to be accepted; false otherwise
    * 
    * @see dragOver()
    */
    protected boolean prepareTransferAtLocation(_package.component.gUI.Point point, int iAction, java.util.List listFlavors)
        {
        int iColumn = isEditing() ? getEditingColumn() : columnAtPoint(point);
        int iRow    = isEditing() ? getEditingRow()    : rowAtPoint(point);
        
        return iColumn >= 0 && iRow >= 0 && isCellEditable(iRow, iColumn);
        }
    
    // Declared at the super level
    /**
    * Puts (drops) the specified Transferable object at the specified location
    * for the specified action
    * 
    * @return true if transfer is accepted; false otherwise
    * 
    * @see drop()
    */
    protected boolean putTransferAtLocation(java.awt.datatransfer.Transferable transfer, _package.component.gUI.Point point, int iAction)
        {
        // import java.awt.datatransfer.DataFlavor;
        // import java.awt.dnd.DnDConstants;
        
        int iColumn = isEditing() ? getEditingColumn() : columnAtPoint(point);
        int iRow    = isEditing() ? getEditingRow()    : rowAtPoint(point);
        
        if (isEditing())
            {
            get_CellEditor().cancelCellEditing();
            }
        
        if (iColumn < 0 || iRow < 0 || !isCellEditable(iRow, iColumn))
            {
            return false;
            }
        
        setSelectedRow(iRow); // in turn calls "onSelected()"
        
        String sValue = null;
        try
            {
            if (transfer.isDataFlavorSupported(DataFlavor.stringFlavor))
                {    
                sValue = (String) transfer.getTransferData(DataFlavor.stringFlavor);
                }
            }
        // UnsupportedFlavorException, IOException
        catch (Exception e)
            {
            _trace("transfer failed " + e, 1);
            return false;
            }
        
        if (sValue != null)
            {
            if (iAction == DnDConstants.ACTION_COPY)
                {
                // concatenate the transfered value with the old value
                Object oValue = getValueAt(iRow, iColumn);
                if (oValue != null)
                    {
                    sValue = oValue.toString() + sValue;
                    }
                }
        
            setValueAt(sValue, iRow, iColumn);
            }
        
        return true;
        }
    
    public void removeAllRows()
        {
        // import javax.swing.table.DefaultTableModel;
        // import javax.swing.table.TableModel;
        // import javax.swing.event.ChangeEvent;
        
        if (isEditing())
            {
            editingCanceled(new ChangeEvent(this));
            }
        
        TableModel _tm = get_Model();
        if (!(_tm instanceof DefaultTableModel))
            {
            throw new UnsupportedOperationException();
            }
        
        ((DefaultTableModel) _tm).setNumRows(0);

        }
    
    public void removeColumn(_package.component.gUI.TableColumn column)
        {
        throw new UnsupportedOperationException();
        }
    
    public void removeEmptyRows(boolean fTrimSpaces)
        {
        int cRows = getRowCount();
        int cCols = getColumnCount();
        
        NextRow:
        for (int iRow = cRows - 1; iRow >=0; iRow--)
            {
            for (int iCol = 0; iCol < cCols; iCol++)
                {
                String s = getValueAt(iRow, iCol).toString();
                if (fTrimSpaces)
                    {
                    s = s.trim();
                    }
                if (s.length() > 0)
                    continue NextRow;
                }
            // empty row -- remove
            removeRow(iRow);
            }
        }
    
    public void removeRow(int iRow)
        {
        // import javax.swing.table.DefaultTableModel;
        // import javax.swing.table.TableModel;
        // import javax.swing.event.ChangeEvent;
        
        TableModel _tm = get_Model();
        if (!(_tm instanceof DefaultTableModel))
            {
            throw new UnsupportedOperationException();
            }
        
        if (isEditing() && iRow == getEditingRow())
            {
            editingCanceled(new ChangeEvent(this));
            }
        
        int iSelRow = getSelectedRow();
        
        ((DefaultTableModel) _tm).removeRow(iRow);
        
        int cRows = getRowCount();
        if (cRows > 0)
            {
            // JTable's misbehavior: SelectedRow may report incorrectly
            if (iSelRow < 0 || iSelRow >= cRows)
                {
                iSelRow = cRows - 1;
                }
            else
                {
                setSelectedRow(-1); // to force the "valueChanged" event
                }
            setSelectedRow(iSelRow);
            }
        }
    
    public int rowAtPoint(_package.component.gUI.Point point)
        {
        return ((_JTable) get_Feed()).rowAtPoint(point.get_Point());
        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        config.putInt(sPrefix + ".SelectedColumn", getSelectedColumn());
        config.putInt(sPrefix + ".SelectedRow",    getSelectedRow()   );
        
        getViewPosition().saveConfig(config, sPrefix + ".ViewPosition");
        getViewSize    ().saveConfig(config, sPrefix + ".ViewSize");
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "ColumnMargin"
    /**
    * Setter for property ColumnMargin.<p>
    * Specifies the ColumnMarging in TableColumnModel. Default value is 1,
    * which chops the leftmost pixels (due to changes in JDK 1.3).
    */
    public void setColumnMargin(int pColumnMargin)
        {
        ((_JTable) get_Feed()).getColumnModel().setColumnMargin(pColumnMargin);
        }
    
    /**
    * Sets the values in the specified column to the specifed array of objects.
    * If the passed in array is smaller then the amount of rows, the trailing
    * rows will be set to the <code>oFill</code> object; if the array is larger
    * the extra values will be discarded.
    * 
    * @param iRow  index of the row to change
    * @param aoRow  the array of new values
    * @param oFill  an object to fill the extra columns; if null those columns
    * will not be changed
    */
    public void setColumnValues(int iColumn, Object[] aoColumn, Object oFill)
        {
        if (iColumn < 0 || iColumn >= getColumnCount())
            {
            throw new IllegalArgumentException(get_Name() + ".setColumnValues: " +
                "Invalid column " + iColumn);
            }
        
        int cValues = aoColumn == null ? 0 : aoColumn.length;
        int cRows   = getRowCount();
        int cSet    = Math.min(cRows, cValues);
        
        for (int iRow = 0; iRow < cSet; iRow++)
            {
            setValueAt(aoColumn[iRow], iRow, iColumn);
            }
        
        
        if (oFill != null)
            {
            for (int iRow = cSet; iRow < cRows; iRow++)
                {
                setValueAt(oFill, iRow, iColumn);
                }
            }
        }
    
    // Declared at the super level
    /**
    * Setter for property Font.<p>
    */
    public void setFont(_package.component.gUI.Font pFont)
        {
        super.setFont(pFont);
        
        // TODO: should we make available the full access to JTableHeader?
        _JTableHeader _header = get_TableHeader();
        if (_header != null)
            {
            _header.setFont(pFont.get_Font());
            }
        }
    
    // Accessor for the property "HeaderVisible"
    /**
    * Setter for property HeaderVisible.<p>
    * Specifies whether the table header should be visible. Default is true.
    * 
    * Note: the JTable must be Scrollable in order to have the ColumnHeader.
    * 
    * @see javax.swing.JTable#addNotify
    */
    public void setHeaderVisible(boolean pHeaderVisible)
        {
        if (pHeaderVisible == isHeaderVisible())
            {
            return;
            }
        
        set_TableHeader(pHeaderVisible ?
            new _JTableHeader(get_ColumnModel()) : null);
        }
    
    // Accessor for the property "LastColumnSelected"
    /**
    * Setter for property LastColumnSelected.<p>
    * not used
    */
    public void setLastColumnSelected(int pLastColumnSelected)
        {
        __m_LastColumnSelected = pLastColumnSelected;
        }
    
    // Accessor for the property "LastRowSelected"
    /**
    * Setter for property LastRowSelected.<p>
    * not used
    */
    public void setLastRowSelected(int pLastRowSelected)
        {
        __m_LastRowSelected = pLastRowSelected;
        }
    
    // Accessor for the property "ReorderingAllowed"
    /**
    * Setter for property ReorderingAllowed.<p>
    */
    public void setReorderingAllowed(boolean pReorderingAllowed)
        {
        _JTableHeader _header = get_TableHeader();
        if (_header != null)
            {
            _header.setReorderingAllowed(pReorderingAllowed);
            }
        }
    
    // Accessor for the property "ResizingAllowed"
    /**
    * Setter for property ResizingAllowed.<p>
    * Specifies whether the column resizing should be allowed.
    */
    public void setResizingAllowed(boolean pResizingAllowed)
        {
        _JTableHeader _header = get_TableHeader();
        if (_header != null)
            {
            _header.setResizingAllowed(pResizingAllowed);
            }
        }
    
    /**
    * Sets the values in the specified row to the specifed array of objects. If
    * the passed in array is smaller then the amount of columns, the trailing
    * columns are set to the <code>oFill</code> object; if the array is larger
    * the extra values will be discarded.
    * 
    * @param iRow  index of the row to change
    * @param aoRow  the array of new values
    * @param oFill  an object to fill the extra columns; if null those rows
    * will not be changed
    */
    public void setRowValues(int iRow, Object[] aoRow, Object oFill)
        {
        if (iRow < 0 || iRow >= getRowCount())
            {
            throw new IllegalArgumentException(get_Name() + ".setRowValues: " +
                "Invalid row " + iRow);
            }
        
        int cValues  = aoRow == null ? 0 : aoRow.length;
        int cColumns = getColumnCount();
        int cSet     = Math.min(cColumns, cValues);
        
        for (int iColumn = 0; iColumn < cSet; iColumn++)
            {
            setValueAt(aoRow[iColumn], iRow, iColumn);
            }
        
        if (oFill != null)
            {
            for (int iColumn = cSet; iColumn < cColumns; iColumn++)
                {
                setValueAt(oFill, iRow, iColumn);
                }
            }
        }
    
    // Accessor for the property "SelectedColumn"
    /**
    * Setter for property SelectedColumn.<p>
    * Specifies the index of a currently selected column (assuming single
    * selection mode)
    */
    public void setSelectedColumn(int pSelectedColumn)
        {
        if (pSelectedColumn == -1)
            {
            get_ColumnModel().getSelectionModel().clearSelection();
            }
        else
            {
            // get_ColumnModel().getSelectionModel().
            //   setSelectionInterval(pSelectedColumn, pSelectedColumn);
            ((_JTable) get_Feed()).changeSelection(-1, pSelectedColumn, false, false);
            }

        }
    
    // Accessor for the property "SelectedRow"
    /**
    * Setter for property SelectedRow.<p>
    * Specifies the index of a currently selected row (assuming single
    * selection mode)
    */
    public void setSelectedRow(int pSelectedRow)
        {
        if (pSelectedRow == -1)
            {
            get_SelectionModel().clearSelection();
            }
        else
            {
            // get_SelectionModel().setSelectionInterval(pSelectedRow, pSelectedRow);
            ((_JTable) get_Feed()).changeSelection(pSelectedRow, -1, false, false);
            }
        }
    
    // Accessor for the property "Sorted"
    /**
    * Setter for property Sorted.<p>
    * Specifies whether the table is sorted. If set to true, it is assumed that
    * at least one of the table columns is set to be sorted as well.
    * 
    * @see #addRow
    * @see Component.GUI.TableColumn#Sorted
    */
    public void setSorted(boolean pSorted)
        {
        __m_Sorted = pSorted;
        }
    
    /**
    * Programmatically stops the cell editing.
    * 
    * @see #editCellAt
    */
    public void stopCellEditing()
        {
        if (isEditing())
            {
            get_CellEditor().stopCellEditing();
            }

        }
    
    public void updateCellAt(int iRow, int iColumn)
        {
        // TODO: integrate this?
        ((javax.swing.table.DefaultTableModel) get_Model()).
            fireTableCellUpdated(iRow, iColumn);

        }
    
    // From interface: javax.swing.event.ListSelectionListener
    public void valueChanged(javax.swing.event.ListSelectionEvent e)
        {
        /*
        _trace("*** value changed " + e.getValueIsAdjusting() +
            " row=" + getSelectedRow() + " col=" + getSelectedColumn() +
            " lead=" + get_SelectionModel().getLeadSelectionIndex() +
            " anchor=" + get_SelectionModel().getAnchorSelectionIndex());
        */
        // JTable's bug the values are incorrect when ValueIsAdjusting set to true
        // (happens when the mouse is dragged)
        if (!e.getValueIsAdjusting())
            {
            int iRow = getSelectedRow();
            int iCol = getSelectedColumn();
            // JTable's misbehavior: Sometimes it comes with iRow == -1 or iRow == cRows
            if (iRow >= 0 && iRow < getRowCount() && iCol >= 0)
                {
                onSelected(iRow, iCol);
                
                setLastRowSelected(iRow);
                setLastColumnSelected(iCol);
                }
            }
        }
    }
