/* Class
*     _package.component.gUI.control.container.window.frame.JFrame
*/

package _package.component.gUI.control.container.window.frame;

import javax.swing.JFrame; // as _JFrame
import javax.swing.WindowConstants;

/*
* Integrates
*     javax.swing.JFrame
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JFrame
        extends    _package.component.gUI.control.container.window.Frame
    {
    // Fields declarations
    
    // fields used by the integration model:
    private sink_JFrame __sink;
    private javax.swing.JFrame __feed;
    
    // Default constructor
    public JFrame()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JFrame(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setTBounds("100,100,290,250");
            setTLayout("BorderLayout");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JFrame.__tloPeer.setObject(this);
            new jb_JFrame(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JFrame();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/window/frame/JFrame".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JFrame integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JFrame) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JFrame) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public void _add(java.awt.Component comp, Object constraints, int index)
        {
        ((_JFrame) get_Feed()).getContentPane().add(comp, constraints, index);
        }
    public java.awt.LayoutManager get_Layout()
        {
        return ((_JFrame) get_Feed()).getContentPane().getLayout();
        }
    //-- javax.swing.JFrame integration
    
    // Declared at the super level
    public void _imports()
        {
        // import javax.swing.JFrame as _JFrame;
        
        

        }
    
    // Declared at the super level
    /**
    * Hosts (adds as a child) the specified JPanel and make the client area of
    * this container equal to the size of the hosted panel.
    * 
    * @see #getHostedPanel
    */
    public void hostPanel(_package.component.gUI.control.container.jComponent.JPanel panel)
        {
        setIconImage(panel.getIcon());
        setLocation (panel.getLocation());
        setResizable(panel.isResizable());
        setTitle    (panel.getTitle());
        
        super.hostPanel(panel);
        }
    
    // Declared at the super level
    /**
    * The "component has been added to a containing component"
    * method-notification.
    * 
    * Note: this notification is not sent during the component's state
    * initialization (deserialization)
    * 
    * @see _addChild
    */
    public void onAdd()
        {
        throw new IllegalStateException(get_Name() +
            ".onAdd: cannot be a child -- use Owner property instead");

        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import javax.swing.WindowConstants;
        
        // close event is explicitly handled by the onClosing event handler
        // see Component.GUI.Window#onWindowClosing()
        ((_JFrame) get_Feed()).setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        
        super.onInit();
        }
    
    // Declared at the super level
    public void setLayout(_package.component.gUI.LayoutManager pLayout)
        {
        ((_JFrame) get_Feed()).getContentPane().setLayout(pLayout);
        }
    }
