/* Class
*     _package.component.gUI.control.container.jComponent.abstractButton.jMenuItem.JMenu
*/

package _package.component.gUI.control.container.jComponent.abstractButton.jMenuItem;

import _package.component.gUI.control.container.jComponent.JSeparator;
import _package.component.gUI.control.container.jComponent.abstractButton.JMenuItem;

/*
* Integrates
*     javax.swing.JMenu
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*
* 
* +++++++++++++++++++++++++++++++++++++
* 
* We don't map the MenuListener dispatch because it is a trivial wrapper around
* ChangeListener dispatch
* 
* @see javax.swing.JMenu#createMenuChangeListener
*
*/
public class JMenu
        extends    _package.component.gUI.control.container.jComponent.abstractButton.JMenuItem
    {
    // Fields declarations
    
    /**
    * Property Delay
    *
    * Specifies the suggested delay before the menu's PopupMenu is popped up or
    * down. Each look and feel may determine its own policy for observing the
    * delay property.  In most cases, the delay is not observed for top level
    * menus or while dragging.
    */
    private transient int __m_Delay;
    
    /**
    * Property PopupMenuVisible
    *
    */
    private transient boolean __m_PopupMenuVisible;
    
    /**
    * Property STATE_CHILD
    *
    * This state-change value bit indicates that a child item's state has
    * changed.
    * 
    * @see JMenuItem#onItemStateChanged
    */
    public static final int STATE_CHILD = 32768;
    
    // fields used by the integration model:
    private sink_JMenu __sink;
    private javax.swing.JMenu __feed;
    
    // Default constructor
    public JMenu()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JMenu(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setTFont("DefaultMenu");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JMenu.__tloPeer.setObject(this);
            new jb_JMenu(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JMenu();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/abstractButton/jMenuItem/JMenu".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JMenu integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JMenu) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JMenu) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public void _add(java.awt.Component comp, Object constraints, int index)
        {
        javax.swing.JPopupMenu _popup = ((javax.swing.JMenu) get_Feed()).getPopupMenu();
        
        if (index >= 0)
            {
            _popup.insert(comp, index);
            }
        else
            {
            _popup.add(comp);
            }
        }
    public void addSeparator()
        {
        __sink.addSeparator();
        }
    public int getDelay()
        {
        return __sink.getDelay();
        }
    public boolean isPopupMenuVisible()
        {
        return __sink.isPopupMenuVisible();
        }
    public void setDelay(int pDelay)
        {
        __sink.setDelay(pDelay);
        }
    public void setPopupMenuVisible(boolean pPopupMenuVisible)
        {
        __sink.setPopupMenuVisible(pPopupMenuVisible);
        }
    //-- javax.swing.JMenu integration
    
    // Declared at the super level
    /**
    * Adds the visual feed of the specified child component to the visual feed
    * of this container. Having this functionality separate from _addChild
    * allows it to be overwritten by containers that know better.
    * 
    * @see #_addChild
    */
    public void addControl(_package.component.gUI.Control child)
        {
        // import Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem;
        // import Component.GUI.Control.Container.JComponent.JSeparator;
        
        java.awt.Component _item = child.getAWTContainee(true);
        if (_item == null)
            {
            return; // nothing to add
            }
        
        javax.swing.JMenu  _menu = (javax.swing.JMenu) get_Feed();
        
        int index = child.get_Position();
        if (index >= _menu.getMenuComponentCount())
            {
            index = -1;
            }
        
        if (child instanceof JMenuItem)
            {
            if (index >= 0)
                {
                _menu.insert((javax.swing.JMenuItem) _item, index);
                }
            else
                {
                _menu.add((javax.swing.JMenuItem) _item);
                }
            }
        else
            {
            // adding all other controls is handled by _add()
            _add(_item, null, index);
            }
        }
    }
