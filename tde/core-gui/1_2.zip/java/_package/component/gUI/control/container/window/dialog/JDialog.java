/* Class
*     _package.component.gUI.control.container.window.dialog.JDialog
*/

package _package.component.gUI.control.container.window.dialog;

import _package.component.gUI.control.container.Window;
import javax.swing.JDialog; // as _JDialog
import javax.swing.WindowConstants;

/*
* Integrates
*     javax.swing.JDialog
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JDialog
        extends    _package.component.gUI.control.container.window.Dialog
    {
    // Fields declarations
    
    // fields used by the integration model:
    private sink_JDialog __sink;
    private javax.swing.JDialog __feed;
    
    // Default constructor
    public JDialog()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JDialog(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setVisible(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JDialog();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/window/dialog/JDialog".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JDialog integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JDialog) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JDialog) pFeed;
        super.set_Feed(pFeed);
        }
    private void _initFeed$AutoGen(java.awt.Dialog _ownerDialog)
        {
        jb_JDialog.__tloPeer.setObject(this);
        new jb_JDialog(_ownerDialog, this, false); // this sets the Sink which sets the Feed
        __init();
        }
    public void _initFeed(java.awt.Dialog _ownerDialog)
        {
        // import Component.GUI.Control.Container.Window;
        
        _initFeed$AutoGen(_ownerDialog);
        setOwner((Window) _findFeed(_ownerDialog));

        }
    private void _initFeed$AutoGen(java.awt.Frame _ownerFrame)
        {
        jb_JDialog.__tloPeer.setObject(this);
        new jb_JDialog(_ownerFrame, this, false); // this sets the Sink which sets the Feed
        __init();
        }
    public void _initFeed(java.awt.Frame _ownerFrame)
        {
        // import Component.GUI.Control.Container.Window;
        
        _initFeed$AutoGen(_ownerFrame);
        setOwner((Window) _findFeed(_ownerFrame));

        }
    // properties integration
    // methods integration
    public void _add(java.awt.Component comp, Object constraints, int index)
        {
        ((_JDialog) get_Feed()).getContentPane().add(comp, constraints, index);
        }
    /**
    * Releases all of the native screen resources used by this Window,  its
    * subcomponents, and all of its owned children. That is, the resources for
    * these Components will be destroyed, any memory they consume will be
    * returned to the OS, and they will be marked as undisplayable. As a result
    * of this, the removeNotify will be called (possibly on a different thread).
    */
    public void dispose()
        {
        getOwner().setEnabled(true);
        setVisible(false);
        
        super.dispose();
        }
    public java.awt.LayoutManager get_Layout()
        {
        _JDialog _feed = (_JDialog) get_Feed();
        
        return _feed.getRootPane() != null ?
            _feed.getContentPane().getLayout() : super.get_Layout();
        }
    public void set_Layout(java.awt.LayoutManager p_Layout)
        {
        _JDialog _feed = (_JDialog) get_Feed();
        
        if (_feed.getRootPane() != null)
            {
            _feed.getContentPane().setLayout(p_Layout);
            }
        else
            {
            super.set_Layout(p_Layout);
            }
        }
    public void set_LocationRelativeTo(java.awt.Component _comp)
        {
        __sink.setLocationRelativeTo(_comp);
        }
    //-- javax.swing.JDialog integration
    
    // Declared at the super level
    public void _imports()
        {
        // import javax.swing.JDialog as _JDialog;
        

        }
    
    public void _initFeed()
        {
        }
    
    // Declared at the super level
    /**
    * Hosts (adds as a child) the specified JPanel and make the client area of
    * this container equal to the size of the hosted panel.
    * 
    * @see #getHostedPanel
    */
    public void hostPanel(_package.component.gUI.control.container.jComponent.JPanel panel)
        {
        setLocation (panel.getLocation());
        setResizable(panel.isResizable());
        setTitle    (panel.getTitle());
        
        super.hostPanel(panel);
        
        // in order for the "setLocationRelativeTo()" to work,
        // the "Bounds" property has to be already set
        setLocationRelativeTo(getOwner());
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import javax.swing.WindowConstants;
        
        // close event is explicitly handled by the onClosing event handler
        // see Component.GUI.Window#onWindowClosing()
        ((_JDialog) get_Feed()).setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        
        super.onInit();
        }
    
    // Declared at the super level
    public void onWindowClosing()
        {
        getHostedPanel().endDialog(null);
        
        // we don't call "super.onWindowClosing();" !
        }
    
    public void setLocationRelativeTo(_package.component.gUI.Control control)
        {
        set_LocationRelativeTo((java.awt.Component) control.get_Feed());
        }
    }
