/* Class
*      jb_JTable
*
* automatically generated "Feed" which
* a) extends an external bean:
*      javax.swing.JTable
* b) delegates to the peer component:
*      Component.GUI.Control.Container.JComponent.JTable
*/

package _package.component.gUI.control.container.jComponent;

public class jb_JTable
        extends    javax.swing.JTable
        implements com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected JTable __peer;
    
    private static JTable __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            JTable peer = (JTable)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // default (JavaBean) constructor
    public jb_JTable()
        {
        this(JTable.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTable(int Param_1, int Param_2)
        {
        this(Param_1, Param_2, JTable.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTable(java.util.Vector Param_1, java.util.Vector Param_2)
        {
        this(Param_1, Param_2, JTable.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTable(javax.swing.table.TableModel Param_1)
        {
        this(Param_1, JTable.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTable(javax.swing.table.TableModel Param_1, javax.swing.table.TableColumnModel Param_2)
        {
        this(Param_1, Param_2, JTable.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTable(javax.swing.table.TableModel Param_1, javax.swing.table.TableColumnModel Param_2, javax.swing.ListSelectionModel Param_3)
        {
        this(Param_1, Param_2, Param_3, JTable.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTable(Object[][] Param_1, Object[] Param_2)
        {
        this(Param_1, Param_2, JTable.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTable(Class clzPeer)
        {
        this(__createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTable(int Param_1, int Param_2, Class clzPeer)
        {
        this(Param_1, Param_2, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTable(java.util.Vector Param_1, java.util.Vector Param_2, Class clzPeer)
        {
        this(Param_1, Param_2, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTable(javax.swing.table.TableModel Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTable(javax.swing.table.TableModel Param_1, javax.swing.table.TableColumnModel Param_2, Class clzPeer)
        {
        this(Param_1, Param_2, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTable(javax.swing.table.TableModel Param_1, javax.swing.table.TableColumnModel Param_2, javax.swing.ListSelectionModel Param_3, Class clzPeer)
        {
        this(Param_1, Param_2, Param_3, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTable(Object[][] Param_1, Object[] Param_2, Class clzPeer)
        {
        this(Param_1, Param_2, __createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTable(JTable peer, boolean fInit)
        {
        super();
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTable(int Param_1, int Param_2, JTable peer, boolean fInit)
        {
        super(Param_1, Param_2);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTable(java.util.Vector Param_1, java.util.Vector Param_2, JTable peer, boolean fInit)
        {
        super(Param_1, Param_2);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTable(javax.swing.table.TableModel Param_1, JTable peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTable(javax.swing.table.TableModel Param_1, javax.swing.table.TableColumnModel Param_2, JTable peer, boolean fInit)
        {
        super(Param_1, Param_2);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTable(javax.swing.table.TableModel Param_1, javax.swing.table.TableColumnModel Param_2, javax.swing.ListSelectionModel Param_3, JTable peer, boolean fInit)
        {
        super(Param_1, Param_2, Param_3);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTable(Object[][] Param_1, Object[] Param_2, JTable peer, boolean fInit)
        {
        super(Param_1, Param_2);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private JTable __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (JTable) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_JTable(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    public void add(java.awt.Component comp, Object constraints, int index)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._add(comp, constraints, index);
        }
    void super$add(java.awt.Component comp, Object constraints, int index)
        {
        super.add(comp, constraints, index);
        }
    public void remove(java.awt.Component comp)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._remove(comp);
        }
    void super$remove(java.awt.Component comp)
        {
        super.remove(comp);
        }
    public void addFocusListener(java.awt.event.FocusListener l)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addFocusListener(l);
        }
    void super$addFocusListener(java.awt.event.FocusListener l)
        {
        super.addFocusListener(l);
        }
    public void addKeyListener(java.awt.event.KeyListener l)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addKeyListener(l);
        }
    void super$addKeyListener(java.awt.event.KeyListener l)
        {
        super.addKeyListener(l);
        }
    public void addMouseListener(java.awt.event.MouseListener l)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseListener(l);
        }
    void super$addMouseListener(java.awt.event.MouseListener l)
        {
        super.addMouseListener(l);
        }
    public void addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseMotionListener(l);
        }
    void super$addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.addMouseMotionListener(l);
        }
    public void addNotify()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addNotify();
        }
    void super$addNotify()
        {
        super.addNotify();
        }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addPropertyChangeListener(l);
        }
    void super$addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.addPropertyChangeListener(l);
        }
    public void addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addVetoableChangeListener(l);
        }
    void super$addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.addVetoableChangeListener(l);
        }
    public void clearSelection()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.clearSelection();
        }
    void super$clearSelection()
        {
        super.clearSelection();
        }
    public javax.swing.JToolTip createToolTip()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.createToolTip();
        }
    javax.swing.JToolTip super$createToolTip()
        {
        return super.createToolTip();
        }
    public void doLayout()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.doLayout();
        }
    void super$doLayout()
        {
        super.doLayout();
        }
    public boolean editCellAt(int iRow, int iColumn)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.editCellAt(iRow, iColumn);
        }
    boolean super$editCellAt(int iRow, int iColumn)
        {
        return super.editCellAt(iRow, iColumn);
        }
    public boolean editCellAt(int iRow, int iColumn, java.util.EventObject event)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.editCellAt(iRow, iColumn, event);
        }
    boolean super$editCellAt(int iRow, int iColumn, java.util.EventObject event)
        {
        return super.editCellAt(iRow, iColumn, event);
        }
    public void editingCanceled(javax.swing.event.ChangeEvent e)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.editingCanceled(e);
        }
    void super$editingCanceled(javax.swing.event.ChangeEvent e)
        {
        super.editingCanceled(e);
        }
    public void editingStopped(javax.swing.event.ChangeEvent e)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.editingStopped(e);
        }
    void super$editingStopped(javax.swing.event.ChangeEvent e)
        {
        super.editingStopped(e);
        }
    public java.awt.Color getBackground()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Background();
        }
    java.awt.Color super$getBackground()
        {
        return super.getBackground();
        }
    public javax.swing.border.Border getBorder()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Border();
        }
    javax.swing.border.Border super$getBorder()
        {
        return super.getBorder();
        }
    public java.awt.Rectangle getBounds()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Bounds();
        }
    java.awt.Rectangle super$getBounds()
        {
        return super.getBounds();
        }
    public javax.swing.table.TableCellEditor getCellEditor()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_CellEditor();
        }
    javax.swing.table.TableCellEditor super$getCellEditor()
        {
        return super.getCellEditor();
        }
    public javax.swing.table.TableColumnModel getColumnModel()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_ColumnModel();
        }
    javax.swing.table.TableColumnModel super$getColumnModel()
        {
        return super.getColumnModel();
        }
    public java.awt.Cursor getCursor()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Cursor();
        }
    java.awt.Cursor super$getCursor()
        {
        return super.getCursor();
        }
    public java.awt.Font getFont()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Font();
        }
    java.awt.Font super$getFont()
        {
        return super.getFont();
        }
    public java.awt.Color getForeground()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Foreground();
        }
    java.awt.Color super$getForeground()
        {
        return super.getForeground();
        }
    public java.awt.Color getGridColor()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_GridColor();
        }
    java.awt.Color super$getGridColor()
        {
        return super.getGridColor();
        }
    public java.awt.Insets getInsets()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Insets();
        }
    java.awt.Insets super$getInsets()
        {
        return super.getInsets();
        }
    public java.awt.LayoutManager getLayout()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Layout();
        }
    java.awt.LayoutManager super$getLayout()
        {
        return super.getLayout();
        }
    public java.awt.Point getLocation()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Location();
        }
    java.awt.Point super$getLocation()
        {
        return super.getLocation();
        }
    public java.awt.Point getLocationOnScreen()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_LocationOnScreen();
        }
    java.awt.Point super$getLocationOnScreen()
        {
        return super.getLocationOnScreen();
        }
    public java.awt.Dimension getMaximumSize()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MaximumSize();
        }
    java.awt.Dimension super$getMaximumSize()
        {
        return super.getMaximumSize();
        }
    public java.awt.Dimension getMinimumSize()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MinimumSize();
        }
    java.awt.Dimension super$getMinimumSize()
        {
        return super.getMinimumSize();
        }
    public javax.swing.table.TableModel getModel()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Model();
        }
    javax.swing.table.TableModel super$getModel()
        {
        return super.getModel();
        }
    public java.awt.Dimension getPreferredSize()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_PreferredSize();
        }
    java.awt.Dimension super$getPreferredSize()
        {
        return super.getPreferredSize();
        }
    public java.awt.Color getSelectionBackground()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_SelectionBackground();
        }
    java.awt.Color super$getSelectionBackground()
        {
        return super.getSelectionBackground();
        }
    public java.awt.Color getSelectionForeground()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_SelectionForeground();
        }
    java.awt.Color super$getSelectionForeground()
        {
        return super.getSelectionForeground();
        }
    public javax.swing.ListSelectionModel getSelectionModel()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_SelectionModel();
        }
    javax.swing.ListSelectionModel super$getSelectionModel()
        {
        return super.getSelectionModel();
        }
    public java.awt.Dimension getSize()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Size();
        }
    java.awt.Dimension super$getSize()
        {
        return super.getSize();
        }
    public javax.swing.table.JTableHeader getTableHeader()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_TableHeader();
        }
    javax.swing.table.JTableHeader super$getTableHeader()
        {
        return super.getTableHeader();
        }
    public int getAutoResizeMode()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getAutoResizeMode();
        }
    int super$getAutoResizeMode()
        {
        return super.getAutoResizeMode();
        }
    public javax.swing.table.TableCellEditor getCellEditor(int iRow, int iColumn)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getCellEditor(iRow, iColumn);
        }
    javax.swing.table.TableCellEditor super$getCellEditor(int iRow, int iColumn)
        {
        return super.getCellEditor(iRow, iColumn);
        }
    public java.awt.Rectangle getCellRect(int iRow, int iColumn, boolean fIncludeSpacing)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getCellRect(iRow, iColumn, fIncludeSpacing);
        }
    java.awt.Rectangle super$getCellRect(int iRow, int iColumn, boolean fIncludeSpacing)
        {
        return super.getCellRect(iRow, iColumn, fIncludeSpacing);
        }
    public javax.swing.table.TableCellRenderer getCellRenderer(int iRow, int iColumn)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getCellRenderer(iRow, iColumn);
        }
    javax.swing.table.TableCellRenderer super$getCellRenderer(int iRow, int iColumn)
        {
        return super.getCellRenderer(iRow, iColumn);
        }
    public int getColumnCount()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getColumnCount();
        }
    int super$getColumnCount()
        {
        return super.getColumnCount();
        }
    public int getEditingColumn()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getEditingColumn();
        }
    int super$getEditingColumn()
        {
        return super.getEditingColumn();
        }
    public int getEditingRow()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getEditingRow();
        }
    int super$getEditingRow()
        {
        return super.getEditingRow();
        }
    public int getRowCount()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getRowCount();
        }
    int super$getRowCount()
        {
        return super.getRowCount();
        }
    public int getRowHeight()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getRowHeight();
        }
    int super$getRowHeight()
        {
        return super.getRowHeight();
        }
    public int getRowMargin()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getRowMargin();
        }
    int super$getRowMargin()
        {
        return super.getRowMargin();
        }
    public int getSelectedColumn()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectedColumn();
        }
    int super$getSelectedColumn()
        {
        return super.getSelectedColumn();
        }
    public int getSelectedColumnCount()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectedColumnCount();
        }
    int super$getSelectedColumnCount()
        {
        return super.getSelectedColumnCount();
        }
    public int[] getSelectedColumns()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectedColumns();
        }
    int[] super$getSelectedColumns()
        {
        return super.getSelectedColumns();
        }
    public int getSelectedRow()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectedRow();
        }
    int super$getSelectedRow()
        {
        return super.getSelectedRow();
        }
    public int getSelectedRowCount()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectedRowCount();
        }
    int super$getSelectedRowCount()
        {
        return super.getSelectedRowCount();
        }
    public int[] getSelectedRows()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectedRows();
        }
    int[] super$getSelectedRows()
        {
        return super.getSelectedRows();
        }
    public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent e)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipLocation(e);
        }
    java.awt.Point super$getToolTipLocation(java.awt.event.MouseEvent e)
        {
        return super.getToolTipLocation(e);
        }
    public String getToolTipText()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText();
        }
    String super$getToolTipText()
        {
        return super.getToolTipText();
        }
    public String getToolTipText(java.awt.event.MouseEvent e)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText(e);
        }
    String super$getToolTipText(java.awt.event.MouseEvent e)
        {
        return super.getToolTipText(e);
        }
    public Object getValueAt(int iRow, int iColumn)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getValueAt(iRow, iColumn);
        }
    Object super$getValueAt(int iRow, int iColumn)
        {
        return super.getValueAt(iRow, iColumn);
        }
    public boolean getAutoscrolls()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isAutoscrolls();
        }
    boolean super$getAutoscrolls()
        {
        return super.getAutoscrolls();
        }
    public boolean isCellEditable(int iRow, int iColumn)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isCellEditable(iRow, iColumn);
        }
    boolean super$isCellEditable(int iRow, int iColumn)
        {
        return super.isCellEditable(iRow, iColumn);
        }
    public boolean isCellSelected(int iRow, int iColumn)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isCellSelected(iRow, iColumn);
        }
    boolean super$isCellSelected(int iRow, int iColumn)
        {
        return super.isCellSelected(iRow, iColumn);
        }
    public boolean getCellSelectionEnabled()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isCellSelectionEnabled();
        }
    boolean super$getCellSelectionEnabled()
        {
        return super.getCellSelectionEnabled();
        }
    public boolean isColumnSelected(int pColumnSelected)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isColumnSelected(pColumnSelected);
        }
    boolean super$isColumnSelected(int pColumnSelected)
        {
        return super.isColumnSelected(pColumnSelected);
        }
    public boolean getColumnSelectionAllowed()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isColumnSelectionAllowed();
        }
    boolean super$getColumnSelectionAllowed()
        {
        return super.getColumnSelectionAllowed();
        }
    public boolean isEditing()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isEditing();
        }
    boolean super$isEditing()
        {
        return super.isEditing();
        }
    public boolean isEnabled()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isEnabled();
        }
    boolean super$isEnabled()
        {
        return super.isEnabled();
        }
    public boolean isFocusTraversable()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isFocusTraversable();
        }
    boolean super$isFocusTraversable()
        {
        return super.isFocusTraversable();
        }
    public boolean isOpaque()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isOpaque();
        }
    boolean super$isOpaque()
        {
        return super.isOpaque();
        }
    public boolean isRowSelected(int row)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isRowSelected(row);
        }
    boolean super$isRowSelected(int row)
        {
        return super.isRowSelected(row);
        }
    public boolean getRowSelectionAllowed()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isRowSelectionAllowed();
        }
    boolean super$getRowSelectionAllowed()
        {
        return super.getRowSelectionAllowed();
        }
    public boolean getShowHorizontalLines()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isShowHorizontalLines();
        }
    boolean super$getShowHorizontalLines()
        {
        return super.getShowHorizontalLines();
        }
    public boolean isShowing()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isShowing();
        }
    boolean super$isShowing()
        {
        return super.isShowing();
        }
    public boolean getShowVerticalLines()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isShowVerticalLines();
        }
    boolean super$getShowVerticalLines()
        {
        return super.getShowVerticalLines();
        }
    public boolean isVisible()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isVisible();
        }
    boolean super$isVisible()
        {
        return super.isVisible();
        }
    public void moveColumn(int index, int indexNew)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.moveColumn(index, indexNew);
        }
    void super$moveColumn(int index, int indexNew)
        {
        super.moveColumn(index, indexNew);
        }
    public void paint(java.awt.Graphics g)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paint(g);
        }
    void super$paint(java.awt.Graphics g)
        {
        super.paint(g);
        }
    protected void paintBorder(java.awt.Graphics g)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintBorder(g);
        }
    void super$paintBorder(java.awt.Graphics g)
        {
        super.paintBorder(g);
        }
    protected void paintChildren(java.awt.Graphics g)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintChildren(g);
        }
    void super$paintChildren(java.awt.Graphics g)
        {
        super.paintChildren(g);
        }
    protected void paintComponent(java.awt.Graphics g)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintComponent(g);
        }
    void super$paintComponent(java.awt.Graphics g)
        {
        super.paintComponent(g);
        }
    public java.awt.Component prepareEditor(javax.swing.table.TableCellEditor editor, int iRow, int iColumn)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.prepareEditor(editor, iRow, iColumn);
        }
    java.awt.Component super$prepareEditor(javax.swing.table.TableCellEditor editor, int iRow, int iColumn)
        {
        return super.prepareEditor(editor, iRow, iColumn);
        }
    public java.awt.Component prepareRenderer(javax.swing.table.TableCellRenderer renderer, int iRow, int iColumn)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.prepareRenderer(renderer, iRow, iColumn);
        }
    java.awt.Component super$prepareRenderer(javax.swing.table.TableCellRenderer renderer, int iRow, int iColumn)
        {
        return super.prepareRenderer(renderer, iRow, iColumn);
        }
    public void removeEditor()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeEditor();
        }
    void super$removeEditor()
        {
        super.removeEditor();
        }
    public void removeFocusListener(java.awt.event.FocusListener l)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeFocusListener(l);
        }
    void super$removeFocusListener(java.awt.event.FocusListener l)
        {
        super.removeFocusListener(l);
        }
    public void removeKeyListener(java.awt.event.KeyListener l)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeKeyListener(l);
        }
    void super$removeKeyListener(java.awt.event.KeyListener l)
        {
        super.removeKeyListener(l);
        }
    public void removeMouseListener(java.awt.event.MouseListener l)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseListener(l);
        }
    void super$removeMouseListener(java.awt.event.MouseListener l)
        {
        super.removeMouseListener(l);
        }
    public void removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseMotionListener(l);
        }
    void super$removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.removeMouseMotionListener(l);
        }
    public void removeNotify()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeNotify();
        }
    void super$removeNotify()
        {
        super.removeNotify();
        }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removePropertyChangeListener(l);
        }
    void super$removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.removePropertyChangeListener(l);
        }
    public void removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeVetoableChangeListener(l);
        }
    void super$removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.removeVetoableChangeListener(l);
        }
    public void requestFocus()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.requestFocus();
        }
    void super$requestFocus()
        {
        super.requestFocus();
        }
    public void selectAll()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.selectAll();
        }
    void super$selectAll()
        {
        super.selectAll();
        }
    public void setBackground(java.awt.Color p_Background)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Background(p_Background);
        }
    void super$setBackground(java.awt.Color p_Background)
        {
        super.setBackground(p_Background);
        }
    public void setBorder(javax.swing.border.Border p_Border)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Border(p_Border);
        }
    void super$setBorder(javax.swing.border.Border p_Border)
        {
        super.setBorder(p_Border);
        }
    public void setBounds(java.awt.Rectangle p_Bounds)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Bounds(p_Bounds);
        }
    void super$setBounds(java.awt.Rectangle p_Bounds)
        {
        super.setBounds(p_Bounds);
        }
    public void setCellEditor(javax.swing.table.TableCellEditor p_CellEditor)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_CellEditor(p_CellEditor);
        }
    void super$setCellEditor(javax.swing.table.TableCellEditor p_CellEditor)
        {
        super.setCellEditor(p_CellEditor);
        }
    public void setColumnModel(javax.swing.table.TableColumnModel p_ColumnModel)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_ColumnModel(p_ColumnModel);
        }
    void super$setColumnModel(javax.swing.table.TableColumnModel p_ColumnModel)
        {
        super.setColumnModel(p_ColumnModel);
        }
    public void setCursor(java.awt.Cursor p_Cursor)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Cursor(p_Cursor);
        }
    void super$setCursor(java.awt.Cursor p_Cursor)
        {
        super.setCursor(p_Cursor);
        }
    public void setFont(java.awt.Font p_Font)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Font(p_Font);
        }
    void super$setFont(java.awt.Font p_Font)
        {
        super.setFont(p_Font);
        }
    public void setForeground(java.awt.Color p_Foreground)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Foreground(p_Foreground);
        }
    void super$setForeground(java.awt.Color p_Foreground)
        {
        super.setForeground(p_Foreground);
        }
    public void setGridColor(java.awt.Color p_GridColor)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_GridColor(p_GridColor);
        }
    void super$setGridColor(java.awt.Color p_GridColor)
        {
        super.setGridColor(p_GridColor);
        }
    public void setLayout(java.awt.LayoutManager p_Layout)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Layout(p_Layout);
        }
    void super$setLayout(java.awt.LayoutManager p_Layout)
        {
        super.setLayout(p_Layout);
        }
    public void setLocation(java.awt.Point p_Location)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Location(p_Location);
        }
    void super$setLocation(java.awt.Point p_Location)
        {
        super.setLocation(p_Location);
        }
    public void setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MaximumSize(p_MaximumSize);
        }
    void super$setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        super.setMaximumSize(p_MaximumSize);
        }
    public void setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MinimumSize(p_MinimumSize);
        }
    void super$setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        super.setMinimumSize(p_MinimumSize);
        }
    public void setModel(javax.swing.table.TableModel p_Model)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Model(p_Model);
        }
    void super$setModel(javax.swing.table.TableModel p_Model)
        {
        super.setModel(p_Model);
        }
    public void setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_PreferredSize(p_PreferredSize);
        }
    void super$setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        super.setPreferredSize(p_PreferredSize);
        }
    public void setSelectionBackground(java.awt.Color p_SelectionBackground)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_SelectionBackground(p_SelectionBackground);
        }
    void super$setSelectionBackground(java.awt.Color p_SelectionBackground)
        {
        super.setSelectionBackground(p_SelectionBackground);
        }
    public void setSelectionForeground(java.awt.Color p_SelectionForeground)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_SelectionForeground(p_SelectionForeground);
        }
    void super$setSelectionForeground(java.awt.Color p_SelectionForeground)
        {
        super.setSelectionForeground(p_SelectionForeground);
        }
    public void setSelectionModel(javax.swing.ListSelectionModel p_SelectionModel)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_SelectionModel(p_SelectionModel);
        }
    void super$setSelectionModel(javax.swing.ListSelectionModel p_SelectionModel)
        {
        super.setSelectionModel(p_SelectionModel);
        }
    public void setSize(java.awt.Dimension p_Size)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Size(p_Size);
        }
    void super$setSize(java.awt.Dimension p_Size)
        {
        super.setSize(p_Size);
        }
    public void setTableHeader(javax.swing.table.JTableHeader p_TableHeader)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_TableHeader(p_TableHeader);
        }
    void super$setTableHeader(javax.swing.table.JTableHeader p_TableHeader)
        {
        super.setTableHeader(p_TableHeader);
        }
    public void setAutoResizeMode(int pAutoResizeMode)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setAutoResizeMode(pAutoResizeMode);
        }
    void super$setAutoResizeMode(int pAutoResizeMode)
        {
        super.setAutoResizeMode(pAutoResizeMode);
        }
    public void setAutoscrolls(boolean pAutoscrolls)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setAutoscrolls(pAutoscrolls);
        }
    void super$setAutoscrolls(boolean pAutoscrolls)
        {
        super.setAutoscrolls(pAutoscrolls);
        }
    public void setCellSelectionEnabled(boolean pCellSelectionEnabled)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setCellSelectionEnabled(pCellSelectionEnabled);
        }
    void super$setCellSelectionEnabled(boolean pCellSelectionEnabled)
        {
        super.setCellSelectionEnabled(pCellSelectionEnabled);
        }
    public void setColumnSelectionAllowed(boolean pColumnSelectionAllowed)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setColumnSelectionAllowed(pColumnSelectionAllowed);
        }
    void super$setColumnSelectionAllowed(boolean pColumnSelectionAllowed)
        {
        super.setColumnSelectionAllowed(pColumnSelectionAllowed);
        }
    public void setEnabled(boolean pEnabled)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setEnabled(pEnabled);
        }
    void super$setEnabled(boolean pEnabled)
        {
        super.setEnabled(pEnabled);
        }
    public void setOpaque(boolean pOpaque)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setOpaque(pOpaque);
        }
    void super$setOpaque(boolean pOpaque)
        {
        super.setOpaque(pOpaque);
        }
    public void setRowHeight(int pRowHeight)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setRowHeight(pRowHeight);
        }
    void super$setRowHeight(int pRowHeight)
        {
        super.setRowHeight(pRowHeight);
        }
    public void setRowMargin(int pRowMargin)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setRowMargin(pRowMargin);
        }
    void super$setRowMargin(int pRowMargin)
        {
        super.setRowMargin(pRowMargin);
        }
    public void setRowSelectionAllowed(boolean pRowSelectionAllowed)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setRowSelectionAllowed(pRowSelectionAllowed);
        }
    void super$setRowSelectionAllowed(boolean pRowSelectionAllowed)
        {
        super.setRowSelectionAllowed(pRowSelectionAllowed);
        }
    public void setSelectionMode(int pSelectionMode)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setSelectionMode(pSelectionMode);
        }
    void super$setSelectionMode(int pSelectionMode)
        {
        super.setSelectionMode(pSelectionMode);
        }
    public void setShowGrid(boolean pShowGrid)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setShowGrid(pShowGrid);
        }
    void super$setShowGrid(boolean pShowGrid)
        {
        super.setShowGrid(pShowGrid);
        }
    public void setShowHorizontalLines(boolean pShowHorizontalLines)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setShowHorizontalLines(pShowHorizontalLines);
        }
    void super$setShowHorizontalLines(boolean pShowHorizontalLines)
        {
        super.setShowHorizontalLines(pShowHorizontalLines);
        }
    public void setShowVerticalLines(boolean pShowVerticalLines)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setShowVerticalLines(pShowVerticalLines);
        }
    void super$setShowVerticalLines(boolean pShowVerticalLines)
        {
        super.setShowVerticalLines(pShowVerticalLines);
        }
    public void setToolTipText(String pToolTipText)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setToolTipText(pToolTipText);
        }
    void super$setToolTipText(String pToolTipText)
        {
        super.setToolTipText(pToolTipText);
        }
    public void setValueAt(Object oValue, int iRow, int iCol)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setValueAt(oValue, iRow, iCol);
        }
    void super$setValueAt(Object oValue, int iRow, int iCol)
        {
        super.setValueAt(oValue, iRow, iCol);
        }
    public void setVisible(boolean pVisible)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVisible(pVisible);
        }
    void super$setVisible(boolean pVisible)
        {
        super.setVisible(pVisible);
        }
    public void sizeColumnsToFit(int iColumn)
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.sizeColumnsToFit(iColumn);
        }
    void super$sizeColumnsToFit(int iColumn)
        {
        super.sizeColumnsToFit(iColumn);
        }
    public void updateUI()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.updateUI();
        }
    void super$updateUI()
        {
        super.updateUI();
        }
    public void validate()
        {
        JTable peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.validate();
        }
    void super$validate()
        {
        super.validate();
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
