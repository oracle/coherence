/* Class
*     _package.component.gUI.control.container.window.Frame
*/

package _package.component.gUI.control.container.window;

import _package.component.gUI.Rectangle;
import _package.component.util.Config;

/*
* Integrates
*     java.awt.Frame
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class Frame
        extends    _package.component.gUI.control.container.Window
    {
    // Fields declarations
    
    /**
    * Property _IconImage
    *
    */
    private transient java.awt.Image __m__IconImage;
    
    /**
    * Property IconImage
    *
    */
    private _package.component.gUI.Image __m_IconImage;
    
    /**
    * Property Resizable
    *
    */
    private transient boolean __m_Resizable;
    
    /**
    * Property Title
    *
    */
    private transient String __m_Title;
    
    // fields used by the integration model:
    private sink_Frame __sink;
    private java.awt.Frame __feed;
    
    // Default constructor
    public Frame()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Frame(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_Frame.__tloPeer.setObject(this);
            new jb_Frame(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Frame();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/window/Frame".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.Frame integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_Frame) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (java.awt.Frame) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public java.awt.Image get_IconImage()
        {
        return __sink.getIconImage();
        }
    public String getTitle()
        {
        return __sink.getTitle();
        }
    public boolean isResizable()
        {
        return __sink.isResizable();
        }
    public void set_IconImage(java.awt.Image _image)
        {
        __sink.setIconImage(_image);
        }
    public void setResizable(boolean pResizable)
        {
        __sink.setResizable(pResizable);
        }
    public void setTitle(String pTitle)
        {
        __sink.setTitle(pTitle);
        }
    //-- java.awt.Frame integration
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        // import Component.GUI.Rectangle;
        // import Component.Util.Config;
        
        if (isResizable())
            {
            Config cfgBounds = config.getConfig(sPrefix + ".Bounds");
        
            if (!cfgBounds.isEmpty())
                {
                Rectangle rect = new Rectangle();
                rect.applyConfig(cfgBounds, "");
                setBounds(rect);
        
                // doLayout(); // we should not have to do this...
                }
            }
        
        super.applyConfig(config, sPrefix);
        }
    
    // Accessor for the property "IconImage"
    public _package.component.gUI.Image getIconImage()
        {
        return __m_IconImage;
        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        getBounds().saveConfig(config, sPrefix + ".Bounds");
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "IconImage"
    public void setIconImage(_package.component.gUI.Image pIconImage)
        {
        if (pIconImage != null)
            {
            java.awt.Image _image = pIconImage.get_Image();
            set_IconImage(_image != null ? _image : null);
            }
        __m_IconImage = (pIconImage);
        }
    }
