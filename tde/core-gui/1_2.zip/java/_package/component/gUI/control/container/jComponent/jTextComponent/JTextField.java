/* Class
*     _package.component.gUI.control.container.jComponent.jTextComponent.JTextField
*/

package _package.component.gUI.control.container.jComponent.jTextComponent;

import com.tangosol.run.component.EventDeathException;

/*
* Integrates
*     javax.swing.JTextField
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JTextField
        extends    _package.component.gUI.control.container.jComponent.JTextComponent
        implements java.awt.event.ActionListener
    {
    // Fields declarations
    
    /**
    * Property _ActionCommand
    *
    * Functional integrated property that sets the command string used for
    * action events.
    * 
    * @see setActionCommand
    */
    
    /**
    * Property ActionCommand
    *
    * Specifies the command string used for action event. If this property is
    * set to null (default) then the action event for this TextField is not
    * going to be generated.
    */
    private String __m_ActionCommand;
    
    /**
    * Property HorizontalAlignment
    *
    * Specifies the horizontal alignment of the text.
    * 
    * The valid values are (see javax.swing.SwingConstants):
    * CENTER = 0
    * LEFT = 2
    * RIGHT = 4
    */
    private transient int __m_HorizontalAlignment;
    
    /**
    * Property ScrollOffset
    *
    */
    private transient int __m_ScrollOffset;
    
    // fields used by the integration model:
    private sink_JTextField __sink;
    private javax.swing.JTextField __feed;
    
    // Default constructor
    public JTextField()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JTextField(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setTBounds("0,0,100,20");
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new _package.component.gUI.control.container.jComponent.JTextComponent$KeyRedo("KeyRedo", this, true), "KeyRedo");
        _addChild(new _package.component.gUI.control.container.jComponent.JTextComponent$KeyUndo("KeyUndo", this, true), "KeyUndo");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JTextField.__tloPeer.setObject(this);
            new jb_JTextField(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        super.__initEvents();
        
        addActionListener(this);
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new JTextField();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jTextComponent/JTextField".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ ActionListener dispatcher
    private com.tangosol.util.Listeners __ActionListeners;
    private void addActionListener$Router(java.awt.event.ActionListener l)
        {
        __sink.addActionListener(l);
        }
    private void addActionListener$Default(java.awt.event.ActionListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __ActionListeners;
        if (_listeners == null)
            {
            __ActionListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addActionListener$Router(this);
            }
        _listeners.add(l);
        }
    public void addActionListener(java.awt.event.ActionListener l)
        {
        if (l == this && getActionCommand() == null)
            {
            // we could also remove the JTextField's keystroke bindings ...
            // (see description for bug #4174465)    
            return;
            }
        
        addActionListener$Default(l);

        }
    private void removeActionListener$Router(java.awt.event.ActionListener l)
        {
        __sink.removeActionListener(l);
        }
    public void removeActionListener(java.awt.event.ActionListener l)
        {
        com.tangosol.util.Listeners _listeners = __ActionListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeActionListener$Router(this);
            }
        }
    private void actionPerformed$Dispatch(java.awt.event.ActionEvent e)
        {
        java.util.EventListener[] targets = __ActionListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.ActionListener target = (java.awt.event.ActionListener) targets[i];
            if (target != this)
                {
                target.actionPerformed(e);
                }
            }
        }
    /**
    * The quote from javax.swing.JTextFied:
    * 
    * *** begin quote
    * 
    * For compatibility with java.awt.TextField, the VK_ENTER key fires the
    * ActionEvent to the registered ActionListeners.  However, awt didn't have
    * default buttons like swing does.  If a text field has focus and the
    * VK_ENTER key is pressed, it will fire the fields ActionEvent rather than
    * activate the default button.  To disable the compatibility with awt for
    * text fields, the following code fragment will remove the binding of
    * VK_ENTER from the default keymap used by all JTextFields if that is
    * desired.
    *  <pre><code>
    * static
    *     {
    *     JTextField f = new JTextField();
    *     KeyStroke enter = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);
    *     Keymap map = f.getKeymap();
    *     map.removeKeyStrokeBinding(enter);
    *     }
    * </code></pre>
    * 
    * *** end quote
    */
    public void actionPerformed(java.awt.event.ActionEvent e)
        {
        // import com.tangosol.run.component.EventDeathException;
        try
            {
            if (is_Constructed())
                {
                onAction(e.getActionCommand(), e.getModifiers(), e.paramString());
                }
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        if (getActionCommand() != null)
            {
            actionPerformed$Dispatch(e);
            }
        }
    //-- ActionListener dispatcher
    
    //++ javax.swing.JTextField integration
    // Access optimization
    /**
    * Setter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JTextField) pSink;
        super.set_Sink(pSink);
        }
    /**
    * Setter for property _Feed.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JTextField) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    /**
    * Getter for property HorizontalAlignment.<p>
    * Specifies the horizontal alignment of the text.
    * 
    * The valid values are (see javax.swing.SwingConstants):
    * CENTER = 0
    * LEFT = 2
    * RIGHT = 4
    */
    public int getHorizontalAlignment()
        {
        return __sink.getHorizontalAlignment();
        }
    /**
    * Getter for property ScrollOffset.<p>
    */
    public int getScrollOffset()
        {
        return __sink.getScrollOffset();
        }
    /**
    * Setter for property _ActionCommand.<p>
    * Functional integrated property that sets the command string used for
    * action events.
    * 
    * @see setActionCommand
    */
    public void set_ActionCommand(String p_ActionCommand)
        {
        __sink.setActionCommand(p_ActionCommand);
        }
    /**
    * Setter for property HorizontalAlignment.<p>
    * Specifies the horizontal alignment of the text.
    * 
    * The valid values are (see javax.swing.SwingConstants):
    * CENTER = 0
    * LEFT = 2
    * RIGHT = 4
    */
    public void setHorizontalAlignment(int pHorizontalAlignment)
        {
        __sink.setHorizontalAlignment(pHorizontalAlignment);
        }
    /**
    * Setter for property ScrollOffset.<p>
    */
    public void setScrollOffset(int pScrollOffset)
        {
        __sink.setScrollOffset(pScrollOffset);
        }
    //-- javax.swing.JTextField integration
    
    // Accessor for the property "ActionCommand"
    /**
    * Getter for property ActionCommand.<p>
    * Specifies the command string used for action event. If this property is
    * set to null (default) then the action event for this TextField is not
    * going to be generated.
    */
    public String getActionCommand()
        {
        return __m_ActionCommand;
        }
    
    /**
    * This event is only generated when any of the registered keystrokes (i.e.
    * VK_ENTER) is pressed.
    * 
    * @see #actionPerformed
    */
    public void onAction(String action, int modifiers, String param)
        {
        }
    
    // Accessor for the property "ActionCommand"
    /**
    * Setter for property ActionCommand.<p>
    * Specifies the command string used for action event. If this property is
    * set to null (default) then the action event for this TextField is not
    * going to be generated.
    */
    public void setActionCommand(String pActionCommand)
        {
        String sCmdOld = getActionCommand();
        String sCmdNew = pActionCommand;
        
        __m_ActionCommand = (pActionCommand);
        set_ActionCommand(pActionCommand);
        
        if (is_Constructed())
            {
            if (sCmdOld == null && sCmdNew != null)
                {
                addActionListener(this);
                }
            else if (sCmdOld != null && sCmdNew == null)
                {
                removeActionListener(this);        
                }
            }

        }
    }
