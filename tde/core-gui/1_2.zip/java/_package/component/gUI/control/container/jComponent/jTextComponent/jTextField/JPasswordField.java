/* Class
*     _package.component.gUI.control.container.jComponent.jTextComponent.jTextField.JPasswordField
*/

package _package.component.gUI.control.container.jComponent.jTextComponent.jTextField;

/*
* Integrates
*     javax.swing.JPasswordField
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JPasswordField
        extends    _package.component.gUI.control.container.jComponent.jTextComponent.JTextField
    {
    // Fields declarations
    
    /**
    * Property BOTTOM
    *
    */
    public static final int BOTTOM = 3; // javax.swing.JPasswordField.BOTTOM;
    
    /**
    * Property CENTER
    *
    */
    public static final int CENTER = 0; // javax.swing.JPasswordField.CENTER;
    
    /**
    * Property EchoChar
    *
    * Specifies the character to be used for echoing.  The default is '*'.
    */
    private char __m_EchoChar;
    
    /**
    * Property Password
    *
    * Returns the text contained in this TextComponent.  For stronger
    * security, it is recommended that the returned character array be cleared
    * after use by setting each character to zero.
    * 
    * @see #getPassword
    */
    
    // fields used by the integration model:
    private sink_JPasswordField __sink;
    private javax.swing.JPasswordField __feed;
    
    // Default constructor
    public JPasswordField()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JPasswordField(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setTBounds("0,0,100,20");
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new _package.component.gUI.control.container.jComponent.JTextComponent$KeyRedo("KeyRedo", this, true), "KeyRedo");
        _addChild(new _package.component.gUI.control.container.jComponent.JTextComponent$KeyUndo("KeyUndo", this, true), "KeyUndo");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JPasswordField.__tloPeer.setObject(this);
            new jb_JPasswordField(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JPasswordField();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jTextComponent/jTextField/JPasswordField".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JPasswordField integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JPasswordField) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JPasswordField) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public char getEchoChar()
        {
        return __sink.getEchoChar();
        }
    /**
    * Returns the text contained in this TextComponent.  If the underlying
    * document is null, will give a NullPointerException.  For stronger
    * security, it is recommended that the returned character array be cleared
    * after use by setting each character to zero.
    */
    public char[] getPassword()
        {
        return __sink.getPassword();
        }
    public void setEchoChar(char pEchoChar)
        {
        __sink.setEchoChar(pEchoChar);
        }
    //-- javax.swing.JPasswordField integration
    }
