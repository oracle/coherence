/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.WizardPane
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.gUI.control.container.Window;
import _package.component.gUI.control.container.jComponent.JInternalFrame;
import _package.component.gUI.control.container.jComponent.JLabel;
import _package.component.gUI.control.container.jComponent.jPanel.WizardPage;
import com.tangosol.run.component.EventDeathException;
import com.tangosol.util.ClassFilter;
import com.tangosol.util.FilterEnumerator;
import java.util.Enumeration;

/**
* This component represents the Wizard's main pane. All the pages should
* inherit from JPanel.WizardPage component and are to be inserted into the
* $Workspace panel. All pages have unique names (within the $Workspace) and
* ordered according to values of their _Order property (this allows pages to be
* inserted later at derivation levels).
*/
public class WizardPane
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property ActivePage
    *
    * Specifies the currently active (visible) page.  Setting this property
    * changes the currently active page.
    */
    private transient WizardPage __m_ActivePage;
    
    /**
    * Property ActivePageName
    *
    * Helper property that specifies the name of the currently active (visible)
    * page.  Setting this property changes the currently active page.
    */
    private transient String __m_ActivePageName;
    
    /**
    * Property NextAllowed
    *
    * (Functional) Specifies whether the "Next" (or "Finish", if this page is
    * the last one) button should be enabled for this page. Setting this
    * property enables or disables an appropriate button.
    * 
    * @see WizardPage#NextAllowed property
    */
    
    /**
    * Property OnFirstPage
    *
    * (Calculated) Helper property that returns true iff the last page is
    * currently active.
    */
    
    /**
    * Property OnLastPage
    *
    * (Calculated) Helper property that returns true iff the first page is
    * currently active.
    */
    
    /**
    * Property PageCount
    *
    * Specifies the number of pages this Wizard has.
    */
    private transient int __m_PageCount;
    
    /**
    * Property Pages
    *
    * Helper indexed property that specifies the array of all WizardPages for
    * this wizard.
    */
    private transient WizardPage[] __m_Pages;
    
    /**
    * Property WizardTitle
    *
    * Since the Title property is used to change the title of the wizard when
    * an active page changes, we need this property to preserve the original
    * title.
    * 
    * @see #setActivePage
    */
    private String __m_WizardTitle;
    
    // Default constructor
    public WizardPane()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public WizardPane(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(false);
            setTBounds("0,0,475,325");
            setTConstraints("Center");
            setTIcon("WizardIcon");
            setTLayout("BorderLayout");
            setWizardTitle("Wizard");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new WizardPane$Navigation("Navigation", this, true), "Navigation");
        _addChild(new WizardPane$Ornament("Ornament", this, true), "Ornament");
        _addChild(new WizardPane$Workspace("Workspace", this, true), "Workspace");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new WizardPane();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/WizardPane".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.WizardPage;
        

        }
    
    // Declared at the super level
    /**
    * Adds the visual feed of the specified child component to the visual feed
    * of this container. Having this functionality separate from _addChild
    * allows it to be overwritten by containers that know better.
    * 
    * @see #_addChild
    */
    public void addControl(_package.component.gUI.Control child)
        {
        super.addControl(child);
        
        if (child instanceof WizardPage)
            {
            setPageCount(getPageCount() + 1);
            setPages(null);
            }
        }
    
    /**
    * Closes the wizard.
    * 
    * TODO: move this up to the JPanel
    */
    public void closeWizard()
        {
        // import Component.GUI.Control.Container.JComponent.JInternalFrame;
        // import Component.GUI.Control.Container.Window;
        // import com.tangosol.run.component.EventDeathException;
        
        WizardPage[] aPage  = getPages();
        int          cPages = aPage.length;
        
        for (int i = 0; i < cPages; i++)
            {
            try
                {
                aPage[i].onWizardClosing();
                }
            catch (EventDeathException e)
                {
                return;
                }
            }
        
        endDialog(getDialogResult());
        }
    
    /**
    * Programatically perform a "click" on the "Back" button. This does the
    * same thing as if the user had pressed and released the button.
    */
    public void doBack()
        {
        (($BTN_Back) _findName("Navigation$BTN_Back")).doClick();
        }
    
    /**
    * Programatically perform a "click" on the "Next" button. This does the
    * same thing as if the user had pressed and released the button.
    */
    public void doNext()
        {
        (($BTN_Next) _findName("Navigation$BTN_Next")).doClick();
        }
    
    /**
    * Returns an enumeration of WizardPages ordered according to their
    * appearance in the wizard (calculated based on their _Order property
    * values)
    */
    public java.util.Enumeration enumPages()
        {
        // import com.tangosol.util.ClassFilter;
        // import com.tangosol.util.FilterEnumerator;
        
        $Workspace Workspace = ($Workspace) _findName("Workspace");
        return new FilterEnumerator(
            Workspace._enumChildrenInOrder(), new ClassFilter(WizardPage.class));

        }
    
    /**
    * Find a page by name.
    * 
    * @param simple name of a page to look for.
    * 
    * @return the page with the specified name or null if not found
    */
    public WizardPage findPage(String sPageName)
        {
        return (WizardPage) _findName("Workspace$" + sPageName);
        }
    
    // Accessor for the property "ActivePage"
    public WizardPage getActivePage()
        {
        return __m_ActivePage;
        }
    
    // Accessor for the property "ActivePageName"
    public String getActivePageName()
        {
        return getActivePage().get_Name();
        }
    
    // Accessor for the property "PageCount"
    public int getPageCount()
        {
        return __m_PageCount;
        }
    
    // Accessor for the property "Pages"
    /**
    * Returns lazily instantiated array of the WizardPages existing for this
    * wizard.
    */
    public WizardPage[] getPages()
        {
        // import java.util.Enumeration;
        
        WizardPage[] aPages = __m_Pages;
        if (aPages == null)
            {
            aPages = new WizardPage[getPageCount()];
        
            Enumeration enum = enumPages();
            for (int i = 0; enum.hasMoreElements(); i++)
                {
                aPages[i] = (WizardPage) enum.nextElement();
                }
            setPages(aPages);
            }
        return aPages;
        }
    
    // Accessor for the property "WizardTitle"
    public String getWizardTitle()
        {
        return __m_WizardTitle;
        }
    
    /**
    * Performs Wizard initialization. WiardPane subcomponents are expected to
    * perform some custom initialization here <b>before</b> calling
    * super.initWizard() which in turn activates the first wizard page.
    */
    protected void initWizard()
        {
        // import java.util.Enumeration;
        
        Enumeration enum = enumPages();
        
        if (!enum.hasMoreElements())
            {
            // empty wizard
            return;
            }
        
        WizardPage pageFirst = (WizardPage) enum.nextElement();
            
        int cPages;
        
        // count and hide the rest of the pages
        for (cPages = 1; enum.hasMoreElements(); cPages++)
            {
            WizardPage page = (WizardPage) enum.nextElement();
            if (page.isVisible())
                {
                page.setVisible(false);
                }
            }
        
        setPageCount(cPages);
        
        if (getWizardTitle() == null)
            {
            // preserve the designed title
            setWizardTitle(getTitle());
            }
        
        // activate the first page
        setActivePage(pageFirst);

        }
    
    // Accessor for the property "OnFirstPage"
    public boolean isOnFirstPage()
        {
        int cPages = getPageCount();
        
        return cPages > 0 && getActivePage() == getPages()[0];
        }
    
    // Accessor for the property "OnLastPage"
    public boolean isOnLastPage()
        {
        int cPages = getPageCount();
        
        return cPages > 0 && getActivePage() == getPages()[cPages - 1];
        }
    
    // Declared at the super level
    /**
    * The "component has been added to a containing component"
    * method-notification.
    * 
    * Note: this notification is not sent during the component's state
    * initialization (deserialization)
    * 
    * @see _addChild
    */
    public void onAdd()
        {
        super.onAdd();
        
        initWizard();
        }
    
    /**
    * Method-notification sent when the "Cancel" button has been pressed.
    * Default implentation closes the Wizard.
    */
    public void onCancel()
        {
        closeWizard();
        }
    
    /**
    * Method-notification sent when the "Finish" button on the last page has
    * been pressed.
    * Default implentation closes the Wizard.
    */
    public void onFinish()
        {
        closeWizard();
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        super.onInit();
        
        // if there is no parent yet, defer initialization until "onAdd()"
        if (get_Parent() != null)
            {
            initWizard();
            }
        }
    
    // Declared at the super level
    /**
    * @see #_removeChild
    */
    public void removeControl(_package.component.gUI.Control child)
        {
        super.removeControl(child);
        
        if (child instanceof WizardPage)
            {
            setPageCount(getPageCount() - 1);
            setPages(null);
            }
        }
    
    // Accessor for the property "ActivePage"
    public void setActivePage(WizardPage pActivePage)
        {
        // import Component.GUI.Control.Container.JComponent.JLabel;
        // import com.tangosol.run.component.EventDeathException;
        // import java.util.Enumeration;
        
        WizardPage pageOld = getActivePage();
        WizardPage pageNew = pActivePage;
        
        if (pageNew == pageOld)
            {
            return;
            }
        
        if (pageNew == null || pageNew.get_Parent() != _findName("Workspace"))
            {
            throw new IllegalArgumentException("Invalid page " + pageNew);
            }
        
        boolean fForward = pageOld == null ? true : pageOld.get_Order() <= pageNew.get_Order();
        int     iDir     = fForward ? WizardPage.DIR_FORWARD : WizardPage.DIR_BACKWARD;
        
        try
            {
            if (pageOld != null)
                {
                pageOld.onPageLeaving(iDir);
                pageOld.setVisible(false);
                }
            }
        catch (EventDeathException e)
            {
            // TODO: should we do the following?
            // throw new PropertyVetoException();
            return;
            }
        
        __m_ActivePage = (pageNew);
        
        pageNew.setVisible(true);
        
        // TODO: Attempt to workaround Bug 4259549, remove when fixed
        JLabel LBL_Desc = (JLabel) pageNew._findName("LBL_Desc");
        LBL_Desc.paintImmediately();
        
        try
            {
            pageNew.onPageEntering(iDir);
            }
        catch (EventDeathException e)
            {
            // it could have skipped somewhere else
            return;
            }
        
        $BTN_Back BTN_Back = ($BTN_Back) _findName("Navigation$BTN_Back");
        $BTN_Next BTN_Next = ($BTN_Next) _findName("Navigation$BTN_Next");
        
        BTN_Back.setEnabled(!isOnFirstPage());
        BTN_Next.setEnabled(pageNew.isNextAllowed());
        BTN_Next.setText(isOnLastPage() ? BTN_Next.getTEXT_FINISH() : BTN_Next.getTEXT_NEXT());
        
        String sTitle = pageNew.getTitle();
        setTitle(sTitle != null && sTitle.length() > 0 ?
            sTitle : getWizardTitle());
        }
    
    // Accessor for the property "ActivePageName"
    public void setActivePageName(String pActivePageName)
        {
        WizardPage page = findPage(pActivePageName);
        if (page != null)
            {
            setActivePage(page);
            }
        }
    
    // Accessor for the property "NextAllowed"
    public void setNextAllowed(boolean pNextAllowed)
        {
        $BTN_Next BTN_Next = ($BTN_Next) _findName("Navigation$BTN_Next");
        BTN_Next.setEnabled(pNextAllowed);
        }
    
    // Accessor for the property "PageCount"
    private void setPageCount(int pPageCount)
        {
        __m_PageCount = pPageCount;
        }
    
    // Accessor for the property "Pages"
    protected void setPages(WizardPage[] pPages)
        {
        __m_Pages = pPages;
        }
    
    // Accessor for the property "WizardTitle"
    public void setWizardTitle(String pWizardTitle)
        {
        __m_WizardTitle = pWizardTitle;
        }
    
    /**
    * Skips the specified number of pages and activates the new page.
    * 
    * @param iSkip  number of pages to skip. Value of 1 means skipping to the
    * next page, -1 -- skipping to the previous one.
    */
    public void skipPage(int iSkip)
        {
        WizardPage[] aPage  = getPages();
        int          cPages = aPage.length;
        
        for (int i = 0; i < cPages; i++)
            {
            if (aPage[i] == getActivePage())
                {
                int iPage = i + iSkip;
                if (iPage < 0)
                    {
                    iPage = 0;
                    }
                if (iPage >= cPages)
                    {
                    iPage = cPages - 1;
                    }
        
                setActivePage(aPage[iPage]);
                break;
                }
            }
        }
    }
