/* Class
*     _package.component.gUI.control.container.jComponent.JList
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.Color;
import _package.component.gUI.Dimension;
import _package.component.gUI.Point;
import com.tangosol.run.component.EventDeathException;
import javax.swing.DefaultListModel;
import javax.swing.JComponent;
import javax.swing.JList; // as _JList
import javax.swing.ListCellRenderer;
import javax.swing.ListModel;

/*
* Integrates
*     javax.swing.JList
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JList
        extends    _package.component.gUI.control.container.JComponent
        implements javax.swing.ListCellRenderer,
                   javax.swing.event.ListSelectionListener
    {
    // Fields declarations
    
    /**
    * Property _DefaultRenderer
    *
    */
    private transient javax.swing.ListCellRenderer __m__DefaultRenderer;
    
    /**
    * Property _Model
    *
    */
    private transient javax.swing.ListModel __m__Model;
    
    /**
    * Property _SelectionBackground
    *
    */
    private transient java.awt.Color __m__SelectionBackground;
    
    /**
    * Property _SelectionForeground
    *
    */
    private transient java.awt.Color __m__SelectionForeground;
    
    /**
    * Property Adjusting
    *
    */
    private transient boolean __m_Adjusting;
    
    /**
    * Property CaseSensitive
    *
    */
    private boolean __m_CaseSensitive;
    
    /**
    * Property Collator
    *
    */
    private java.text.Collator __m_Collator;
    
    /**
    * Property FirstVisibleIndex
    *
    */
    
    /**
    * Property FixedCellHeight
    *
    */
    private transient int __m_FixedCellHeight;
    
    /**
    * Property FixedCellWidth
    *
    */
    private transient int __m_FixedCellWidth;
    
    /**
    * Property ITEM_NOT_FOUND
    *
    */
    public static final int ITEM_NOT_FOUND = -1;
    
    /**
    * Property ItemCount
    *
    */
    
    /**
    * Property Items
    *
    */
    private transient Object[] __m_Items;
    
    /**
    * Property LastVisibleIndex
    *
    */
    
    /**
    * Property LeadSelectionIndex
    *
    */
    private transient int __m_LeadSelectionIndex;
    
    /**
    * Property MaxSelectionIndex
    *
    */
    private transient int __m_MaxSelectionIndex;
    
    /**
    * Property MinSelectionIndex
    *
    */
    private transient int __m_MinSelectionIndex;
    
    /**
    * Property PreferredCellSize
    *
    */
    private _package.component.gUI.Dimension __m_PreferredCellSize;
    
    /**
    * Property SelectedIndex
    *
    */
    private transient int __m_SelectedIndex;
    
    /**
    * Property SelectedIndices
    *
    */
    private transient int[] __m_SelectedIndices;
    
    /**
    * Property SelectedValue
    *
    */
    private transient Object __m_SelectedValue;
    
    /**
    * Property SelectedValues
    *
    */
    private transient Object[] __m_SelectedValues;
    
    /**
    * Property SelectionBackground
    *
    */
    private transient _package.component.gUI.Color __m_SelectionBackground;
    
    /**
    * Property SelectionEmpty
    *
    */
    
    /**
    * Property SelectionForeground
    *
    */
    private transient _package.component.gUI.Color __m_SelectionForeground;
    
    /**
    * Property SelectionMode
    *
    */
    private transient int __m_SelectionMode;
    
    /**
    * Property Sorted
    *
    */
    private boolean __m_Sorted;
    
    /**
    * Property Text
    *
    */
    private transient String __m_Text;
    
    /**
    * Property VisibleRowCount
    *
    */
    private int __m_VisibleRowCount;
    
    // fields used by the integration model:
    private sink_JList __sink;
    private javax.swing.JList __feed;
    
    // Default constructor
    public JList()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JList(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setScrollable(true);
            setSelectionMode(1);
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JList.__tloPeer.setObject(this);
            new jb_JList(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        super.__initEvents();
        
        addListSelectionListener(this);
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JList();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JList".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ ListSelectionListener dispatcher
    private com.tangosol.util.Listeners __ListSelectionListeners;
    private void addListSelectionListener$Router(javax.swing.event.ListSelectionListener l)
        {
        __sink.addListSelectionListener(l);
        }
    public void addListSelectionListener(javax.swing.event.ListSelectionListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __ListSelectionListeners;
        if (_listeners == null)
            {
            __ListSelectionListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addListSelectionListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeListSelectionListener$Router(javax.swing.event.ListSelectionListener l)
        {
        __sink.removeListSelectionListener(l);
        }
    public void removeListSelectionListener(javax.swing.event.ListSelectionListener l)
        {
        com.tangosol.util.Listeners _listeners = __ListSelectionListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeListSelectionListener$Router(this);
            }
        }
    private void valueChanged$Dispatch(javax.swing.event.ListSelectionEvent e)
        {
        java.util.EventListener[] targets = __ListSelectionListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.ListSelectionListener target = (javax.swing.event.ListSelectionListener) targets[i];
            if (target != this)
                {
                target.valueChanged(e);
                }
            }
        }
    public void valueChanged(javax.swing.event.ListSelectionEvent e)
        {
        // import com.tangosol.run.component.EventDeathException;
        try
            {
            if (is_Constructed() && !e.getValueIsAdjusting())
                {
                // e.getFirstIndex() and e.getLastIndex()
                // hold the "old" values
                onSelected(getSelectedIndex());
                }
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        valueChanged$Dispatch(e);
        }
    //-- ListSelectionListener dispatcher
    
    //++ javax.swing.JList integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JList) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JList) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public void updateUI()
        {
        _JList _list = (_JList) get_Feed();
        
        _list.setCellRenderer(null);
        
        super.updateUI();
        
        set_DefaultRenderer(_list.getCellRenderer());
        _list.setCellRenderer(this);

        }
    public void addSelectionInterval(int anchor, int lead)
        {
        __sink.addSelectionInterval(anchor, lead);
        }
    public void clearSelection()
        {
        __sink.clearSelection();
        }
    public void ensureIndexIsVisible(int index)
        {
        __sink.ensureIndexIsVisible(index);
        }
    public int getFirstVisibleIndex()
        {
        return __sink.getFirstVisibleIndex();
        }
    public int getFixedCellHeight()
        {
        return __sink.getFixedCellHeight();
        }
    public int getFixedCellWidth()
        {
        return __sink.getFixedCellWidth();
        }
    public int getLastVisibleIndex()
        {
        return __sink.getLastVisibleIndex();
        }
    public int getLeadSelectionIndex()
        {
        return __sink.getLeadSelectionIndex();
        }
    public int getMaxSelectionIndex()
        {
        return __sink.getMaxSelectionIndex();
        }
    public int getMinSelectionIndex()
        {
        return __sink.getMinSelectionIndex();
        }
    private javax.swing.ListModel get_Model$Router()
        {
        return __sink.getModel();
        }
    public javax.swing.ListModel get_Model()
        {
        // import javax.swing.DefaultListModel;
        // import javax.swing.ListModel;
        
        ListModel lm = get_Model$Router();
        
        // default JList constructor creates an empty AbstractListModel !?
        if (lm == null || !(lm instanceof DefaultListModel) && lm.getSize() == 0)
            {
            set_Model(lm = new DefaultListModel());
            }
        return lm;
        }
    public int getSelectedIndex()
        {
        return __sink.getSelectedIndex();
        }
    public int[] getSelectedIndices()
        {
        return __sink.getSelectedIndices();
        }
    public Object getSelectedValue()
        {
        return __sink.getSelectedValue();
        }
    public Object[] getSelectedValues()
        {
        return __sink.getSelectedValues();
        }
    public java.awt.Color get_SelectionBackground()
        {
        return __sink.getSelectionBackground();
        }
    public java.awt.Color get_SelectionForeground()
        {
        return __sink.getSelectionForeground();
        }
    public int getSelectionMode()
        {
        return __sink.getSelectionMode();
        }
    public boolean isAdjusting()
        {
        return __sink.getValueIsAdjusting();
        }
    public int getVisibleRowCount()
        {
        return __sink.getVisibleRowCount();
        }
    public java.awt.Point _indexToLocation(int index)
        {
        return __sink.indexToLocation(index);
        }
    public boolean isItemSelectedAt(int index)
        {
        return __sink.isSelectedIndex(index);
        }
    public boolean isSelectionEmpty()
        {
        return __sink.isSelectionEmpty();
        }
    public int _locationToIndex(java.awt.Point point)
        {
        return __sink.locationToIndex(point);
        }
    public void setFixedCellHeight(int pFixedCellHeight)
        {
        __sink.setFixedCellHeight(pFixedCellHeight);
        }
    public void setFixedCellWidth(int pFixedCellWidth)
        {
        __sink.setFixedCellWidth(pFixedCellWidth);
        }
    public void set_Model(javax.swing.ListModel pModel)
        {
        __sink.setModel(pModel);
        }
    public void setSelectedIndex(int pSelectedIndex)
        {
        __sink.setSelectedIndex(pSelectedIndex);
        }
    public void setSelectedIndices(int[] pSelectedIndicies)
        {
        __sink.setSelectedIndices(pSelectedIndicies);
        }
    public void setSelectedValue(Object value, boolean shouldScroll)
        {
        __sink.setSelectedValue(value, shouldScroll);
        }
    public void set_SelectionBackground(java.awt.Color p_SelectionBackground)
        {
        __sink.setSelectionBackground(p_SelectionBackground);
        }
    public void set_SelectionForeground(java.awt.Color p_SelectionForeground)
        {
        __sink.setSelectionForeground(p_SelectionForeground);
        }
    public void setSelectionInterval(int anchor, int lead)
        {
        __sink.setSelectionInterval(anchor, lead);
        }
    public void setSelectionMode(int pSelectionMode)
        {
        __sink.setSelectionMode(pSelectionMode);
        }
    public void setAdjusting(boolean pAdjusting)
        {
        __sink.setValueIsAdjusting(pAdjusting);
        }
    public void setVisibleRowCount(int pVisibleRowCount)
        {
        __sink.setVisibleRowCount(pVisibleRowCount);
        }
    //-- javax.swing.JList integration
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Color;
        // import Component.GUI.Dimension;
        // import javax.swing.JList as _JList;
        
        

        }
    
    /**
    * @see JComboBox#addItem
    */
    public void addItem(Object item)
        {
        // import javax.swing.DefaultListModel;
        // import javax.swing.ListModel;
        
        ListModel lm = get_Model();
        if (!(lm instanceof DefaultListModel))
            {
            throw new UnsupportedOperationException();
            }
        
        if (isSorted())
            {
            int      count      = getItemCount();
            boolean  ignoreCase = !isCaseSensitive();
            String   sItem      = item.toString();
        
            java.text.Collator collator   = getCollator();
            java.text.CollationKey ckItem = null;
        
            if (collator != null)
                {
                ckItem = collator.getCollationKey(sItem);
                }
            else
                {
                if (ignoreCase)
                    {
                    sItem = sItem.toUpperCase();
                    }
                }
        
            for (int i = 0; i < count; i++)
                {
                boolean bInsert;
                String  s = getItemAt(i).toString();
        
                if (collator != null)
                    {
                    bInsert = collator.getCollationKey(s).compareTo(ckItem) > 0;
                    }
                else
                    {
                    if (ignoreCase)
                        {
                        s = s.toUpperCase();
                        }
                    bInsert = s.compareTo(sItem) > 0;
                    }
        
                if (bInsert)
                    {
                    insertItemAt(item, i);
                    return;
                    }
                }
            }
        ((DefaultListModel) lm).addElement(item);
        }
    
    public int findItem(Object item)
        {
        int count = getItemCount();
        
        for (int i = 0; i < count; i++)
            {
            if (getItemAt(i).equals(item))
                {
                return i;
                }
            }
        
        return ITEM_NOT_FOUND;

        }
    
    /**
    * Looks for an item that starts with the specified pattern.
    * 
    * Note: this method is identical to JComboBox#findItem(pattern, exactMatch,
    * startAt)
    * 
    * @param pattern  pattern to look for
    * @param exactMatch if true, compares using "equals()"; otherwise uses
    * "startsWith()"
    * @param startAt  specifies the position in the combobox to start at
    */
    public int findItem(String pattern, boolean exactMatch, int startAt)
        {
        int     count      = getItemCount();
        boolean ignoreCase = !isCaseSensitive();
        
        if (startAt < 0 || startAt > count)
            throw new IllegalArgumentException("Invalid starting index");
        
        if (ignoreCase)
            {
            pattern = pattern.toUpperCase();
            }
        
        while (true) // maximum two passes
            {
            for (int i = startAt; i < count; i++)
                {
                String sItem = getItemAt(i).toString();
        
                if (ignoreCase)
                    {
                    sItem = sItem.toUpperCase();
                    }
        
                if (exactMatch)
                    {
                    if (sItem.equals(pattern))
                        {
                        return i;
                        }
                    }
                else
                    {
                    if (sItem.startsWith(pattern))
                        {
                        return i;
                        }
                    }
                }
        
            if (startAt == 0)
                break;
        
            // perform the second pass
            count   = startAt;
            startAt = 0;
            }
        return ITEM_NOT_FOUND;

        }
    
    // Accessor for the property "_DefaultRenderer"
    public javax.swing.ListCellRenderer get_DefaultRenderer()
        {
        return __m__DefaultRenderer;
        }
    
    // Accessor for the property "Collator"
    public java.text.Collator getCollator()
        {
        return __m_Collator;
        }
    
    public Object getItemAt(int index)
        {
        return get_Model().getElementAt(index);
        }
    
    // Accessor for the property "ItemCount"
    public int getItemCount()
        {
        return get_Model().getSize();
        }
    
    // Accessor for the property "Items"
    public Object[] getItems()
        {
        // import javax.swing.DefaultListModel;
        // import javax.swing.ListModel;
        
        ListModel lm = get_Model();
        if (lm instanceof DefaultListModel)
            {
            return ((DefaultListModel) lm).toArray();
            }
        else
            {
            int cnt = lm.getSize();
            Object[] items = new Object[cnt];
            for (int i = 0; i < cnt; i++)
                {
                items[i] = lm.getElementAt(i);
                }
            return items;
            }
        }
    
    // Accessor for the property "Items"
    public Object getItems(int pIndex)
        {
        return getItemAt(pIndex);
        }
    
    // From interface: javax.swing.ListCellRenderer
    public java.awt.Component getListCellRendererComponent(javax.swing.JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
        {
        // import javax.swing.ListCellRenderer;
        
        _assert(list == get_Feed());
        
        ListCellRenderer renderer = get_DefaultRenderer();
        _assert(renderer != this);
        _assert(getItemAt(index) == value);
        
        java.awt.Component compRenderer =
            renderer.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        
        onCellRendering(compRenderer, value, index, cellHasFocus);
        
        return compRenderer;
        }
    
    // Accessor for the property "PreferredCellSize"
    public _package.component.gUI.Dimension getPreferredCellSize()
        {
        return __m_PreferredCellSize;
        }
    
    // Accessor for the property "SelectionBackground"
    public _package.component.gUI.Color getSelectionBackground()
        {
        Color color = new Color();
        color.set_Color(get_SelectionBackground());
        return color;

        }
    
    // Accessor for the property "SelectionForeground"
    public _package.component.gUI.Color getSelectionForeground()
        {
        Color color = new Color();
        color.set_Color(get_SelectionForeground());
        return color;

        }
    
    // Accessor for the property "Text"
    public String getText()
        {
        return getSelectedValue().toString();
        }
    
    /**
    * Returns the origin of the specified item in JList coordinates, null if
    * index isn't valid.
    * 
    * @param index the index of the JList cell.
    * 
    * @return the origin of the index'th cell.
    */
    public _package.component.gUI.Point indexToLocation(int index)
        {
        // import Component.GUI.Point;
        
        java.awt.Point _point = _indexToLocation(index);
        
        return _point != null ? Point.instantiate(_point) : null;
        }
    
    public void insertItemAt(Object item, int index)
        {
        // import javax.swing.DefaultListModel;
        // import javax.swing.ListModel;
        
        ListModel lm = get_Model();
        if (!(lm instanceof DefaultListModel))
            {
            throw new UnsupportedOperationException();
            }
        
        ((DefaultListModel) lm).insertElementAt(item, index);
        }
    
    // Accessor for the property "CaseSensitive"
    public boolean isCaseSensitive()
        {
        return __m_CaseSensitive;
        }
    
    // Accessor for the property "Sorted"
    public boolean isSorted()
        {
        return __m_Sorted;
        }
    
    /**
    * Convert a point in JList coordinates to the index of the cell at that
    * location.  Returns -1 if there's no cell the specified location.
    * 
    * @param location the JList relative coordinates of the cell
    * 
    * @return the index of the cell at the given location, or -1
    */
    public int locationToIndex(_package.component.gUI.Point point)
        {
        return _locationToIndex(point.get_Point());
        }
    
    public void onCellRendering(java.awt.Component compRenderer, Object value, int index, boolean hasFocus)
        {
        // import javax.swing.JComponent;
        
        if (compRenderer instanceof JComponent)
            {
            Dimension size = getPreferredCellSize();
            if (size != null)
                {
                ((JComponent) compRenderer).setPreferredSize(size.get_Dimension());
                }
            }

        }
    
    public void onSelected(int index)
        {
        }
    
    public void removeAllItems()
        {
        // import javax.swing.DefaultListModel;
        // import javax.swing.ListModel;
        
        ListModel lm = get_Model();
        if (lm instanceof DefaultListModel)
            {
            ((DefaultListModel) lm).removeAllElements();
            }
        else
            {
            throw new UnsupportedOperationException();
            }
        }
    
    public void removeItemAt(int index)
        {
        // import javax.swing.DefaultListModel;
        // import javax.swing.ListModel;
        
        ListModel lm = get_Model();
        if (lm instanceof DefaultListModel)
            {
            ((DefaultListModel) lm).removeElementAt(index);
            }
        else
            {
            throw new UnsupportedOperationException();
            }
        }
    
    // Accessor for the property "_DefaultRenderer"
    public void set_DefaultRenderer(javax.swing.ListCellRenderer p_DefaultRenderer)
        {
        __m__DefaultRenderer = p_DefaultRenderer;
        }
    
    // Accessor for the property "CaseSensitive"
    public void setCaseSensitive(boolean pCaseSensitive)
        {
        __m_CaseSensitive = pCaseSensitive;
        }
    
    // Accessor for the property "Collator"
    public void setCollator(java.text.Collator pCollator)
        {
        __m_Collator = pCollator;
        }
    
    public void setItemAt(Object item, int index)
        {
        // import javax.swing.DefaultListModel;
        // import javax.swing.ListModel;
        
        ListModel lm = get_Model();
        if (lm instanceof DefaultListModel)
            {
            ((DefaultListModel) lm).setElementAt(item, index);
            }
        else
            {
            throw new UnsupportedOperationException();
            }
        }
    
    // Accessor for the property "Items"
    public void setItems(Object[] pItems)
        {
        // import javax.swing.DefaultListModel;
        // import javax.swing.ListModel;
        
        ListModel lm = get_Model();
        if (lm instanceof DefaultListModel)
            {
            ((DefaultListModel) lm).removeAllElements();
            }
        else
            {
            set_Model(lm = new DefaultListModel());
            }
        
        if (pItems != null)
            {
            for (int i = 0; i< pItems.length; i++)
                {
                addItem(pItems[i]);
                }
            }
        }
    
    // Accessor for the property "Items"
    public void setItems(int pIndex, Object pItem)
        {
        setItemAt(pItem, pIndex);
        }
    
    // Accessor for the property "LeadSelectionIndex"
    public void setLeadSelectionIndex(int pLeadSelectionIndex)
        {
        __m_LeadSelectionIndex = pLeadSelectionIndex;
        }
    
    // Accessor for the property "MaxSelectionIndex"
    public void setMaxSelectionIndex(int pMaxSelectionIndex)
        {
        __m_MaxSelectionIndex = pMaxSelectionIndex;
        }
    
    // Accessor for the property "MinSelectionIndex"
    public void setMinSelectionIndex(int pMinSelectionIndex)
        {
        __m_MinSelectionIndex = pMinSelectionIndex;
        }
    
    // Accessor for the property "PreferredCellSize"
    public void setPreferredCellSize(_package.component.gUI.Dimension pPreferredCellSize)
        {
        __m_PreferredCellSize = pPreferredCellSize;
        }
    
    // Accessor for the property "SelectedValue"
    public void setSelectedValue(Object pSelectedValue)
        {
        setSelectedValue(pSelectedValue, true);
        }
    
    // Accessor for the property "SelectedValues"
    public void setSelectedValues(Object[] pSelectedValues)
        {
        for (int i = 0; i < pSelectedValues.length; i++)
            {
            setSelectedValue(pSelectedValues[i]);
            }
        }
    
    // Accessor for the property "SelectionBackground"
    public void setSelectionBackground(_package.component.gUI.Color pSelectionBackground)
        {
        set_SelectionBackground(pSelectionBackground.get_Color());
        }
    
    // Accessor for the property "SelectionForeground"
    public void setSelectionForeground(_package.component.gUI.Color pSelectionForeground)
        {
        set_SelectionForeground(pSelectionForeground.get_Color());
        }
    
    // Accessor for the property "Sorted"
    public void setSorted(boolean pSorted)
        {
        if (pSorted == isSorted())
            {
            return;
            }
        
        __m_Sorted = (pSorted);
        
        if (pSorted)
            {
            // force sorting
            setItems(getItems());
            }
        }
    
    // Accessor for the property "Text"
    public void setText(String pText)
        {
        int ix = findItem(pText, true, 0);
                
        if (ix != ITEM_NOT_FOUND)
            {
            setSelectedIndex(ix);
            }

        }
    }
