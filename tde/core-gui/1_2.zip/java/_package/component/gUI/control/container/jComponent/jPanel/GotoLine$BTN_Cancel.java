/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.GotoLine$BTN_Cancel
*/

package _package.component.gUI.control.container.jComponent.jPanel;

public class GotoLine$BTN_Cancel
        extends    _package.component.gUI.control.container.jComponent.abstractButton.jButton.EscapeButton
    {
    // Fields declarations
    
    // Default constructor
    public GotoLine$BTN_Cancel()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public GotoLine$BTN_Cancel(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setTBounds("135,40,85,25");
            setText("Cancel");
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new _package.component.gUI.control.container.jComponent.abstractButton.jButton.EscapeButton$KeyEnter("KeyEnter", this, true), "KeyEnter");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new GotoLine$BTN_Cancel();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/GotoLine$BTN_Cancel".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    }
