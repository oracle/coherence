/* Class
*      jb_JMenuItem
*
* automatically generated "Feed" which
* a) extends an external bean:
*      javax.swing.JMenuItem
* b) delegates to the peer component:
*      Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem
*/

package _package.component.gUI.control.container.jComponent.abstractButton;

public class jb_JMenuItem
        extends    javax.swing.JMenuItem
        implements com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected JMenuItem __peer;
    
    private static JMenuItem __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            JMenuItem peer = (JMenuItem)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // default (JavaBean) constructor
    public jb_JMenuItem()
        {
        this(JMenuItem.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JMenuItem(String Param_1)
        {
        this(Param_1, JMenuItem.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JMenuItem(String Param_1, int Param_2)
        {
        this(Param_1, Param_2, JMenuItem.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JMenuItem(String Param_1, javax.swing.Icon Param_2)
        {
        this(Param_1, Param_2, JMenuItem.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JMenuItem(javax.swing.Action Param_1)
        {
        this(Param_1, JMenuItem.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JMenuItem(javax.swing.Icon Param_1)
        {
        this(Param_1, JMenuItem.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JMenuItem(Class clzPeer)
        {
        this(__createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JMenuItem(String Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JMenuItem(String Param_1, int Param_2, Class clzPeer)
        {
        this(Param_1, Param_2, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JMenuItem(String Param_1, javax.swing.Icon Param_2, Class clzPeer)
        {
        this(Param_1, Param_2, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JMenuItem(javax.swing.Action Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JMenuItem(javax.swing.Icon Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JMenuItem(JMenuItem peer, boolean fInit)
        {
        super();
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JMenuItem(String Param_1, JMenuItem peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JMenuItem(String Param_1, int Param_2, JMenuItem peer, boolean fInit)
        {
        super(Param_1, Param_2);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JMenuItem(String Param_1, javax.swing.Icon Param_2, JMenuItem peer, boolean fInit)
        {
        super(Param_1, Param_2);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JMenuItem(javax.swing.Action Param_1, JMenuItem peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JMenuItem(javax.swing.Icon Param_1, JMenuItem peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private JMenuItem __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (JMenuItem) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_JMenuItem(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    public void add(java.awt.Component comp, Object constraints, int index)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._add(comp, constraints, index);
        }
    void super$add(java.awt.Component comp, Object constraints, int index)
        {
        super.add(comp, constraints, index);
        }
    public void remove(java.awt.Component comp)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._remove(comp);
        }
    void super$remove(java.awt.Component comp)
        {
        super.remove(comp);
        }
    public void addActionListener(java.awt.event.ActionListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addActionListener(l);
        }
    void super$addActionListener(java.awt.event.ActionListener l)
        {
        super.addActionListener(l);
        }
    public void addChangeListener(javax.swing.event.ChangeListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addChangeListener(l);
        }
    void super$addChangeListener(javax.swing.event.ChangeListener l)
        {
        super.addChangeListener(l);
        }
    public void addFocusListener(java.awt.event.FocusListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addFocusListener(l);
        }
    void super$addFocusListener(java.awt.event.FocusListener l)
        {
        super.addFocusListener(l);
        }
    public void addItemListener(java.awt.event.ItemListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addItemListener(l);
        }
    void super$addItemListener(java.awt.event.ItemListener l)
        {
        super.addItemListener(l);
        }
    public void addKeyListener(java.awt.event.KeyListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addKeyListener(l);
        }
    void super$addKeyListener(java.awt.event.KeyListener l)
        {
        super.addKeyListener(l);
        }
    public void addMouseListener(java.awt.event.MouseListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseListener(l);
        }
    void super$addMouseListener(java.awt.event.MouseListener l)
        {
        super.addMouseListener(l);
        }
    public void addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseMotionListener(l);
        }
    void super$addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.addMouseMotionListener(l);
        }
    public void addNotify()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addNotify();
        }
    void super$addNotify()
        {
        super.addNotify();
        }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addPropertyChangeListener(l);
        }
    void super$addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.addPropertyChangeListener(l);
        }
    public void addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addVetoableChangeListener(l);
        }
    void super$addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.addVetoableChangeListener(l);
        }
    public javax.swing.JToolTip createToolTip()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.createToolTip();
        }
    javax.swing.JToolTip super$createToolTip()
        {
        return super.createToolTip();
        }
    public void doClick()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.doClick();
        }
    void super$doClick()
        {
        super.doClick();
        }
    public void doClick(int iPressTime)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.doClick(iPressTime);
        }
    void super$doClick(int iPressTime)
        {
        super.doClick(iPressTime);
        }
    public void doLayout()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.doLayout();
        }
    void super$doLayout()
        {
        super.doLayout();
        }
    public java.awt.Color getBackground()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Background();
        }
    java.awt.Color super$getBackground()
        {
        return super.getBackground();
        }
    public javax.swing.border.Border getBorder()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Border();
        }
    javax.swing.border.Border super$getBorder()
        {
        return super.getBorder();
        }
    public java.awt.Rectangle getBounds()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Bounds();
        }
    java.awt.Rectangle super$getBounds()
        {
        return super.getBounds();
        }
    public java.awt.Cursor getCursor()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Cursor();
        }
    java.awt.Cursor super$getCursor()
        {
        return super.getCursor();
        }
    public javax.swing.Icon getDisabledIcon()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_DisabledIcon();
        }
    javax.swing.Icon super$getDisabledIcon()
        {
        return super.getDisabledIcon();
        }
    public javax.swing.Icon getDisabledSelectedIcon()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_DisabledSelectedIcon();
        }
    javax.swing.Icon super$getDisabledSelectedIcon()
        {
        return super.getDisabledSelectedIcon();
        }
    public java.awt.Font getFont()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Font();
        }
    java.awt.Font super$getFont()
        {
        return super.getFont();
        }
    public java.awt.Color getForeground()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Foreground();
        }
    java.awt.Color super$getForeground()
        {
        return super.getForeground();
        }
    public javax.swing.Icon getIcon()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Icon();
        }
    javax.swing.Icon super$getIcon()
        {
        return super.getIcon();
        }
    public java.awt.Insets getInsets()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Insets();
        }
    java.awt.Insets super$getInsets()
        {
        return super.getInsets();
        }
    public java.awt.LayoutManager getLayout()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Layout();
        }
    java.awt.LayoutManager super$getLayout()
        {
        return super.getLayout();
        }
    public java.awt.Point getLocation()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Location();
        }
    java.awt.Point super$getLocation()
        {
        return super.getLocation();
        }
    public java.awt.Point getLocationOnScreen()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_LocationOnScreen();
        }
    java.awt.Point super$getLocationOnScreen()
        {
        return super.getLocationOnScreen();
        }
    public java.awt.Insets getMargin()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Margin();
        }
    java.awt.Insets super$getMargin()
        {
        return super.getMargin();
        }
    public java.awt.Dimension getMaximumSize()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MaximumSize();
        }
    java.awt.Dimension super$getMaximumSize()
        {
        return super.getMaximumSize();
        }
    public java.awt.Dimension getMinimumSize()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MinimumSize();
        }
    java.awt.Dimension super$getMinimumSize()
        {
        return super.getMinimumSize();
        }
    public int getMnemonic()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Mnemonic();
        }
    int super$getMnemonic()
        {
        return super.getMnemonic();
        }
    public java.awt.Dimension getPreferredSize()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_PreferredSize();
        }
    java.awt.Dimension super$getPreferredSize()
        {
        return super.getPreferredSize();
        }
    public javax.swing.Icon getPressedIcon()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_PressedIcon();
        }
    javax.swing.Icon super$getPressedIcon()
        {
        return super.getPressedIcon();
        }
    public javax.swing.Icon getRolloverIcon()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_RolloverIcon();
        }
    javax.swing.Icon super$getRolloverIcon()
        {
        return super.getRolloverIcon();
        }
    public javax.swing.Icon getRolloverSelectedIcon()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_RolloverSelectedIcon();
        }
    javax.swing.Icon super$getRolloverSelectedIcon()
        {
        return super.getRolloverSelectedIcon();
        }
    public javax.swing.Icon getSelectedIcon()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_SelectedIcon();
        }
    javax.swing.Icon super$getSelectedIcon()
        {
        return super.getSelectedIcon();
        }
    public java.awt.Dimension getSize()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Size();
        }
    java.awt.Dimension super$getSize()
        {
        return super.getSize();
        }
    public String getActionCommand()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getActionCommand();
        }
    String super$getActionCommand()
        {
        return super.getActionCommand();
        }
    public int getHorizontalAlignment()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getHorizontalAlignment();
        }
    int super$getHorizontalAlignment()
        {
        return super.getHorizontalAlignment();
        }
    public int getHorizontalTextPosition()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getHorizontalTextPosition();
        }
    int super$getHorizontalTextPosition()
        {
        return super.getHorizontalTextPosition();
        }
    public String getText()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getText();
        }
    String super$getText()
        {
        return super.getText();
        }
    public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent e)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipLocation(e);
        }
    java.awt.Point super$getToolTipLocation(java.awt.event.MouseEvent e)
        {
        return super.getToolTipLocation(e);
        }
    public String getToolTipText()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText();
        }
    String super$getToolTipText()
        {
        return super.getToolTipText();
        }
    public String getToolTipText(java.awt.event.MouseEvent e)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText(e);
        }
    String super$getToolTipText(java.awt.event.MouseEvent e)
        {
        return super.getToolTipText(e);
        }
    public int getVerticalAlignment()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getVerticalAlignment();
        }
    int super$getVerticalAlignment()
        {
        return super.getVerticalAlignment();
        }
    public int getVerticalTextPosition()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getVerticalTextPosition();
        }
    int super$getVerticalTextPosition()
        {
        return super.getVerticalTextPosition();
        }
    public boolean isArmed()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isArmed();
        }
    boolean super$isArmed()
        {
        return super.isArmed();
        }
    public boolean getAutoscrolls()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isAutoscrolls();
        }
    boolean super$getAutoscrolls()
        {
        return super.getAutoscrolls();
        }
    public boolean isEnabled()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isEnabled();
        }
    boolean super$isEnabled()
        {
        return super.isEnabled();
        }
    public boolean isFocusPainted()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isFocusPainted();
        }
    boolean super$isFocusPainted()
        {
        return super.isFocusPainted();
        }
    public boolean isFocusTraversable()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isFocusTraversable();
        }
    boolean super$isFocusTraversable()
        {
        return super.isFocusTraversable();
        }
    public boolean isOpaque()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isOpaque();
        }
    boolean super$isOpaque()
        {
        return super.isOpaque();
        }
    public boolean isRolloverEnabled()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isRolloverEnabled();
        }
    boolean super$isRolloverEnabled()
        {
        return super.isRolloverEnabled();
        }
    public boolean isSelected()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isSelected();
        }
    boolean super$isSelected()
        {
        return super.isSelected();
        }
    public boolean isShowing()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isShowing();
        }
    boolean super$isShowing()
        {
        return super.isShowing();
        }
    public boolean isVisible()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isVisible();
        }
    boolean super$isVisible()
        {
        return super.isVisible();
        }
    public void paint(java.awt.Graphics g)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paint(g);
        }
    void super$paint(java.awt.Graphics g)
        {
        super.paint(g);
        }
    protected void paintBorder(java.awt.Graphics g)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintBorder(g);
        }
    void super$paintBorder(java.awt.Graphics g)
        {
        super.paintBorder(g);
        }
    protected void paintChildren(java.awt.Graphics g)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintChildren(g);
        }
    void super$paintChildren(java.awt.Graphics g)
        {
        super.paintChildren(g);
        }
    protected void paintComponent(java.awt.Graphics g)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintComponent(g);
        }
    void super$paintComponent(java.awt.Graphics g)
        {
        super.paintComponent(g);
        }
    public void removeActionListener(java.awt.event.ActionListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeActionListener(l);
        }
    void super$removeActionListener(java.awt.event.ActionListener l)
        {
        super.removeActionListener(l);
        }
    public void removeChangeListener(javax.swing.event.ChangeListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeChangeListener(l);
        }
    void super$removeChangeListener(javax.swing.event.ChangeListener l)
        {
        super.removeChangeListener(l);
        }
    public void removeFocusListener(java.awt.event.FocusListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeFocusListener(l);
        }
    void super$removeFocusListener(java.awt.event.FocusListener l)
        {
        super.removeFocusListener(l);
        }
    public void removeItemListener(java.awt.event.ItemListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeItemListener(l);
        }
    void super$removeItemListener(java.awt.event.ItemListener l)
        {
        super.removeItemListener(l);
        }
    public void removeKeyListener(java.awt.event.KeyListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeKeyListener(l);
        }
    void super$removeKeyListener(java.awt.event.KeyListener l)
        {
        super.removeKeyListener(l);
        }
    public void removeMouseListener(java.awt.event.MouseListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseListener(l);
        }
    void super$removeMouseListener(java.awt.event.MouseListener l)
        {
        super.removeMouseListener(l);
        }
    public void removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseMotionListener(l);
        }
    void super$removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.removeMouseMotionListener(l);
        }
    public void removeNotify()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeNotify();
        }
    void super$removeNotify()
        {
        super.removeNotify();
        }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removePropertyChangeListener(l);
        }
    void super$removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.removePropertyChangeListener(l);
        }
    public void removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeVetoableChangeListener(l);
        }
    void super$removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.removeVetoableChangeListener(l);
        }
    public void requestFocus()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.requestFocus();
        }
    void super$requestFocus()
        {
        super.requestFocus();
        }
    public void setBackground(java.awt.Color p_Background)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Background(p_Background);
        }
    void super$setBackground(java.awt.Color p_Background)
        {
        super.setBackground(p_Background);
        }
    public void setBorder(javax.swing.border.Border p_Border)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Border(p_Border);
        }
    void super$setBorder(javax.swing.border.Border p_Border)
        {
        super.setBorder(p_Border);
        }
    public void setBounds(java.awt.Rectangle p_Bounds)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Bounds(p_Bounds);
        }
    void super$setBounds(java.awt.Rectangle p_Bounds)
        {
        super.setBounds(p_Bounds);
        }
    public void setCursor(java.awt.Cursor p_Cursor)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Cursor(p_Cursor);
        }
    void super$setCursor(java.awt.Cursor p_Cursor)
        {
        super.setCursor(p_Cursor);
        }
    public void setDisabledIcon(javax.swing.Icon p_DisabledIcon)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_DisabledIcon(p_DisabledIcon);
        }
    void super$setDisabledIcon(javax.swing.Icon p_DisabledIcon)
        {
        super.setDisabledIcon(p_DisabledIcon);
        }
    public void setDisabledSelectedIcon(javax.swing.Icon p_DisabledSelectedIcon)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_DisabledSelectedIcon(p_DisabledSelectedIcon);
        }
    void super$setDisabledSelectedIcon(javax.swing.Icon p_DisabledSelectedIcon)
        {
        super.setDisabledSelectedIcon(p_DisabledSelectedIcon);
        }
    public void setFont(java.awt.Font p_Font)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Font(p_Font);
        }
    void super$setFont(java.awt.Font p_Font)
        {
        super.setFont(p_Font);
        }
    public void setForeground(java.awt.Color p_Foreground)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Foreground(p_Foreground);
        }
    void super$setForeground(java.awt.Color p_Foreground)
        {
        super.setForeground(p_Foreground);
        }
    public void setIcon(javax.swing.Icon p_Icon)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Icon(p_Icon);
        }
    void super$setIcon(javax.swing.Icon p_Icon)
        {
        super.setIcon(p_Icon);
        }
    public void setLayout(java.awt.LayoutManager p_Layout)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Layout(p_Layout);
        }
    void super$setLayout(java.awt.LayoutManager p_Layout)
        {
        super.setLayout(p_Layout);
        }
    public void setLocation(java.awt.Point p_Location)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Location(p_Location);
        }
    void super$setLocation(java.awt.Point p_Location)
        {
        super.setLocation(p_Location);
        }
    public void setMargin(java.awt.Insets p_Margin)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Margin(p_Margin);
        }
    void super$setMargin(java.awt.Insets p_Margin)
        {
        super.setMargin(p_Margin);
        }
    public void setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MaximumSize(p_MaximumSize);
        }
    void super$setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        super.setMaximumSize(p_MaximumSize);
        }
    public void setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MinimumSize(p_MinimumSize);
        }
    void super$setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        super.setMinimumSize(p_MinimumSize);
        }
    public void setMnemonic(int p_Mnemonic)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Mnemonic(p_Mnemonic);
        }
    void super$setMnemonic(int p_Mnemonic)
        {
        super.setMnemonic(p_Mnemonic);
        }
    public void setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_PreferredSize(p_PreferredSize);
        }
    void super$setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        super.setPreferredSize(p_PreferredSize);
        }
    public void setPressedIcon(javax.swing.Icon p_PressedIcon)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_PressedIcon(p_PressedIcon);
        }
    void super$setPressedIcon(javax.swing.Icon p_PressedIcon)
        {
        super.setPressedIcon(p_PressedIcon);
        }
    public void setRolloverIcon(javax.swing.Icon p_RolloverIcon)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_RolloverIcon(p_RolloverIcon);
        }
    void super$setRolloverIcon(javax.swing.Icon p_RolloverIcon)
        {
        super.setRolloverIcon(p_RolloverIcon);
        }
    public void setRolloverSelectedIcon(javax.swing.Icon p_RolloverSelectedIcon)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_RolloverSelectedIcon(p_RolloverSelectedIcon);
        }
    void super$setRolloverSelectedIcon(javax.swing.Icon p_RolloverSelectedIcon)
        {
        super.setRolloverSelectedIcon(p_RolloverSelectedIcon);
        }
    public void setSelectedIcon(javax.swing.Icon p_SelectedIcon)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_SelectedIcon(p_SelectedIcon);
        }
    void super$setSelectedIcon(javax.swing.Icon p_SelectedIcon)
        {
        super.setSelectedIcon(p_SelectedIcon);
        }
    public void setSize(java.awt.Dimension p_Size)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Size(p_Size);
        }
    void super$setSize(java.awt.Dimension p_Size)
        {
        super.setSize(p_Size);
        }
    public void setActionCommand(String pActionCommand)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setActionCommand(pActionCommand);
        }
    void super$setActionCommand(String pActionCommand)
        {
        super.setActionCommand(pActionCommand);
        }
    public void setArmed(boolean pArmed)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setArmed(pArmed);
        }
    void super$setArmed(boolean pArmed)
        {
        super.setArmed(pArmed);
        }
    public void setAutoscrolls(boolean pAutoscrolls)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setAutoscrolls(pAutoscrolls);
        }
    void super$setAutoscrolls(boolean pAutoscrolls)
        {
        super.setAutoscrolls(pAutoscrolls);
        }
    public void setEnabled(boolean pEnabled)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setEnabled(pEnabled);
        }
    void super$setEnabled(boolean pEnabled)
        {
        super.setEnabled(pEnabled);
        }
    public void setFocusPainted(boolean pFocusPainted)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setFocusPainted(pFocusPainted);
        }
    void super$setFocusPainted(boolean pFocusPainted)
        {
        super.setFocusPainted(pFocusPainted);
        }
    public void setHorizontalAlignment(int pHorizontalAlignment)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setHorizontalAlignment(pHorizontalAlignment);
        }
    void super$setHorizontalAlignment(int pHorizontalAlignment)
        {
        super.setHorizontalAlignment(pHorizontalAlignment);
        }
    public void setHorizontalTextPosition(int pHorizontalTextPosition)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setHorizontalTextPosition(pHorizontalTextPosition);
        }
    void super$setHorizontalTextPosition(int pHorizontalTextPosition)
        {
        super.setHorizontalTextPosition(pHorizontalTextPosition);
        }
    public void setMnemonic(char pMnemonic)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setMnemonic(pMnemonic);
        }
    void super$setMnemonic(char pMnemonic)
        {
        super.setMnemonic(pMnemonic);
        }
    public void setOpaque(boolean pOpaque)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setOpaque(pOpaque);
        }
    void super$setOpaque(boolean pOpaque)
        {
        super.setOpaque(pOpaque);
        }
    public void setRolloverEnabled(boolean pRolloverEnabled)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setRolloverEnabled(pRolloverEnabled);
        }
    void super$setRolloverEnabled(boolean pRolloverEnabled)
        {
        super.setRolloverEnabled(pRolloverEnabled);
        }
    public void setSelected(boolean pSelected)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setSelected(pSelected);
        }
    void super$setSelected(boolean pSelected)
        {
        super.setSelected(pSelected);
        }
    public void setText(String pText)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setText(pText);
        }
    void super$setText(String pText)
        {
        super.setText(pText);
        }
    public void setToolTipText(String pToolTipText)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setToolTipText(pToolTipText);
        }
    void super$setToolTipText(String pToolTipText)
        {
        super.setToolTipText(pToolTipText);
        }
    public void setVerticalAlignment(int pVerticalAlignment)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVerticalAlignment(pVerticalAlignment);
        }
    void super$setVerticalAlignment(int pVerticalAlignment)
        {
        super.setVerticalAlignment(pVerticalAlignment);
        }
    public void setVerticalTextPosition(int pVerticalTextPosition)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVerticalTextPosition(pVerticalTextPosition);
        }
    void super$setVerticalTextPosition(int pVerticalTextPosition)
        {
        super.setVerticalTextPosition(pVerticalTextPosition);
        }
    public void setVisible(boolean pVisible)
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVisible(pVisible);
        }
    void super$setVisible(boolean pVisible)
        {
        super.setVisible(pVisible);
        }
    public void updateUI()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.updateUI();
        }
    void super$updateUI()
        {
        super.updateUI();
        }
    public void validate()
        {
        JMenuItem peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.validate();
        }
    void super$validate()
        {
        super.validate();
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
