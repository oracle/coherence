/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.GotoLine
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.gUI.control.container.JComponent;
import _package.component.gUI.control.container.jComponent.jTextComponent.JTextArea;

public class GotoLine
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property Host
    *
    * Specifies a "host" component for this FindText [dialog box] panel. 
    * @see #onInit
    */
    private transient _package.component.gUI.control.container.JComponent __m_Host;
    
    /**
    * Property Line
    *
    * (Calculated) Line number specified by the user
    */
    
    // Default constructor
    public GotoLine()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public GotoLine(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(false);
            setTBounds("0,0,225,80");
            setTConstraints("Center");
            setTitle("Goto Line");
            setTLayout(null);
            setVisible(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new GotoLine$BTN_Cancel("BTN_Cancel", this, true), "BTN_Cancel");
        _addChild(new GotoLine$BTN_Goto("BTN_Goto", this, true), "BTN_Goto");
        _addChild(new GotoLine$KeyGoto("KeyGoto", this, true), "KeyGoto");
        _addChild(new GotoLine$LBL_Goto("LBL_Goto", this, true), "LBL_Goto");
        _addChild(new GotoLine$TXT_Line("TXT_Line", this, true), "TXT_Line");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new GotoLine();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/GotoLine".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent;

        }
    
    // Declared at the super level
    public void addNotify()
        {
        super.addNotify();
        
        (($TXT_Line) _findName("TXT_Line")).requestFocus();
        }
    
    /**
    * Brings up the "FindText" dialog box and performs a "find" operation on
    * the TextHost.
    * 
    * @param sPattern  (optional) the text to look for; if null the attempt
    * will be made to retrieve it from the host
    */
    public void doGoto()
        {
        Component  parent = get_Parent();
        String     sName  = get_Name();
        JComponent host   = getHost();
        
        $BTN_Goto BTN_Goto = ($BTN_Goto) _findName("BTN_Goto");
        BTN_Goto.setEnabled(getLine() >= 0);
        
        if (parent != null)
            {
            parent._removeChild(this);
            }
        
        setVisible(true);
        
        Object oAction = host.dialogBox(this, null);
        
        setVisible(false);
        
        if (parent != null)
            {
            get_Parent()._removeChild(this); // get_Parent() != parent
            parent._addChild(this, sName);
            }
        
        if (host.isEnabled())
            {
            host.requestFocus();
            }
        
        if (oAction != null)
            {
            performGoto(oAction);
            }
        }
    
    // Declared at the super level
    /**
    * This method is called by  Component.Control.Container#addControl() as a
    * last chance to intervene during the construction/integration cycle.
    * A Control would override this if more than one AWT components should be
    * created for one Control or if the component should not be added to the
    * container (see Component...Window or Component...TabbedPanel).
    * This method can also be used to make sure that the parent is of the
    * allowed type (i.e. TabbedPanel is only allowed to be added into the
    * JTabbedPane).
    *  
    * @param  fAdd is true <b>only</b> when this is the frist call (from
    * addControl()) and an override is supposed to tie all the pieces together;
    * false in all other situations
    * 
    * @return AWT component that is added to a container [integratee].
    * 
    * @see Component.Control.Container.Window
    * @see Component.GUI.Control.Container.JComponent
    * @see
    * Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem.JMenu
    * @see Component.GUI.Control.Container.JComponent.JPanel.ButtonGroupPanel
    */
    public java.awt.Component getAWTContainee(boolean fAdd)
        {
        return isVisible() ? super.getAWTContainee(fAdd) : null;
        }
    
    // Accessor for the property "Host"
    /**
    * Getter for property Host.<p>
    * Specifies a "host" component for this FindText [dialog box] panel. 
    * @see #onInit
    */
    public _package.component.gUI.control.container.JComponent getHost()
        {
        return __m_Host;
        }
    
    // Accessor for the property "Line"
    /**
    * Getter for property Line.<p>
    * (Calculated) Line number specified by the user
    */
    public int getLine()
        {
        $TXT_Line TXT_Line = ($TXT_Line) _findName("TXT_Line");
        try
            {
            return Integer.parseInt(TXT_Line.getText());
            }
        catch (NumberFormatException e)
            {
            return -1;
            }
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        _assert(!isVisible(), "GotoLine must be initially invisible");
        
        super.onInit();
        
        setHost((JComponent) get_Parent());
        
        // see setHost for binding -- should be soft coded...
        }
    
    /**
    * Perform the goto based on the current settings. This method could be
    * overriten if the host is not one of the component types that the GotoLine
    * is aware of.
    * 
    * @param oAction  if the search is initiated by the dialog box, this
    * carries the value returned by the dialogBox() call; otherwise is null.
    */
    protected void performGoto(Object oAction)
        {
        // import Component.GUI.Control.Container.JComponent.JTextComponent.JTextArea;
        
        JComponent host = getHost();
        if (host instanceof JTextArea)
            {
            JTextArea text = (JTextArea) host;
        
            int cLines = text.getLineCount();
            int nLine  = getLine();
        
            if (nLine >= 0)
                {
                text.selectLine(Math.min(nLine - 1, cLines));
                }
            else
                {
                _beep();
                }
            }

        }
    
    // Accessor for the property "Host"
    /**
    * Setter for property Host.<p>
    * Specifies a "host" component for this FindText [dialog box] panel. 
    * @see #onInit
    */
    public void setHost(_package.component.gUI.control.container.JComponent pHost)
        {
        JComponent hostOld = getHost();
        JComponent hostNew = pHost;
        
        if (hostNew == hostOld)
            {
            return;
            }
        
        if (hostOld != null)
            {
            (($KeyGoto) _findName("KeyGoto")).unbind(hostOld);
            }
        
        __m_Host = (hostNew);
        
        if (hostNew != null)
            {
            (($KeyGoto) _findName("KeyGoto")).bind(hostNew);
            }
        }
    }
