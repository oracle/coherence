/* Class
*     _package.component.gUI.control.container.jComponent.jInternalFrame.InternalDialog
*/

package _package.component.gUI.control.container.jComponent.jInternalFrame;

import _package.component.gUI.Control;
import _package.component.gUI.Dimension;
import _package.component.gUI.Point;
import _package.component.gUI.control.container.jComponent.JDesktopPane;
import java.awt.AWTEvent;
import java.awt.Component; // as _Control
import java.awt.EventQueue;
import javax.swing.JDesktopPane; // as _JDesktopPane
import javax.swing.JInternalFrame; // as _JInternalFrame
import javax.swing.JLayeredPane;
import javax.swing.SwingUtilities;

public class InternalDialog
        extends    _package.component.gUI.control.container.jComponent.JInternalFrame
    {
    // Fields declarations
    
    /**
    * Property Modal
    *
    * Specifies whether this dialog should come up as a modal dialog (disabling
    * all other internal frames)
    */
    private boolean __m_Modal;
    
    /**
    * Property Owner
    *
    * Specifies the owner frame of this dialog.
    */
    private transient _package.component.gUI.control.container.jComponent.JInternalFrame __m_Owner;
    
    // Default constructor
    public InternalDialog()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public InternalDialog(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAllowClosing(true);
            setClosable(true);
            setFocusable(true);
            setIconifiable(false);
            setMaximizable(false);
            setResizable(false);
            setVisible(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new InternalDialog();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jInternalFrame/InternalDialog".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void dispose()
        {
        // import Component.GUI.Control.Container.JComponent.JDesktopPane;
        
        ((JDesktopPane) getOwner().get_Parent()).
            setEnabled(true); // re-enable all internal frames
        
        setVisible(false);
        
        getOwner().setSelected(true);
        
        super.dispose();
        }
    
    // Accessor for the property "Owner"
    public _package.component.gUI.control.container.jComponent.JInternalFrame getOwner()
        {
        return __m_Owner;
        }
    
    // Accessor for the property "Modal"
    public boolean isModal()
        {
        return __m_Modal;
        }
    
    // Declared at the super level
    /**
    * As of JDK 1.2, the only way to dynamically stop "closing" is to intercept
    * "setClosed()" (by not calling super.setClosed(true)) or throw a
    * PropertyVetoException from VetoableChange event (property
    * JInternalFrame.IS_CLOSED_PROPERTY value Bolean.TRUE)
    * 
    * Setting the "Closeable" property doesn't help much, because it prevents
    * the InternalFrameClosing event from being sent.
    * 
    * To overcoome the problem we introduced a new property "AllowClosing" that
    * controls the way "setClosed" behaves. If AllowClosing is not set, the
    * frame is not closed automatically, but instead, the InternalFrameClosing
    * event is invoked that could in turn set the property and call
    * setClosed(true) itself.
    * 
    * Note: the super (integrated class) declares an exception, but we shield
    * it for the ease of use (no one cares anyway -- see
    * javax.swing.plaf.basic.BasicInternalFrameUI)
    */
    public void setClosed(boolean pClosed)
        {
        if (pClosed)
            {
            getHostedPanel().endDialog(null);
            }
        
        super.setClosed(pClosed);
        }
    
    public void setLocationRelativeTo(_package.component.gUI.control.container.jComponent.JInternalFrame ownerFrame)
        {
        // import Component.GUI.Control.Container.JComponent.JDesktopPane;
        // import Component.GUI.Dimension;
        // import Component.GUI.Point;
        
        Point     loc  = getLocation();
        Dimension size = getSize();
        
        loc.add(ownerFrame.getLocation());
        
        // make sure it's visible on the JDesktop
        
        Dimension sizeDesktop = ((JDesktopPane) ownerFrame.get_Parent()).getSize();
        
        int iHangoutX = loc.getX() + size.getWidth() - sizeDesktop.getWidth();
        if (iHangoutX > 0)
            {
            loc.setX(loc.getX() - iHangoutX);
            }
        int iHangoutY = loc.getY() + size.getHeight() - sizeDesktop.getHeight();
        if (iHangoutY > 0)
            {
            loc.setY(loc.getY() - iHangoutY);
            }
        
        setLocation(loc);
        }
    
    // Accessor for the property "Modal"
    public void setModal(boolean pModal)
        {
        __m_Modal = pModal;
        }
    
    // Accessor for the property "Owner"
    public void setOwner(_package.component.gUI.control.container.jComponent.JInternalFrame pOwner)
        {
        __m_Owner = (pOwner);
        
        if (pOwner != null)
            {
            // in order for the "setLocationRelativeTo()" to work,
            // the "Bounds" property has to be already set
            setLocationRelativeTo(pOwner);
            }
        }
    
    // Declared at the super level
    /**
    * Makes the InternalDialog visible. If the dialog and/or its owner are not
    * yet displayable, both are made displayable. If the dialog is already
    * visible, this will bring the dialog to the front.
    * If the InternalDialog is modal, this call will block until the dialog is
    * hidden by calling <code>setClosed(false)</code> or <code>dispose</code>. 
    * 
    * The code has been copied from javax.swing.JInternalFrame#startModal()
    * 
    * @see javax.swing.JInternalFrame#startModal
    * @see java.awt.Dialog#setVisible
    */
    public void setVisible(boolean pVisible)
        {
        // import Component.GUI.Control;
        // import Component.GUI.Control.Container.JComponent.JDesktopPane;
        // import java.awt.AWTEvent;
        // import java.awt.Component as _Control;
        // import java.awt.EventQueue;
        // import javax.swing.SwingUtilities;
        // import javax.swing.JDesktopPane   as _JDesktopPane;
        // import javax.swing.JInternalFrame as _JInternalFrame;
        // import javax.swing.JLayeredPane;
        
        if (!is_Constructed())
            {
            return;
            }
        
        if (!pVisible)
            {
            super.setVisible(false);
            synchronized (this)
                {
                notify();
                }
            return;
            }
        
        JDesktopPane desktop = (JDesktopPane) getOwner().get_Parent();
        if (desktop.isVisible() && !desktop.isShowing())
            {
            Control parent = (Control) desktop.get_Parent();
            while (parent != null)
                {
                if (!parent.isVisible())
                    {
                    parent.setVisible(true);
                    }
                parent = (Control) parent.get_Parent();
                }
            }
        
        _JDesktopPane   _desktop = (_JDesktopPane) desktop.get_Feed();
        _JInternalFrame _frame   = (_JInternalFrame) get_Feed();
        
        super.setVisible(true);
        
        _desktop.add(_frame, JLayeredPane.MODAL_LAYER);
        //_desktop.validate(); // do we need this?
        
        setSelected(true);
        
        try
            {
            if (SwingUtilities.isEventDispatchThread())
                {
                EventQueue queue = _frame.getToolkit().getSystemEventQueue();
                while (isVisible())
                    {
                    AWTEvent event = queue.getNextEvent();
                    Object   src   = event.getSource();
        
                    if (event instanceof java.awt.ActiveEvent)
                        {
                        ((java.awt.ActiveEvent) event).dispatch();
                        }
                    else if (src instanceof java.awt.Component)
                        {
                        ((java.awt.Component) src).dispatchEvent(event);
                        }
                    else if (src instanceof java.awt.MenuComponent)
                        {
                        ((java.awt.MenuComponent) src).dispatchEvent(event);
                        }
                    else
                        {
                        _trace("Unable to dispatch event: " + event + " @ " + src, 1);
                        }
                    }
                }
            else
                {
                while (isVisible())
                    {
                    synchronized (this)
                        {
                        wait(); 
                        }
                    }
                }
            }
        catch (InterruptedException e) {}
        }
    }
