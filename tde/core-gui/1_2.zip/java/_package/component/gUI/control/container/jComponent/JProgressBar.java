/* Class
*     _package.component.gUI.control.container.jComponent.JProgressBar
*/

package _package.component.gUI.control.container.jComponent;

import com.tangosol.run.component.EventDeathException;

/*
* Integrates
*     javax.swing.JProgressBar
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JProgressBar
        extends    _package.component.gUI.control.container.JComponent
        implements javax.swing.event.ChangeListener
    {
    // Fields declarations
    
    /**
    * Property BorderPainted
    *
    * Specifies whether to display the border around the progress bar. The
    * default is true.                                                    
    */
    private transient boolean __m_BorderPainted;
    
    /**
    * Property Maximum
    *
    * Specifies the maximum value for the progress bar. The default value is
    * 100.
    */
    private transient int __m_Maximum;
    
    /**
    * Property Minimum
    *
    * Specifies the minimum value for the progress bar. The default value is 0.
    */
    private transient int __m_Minimum;
    
    /**
    * Property Orientation
    *
    * Specifies the orientation to display the progress bar. Valid values are:
    * HORIZONTAL = 0 (Default)
    * VERTICAL=1
    */
    private transient int __m_Orientation;
    
    /**
    * Property PercentComplete
    *
    * (Calculated) Specifies the percentage/percent complete for the progress
    * bar. Note that, as a double, this number is between 0.00 and 1.00.
    */
    
    /**
    * Property String
    *
    * Specifies an optional String that can be displayed on the progress bar.
    * Setting this to a non-null value does not imply that the String will be
    * displayed.
    * 
    * @see #StringPainted property
    */
    private transient String __m_String;
    
    /**
    * Property StringPainted
    *
    * Specifies whether to textually display a String on the progress bar. The
    * default is false. Setting this to true will cause a textual display of
    * the progress to de rendered on the progress bar. If the ProgressString is
    * null, the percentage done to be displayed on the progress bar. If the
    * ProgressString is non-null, it is rendered on the progress bar.
    */
    private transient boolean __m_StringPainted;
    
    /**
    * Property Value
    *
    * Specifies the current value for the progress bar.
    */
    private transient int __m_Value;
    
    // fields used by the integration model:
    private sink_JProgressBar __sink;
    private javax.swing.JProgressBar __feed;
    
    // Default constructor
    public JProgressBar()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JProgressBar(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JProgressBar.__tloPeer.setObject(this);
            new jb_JProgressBar(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        super.__initEvents();
        
        addChangeListener(this);
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JProgressBar();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JProgressBar".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ ChangeListener dispatcher
    private com.tangosol.util.Listeners __ChangeListeners;
    private void addChangeListener$Router(javax.swing.event.ChangeListener l)
        {
        __sink.addChangeListener(l);
        }
    public void addChangeListener(javax.swing.event.ChangeListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __ChangeListeners;
        if (_listeners == null)
            {
            __ChangeListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addChangeListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeChangeListener$Router(javax.swing.event.ChangeListener l)
        {
        __sink.removeChangeListener(l);
        }
    public void removeChangeListener(javax.swing.event.ChangeListener l)
        {
        com.tangosol.util.Listeners _listeners = __ChangeListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeChangeListener$Router(this);
            }
        }
    private void stateChanged$Dispatch(javax.swing.event.ChangeEvent e)
        {
        java.util.EventListener[] targets = __ChangeListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.ChangeListener target = (javax.swing.event.ChangeListener) targets[i];
            if (target != this)
                {
                target.stateChanged(e);
                }
            }
        }
    public void stateChanged(javax.swing.event.ChangeEvent e)
        {
        // import com.tangosol.run.component.EventDeathException;
        
        try
            {
            onValueChanged();
            }
        catch (EventDeathException ex)
            {
            return;
            }
            
        stateChanged$Dispatch(e);
        }
    //-- ChangeListener dispatcher
    
    //++ javax.swing.JProgressBar integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JProgressBar) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JProgressBar) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public int getMaximum()
        {
        return __sink.getMaximum();
        }
    public int getMinimum()
        {
        return __sink.getMinimum();
        }
    public int getOrientation()
        {
        return __sink.getOrientation();
        }
    public double getPercentComplete()
        {
        return __sink.getPercentComplete();
        }
    public String getString()
        {
        return __sink.getString();
        }
    public int getValue()
        {
        return __sink.getValue();
        }
    public boolean isBorderPainted()
        {
        return __sink.isBorderPainted();
        }
    public boolean isStringPainted()
        {
        return __sink.isStringPainted();
        }
    public void setBorderPainted(boolean pBorderPainted)
        {
        __sink.setBorderPainted(pBorderPainted);
        }
    public void setMaximum(int pMaximum)
        {
        __sink.setMaximum(pMaximum);
        }
    public void setMinimum(int pMinimum)
        {
        __sink.setMinimum(pMinimum);
        }
    public void setOrientation(int pOrientation)
        {
        __sink.setOrientation(pOrientation);
        }
    public void setString(String pString)
        {
        __sink.setString(pString);
        }
    public void setStringPainted(boolean pStringPainted)
        {
        __sink.setStringPainted(pStringPainted);
        }
    public void setValue(int pValue)
        {
        __sink.setValue(pValue);
        }
    //-- javax.swing.JProgressBar integration
    
    /**
    * Increases the value of the progress bar by one point.
    */
    public void increase()
        {
        increase(1);
        }
    
    /**
    * Increases the value of the progress bar by the specified number of points.
    */
    public void increase(int iPoints)
        {
        setValue(getValue() + iPoints);
        }
    
    /**
    * Method-notification sent when the value of this progress bar changes.
    */
    public void onValueChanged()
        {
        }
    
    /**
    * Resets the value of the progress bar to the minimum value.
    */
    public void reset()
        {
        setValue(getMinimum());
        }
    }
