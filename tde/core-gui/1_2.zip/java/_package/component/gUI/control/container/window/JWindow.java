/* Class
*     _package.component.gUI.control.container.window.JWindow
*/

package _package.component.gUI.control.container.window;

import javax.swing.JWindow; // as _JWindow

/*
* Integrates
*     javax.swing.JWindow
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JWindow
        extends    _package.component.gUI.control.container.Window
    {
    // Fields declarations
    
    // fields used by the integration model:
    private sink_JWindow __sink;
    private javax.swing.JWindow __feed;
    
    // Default constructor
    public JWindow()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JWindow(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setTBounds("0,0,300,200");
            setTLayout("BorderLayout");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JWindow.__tloPeer.setObject(this);
            new jb_JWindow(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JWindow();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/window/JWindow".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JWindow integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JWindow) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JWindow) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public void _add(java.awt.Component comp, Object constraints, int index)
        {
        ((_JWindow) get_Feed()).getContentPane().add(comp, constraints, index);
        }
    public java.awt.LayoutManager get_Layout()
        {
        return ((_JWindow) get_Feed()).getContentPane().getLayout();
        }
    //-- javax.swing.JWindow integration
    
    // Declared at the super level
    public void _imports()
        {
        // import javax.swing.JWindow as _JWindow;
        

        }
    
    // Declared at the super level
    /**
    * Hosts (adds as a child) the specified JPanel and make the client area of
    * this container equal to the size of the hosted panel.
    * 
    * @see #getHostedPanel
    */
    public void hostPanel(_package.component.gUI.control.container.jComponent.JPanel panel)
        {
        setLocation(panel.getLocation());
        
        super.hostPanel(panel);
        }
    
    // Declared at the super level
    public void setLayout(_package.component.gUI.LayoutManager pLayout)
        {
        ((_JWindow) get_Feed()).getContentPane().setLayout(pLayout);
        }
    }
