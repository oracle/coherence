/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.ActionGroup
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.gUI.control.Container;

/**
* This component logically represents a group of related items (i.e. mutually
* exclusive CheckBoxMenuItems) that is present in the Component hierarchy, but
* does not exist as a swing component
* 
* Usually those items report Action events up to us.
*/
public class ActionGroup
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    // Default constructor
    public ActionGroup()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ActionGroup(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setOpaque(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ActionGroup();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/ActionGroup".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Find a position of the specified child component relative to other
    * children of this component by calculating the number of the "ordered"
    * children that have the lesser _Order property value
    * 
    * Note: a child with the _Order equal to 0.0 is considered to be not
    * "ordered".
    * 
    * @return position among the "ordered" children, where 0 means there is no
    * other child with a lower _Order value and -1 means that this child is not
    * ordered.
    * 
    */
    public int _positionOf(_package.Component child)
        {
        // the child is inserted to our parent (see addControl())
        return get_Parent()._positionOf(child);
        }
    
    // Declared at the super level
    /**
    * Adds the visual feed of the specified child component to the visual feed
    * of this container. Having this functionality separate from _addChild
    * allows it to be overwritten by containers that know better.
    * 
    * @see #_addChild
    */
    public void addControl(_package.component.gUI.Control child)
        {
        // import Component.GUI.Control.Container;
        
        // MenuGroup doesn't add itself to an AWT container (see getAWTContainer())
        // so the children are added to its parent
        
        // before adding our child to our parent let's bump up the "_Order"
        // of the child with our "_Order" value
        child.set_Order(this.get_Order() + child.get_Order());
        
        ((Container) get_Parent()).addControl(child);
        }
    
    // Declared at the super level
    /**
    * This method is called by  Component.Control.Container#addControl() as a
    * last chance to intervene during the construction/integration cycle.
    * A Control would override this if more than one AWT components should be
    * created for one Control or if the component should not be added to the
    * container (see Component...Window or Component...TabbedPanel).
    * This method can also be used to make sure that the parent is of the
    * allowed type (i.e. TabbedPanel is only allowed to be added into the
    * JTabbedPane).
    *  
    * @param  fAdd is true <b>only</b> when this is the frist call (from
    * addControl()) and an override is supposed to tie all the pieces together;
    * false in all other situations
    * 
    * @return AWT component that is added to a container [integratee].
    * 
    * @see Component.Control.Container.Window
    * @see Component.GUI.Control.Container.JComponent
    * @see
    * Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem.JMenu
    * @see Component.GUI.Control.Container.JComponent.JPanel.ButtonGroupPanel
    */
    public java.awt.Component getAWTContainee(boolean fAdd)
        {
        // ActionGroup doesn't add itself to an AWT container
        // (see addControl())
        return null;
        }
    
    /**
    * Method-notification taht serves as a "collector" event that is called by
    * the children of this ActionGroup
    */
    public void onAction(String action, int modifiers, String param)
        {
        }
    }
