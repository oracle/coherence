/* Class
*      jb_JComboBox
*
* automatically generated "Feed" which
* a) extends an external bean:
*      javax.swing.JComboBox
* b) delegates to the peer component:
*      Component.GUI.Control.Container.JComponent.JComboBox
*/

package _package.component.gUI.control.container.jComponent;

public class jb_JComboBox
        extends    javax.swing.JComboBox
        implements com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected JComboBox __peer;
    
    private static JComboBox __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            JComboBox peer = (JComboBox)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // default (JavaBean) constructor
    public jb_JComboBox()
        {
        this(JComboBox.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JComboBox(java.util.Vector Param_1)
        {
        this(Param_1, JComboBox.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JComboBox(javax.swing.ComboBoxModel Param_1)
        {
        this(Param_1, JComboBox.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JComboBox(Object[] Param_1)
        {
        this(Param_1, JComboBox.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JComboBox(Class clzPeer)
        {
        this(__createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JComboBox(java.util.Vector Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JComboBox(javax.swing.ComboBoxModel Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JComboBox(Object[] Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JComboBox(JComboBox peer, boolean fInit)
        {
        super();
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JComboBox(java.util.Vector Param_1, JComboBox peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JComboBox(javax.swing.ComboBoxModel Param_1, JComboBox peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JComboBox(Object[] Param_1, JComboBox peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private JComboBox __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (JComboBox) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_JComboBox(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    public void add(java.awt.Component comp, Object constraints, int index)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._add(comp, constraints, index);
        }
    void super$add(java.awt.Component comp, Object constraints, int index)
        {
        super.add(comp, constraints, index);
        }
    public void remove(java.awt.Component comp)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._remove(comp);
        }
    void super$remove(java.awt.Component comp)
        {
        super.remove(comp);
        }
    public void addActionListener(java.awt.event.ActionListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addActionListener(l);
        }
    void super$addActionListener(java.awt.event.ActionListener l)
        {
        super.addActionListener(l);
        }
    public void addFocusListener(java.awt.event.FocusListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addFocusListener(l);
        }
    void super$addFocusListener(java.awt.event.FocusListener l)
        {
        super.addFocusListener(l);
        }
    public void addItem(Object item)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addItem(item);
        }
    void super$addItem(Object item)
        {
        super.addItem(item);
        }
    public void addItemListener(java.awt.event.ItemListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addItemListener(l);
        }
    void super$addItemListener(java.awt.event.ItemListener l)
        {
        super.addItemListener(l);
        }
    public void addKeyListener(java.awt.event.KeyListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addKeyListener(l);
        }
    void super$addKeyListener(java.awt.event.KeyListener l)
        {
        super.addKeyListener(l);
        }
    public void addMouseListener(java.awt.event.MouseListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseListener(l);
        }
    void super$addMouseListener(java.awt.event.MouseListener l)
        {
        super.addMouseListener(l);
        }
    public void addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseMotionListener(l);
        }
    void super$addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.addMouseMotionListener(l);
        }
    public void addNotify()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addNotify();
        }
    void super$addNotify()
        {
        super.addNotify();
        }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addPropertyChangeListener(l);
        }
    void super$addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.addPropertyChangeListener(l);
        }
    public void addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addVetoableChangeListener(l);
        }
    void super$addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.addVetoableChangeListener(l);
        }
    public javax.swing.JToolTip createToolTip()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.createToolTip();
        }
    javax.swing.JToolTip super$createToolTip()
        {
        return super.createToolTip();
        }
    public void doLayout()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.doLayout();
        }
    void super$doLayout()
        {
        super.doLayout();
        }
    public java.awt.Color getBackground()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Background();
        }
    java.awt.Color super$getBackground()
        {
        return super.getBackground();
        }
    public javax.swing.border.Border getBorder()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Border();
        }
    javax.swing.border.Border super$getBorder()
        {
        return super.getBorder();
        }
    public java.awt.Rectangle getBounds()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Bounds();
        }
    java.awt.Rectangle super$getBounds()
        {
        return super.getBounds();
        }
    public java.awt.Cursor getCursor()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Cursor();
        }
    java.awt.Cursor super$getCursor()
        {
        return super.getCursor();
        }
    public java.awt.Font getFont()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Font();
        }
    java.awt.Font super$getFont()
        {
        return super.getFont();
        }
    public java.awt.Color getForeground()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Foreground();
        }
    java.awt.Color super$getForeground()
        {
        return super.getForeground();
        }
    public java.awt.Insets getInsets()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Insets();
        }
    java.awt.Insets super$getInsets()
        {
        return super.getInsets();
        }
    public java.awt.LayoutManager getLayout()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Layout();
        }
    java.awt.LayoutManager super$getLayout()
        {
        return super.getLayout();
        }
    public java.awt.Point getLocation()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Location();
        }
    java.awt.Point super$getLocation()
        {
        return super.getLocation();
        }
    public java.awt.Point getLocationOnScreen()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_LocationOnScreen();
        }
    java.awt.Point super$getLocationOnScreen()
        {
        return super.getLocationOnScreen();
        }
    public java.awt.Dimension getMaximumSize()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MaximumSize();
        }
    java.awt.Dimension super$getMaximumSize()
        {
        return super.getMaximumSize();
        }
    public java.awt.Dimension getMinimumSize()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MinimumSize();
        }
    java.awt.Dimension super$getMinimumSize()
        {
        return super.getMinimumSize();
        }
    public java.awt.Dimension getPreferredSize()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_PreferredSize();
        }
    java.awt.Dimension super$getPreferredSize()
        {
        return super.getPreferredSize();
        }
    public java.awt.Dimension getSize()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Size();
        }
    java.awt.Dimension super$getSize()
        {
        return super.getSize();
        }
    public Object getItemAt(int index)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getItemAt(index);
        }
    Object super$getItemAt(int index)
        {
        return super.getItemAt(index);
        }
    public int getItemCount()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getItemCount();
        }
    int super$getItemCount()
        {
        return super.getItemCount();
        }
    public int getMaximumRowCount()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getMaximumRowCount();
        }
    int super$getMaximumRowCount()
        {
        return super.getMaximumRowCount();
        }
    public int getSelectedIndex()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectedIndex();
        }
    int super$getSelectedIndex()
        {
        return super.getSelectedIndex();
        }
    public Object getSelectedItem()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectedItem();
        }
    Object super$getSelectedItem()
        {
        return super.getSelectedItem();
        }
    public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent e)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipLocation(e);
        }
    java.awt.Point super$getToolTipLocation(java.awt.event.MouseEvent e)
        {
        return super.getToolTipLocation(e);
        }
    public String getToolTipText()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText();
        }
    String super$getToolTipText()
        {
        return super.getToolTipText();
        }
    public String getToolTipText(java.awt.event.MouseEvent e)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText(e);
        }
    String super$getToolTipText(java.awt.event.MouseEvent e)
        {
        return super.getToolTipText(e);
        }
    public void insertItemAt(Object item, int index)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.insertItemAt(item, index);
        }
    void super$insertItemAt(Object item, int index)
        {
        super.insertItemAt(item, index);
        }
    public boolean getAutoscrolls()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isAutoscrolls();
        }
    boolean super$getAutoscrolls()
        {
        return super.getAutoscrolls();
        }
    public boolean isEditable()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isEditable();
        }
    boolean super$isEditable()
        {
        return super.isEditable();
        }
    public boolean isEnabled()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isEnabled();
        }
    boolean super$isEnabled()
        {
        return super.isEnabled();
        }
    public boolean isFocusTraversable()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isFocusTraversable();
        }
    boolean super$isFocusTraversable()
        {
        return super.isFocusTraversable();
        }
    public boolean isLightWeightPopupEnabled()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isLightWeightPopupEnabled();
        }
    boolean super$isLightWeightPopupEnabled()
        {
        return super.isLightWeightPopupEnabled();
        }
    public boolean isOpaque()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isOpaque();
        }
    boolean super$isOpaque()
        {
        return super.isOpaque();
        }
    public boolean isPopupVisible()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isPopupVisible();
        }
    boolean super$isPopupVisible()
        {
        return super.isPopupVisible();
        }
    public boolean isShowing()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isShowing();
        }
    boolean super$isShowing()
        {
        return super.isShowing();
        }
    public boolean isVisible()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isVisible();
        }
    boolean super$isVisible()
        {
        return super.isVisible();
        }
    public void paint(java.awt.Graphics g)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paint(g);
        }
    void super$paint(java.awt.Graphics g)
        {
        super.paint(g);
        }
    protected void paintBorder(java.awt.Graphics g)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintBorder(g);
        }
    void super$paintBorder(java.awt.Graphics g)
        {
        super.paintBorder(g);
        }
    protected void paintChildren(java.awt.Graphics g)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintChildren(g);
        }
    void super$paintChildren(java.awt.Graphics g)
        {
        super.paintChildren(g);
        }
    protected void paintComponent(java.awt.Graphics g)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintComponent(g);
        }
    void super$paintComponent(java.awt.Graphics g)
        {
        super.paintComponent(g);
        }
    public void removeActionListener(java.awt.event.ActionListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeActionListener(l);
        }
    void super$removeActionListener(java.awt.event.ActionListener l)
        {
        super.removeActionListener(l);
        }
    public void removeAllItems()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeAllItems();
        }
    void super$removeAllItems()
        {
        super.removeAllItems();
        }
    public void removeFocusListener(java.awt.event.FocusListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeFocusListener(l);
        }
    void super$removeFocusListener(java.awt.event.FocusListener l)
        {
        super.removeFocusListener(l);
        }
    public void removeItemAt(int index)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeItemAt(index);
        }
    void super$removeItemAt(int index)
        {
        super.removeItemAt(index);
        }
    public void removeItemListener(java.awt.event.ItemListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeItemListener(l);
        }
    void super$removeItemListener(java.awt.event.ItemListener l)
        {
        super.removeItemListener(l);
        }
    public void removeKeyListener(java.awt.event.KeyListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeKeyListener(l);
        }
    void super$removeKeyListener(java.awt.event.KeyListener l)
        {
        super.removeKeyListener(l);
        }
    public void removeMouseListener(java.awt.event.MouseListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseListener(l);
        }
    void super$removeMouseListener(java.awt.event.MouseListener l)
        {
        super.removeMouseListener(l);
        }
    public void removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseMotionListener(l);
        }
    void super$removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.removeMouseMotionListener(l);
        }
    public void removeNotify()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeNotify();
        }
    void super$removeNotify()
        {
        super.removeNotify();
        }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removePropertyChangeListener(l);
        }
    void super$removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.removePropertyChangeListener(l);
        }
    public void removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeVetoableChangeListener(l);
        }
    void super$removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.removeVetoableChangeListener(l);
        }
    public void requestFocus()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.requestFocus();
        }
    void super$requestFocus()
        {
        super.requestFocus();
        }
    public void setBackground(java.awt.Color p_Background)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Background(p_Background);
        }
    void super$setBackground(java.awt.Color p_Background)
        {
        super.setBackground(p_Background);
        }
    public void setBorder(javax.swing.border.Border p_Border)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Border(p_Border);
        }
    void super$setBorder(javax.swing.border.Border p_Border)
        {
        super.setBorder(p_Border);
        }
    public void setBounds(java.awt.Rectangle p_Bounds)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Bounds(p_Bounds);
        }
    void super$setBounds(java.awt.Rectangle p_Bounds)
        {
        super.setBounds(p_Bounds);
        }
    public void setCursor(java.awt.Cursor p_Cursor)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Cursor(p_Cursor);
        }
    void super$setCursor(java.awt.Cursor p_Cursor)
        {
        super.setCursor(p_Cursor);
        }
    public void setFont(java.awt.Font p_Font)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Font(p_Font);
        }
    void super$setFont(java.awt.Font p_Font)
        {
        super.setFont(p_Font);
        }
    public void setForeground(java.awt.Color p_Foreground)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Foreground(p_Foreground);
        }
    void super$setForeground(java.awt.Color p_Foreground)
        {
        super.setForeground(p_Foreground);
        }
    public void setLayout(java.awt.LayoutManager p_Layout)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Layout(p_Layout);
        }
    void super$setLayout(java.awt.LayoutManager p_Layout)
        {
        super.setLayout(p_Layout);
        }
    public void setLocation(java.awt.Point p_Location)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Location(p_Location);
        }
    void super$setLocation(java.awt.Point p_Location)
        {
        super.setLocation(p_Location);
        }
    public void setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MaximumSize(p_MaximumSize);
        }
    void super$setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        super.setMaximumSize(p_MaximumSize);
        }
    public void setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MinimumSize(p_MinimumSize);
        }
    void super$setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        super.setMinimumSize(p_MinimumSize);
        }
    public void setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_PreferredSize(p_PreferredSize);
        }
    void super$setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        super.setPreferredSize(p_PreferredSize);
        }
    public void setSize(java.awt.Dimension p_Size)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Size(p_Size);
        }
    void super$setSize(java.awt.Dimension p_Size)
        {
        super.setSize(p_Size);
        }
    public void setAutoscrolls(boolean pAutoscrolls)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setAutoscrolls(pAutoscrolls);
        }
    void super$setAutoscrolls(boolean pAutoscrolls)
        {
        super.setAutoscrolls(pAutoscrolls);
        }
    public void setEditable(boolean pEditable)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setEditable(pEditable);
        }
    void super$setEditable(boolean pEditable)
        {
        super.setEditable(pEditable);
        }
    public void setEnabled(boolean pEnabled)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setEnabled(pEnabled);
        }
    void super$setEnabled(boolean pEnabled)
        {
        super.setEnabled(pEnabled);
        }
    public void setLightWeightPopupEnabled(boolean pLightWeightPopupEnabled)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setLightWeightPopupEnabled(pLightWeightPopupEnabled);
        }
    void super$setLightWeightPopupEnabled(boolean pLightWeightPopupEnabled)
        {
        super.setLightWeightPopupEnabled(pLightWeightPopupEnabled);
        }
    public void setMaximumRowCount(int pMaximumRowCount)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setMaximumRowCount(pMaximumRowCount);
        }
    void super$setMaximumRowCount(int pMaximumRowCount)
        {
        super.setMaximumRowCount(pMaximumRowCount);
        }
    public void setOpaque(boolean pOpaque)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setOpaque(pOpaque);
        }
    void super$setOpaque(boolean pOpaque)
        {
        super.setOpaque(pOpaque);
        }
    public void setPopupVisible(boolean pPopupVisible)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setPopupVisible(pPopupVisible);
        }
    void super$setPopupVisible(boolean pPopupVisible)
        {
        super.setPopupVisible(pPopupVisible);
        }
    public void setSelectedIndex(int pSelectedIndex)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setSelectedIndex(pSelectedIndex);
        }
    void super$setSelectedIndex(int pSelectedIndex)
        {
        super.setSelectedIndex(pSelectedIndex);
        }
    public void setSelectedItem(Object pSelectedItem)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setSelectedItem(pSelectedItem);
        }
    void super$setSelectedItem(Object pSelectedItem)
        {
        super.setSelectedItem(pSelectedItem);
        }
    public void setToolTipText(String pToolTipText)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setToolTipText(pToolTipText);
        }
    void super$setToolTipText(String pToolTipText)
        {
        super.setToolTipText(pToolTipText);
        }
    public void setVisible(boolean pVisible)
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVisible(pVisible);
        }
    void super$setVisible(boolean pVisible)
        {
        super.setVisible(pVisible);
        }
    public void updateUI()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.updateUI();
        }
    void super$updateUI()
        {
        super.updateUI();
        }
    public void validate()
        {
        JComboBox peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.validate();
        }
    void super$validate()
        {
        super.validate();
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
