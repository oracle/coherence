/* Class
*     _package.component.gUI.control.container.jComponent.JLabel
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.image.Icon;

/*
* Integrates
*     javax.swing.JLabel
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JLabel
        extends    _package.component.gUI.control.container.JComponent
    {
    // Fields declarations
    
    /**
    * Property _DisplayedMnemonic
    *
    * This property of type "int" is wrapped by the DisplayedMnemonic property
    * of type "char" to make it easier to design.
    */
    private transient int __m__DisplayedMnemonic;
    
    /**
    * Property _Icon
    *
    */
    private transient javax.swing.Icon __m__Icon;
    
    /**
    * Property DisplayedMnemonic
    *
    */
    private transient char __m_DisplayedMnemonic;
    
    /**
    * Property HorizontalAlignment
    *
    * Specifies the alignment of the label's contents along the X axis.
    * 
    * The valid values are (see javax.swing.SwingConstants):
    * CENTER = 0
    * LEFT = 2
    * RIGHT = 4
    * LEADING = 10 (Default)
    * TRAILING = 11
    */
    private transient int __m_HorizontalAlignment;
    
    /**
    * Property HorizontalTextPosition
    *
    * Specifies the horizontal position of the label's text, relative to its
    * image.
    * 
    * The valid values are (see javax.swing.SwingConstants):
    * CENTER = 0
    * LEFT = 2
    * RIGHT = 4
    * LEADING = 10
    * TRAILING = 11 (Default)
    */
    private transient int __m_HorizontalTextPosition;
    
    /**
    * Property Icon
    *
    */
    private transient _package.component.gUI.image.Icon __m_Icon;
    
    /**
    * Property IconTextGap
    *
    * Specifies the amount of space (in pixels) between the text and the icon
    * displayed in this label.
    */
    private transient int __m_IconTextGap;
    
    /**
    * Property Text
    *
    */
    private transient String __m_Text;
    
    /**
    * Property TIcon
    *
    */
    private String __m_TIcon;
    
    /**
    * Property VerticalAlignment
    *
    * Specifies the alignment of the label's contents along the Y axis.
    * 
    * The valid values are (see javax.swing.SwingConstants):
    * CENTER = 0 (Default)
    * TOP = 1
    * BOTTOM = 3
    */
    private transient int __m_VerticalAlignment;
    
    /**
    * Property VerticalTextPosition
    *
    * Specifies the vertical position of the label's text, relative to its
    * image.
    * 
    * The valid values are (see javax.swing.SwingConstants):
    * CENTER = 0 (Default)
    * TOP = 1
    * BOTTOM = 3
    */
    private transient int __m_VerticalTextPosition;
    
    // fields used by the integration model:
    private sink_JLabel __sink;
    private javax.swing.JLabel __feed;
    
    // Default constructor
    public JLabel()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JLabel(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setHorizontalAlignment(10);
            setHorizontalTextPosition(11);
            setOpaque(false);
            setTBounds("0,0,100,17");
            setTFont("DefaultProportional");
            setVerticalAlignment(0);
            setVerticalTextPosition(0);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JLabel.__tloPeer.setObject(this);
            new jb_JLabel(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JLabel();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JLabel".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JLabel integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JLabel) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JLabel) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public int get_DisplayedMnemonic()
        {
        return __sink.getDisplayedMnemonic();
        }
    public int getHorizontalAlignment()
        {
        return __sink.getHorizontalAlignment();
        }
    public int getHorizontalTextPosition()
        {
        return __sink.getHorizontalTextPosition();
        }
    public javax.swing.Icon get_Icon()
        {
        return __sink.getIcon();
        }
    public int getIconTextGap()
        {
        return __sink.getIconTextGap();
        }
    public String getText()
        {
        return __sink.getText();
        }
    public int getVerticalAlignment()
        {
        return __sink.getVerticalAlignment();
        }
    public int getVerticalTextPosition()
        {
        return __sink.getVerticalTextPosition();
        }
    public void setDisplayedMnemonic(char pDisplayedMnemonic)
        {
        __sink.setDisplayedMnemonic(pDisplayedMnemonic);
        }
    public void set_DisplayedMnemonic(int p_DisplayedMnemonic)
        {
        __sink.setDisplayedMnemonic(p_DisplayedMnemonic);
        }
    public void setHorizontalAlignment(int pHorizontalAlignment)
        {
        __sink.setHorizontalAlignment(pHorizontalAlignment);
        }
    public void setHorizontalTextPosition(int pHorizontalTextPosition)
        {
        __sink.setHorizontalTextPosition(pHorizontalTextPosition);
        }
    public void set_Icon(javax.swing.Icon p_Icon)
        {
        __sink.setIcon(p_Icon);
        }
    public void setIconTextGap(int pIconTextGap)
        {
        __sink.setIconTextGap(pIconTextGap);
        }
    public void setText(String pText)
        {
        __sink.setText(pText);
        }
    public void setVerticalAlignment(int pVerticalAlignment)
        {
        __sink.setVerticalAlignment(pVerticalAlignment);
        }
    public void setVerticalTextPosition(int pVerticalTextPosition)
        {
        __sink.setVerticalTextPosition(pVerticalTextPosition);
        }
    //-- javax.swing.JLabel integration
    
    // Accessor for the property "DisplayedMnemonic"
    public char getDisplayedMnemonic()
        {
        return (char) get_DisplayedMnemonic();
        }
    
    // Accessor for the property "Icon"
    public _package.component.gUI.image.Icon getIcon()
        {
        // import Component.GUI.Image.Icon;
        
        javax.swing.Icon _icon = get_Icon();
        return _icon instanceof Icon ? (Icon) _icon : null;
        }
    
    // Accessor for the property "TIcon"
    public String getTIcon()
        {
        return __m_TIcon;
        }
    
    // Accessor for the property "Icon"
    public void setIcon(_package.component.gUI.image.Icon pIcon)
        {
        set_Icon(pIcon);
        }
    
    // Accessor for the property "TIcon"
    public void setTIcon(String pTIcon)
        {
        // import Component.GUI.Image.Icon;
        
        Icon icon = (Icon) _newInstance("Component.GUI.Image.Icon." + pTIcon);
        if (icon != null && icon.get_Icon() != null)
            {
            setIcon(icon);
            }
        }
    }
