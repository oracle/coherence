/* Class
*      jb_JToggleButton
*
* automatically generated "Feed" which
* a) extends an external bean:
*      javax.swing.JToggleButton
* b) delegates to the peer component:
*      Component.GUI.Control.Container.JComponent.AbstractButton.JToggleButton
*/

package _package.component.gUI.control.container.jComponent.abstractButton;

public class jb_JToggleButton
        extends    javax.swing.JToggleButton
        implements com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected JToggleButton __peer;
    
    private static JToggleButton __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            JToggleButton peer = (JToggleButton)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // default (JavaBean) constructor
    public jb_JToggleButton()
        {
        this(JToggleButton.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JToggleButton(String Param_1)
        {
        this(Param_1, JToggleButton.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JToggleButton(String Param_1, javax.swing.Icon Param_2)
        {
        this(Param_1, Param_2, JToggleButton.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JToggleButton(String Param_1, javax.swing.Icon Param_2, boolean Param_3)
        {
        this(Param_1, Param_2, Param_3, JToggleButton.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JToggleButton(String Param_1, boolean Param_2)
        {
        this(Param_1, Param_2, JToggleButton.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JToggleButton(javax.swing.Action Param_1)
        {
        this(Param_1, JToggleButton.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JToggleButton(javax.swing.Icon Param_1)
        {
        this(Param_1, JToggleButton.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JToggleButton(javax.swing.Icon Param_1, boolean Param_2)
        {
        this(Param_1, Param_2, JToggleButton.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JToggleButton(Class clzPeer)
        {
        this(__createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JToggleButton(String Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JToggleButton(String Param_1, javax.swing.Icon Param_2, Class clzPeer)
        {
        this(Param_1, Param_2, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JToggleButton(String Param_1, javax.swing.Icon Param_2, boolean Param_3, Class clzPeer)
        {
        this(Param_1, Param_2, Param_3, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JToggleButton(String Param_1, boolean Param_2, Class clzPeer)
        {
        this(Param_1, Param_2, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JToggleButton(javax.swing.Action Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JToggleButton(javax.swing.Icon Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JToggleButton(javax.swing.Icon Param_1, boolean Param_2, Class clzPeer)
        {
        this(Param_1, Param_2, __createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JToggleButton(JToggleButton peer, boolean fInit)
        {
        super();
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JToggleButton(String Param_1, JToggleButton peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JToggleButton(String Param_1, javax.swing.Icon Param_2, JToggleButton peer, boolean fInit)
        {
        super(Param_1, Param_2);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JToggleButton(String Param_1, javax.swing.Icon Param_2, boolean Param_3, JToggleButton peer, boolean fInit)
        {
        super(Param_1, Param_2, Param_3);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JToggleButton(String Param_1, boolean Param_2, JToggleButton peer, boolean fInit)
        {
        super(Param_1, Param_2);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JToggleButton(javax.swing.Action Param_1, JToggleButton peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JToggleButton(javax.swing.Icon Param_1, JToggleButton peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JToggleButton(javax.swing.Icon Param_1, boolean Param_2, JToggleButton peer, boolean fInit)
        {
        super(Param_1, Param_2);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private JToggleButton __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (JToggleButton) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_JToggleButton(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    public void add(java.awt.Component comp, Object constraints, int index)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._add(comp, constraints, index);
        }
    void super$add(java.awt.Component comp, Object constraints, int index)
        {
        super.add(comp, constraints, index);
        }
    public void remove(java.awt.Component comp)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._remove(comp);
        }
    void super$remove(java.awt.Component comp)
        {
        super.remove(comp);
        }
    public void addActionListener(java.awt.event.ActionListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addActionListener(l);
        }
    void super$addActionListener(java.awt.event.ActionListener l)
        {
        super.addActionListener(l);
        }
    public void addChangeListener(javax.swing.event.ChangeListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addChangeListener(l);
        }
    void super$addChangeListener(javax.swing.event.ChangeListener l)
        {
        super.addChangeListener(l);
        }
    public void addFocusListener(java.awt.event.FocusListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addFocusListener(l);
        }
    void super$addFocusListener(java.awt.event.FocusListener l)
        {
        super.addFocusListener(l);
        }
    public void addItemListener(java.awt.event.ItemListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addItemListener(l);
        }
    void super$addItemListener(java.awt.event.ItemListener l)
        {
        super.addItemListener(l);
        }
    public void addKeyListener(java.awt.event.KeyListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addKeyListener(l);
        }
    void super$addKeyListener(java.awt.event.KeyListener l)
        {
        super.addKeyListener(l);
        }
    public void addMouseListener(java.awt.event.MouseListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseListener(l);
        }
    void super$addMouseListener(java.awt.event.MouseListener l)
        {
        super.addMouseListener(l);
        }
    public void addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseMotionListener(l);
        }
    void super$addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.addMouseMotionListener(l);
        }
    public void addNotify()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addNotify();
        }
    void super$addNotify()
        {
        super.addNotify();
        }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addPropertyChangeListener(l);
        }
    void super$addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.addPropertyChangeListener(l);
        }
    public void addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addVetoableChangeListener(l);
        }
    void super$addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.addVetoableChangeListener(l);
        }
    public javax.swing.JToolTip createToolTip()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.createToolTip();
        }
    javax.swing.JToolTip super$createToolTip()
        {
        return super.createToolTip();
        }
    public void doClick()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.doClick();
        }
    void super$doClick()
        {
        super.doClick();
        }
    public void doClick(int iPressTime)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.doClick(iPressTime);
        }
    void super$doClick(int iPressTime)
        {
        super.doClick(iPressTime);
        }
    public void doLayout()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.doLayout();
        }
    void super$doLayout()
        {
        super.doLayout();
        }
    public java.awt.Color getBackground()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Background();
        }
    java.awt.Color super$getBackground()
        {
        return super.getBackground();
        }
    public javax.swing.border.Border getBorder()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Border();
        }
    javax.swing.border.Border super$getBorder()
        {
        return super.getBorder();
        }
    public java.awt.Rectangle getBounds()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Bounds();
        }
    java.awt.Rectangle super$getBounds()
        {
        return super.getBounds();
        }
    public java.awt.Cursor getCursor()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Cursor();
        }
    java.awt.Cursor super$getCursor()
        {
        return super.getCursor();
        }
    public javax.swing.Icon getDisabledIcon()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_DisabledIcon();
        }
    javax.swing.Icon super$getDisabledIcon()
        {
        return super.getDisabledIcon();
        }
    public javax.swing.Icon getDisabledSelectedIcon()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_DisabledSelectedIcon();
        }
    javax.swing.Icon super$getDisabledSelectedIcon()
        {
        return super.getDisabledSelectedIcon();
        }
    public java.awt.Font getFont()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Font();
        }
    java.awt.Font super$getFont()
        {
        return super.getFont();
        }
    public java.awt.Color getForeground()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Foreground();
        }
    java.awt.Color super$getForeground()
        {
        return super.getForeground();
        }
    public javax.swing.Icon getIcon()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Icon();
        }
    javax.swing.Icon super$getIcon()
        {
        return super.getIcon();
        }
    public java.awt.Insets getInsets()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Insets();
        }
    java.awt.Insets super$getInsets()
        {
        return super.getInsets();
        }
    public java.awt.LayoutManager getLayout()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Layout();
        }
    java.awt.LayoutManager super$getLayout()
        {
        return super.getLayout();
        }
    public java.awt.Point getLocation()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Location();
        }
    java.awt.Point super$getLocation()
        {
        return super.getLocation();
        }
    public java.awt.Point getLocationOnScreen()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_LocationOnScreen();
        }
    java.awt.Point super$getLocationOnScreen()
        {
        return super.getLocationOnScreen();
        }
    public java.awt.Insets getMargin()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Margin();
        }
    java.awt.Insets super$getMargin()
        {
        return super.getMargin();
        }
    public java.awt.Dimension getMaximumSize()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MaximumSize();
        }
    java.awt.Dimension super$getMaximumSize()
        {
        return super.getMaximumSize();
        }
    public java.awt.Dimension getMinimumSize()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MinimumSize();
        }
    java.awt.Dimension super$getMinimumSize()
        {
        return super.getMinimumSize();
        }
    public int getMnemonic()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Mnemonic();
        }
    int super$getMnemonic()
        {
        return super.getMnemonic();
        }
    public java.awt.Dimension getPreferredSize()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_PreferredSize();
        }
    java.awt.Dimension super$getPreferredSize()
        {
        return super.getPreferredSize();
        }
    public javax.swing.Icon getPressedIcon()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_PressedIcon();
        }
    javax.swing.Icon super$getPressedIcon()
        {
        return super.getPressedIcon();
        }
    public javax.swing.Icon getRolloverIcon()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_RolloverIcon();
        }
    javax.swing.Icon super$getRolloverIcon()
        {
        return super.getRolloverIcon();
        }
    public javax.swing.Icon getRolloverSelectedIcon()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_RolloverSelectedIcon();
        }
    javax.swing.Icon super$getRolloverSelectedIcon()
        {
        return super.getRolloverSelectedIcon();
        }
    public javax.swing.Icon getSelectedIcon()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_SelectedIcon();
        }
    javax.swing.Icon super$getSelectedIcon()
        {
        return super.getSelectedIcon();
        }
    public java.awt.Dimension getSize()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Size();
        }
    java.awt.Dimension super$getSize()
        {
        return super.getSize();
        }
    public String getActionCommand()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getActionCommand();
        }
    String super$getActionCommand()
        {
        return super.getActionCommand();
        }
    public int getHorizontalAlignment()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getHorizontalAlignment();
        }
    int super$getHorizontalAlignment()
        {
        return super.getHorizontalAlignment();
        }
    public int getHorizontalTextPosition()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getHorizontalTextPosition();
        }
    int super$getHorizontalTextPosition()
        {
        return super.getHorizontalTextPosition();
        }
    public String getText()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getText();
        }
    String super$getText()
        {
        return super.getText();
        }
    public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent e)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipLocation(e);
        }
    java.awt.Point super$getToolTipLocation(java.awt.event.MouseEvent e)
        {
        return super.getToolTipLocation(e);
        }
    public String getToolTipText()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText();
        }
    String super$getToolTipText()
        {
        return super.getToolTipText();
        }
    public String getToolTipText(java.awt.event.MouseEvent e)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText(e);
        }
    String super$getToolTipText(java.awt.event.MouseEvent e)
        {
        return super.getToolTipText(e);
        }
    public int getVerticalAlignment()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getVerticalAlignment();
        }
    int super$getVerticalAlignment()
        {
        return super.getVerticalAlignment();
        }
    public int getVerticalTextPosition()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getVerticalTextPosition();
        }
    int super$getVerticalTextPosition()
        {
        return super.getVerticalTextPosition();
        }
    public boolean getAutoscrolls()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isAutoscrolls();
        }
    boolean super$getAutoscrolls()
        {
        return super.getAutoscrolls();
        }
    public boolean isEnabled()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isEnabled();
        }
    boolean super$isEnabled()
        {
        return super.isEnabled();
        }
    public boolean isFocusPainted()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isFocusPainted();
        }
    boolean super$isFocusPainted()
        {
        return super.isFocusPainted();
        }
    public boolean isFocusTraversable()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isFocusTraversable();
        }
    boolean super$isFocusTraversable()
        {
        return super.isFocusTraversable();
        }
    public boolean isOpaque()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isOpaque();
        }
    boolean super$isOpaque()
        {
        return super.isOpaque();
        }
    public boolean isRolloverEnabled()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isRolloverEnabled();
        }
    boolean super$isRolloverEnabled()
        {
        return super.isRolloverEnabled();
        }
    public boolean isSelected()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isSelected();
        }
    boolean super$isSelected()
        {
        return super.isSelected();
        }
    public boolean isShowing()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isShowing();
        }
    boolean super$isShowing()
        {
        return super.isShowing();
        }
    public boolean isVisible()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isVisible();
        }
    boolean super$isVisible()
        {
        return super.isVisible();
        }
    public void paint(java.awt.Graphics g)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paint(g);
        }
    void super$paint(java.awt.Graphics g)
        {
        super.paint(g);
        }
    protected void paintBorder(java.awt.Graphics g)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintBorder(g);
        }
    void super$paintBorder(java.awt.Graphics g)
        {
        super.paintBorder(g);
        }
    protected void paintChildren(java.awt.Graphics g)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintChildren(g);
        }
    void super$paintChildren(java.awt.Graphics g)
        {
        super.paintChildren(g);
        }
    protected void paintComponent(java.awt.Graphics g)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintComponent(g);
        }
    void super$paintComponent(java.awt.Graphics g)
        {
        super.paintComponent(g);
        }
    public void removeActionListener(java.awt.event.ActionListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeActionListener(l);
        }
    void super$removeActionListener(java.awt.event.ActionListener l)
        {
        super.removeActionListener(l);
        }
    public void removeChangeListener(javax.swing.event.ChangeListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeChangeListener(l);
        }
    void super$removeChangeListener(javax.swing.event.ChangeListener l)
        {
        super.removeChangeListener(l);
        }
    public void removeFocusListener(java.awt.event.FocusListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeFocusListener(l);
        }
    void super$removeFocusListener(java.awt.event.FocusListener l)
        {
        super.removeFocusListener(l);
        }
    public void removeItemListener(java.awt.event.ItemListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeItemListener(l);
        }
    void super$removeItemListener(java.awt.event.ItemListener l)
        {
        super.removeItemListener(l);
        }
    public void removeKeyListener(java.awt.event.KeyListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeKeyListener(l);
        }
    void super$removeKeyListener(java.awt.event.KeyListener l)
        {
        super.removeKeyListener(l);
        }
    public void removeMouseListener(java.awt.event.MouseListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseListener(l);
        }
    void super$removeMouseListener(java.awt.event.MouseListener l)
        {
        super.removeMouseListener(l);
        }
    public void removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseMotionListener(l);
        }
    void super$removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.removeMouseMotionListener(l);
        }
    public void removeNotify()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeNotify();
        }
    void super$removeNotify()
        {
        super.removeNotify();
        }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removePropertyChangeListener(l);
        }
    void super$removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.removePropertyChangeListener(l);
        }
    public void removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeVetoableChangeListener(l);
        }
    void super$removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.removeVetoableChangeListener(l);
        }
    public void requestFocus()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.requestFocus();
        }
    void super$requestFocus()
        {
        super.requestFocus();
        }
    public void setBackground(java.awt.Color p_Background)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Background(p_Background);
        }
    void super$setBackground(java.awt.Color p_Background)
        {
        super.setBackground(p_Background);
        }
    public void setBorder(javax.swing.border.Border p_Border)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Border(p_Border);
        }
    void super$setBorder(javax.swing.border.Border p_Border)
        {
        super.setBorder(p_Border);
        }
    public void setBounds(java.awt.Rectangle p_Bounds)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Bounds(p_Bounds);
        }
    void super$setBounds(java.awt.Rectangle p_Bounds)
        {
        super.setBounds(p_Bounds);
        }
    public void setCursor(java.awt.Cursor p_Cursor)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Cursor(p_Cursor);
        }
    void super$setCursor(java.awt.Cursor p_Cursor)
        {
        super.setCursor(p_Cursor);
        }
    public void setDisabledIcon(javax.swing.Icon p_DisabledIcon)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_DisabledIcon(p_DisabledIcon);
        }
    void super$setDisabledIcon(javax.swing.Icon p_DisabledIcon)
        {
        super.setDisabledIcon(p_DisabledIcon);
        }
    public void setDisabledSelectedIcon(javax.swing.Icon p_DisabledSelectedIcon)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_DisabledSelectedIcon(p_DisabledSelectedIcon);
        }
    void super$setDisabledSelectedIcon(javax.swing.Icon p_DisabledSelectedIcon)
        {
        super.setDisabledSelectedIcon(p_DisabledSelectedIcon);
        }
    public void setFont(java.awt.Font p_Font)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Font(p_Font);
        }
    void super$setFont(java.awt.Font p_Font)
        {
        super.setFont(p_Font);
        }
    public void setForeground(java.awt.Color p_Foreground)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Foreground(p_Foreground);
        }
    void super$setForeground(java.awt.Color p_Foreground)
        {
        super.setForeground(p_Foreground);
        }
    public void setIcon(javax.swing.Icon p_Icon)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Icon(p_Icon);
        }
    void super$setIcon(javax.swing.Icon p_Icon)
        {
        super.setIcon(p_Icon);
        }
    public void setLayout(java.awt.LayoutManager p_Layout)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Layout(p_Layout);
        }
    void super$setLayout(java.awt.LayoutManager p_Layout)
        {
        super.setLayout(p_Layout);
        }
    public void setLocation(java.awt.Point p_Location)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Location(p_Location);
        }
    void super$setLocation(java.awt.Point p_Location)
        {
        super.setLocation(p_Location);
        }
    public void setMargin(java.awt.Insets p_Margin)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Margin(p_Margin);
        }
    void super$setMargin(java.awt.Insets p_Margin)
        {
        super.setMargin(p_Margin);
        }
    public void setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MaximumSize(p_MaximumSize);
        }
    void super$setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        super.setMaximumSize(p_MaximumSize);
        }
    public void setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MinimumSize(p_MinimumSize);
        }
    void super$setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        super.setMinimumSize(p_MinimumSize);
        }
    public void setMnemonic(int p_Mnemonic)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Mnemonic(p_Mnemonic);
        }
    void super$setMnemonic(int p_Mnemonic)
        {
        super.setMnemonic(p_Mnemonic);
        }
    public void setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_PreferredSize(p_PreferredSize);
        }
    void super$setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        super.setPreferredSize(p_PreferredSize);
        }
    public void setPressedIcon(javax.swing.Icon p_PressedIcon)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_PressedIcon(p_PressedIcon);
        }
    void super$setPressedIcon(javax.swing.Icon p_PressedIcon)
        {
        super.setPressedIcon(p_PressedIcon);
        }
    public void setRolloverIcon(javax.swing.Icon p_RolloverIcon)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_RolloverIcon(p_RolloverIcon);
        }
    void super$setRolloverIcon(javax.swing.Icon p_RolloverIcon)
        {
        super.setRolloverIcon(p_RolloverIcon);
        }
    public void setRolloverSelectedIcon(javax.swing.Icon p_RolloverSelectedIcon)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_RolloverSelectedIcon(p_RolloverSelectedIcon);
        }
    void super$setRolloverSelectedIcon(javax.swing.Icon p_RolloverSelectedIcon)
        {
        super.setRolloverSelectedIcon(p_RolloverSelectedIcon);
        }
    public void setSelectedIcon(javax.swing.Icon p_SelectedIcon)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_SelectedIcon(p_SelectedIcon);
        }
    void super$setSelectedIcon(javax.swing.Icon p_SelectedIcon)
        {
        super.setSelectedIcon(p_SelectedIcon);
        }
    public void setSize(java.awt.Dimension p_Size)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Size(p_Size);
        }
    void super$setSize(java.awt.Dimension p_Size)
        {
        super.setSize(p_Size);
        }
    public void setActionCommand(String pActionCommand)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setActionCommand(pActionCommand);
        }
    void super$setActionCommand(String pActionCommand)
        {
        super.setActionCommand(pActionCommand);
        }
    public void setAutoscrolls(boolean pAutoscrolls)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setAutoscrolls(pAutoscrolls);
        }
    void super$setAutoscrolls(boolean pAutoscrolls)
        {
        super.setAutoscrolls(pAutoscrolls);
        }
    public void setEnabled(boolean pEnabled)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setEnabled(pEnabled);
        }
    void super$setEnabled(boolean pEnabled)
        {
        super.setEnabled(pEnabled);
        }
    public void setFocusPainted(boolean pFocusPainted)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setFocusPainted(pFocusPainted);
        }
    void super$setFocusPainted(boolean pFocusPainted)
        {
        super.setFocusPainted(pFocusPainted);
        }
    public void setHorizontalAlignment(int pHorizontalAlignment)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setHorizontalAlignment(pHorizontalAlignment);
        }
    void super$setHorizontalAlignment(int pHorizontalAlignment)
        {
        super.setHorizontalAlignment(pHorizontalAlignment);
        }
    public void setHorizontalTextPosition(int pHorizontalTextPosition)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setHorizontalTextPosition(pHorizontalTextPosition);
        }
    void super$setHorizontalTextPosition(int pHorizontalTextPosition)
        {
        super.setHorizontalTextPosition(pHorizontalTextPosition);
        }
    public void setMnemonic(char pMnemonic)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setMnemonic(pMnemonic);
        }
    void super$setMnemonic(char pMnemonic)
        {
        super.setMnemonic(pMnemonic);
        }
    public void setOpaque(boolean pOpaque)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setOpaque(pOpaque);
        }
    void super$setOpaque(boolean pOpaque)
        {
        super.setOpaque(pOpaque);
        }
    public void setRolloverEnabled(boolean pRolloverEnabled)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setRolloverEnabled(pRolloverEnabled);
        }
    void super$setRolloverEnabled(boolean pRolloverEnabled)
        {
        super.setRolloverEnabled(pRolloverEnabled);
        }
    public void setSelected(boolean pSelected)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setSelected(pSelected);
        }
    void super$setSelected(boolean pSelected)
        {
        super.setSelected(pSelected);
        }
    public void setText(String pText)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setText(pText);
        }
    void super$setText(String pText)
        {
        super.setText(pText);
        }
    public void setToolTipText(String pToolTipText)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setToolTipText(pToolTipText);
        }
    void super$setToolTipText(String pToolTipText)
        {
        super.setToolTipText(pToolTipText);
        }
    public void setVerticalAlignment(int pVerticalAlignment)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVerticalAlignment(pVerticalAlignment);
        }
    void super$setVerticalAlignment(int pVerticalAlignment)
        {
        super.setVerticalAlignment(pVerticalAlignment);
        }
    public void setVerticalTextPosition(int pVerticalTextPosition)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVerticalTextPosition(pVerticalTextPosition);
        }
    void super$setVerticalTextPosition(int pVerticalTextPosition)
        {
        super.setVerticalTextPosition(pVerticalTextPosition);
        }
    public void setVisible(boolean pVisible)
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVisible(pVisible);
        }
    void super$setVisible(boolean pVisible)
        {
        super.setVisible(pVisible);
        }
    public void updateUI()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.updateUI();
        }
    void super$updateUI()
        {
        super.updateUI();
        }
    public void validate()
        {
        JToggleButton peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.validate();
        }
    void super$validate()
        {
        super.validate();
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
