/* Class
*     _package.component.gUI.control.Container
*/

package _package.component.gUI.control;

import _package.component.gUI.Constraints;
import _package.component.gUI.Control;
import _package.component.gUI.Dimension;
import _package.component.gUI.Insets;
import _package.component.gUI.LayoutManager;
import _package.component.gUI.control.container.jComponent.JPanel;
import java.awt.LayoutManager; // as _LayoutManager

/*
* Integrates
*     java.awt.Container
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class Container
        extends    _package.component.gUI.Control
    {
    // Fields declarations
    
    /**
    * Property _Insets
    *
    */
    
    /**
    * Property _Layout
    *
    */
    private transient java.awt.LayoutManager __m__Layout;
    
    /**
    * Property HostedPanel
    *
    * Specifies a panel hosted by this container.
    * 
    * @see #hostPanel
    */
    
    /**
    * Property Insets
    *
    */
    
    /**
    * Property Layout
    *
    */
    private transient _package.component.gUI.LayoutManager __m_Layout;
    
    /**
    * Property MAIN_PANEL
    *
    */
    public static final String MAIN_PANEL = "_MainPanel";
    
    /**
    * Property TLayout
    *
    */
    
    // fields used by the integration model:
    private sink_Container __sink;
    private java.awt.Container __feed;
    
    // Default constructor
    public Container()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Container(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_Container.__tloPeer.setObject(this);
            new jb_Container(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Container();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/Container".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.Container integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_Container) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (java.awt.Container) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public void _add(java.awt.Component comp, Object constraints, int index)
        {
        __sink.add(comp, constraints, index);
        }
    public java.awt.Insets get_Insets()
        {
        return __sink.getInsets();
        }
    public java.awt.LayoutManager get_Layout()
        {
        return __sink.getLayout();
        }
    public void _remove(java.awt.Component comp)
        {
        __sink.remove(comp);
        }
    public void set_Layout(java.awt.LayoutManager p_Layout)
        {
        __sink.setLayout(p_Layout);
        }
    //-- java.awt.Container integration
    
    // Declared at the super level
    /**
    * Add a child component with the specified name to this component.
    * 
    * @param child  a component to add ti this component as a child
    * @param name  a [unique] name to identify this child. If the name is not
    * specified (null is passed) then a unique child name will be automatically
    * assigned
    * 
    * Note: this method fires onAdd() notification only if the parent (this
    * component) has already been fully constructed.
    * Note2: component containment/aggregation produces children initialization
    * code (see __init()) that is executed while the parent is not flagged as
    * _Constructed yet
    */
    public void _addChild(_package.Component child, String name)
        {
        // import Component.GUI.Control;
        
        // the general idea here is that during the call to
        // addControl() the child component is already "plugged in"
        // (i.e. known to its component parent)
        
        super._addChild(child, name);
        
        if (child instanceof Control)
            {
            addControl((Control) child);
            }
        }
    
    // Declared at the super level
    /**
    * Remove the specified child component.
    */
    public void _removeChild(_package.Component child)
        {
        // import Component.GUI.Control;
        
        // the general idea here is that during the call to
        // removeControl() the child component is still "plugged in"
        // (i.e. known to its component parent)
        
        if (child instanceof Control)
            {
            removeControl((Control) child);
            }
        
        super._removeChild(child);
        }
    
    /**
    * Adds the visual feed of the specified child component to the visual feed
    * of this container. Having this functionality separate from _addChild
    * allows it to be overwritten by containers that know better.
    * 
    * @see #_addChild
    */
    public void addControl(_package.component.gUI.Control child)
        {
        // import Component.GUI.Constraints;
        
        // We have this method separate from _addChild(), so it
        // could be overwritten by those Containers that know better ...
        
        java.awt.Container _feed      = (java.awt.Container) get_Feed();
        java.awt.Component _containee = child.getAWTContainee(true);
        
        if (_containee != null)
            {
            Constraints constraints  = child.getConstraints();
            Object      _constraints = constraints == null ? null : constraints.get_Constraints();
            int         index        = child.get_Position();
        
            //_trace("Adding " + child.get_Name() + " @(" + constraints + ") to " + get_Name() + " at " + index + " out of " + _feed.getComponentCount());
            if (index >= _feed.getComponentCount())
                {
                index = -1;
                }
        
            _add(_containee, _constraints, index);
            }
        }
    
    // Accessor for the property "HostedPanel"
    /**
    * Returns a panel hosted by this container.
    * 
    * @see #hostPanel
    */
    public _package.component.gUI.control.container.jComponent.JPanel getHostedPanel()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel;
        
        return (JPanel) _findChild(MAIN_PANEL);
        }
    
    // Accessor for the property "Insets"
    public _package.component.gUI.Insets getInsets()
        {
        // import Component.GUI.Insets;
        
        Insets wrapper = new Insets();
        wrapper.set_Insets(get_Insets());
        return wrapper;
        }
    
    // Accessor for the property "Layout"
    public _package.component.gUI.LayoutManager getLayout()
        {
        // import Component.GUI.LayoutManager;
        // import java.awt.LayoutManager as _LayoutManager;
        
        _LayoutManager _mgr = get_Layout();
        
        if (_mgr instanceof LayoutManager)
            {
            return (LayoutManager) _mgr;
            }
        else
            {
            LayoutManager wrapper = new LayoutManager();
            wrapper.set_Layout(_mgr);
            return wrapper;
            }
        }
    
    /**
    * Hosts (adds as a child) the specified JPanel and make the client area of
    * this container equal to the size of the hosted panel.
    * 
    * @see #getHostedPanel
    */
    public void hostPanel(_package.component.gUI.control.container.jComponent.JPanel panel)
        {
        // import Component.GUI.Dimension;
        // import Component.GUI.Insets;
        
        Dimension size = panel.getSize();
        
        // to make the client area of the container equal to the size of this panel
        // we have to compensate container's insets
        Insets insets = getInsets();
        
        size.setWidth (size.getWidth()  + insets.getLeft() + insets.getRight());
        size.setHeight(size.getHeight() + insets.getTop()  + insets.getBottom());
        setSize(size);
        
        _addChild(panel, MAIN_PANEL);
        }
    
    /**
    * @see #_removeChild
    */
    public void removeControl(_package.component.gUI.Control child)
        {
        java.awt.Component containee  = child.getAWTContainee(false);
        if (containee != null)
            {
            _remove(containee);
            }

        }
    
    // Accessor for the property "Layout"
    public void setLayout(_package.component.gUI.LayoutManager pLayout)
        {
        set_Layout(pLayout);
        }
    
    // Accessor for the property "TLayout"
    public void setTLayout(String pTLayout)
        {
        // import Component.GUI.LayoutManager;
        setLayout(pTLayout == null ? null :
            (LayoutManager) _newInstance("Component.GUI.LayoutManager." + pTLayout));

        }
    }
