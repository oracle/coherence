/* Class
*     _package.component.gUI.control.container.jComponent.JFileChooser
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.FileFilter;
import java.awt.Container;
import java.io.File;
import javax.swing.JFileChooser; // as _JFileChooser
import javax.swing.JList;
import javax.swing.filechooser.FileFilter; // as _FileFilter

/**
* This component integrates the javax.swing.JFileChooser component. It could
* also contain FileFilter children that will become choosable file filters for
* this file chooser.
* 
* @see #_addChild
*/
/*
* Integrates
*     javax.swing.JFileChooser
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JFileChooser
        extends    _package.component.gUI.control.container.JComponent
    {
    // Fields declarations
    
    /**
    * Property APPROVE_OPTION
    *
    */
    public static final int APPROVE_OPTION = 0; // javax.swing.JFileChooser.APPROVE_OPTION;
    
    /**
    * Property ApproveButtonMnemonic
    *
    * Specifies the approve button's mnemonic.
    */
    private transient char __m_ApproveButtonMnemonic;
    
    /**
    * Property ApproveButtonText
    *
    * Specifies the approve button's text.
    */
    private transient String __m_ApproveButtonText;
    
    /**
    * Property ApproveButtonToolTipText
    *
    * Specifies the approve button's tool tip text.
    */
    private transient String __m_ApproveButtonToolTipText;
    
    /**
    * Property CANCEL_OPTION
    *
    */
    public static final int CANCEL_OPTION = 1; // javax.swing.JFileChooser.CANCEL_OPTION;
    
    /**
    * Property CurrentDirectory
    *
    * Specifies the current directory. Passing in null sets the filechooser to
    * point to the users's home directory.
    */
    private transient java.io.File __m_CurrentDirectory;
    
    /**
    * Property CUSTOM_DIALOG
    *
    */
    public static final int CUSTOM_DIALOG = 2; // javax.swing.JFileChooser.CUSTOM_DIALOG;
    
    /**
    * Property DialogTitle
    *
    * Specifeis the dialog box title.
    */
    private transient String __m_DialogTitle;
    
    /**
    * Property DialogType
    *
    * Specifies the type of the dialog to be displayed. The value is one of:
    * OPEN_DIALOG = 0
    * SAVE_DIALOG = 1
    * CUSTOM_DIALOG = 2
    */
    private transient int __m_DialogType;
    
    /**
    * Property DIRECTORIES_ONLY
    *
    */
    public static final int DIRECTORIES_ONLY = 1; // javax.swing.JFileChooser.DIRECTORIES_ONLY;
    
    /**
    * Property FileFilter
    *
    * Specifies the current file filter.
    */
    private transient _package.component.gUI.FileFilter __m_FileFilter;
    
    /**
    * Property FileHidingEnabled
    *
    * Specifies whether or not the hidden files are not shown in the
    * filechooser.
    */
    private transient boolean __m_FileHidingEnabled;
    
    /**
    * Property FILES_AND_DIRECTORIES
    *
    */
    public static final int FILES_AND_DIRECTORIES = 2; // javax.swing.JFileChooser.FILES_AND_DIRECTORIES;
    
    /**
    * Property FILES_ONLY
    *
    */
    public static final int FILES_ONLY = 0; // javax.swing.JFileChooser.FILES_ONLY;
    
    /**
    * Property FileSelectionMode
    *
    * Specifies whether the FileChooser allows the user to just select files,
    * just select directories, or select both files and directetories.
    * 
    * Valid values are
    * FILES_ONLY=0
    * DIRECTORIES_ONLY=1
    * FILES_AND_DIRECTORIES=2
    */
    private transient int __m_FileSelectionMode;
    
    /**
    * Property FileSystemView
    *
    */
    private transient javax.swing.filechooser.FileSystemView __m_FileSystemView;
    
    /**
    * Property LastCurrentDirectory
    *
    * The last current directory used by a FileChooser. This static property
    * allows the file chooser to be more user friendly and rememeber the last
    * current directory used by any instance of the file chooser.
    */
    private static transient java.io.File __s_LastCurrentDirectory;
    
    /**
    * Property MultiSelectionEnabled
    *
    * Specifies whether or not the filechooser is allowing multiple file
    * selections.
    */
    private transient boolean __m_MultiSelectionEnabled;
    
    /**
    * Property OPEN_DIALOG
    *
    */
    public static final int OPEN_DIALOG = 0; // javax.swing.JFileChooser.OPEN_DIALOG;
    
    /**
    * Property SAVE_DIALOG
    *
    */
    public static final int SAVE_DIALOG = 1; // javax.swing.JFileChooser.SAVE_DIALOG;
    
    /**
    * Property SelectedFile
    *
    */
    private transient java.io.File __m_SelectedFile;
    
    /**
    * Property SelectedFiles
    *
    */
    private transient java.io.File[] __m_SelectedFiles;
    
    // fields used by the integration model:
    private sink_JFileChooser __sink;
    private javax.swing.JFileChooser __feed;
    
    // Default constructor
    public JFileChooser()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JFileChooser(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JFileChooser.__tloPeer.setObject(this);
            new jb_JFileChooser(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JFileChooser();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JFileChooser".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JFileChooser integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JFileChooser) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JFileChooser) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    /**
    * Returns true if the file should be displayed. This method could be
    * overriden by subclasses.
    */
    public boolean accept(java.io.File f)
        {
        return __sink.accept(f);
        }
    /**
    * Called by the UI when the user hits the approve (AKA "Open" or "Save")
    * button. This method could be overriden by subclasses.
    */
    public void approveSelection()
        {
        __sink.approveSelection();
        }
    /**
    * Called by the UI when the user hits the "Cancel" button. This method
    * could be overriden by subclasses.
    */
    public void cancelSelection()
        {
        __sink.cancelSelection();
        }
    public int get_ApproveButtonMnemonic()
        {
        return __sink.getApproveButtonMnemonic();
        }
    public String getApproveButtonText()
        {
        return __sink.getApproveButtonText();
        }
    public String getApproveButtonToolTipText()
        {
        return __sink.getApproveButtonToolTipText();
        }
    public java.io.File getCurrentDirectory()
        {
        return __sink.getCurrentDirectory();
        }
    public String getDialogTitle()
        {
        return __sink.getDialogTitle();
        }
    public int getDialogType()
        {
        return __sink.getDialogType();
        }
    public int getFileSelectionMode()
        {
        return __sink.getFileSelectionMode();
        }
    public javax.swing.filechooser.FileSystemView getFileSystemView()
        {
        return __sink.getFileSystemView();
        }
    public java.io.File getSelectedFile()
        {
        return __sink.getSelectedFile();
        }
    private java.io.File[] getSelectedFiles$Router()
        {
        return __sink.getSelectedFiles();
        }
    public java.io.File[] getSelectedFiles()
        {
        // import java.awt.Container;
        // import java.io.File;
        // import javax.swing.JList;
        
        File[] aFile = getSelectedFiles$Router();
        
        if (aFile.length == 0)
            {
            // TODO: remove when the bug (Id # 4218431) is fixed
            // Note: this only works for Metal PLAF
            JList     jl = null;
            Container c1 = (Container) ((_JFileChooser) get_Feed()).getComponent(3); // center panel
            while (c1 != null)
                {
                Container c = (Container) c1.getComponent(0);
                if (c instanceof JList)
                    {
                    jl = (JList) c;
                    break;
                    }
                c1 = c;
                }
        
            if (jl != null)
                {
                Object[] aoSel = jl.getSelectedValues();
        
                aFile = new File[aoSel.length];
            
                for (int i = 0; i < aoSel.length; i++)
                    {
                    if (aoSel[i] instanceof File)
                        {
                        aFile[i] = (File) aoSel[i];
                        }
                    }
                }
            }
        
        return aFile;
        }
    public boolean isFileHidingEnabled()
        {
        return __sink.isFileHidingEnabled();
        }
    public boolean isMultiSelectionEnabled()
        {
        return __sink.isMultiSelectionEnabled();
        }
    /**
    * Returns true if the file (directory) can be visited, false if the
    * directory cannot be traversed. This method could be overriden by
    * subclasses.
    */
    public boolean isTraversable(java.io.File f)
        {
        return __sink.isTraversable(f);
        }
    public void setApproveButtonMnemonic(char mnemonic)
        {
        __sink.setApproveButtonMnemonic(mnemonic);
        }
    public void setApproveButtonText(String pApproveButtonText)
        {
        __sink.setApproveButtonText(pApproveButtonText);
        }
    public void setApproveButtonToolTipText(String pApproveButtonToolTipText)
        {
        __sink.setApproveButtonToolTipText(pApproveButtonToolTipText);
        }
    public void setCurrentDirectory(java.io.File pCurrentDirectory)
        {
        __sink.setCurrentDirectory(pCurrentDirectory);
        }
    public void setDialogTitle(String pDialogTitle)
        {
        __sink.setDialogTitle(pDialogTitle);
        }
    public void setDialogType(int pDialogType)
        {
        __sink.setDialogType(pDialogType);
        }
    public void setFileHidingEnabled(boolean pFileHidingEnabled)
        {
        __sink.setFileHidingEnabled(pFileHidingEnabled);
        }
    public void setFileSelectionMode(int pFileSelectionMode)
        {
        __sink.setFileSelectionMode(pFileSelectionMode);
        }
    public void setFileSystemView(javax.swing.filechooser.FileSystemView pFileSystemView)
        {
        __sink.setFileSystemView(pFileSystemView);
        }
    public void setMultiSelectionEnabled(boolean pMultiSelectionEnabled)
        {
        __sink.setMultiSelectionEnabled(pMultiSelectionEnabled);
        }
    public void setSelectedFile(java.io.File pSelectedFile)
        {
        __sink.setSelectedFile(pSelectedFile);
        }
    public void setSelectedFiles(java.io.File[] pSelectedFiles)
        {
        __sink.setSelectedFiles(pSelectedFiles);
        }
    //-- javax.swing.JFileChooser integration
    
    // Declared at the super level
    /**
    * Add a child component with the specified name to this component.
    * 
    * @param child  a component to add ti this component as a child
    * @param name  a [unique] name to identify this child. If the name is not
    * specified (null is passed) then a unique child name will be automatically
    * assigned
    * 
    * Note: this method fires onAdd() notification only if the parent (this
    * component) has already been fully constructed.
    * Note2: component containment/aggregation produces children initialization
    * code (see __init()) that is executed while the parent is not flagged as
    * _Constructed yet
    */
    public void _addChild(_package.Component child, String name)
        {
        super._addChild(child, name);
        
        if (child instanceof FileFilter)
            {
            FileFilter filter = (FileFilter) child;
        
            ((_JFileChooser) get_Feed()).addChoosableFileFilter((_FileFilter) child.get_Feed());
            
            if (filter.isActive())
                {
                setFileFilter(filter);
                }
            }
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.FileFilter;
        // import javax.swing.filechooser.FileFilter as _FileFilter;
        // import javax.swing.JFileChooser as _JFileChooser;
        

        }
    
    // Accessor for the property "ApproveButtonMnemonic"
    public char getApproveButtonMnemonic()
        {
        return (char) get_ApproveButtonMnemonic();
        }
    
    // Declared at the super level
    /**
    * This method is called by  Component.Control.Container#addControl() as a
    * last chance to intervene during the construction/integration cycle.
    * A Control would override this if more than one AWT components should be
    * created for one Control or if the component should not be added to the
    * container (see Component...Window or Component...TabbedPanel).
    * This method can also be used to make sure that the parent is of the
    * allowed type (i.e. TabbedPanel is only allowed to be added into the
    * JTabbedPane).
    *  
    * @param  fAdd is true <b>only</b> when this is the frist call (from
    * addControl()) and an override is supposed to tie all the pieces together;
    * false in all other situations
    * 
    * @return AWT component that is added to a container [integratee].
    * 
    * @see Component.Control.Container.Window
    * @see Component.GUI.Control.Container.JComponent
    * @see
    * Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem.JMenu
    * @see Component.GUI.Control.Container.JComponent.JPanel.ButtonGroupPanel
    */
    public java.awt.Component getAWTContainee(boolean fAdd)
        {
        // JFileChooser should not be inserted into a container component
        // it gets activated using "showDialog(owner)" instead
        return null;
        }
    
    // Accessor for the property "FileFilter"
    public _package.component.gUI.FileFilter getFileFilter()
        {
        _FileFilter _filter = ((_JFileChooser) get_Feed()).getFileFilter();;
        
        return (FileFilter) _findFeed(_filter);

        }
    
    // Accessor for the property "LastCurrentDirectory"
    public static java.io.File getLastCurrentDirectory()
        {
        return __s_LastCurrentDirectory;
        }
    
    // Accessor for the property "FileFilter"
    public void setFileFilter(_package.component.gUI.FileFilter pFileFilter)
        {
        _FileFilter _filter = pFileFilter == null ? null :
            (_FileFilter) pFileFilter.get_Feed();;
        
        ((_JFileChooser) get_Feed()).setFileFilter(_filter);

        }
    
    // Accessor for the property "LastCurrentDirectory"
    public static void setLastCurrentDirectory(java.io.File pLastCurrentDirectory)
        {
        __s_LastCurrentDirectory = pLastCurrentDirectory;
        }
    
    /**
    * Pops a file chooser dialog.
    * 
    * @return one of APPROVE_OPTION (0), CANCEL_OPTION (1)
    */
    public int showDialog(_package.component.gUI.control.Container owner)
        {
        // import java.io.File;
        
        File dir = getCurrentDirectory();
        if (dir == null || dir.equals(getFileSystemView().getHomeDirectory()))
            {
            setCurrentDirectory(getLastCurrentDirectory());
            }
        
        int iResult = ((_JFileChooser) get_Feed()).showDialog(
            (java.awt.Component) owner.get_Feed(), null);
        
        if (iResult == APPROVE_OPTION)
            {
            setLastCurrentDirectory(getCurrentDirectory());
            }
        
        return iResult;
        }
    }
