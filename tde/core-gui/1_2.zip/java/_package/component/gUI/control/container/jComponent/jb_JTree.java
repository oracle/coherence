/* Class
*      jb_JTree
*
* automatically generated "Feed" which
* a) extends an external bean:
*      javax.swing.JTree
* b) delegates to the peer component:
*      Component.GUI.Control.Container.JComponent.JTree
*/

package _package.component.gUI.control.container.jComponent;

public class jb_JTree
        extends    javax.swing.JTree
        implements java.awt.dnd.Autoscroll,
                   com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected JTree __peer;
    
    private static JTree __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            JTree peer = (JTree)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // default (JavaBean) constructor
    public jb_JTree()
        {
        this(JTree.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTree(java.util.Hashtable Param_1)
        {
        this(Param_1, JTree.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTree(java.util.Vector Param_1)
        {
        this(Param_1, JTree.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTree(javax.swing.tree.TreeModel Param_1)
        {
        this(Param_1, JTree.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTree(javax.swing.tree.TreeNode Param_1)
        {
        this(Param_1, JTree.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTree(javax.swing.tree.TreeNode Param_1, boolean Param_2)
        {
        this(Param_1, Param_2, JTree.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JTree(Object[] Param_1)
        {
        this(Param_1, JTree.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTree(Class clzPeer)
        {
        this(__createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTree(java.util.Hashtable Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTree(java.util.Vector Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTree(javax.swing.tree.TreeModel Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTree(javax.swing.tree.TreeNode Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTree(javax.swing.tree.TreeNode Param_1, boolean Param_2, Class clzPeer)
        {
        this(Param_1, Param_2, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JTree(Object[] Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTree(JTree peer, boolean fInit)
        {
        super();
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTree(java.util.Hashtable Param_1, JTree peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTree(java.util.Vector Param_1, JTree peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTree(javax.swing.tree.TreeModel Param_1, JTree peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTree(javax.swing.tree.TreeNode Param_1, JTree peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTree(javax.swing.tree.TreeNode Param_1, boolean Param_2, JTree peer, boolean fInit)
        {
        super(Param_1, Param_2);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JTree(Object[] Param_1, JTree peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private JTree __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (JTree) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_JTree(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    public void add(java.awt.Component comp, Object constraints, int index)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._add(comp, constraints, index);
        }
    void super$add(java.awt.Component comp, Object constraints, int index)
        {
        super.add(comp, constraints, index);
        }
    public void remove(java.awt.Component comp)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._remove(comp);
        }
    void super$remove(java.awt.Component comp)
        {
        super.remove(comp);
        }
    public void addFocusListener(java.awt.event.FocusListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addFocusListener(l);
        }
    void super$addFocusListener(java.awt.event.FocusListener l)
        {
        super.addFocusListener(l);
        }
    public void addKeyListener(java.awt.event.KeyListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addKeyListener(l);
        }
    void super$addKeyListener(java.awt.event.KeyListener l)
        {
        super.addKeyListener(l);
        }
    public void addMouseListener(java.awt.event.MouseListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseListener(l);
        }
    void super$addMouseListener(java.awt.event.MouseListener l)
        {
        super.addMouseListener(l);
        }
    public void addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseMotionListener(l);
        }
    void super$addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.addMouseMotionListener(l);
        }
    public void addNotify()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addNotify();
        }
    void super$addNotify()
        {
        super.addNotify();
        }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addPropertyChangeListener(l);
        }
    void super$addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.addPropertyChangeListener(l);
        }
    public void addTreeExpansionListener(javax.swing.event.TreeExpansionListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addTreeExpansionListener(l);
        }
    void super$addTreeExpansionListener(javax.swing.event.TreeExpansionListener l)
        {
        super.addTreeExpansionListener(l);
        }
    public void addTreeSelectionListener(javax.swing.event.TreeSelectionListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addTreeSelectionListener(l);
        }
    void super$addTreeSelectionListener(javax.swing.event.TreeSelectionListener l)
        {
        super.addTreeSelectionListener(l);
        }
    public void addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addVetoableChangeListener(l);
        }
    void super$addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.addVetoableChangeListener(l);
        }
    public void cancelEditing()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.cancelEditing();
        }
    void super$cancelEditing()
        {
        super.cancelEditing();
        }
    public String convertValueToText(Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.convertValueToText(value, selected, expanded, leaf, row, hasFocus);
        }
    String super$convertValueToText(Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus)
        {
        return super.convertValueToText(value, selected, expanded, leaf, row, hasFocus);
        }
    public javax.swing.JToolTip createToolTip()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.createToolTip();
        }
    javax.swing.JToolTip super$createToolTip()
        {
        return super.createToolTip();
        }
    public void doLayout()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.doLayout();
        }
    void super$doLayout()
        {
        super.doLayout();
        }
    public java.awt.Color getBackground()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Background();
        }
    java.awt.Color super$getBackground()
        {
        return super.getBackground();
        }
    public javax.swing.border.Border getBorder()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Border();
        }
    javax.swing.border.Border super$getBorder()
        {
        return super.getBorder();
        }
    public java.awt.Rectangle getBounds()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Bounds();
        }
    java.awt.Rectangle super$getBounds()
        {
        return super.getBounds();
        }
    public java.awt.Cursor getCursor()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Cursor();
        }
    java.awt.Cursor super$getCursor()
        {
        return super.getCursor();
        }
    public java.awt.Font getFont()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Font();
        }
    java.awt.Font super$getFont()
        {
        return super.getFont();
        }
    public java.awt.Color getForeground()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Foreground();
        }
    java.awt.Color super$getForeground()
        {
        return super.getForeground();
        }
    public java.awt.Insets getInsets()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Insets();
        }
    java.awt.Insets super$getInsets()
        {
        return super.getInsets();
        }
    public java.awt.LayoutManager getLayout()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Layout();
        }
    java.awt.LayoutManager super$getLayout()
        {
        return super.getLayout();
        }
    public java.awt.Point getLocation()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Location();
        }
    java.awt.Point super$getLocation()
        {
        return super.getLocation();
        }
    public java.awt.Point getLocationOnScreen()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_LocationOnScreen();
        }
    java.awt.Point super$getLocationOnScreen()
        {
        return super.getLocationOnScreen();
        }
    public java.awt.Dimension getMaximumSize()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MaximumSize();
        }
    java.awt.Dimension super$getMaximumSize()
        {
        return super.getMaximumSize();
        }
    public java.awt.Dimension getMinimumSize()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MinimumSize();
        }
    java.awt.Dimension super$getMinimumSize()
        {
        return super.getMinimumSize();
        }
    public java.awt.Dimension getPreferredSize()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_PreferredSize();
        }
    java.awt.Dimension super$getPreferredSize()
        {
        return super.getPreferredSize();
        }
    public java.awt.Dimension getSize()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Size();
        }
    java.awt.Dimension super$getSize()
        {
        return super.getSize();
        }
    public javax.swing.tree.TreeCellEditor getCellEditor()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getCellEditor();
        }
    javax.swing.tree.TreeCellEditor super$getCellEditor()
        {
        return super.getCellEditor();
        }
    public javax.swing.tree.TreeCellRenderer getCellRenderer()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getCellRenderer();
        }
    javax.swing.tree.TreeCellRenderer super$getCellRenderer()
        {
        return super.getCellRenderer();
        }
    public int getRowCount()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getRowCount();
        }
    int super$getRowCount()
        {
        return super.getRowCount();
        }
    public int getRowHeight()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getRowHeight();
        }
    int super$getRowHeight()
        {
        return super.getRowHeight();
        }
    public int getToggleClickCount()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToggleClickCount();
        }
    int super$getToggleClickCount()
        {
        return super.getToggleClickCount();
        }
    public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent e)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipLocation(e);
        }
    java.awt.Point super$getToolTipLocation(java.awt.event.MouseEvent e)
        {
        return super.getToolTipLocation(e);
        }
    public String getToolTipText()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText();
        }
    String super$getToolTipText()
        {
        return super.getToolTipText();
        }
    public String getToolTipText(java.awt.event.MouseEvent e)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText(e);
        }
    String super$getToolTipText(java.awt.event.MouseEvent e)
        {
        return super.getToolTipText(e);
        }
    public int getVisibleRowCount()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getVisibleRowCount();
        }
    int super$getVisibleRowCount()
        {
        return super.getVisibleRowCount();
        }
    public boolean getAutoscrolls()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isAutoscrolls();
        }
    boolean super$getAutoscrolls()
        {
        return super.getAutoscrolls();
        }
    public boolean isCollapsed(javax.swing.tree.TreePath path)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isCollapsed(path);
        }
    boolean super$isCollapsed(javax.swing.tree.TreePath path)
        {
        return super.isCollapsed(path);
        }
    public boolean isEditable()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isEditable();
        }
    boolean super$isEditable()
        {
        return super.isEditable();
        }
    public boolean isEditing()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isEditing();
        }
    boolean super$isEditing()
        {
        return super.isEditing();
        }
    public boolean isEnabled()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isEnabled();
        }
    boolean super$isEnabled()
        {
        return super.isEnabled();
        }
    public boolean isExpanded(javax.swing.tree.TreePath path)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isExpanded(path);
        }
    boolean super$isExpanded(javax.swing.tree.TreePath path)
        {
        return super.isExpanded(path);
        }
    public boolean isFocusTraversable()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isFocusTraversable();
        }
    boolean super$isFocusTraversable()
        {
        return super.isFocusTraversable();
        }
    public boolean getInvokesStopCellEditing()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isInvokesStopCellEditing();
        }
    boolean super$getInvokesStopCellEditing()
        {
        return super.getInvokesStopCellEditing();
        }
    public boolean isLargeModel()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isLargeModel();
        }
    boolean super$isLargeModel()
        {
        return super.isLargeModel();
        }
    public boolean isOpaque()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isOpaque();
        }
    boolean super$isOpaque()
        {
        return super.isOpaque();
        }
    public boolean isPathEditable(javax.swing.tree.TreePath path)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isPathEditable(path);
        }
    boolean super$isPathEditable(javax.swing.tree.TreePath path)
        {
        return super.isPathEditable(path);
        }
    public boolean isRootVisible()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isRootVisible();
        }
    boolean super$isRootVisible()
        {
        return super.isRootVisible();
        }
    public boolean getScrollsOnExpand()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isScrollsOnExpand();
        }
    boolean super$getScrollsOnExpand()
        {
        return super.getScrollsOnExpand();
        }
    public boolean isShowing()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isShowing();
        }
    boolean super$isShowing()
        {
        return super.isShowing();
        }
    public boolean getShowsRootHandles()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isShowsRootHandles();
        }
    boolean super$getShowsRootHandles()
        {
        return super.getShowsRootHandles();
        }
    public boolean isVisible()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isVisible();
        }
    boolean super$isVisible()
        {
        return super.isVisible();
        }
    public void paint(java.awt.Graphics g)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paint(g);
        }
    void super$paint(java.awt.Graphics g)
        {
        super.paint(g);
        }
    protected void paintBorder(java.awt.Graphics g)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintBorder(g);
        }
    void super$paintBorder(java.awt.Graphics g)
        {
        super.paintBorder(g);
        }
    protected void paintChildren(java.awt.Graphics g)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintChildren(g);
        }
    void super$paintChildren(java.awt.Graphics g)
        {
        super.paintChildren(g);
        }
    protected void paintComponent(java.awt.Graphics g)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintComponent(g);
        }
    void super$paintComponent(java.awt.Graphics g)
        {
        super.paintComponent(g);
        }
    public void removeFocusListener(java.awt.event.FocusListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeFocusListener(l);
        }
    void super$removeFocusListener(java.awt.event.FocusListener l)
        {
        super.removeFocusListener(l);
        }
    public void removeKeyListener(java.awt.event.KeyListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeKeyListener(l);
        }
    void super$removeKeyListener(java.awt.event.KeyListener l)
        {
        super.removeKeyListener(l);
        }
    public void removeMouseListener(java.awt.event.MouseListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseListener(l);
        }
    void super$removeMouseListener(java.awt.event.MouseListener l)
        {
        super.removeMouseListener(l);
        }
    public void removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseMotionListener(l);
        }
    void super$removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.removeMouseMotionListener(l);
        }
    public void removeNotify()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeNotify();
        }
    void super$removeNotify()
        {
        super.removeNotify();
        }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removePropertyChangeListener(l);
        }
    void super$removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.removePropertyChangeListener(l);
        }
    public void removeTreeExpansionListener(javax.swing.event.TreeExpansionListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeTreeExpansionListener(l);
        }
    void super$removeTreeExpansionListener(javax.swing.event.TreeExpansionListener l)
        {
        super.removeTreeExpansionListener(l);
        }
    public void removeTreeSelectionListener(javax.swing.event.TreeSelectionListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeTreeSelectionListener(l);
        }
    void super$removeTreeSelectionListener(javax.swing.event.TreeSelectionListener l)
        {
        super.removeTreeSelectionListener(l);
        }
    public void removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeVetoableChangeListener(l);
        }
    void super$removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.removeVetoableChangeListener(l);
        }
    public void requestFocus()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.requestFocus();
        }
    void super$requestFocus()
        {
        super.requestFocus();
        }
    public void setBackground(java.awt.Color p_Background)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Background(p_Background);
        }
    void super$setBackground(java.awt.Color p_Background)
        {
        super.setBackground(p_Background);
        }
    public void setBorder(javax.swing.border.Border p_Border)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Border(p_Border);
        }
    void super$setBorder(javax.swing.border.Border p_Border)
        {
        super.setBorder(p_Border);
        }
    public void setBounds(java.awt.Rectangle p_Bounds)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Bounds(p_Bounds);
        }
    void super$setBounds(java.awt.Rectangle p_Bounds)
        {
        super.setBounds(p_Bounds);
        }
    public void setCursor(java.awt.Cursor p_Cursor)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Cursor(p_Cursor);
        }
    void super$setCursor(java.awt.Cursor p_Cursor)
        {
        super.setCursor(p_Cursor);
        }
    public void setFont(java.awt.Font p_Font)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Font(p_Font);
        }
    void super$setFont(java.awt.Font p_Font)
        {
        super.setFont(p_Font);
        }
    public void setForeground(java.awt.Color p_Foreground)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Foreground(p_Foreground);
        }
    void super$setForeground(java.awt.Color p_Foreground)
        {
        super.setForeground(p_Foreground);
        }
    public void setLayout(java.awt.LayoutManager p_Layout)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Layout(p_Layout);
        }
    void super$setLayout(java.awt.LayoutManager p_Layout)
        {
        super.setLayout(p_Layout);
        }
    public void setLocation(java.awt.Point p_Location)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Location(p_Location);
        }
    void super$setLocation(java.awt.Point p_Location)
        {
        super.setLocation(p_Location);
        }
    public void setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MaximumSize(p_MaximumSize);
        }
    void super$setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        super.setMaximumSize(p_MaximumSize);
        }
    public void setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MinimumSize(p_MinimumSize);
        }
    void super$setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        super.setMinimumSize(p_MinimumSize);
        }
    public void setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_PreferredSize(p_PreferredSize);
        }
    void super$setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        super.setPreferredSize(p_PreferredSize);
        }
    public void setSize(java.awt.Dimension p_Size)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Size(p_Size);
        }
    void super$setSize(java.awt.Dimension p_Size)
        {
        super.setSize(p_Size);
        }
    public void setAutoscrolls(boolean pAutoscrolls)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setAutoscrolls(pAutoscrolls);
        }
    void super$setAutoscrolls(boolean pAutoscrolls)
        {
        super.setAutoscrolls(pAutoscrolls);
        }
    public void setCellEditor(javax.swing.tree.TreeCellEditor pCellEditor)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setCellEditor(pCellEditor);
        }
    void super$setCellEditor(javax.swing.tree.TreeCellEditor pCellEditor)
        {
        super.setCellEditor(pCellEditor);
        }
    public void setCellRenderer(javax.swing.tree.TreeCellRenderer pCellRenderer)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setCellRenderer(pCellRenderer);
        }
    void super$setCellRenderer(javax.swing.tree.TreeCellRenderer pCellRenderer)
        {
        super.setCellRenderer(pCellRenderer);
        }
    public void setEditable(boolean pEditable)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setEditable(pEditable);
        }
    void super$setEditable(boolean pEditable)
        {
        super.setEditable(pEditable);
        }
    public void setEnabled(boolean pEnabled)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setEnabled(pEnabled);
        }
    void super$setEnabled(boolean pEnabled)
        {
        super.setEnabled(pEnabled);
        }
    public void setInvokesStopCellEditing(boolean pInvokesStopCellEditing)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setInvokesStopCellEditing(pInvokesStopCellEditing);
        }
    void super$setInvokesStopCellEditing(boolean pInvokesStopCellEditing)
        {
        super.setInvokesStopCellEditing(pInvokesStopCellEditing);
        }
    public void setLargeModel(boolean pLargeModel)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setLargeModel(pLargeModel);
        }
    void super$setLargeModel(boolean pLargeModel)
        {
        super.setLargeModel(pLargeModel);
        }
    public void setOpaque(boolean pOpaque)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setOpaque(pOpaque);
        }
    void super$setOpaque(boolean pOpaque)
        {
        super.setOpaque(pOpaque);
        }
    public void setRootVisible(boolean pRootVisible)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setRootVisible(pRootVisible);
        }
    void super$setRootVisible(boolean pRootVisible)
        {
        super.setRootVisible(pRootVisible);
        }
    public void setRowHeight(int pRowHeight)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setRowHeight(pRowHeight);
        }
    void super$setRowHeight(int pRowHeight)
        {
        super.setRowHeight(pRowHeight);
        }
    public void setScrollsOnExpand(boolean pScrollsOnExpand)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setScrollsOnExpand(pScrollsOnExpand);
        }
    void super$setScrollsOnExpand(boolean pScrollsOnExpand)
        {
        super.setScrollsOnExpand(pScrollsOnExpand);
        }
    public void setShowsRootHandles(boolean pShowsRootHandles)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setShowsRootHandles(pShowsRootHandles);
        }
    void super$setShowsRootHandles(boolean pShowsRootHandles)
        {
        super.setShowsRootHandles(pShowsRootHandles);
        }
    public void setToggleClickCount(int pToggleClickCount)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setToggleClickCount(pToggleClickCount);
        }
    void super$setToggleClickCount(int pToggleClickCount)
        {
        super.setToggleClickCount(pToggleClickCount);
        }
    public void setToolTipText(String pToolTipText)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setToolTipText(pToolTipText);
        }
    void super$setToolTipText(String pToolTipText)
        {
        super.setToolTipText(pToolTipText);
        }
    public void setVisible(boolean pVisible)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVisible(pVisible);
        }
    void super$setVisible(boolean pVisible)
        {
        super.setVisible(pVisible);
        }
    public void setVisibleRowCount(int pVisibleRowCount)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVisibleRowCount(pVisibleRowCount);
        }
    void super$setVisibleRowCount(int pVisibleRowCount)
        {
        super.setVisibleRowCount(pVisibleRowCount);
        }
    public void startEditingAtPath(javax.swing.tree.TreePath path)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.startEditingAtPath(path);
        }
    void super$startEditingAtPath(javax.swing.tree.TreePath path)
        {
        super.startEditingAtPath(path);
        }
    public boolean stopEditing()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.stopEditing();
        }
    boolean super$stopEditing()
        {
        return super.stopEditing();
        }
    public void updateUI()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.updateUI();
        }
    void super$updateUI()
        {
        super.updateUI();
        }
    public void validate()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.validate();
        }
    void super$validate()
        {
        super.validate();
        }
    
    // declared interface java.awt.dnd.Autoscroll
    public void autoscroll(java.awt.Point ptCursor)
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.autoscroll(ptCursor);
        }
    public java.awt.Insets getAutoscrollInsets()
        {
        JTree peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getAutoscrollInsets();
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
