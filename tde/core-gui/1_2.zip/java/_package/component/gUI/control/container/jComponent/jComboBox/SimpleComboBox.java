/* Class
*     _package.component.gUI.control.container.jComponent.jComboBox.SimpleComboBox
*/

package _package.component.gUI.control.container.jComponent.jComboBox;

public class SimpleComboBox
        extends    _package.component.gUI.control.container.jComponent.JComboBox
    {
    // Fields declarations
    
    /**
    * Property List
    *
    */
    private String[] __m_List;
    
    // Default constructor
    public SimpleComboBox()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public SimpleComboBox(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setCaseSensitive(true);
            setCollator(null);
            setFocusable(true);
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new SimpleComboBox();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jComboBox/SimpleComboBox".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "List"
    public String[] getList()
        {
        Object[] aoItem = getItems();
        String[] asItem = new String[aoItem.length];
        
        System.arraycopy(aoItem, 0, asItem, 0, aoItem.length);
        
        return asItem;

        }
    
    // Accessor for the property "List"
    public String getList(int pIndex)
        {
        return getList()[pIndex];
        }
    
    // Accessor for the property "List"
    public void setList(String[] pList)
        {
        setItems(pList);
        }
    
    // Accessor for the property "List"
    public void setList(int pIndex, String pList)
        {
        getList()[pIndex] = pList;
        }
    
    /**
    * Update the MRU (most recently used) list of items with the specified
    * item, keeping not more than the specified maximum number.
    */
    public void updateMRUList(String sItem, int cMax)
        {
        int ix = findItem(sItem, true, 0);
        if (ix != 0)
            {
            if (ix > 0)
                {
                removeItemAt(ix);
                }
            else
                {
                for (int i = getItemCount() - 1; i >= cMax; i--)
                    {
                    removeItemAt(i);
                    }
                }
            insertItemAt(sItem, 0);
            setText(sItem);
            }
        }
    }
