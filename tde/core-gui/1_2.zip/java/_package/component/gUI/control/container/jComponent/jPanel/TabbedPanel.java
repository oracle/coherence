/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.TabbedPanel
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.Component;
import _package.component.gUI.control.Container;
import _package.component.gUI.control.container.jComponent.JTabbedPane;
import java.awt.Component; // as _Control
import javax.swing.JPanel; // as _JPanel
import javax.swing.JTabbedPane; // as _JTabbedPane

/**
* TabbedPanel is mostly used as a child of a JTabbedPane. During testing,
* however, it could be used as a plain JPanel.
* 
* @see Component.GUI.Control.Container.JComponent.JTabbedPane#addControl()
*/
public class TabbedPanel
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property _TabbedPane
    *
    */
    
    /**
    * Property DisabledIcon
    *
    */
    private transient _package.component.gUI.image.Icon __m_DisabledIcon;
    
    /**
    * Property Index
    *
    * Specifies an index of this tab (TabbedPanel) in the container
    * (JTabbedPane). This value is used for tabs that are created dynamically
    * at run time and should not be used for designed tabs. Designed tabs use
    * the _Order property to "order" the tabs.
    * 
    * @see JTabbedPane#addControl
    */
    private transient int __m_Index;
    
    /**
    * Property Selected
    *
    * Specifies whether or not this tab (TabbedPanel) is selected.
    */
    private transient boolean __m_Selected;
    
    // Default constructor
    public TabbedPanel()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TabbedPanel(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setIndex(-1);
            setResizable(true);
            setTConstraints("Center");
            setTFont("DefaultProportional-0-10");
            setTLayout("BorderLayout");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new TabbedPanel();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/TabbedPanel".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component;
        // import Component.GUI.Control.Container;
        // import Component.GUI.Control.Container.JComponent.JTabbedPane;
        // import javax.swing.JTabbedPane as _JTabbedPane;
        

        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        if (config.getBoolean(sPrefix + ".Selected") && isEnabled())
            {
            setSelected(true);
            }
        
        super.applyConfig(config, sPrefix);
        }
    
    // Accessor for the property "_TabbedPane"
    /**
    * Returns a visual (swing) JTabbedPane that this component's feed contains
    * in. Returns null if this component or it's parent JTabbedPane have not
    * been constructed yet.
    */
    protected javax.swing.JTabbedPane get_TabbedPane()
        {
        // import javax.swing.JPanel as _JPanel;
        
        // wait until this component's feed is added into its container
        if (((_JPanel) get_Feed()).getParent() != null)
            {
            Component parent = get_Parent();
            return parent instanceof JTabbedPane ? (_JTabbedPane) parent.get_Feed() : null;
            }
        else
            {
            return null;
            }
        }
    
    // Accessor for the property "DisabledIcon"
    public _package.component.gUI.image.Icon getDisabledIcon()
        {
        return __m_DisabledIcon;
        }
    
    // Accessor for the property "Index"
    /**
    * Return the index of this tab in the JTabbedPane parent. If this panel is
    * not plugged in yet, returns a "desired" tab index.
    */
    public int getIndex()
        {
        // import javax.swing.JPanel as _JPanel;
        
        _JTabbedPane _pane = get_TabbedPane();
        
        int index;
        
        if (_pane != null)
            {
            index = _pane.indexOfComponent((_JPanel) get_Feed());
            }
        else
            {
            index = __m_Index;
        
            if (index == -1)
                {
                index = get_Position();
                }
            }
        
        return index;
        }
    
    // Declared at the super level
    public boolean isEnabled()
        {
        _JTabbedPane _pane = get_TabbedPane();
        return _pane != null ? _pane.isEnabledAt(getIndex()) : super.isEnabled();
        }
    
    // Accessor for the property "Selected"
    public boolean isSelected()
        {
        _JTabbedPane _pane = get_TabbedPane();
        return _pane != null ? _pane.getSelectedComponent() == get_Feed() : false;
        }
    
    // Declared at the super level
    /**
    * Convenience method that moves this panel to front view in a way that
    * depends on the type of the parent.
    */
    public void moveToFront()
        {
        super.moveToFront();
        
        setSelected(true);
        }
    
    /**
    * This event is called by the parent JTabbedPane when the tab gets
    * selected.
    * 
    * @see JTabbedPane#onSelectionChanged
    */
    public void onSelected()
        {
        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        config.putBoolean(sPrefix + ".Selected", isSelected());
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "DisabledIcon"
    public void setDisabledIcon(_package.component.gUI.image.Icon pDisabledIcon)
        {
        __m_DisabledIcon = (pDisabledIcon);
        
        _JTabbedPane _pane = get_TabbedPane();
        if (_pane != null)
            {
            _pane.setDisabledIconAt(getIndex(), pDisabledIcon);
            }

        }
    
    // Declared at the super level
    public void setEnabled(boolean pEnabled)
        {
        super.setEnabled(pEnabled);
        
        _JTabbedPane _pane = get_TabbedPane();
        if (_pane != null)
            {
            _pane.setEnabledAt(getIndex(), pEnabled);
            }
        }
    
    // Declared at the super level
    public void setIcon(_package.component.gUI.image.Icon pIcon)
        {
        super.setIcon(pIcon);
        
        _JTabbedPane _pane = get_TabbedPane();
        if (_pane != null)
            {
            _pane.setIconAt(getIndex(), pIcon);
            }

        }
    
    // Accessor for the property "Index"
    public void setIndex(int pIndex)
        {
        __m_Index = (pIndex);
        
        if (is_Constructed())
            {
            Component parent = get_Parent();
            if (parent instanceof JTabbedPane)
                {
                ((JTabbedPane) parent).moveTab(getIndex(), pIndex);
                }
            }
        }
    
    // Accessor for the property "Selected"
    public void setSelected(boolean pSelected)
        {
        // import java.awt.Component as _Control;
        
        __m_Selected = (pSelected);
        
        _JTabbedPane _pane = get_TabbedPane();
        if (_pane != null && pSelected)
            {
            _pane.setSelectedComponent((_Control) get_Feed());
            }
        }
    
    // Declared at the super level
    public void setTitle(String pTitle)
        {
        super.setTitle(pTitle);
        
        _JTabbedPane _pane = get_TabbedPane();
        if (_pane != null)
            {
            _pane.setTitleAt(getIndex(), pTitle);
            }
        }
    
    // Declared at the super level
    public void setToolTipText(String pToolTipText)
        {
        super.setToolTipText(pToolTipText);
        
        _JTabbedPane _pane = get_TabbedPane();
        if (_pane != null)
            {
            _pane.setToolTipTextAt(getIndex(), pToolTipText);
            }
        }
    }
