/* Class
*     _package.component.gUI.control.container.JComponent
*/

package _package.component.gUI.control.container;

import _package.component.gUI.Border;
import _package.component.gUI.Dimension;
import _package.component.gUI.Insets;
import _package.component.gUI.KeyAction;
import _package.component.gUI.Point;
import com.tangosol.run.component.EventDeathException;
import java.awt.Insets; // as _Insets
import java.awt.Point; // as _Point
import java.awt.Rectangle;
import java.awt.Rectangle; // as _Rectangle
import javax.swing.JComponent; // as _JComponent
import javax.swing.JScrollPane; // as _JScrollPane
import javax.swing.ToolTipManager;

/*
* Integrates
*     javax.swing.JComponent
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JComponent
        extends    _package.component.gUI.control.Container
        implements java.awt.dnd.Autoscroll,
                   javax.swing.ScrollPaneConstants,
                   javax.swing.SwingConstants,
                   java.beans.VetoableChangeListener
    {
    // Fields declarations
    
    /**
    * Property _Border
    *
    */
    private transient javax.swing.border.Border __m__Border;
    
    /**
    * Property _MaximumSize
    *
    */
    private transient java.awt.Dimension __m__MaximumSize;
    
    /**
    * Property _MinimumSize
    *
    */
    private transient java.awt.Dimension __m__MinimumSize;
    
    /**
    * Property _PreferredSize
    *
    */
    private transient java.awt.Dimension __m__PreferredSize;
    
    /**
    * Property _ScrollPane
    *
    */
    private javax.swing.JScrollPane __m__ScrollPane;
    
    /**
    * Property _ToolTip
    *
    * Specifies the cached JToolTip object.
    * 
    * @see #createToolTip
    */
    private transient javax.swing.JToolTip __m__ToolTip;
    
    /**
    * Property Autoscrolls
    *
    * Specifies whether this component automatically scrolls its contents when
    * dragged.
    */
    private transient boolean __m_Autoscrolls;
    
    /**
    * Property Border
    *
    */
    private transient _package.component.gUI.Border __m_Border;
    
    /**
    * Property HorizontalScrollBarPolicy
    *
    * Used to set the horizontal scroll bar policy so that  horizontal
    * scrollbars are displayed only when needed.
    *     HORIZONTAL_SCROLLBAR_AS_NEEDED = 30;
    * 
    * Used to set the  horizontal scroll bar policy so that  horizontal
    * scrollbars are never displayed.
    *      HORIZONTAL_SCROLLBAR_NEVER = 31;
    * 
    * Used to set the  horizontal scroll bar policy so that  horizontal
    * scrollbars are always displayed.
    *      HORIZONTAL_SCROLLBAR_ALWAYS = 32;
    */
    private int __m_HorizontalScrollBarPolicy;
    
    /**
    * Property MaximumSize
    *
    */
    private transient _package.component.gUI.Dimension __m_MaximumSize;
    
    /**
    * Property MinimumSize
    *
    */
    private transient _package.component.gUI.Dimension __m_MinimumSize;
    
    /**
    * Property Opaque
    *
    * Specifies whether this component is completely opaque.<p>
    * An opaque component paints every pixel within its rectangular region. A
    * non-opaque component paints only some of its pixels, allowing the pixels
    * underneath it to "show through". A component that does not fully paint
    * its pixels therefore provides a degree of transparency.
    */
    private transient boolean __m_Opaque;
    
    /**
    * Property PreferredSize
    *
    */
    private transient _package.component.gUI.Dimension __m_PreferredSize;
    
    /**
    * Property Scrollable
    *
    * Specifies whether this component is scrollable.
    * 
    * @see #getAWTContainee()
    */
    private boolean __m_Scrollable;
    
    /**
    * Property TBorder
    *
    */
    
    /**
    * Property ToolTipText
    *
    * A tooltip string.
    */
    private transient String __m_ToolTipText;
    
    /**
    * Property VerticalScrollBarPolicy
    *
    * Used to set the vertical scroll bar policy so that vertical scrollbars
    * are displayed only when needed.
    *     VERTICAL_SCROLLBAR_AS_NEEDED = 20;
    * 
    * Used to set the vertical scroll bar policy so that vertical scrollbars
    * are never displayed.
    *     VERTICAL_SCROLLBAR_NEVER = 21;
    * 
    * Used to set the vertical scroll bar policy so that vertical scrollbars
    * are always displayed.
    *     VERTICAL_SCROLLBAR_ALWAYS = 22
    */
    private int __m_VerticalScrollBarPolicy;
    
    /**
    * Property ViewPosition
    *
    * Specifies the view coordinates that appear in the upper left hand corner
    * of this component's scrollpane viewport, 0,0 if the component is not
    * scrollable.
    */
    private transient _package.component.gUI.Point __m_ViewPosition;
    
    /**
    * Property ViewSize
    *
    * Specifies the size of this component's scrollpane viewport, or size of
    * the component itself if the component is not scrollable.
    */
    private transient _package.component.gUI.Dimension __m_ViewSize;
    
    // fields used by the integration model:
    private sink_JComponent __sink;
    private javax.swing.JComponent __feed;
    
    // Default constructor
    public JComponent()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JComponent(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JComponent.__tloPeer.setObject(this);
            new jb_JComponent(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        super.__initEvents();
        
        addVetoableChangeListener(this);
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new JComponent();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/JComponent".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ VetoableChangeListener dispatcher
    private com.tangosol.util.Listeners __VetoableChangeListeners;
    private void addVetoableChangeListener$Router(java.beans.VetoableChangeListener l)
        {
        __sink.addVetoableChangeListener(l);
        }
    public void addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __VetoableChangeListeners;
        if (_listeners == null)
            {
            __VetoableChangeListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addVetoableChangeListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeVetoableChangeListener$Router(java.beans.VetoableChangeListener l)
        {
        __sink.removeVetoableChangeListener(l);
        }
    public void removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        com.tangosol.util.Listeners _listeners = __VetoableChangeListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeVetoableChangeListener$Router(this);
            }
        }
    private void vetoableChange$Dispatch(java.beans.PropertyChangeEvent e)
            throws java.beans.PropertyVetoException
        {
        java.util.EventListener[] targets = __VetoableChangeListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.beans.VetoableChangeListener target = (java.beans.VetoableChangeListener) targets[i];
            if (target != this)
                {
                target.vetoableChange(e);
                }
            }
        }
    public void vetoableChange(java.beans.PropertyChangeEvent e)
            throws java.beans.PropertyVetoException
        {
        // import com.tangosol.run.component.EventDeathException;
        
        try
            {
            if (is_Constructed())
                {
                onVetoableChange(e.getPropertyName(), e.getNewValue(), e.getOldValue());
                }
            }
        catch (EventDeathException x)
            {
            return;
            }
        
        vetoableChange$Dispatch(e);
        }
    //-- VetoableChangeListener dispatcher
    
    //++ javax.swing.JComponent integration
    // Access optimization
    /**
    * Setter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JComponent) pSink;
        super.set_Sink(pSink);
        }
    /**
    * Setter for property _Feed.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JComponent) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public void removeNotify()
        {
        // import javax.swing.ToolTipManager;
        
        if (getToolTipText() != null || get_ToolTip() != null)
            {
            // this should done by the javax.swing.JComponent
            ToolTipManager.sharedInstance().unregisterComponent((_JComponent) get_Feed());
            }
        super.removeNotify();
        }
    /**
    * Setter for property Visible.<p>
    */
    public void setVisible(boolean pVisible)
        {
        super.setVisible(pVisible);
        
        if (is_Constructed() && isScrollable())
            {
            _JScrollPane _pane = get_ScrollPane();
            if (_pane != null)
                {
                _pane.setVisible(pVisible);
                }
            }
        }
    private javax.swing.JToolTip createToolTip$Router()
        {
        return __sink.createToolTip();
        }
    /**
    * Returns the instance of JToolTip that should be used to display the
    * tooltip. Components typically would not override this method, but it can
    * be used to cause different tool tips to be displayed differently.
    */
    public javax.swing.JToolTip createToolTip()
        {
        javax.swing.JToolTip _tip = createToolTip$Router();
        set_ToolTip(_tip);
        
        _tip.setFont(get_Font());
        
        return _tip;
        }
    /**
    * Getter for property Autoscrolls.<p>
    * Specifies whether this component automatically scrolls its contents when
    * dragged.
    */
    public boolean isAutoscrolls()
        {
        return __sink.getAutoscrolls();
        }
    /**
    * Getter for property _Border.<p>
    */
    public javax.swing.border.Border get_Border()
        {
        return __sink.getBorder();
        }
    /**
    * Getter for property _MaximumSize.<p>
    */
    public java.awt.Dimension get_MaximumSize()
        {
        return __sink.getMaximumSize();
        }
    /**
    * Getter for property _MinimumSize.<p>
    */
    public java.awt.Dimension get_MinimumSize()
        {
        return __sink.getMinimumSize();
        }
    /**
    * Getter for property _PreferredSize.<p>
    */
    public java.awt.Dimension get_PreferredSize()
        {
        return __sink.getPreferredSize();
        }
    /**
    * Return a location for the ToolTip in the receiving component coordinate
    * system. If null is returned, Swing will choose a location. The default
    * implementation returns null.
    */
    public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent e)
        {
        return __sink.getToolTipLocation(e);
        }
    /**
    * Getter for property ToolTipText.<p>
    * A tooltip string.
    */
    public String getToolTipText()
        {
        return __sink.getToolTipText();
        }
    /**
    * Returns the string to be used as the tooltip for <i>event</i>.  By
    * default this returns a value of ToolTipText property.  If a component
    * provides more extensive API to support differing tooltips at different
    * locations, this method should be overridden.
    */
    public String getToolTipText(java.awt.event.MouseEvent e)
        {
        return __sink.getToolTipText(e);
        }
    /**
    * Getter for property Opaque.<p>
    * Specifies whether this component is completely opaque.<p>
    * An opaque component paints every pixel within its rectangular region. A
    * non-opaque component paints only some of its pixels, allowing the pixels
    * underneath it to "show through". A component that does not fully paint
    * its pixels therefore provides a degree of transparency.
    */
    public boolean isOpaque()
        {
        return __sink.isOpaque();
        }
    /**
    * Paint the component's border.
    */
    public void paintBorder(java.awt.Graphics g)
        {
        __sink.paintBorder(g);
        }
    /**
    * Paint this component's children.
    */
    public void paintChildren(java.awt.Graphics g)
        {
        __sink.paintChildren(g);
        }
    /**
    * Paint this component. Default implementation calls the paint method of
    * the UI delegate.
    */
    public void paintComponent(java.awt.Graphics g)
        {
        __sink.paintComponent(g);
        }
    /**
    * Setter for property Autoscrolls.<p>
    * Specifies whether this component automatically scrolls its contents when
    * dragged.
    */
    public void setAutoscrolls(boolean pAutoscrolls)
        {
        __sink.setAutoscrolls(pAutoscrolls);
        }
    /**
    * Setter for property _Border.<p>
    */
    public void set_Border(javax.swing.border.Border p_Border)
        {
        __sink.setBorder(p_Border);
        }
    /**
    * Setter for property _MaximumSize.<p>
    */
    public void set_MaximumSize(java.awt.Dimension p_MaximumSize)
        {
        __sink.setMaximumSize(p_MaximumSize);
        }
    /**
    * Setter for property _MinimumSize.<p>
    */
    public void set_MinimumSize(java.awt.Dimension p_MinimumSize)
        {
        __sink.setMinimumSize(p_MinimumSize);
        }
    /**
    * Setter for property Opaque.<p>
    * Specifies whether this component is completely opaque.<p>
    * An opaque component paints every pixel within its rectangular region. A
    * non-opaque component paints only some of its pixels, allowing the pixels
    * underneath it to "show through". A component that does not fully paint
    * its pixels therefore provides a degree of transparency.
    */
    public void setOpaque(boolean pOpaque)
        {
        __sink.setOpaque(pOpaque);
        }
    /**
    * Setter for property _PreferredSize.<p>
    */
    public void set_PreferredSize(java.awt.Dimension p_PreferredSize)
        {
        __sink.setPreferredSize(p_PreferredSize);
        }
    /**
    * Setter for property ToolTipText.<p>
    * A tooltip string.
    */
    public void setToolTipText(String pToolTipText)
        {
        __sink.setToolTipText(pToolTipText);
        }
    public void updateUI()
        {
        __sink.updateUI();
        }
    //-- javax.swing.JComponent integration
    
    // Declared at the super level
    /**
    * Add a child component with the specified name to this component.
    * 
    * @param child  a component to add ti this component as a child
    * @param name  a [unique] name to identify this child. If the name is not
    * specified (null is passed) then a unique child name will be automatically
    * assigned
    * 
    * Note: this method fires onAdd() notification only if the parent (this
    * component) has already been fully constructed.
    * Note2: component containment/aggregation produces children initialization
    * code (see __init()) that is executed while the parent is not flagged as
    * _Constructed yet
    */
    public void _addChild(_package.Component child, String name)
        {
        super._addChild(child, name);
        
        if (child instanceof KeyAction)
            {
            ((KeyAction) child).bind();
            }
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Border;
        // import Component.GUI.Dimension;
        // import Component.GUI.KeyAction;
        // import Component.GUI.Point;
        // import Component.GUI.Rectangle;
        // import javax.swing.JComponent as _JComponent;
        // import javax.swing.JScrollPane as _JScrollPane;

        }
    
    // Declared at the super level
    /**
    * Remove the specified child component.
    */
    public void _removeChild(_package.Component child)
        {
        super._removeChild(child);
        
        if (child instanceof KeyAction)
            {
            ((KeyAction) child).unbind();
            }
        }
    
    // From interface: java.awt.dnd.Autoscroll
    /**
    * Notify the Component to autoscroll
    * 
    * @param ptCursor A <code>Point</code> indicating the location of the
    * cursor that triggered this operation.
    * 
    * Note: for component to become "autoscrollable" all that has to be done is
    * marking the feed as implementing the Autoscroll interface by placing the
    * "interface=java.awt.dnd.Autoscroll" attribute into the Misc property of
    * the integration map.
    */
    public void autoscroll(java.awt.Point ptCursor)
        {
        // import java.awt.Point     as _Point;
        // import java.awt.Rectangle as _Rectangle;
        
        _JScrollPane _scrollPane = get_ScrollPane();
        
        _Rectangle rectFull = get_Bounds();
        _Rectangle rectView = _scrollPane.getViewportBorderBounds();
        _Point     ptView   = _scrollPane.getViewport().getViewPosition();
        
        int iSize  = 10; // getAutoscrollRegionSize()
        int dX     = 0;
        int dY     = 0;
        
        if (ptCursor.x < ptView.x + iSize)
            {
            if (rectFull.x < 0)
                {
                dX = -iSize;
                }
            }
        else if (
            ptCursor.x > ptView.x + rectView.width - iSize)
            {
            if (rectFull.width > ptView.x + rectView.width)
                {
                dX = +iSize;
                }
            }
        
        if (ptCursor.y < ptView.y + iSize)
            {
            if (rectFull.y < 0)
                {
                dY = -iSize;
                }
            }
        else if (
            ptCursor.y > ptView.y + rectView.height - iSize)
            {
            if (rectFull.height > ptView.y + rectView.height)
                {
                dY = +iSize;
                }
            }
        
        if (dX != 0 || dY != 0)
            {
            _scrollPane.getViewport().setViewPosition(
                new _Point(ptView.x + dX, ptView.y + dY));
            }
        }
    
    /**
    * Convert a point from a screen coordinates to a component's coordinate
    * system.
    * 
    * @param point  a Point object ([that is being] converted to the new
    * coordinate system).
    */
    public void convertPointFromScreen(_package.component.gUI.Point point)
        {
        javax.swing.SwingUtilities.
            convertPointFromScreen(point.get_Point(), (_JComponent) get_Feed());
        }
    
    /**
    * Convert a point from a component's coordinate system to screen
    * coordinates.
    * 
    * @param point  a Point object ([that is being] converted to the new
    * coordinate system)
    */
    public void convertPointToScreen(_package.component.gUI.Point point)
        {
        javax.swing.SwingUtilities.
            convertPointToScreen(point.get_Point(), (_JComponent) get_Feed());
        }
    
    // Accessor for the property "_ScrollPane"
    /**
    * Getter for property _ScrollPane.<p>
    */
    public javax.swing.JScrollPane get_ScrollPane()
        {
        _JScrollPane _scrollPane = __m__ScrollPane;
        if (_scrollPane == null)
            {
            _scrollPane = new _JScrollPane();
            set_ScrollPane(_scrollPane);
            }
        return _scrollPane;
        }
    
    // Accessor for the property "_ToolTip"
    /**
    * Getter for property _ToolTip.<p>
    * Specifies the cached JToolTip object.
    * 
    * @see #createToolTip
    */
    public javax.swing.JToolTip get_ToolTip()
        {
        return __m__ToolTip;
        }
    
    // From interface: java.awt.dnd.Autoscroll
    /**
    * This method returns the <code>Insets</code> describing  the autoscrolling
    * region or border relative to the geometry of the implementing
    * Component.<p>
    * This value is read once by the <code>DropTarget</code> upon entry of the
    * drag cursor into the associated Component.
    */
    public java.awt.Insets getAutoscrollInsets()
        {
        // import java.awt.Insets    as _Insets;
        // import java.awt.Point     as _Point;
        // import java.awt.Rectangle as _Rectangle;
        
        _Insets _insets;
        
        if (isScrollable())
            {
            _JScrollPane _scrollPane = get_ScrollPane();
        
            _insets = (_Insets) _scrollPane.getInsets().clone();
        
            _Rectangle rectFull = get_Bounds();
            _Rectangle rectView = _scrollPane.getViewportBorderBounds();
            _Point     ptView   = _scrollPane.getViewport().getViewPosition();
        
            int iSize = 10; // getAutoscrollRegionSize()
            
            _insets.top    += iSize + (rectView.y      - rectFull.y);
            _insets.left   += iSize + (rectView.x      - rectFull.x);
            _insets.bottom += iSize + (rectFull.height - rectView.height - ptView.y);
            _insets.right  += iSize + (rectFull.width  - rectView.width  - ptView.x);
            }
        else
            {
            _insets = (_Insets) get_Insets();
            }
        
        return _insets;

        }
    
    // Declared at the super level
    /**
    * This method is called by  Component.Control.Container#addControl() as a
    * last chance to intervene during the construction/integration cycle.
    * A Control would override this if more than one AWT components should be
    * created for one Control or if the component should not be added to the
    * container (see Component...Window or Component...TabbedPanel).
    * This method can also be used to make sure that the parent is of the
    * allowed type (i.e. TabbedPanel is only allowed to be added into the
    * JTabbedPane).
    *  
    * @param  fAdd is true <b>only</b> when this is the frist call (from
    * addControl()) and an override is supposed to tie all the pieces together;
    * false in all other situations
    * 
    * @return AWT component that is added to a container [integratee].
    * 
    * @see Component.Control.Container.Window
    * @see Component.GUI.Control.Container.JComponent
    * @see
    * Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem.JMenu
    * @see Component.GUI.Control.Container.JComponent.JPanel.ButtonGroupPanel
    */
    public java.awt.Component getAWTContainee(boolean fAdd)
        {
        if (isScrollable())
            {
            _JScrollPane _scrollPane = get_ScrollPane();
            if (fAdd)
                {
                _scrollPane.setViewportView(super.getAWTContainee(fAdd));
                _scrollPane.setVisible(isVisible()); // see #setVisible()
                }
            return _scrollPane;
            }
        else
            {
            return super.getAWTContainee(fAdd);
            }
        }
    
    // Accessor for the property "Border"
    /**
    * Getter for property Border.<p>
    */
    public _package.component.gUI.Border getBorder()
        {
        Border border = __m_Border;
        if (border == null)
            {
            javax.swing.border.Border _border = get_Border();
            if (_border != null)
                {
                border = new Border();
                border.set_Border(_border);
                setBorder(border);
                }
            }
        return border;
        }
    
    // Declared at the super level
    /**
    * Getter for property Bounds.<p>
    */
    public _package.component.gUI.Rectangle getBounds()
        {
        if (isScrollable())
            {
            // we use "getViewportBorderBounds" instead of "getBounds" to account for
            // [optional] headers and scrollbars
            // return Rectangle.instantiate(get_ScrollPane().getBounds());
            return Rectangle.instantiate(get_ScrollPane().getViewportBorderBounds());
            }
        else
            {
            return super.getBounds();
            }
        }
    
    // Accessor for the property "HorizontalScrollBarPolicy"
    /**
    * Getter for property HorizontalScrollBarPolicy.<p>
    * Used to set the horizontal scroll bar policy so that  horizontal
    * scrollbars are displayed only when needed.
    *     HORIZONTAL_SCROLLBAR_AS_NEEDED = 30;
    * 
    * Used to set the  horizontal scroll bar policy so that  horizontal
    * scrollbars are never displayed.
    *      HORIZONTAL_SCROLLBAR_NEVER = 31;
    * 
    * Used to set the  horizontal scroll bar policy so that  horizontal
    * scrollbars are always displayed.
    *      HORIZONTAL_SCROLLBAR_ALWAYS = 32;
    */
    public int getHorizontalScrollBarPolicy()
        {
        return isScrollable() ?
            get_ScrollPane().getHorizontalScrollBarPolicy() :
            __m_HorizontalScrollBarPolicy;
        }
    
    // Declared at the super level
    /**
    * Getter for property Insets.<p>
    */
    public _package.component.gUI.Insets getInsets()
        {
        // import Component.GUI.Insets;
        
        return Insets.instantiate(isScrollable() ?
            get_ScrollPane().getInsets() : get_Insets());
        }
    
    // Declared at the super level
    /**
    * Gets the location of this component in the form of a point specifying the
    * component's top-left corner in the screen's coordinate space.
    * 
    * @see JComponent#convertPointToScreen
    */
    public _package.component.gUI.Point getLocationOnScreen()
        {
        Point pt = super.getLocationOnScreen();
        
        if (isScrollable())
            {
            // adjust to the viewport (should this be considered as a JDK bug?)
            pt.add(getViewPosition());
            }
        return pt;
        }
    
    // Accessor for the property "MaximumSize"
    /**
    * Getter for property MaximumSize.<p>
    */
    public _package.component.gUI.Dimension getMaximumSize()
        {
        return Dimension.instantiate(get_MaximumSize());

        }
    
    // Accessor for the property "MinimumSize"
    /**
    * Getter for property MinimumSize.<p>
    */
    public _package.component.gUI.Dimension getMinimumSize()
        {
        return Dimension.instantiate(get_MinimumSize());
        }
    
    // Accessor for the property "PreferredSize"
    /**
    * Getter for property PreferredSize.<p>
    */
    public _package.component.gUI.Dimension getPreferredSize()
        {
        return Dimension.instantiate(get_PreferredSize());
        }
    
    // Declared at the super level
    /**
    * Getter for property Size.<p>
    */
    public _package.component.gUI.Dimension getSize()
        {
        if (isScrollable())
            {
            // "getBounds" uses "getViewportBorderBounds" instead of "getBounds"
            // to account for [optional] headers and scrollbars
            return getBounds().getSize();
            }
        else
            {
            return super.getSize();
            }
        }
    
    // Accessor for the property "VerticalScrollBarPolicy"
    /**
    * Getter for property VerticalScrollBarPolicy.<p>
    * Used to set the vertical scroll bar policy so that vertical scrollbars
    * are displayed only when needed.
    *     VERTICAL_SCROLLBAR_AS_NEEDED = 20;
    * 
    * Used to set the vertical scroll bar policy so that vertical scrollbars
    * are never displayed.
    *     VERTICAL_SCROLLBAR_NEVER = 21;
    * 
    * Used to set the vertical scroll bar policy so that vertical scrollbars
    * are always displayed.
    *     VERTICAL_SCROLLBAR_ALWAYS = 22
    */
    public int getVerticalScrollBarPolicy()
        {
        return isScrollable() ?
            get_ScrollPane().getVerticalScrollBarPolicy() :
            __m_VerticalScrollBarPolicy;

        }
    
    // Accessor for the property "ViewPosition"
    /**
    * Getter for property ViewPosition.<p>
    * Specifies the view coordinates that appear in the upper left hand corner
    * of this component's scrollpane viewport, 0,0 if the component is not
    * scrollable.
    */
    public _package.component.gUI.Point getViewPosition()
        {
        Point pt = new Point();
        if (isScrollable())
            {
            pt.set_Point(get_ScrollPane().getViewport().getViewPosition());
            }
        return pt;
        }
    
    // Accessor for the property "ViewSize"
    /**
    * Getter for property ViewSize.<p>
    * Specifies the size of this component's scrollpane viewport, or size of
    * the component itself if the component is not scrollable.
    */
    public _package.component.gUI.Dimension getViewSize()
        {
        Dimension dim = getSize();
        if (isScrollable())
            {
            dim.set_Dimension(get_ScrollPane().getViewport().getViewSize());
            }
        return dim;
        }
    
    // Accessor for the property "Scrollable"
    /**
    * Getter for property Scrollable.<p>
    * Specifies whether this component is scrollable.
    * 
    * @see #getAWTContainee()
    */
    public boolean isScrollable()
        {
        return __m_Scrollable;
        }
    
    // Declared at the super level
    public void onMouseDragged(_package.component.gUI.Point point, int modifiers)
        {
        // import java.awt.Rectangle;
        
        super.onMouseDragged(point, modifiers);
        
        if (isAutoscrolls())
            {
            // see bugParade: BugId 4201314
            ((_JComponent) get_Feed()).scrollRectToVisible(
                new Rectangle(point.getX(), point.getY(), 1, 1));
            }
        }
    
    /**
    * Method notification specifying that a property with the specified name is
    * about to change the value.
    */
    public void onVetoableChange(String sName, Object oNewValue, Object oOldValue)
            throws java.beans.PropertyVetoException
        {
        }
    
    /**
    * Paint this component now.
    * 
    * TODO: This method will migrate to java.awt.Component in the next major
    * JDK release at which point we should move it up as well...
    */
    public void paintImmediately()
        {
        _JComponent _comp = (_JComponent) getAWTContainee(false);
        _comp.paintImmediately(_comp.getBounds());
        }
    
    /**
    * Request the focus for the component that should have the focus by
    * default. The default implementation will recursively request the focus on
    * the first component that is focus-traversable.
    * 
    * @return false if the focus has not been set, otherwise return true
    * 
    * @see Control#requestFocus
    */
    public boolean requestDefaultFocus()
        {
        // TODO: should we integrate this?
        
        // TODO: this is a workaround for DnD bug -- remove when fixed
        // (see Control#requestFocus)
        if (isDnDDroppingActive())
            {
            // _trace("Cannot set default focus to " + get_Name() + " due to the DnD bug");
            return false;
            }
        else
            {
            return ((_JComponent) get_Feed()).requestDefaultFocus();
            }

        }
    
    /**
    * Support for deferred automatic layout.  <p> 
    * Calls invalidate() and then adds this components validateRoot  to a list
    * of components that need to be validated.  Validation will occur after all
    * currently pending events have been dispatched. In other words after this
    * method is called,  the first validateRoot (if any) found when walking up
    * the containment hierarchy of this  component will be validated. By
    * default, JRootPane, JScrollPane, and JTextField return true  from
    * isValidateRoot(). <p>
    * This method will automatically be called on this component  when a
    * property value changes such that size, location, or  internal layout of
    * this component has been affected.  This automatic updating differs from
    * the AWT because programs generally no longer need to invoke validate() to
    * get the contents of the GUI to update. 
    */
    public void revalidate()
        {
        // TO DO: do we want to integrate this method and/or isValidateRoot()?
        ((_JComponent) get_Feed()).revalidate();
        }
    
    // Accessor for the property "_ScrollPane"
    /**
    * Setter for property _ScrollPane.<p>
    */
    public void set_ScrollPane(javax.swing.JScrollPane p_ScrollPane)
        {
        __m__ScrollPane = p_ScrollPane;
        }
    
    // Accessor for the property "_ToolTip"
    /**
    * Setter for property _ToolTip.<p>
    * Specifies the cached JToolTip object.
    * 
    * @see #createToolTip
    */
    public void set_ToolTip(javax.swing.JToolTip p_ToolTip)
        {
        __m__ToolTip = p_ToolTip;
        }
    
    // Accessor for the property "Border"
    /**
    * Setter for property Border.<p>
    */
    public void setBorder(_package.component.gUI.Border pBorder)
        {
        set_Border(pBorder != null ? pBorder.get_Border() : null);
        __m_Border = (pBorder);
        }
    
    // Declared at the super level
    /**
    * Setter for property Bounds.<p>
    */
    public void setBounds(_package.component.gUI.Rectangle pBounds)
        {
        if (isScrollable())
            {
            get_ScrollPane().setBounds(pBounds.get_Rectangle());
            }
        else
            {
            super.setBounds(pBounds);
            }
        
        if (!is_Constructed())
            {
            // LayoutManager uses PreferredSize to lay things out
            // TODO: remove after the composite properties are implemented
            //       and users can design the PreferredSize
            setPreferredSize(pBounds.getSize());
            }
        }
    
    // Accessor for the property "HorizontalScrollBarPolicy"
    /**
    * Setter for property HorizontalScrollBarPolicy.<p>
    * Used to set the horizontal scroll bar policy so that  horizontal
    * scrollbars are displayed only when needed.
    *     HORIZONTAL_SCROLLBAR_AS_NEEDED = 30;
    * 
    * Used to set the  horizontal scroll bar policy so that  horizontal
    * scrollbars are never displayed.
    *      HORIZONTAL_SCROLLBAR_NEVER = 31;
    * 
    * Used to set the  horizontal scroll bar policy so that  horizontal
    * scrollbars are always displayed.
    *      HORIZONTAL_SCROLLBAR_ALWAYS = 32;
    */
    public void setHorizontalScrollBarPolicy(int pHorizontalScrollBarPolicy)
        {
        if (isScrollable())
            {
            get_ScrollPane().setHorizontalScrollBarPolicy(pHorizontalScrollBarPolicy);
            }
        else
            {
            __m_HorizontalScrollBarPolicy = (pHorizontalScrollBarPolicy);
            }

        }
    
    // Accessor for the property "MaximumSize"
    /**
    * Setter for property MaximumSize.<p>
    */
    public void setMaximumSize(_package.component.gUI.Dimension pMaximumSize)
        {
        java.awt.Dimension _size =
            pMaximumSize == null ? null : pMaximumSize.get_Dimension();
        if (isScrollable())
            {
            get_ScrollPane().setMaximumSize(_size);
            }
        else
            {
            set_MaximumSize(_size);
            }
        }
    
    // Accessor for the property "MinimumSize"
    /**
    * Setter for property MinimumSize.<p>
    */
    public void setMinimumSize(_package.component.gUI.Dimension pMinimumSize)
        {
        java.awt.Dimension _size =
            pMinimumSize == null ? null : pMinimumSize.get_Dimension();
        if (isScrollable())
            {
            get_ScrollPane().setMinimumSize(_size);
            }
        else
            {
            set_MinimumSize(_size);
            }
        }
    
    // Accessor for the property "PreferredSize"
    /**
    * Setter for property PreferredSize.<p>
    */
    public void setPreferredSize(_package.component.gUI.Dimension pPreferredSize)
        {
        if (isScrollable())
            {
            get_ScrollPane().setPreferredSize(pPreferredSize.get_Dimension());
            }
        else
            {
            set_PreferredSize(pPreferredSize.get_Dimension());
            }

        }
    
    // Accessor for the property "Scrollable"
    /**
    * Setter for property Scrollable.<p>
    * Specifies whether this component is scrollable.
    * 
    * @see #getAWTContainee()
    */
    public void setScrollable(boolean pScrollable)
        {
        if (is_Constructed())
            {
            // it has to be set BEFORE the call to getAWTContainer() ...
            throw new UnsupportedOperationException(get_Name() +
                "Scrollable property is not settable at run time");
            }
        
        if (pScrollable == isScrollable())
            {
            return;
            }
        
        // transfer the policy values as the Scrollable property changes
        
        int hsbp = getHorizontalScrollBarPolicy();
        int vsbp = getVerticalScrollBarPolicy();
        
        __m_Scrollable = (pScrollable);
        
        if (hsbp != 0)
            {
            setHorizontalScrollBarPolicy(hsbp);
            }
        if (vsbp != 0)
            {
            setVerticalScrollBarPolicy(vsbp);
            }
        }
    
    // Declared at the super level
    /**
    * Setter for property Size.<p>
    */
    public void setSize(_package.component.gUI.Dimension pSize)
        {
        if (isScrollable())
            {
            get_ScrollPane().setSize(pSize.get_Dimension());
            }
        else
            {
            super.setSize(pSize);
            }
        }
    
    // Accessor for the property "TBorder"
    /**
    * Setter for property TBorder.<p>
    */
    public void setTBorder(String pTBorder)
        {
        setBorder(pTBorder == null ? null :
            (Border) _newInstance("Component.GUI.Border." + pTBorder));
        }
    
    // Accessor for the property "VerticalScrollBarPolicy"
    /**
    * Setter for property VerticalScrollBarPolicy.<p>
    * Used to set the vertical scroll bar policy so that vertical scrollbars
    * are displayed only when needed.
    *     VERTICAL_SCROLLBAR_AS_NEEDED = 20;
    * 
    * Used to set the vertical scroll bar policy so that vertical scrollbars
    * are never displayed.
    *     VERTICAL_SCROLLBAR_NEVER = 21;
    * 
    * Used to set the vertical scroll bar policy so that vertical scrollbars
    * are always displayed.
    *     VERTICAL_SCROLLBAR_ALWAYS = 22
    */
    public void setVerticalScrollBarPolicy(int pVerticalScrollBarPolicy)
        {
        if (isScrollable())
            {
            get_ScrollPane().setVerticalScrollBarPolicy(pVerticalScrollBarPolicy);
            }
        else
            {
            __m_VerticalScrollBarPolicy = (pVerticalScrollBarPolicy);
            }

        }
    
    // Accessor for the property "ViewPosition"
    /**
    * Setter for property ViewPosition.<p>
    * Specifies the view coordinates that appear in the upper left hand corner
    * of this component's scrollpane viewport, 0,0 if the component is not
    * scrollable.
    */
    public void setViewPosition(_package.component.gUI.Point pViewPosition)
        {
        if (isScrollable())
            {
            get_ScrollPane().getViewport().
                setViewPosition(pViewPosition.get_Point());
            }
        }
    
    // Accessor for the property "ViewSize"
    /**
    * Setter for property ViewSize.<p>
    * Specifies the size of this component's scrollpane viewport, or size of
    * the component itself if the component is not scrollable.
    */
    public void setViewSize(_package.component.gUI.Dimension pViewSize)
        {
        // The following are almost equivalent
        //
        //   get_ScrollPane().getViewport().setViewSize(new java.awt.Dimension(w, h));
        //
        // and
        //
        // set_Size(new java.awt.Dimension(w, h));
        // set_PreferredSize(new java.awt.Dimension(w, h));
        //
        // The problem with the first is that ScrollPaneLayout line # 745 is inconsistent
        // with JViewport.getViewSize(), so AS_NEEDED scroll bars misbehave.
        // The problem with the second is that (for reasons I didn't have time to investigate)
        // it doesn't work with JTable
        
        if (isScrollable())
            {
            java.awt.Dimension _dim = pViewSize.get_Dimension();
        
            if (true)
                {
                get_ScrollPane().getViewport().setViewSize(_dim);
                }
            else
                {
                set_Size(_dim);
                set_PreferredSize(_dim);
                }
            }
        }
    }
