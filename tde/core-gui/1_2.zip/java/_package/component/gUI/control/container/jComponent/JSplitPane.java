/* Class
*     _package.component.gUI.control.container.jComponent.JSplitPane
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.Constraints;
import _package.component.gUI.Control;
import _package.component.gUI.constraints.namedConstraints.Bottom;
import _package.component.gUI.constraints.namedConstraints.Left;
import _package.component.gUI.constraints.namedConstraints.Right;
import _package.component.gUI.constraints.namedConstraints.Top;
import java.awt.Component; // as _Control

/*
* Integrates
*     javax.swing.JSplitPane
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JSplitPane
        extends    _package.component.gUI.control.container.JComponent
    {
    // Fields declarations
    
    /**
    * Property BottomComponent
    *
    */
    private transient _package.component.gUI.Control __m_BottomComponent;
    
    /**
    * Property ContinuousLayout
    *
    */
    private transient boolean __m_ContinuousLayout;
    
    /**
    * Property DividerLocation
    *
    */
    private transient int __m_DividerLocation;
    
    /**
    * Property DividerSize
    *
    */
    private transient int __m_DividerSize;
    
    /**
    * Property HORIZONTAL_SPLIT
    *
    */
    public static final int HORIZONTAL_SPLIT = 1; // javax.swing.JSplitPane.HORIZONTAL_SPLIT;
    
    /**
    * Property LastDividerLocation
    *
    */
    private transient int __m_LastDividerLocation;
    
    /**
    * Property LeftComponent
    *
    */
    private _package.component.gUI.Control __m_LeftComponent;
    
    /**
    * Property MaximumDividerLocation
    *
    */
    
    /**
    * Property MinimumDividerLocation
    *
    */
    
    /**
    * Property OneTouchExpandable
    *
    */
    private transient boolean __m_OneTouchExpandable;
    
    /**
    * Property Orientation
    *
    * Splitter line going horizontally:
    * VERTICAL_SPLIT = 0
    * 
    * Splitter line going vertically:
    * HORIZONTAL_SPLIT = 1
    */
    private transient int __m_Orientation;
    
    /**
    * Property RightComponent
    *
    */
    private _package.component.gUI.Control __m_RightComponent;
    
    /**
    * Property TopComponent
    *
    */
    private transient _package.component.gUI.Control __m_TopComponent;
    
    /**
    * Property VERTICAL_SPLIT
    *
    */
    public static final int VERTICAL_SPLIT = 0; // javax.swing.JSplitPane.VERTICAL_SPLIT;
    
    // fields used by the integration model:
    private sink_JSplitPane __sink;
    private javax.swing.JSplitPane __feed;
    
    // Default constructor
    public JSplitPane()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JSplitPane(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setDividerSize(8);
            setFocusable(true);
            setOrientation(0);
            setTConstraints("Center");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JSplitPane.__tloPeer.setObject(this);
            new jb_JSplitPane(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JSplitPane();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JSplitPane".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JSplitPane integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JSplitPane) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JSplitPane) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public int getDividerLocation()
        {
        return __sink.getDividerLocation();
        }
    public int getDividerSize()
        {
        return __sink.getDividerSize();
        }
    public int getLastDividerLocation()
        {
        return __sink.getLastDividerLocation();
        }
    public int getMaximumDividerLocation()
        {
        return __sink.getMaximumDividerLocation();
        }
    public int getMinimumDividerLocation()
        {
        return __sink.getMinimumDividerLocation();
        }
    public int getOrientation()
        {
        return __sink.getOrientation();
        }
    public boolean isContinuousLayout()
        {
        return __sink.isContinuousLayout();
        }
    public boolean isOneTouchExpandable()
        {
        return __sink.isOneTouchExpandable();
        }
    public void setContinuousLayout(boolean pContinuousLayout)
        {
        __sink.setContinuousLayout(pContinuousLayout);
        }
    public void setDividerLocation(int pDividerLocation)
        {
        __sink.setDividerLocation(pDividerLocation);
        }
    public void setDividerSize(int pDividerSize)
        {
        __sink.setDividerSize(pDividerSize);
        }
    public void setLastDividerLocation(int pLastDividerLocation)
        {
        __sink.setLastDividerLocation(pLastDividerLocation);
        }
    public void set_LeftComponent(java.awt.Component comp)
        {
        __sink.setLeftComponent(comp);
        }
    public void setOneTouchExpandable(boolean pOneTouchExpandable)
        {
        __sink.setOneTouchExpandable(pOneTouchExpandable);
        }
    public void setOrientation(int pOrientation)
        {
        __sink.setOrientation(pOrientation);
        }
    public void set_RightComponent(java.awt.Component comp)
        {
        __sink.setRightComponent(comp);
        }
    //-- javax.swing.JSplitPane integration
    
    // Declared at the super level
    /**
    * Add a child component with the specified name to this component.
    * 
    * @param child  a component to add ti this component as a child
    * @param name  a [unique] name to identify this child. If the name is not
    * specified (null is passed) then a unique child name will be automatically
    * assigned
    * 
    * Note: this method fires onAdd() notification only if the parent (this
    * component) has already been fully constructed.
    * Note2: component containment/aggregation produces children initialization
    * code (see __init()) that is executed while the parent is not flagged as
    * _Constructed yet
    */
    public void _addChild(_package.Component child, String name)
        {
        // import Component.GUI.Constraints;
        // import Component.GUI.Constraints.NamedConstraints.Left;
        // import Component.GUI.Constraints.NamedConstraints.Right;
        // import Component.GUI.Constraints.NamedConstraints.Top;
        // import Component.GUI.Constraints.NamedConstraints.Bottom;
        
        super._addChild(child, name);
        
        Control     ctrl        = (Control) child;
        Constraints constraints = ctrl.getConstraints();
        
        if      (constraints instanceof Left  || constraints instanceof Top)
            {
            setLeftComponent(ctrl);
            }
        else if (constraints instanceof Right || constraints instanceof Bottom)
            {
            setRightComponent(ctrl);
            }
        else
            {
            throw new IllegalArgumentException(get_Name() +
                "._addChild: invalid child's constraints");
            }

        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control;
        // import java.awt.Component as _Control;

        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        int iLoc;
        
        iLoc = config.getInt(sPrefix + ".LastDividerLocation", -1);
        if (iLoc != -1)
            {
            setLastDividerLocation(iLoc);
            }
        
        iLoc = config.getInt(sPrefix + ".DividerLocation", -1);
        if (iLoc != -1)
            {
            setDividerLocation(iLoc);
            }
        
        super.applyConfig(config, sPrefix);
        }
    
    // Accessor for the property "BottomComponent"
    public _package.component.gUI.Control getBottomComponent()
        {
        return getRightComponent();
        }
    
    // Accessor for the property "LeftComponent"
    public _package.component.gUI.Control getLeftComponent()
        {
        return __m_LeftComponent;
        }
    
    // Accessor for the property "RightComponent"
    public _package.component.gUI.Control getRightComponent()
        {
        return __m_RightComponent;
        }
    
    // Accessor for the property "TopComponent"
    public _package.component.gUI.Control getTopComponent()
        {
        return getLeftComponent();
        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        config.putInt(sPrefix + ".LastDividerLocation", getLastDividerLocation());
        config.putInt(sPrefix + ".DividerLocation",     getDividerLocation());
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "BottomComponent"
    public void setBottomComponent(_package.component.gUI.Control pBottomComponent)
        {
        setRightComponent(pBottomComponent);
        }
    
    // Accessor for the property "LeftComponent"
    public void setLeftComponent(_package.component.gUI.Control pLeftComponent)
        {
        __m_LeftComponent = (pLeftComponent);
        set_LeftComponent((_Control) pLeftComponent.get_Feed());
        }
    
    // Accessor for the property "RightComponent"
    public void setRightComponent(_package.component.gUI.Control pRightComponent)
        {
        __m_RightComponent = (pRightComponent);
        set_RightComponent((_Control) pRightComponent.get_Feed());
        }
    
    // Accessor for the property "TopComponent"
    public void setTopComponent(_package.component.gUI.Control pTopComponent)
        {
        setLeftComponent(pTopComponent);
        }
    }
