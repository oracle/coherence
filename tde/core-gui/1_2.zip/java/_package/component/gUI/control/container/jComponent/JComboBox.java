/* Class
*     _package.component.gUI.control.container.jComponent.JComboBox
*/

package _package.component.gUI.control.container.jComponent;

import com.tangosol.run.component.EventDeathException;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetListener;
import javax.swing.JComboBox; // as _JComboBox
import javax.swing.ListCellRenderer;
import javax.swing.text.JTextComponent; // as _JTextComponent

/*
* Integrates
*     javax.swing.JComboBox
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JComboBox
        extends    _package.component.gUI.control.container.JComponent
        implements javax.swing.ListCellRenderer,
                   java.awt.event.ActionListener,
                   java.awt.event.ItemListener
    {
    // Fields declarations
    
    /**
    * Property _DefaultRenderer
    *
    */
    private javax.swing.ListCellRenderer __m__DefaultRenderer;
    
    /**
    * Property CaseSensitive
    *
    */
    private boolean __m_CaseSensitive;
    
    /**
    * Property Collator
    *
    */
    private java.text.Collator __m_Collator;
    
    /**
    * Property Editable
    *
    */
    private transient boolean __m_Editable;
    
    /**
    * Property FocusAccelerator
    *
    */
    private transient char __m_FocusAccelerator;
    
    /**
    * Property ITEM_NOT_FOUND
    *
    */
    public static final int ITEM_NOT_FOUND = -1;
    
    /**
    * Property ItemCount
    *
    */
    
    /**
    * Property Items
    *
    */
    private transient Object[] __m_Items;
    
    /**
    * Property LightWeightPopupEnabled
    *
    */
    private transient boolean __m_LightWeightPopupEnabled;
    
    /**
    * Property MaximumRowCount
    *
    */
    private transient int __m_MaximumRowCount;
    
    /**
    * Property PopupVisible
    *
    */
    private transient boolean __m_PopupVisible;
    
    /**
    * Property SelectedIndex
    *
    */
    private transient int __m_SelectedIndex;
    
    /**
    * Property SelectedItem
    *
    */
    private transient Object __m_SelectedItem;
    
    /**
    * Property Sorted
    *
    */
    private boolean __m_Sorted;
    
    /**
    * Property STATE_DESELECTED
    *
    */
    public static final int STATE_DESELECTED = 2;
    
    /**
    * Property STATE_SELECTED
    *
    */
    public static final int STATE_SELECTED = 1;
    
    /**
    * Property Text
    *
    */
    private String __m_Text;
    
    /**
    * Property TextEditor
    *
    */
    
    // fields used by the integration model:
    private sink_JComboBox __sink;
    private javax.swing.JComboBox __feed;
    
    // Default constructor
    public JComboBox()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JComboBox(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JComboBox.__tloPeer.setObject(this);
            new jb_JComboBox(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        super.__initEvents();
        
        addActionListener(this);
        addItemListener(this);
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JComboBox();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JComboBox".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ ActionListener dispatcher
    private com.tangosol.util.Listeners __ActionListeners;
    private void addActionListener$Router(java.awt.event.ActionListener l)
        {
        __sink.addActionListener(l);
        }
    public void addActionListener(java.awt.event.ActionListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __ActionListeners;
        if (_listeners == null)
            {
            __ActionListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addActionListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeActionListener$Router(java.awt.event.ActionListener l)
        {
        __sink.removeActionListener(l);
        }
    public void removeActionListener(java.awt.event.ActionListener l)
        {
        com.tangosol.util.Listeners _listeners = __ActionListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeActionListener$Router(this);
            }
        }
    private void actionPerformed$Dispatch(java.awt.event.ActionEvent e)
        {
        java.util.EventListener[] targets = __ActionListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.ActionListener target = (java.awt.event.ActionListener) targets[i];
            if (target != this)
                {
                target.actionPerformed(e);
                }
            }
        }
    public void actionPerformed(java.awt.event.ActionEvent e)
        {
        try
            {
            onAction(e.getActionCommand(), e.getModifiers(), e.paramString());
            }
        catch (EventDeathException ex)
            {
            return;
            }
        actionPerformed$Dispatch(e);
        }
    //-- ActionListener dispatcher
    
    //++ ItemListener dispatcher
    private com.tangosol.util.Listeners __ItemListeners;
    private void addItemListener$Router(java.awt.event.ItemListener l)
        {
        __sink.addItemListener(l);
        }
    public void addItemListener(java.awt.event.ItemListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __ItemListeners;
        if (_listeners == null)
            {
            __ItemListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addItemListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeItemListener$Router(java.awt.event.ItemListener l)
        {
        __sink.removeItemListener(l);
        }
    public void removeItemListener(java.awt.event.ItemListener l)
        {
        com.tangosol.util.Listeners _listeners = __ItemListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeItemListener$Router(this);
            }
        }
    private void itemStateChanged$Dispatch(java.awt.event.ItemEvent e)
        {
        java.util.EventListener[] targets = __ItemListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.ItemListener target = (java.awt.event.ItemListener) targets[i];
            if (target != this)
                {
                target.itemStateChanged(e);
                }
            }
        }
    public void itemStateChanged(java.awt.event.ItemEvent e)
        {
        try
            {
            if (is_Constructed())
                {
                onSelected(e.getItem(), e.getStateChange(), e.paramString());
                }
            }
        catch (EventDeathException ex)
            {
            return;
            }
        itemStateChanged$Dispatch(e);
        }
    //-- ItemListener dispatcher
    
    //++ javax.swing.JComboBox integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JComboBox) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JComboBox) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    /**
    * Requests that this component get the input focus. The component must be
    * visible on the screen for this request to be granted.
    * 
    * @see JComponent#requestDefaultFocus
    */
    public void requestFocus()
        {
        if (isEditable() && getTextEditor() != null)
            {
            getTextEditor().requestFocus();
            }
        else
            {
            super.requestFocus();
            }
        }
    public void updateUI()
        {
        _JComboBox _combo = (_JComboBox) get_Feed();
        
        _combo.setRenderer(null);
        
        super.updateUI();
        
        set_DefaultRenderer(_combo.getRenderer());
        _combo.setRenderer(this);
        }
    private void addItem$Router(Object item)
        {
        __sink.addItem(item);
        }
    public void addItem(Object item)
        {
        // see JList#addItem()
        
        if (isSorted())
            {
            int      cItems      = getItemCount();
            boolean  fIgnoreCase = !isCaseSensitive();
            String   sItem       = item.toString();
        
            java.text.Collator     collator = getCollator();
            java.text.CollationKey ckItem   = null;
        
            if (collator != null)
                {
                ckItem = collator.getCollationKey(sItem);
                }
            else
                {
                if (fIgnoreCase)
                    {
                    sItem = sItem.toUpperCase();
                    }
                }
        
            for (int i = 0; i < cItems; i++)
                {
                boolean bInsert;
                String  s = (String) getItemAt(i);
        
                if (collator != null)
                    {
                    bInsert = collator.getCollationKey(s).compareTo(ckItem) > 0;
                    }
                else
                    {
                    if (fIgnoreCase)
                        {
                        s = s.toUpperCase();
                        }
                    bInsert = s.compareTo(sItem) > 0;
                    }
        
                if (bInsert)
                    {
                    insertItemAt(item, i);
                    return;
                    }
                }
            }
        addItem$Router(item);
        }
    public Object getItemAt(int index)
        {
        return __sink.getItemAt(index);
        }
    public int getItemCount()
        {
        return __sink.getItemCount();
        }
    public int getMaximumRowCount()
        {
        return __sink.getMaximumRowCount();
        }
    public int getSelectedIndex()
        {
        return __sink.getSelectedIndex();
        }
    public Object getSelectedItem()
        {
        return __sink.getSelectedItem();
        }
    public void insertItemAt(Object item, int index)
        {
        __sink.insertItemAt(item, index);
        }
    public boolean isEditable()
        {
        return __sink.isEditable();
        }
    public boolean isLightWeightPopupEnabled()
        {
        return __sink.isLightWeightPopupEnabled();
        }
    public boolean isPopupVisible()
        {
        return __sink.isPopupVisible();
        }
    private void removeAllItems$Router()
        {
        __sink.removeAllItems();
        }
    public void removeAllItems()
        {
        if (getItemCount() > 0)
            {
            removeAllItems$Router();
            }
        }
    public void removeItemAt(int index)
        {
        __sink.removeItemAt(index);
        }
    public void setEditable(boolean pEditable)
        {
        __sink.setEditable(pEditable);
        }
    public void setLightWeightPopupEnabled(boolean pLightWeightPopupEnabled)
        {
        __sink.setLightWeightPopupEnabled(pLightWeightPopupEnabled);
        }
    public void setMaximumRowCount(int pMaximumRowCount)
        {
        __sink.setMaximumRowCount(pMaximumRowCount);
        }
    public void setPopupVisible(boolean pPopupVisible)
        {
        __sink.setPopupVisible(pPopupVisible);
        }
    public void setSelectedIndex(int pSelectedIndex)
        {
        __sink.setSelectedIndex(pSelectedIndex);
        }
    public void setSelectedItem(Object pSelectedItem)
        {
        __sink.setSelectedItem(pSelectedItem);
        }
    //-- javax.swing.JComboBox integration
    
    // Declared at the super level
    public void _imports()
        {
        // import javax.swing.JComboBox as _JComboBox;
        // import javax.swing.text.JTextComponent as _JTextComponent;
        // import com.tangosol.run.component.EventDeathException;
        

        }
    
    public int findItem(Object item)
        {
        int cItems = getItemCount();
        
        for (int i = 0; i < cItems; i++)
            {
            if (getItemAt(i).equals(item))
                {
                return i;
                }
            }
        
        return ITEM_NOT_FOUND;
        }
    
    /**
    * Looks for an item that starts with the specified pattern
    * 
    * @param pattern    pattern to look for
    * @param exactMatch if true, compares using "equals()"; otherwise uses
    * "startsWith()"
    * @param startAt    specifies the position in the combobox to start at
    * 
    * @return an index of the specified item; -1 if not found
    * 
    * @see JList#findItem(pattenr, exactMatch, startAt)
    */
    public int findItem(String pattern, boolean exactMatch, int startAt)
        {
        int     cItems      = getItemCount();
        boolean fIgnoreCase = !isCaseSensitive();
        
        if (startAt < 0 || startAt > cItems)
            throw new IllegalArgumentException("Invalid starting index");
        
        if (fIgnoreCase)
            {
            pattern = pattern.toUpperCase();
            }
        
        while (true) // maximum two passes
            {
            for (int i = startAt; i < cItems; i++)
                {
                String sItem = getItemAt(i).toString();
        
                if (fIgnoreCase)
                    {
                    sItem = sItem.toUpperCase();
                    }
        
                if (exactMatch)
                    {
                    if (sItem.equals(pattern))
                        {
                        return i;
                        }
                    }
                else
                    {
                    if (sItem.startsWith(pattern))
                        {
                        return i;
                        }
                    }
                }
        
            if (startAt == 0)
                break;
        
            // perform the second pass
            cItems  = startAt;
            startAt = 0;
            }
        
        return ITEM_NOT_FOUND;
        }
    
    // Accessor for the property "_DefaultRenderer"
    public javax.swing.ListCellRenderer get_DefaultRenderer()
        {
        return __m__DefaultRenderer;
        }
    
    // Accessor for the property "Collator"
    public java.text.Collator getCollator()
        {
        return __m_Collator;
        }
    
    // Accessor for the property "FocusAccelerator"
    public char getFocusAccelerator()
        {
        _JTextComponent textEditor = getTextEditor();
        
        if (textEditor != null)
            {
            return textEditor.getFocusAccelerator();
            }
        else
            {
            // see javax.swing.text.JTextComponent#getFocusAccelerator()
            return '\0';
            }

        }
    
    // Accessor for the property "Items"
    public Object[] getItems()
        {
        int count = getItemCount();
        
        Object[] list = new Object[count];
        
        for (int i = 0; i < count; i++)
            {
            list[i] = getItemAt(i);
            }
        
        return list;
        }
    
    // From interface: javax.swing.ListCellRenderer
    public java.awt.Component getListCellRendererComponent(javax.swing.JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
        {
        // import javax.swing.ListCellRenderer;
        
        // list object is the JList portion of a popup
        
        ListCellRenderer renderer = get_DefaultRenderer();
        _assert(renderer != this);
        _assert(index < 0 || getItemAt(index) == value);
        
        java.awt.Component compRenderer =
            renderer.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
        
        if (index >= 0)
            {
            onCellRendering(compRenderer, value, index, cellHasFocus);
            }
        
        return compRenderer;

        }
    
    // Accessor for the property "Text"
    public String getText()
        {
        _JTextComponent textEditor = getTextEditor();
        
        return textEditor != null ? textEditor.getText() : getSelectedItem().toString();

        }
    
    // Accessor for the property "TextEditor"
    protected javax.swing.text.JTextComponent getTextEditor()
        {
        if (isEditable())
            {
            try
                {
                _JComboBox feed = (_JComboBox) get_Feed();
                return (_JTextComponent) feed.getEditor().getEditorComponent();
                }
            catch (Exception e) // ClassCastException or NullPointerException
                {
                }
            }
        
        return null;

        }
    
    // Accessor for the property "CaseSensitive"
    public boolean isCaseSensitive()
        {
        return __m_CaseSensitive;
        }
    
    // Accessor for the property "Sorted"
    public boolean isSorted()
        {
        return __m_Sorted;
        }
    
    // Declared at the super level
    public void keyPressed(java.awt.event.KeyEvent e)
        {
        // don't dispatch the event if the editor is the source
        // (see #onInit)
        if (e.getSource() == getTextEditor())
            {
            try
                {
                onKeyPressed(e.getKeyChar(), e.getKeyCode(), e.getModifiers());
        
                // the following is a work around for bugs 4203556, 4256046, 4138762, 4112282
                // TODO: remove when fixed
                    {
                    char ch = e.getKeyChar();
                    if (ch == java.awt.event.KeyEvent.VK_ENTER ||
                        ch == java.awt.event.KeyEvent.VK_ESCAPE)
                        {
                        ((_JComboBox) get_Feed()).getParent().dispatchEvent(e);
                        }
                    }
                }
            catch (EventDeathException x)
                {
                }
            }
        else
            {
            super.keyPressed(e);
            }
        }
    
    // Declared at the super level
    public void keyReleased(java.awt.event.KeyEvent e)
        {
        // don't dispatch the event if the editor is the source
        // (see #onInit)
        if (e.getSource() == getTextEditor())
            {
            try
                {
                onKeyReleased(e.getKeyChar(), e.getKeyCode(), e.getModifiers());
                }
            catch (EventDeathException x)
                {
                }
            }
        else
            {
            super.keyReleased(e);
            }
        }
    
    // Declared at the super level
    public void keyTyped(java.awt.event.KeyEvent e)
        {
        // don't dispatch the event if the editor is the source
        // (see #onInit)
        if (e.getSource() == getTextEditor())
            {
            try
                {
                onKeyTyped(e.getKeyChar(), e.getModifiers());
                }
            catch (EventDeathException x)
                {
                }
            }
        else
            {
            super.keyTyped(e);
            }

        }
    
    public void onAction(String command, int modifiers, String param)
        {
        }
    
    public void onCellRendering(java.awt.Component compRenderer, Object value, int index, boolean hasFocus)
        {
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import java.awt.dnd.DropTarget;
        // import java.awt.dnd.DropTargetListener;
        
        // for JComboBox an actual drop target is the text editor
        boolean fDropAllowed = isDropAllowed();
        if (fDropAllowed)
            {
            // preventing the JComboBox becoming a target
            setDropAllowed(false);
            }
        
        super.onInit();
        
        // When you type a text in the editor, the combobox gets no notifications.
        // The following is a work-around (see #keyPressed, #keyReleased, #keyTyped)
        _JTextComponent editor = getTextEditor();
        if (editor != null)
            {
            editor.addKeyListener(this);
        
            if (fDropAllowed)
                {
                setDropAllowed(true);
        
                DropTarget target = new DropTarget(
                    editor, getDropActions(), (DropTargetListener) this, true);
                }
            }

        }
    
    /**
    * Notification sent when the specified item gets selected
    * (state==STATE_SELECTED) or deselected (state==STATE_DESELECTED)
    * 
    * @param item  item whose state has changed
    * @param state  one of STATE_SELECTED or STATE_DESELECTED
    * @param  param event parameter
    * 
    * @see #itemStateChanged
    */
    public void onSelected(Object item, int state, String param)
        {
        }
    
    // Declared at the super level
    /**
    * Prepares to transfer something at the specified location for the
    * specified action
    * 
    * @return true if transfer is going to be accepted; false otherwise
    * 
    * @see dragOver()
    */
    protected boolean prepareTransferAtLocation(_package.component.gUI.Point point, int iAction, java.util.List listFlavors)
        {
        return isEnabled() && isEditable();
        }
    
    // Declared at the super level
    /**
    * Puts (drops) the specified Transferable object at the specified location
    * for the specified action
    * 
    * @return true if transfer is accepted; false otherwise
    * 
    * @see drop()
    */
    protected boolean putTransferAtLocation(java.awt.datatransfer.Transferable transfer, _package.component.gUI.Point point, int iAction)
        {
        // import java.awt.datatransfer.DataFlavor;
        // import java.awt.dnd.DnDConstants;
        
        _JTextComponent editor = getTextEditor();
        if (editor == null)
            {
            return false;
            }
        
        String sValue = null;
        try
            {
            DataFlavor flavor;
            if (transfer.isDataFlavorSupported(DataFlavor.stringFlavor))
                {
                flavor = DataFlavor.stringFlavor;
                }
            else
                {
                flavor = transfer.getTransferDataFlavors()[0];
                }
            sValue = String.valueOf(transfer.getTransferData(flavor));
            }
        // UnsupportedFlavorException, IOException
        catch (Exception e)
            {
            _trace("transfer failed " + e, 1);
            return false;
            }
        
        if (sValue != null)
            {
            editor.setText(sValue);
            }
        
        return true;
        }
    
    // Accessor for the property "_DefaultRenderer"
    public void set_DefaultRenderer(javax.swing.ListCellRenderer p_DefaultRenderer)
        {
        __m__DefaultRenderer = p_DefaultRenderer;
        }
    
    // Accessor for the property "CaseSensitive"
    public void setCaseSensitive(boolean pCaseSensitive)
        {
        __m_CaseSensitive = pCaseSensitive;
        }
    
    // Accessor for the property "Collator"
    public void setCollator(java.text.Collator pCollator)
        {
        __m_Collator = pCollator;
        }
    
    // Accessor for the property "FocusAccelerator"
    public void setFocusAccelerator(char key)
        {
        _JTextComponent textEditor = getTextEditor();
        
        if (textEditor != null)
            {
            textEditor.setFocusAccelerator(key);
            }
        else
            {
            // see javax.swing.text.JTextComponent#setFocusAccelerator()
            }
        }
    
    // Accessor for the property "Items"
    public void setItems(Object[] list)
        {
        removeAllItems();
        
        if (list != null)
            {
            for (int i = 0; i < list.length; i++)
                {
                addItem(list[i]);
                }
            }
        }
    
    // Accessor for the property "Sorted"
    public void setSorted(boolean pSorted)
        {
        if (pSorted == isSorted())
            {
            return;
            }
        
        __m_Sorted = (pSorted);
        
        if (pSorted)
            {
            // force sorting
            setItems(getItems());
            }
        }
    
    // Accessor for the property "Text"
    public void setText(String pText)
        {
        _JTextComponent textEditor = getTextEditor();
        int ix = findItem(pText, true, 0);
        
        if (textEditor != null)
            {
            textEditor.setText(pText);
            }
        
        if (ix != ITEM_NOT_FOUND)
            {
            setSelectedIndex(ix);
            }
        else if (textEditor == null || !isEditable())
            {
            // swing bug/feature: cannot change the text if not editable
            addItem(pText);
            setSelectedIndex(findItem(pText, true, 0));
            }
        }
    }
