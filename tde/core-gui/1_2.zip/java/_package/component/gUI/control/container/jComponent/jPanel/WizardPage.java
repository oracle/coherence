/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.WizardPage
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.gUI.control.container.jComponent.jPanel.WizardPane;

/**
* This component represents one of a Wizard's pages. It is to be inserted into
* the $Workspace panel of a WizardPane component. All pages are ordered
* according to values of their _Order property (this allows pages to be
* inserted later at derivation levels).
*/
public class WizardPage
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property DIR_BACKWARD
    *
    */
    public static final int DIR_BACKWARD = 1;
    
    /**
    * Property DIR_CANCEL
    *
    */
    public static final int DIR_CANCEL = 2;
    
    /**
    * Property DIR_FINISH
    *
    */
    public static final int DIR_FINISH = 3;
    
    /**
    * Property DIR_FORWARD
    *
    */
    public static final int DIR_FORWARD = 0;
    
    /**
    * Property NextAllowed
    *
    * Specifies whether the "Next" (or "Finish", if this page is the last one)
    * button should be enabled for this page. Setting this property enables or
    * disables an appropriate button if this page is currenlty active one or
    * when it becomes active.
    */
    private transient boolean __m_NextAllowed;
    
    /**
    * Property Wizard
    *
    * Helper property that specifies the enclosing Wizard pane.
    */
    private transient WizardPane __m_Wizard;
    
    // Default constructor
    public WizardPage()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public WizardPage(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setNextAllowed(true);
            setResizable(true);
            setTBounds("0,0,350,270");
            setTConstraints("Center");
            setTLayout(null);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new WizardPage$LBL_Desc("LBL_Desc", this, true), "LBL_Desc");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new WizardPage();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/WizardPage".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "Wizard"
    public WizardPane getWizard()
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.WizardPane;
        
        WizardPane wizard = __m_Wizard;
        if (wizard == null)
            {
            wizard = (WizardPane) _findAncestor(WizardPane.class);
            setWizard(wizard);
            }
        
        return wizard;
        }
    
    // Accessor for the property "NextAllowed"
    public boolean isNextAllowed()
        {
        return __m_NextAllowed;
        }
    
    /**
    * A message-notification sent when this page has been entered.
    * 
    * @param iDirection  one of the following values:
    *     DIR_FORWARD -- entering from a previous page
    *     DIR_BACKWARD -- entering from a next page
    */
    public void onPageEntering(int iDirection)
        {
        }
    
    /**
    * A message-notification sent when this [currenlt active] page is about to
    * be left.
    * 
    * @param iDirection  one of the following values:
    *     DIR_FORWARD -- leaving for a next page
    *     DIR_BACKWARD -- leaving for a previous page
    *     DIR_CANCEL -- leaving the wizard abnormally
    *     DIR_FINISH -- leaving the wizard normally
    * 
    * @throw EventDeathException when this page shoud not be left
    */
    public void onPageLeaving(int iDirection)
        {
        }
    
    /**
    * A message-notification sent when the wizard is about to be closed giving
    * each page a chance to cleanup.
    */
    public void onWizardClosing()
        {
        }
    
    // Accessor for the property "NextAllowed"
    public void setNextAllowed(boolean pNextAllowed)
        {
        // import Component.GUI.Control.Container.JComponent.JPanel.WizardPane;
        
        __m_NextAllowed = (pNextAllowed);
        
        WizardPane wizard = getWizard();
        
        if (wizard != null && wizard.getActivePage() == this)
            {
            wizard.setNextAllowed(pNextAllowed);
            }
        }
    
    // Accessor for the property "Wizard"
    private void setWizard(WizardPane pWizard)
        {
        __m_Wizard = pWizard;
        }
    }
