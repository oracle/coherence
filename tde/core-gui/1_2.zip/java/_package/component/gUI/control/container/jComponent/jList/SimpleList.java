/* Class
*     _package.component.gUI.control.container.jComponent.jList.SimpleList
*/

package _package.component.gUI.control.container.jComponent.jList;

public class SimpleList
        extends    _package.component.gUI.control.container.jComponent.JList
    {
    // Fields declarations
    
    /**
    * Property List
    *
    */
    private transient String[] __m_List;
    
    // Default constructor
    public SimpleList()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public SimpleList(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setScrollable(true);
            setSelectionMode(1);
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new SimpleList();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jList/SimpleList".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "List"
    public String[] getList()
        {
        Object[] aoItem = getItems();
        String[] asItem = new String[aoItem.length];
        
        System.arraycopy(aoItem, 0, asItem, 0, aoItem.length);
        
        return asItem;
        }
    
    // Accessor for the property "List"
    public String getList(int pIndex)
        {
        return getList()[pIndex];
        }
    
    // Accessor for the property "List"
    public void setList(String[] pList)
        {
        setItems(pList);
        }
    
    // Accessor for the property "List"
    public void setList(int pIndex, String pList)
        {
        getList()[pIndex] = pList;
        }
    }
