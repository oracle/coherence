/* Class
*      jb_JList
*
* automatically generated "Feed" which
* a) extends an external bean:
*      javax.swing.JList
* b) delegates to the peer component:
*      Component.GUI.Control.Container.JComponent.JList
*/

package _package.component.gUI.control.container.jComponent;

public class jb_JList
        extends    javax.swing.JList
        implements com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected JList __peer;
    
    private static JList __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            JList peer = (JList)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // default (JavaBean) constructor
    public jb_JList()
        {
        this(JList.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JList(java.util.Vector Param_1)
        {
        this(Param_1, JList.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JList(javax.swing.ListModel Param_1)
        {
        this(Param_1, JList.get_CLASS());
        }
    
    // parameterized constructor
    public jb_JList(Object[] Param_1)
        {
        this(Param_1, JList.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JList(Class clzPeer)
        {
        this(__createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JList(java.util.Vector Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JList(javax.swing.ListModel Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_JList(Object[] Param_1, Class clzPeer)
        {
        this(Param_1, __createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JList(JList peer, boolean fInit)
        {
        super();
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JList(java.util.Vector Param_1, JList peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JList(javax.swing.ListModel Param_1, JList peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_JList(Object[] Param_1, JList peer, boolean fInit)
        {
        super(Param_1);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private JList __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (JList) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_JList(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    public void add(java.awt.Component comp, Object constraints, int index)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._add(comp, constraints, index);
        }
    void super$add(java.awt.Component comp, Object constraints, int index)
        {
        super.add(comp, constraints, index);
        }
    public java.awt.Point indexToLocation(int index)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer._indexToLocation(index);
        }
    java.awt.Point super$indexToLocation(int index)
        {
        return super.indexToLocation(index);
        }
    public int locationToIndex(java.awt.Point point)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer._locationToIndex(point);
        }
    int super$locationToIndex(java.awt.Point point)
        {
        return super.locationToIndex(point);
        }
    public void remove(java.awt.Component comp)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer._remove(comp);
        }
    void super$remove(java.awt.Component comp)
        {
        super.remove(comp);
        }
    public void addFocusListener(java.awt.event.FocusListener l)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addFocusListener(l);
        }
    void super$addFocusListener(java.awt.event.FocusListener l)
        {
        super.addFocusListener(l);
        }
    public void addKeyListener(java.awt.event.KeyListener l)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addKeyListener(l);
        }
    void super$addKeyListener(java.awt.event.KeyListener l)
        {
        super.addKeyListener(l);
        }
    public void addListSelectionListener(javax.swing.event.ListSelectionListener l)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addListSelectionListener(l);
        }
    void super$addListSelectionListener(javax.swing.event.ListSelectionListener l)
        {
        super.addListSelectionListener(l);
        }
    public void addMouseListener(java.awt.event.MouseListener l)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseListener(l);
        }
    void super$addMouseListener(java.awt.event.MouseListener l)
        {
        super.addMouseListener(l);
        }
    public void addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMouseMotionListener(l);
        }
    void super$addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.addMouseMotionListener(l);
        }
    public void addNotify()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addNotify();
        }
    void super$addNotify()
        {
        super.addNotify();
        }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addPropertyChangeListener(l);
        }
    void super$addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.addPropertyChangeListener(l);
        }
    public void addSelectionInterval(int anchor, int lead)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addSelectionInterval(anchor, lead);
        }
    void super$addSelectionInterval(int anchor, int lead)
        {
        super.addSelectionInterval(anchor, lead);
        }
    public void addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addVetoableChangeListener(l);
        }
    void super$addVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.addVetoableChangeListener(l);
        }
    public void clearSelection()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.clearSelection();
        }
    void super$clearSelection()
        {
        super.clearSelection();
        }
    public javax.swing.JToolTip createToolTip()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.createToolTip();
        }
    javax.swing.JToolTip super$createToolTip()
        {
        return super.createToolTip();
        }
    public void doLayout()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.doLayout();
        }
    void super$doLayout()
        {
        super.doLayout();
        }
    public void ensureIndexIsVisible(int index)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.ensureIndexIsVisible(index);
        }
    void super$ensureIndexIsVisible(int index)
        {
        super.ensureIndexIsVisible(index);
        }
    public java.awt.Color getBackground()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Background();
        }
    java.awt.Color super$getBackground()
        {
        return super.getBackground();
        }
    public javax.swing.border.Border getBorder()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Border();
        }
    javax.swing.border.Border super$getBorder()
        {
        return super.getBorder();
        }
    public java.awt.Rectangle getBounds()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Bounds();
        }
    java.awt.Rectangle super$getBounds()
        {
        return super.getBounds();
        }
    public java.awt.Cursor getCursor()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Cursor();
        }
    java.awt.Cursor super$getCursor()
        {
        return super.getCursor();
        }
    public java.awt.Font getFont()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Font();
        }
    java.awt.Font super$getFont()
        {
        return super.getFont();
        }
    public java.awt.Color getForeground()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Foreground();
        }
    java.awt.Color super$getForeground()
        {
        return super.getForeground();
        }
    public java.awt.Insets getInsets()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Insets();
        }
    java.awt.Insets super$getInsets()
        {
        return super.getInsets();
        }
    public java.awt.LayoutManager getLayout()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Layout();
        }
    java.awt.LayoutManager super$getLayout()
        {
        return super.getLayout();
        }
    public java.awt.Point getLocation()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Location();
        }
    java.awt.Point super$getLocation()
        {
        return super.getLocation();
        }
    public java.awt.Point getLocationOnScreen()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_LocationOnScreen();
        }
    java.awt.Point super$getLocationOnScreen()
        {
        return super.getLocationOnScreen();
        }
    public java.awt.Dimension getMaximumSize()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MaximumSize();
        }
    java.awt.Dimension super$getMaximumSize()
        {
        return super.getMaximumSize();
        }
    public java.awt.Dimension getMinimumSize()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_MinimumSize();
        }
    java.awt.Dimension super$getMinimumSize()
        {
        return super.getMinimumSize();
        }
    public javax.swing.ListModel getModel()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Model();
        }
    javax.swing.ListModel super$getModel()
        {
        return super.getModel();
        }
    public java.awt.Dimension getPreferredSize()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_PreferredSize();
        }
    java.awt.Dimension super$getPreferredSize()
        {
        return super.getPreferredSize();
        }
    public java.awt.Color getSelectionBackground()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_SelectionBackground();
        }
    java.awt.Color super$getSelectionBackground()
        {
        return super.getSelectionBackground();
        }
    public java.awt.Color getSelectionForeground()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_SelectionForeground();
        }
    java.awt.Color super$getSelectionForeground()
        {
        return super.getSelectionForeground();
        }
    public java.awt.Dimension getSize()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get_Size();
        }
    java.awt.Dimension super$getSize()
        {
        return super.getSize();
        }
    public int getFirstVisibleIndex()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getFirstVisibleIndex();
        }
    int super$getFirstVisibleIndex()
        {
        return super.getFirstVisibleIndex();
        }
    public int getFixedCellHeight()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getFixedCellHeight();
        }
    int super$getFixedCellHeight()
        {
        return super.getFixedCellHeight();
        }
    public int getFixedCellWidth()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getFixedCellWidth();
        }
    int super$getFixedCellWidth()
        {
        return super.getFixedCellWidth();
        }
    public int getLastVisibleIndex()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getLastVisibleIndex();
        }
    int super$getLastVisibleIndex()
        {
        return super.getLastVisibleIndex();
        }
    public int getLeadSelectionIndex()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getLeadSelectionIndex();
        }
    int super$getLeadSelectionIndex()
        {
        return super.getLeadSelectionIndex();
        }
    public int getMaxSelectionIndex()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getMaxSelectionIndex();
        }
    int super$getMaxSelectionIndex()
        {
        return super.getMaxSelectionIndex();
        }
    public int getMinSelectionIndex()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getMinSelectionIndex();
        }
    int super$getMinSelectionIndex()
        {
        return super.getMinSelectionIndex();
        }
    public int getSelectedIndex()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectedIndex();
        }
    int super$getSelectedIndex()
        {
        return super.getSelectedIndex();
        }
    public int[] getSelectedIndices()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectedIndices();
        }
    int[] super$getSelectedIndices()
        {
        return super.getSelectedIndices();
        }
    public Object getSelectedValue()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectedValue();
        }
    Object super$getSelectedValue()
        {
        return super.getSelectedValue();
        }
    public Object[] getSelectedValues()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectedValues();
        }
    Object[] super$getSelectedValues()
        {
        return super.getSelectedValues();
        }
    public int getSelectionMode()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSelectionMode();
        }
    int super$getSelectionMode()
        {
        return super.getSelectionMode();
        }
    public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent e)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipLocation(e);
        }
    java.awt.Point super$getToolTipLocation(java.awt.event.MouseEvent e)
        {
        return super.getToolTipLocation(e);
        }
    public String getToolTipText()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText();
        }
    String super$getToolTipText()
        {
        return super.getToolTipText();
        }
    public String getToolTipText(java.awt.event.MouseEvent e)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getToolTipText(e);
        }
    String super$getToolTipText(java.awt.event.MouseEvent e)
        {
        return super.getToolTipText(e);
        }
    public int getVisibleRowCount()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getVisibleRowCount();
        }
    int super$getVisibleRowCount()
        {
        return super.getVisibleRowCount();
        }
    public boolean getValueIsAdjusting()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isAdjusting();
        }
    boolean super$getValueIsAdjusting()
        {
        return super.getValueIsAdjusting();
        }
    public boolean getAutoscrolls()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isAutoscrolls();
        }
    boolean super$getAutoscrolls()
        {
        return super.getAutoscrolls();
        }
    public boolean isEnabled()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isEnabled();
        }
    boolean super$isEnabled()
        {
        return super.isEnabled();
        }
    public boolean isFocusTraversable()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isFocusTraversable();
        }
    boolean super$isFocusTraversable()
        {
        return super.isFocusTraversable();
        }
    public boolean isSelectedIndex(int index)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isItemSelectedAt(index);
        }
    boolean super$isSelectedIndex(int index)
        {
        return super.isSelectedIndex(index);
        }
    public boolean isOpaque()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isOpaque();
        }
    boolean super$isOpaque()
        {
        return super.isOpaque();
        }
    public boolean isSelectionEmpty()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isSelectionEmpty();
        }
    boolean super$isSelectionEmpty()
        {
        return super.isSelectionEmpty();
        }
    public boolean isShowing()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isShowing();
        }
    boolean super$isShowing()
        {
        return super.isShowing();
        }
    public boolean isVisible()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.isVisible();
        }
    boolean super$isVisible()
        {
        return super.isVisible();
        }
    public void paint(java.awt.Graphics g)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paint(g);
        }
    void super$paint(java.awt.Graphics g)
        {
        super.paint(g);
        }
    protected void paintBorder(java.awt.Graphics g)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintBorder(g);
        }
    void super$paintBorder(java.awt.Graphics g)
        {
        super.paintBorder(g);
        }
    protected void paintChildren(java.awt.Graphics g)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintChildren(g);
        }
    void super$paintChildren(java.awt.Graphics g)
        {
        super.paintChildren(g);
        }
    protected void paintComponent(java.awt.Graphics g)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintComponent(g);
        }
    void super$paintComponent(java.awt.Graphics g)
        {
        super.paintComponent(g);
        }
    public void removeFocusListener(java.awt.event.FocusListener l)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeFocusListener(l);
        }
    void super$removeFocusListener(java.awt.event.FocusListener l)
        {
        super.removeFocusListener(l);
        }
    public void removeKeyListener(java.awt.event.KeyListener l)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeKeyListener(l);
        }
    void super$removeKeyListener(java.awt.event.KeyListener l)
        {
        super.removeKeyListener(l);
        }
    public void removeListSelectionListener(javax.swing.event.ListSelectionListener l)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeListSelectionListener(l);
        }
    void super$removeListSelectionListener(javax.swing.event.ListSelectionListener l)
        {
        super.removeListSelectionListener(l);
        }
    public void removeMouseListener(java.awt.event.MouseListener l)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseListener(l);
        }
    void super$removeMouseListener(java.awt.event.MouseListener l)
        {
        super.removeMouseListener(l);
        }
    public void removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMouseMotionListener(l);
        }
    void super$removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        super.removeMouseMotionListener(l);
        }
    public void removeNotify()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeNotify();
        }
    void super$removeNotify()
        {
        super.removeNotify();
        }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removePropertyChangeListener(l);
        }
    void super$removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        super.removePropertyChangeListener(l);
        }
    public void removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeVetoableChangeListener(l);
        }
    void super$removeVetoableChangeListener(java.beans.VetoableChangeListener l)
        {
        super.removeVetoableChangeListener(l);
        }
    public void requestFocus()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.requestFocus();
        }
    void super$requestFocus()
        {
        super.requestFocus();
        }
    public void setBackground(java.awt.Color p_Background)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Background(p_Background);
        }
    void super$setBackground(java.awt.Color p_Background)
        {
        super.setBackground(p_Background);
        }
    public void setBorder(javax.swing.border.Border p_Border)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Border(p_Border);
        }
    void super$setBorder(javax.swing.border.Border p_Border)
        {
        super.setBorder(p_Border);
        }
    public void setBounds(java.awt.Rectangle p_Bounds)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Bounds(p_Bounds);
        }
    void super$setBounds(java.awt.Rectangle p_Bounds)
        {
        super.setBounds(p_Bounds);
        }
    public void setCursor(java.awt.Cursor p_Cursor)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Cursor(p_Cursor);
        }
    void super$setCursor(java.awt.Cursor p_Cursor)
        {
        super.setCursor(p_Cursor);
        }
    public void setFont(java.awt.Font p_Font)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Font(p_Font);
        }
    void super$setFont(java.awt.Font p_Font)
        {
        super.setFont(p_Font);
        }
    public void setForeground(java.awt.Color p_Foreground)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Foreground(p_Foreground);
        }
    void super$setForeground(java.awt.Color p_Foreground)
        {
        super.setForeground(p_Foreground);
        }
    public void setLayout(java.awt.LayoutManager p_Layout)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Layout(p_Layout);
        }
    void super$setLayout(java.awt.LayoutManager p_Layout)
        {
        super.setLayout(p_Layout);
        }
    public void setLocation(java.awt.Point p_Location)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Location(p_Location);
        }
    void super$setLocation(java.awt.Point p_Location)
        {
        super.setLocation(p_Location);
        }
    public void setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MaximumSize(p_MaximumSize);
        }
    void super$setMaximumSize(java.awt.Dimension p_MaximumSize)
        {
        super.setMaximumSize(p_MaximumSize);
        }
    public void setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_MinimumSize(p_MinimumSize);
        }
    void super$setMinimumSize(java.awt.Dimension p_MinimumSize)
        {
        super.setMinimumSize(p_MinimumSize);
        }
    public void setModel(javax.swing.ListModel pModel)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Model(pModel);
        }
    void super$setModel(javax.swing.ListModel pModel)
        {
        super.setModel(pModel);
        }
    public void setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_PreferredSize(p_PreferredSize);
        }
    void super$setPreferredSize(java.awt.Dimension p_PreferredSize)
        {
        super.setPreferredSize(p_PreferredSize);
        }
    public void setSelectionBackground(java.awt.Color p_SelectionBackground)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_SelectionBackground(p_SelectionBackground);
        }
    void super$setSelectionBackground(java.awt.Color p_SelectionBackground)
        {
        super.setSelectionBackground(p_SelectionBackground);
        }
    public void setSelectionForeground(java.awt.Color p_SelectionForeground)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_SelectionForeground(p_SelectionForeground);
        }
    void super$setSelectionForeground(java.awt.Color p_SelectionForeground)
        {
        super.setSelectionForeground(p_SelectionForeground);
        }
    public void setSize(java.awt.Dimension p_Size)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.set_Size(p_Size);
        }
    void super$setSize(java.awt.Dimension p_Size)
        {
        super.setSize(p_Size);
        }
    public void setValueIsAdjusting(boolean pAdjusting)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setAdjusting(pAdjusting);
        }
    void super$setValueIsAdjusting(boolean pAdjusting)
        {
        super.setValueIsAdjusting(pAdjusting);
        }
    public void setAutoscrolls(boolean pAutoscrolls)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setAutoscrolls(pAutoscrolls);
        }
    void super$setAutoscrolls(boolean pAutoscrolls)
        {
        super.setAutoscrolls(pAutoscrolls);
        }
    public void setEnabled(boolean pEnabled)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setEnabled(pEnabled);
        }
    void super$setEnabled(boolean pEnabled)
        {
        super.setEnabled(pEnabled);
        }
    public void setFixedCellHeight(int pFixedCellHeight)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setFixedCellHeight(pFixedCellHeight);
        }
    void super$setFixedCellHeight(int pFixedCellHeight)
        {
        super.setFixedCellHeight(pFixedCellHeight);
        }
    public void setFixedCellWidth(int pFixedCellWidth)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setFixedCellWidth(pFixedCellWidth);
        }
    void super$setFixedCellWidth(int pFixedCellWidth)
        {
        super.setFixedCellWidth(pFixedCellWidth);
        }
    public void setOpaque(boolean pOpaque)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setOpaque(pOpaque);
        }
    void super$setOpaque(boolean pOpaque)
        {
        super.setOpaque(pOpaque);
        }
    public void setSelectedIndex(int pSelectedIndex)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setSelectedIndex(pSelectedIndex);
        }
    void super$setSelectedIndex(int pSelectedIndex)
        {
        super.setSelectedIndex(pSelectedIndex);
        }
    public void setSelectedIndices(int[] pSelectedIndicies)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setSelectedIndices(pSelectedIndicies);
        }
    void super$setSelectedIndices(int[] pSelectedIndicies)
        {
        super.setSelectedIndices(pSelectedIndicies);
        }
    public void setSelectedValue(Object value, boolean shouldScroll)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setSelectedValue(value, shouldScroll);
        }
    void super$setSelectedValue(Object value, boolean shouldScroll)
        {
        super.setSelectedValue(value, shouldScroll);
        }
    public void setSelectionInterval(int anchor, int lead)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setSelectionInterval(anchor, lead);
        }
    void super$setSelectionInterval(int anchor, int lead)
        {
        super.setSelectionInterval(anchor, lead);
        }
    public void setSelectionMode(int pSelectionMode)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setSelectionMode(pSelectionMode);
        }
    void super$setSelectionMode(int pSelectionMode)
        {
        super.setSelectionMode(pSelectionMode);
        }
    public void setToolTipText(String pToolTipText)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setToolTipText(pToolTipText);
        }
    void super$setToolTipText(String pToolTipText)
        {
        super.setToolTipText(pToolTipText);
        }
    public void setVisible(boolean pVisible)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVisible(pVisible);
        }
    void super$setVisible(boolean pVisible)
        {
        super.setVisible(pVisible);
        }
    public void setVisibleRowCount(int pVisibleRowCount)
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setVisibleRowCount(pVisibleRowCount);
        }
    void super$setVisibleRowCount(int pVisibleRowCount)
        {
        super.setVisibleRowCount(pVisibleRowCount);
        }
    public void updateUI()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.updateUI();
        }
    void super$updateUI()
        {
        super.updateUI();
        }
    public void validate()
        {
        JList peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.validate();
        }
    void super$validate()
        {
        super.validate();
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
