/* Class
*     _package.component.gUI.control.container.jComponent.JTree
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.Dimension;
import _package.component.gUI.Point;
import _package.component.gUI.Rectangle;
import _package.component.gUI.TreeNode;
import _package.component.gUI.image.Icon;
import _package.component.util.Config;
import com.tangosol.run.component.EventDeathException;
import java.awt.datatransfer.StringSelection;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JComponent; // as _JComponent
import javax.swing.JToolTip;
import javax.swing.JTree; // as _JTree
import javax.swing.ToolTipManager;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeCellEditor;
import javax.swing.tree.TreeCellRenderer;
import javax.swing.tree.TreePath;

/*
* Integrates
*     javax.swing.JTree
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JTree
        extends    _package.component.gUI.control.container.JComponent
        implements javax.swing.event.CellEditorListener,
                   javax.swing.event.TreeExpansionListener,
                   javax.swing.event.TreeSelectionListener
    {
    // Fields declarations
    
    /**
    * Property CaseSensitive
    *
    * Specifies whether the sorting should be case sensitive (assuming there is
    * no specified Collator).
    * 
    * @see #makeNode
    * @see Component.GUI.TreeNode#CaseSensitive
    */
    private boolean __m_CaseSensitive;
    
    /**
    * Property CellEditor
    *
    */
    private transient javax.swing.tree.TreeCellEditor __m_CellEditor;
    
    /**
    * Property CellRenderer
    *
    */
    private transient javax.swing.tree.TreeCellRenderer __m_CellRenderer;
    
    /**
    * Property ClosedIcon
    *
    */
    private transient _package.component.gUI.image.Icon __m_ClosedIcon;
    
    /**
    * Property CollapsedIcon
    *
    */
    private transient _package.component.gUI.image.Icon __m_CollapsedIcon;
    
    /**
    * Property Collator
    *
    * Collator used to sort the nodes in this tree. If not specified, the
    * default string comparison (String.compareTo()) is used.
    * 
    * @see #makeNode
    * @see Component.GUI.TreeNode#add
    */
    private java.text.Collator __m_Collator;
    
    /**
    * Property Editable
    *
    * Specifies whether the nodes of the tree are editable. Nodes editability
    * is also controlled individually.
    * 
    * @see TreeNode#Editable property
    */
    private transient boolean __m_Editable;
    
    /**
    * Property Editing
    *
    * (Calculated) Specifies whether if the tree is being edited. The item that
    * is being edited can be obtained using <code>SelectionNode</code> property.
    */
    
    /**
    * Property EditingNode
    *
    * Specifies the node that is currently editing.
    * 
    * @see #startEditingAtPath
    * @see #editingStopped
    * @see #editingCaanceled
    */
    private _package.component.gUI.TreeNode __m_EditingNode;
    
    /**
    * Property ExpandedIcon
    *
    */
    private transient _package.component.gUI.image.Icon __m_ExpandedIcon;
    
    /**
    * Property InvokesStopCellEditing
    *
    * Determines what happens when editing is interrupted by selecting another
    * node in the tree, a change in the tree's data, or by some other means.
    * Setting this property to <code>true</code> causes the changes to be
    * automatically saved when editing is interrupted.
    */
    private transient boolean __m_InvokesStopCellEditing;
    
    /**
    * Property LargeModel
    *
    */
    private transient boolean __m_LargeModel;
    
    /**
    * Property LeafIcon
    *
    */
    private transient _package.component.gUI.image.Icon __m_LeafIcon;
    
    /**
    * Property Model
    *
    */
    
    /**
    * Property OpenIcon
    *
    */
    private transient _package.component.gUI.image.Icon __m_OpenIcon;
    
    /**
    * Property PreferredCellSize
    *
    */
    private transient _package.component.gUI.Dimension __m_PreferredCellSize;
    
    /**
    * Property Redraw
    *
    * If set to false, changes to the tree structure are not made visible until
    * this property is set back to true.
    * Used to optimize the redrawing performance during "bulk" inserts and
    * removes.
    */
    private boolean __m_Redraw;
    
    /**
    * Property Root
    *
    * Specifies the root node ot the tree.
    */
    private transient _package.component.gUI.TreeNode __m_Root;
    
    /**
    * Property RootVisible
    *
    * Specifies whether or not the root node of the tree is displayed.
    */
    private transient boolean __m_RootVisible;
    
    /**
    * Property RowCount
    *
    * (Calculated) Specifies the number of rows that are currently being
    * displayed.
    */
    
    /**
    * Property RowHeight
    *
    * Specifies the height of each cell. If the specified value is less than or
    * equal to zero the current cell renderer is queried for each row's height.
    */
    private transient int __m_RowHeight;
    
    /**
    * Property ScrollsOnExpand
    *
    */
    private transient boolean __m_ScrollsOnExpand;
    
    /**
    * Property SelectionId
    *
    * Specifies the Id of the selection node.
    */
    private transient String __m_SelectionId;
    
    /**
    * Property SelectionMode
    *
    * Valid values are:
    * 
    * SINGLE_TREE_SELECTION = 1;
    * CONTIGUOUS_TREE_SELECTION = 2;
    * DISCONTIGUOUS_TREE_SELECTION = 4;
    * 
    * @see javax.swing.tree.TreeSelectionModel
    */
    private transient int __m_SelectionMode;
    
    /**
    * Property SelectionNode
    *
    * Specifies the currently selected node.
    */
    private transient _package.component.gUI.TreeNode __m_SelectionNode;
    
    /**
    * Property Separator
    *
    * Specifies the separator used to generate node id(s).
    */
    private char __m_Separator;
    
    /**
    * Property ShowNodeTips
    *
    * Specifies whether the Tree will show the tool tips for the individual
    * nodes of this tree. If set to true, a call to the
    * getToolTipText(TreeNode) is made to obtain the text for the specified
    * node.
    * 
    * @see #getToolTipLocation
    * @see #getToolTipText(MouseEvent)
    * @see #getToolTipText(TreeNode)
    */
    private boolean __m_ShowNodeTips;
    
    /**
    * Property ShowsRootHandles
    *
    * Specifies whether handles are displayed at the topmost level of the tree.
    * If the <code>rootVisible</code> setting specifies that the root node is
    * to be displayed, then that is the only node at the topmost level. If the
    * root node is not displayed, then all of its  children are at the topmost
    * level of the tree. Handles are always displayed for nodes other than the
    * topmost.
    * If the root node isn't visible, it is generally a good to make this value
    * true. Otherwise, the tree looks exactly like a list, and users may not
    * know that the "list entries" are actually tree nodes.
    */
    private transient boolean __m_ShowsRootHandles;
    
    /**
    * Property Sorted
    *
    * Specifies whether the tree is sorted. If set to true all the nodes will
    * be made sorted as well.
    * 
    * @see Component.GUI.TreeNode#Sorted
    */
    private boolean __m_Sorted;
    
    /**
    * Property ToggleClickCount
    *
    * Specifies the number of mouse clicks before a node will expand or close.
    * The default is two.
    */
    private transient int __m_ToggleClickCount;
    
    /**
    * Property VisibleRowCount
    *
    * Specifies the number of rows that are displayed in the display area. 
    * Setting this property will only work if the JTree is scrollable and will
    * adjust the preferred size and size of the scrollpane.
    */
    private transient int __m_VisibleRowCount;
    
    // fields used by the integration model:
    private sink_JTree __sink;
    private javax.swing.JTree __feed;
    
    // Default constructor
    public JTree()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JTree(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setEditable(false);
            setFocusable(true);
            setLargeModel(false);
            setRedraw(true);
            setRootVisible(false);
            setRowHeight(16);
            setScrollsOnExpand(true);
            setSelectionMode(1);
            setSeparator('.');
            setShowsRootHandles(true);
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new JTree$KeyCollapse("KeyCollapse", this, true), "KeyCollapse");
        _addChild(new JTree$KeyExpand("KeyExpand", this, true), "KeyExpand");
        _addChild(new JTree$KeyExpandAll("KeyExpandAll", this, true), "KeyExpandAll");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JTree.__tloPeer.setObject(this);
            new jb_JTree(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        super.__initEvents();
        
        addTreeExpansionListener(this);
        addTreeSelectionListener(this);
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new JTree();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JTree".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ TreeExpansionListener dispatcher
    private com.tangosol.util.Listeners __TreeExpansionListeners;
    private void addTreeExpansionListener$Router(javax.swing.event.TreeExpansionListener l)
        {
        __sink.addTreeExpansionListener(l);
        }
    public void addTreeExpansionListener(javax.swing.event.TreeExpansionListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __TreeExpansionListeners;
        if (_listeners == null)
            {
            __TreeExpansionListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addTreeExpansionListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeTreeExpansionListener$Router(javax.swing.event.TreeExpansionListener l)
        {
        __sink.removeTreeExpansionListener(l);
        }
    public void removeTreeExpansionListener(javax.swing.event.TreeExpansionListener l)
        {
        com.tangosol.util.Listeners _listeners = __TreeExpansionListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeTreeExpansionListener$Router(this);
            }
        }
    private void treeCollapsed$Dispatch(javax.swing.event.TreeExpansionEvent e)
        {
        java.util.EventListener[] targets = __TreeExpansionListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.TreeExpansionListener target = (javax.swing.event.TreeExpansionListener) targets[i];
            if (target != this)
                {
                target.treeCollapsed(e);
                }
            }
        }
    public void treeCollapsed(javax.swing.event.TreeExpansionEvent e)
        {
        try
            {
            if (is_Constructed())
                {
                onCollapsed(makeNode(e.getPath()));
                }
            }
        catch (EventDeathException ex)
            {
            return;
            }
        treeCollapsed$Dispatch(e);
        }
    private void treeExpanded$Dispatch(javax.swing.event.TreeExpansionEvent e)
        {
        java.util.EventListener[] targets = __TreeExpansionListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.TreeExpansionListener target = (javax.swing.event.TreeExpansionListener) targets[i];
            if (target != this)
                {
                target.treeExpanded(e);
                }
            }
        }
    public void treeExpanded(javax.swing.event.TreeExpansionEvent e)
        {
        try
            {
            if (is_Constructed())
                {
                onExpanded(makeNode(e.getPath()));
                }
            }
        catch (EventDeathException ex)
            {
            return;
            }
        treeExpanded$Dispatch(e);
        }
    //-- TreeExpansionListener dispatcher
    
    //++ TreeSelectionListener dispatcher
    private com.tangosol.util.Listeners __TreeSelectionListeners;
    private void addTreeSelectionListener$Router(javax.swing.event.TreeSelectionListener l)
        {
        __sink.addTreeSelectionListener(l);
        }
    public void addTreeSelectionListener(javax.swing.event.TreeSelectionListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __TreeSelectionListeners;
        if (_listeners == null)
            {
            __TreeSelectionListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addTreeSelectionListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeTreeSelectionListener$Router(javax.swing.event.TreeSelectionListener l)
        {
        __sink.removeTreeSelectionListener(l);
        }
    public void removeTreeSelectionListener(javax.swing.event.TreeSelectionListener l)
        {
        com.tangosol.util.Listeners _listeners = __TreeSelectionListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeTreeSelectionListener$Router(this);
            }
        }
    private void valueChanged$Dispatch(javax.swing.event.TreeSelectionEvent e)
        {
        java.util.EventListener[] targets = __TreeSelectionListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.TreeSelectionListener target = (javax.swing.event.TreeSelectionListener) targets[i];
            if (target != this)
                {
                target.valueChanged(e);
                }
            }
        }
    public void valueChanged(javax.swing.event.TreeSelectionEvent e)
        {
        try
            {
            // only when the previosly selected item gets unselected as a result
            // of closing the tree branch it is in, isAddedPath() will report "false"
            if (is_Constructed() && e.isAddedPath())
                {
                // we could also pass "e.makeNode(e.getOldLeadSelectionPath())"
                onSelected(makeNode(e.getNewLeadSelectionPath()));
                }
            }
        catch (EventDeathException ex)
            {
            return;
            }
        valueChanged$Dispatch(e);
        }
    //-- TreeSelectionListener dispatcher
    
    //++ javax.swing.JTree integration
    // Access optimization
    /**
    * Setter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JTree) pSink;
        super.set_Sink(pSink);
        }
    /**
    * Setter for property _Feed.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JTree) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public void addNotify()
        {
        // import javax.swing.ToolTipManager;
        
        super.addNotify();
        
        if (isShowNodeTips())
            {
            ToolTipManager.sharedInstance().registerComponent((_JTree) get_Feed());
            }
        }
    /**
    * Return a location for the ToolTip in the receiving component coordinate
    * system. If null is returned, Swing will choose a location. The default
    * implementation returns null.
    * Return a location for the ToolTip in the receiving component coordinate
    * system. If null is returned, Swing will choose a location. The default
    * implementation returns null.
    * 
    * +++++++++++++++++++++++
    * 
    * The problem with the implementation in JDK 1.2 is that the tool tip
    * window gets created at the location where the mouse is, so any mouseMove
    * event immediately generates mouseExit, which in turn hides the ToolTip
    * (sometimes generating flickering). To cope with this we are intercepting
    * the mouseExit and don't deliver the event if the tip is showing.
    * 
    * @see #onMouseExited
    * @see javax.swing.ToolTipManager#mouseExited
    */
    public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent e)
        {
        // import Component.GUI.Point;
        
        if (isShowNodeTips())
            {
            TreeNode node = getNodeForLocation(Point.instantiate(e.getX(), e.getY()));
        
            return node != null && getToolTipText(node) != null ?
                getNodeBounds(node).getLocation().get_Point() : null;
            }
        else
            {
            return super.getToolTipLocation(e);
            }
        }
    /**
    * Returns the string to be used as the tooltip for <i>event</i>.  By
    * default this returns a value of ToolTipText property.  If a component
    * provides more extensive API to support differing tooltips at different
    * locations, this method should be overridden.
    */
    public String getToolTipText(java.awt.event.MouseEvent e)
        {
        // import Component.GUI.Point;
        
        if (isShowNodeTips())
            {
            TreeNode node = getNodeForLocation(Point.instantiate(e.getX(), e.getY()));
        
            return getToolTipText(node);
            }
        else
            {
            return super.getToolTipText(e);
            }
        }
    public void removeNotify()
        {
        // import javax.swing.ToolTipManager;
        
        if (isShowNodeTips())
            {
            ToolTipManager.sharedInstance().unregisterComponent((_JTree) get_Feed());
            }
        
        super.removeNotify();
        }
    public void updateUI()
        {
        TreeCellRenderer rendererOld = getCellRenderer();
        
        super.updateUI();
        
        TreeCellRenderer rendererNew = getCellRenderer();
        
        if (rendererOld != rendererNew &&
            rendererOld instanceof DefaultTreeCellRenderer &&
            rendererNew instanceof DefaultTreeCellRenderer)
            {
            DefaultTreeCellRenderer rndOld = (DefaultTreeCellRenderer) rendererOld;
            DefaultTreeCellRenderer rndNew = (DefaultTreeCellRenderer) rendererNew;
            javax.swing.Icon _icon;
        
            _icon = rndOld.getClosedIcon();
            if (_icon == null || _icon instanceof Icon)
                {
                rndNew.setClosedIcon((Icon) _icon);
                }
            _icon = rndOld.getLeafIcon();
            if (_icon == null || _icon instanceof Icon)
                {
                rndNew.setLeafIcon((Icon) _icon);
                }
            _icon = rndOld.getOpenIcon();
            if (_icon == null || _icon instanceof Icon)
                {
                rndNew.setOpenIcon((Icon) _icon);
                }
            }
        }
    /**
    * Cancels the current editing session. Has no effect if the tree isn't
    * being edited.
    */
    public void cancelEditing()
        {
        __sink.cancelEditing();
        }
    private String convertValueToText$Router(Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus)
        {
        return __sink.convertValueToText(value, selected, expanded, leaf, row, hasFocus);
        }
    /**
    * This method is called by the renderers to convert the specified value to
    * text. Default implementation returns value.toString(), ignoring all other
    * arguments. To control the conversion, override this method and use any of
    * the arguments you need.
    */
    public String convertValueToText(Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus)
        {
        if (is_Constructed() && value instanceof DefaultMutableTreeNode)
            {
            onCellRendering((java.awt.Component) getCellRenderer(), makeNode(value), hasFocus); 
            }
        
        return value != null ? value.toString() : "";
        }
    /**
    * Getter for property CellEditor.<p>
    */
    public javax.swing.tree.TreeCellEditor getCellEditor()
        {
        return __sink.getCellEditor();
        }
    /**
    * Getter for property CellRenderer.<p>
    */
    public javax.swing.tree.TreeCellRenderer getCellRenderer()
        {
        return __sink.getCellRenderer();
        }
    /**
    * Getter for property InvokesStopCellEditing.<p>
    * Determines what happens when editing is interrupted by selecting another
    * node in the tree, a change in the tree's data, or by some other means.
    * Setting this property to <code>true</code> causes the changes to be
    * automatically saved when editing is interrupted.
    */
    public boolean isInvokesStopCellEditing()
        {
        return __sink.getInvokesStopCellEditing();
        }
    /**
    * Getter for property RowCount.<p>
    * (Calculated) Specifies the number of rows that are currently being
    * displayed.
    */
    public int getRowCount()
        {
        return __sink.getRowCount();
        }
    /**
    * Getter for property RowHeight.<p>
    * Specifies the height of each cell. If the specified value is less than or
    * equal to zero the current cell renderer is queried for each row's height.
    */
    public int getRowHeight()
        {
        return __sink.getRowHeight();
        }
    /**
    * Getter for property ScrollsOnExpand.<p>
    */
    public boolean isScrollsOnExpand()
        {
        return __sink.getScrollsOnExpand();
        }
    /**
    * Getter for property ShowsRootHandles.<p>
    * Specifies whether handles are displayed at the topmost level of the tree.
    * If the <code>rootVisible</code> setting specifies that the root node is
    * to be displayed, then that is the only node at the topmost level. If the
    * root node is not displayed, then all of its  children are at the topmost
    * level of the tree. Handles are always displayed for nodes other than the
    * topmost.
    * If the root node isn't visible, it is generally a good to make this value
    * true. Otherwise, the tree looks exactly like a list, and users may not
    * know that the "list entries" are actually tree nodes.
    */
    public boolean isShowsRootHandles()
        {
        return __sink.getShowsRootHandles();
        }
    /**
    * Getter for property ToggleClickCount.<p>
    * Specifies the number of mouse clicks before a node will expand or close.
    * The default is two.
    */
    public int getToggleClickCount()
        {
        return __sink.getToggleClickCount();
        }
    /**
    * Getter for property VisibleRowCount.<p>
    * Specifies the number of rows that are displayed in the display area. 
    * Setting this property will only work if the JTree is scrollable and will
    * adjust the preferred size and size of the scrollpane.
    */
    public int getVisibleRowCount()
        {
        return __sink.getVisibleRowCount();
        }
    public boolean isCollapsed(javax.swing.tree.TreePath path)
        {
        return __sink.isCollapsed(path);
        }
    /**
    * Getter for property Editable.<p>
    * Specifies whether the nodes of the tree are editable. Nodes editability
    * is also controlled individually.
    * 
    * @see TreeNode#Editable property
    */
    public boolean isEditable()
        {
        return __sink.isEditable();
        }
    /**
    * Getter for property Editing.<p>
    * (Calculated) Specifies whether if the tree is being edited. The item that
    * is being edited can be obtained using <code>SelectionNode</code> property.
    */
    public boolean isEditing()
        {
        return __sink.isEditing();
        }
    public boolean isExpanded(javax.swing.tree.TreePath path)
        {
        return __sink.isExpanded(path);
        }
    /**
    * Getter for property LargeModel.<p>
    */
    public boolean isLargeModel()
        {
        return __sink.isLargeModel();
        }
    private boolean isPathEditable$Router(javax.swing.tree.TreePath path)
        {
        return __sink.isPathEditable(path);
        }
    /**
    * This is invoked from the UI before editing begins to insure that the
    * given path can be edited. This method is provided as an entry point for
    * subclassers to add filtered editing without having to resort to creating
    * a new editor. <p>
    * The implementation just returns <code>isEditable()</code>
    */
    public boolean isPathEditable(javax.swing.tree.TreePath path)
        {
        Object _node = ((TreePath) path).getLastPathComponent();
        
        if (_node instanceof DefaultMutableTreeNode)
            {
            Object node = ((DefaultMutableTreeNode) _node).getUserObject();
            if (node instanceof TreeNode)
                {
                return ((TreeNode) node).isEditable();
                }
            }
        return isPathEditable$Router(path);
        }
    /**
    * Getter for property RootVisible.<p>
    * Specifies whether or not the root node of the tree is displayed.
    */
    public boolean isRootVisible()
        {
        return __sink.isRootVisible();
        }
    private void setCellEditor$Router(javax.swing.tree.TreeCellEditor pCellEditor)
        {
        __sink.setCellEditor(pCellEditor);
        }
    /**
    * Setter for property CellEditor.<p>
    */
    public void setCellEditor(javax.swing.tree.TreeCellEditor pCellEditor)
        {
        // import javax.swing.tree.TreeCellEditor;
        
        TreeCellEditor editor = getCellEditor();
        if (editor != null)
            {
            editor.removeCellEditorListener(this);
            }
        
        // The order in which "addCellEditorListener" and "setCellEditor$Router"
        // are called causes the editingStopped() notification be called before or
        // after the call to BasicTreeUI.editingStopped().
        // See editingStopped() for further discussion.
        
        setCellEditor$Router(pCellEditor);
        
        if (pCellEditor != null)
            {
            pCellEditor.addCellEditorListener(this);
            }
        
        // setCellEditor$Router(pCellEditor);

        }
    /**
    * Setter for property CellRenderer.<p>
    */
    public void setCellRenderer(javax.swing.tree.TreeCellRenderer pCellRenderer)
        {
        __sink.setCellRenderer(pCellRenderer);
        }
    /**
    * Setter for property Editable.<p>
    * Specifies whether the nodes of the tree are editable. Nodes editability
    * is also controlled individually.
    * 
    * @see TreeNode#Editable property
    */
    public void setEditable(boolean pEditable)
        {
        __sink.setEditable(pEditable);
        }
    /**
    * Setter for property InvokesStopCellEditing.<p>
    * Determines what happens when editing is interrupted by selecting another
    * node in the tree, a change in the tree's data, or by some other means.
    * Setting this property to <code>true</code> causes the changes to be
    * automatically saved when editing is interrupted.
    */
    public void setInvokesStopCellEditing(boolean pInvokesStopCellEditing)
        {
        __sink.setInvokesStopCellEditing(pInvokesStopCellEditing);
        }
    /**
    * Setter for property LargeModel.<p>
    */
    public void setLargeModel(boolean pLargeModel)
        {
        __sink.setLargeModel(pLargeModel);
        }
    /**
    * Setter for property RootVisible.<p>
    * Specifies whether or not the root node of the tree is displayed.
    */
    public void setRootVisible(boolean pRootVisible)
        {
        __sink.setRootVisible(pRootVisible);
        }
    /**
    * Setter for property RowHeight.<p>
    * Specifies the height of each cell. If the specified value is less than or
    * equal to zero the current cell renderer is queried for each row's height.
    */
    public void setRowHeight(int pRowHeight)
        {
        __sink.setRowHeight(pRowHeight);
        }
    /**
    * Setter for property ScrollsOnExpand.<p>
    */
    public void setScrollsOnExpand(boolean pScrollsOnExpand)
        {
        __sink.setScrollsOnExpand(pScrollsOnExpand);
        }
    private void setShowsRootHandles$Router(boolean pShowsRootHandles)
        {
        __sink.setShowsRootHandles(pShowsRootHandles);
        }
    /**
    * Setter for property ShowsRootHandles.<p>
    * Specifies whether handles are displayed at the topmost level of the tree.
    * If the <code>rootVisible</code> setting specifies that the root node is
    * to be displayed, then that is the only node at the topmost level. If the
    * root node is not displayed, then all of its  children are at the topmost
    * level of the tree. Handles are always displayed for nodes other than the
    * topmost.
    * If the root node isn't visible, it is generally a good to make this value
    * true. Otherwise, the tree looks exactly like a list, and users may not
    * know that the "list entries" are actually tree nodes.
    */
    public void setShowsRootHandles(boolean pShowsRootHandles)
        {
        setShowsRootHandles$Router(pShowsRootHandles);
        
        // Metal PLAF using the "JTree.lineStyle" property:
        // with value domain: "Angled", "Horizontal", "None"
        
        ((_JTree) get_Feed()).putClientProperty("JTree.lineStyle",
            pShowsRootHandles ? "Angled" : "None");
        }
    /**
    * Setter for property ToggleClickCount.<p>
    * Specifies the number of mouse clicks before a node will expand or close.
    * The default is two.
    */
    public void setToggleClickCount(int pToggleClickCount)
        {
        __sink.setToggleClickCount(pToggleClickCount);
        }
    /**
    * Setter for property VisibleRowCount.<p>
    * Specifies the number of rows that are displayed in the display area. 
    * Setting this property will only work if the JTree is scrollable and will
    * adjust the preferred size and size of the scrollpane.
    */
    public void setVisibleRowCount(int pVisibleRowCount)
        {
        __sink.setVisibleRowCount(pVisibleRowCount);
        }
    private void startEditingAtPath$Router(javax.swing.tree.TreePath path)
        {
        __sink.startEditingAtPath(path);
        }
    /**
    * Selects the node identified by the specified path and initiates editing. 
    * The edit-attempt fails if the CellEditor does not allow editing for the
    * specified item.
    * 
    * @see #makeNode
    * @see #editingStopped
    * @see TreeNode#startEditing
    */
    public void startEditingAtPath(javax.swing.tree.TreePath path)
        {
        Object _node = ((TreePath) path).getLastPathComponent();
        
        if (_node instanceof DefaultMutableTreeNode)
            {
            Object obj = ((DefaultMutableTreeNode) _node).getUserObject();
            if (obj instanceof TreeNode)
                {
                TreeNode node = (TreeNode) obj;
                try
                    {
                    onEditingStarting(node);
                    setEditingNode(node);
                    }
                catch (EventDeathException ex)
                    {
                    // don't start editing
                    return;
                    }
                }
            }
        startEditingAtPath$Router(path);
        }
    /**
    * Ends the current editing session. (The DefaultTreeCellEditor object saves
    * any edits that are currently in progress on a cell. Other implementations
    * may operate differently.) Has no effect if the tree isn't being edited.
    * <blockquote> <b>Note:</b><br>
    * To make edit-saves automatic whenever the user changes their position in
    * the tree, use {@link #setInvokesStopCellEditing}. </blockquote>
    */
    public boolean stopEditing()
        {
        return __sink.stopEditing();
        }
    //-- javax.swing.JTree integration
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Image.Icon;
        // import Component.GUI.TreeNode;
        // import javax.swing.tree.DefaultMutableTreeNode;
        // import javax.swing.tree.DefaultTreeModel;
        // import javax.swing.tree.DefaultTreeCellRenderer;
        // import javax.swing.tree.TreeCellRenderer;
        // import javax.swing.tree.TreePath;
        // import javax.swing.JTree as _JTree;
        // import com.tangosol.run.component.EventDeathException;
        
        

        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        // import Component.GUI.Dimension;
        // import Component.GUI.Point;
        // import Component.Util.Config;
        
        getRoot().applyConfig(config, sPrefix + getSeparator());
        
        // for a hard to trace reason, to enforce the JScrollPane/JViewport/JTree
        // to respect our ViewPosition settings we need:
        // a) save and apply the "ViewSize" (one would think as a redundant info)
        // b) set the ViewSize prior to ViewPosition
        //
        // There still remains a problem with possibly incorrect scroll bars state,
        // but we'll defer this for a lack of understanding...
        
        Config cfgSize = config.getConfig(sPrefix + ".ViewSize");
        if (!cfgSize.isEmpty())
            {
            Dimension dimViewSize = new Dimension();
            dimViewSize.applyConfig(cfgSize, "");
            setViewSize(dimViewSize);
            }
        
        Config cfgPos = config.getConfig(sPrefix + ".ViewPosition");
        if (!cfgPos.isEmpty())
            {
            Point ptViewPosition = new Point();
            ptViewPosition.applyConfig(cfgPos, "");
            setViewPosition(ptViewPosition);
            }
        
        if (config.containsKey(sPrefix + ".SelectionId"))
            {
            TreeNode node = findNodeId(config.getString(sPrefix + ".SelectionId"));
            if (node != null)
                {
                setSelectionNode(node);
                }
            }
        
        super.applyConfig(config, sPrefix);
        }
    
    // From interface: javax.swing.event.CellEditorListener
    public void editingCanceled(javax.swing.event.ChangeEvent e)
        {
        TreeNode node = getEditingNode();
        if (node != null)
            {
            onEditingCanceled(node);
        
            setEditingNode(null);
            }
        }
    
    // From interface: javax.swing.event.CellEditorListener
    public void editingStopped(javax.swing.event.ChangeEvent e)
        {
        // Depending on the position among other registered CellEditorListener(s)
        // this notification is called causes before or after the call to
        // BasicTreeUI.editingStopped() that in turn makes a call to the model
        // "treeModel.valueForPathChanged(...)" (BasicTreeUI.java line #1761)
        // If we are called before -- the new value could be obtained from the editor,
        // but any changes to the UserObject will be overwritten later by
        // DefaultTreeModel.valueForPathChanged() (DefaultTreeModel line #202)
        // Otherwise, the UserObject is already set to a the value and we have to 
        // restore it.
        //
        // Note: we rely on the fact that EditingNode is not null ONLY when
        // its UserObject used to point to itself (see startEditingAtPath()).
        
        TreeNode node = getEditingNode();
        if (node != null)
            {
            Object oNewValue;
        
            if (isEditing())
                {
                // we are called before -- get the new value, cancel the editing
                oNewValue = getCellEditor().getCellEditorValue();
                cancelEditing();
                }
            else
                {
                // we are called after
                oNewValue = node.getUserObject();
                node.setUserObject(node);
                }
        
            onEditingStopped(node, oNewValue);
            setEditingNode(null);
        
            // in all cases update the node
            node.update();
            }
        }
    
    /**
    * Finds a child node that "equals" to the specified object.
    * 
    * @param obj object to find
    * 
    * Note: we use the breadth first enumeration method
    * 
    * @see Component.GUI.TreeNode#findNode
    */
    public _package.component.gUI.TreeNode findNode(Object obj)
        {
        TreeNode root = getRoot();
        return obj == null ? root : root.findNode(obj, TreeNode.ENUM_BREADTH_FIRST);
        }
    
    /**
    * Find a node by composite id
    * 
    * @param sNodeId -- node's composite id (null for root)
    * 
    * @return node with the specified composite id; null if not found
    */
    public _package.component.gUI.TreeNode findNodeId(String sNodeId)
        {
        TreeNode root = getRoot();
        return sNodeId == null ? root : root.findNodeId(sNodeId);
        }
    
    // Accessor for the property "ClosedIcon"
    /**
    * Getter for property ClosedIcon.<p>
    */
    public _package.component.gUI.image.Icon getClosedIcon()
        {
        return __m_ClosedIcon;
        }
    
    // Accessor for the property "CollapsedIcon"
    /**
    * Getter for property CollapsedIcon.<p>
    */
    public _package.component.gUI.image.Icon getCollapsedIcon()
        {
        return __m_CollapsedIcon;
        }
    
    // Accessor for the property "Collator"
    /**
    * Getter for property Collator.<p>
    * Collator used to sort the nodes in this tree. If not specified, the
    * default string comparison (String.compareTo()) is used.
    * 
    * @see #makeNode
    * @see Component.GUI.TreeNode#add
    */
    public java.text.Collator getCollator()
        {
        return __m_Collator;
        }
    
    // Accessor for the property "EditingNode"
    /**
    * Getter for property EditingNode.<p>
    * Specifies the node that is currently editing.
    * 
    * @see #startEditingAtPath
    * @see #editingStopped
    * @see #editingCaanceled
    */
    public _package.component.gUI.TreeNode getEditingNode()
        {
        return __m_EditingNode;
        }
    
    // Accessor for the property "ExpandedIcon"
    /**
    * Getter for property ExpandedIcon.<p>
    */
    public _package.component.gUI.image.Icon getExpandedIcon()
        {
        return __m_ExpandedIcon;
        }
    
    // Accessor for the property "LeafIcon"
    /**
    * Getter for property LeafIcon.<p>
    */
    public _package.component.gUI.image.Icon getLeafIcon()
        {
        return __m_LeafIcon;
        }
    
    // Accessor for the property "Model"
    /**
    * Getter for property Model.<p>
    */
    public javax.swing.tree.DefaultTreeModel getModel()
        {
        return (javax.swing.tree.DefaultTreeModel) ((_JTree) get_Feed()).getModel();
        }
    
    public _package.component.gUI.Rectangle getNodeBounds(_package.component.gUI.TreeNode node)
        {
        // import Component.GUI.Rectangle;
        
        java.awt.Rectangle _rect = ((_JTree) get_Feed()).getPathBounds(node.getPath());
        
        return _rect != null ? Rectangle.instantiate(_rect) : null;

        }
    
    public _package.component.gUI.TreeNode getNodeForLocation(_package.component.gUI.Point point)
        {
        TreePath path = ((_JTree) get_Feed()).getPathForLocation(point.getX(), point.getY());
        
        return path == null ? null : makeNode(path.getLastPathComponent());
        }
    
    public _package.component.gUI.TreeNode getNodeForRow(int iRow)
        {
        TreePath path = ((_JTree) get_Feed()).getPathForRow(iRow);
        
        return path == null ? null : makeNode(path.getLastPathComponent());
        }
    
    // Accessor for the property "OpenIcon"
    /**
    * Getter for property OpenIcon.<p>
    */
    public _package.component.gUI.image.Icon getOpenIcon()
        {
        return __m_OpenIcon;
        }
    
    // Accessor for the property "PreferredCellSize"
    /**
    * Getter for property PreferredCellSize.<p>
    */
    public _package.component.gUI.Dimension getPreferredCellSize()
        {
        return __m_PreferredCellSize;
        }
    
    // Accessor for the property "Root"
    /**
    * Getter for property Root.<p>
    * Specifies the root node ot the tree.
    */
    public _package.component.gUI.TreeNode getRoot()
        {
        TreeNode root = __m_Root;
        if (root == null)
            {
            setRoot(root = makeRoot());
            }
        return root;

        }
    
    // Accessor for the property "SelectionId"
    /**
    * Getter for property SelectionId.<p>
    * Specifies the Id of the selection node.
    */
    public String getSelectionId()
        {
        TreeNode node = getSelectionNode();
        return node != null ? node.getId() : "";
        }
    
    // Accessor for the property "SelectionMode"
    /**
    * Getter for property SelectionMode.<p>
    * Valid values are:
    * 
    * SINGLE_TREE_SELECTION = 1;
    * CONTIGUOUS_TREE_SELECTION = 2;
    * DISCONTIGUOUS_TREE_SELECTION = 4;
    * 
    * @see javax.swing.tree.TreeSelectionModel
    */
    public int getSelectionMode()
        {
        return ((_JTree) get_Feed()).getSelectionModel().getSelectionMode();
        }
    
    // Accessor for the property "SelectionNode"
    /**
    * Getter for property SelectionNode.<p>
    * Specifies the currently selected node.
    */
    public _package.component.gUI.TreeNode getSelectionNode()
        {
        // TODO: this assumes the single selection tree
        // see getSelectionMode()
        TreePath path = ((_JTree) get_Feed()).getSelectionPath();
        return path != null ? makeNode(path) : null;
        }
    
    // Accessor for the property "Separator"
    /**
    * Getter for property Separator.<p>
    * Specifies the separator used to generate node id(s).
    */
    public char getSeparator()
        {
        return __m_Separator;
        }
    
    // Accessor for the property "ToolTipText"
    /**
    * Returns the tool tip text for the specified node. If the
    * <code>node</code> is null, there is no node at the mouse position.
    * Default implementation shows the full text of the node only when the node
    * is partially invisible.
    * 
    * Note: this method is only called if the ShowNodeTips property is set to
    * true.
    * 
    * @see#ShowNodeTips property
    * @see #getTooTipText(MouseEvent)
    */
    public String getToolTipText(_package.component.gUI.TreeNode node)
        {
        // import Component.GUI.Dimension;
        // import Component.GUI.Point;
        // import Component.GUI.Rectangle;
        
        String sTip = null;
        
        if (node != null)
            {
            Rectangle rectNode = getNodeBounds(node);
            Point     ptTree   = getViewPosition();
            Dimension dimTree  = getSize();
        
            // show the tip only if the node is not fully visible
            if (rectNode != null &&
                rectNode.getX() + rectNode.getWidth() > ptTree.getX() + dimTree.getWidth())
                {
                sTip = node.toString();
                }
            }
        return sTip;

        }
    
    // Declared at the super level
    /**
    * Gets (drags) a Transferable object from a given location.
    * 
    * @return Transferable object at given location; null if there is nothing
    * to transfer
    * 
    * @see #dragGestureRecognized
    */
    protected java.awt.datatransfer.Transferable getTransferAtLocation(_package.component.gUI.Point point)
        {
        // import java.awt.datatransfer.StringSelection;
        
        TreeNode node = getNodeForLocation(point);
        
        return node != null ?
            new StringSelection(node.getId()) : null;
        }
    
    /**
    * Hide the tool tip by re-issuing the mouseExit event that may have been
    * killed previously
    * 
    * @see #onMousePressed
    */
    private void hideToolTip()
        {
        // import java.awt.event.MouseEvent;
        // import javax.swing.JToolTip;
        
        JToolTip _tip = get_ToolTip();
        if (_tip != null && _tip.isShowing())
            {
            // hide the tool tip by re-generating the mouseExit
            MouseEvent e = new MouseEvent((_JTree) get_Feed(),
                MouseEvent.MOUSE_EXITED, 0L, 0, -1, -1, 0, false);
            mouseExited(e);
            }
        }
    
    // Declared at the super level
    /**
    * Invoke a popup (usually a context menu) for this component at the
    * specified location. Default implementation looks for a child Control
    * named "Context" and tries to instantiate it.
    */
    protected void invokePopup(_package.component.gUI.Point point)
        {
        // import Component.GUI.TreeNode;
        
        // only invoke popup if a node is choosen
        TreeNode node = getNodeForLocation(point);
        if (node != null)
            {
            setSelectionNode(node);
        
            super.invokePopup(point);
            }
        }
    
    // Accessor for the property "CaseSensitive"
    /**
    * Getter for property CaseSensitive.<p>
    * Specifies whether the sorting should be case sensitive (assuming there is
    * no specified Collator).
    * 
    * @see #makeNode
    * @see Component.GUI.TreeNode#CaseSensitive
    */
    public boolean isCaseSensitive()
        {
        return __m_CaseSensitive;
        }
    
    // Accessor for the property "Redraw"
    /**
    * Getter for property Redraw.<p>
    * If set to false, changes to the tree structure are not made visible until
    * this property is set back to true.
    * Used to optimize the redrawing performance during "bulk" inserts and
    * removes.
    */
    public boolean isRedraw()
        {
        return __m_Redraw;
        }
    
    // Accessor for the property "ShowNodeTips"
    /**
    * Getter for property ShowNodeTips.<p>
    * Specifies whether the Tree will show the tool tips for the individual
    * nodes of this tree. If set to true, a call to the
    * getToolTipText(TreeNode) is made to obtain the text for the specified
    * node.
    * 
    * @see #getToolTipLocation
    * @see #getToolTipText(MouseEvent)
    * @see #getToolTipText(TreeNode)
    */
    public boolean isShowNodeTips()
        {
        return __m_ShowNodeTips;
        }
    
    // Accessor for the property "Sorted"
    /**
    * Getter for property Sorted.<p>
    * Specifies whether the tree is sorted. If set to true all the nodes will
    * be made sorted as well.
    * 
    * @see Component.GUI.TreeNode#Sorted
    */
    public boolean isSorted()
        {
        return __m_Sorted;
        }
    
    private _package.component.gUI.image.Icon makeIcon(javax.swing.Icon _icon)
        {
        // import javax.swing.ImageIcon;
        // currently (as of 4/29/99) this method is not used
        
        if (_icon instanceof ImageIcon)
            {
            Icon icon = new Icon();
            icon.set_Icon((ImageIcon) _icon);
            icon.set_Image(((ImageIcon) _icon).getImage());
            return icon;
            }
        else
            {
            return null;
            }

        }
    
    public _package.component.gUI.TreeNode makeNode(Object path)
        {
        if (path instanceof TreePath)
            {
            path = ((TreePath) path).getLastPathComponent();
            }
        _assert(path instanceof DefaultMutableTreeNode || path == null, "" + path);
        
        DefaultMutableTreeNode _node = path instanceof DefaultMutableTreeNode ?
            (DefaultMutableTreeNode) path : new DefaultMutableTreeNode(path);
        
        Object obj = _node.getUserObject();
        if (obj instanceof TreeNode)
            {
            _assert(((TreeNode) obj).getTree() == this, "" + obj);
            return (TreeNode) obj;
            }
        else
            {
            TreeNode node = new TreeNode();
            node.setTree(this);
            node.setEditable(isEditable());
            node.setSorted(isSorted());
            node.setCaseSensitive(isCaseSensitive());
            node.setCollator(getCollator());
            node.setMutableNode(_node);
            return node;
            }
        }
    
    /**
    * Makes a root node for this tree
    */
    protected _package.component.gUI.TreeNode makeRoot()
        {
        DefaultMutableTreeNode _root = (DefaultMutableTreeNode) getModel().getRoot();
        _root.setUserObject(null);
        return makeNode(_root);

        }
    
    public void onCellRendering(java.awt.Component compRenderer, _package.component.gUI.TreeNode node, boolean hasFocus)
        {
        // import Component.GUI.Dimension;
        // import javax.swing.JComponent as _JComponent;
        
        // TODO: PreferredCellSize is never used; do we really need this helper?
        if (compRenderer instanceof _JComponent)
            {
            Dimension size = getPreferredCellSize();
            if (size != null)
                {
                ((DefaultTreeCellRenderer) compRenderer).setPreferredSize(size.get_Dimension());
                }
            }
        }
    
    public void onCollapsed(_package.component.gUI.TreeNode node)
        {
        }
    
    /**
    * Notification message called when editing process gets canceled.
    * 
    * @see #editingCanceled
    */
    public void onEditingCanceled(_package.component.gUI.TreeNode node)
        {
        }
    
    /**
    * Notification sent when editing is about to begin. Throwing
    * EventDeathException will prevent editing from starting.
    * 
    * @see #startEditingAtPath
    */
    public void onEditingStarting(_package.component.gUI.TreeNode node)
        {
        }
    
    /**
    * Notification message called when editing process gets ended for the
    * specified node.
    * 
    * Derived classes are responsible for pulling the new value out of
    * "node.getUserObject()" and setting the corresponding values of derived
    * TreeNode(s). Otherwise the new value will be lost.
    * 
    * @see #editingStoped
    */
    public void onEditingStopped(_package.component.gUI.TreeNode node, Object oNewValue)
        {
        }
    
    public void onExpanded(_package.component.gUI.TreeNode node)
        {
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        super.onInit();
        
        removeAllNodes(); // default constructor adds silly "colors" "sports" "food"

        }
    
    // Declared at the super level
    public void onKeyPressed(char keyChar, int keyCode, int modifiers)
        {
        // TODO: remove when Swing fixes this bug
        hideToolTip();
        
        super.onKeyPressed(keyChar, keyCode, modifiers);

        }
    
    // Declared at the super level
    /**
    * @see #getToolTipTextLocation
    */
    public void onMouseExited(_package.component.gUI.Point point, int modifiers)
        {
        super.onMouseExited(point, modifiers);
        
        if (get_ToolTip() != null && get_ToolTip().isShowing() &&
            ((java.awt.Component) get_Feed()).contains(point.get_Point()))
            {
            // the tool tip is showing (see getToolTipLocation())
            throw new EventDeathException();
            }
        }
    
    // Declared at the super level
    public void onMousePressed(_package.component.gUI.Point point, int modifiers, int clickCount, boolean popupTrigger)
        {
        hideToolTip();
        
        super.onMousePressed(point, modifiers, clickCount, popupTrigger);
        }
    
    public void onSelected(_package.component.gUI.TreeNode node)
        {
        }
    
    // Declared at the super level
    /**
    * Prepares to transfer something at the specified location for the
    * specified action
    * 
    * @return true if transfer is going to be accepted; false otherwise
    * 
    * @see dragOver()
    */
    protected boolean prepareTransferAtLocation(_package.component.gUI.Point point, int iAction, java.util.List listFlavors)
        {
        TreeNode node = getNodeForLocation(point);
        
        if (node != null)
            {
            if (!node.isSelected())
                {
                setSelectionNode(node);
                }
            if (!node.isLeaf() && !node.isExpanded())
                {
                node.setExpanded(true);
                }
            return true;
            }
        else
            {
            return false;
            }
        }
    
    public void reload()
        {
        if (isRedraw())
            {
            getModel().reload();
            }

        }
    
    public void removeAllNodes()
        {
        getRoot().removeAllChildren();
        }
    
    public void removeNodeId(String sNodeId)
        {
        TreeNode node = findNodeId(sNodeId);
        if (node != null)
            {
            node.remove();
            }
        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        getRoot()        .saveConfig(config, sPrefix + getSeparator());
        getViewPosition().saveConfig(config, sPrefix + ".ViewPosition");
        getViewSize    ().saveConfig(config, sPrefix + ".ViewSize");
        
        config.putString(sPrefix + ".SelectionId", getSelectionId());
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "CaseSensitive"
    /**
    * Setter for property CaseSensitive.<p>
    * Specifies whether the sorting should be case sensitive (assuming there is
    * no specified Collator).
    * 
    * @see #makeNode
    * @see Component.GUI.TreeNode#CaseSensitive
    */
    public void setCaseSensitive(boolean pCaseSensitive)
        {
        __m_CaseSensitive = pCaseSensitive;
        }
    
    // Accessor for the property "ClosedIcon"
    /**
    * Setter for property ClosedIcon.<p>
    */
    public void setClosedIcon(_package.component.gUI.image.Icon pClosedIcon)
        {
        __m_ClosedIcon = (pClosedIcon);
        
        TreeCellRenderer renderer = getCellRenderer();
        if (renderer instanceof DefaultTreeCellRenderer)
            {
            ((DefaultTreeCellRenderer) renderer).setClosedIcon(pClosedIcon);
            }
        }
    
    // Accessor for the property "CollapsedIcon"
    /**
    * Setter for property CollapsedIcon.<p>
    */
    public void setCollapsedIcon(_package.component.gUI.image.Icon pCollapsedIcon)
        {
        __m_CollapsedIcon = (pCollapsedIcon);
        
        _JTree _feed = (_JTree) get_Feed();
        ((javax.swing.plaf.basic.BasicTreeUI) _feed.getUI()).setCollapsedIcon(pCollapsedIcon);
        }
    
    // Accessor for the property "Collator"
    /**
    * Setter for property Collator.<p>
    * Collator used to sort the nodes in this tree. If not specified, the
    * default string comparison (String.compareTo()) is used.
    * 
    * @see #makeNode
    * @see Component.GUI.TreeNode#add
    */
    public void setCollator(java.text.Collator pCollator)
        {
        __m_Collator = pCollator;
        }
    
    // Accessor for the property "EditingNode"
    /**
    * Setter for property EditingNode.<p>
    * Specifies the node that is currently editing.
    * 
    * @see #startEditingAtPath
    * @see #editingStopped
    * @see #editingCaanceled
    */
    public void setEditingNode(_package.component.gUI.TreeNode pEditingNode)
        {
        __m_EditingNode = pEditingNode;
        }
    
    // Accessor for the property "ExpandedIcon"
    /**
    * Setter for property ExpandedIcon.<p>
    */
    public void setExpandedIcon(_package.component.gUI.image.Icon pExpandedIcon)
        {
        __m_ExpandedIcon = (pExpandedIcon);
        
        _JTree _feed = (_JTree) get_Feed();
        ((javax.swing.plaf.basic.BasicTreeUI) _feed.getUI()).setExpandedIcon(pExpandedIcon);

        }
    
    // Declared at the super level
    /**
    * Setter for property Font.<p>
    */
    public void setFont(_package.component.gUI.Font pFont)
        {
        super.setFont(pFont);
        
        // JTree bug -- we should not have to do this
        if (getCellRenderer() instanceof DefaultTreeCellRenderer)
            {
            ((DefaultTreeCellRenderer) getCellRenderer()).setFont(get_Font());
            }
        }
    
    // Accessor for the property "LeafIcon"
    /**
    * Setter for property LeafIcon.<p>
    */
    public void setLeafIcon(_package.component.gUI.image.Icon pLeafIcon)
        {
        __m_LeafIcon = (pLeafIcon);
        
        TreeCellRenderer renderer = getCellRenderer();
        if (renderer instanceof DefaultTreeCellRenderer)
            {
            ((DefaultTreeCellRenderer) renderer).setLeafIcon(pLeafIcon);
            }
        }
    
    // Accessor for the property "OpenIcon"
    /**
    * Setter for property OpenIcon.<p>
    */
    public void setOpenIcon(_package.component.gUI.image.Icon pOpenIcon)
        {
        __m_OpenIcon = (pOpenIcon);
        
        TreeCellRenderer renderer = getCellRenderer();
        if (renderer instanceof DefaultTreeCellRenderer)
            {
            ((DefaultTreeCellRenderer) renderer).setOpenIcon(pOpenIcon);
            }
        }
    
    // Accessor for the property "PreferredCellSize"
    /**
    * Setter for property PreferredCellSize.<p>
    */
    public void setPreferredCellSize(_package.component.gUI.Dimension pPreferredCellSize)
        {
        __m_PreferredCellSize = pPreferredCellSize;
        }
    
    // Accessor for the property "Redraw"
    /**
    * Setter for property Redraw.<p>
    * If set to false, changes to the tree structure are not made visible until
    * this property is set back to true.
    * Used to optimize the redrawing performance during "bulk" inserts and
    * removes.
    */
    public void setRedraw(boolean pRedraw)
        {
        // TODO: move this property to the TreeNode
        if (pRedraw == isRedraw())
            {
            return;
            }
        
        __m_Redraw = (pRedraw);
        
        if (is_Constructed() && pRedraw)
            {
            reload();
            }
        }
    
    // Accessor for the property "Root"
    /**
    * Setter for property Root.<p>
    * Specifies the root node ot the tree.
    */
    protected void setRoot(_package.component.gUI.TreeNode pRoot)
        {
        _assert(pRoot != null);
        __m_Root = (pRoot);
        }
    
    // Accessor for the property "SelectionId"
    /**
    * Setter for property SelectionId.<p>
    * Specifies the Id of the selection node.
    */
    public void setSelectionId(String pSelectionId)
        {
        setSelectionNode(findNodeId(pSelectionId));

        }
    
    // Accessor for the property "SelectionMode"
    /**
    * Setter for property SelectionMode.<p>
    * Valid values are:
    * 
    * SINGLE_TREE_SELECTION = 1;
    * CONTIGUOUS_TREE_SELECTION = 2;
    * DISCONTIGUOUS_TREE_SELECTION = 4;
    * 
    * @see javax.swing.tree.TreeSelectionModel
    */
    public void setSelectionMode(int pSelectionMode)
        {
        ((_JTree) get_Feed()).getSelectionModel().setSelectionMode(pSelectionMode);
        }
    
    // Accessor for the property "SelectionNode"
    /**
    * Setter for property SelectionNode.<p>
    * Specifies the currently selected node.
    */
    public void setSelectionNode(_package.component.gUI.TreeNode pSelectionNode)
        {
        ((_JTree) get_Feed()).setSelectionPath(
            pSelectionNode == null ? null : pSelectionNode.getPath());
        }
    
    // Accessor for the property "Separator"
    /**
    * Setter for property Separator.<p>
    * Specifies the separator used to generate node id(s).
    */
    public void setSeparator(char pSeparator)
        {
        __m_Separator = pSeparator;
        }
    
    // Accessor for the property "ShowNodeTips"
    /**
    * Setter for property ShowNodeTips.<p>
    * Specifies whether the Tree will show the tool tips for the individual
    * nodes of this tree. If set to true, a call to the
    * getToolTipText(TreeNode) is made to obtain the text for the specified
    * node.
    * 
    * @see #getToolTipLocation
    * @see #getToolTipText(MouseEvent)
    * @see #getToolTipText(TreeNode)
    */
    public void setShowNodeTips(boolean pShowNodeTips)
        {
        // import javax.swing.ToolTipManager;
        
        if (pShowNodeTips == isShowNodeTips())
            {
            return;
            }
        
        __m_ShowNodeTips = (pShowNodeTips);
        
        if (!is_Constructed())
            {
            // the actual registering/unregistering is done at addNotify/removeNotify
            return;
            }
        
        if (pShowNodeTips)
            {
            ToolTipManager.sharedInstance().registerComponent((_JTree) get_Feed());
            }
        else
            {
            ToolTipManager.sharedInstance().unregisterComponent((_JTree) get_Feed());
            }
        }
    
    // Accessor for the property "Sorted"
    /**
    * Setter for property Sorted.<p>
    * Specifies whether the tree is sorted. If set to true all the nodes will
    * be made sorted as well.
    * 
    * @see Component.GUI.TreeNode#Sorted
    */
    public void setSorted(boolean pSorted)
        {
        __m_Sorted = pSorted;
        }
    }
