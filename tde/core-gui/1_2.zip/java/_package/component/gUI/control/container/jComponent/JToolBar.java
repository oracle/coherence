/* Class
*     _package.component.gUI.control.container.jComponent.JToolBar
*/

package _package.component.gUI.control.container.jComponent;

import _package.component.gUI.Insets;
import _package.component.gUI.Point;
import javax.swing.JToolBar; // as _JToolBar
import javax.swing.plaf.basic.BasicToolBarUI;

/**
* JToolBar integrates javax.swing.JToolBar swing component.
* Following is the quote from JToolBar.java:
* 
* JToolBar provides a component which is useful for displaying commonly used
* Actions or controls.  It can be dragged out into a separate window by the
* user (unless the floatable property is set to false).  In order for drag-out
* to work correctly, it is recommended that you add JToolBar instances to one
* of the four 'sides' of a container whose layout manager is a BorderLayout,
* and do not add children to any of the other four 'sides'.
*/
/*
* Integrates
*     javax.swing.JToolBar
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JToolBar
        extends    _package.component.gUI.control.container.JComponent
    {
    // Fields declarations
    
    /**
    * Property _Margin
    *
    */
    private transient java.awt.Insets __m__Margin;
    
    /**
    * Property BorderPainted
    *
    * Specifies whether the border should be painted (default is true).
    */
    private transient boolean __m_BorderPainted;
    
    /**
    * Property Floatable
    *
    * Specifies whether the toolbar can be made to float (default is true).
    */
    private transient boolean __m_Floatable;
    
    /**
    * Property Floating
    *
    * Specifies whether or not the tool bar is currently floating.
    */
    private transient boolean __m_Floating;
    
    /**
    * Property FloatingLocation
    *
    * Specifies the location of the floating tool bar. Currently this property
    * is only settable  -- there is no API to get this infromation from.
    * 
    * @see javax.swing.plaf.basic.BasicToolBarUI
    */
    private transient _package.component.gUI.Point __m_FloatingLocation;
    
    /**
    * Property Margin
    *
    * Specifies the margin between the toolbar's border and its buttons.
    * Setting to null causes the toolbar to use the default margins. The
    * toolbar's default Border object uses this value to create the proper
    * margin.  However, if a non-default border is set on the toolbar,  it is
    * that Border object's responsibility to create the appropriate margin
    * space (otherwise this property will effectively be ignored).
    */
    private transient _package.component.gUI.Insets __m_Margin;
    
    /**
    * Property Orientation
    *
    * Specifies the orientation of the toolbar. The valid values are:
    * 
    * HORIZONTAL = 0 (Default)
    * VERTICAL = 1
    */
    private transient int __m_Orientation;
    
    /**
    * Property RolloverBorders
    *
    * 
    * @see javax.swing.plaf.metal.MetalToolBarUI
    */
    private transient boolean __m_RolloverBorders;
    
    // fields used by the integration model:
    private sink_JToolBar __sink;
    private javax.swing.JToolBar __feed;
    
    // Default constructor
    public JToolBar()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JToolBar(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setTBounds("0,0,80,24");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JToolBar.__tloPeer.setObject(this);
            new jb_JToolBar(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JToolBar();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JToolBar".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JToolBar integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JToolBar) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JToolBar) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public java.awt.Insets get_Margin()
        {
        return __sink.getMargin();
        }
    public int getOrientation()
        {
        return __sink.getOrientation();
        }
    public boolean isBorderPainted()
        {
        return __sink.isBorderPainted();
        }
    public boolean isFloatable()
        {
        return __sink.isFloatable();
        }
    public void setBorderPainted(boolean pBorderPainted)
        {
        __sink.setBorderPainted(pBorderPainted);
        }
    public void setFloatable(boolean pFloatable)
        {
        __sink.setFloatable(pFloatable);
        }
    public void set_Margin(java.awt.Insets p_Margin)
        {
        __sink.setMargin(p_Margin);
        }
    public void setOrientation(int pOrientation)
        {
        __sink.setOrientation(pOrientation);
        }
    //-- javax.swing.JToolBar integration
    
    // Declared at the super level
    public void _imports()
        {
        // import javax.swing.JToolBar as _JToolBar;
        // import javax.swing.plaf.basic.BasicToolBarUI;
        
        
        

        }
    
    // Accessor for the property "FloatingLocation"
    public _package.component.gUI.Point getFloatingLocation()
        {
        return __m_FloatingLocation;
        }
    
    // Accessor for the property "Margin"
    public _package.component.gUI.Insets getMargin()
        {
        // import Component.GUI.Insets;
        
        Insets wrapper = new Insets();
        wrapper.set_Insets(get_Insets());
        return wrapper;
        }
    
    // Accessor for the property "Floating"
    public boolean isFloating()
        {
        _JToolBar      _toolbar = (_JToolBar) get_Feed();
        BasicToolBarUI ui       = (BasicToolBarUI) _toolbar.getUI();
        
        return ui.isFloating();
        }
    
    // Accessor for the property "RolloverBorders"
    public boolean isRolloverBorders()
        {
        Boolean f = (Boolean) ((_JToolBar) get_Feed()).
            getClientProperty("JToolBar.isRollover");
        
        return f == null ? false : f.booleanValue();
        }
    
    // Accessor for the property "Floating"
    public void setFloating(boolean pFloating)
        {
        // import Component.GUI.Point;
        
        _JToolBar      _toolbar = (_JToolBar) get_Feed();
        BasicToolBarUI ui       = (BasicToolBarUI) _toolbar.getUI();
        
        Point p = getFloatingLocation();
        
        ui.setFloating(pFloating, p == null ? null : p.get_Point());
        }
    
    // Accessor for the property "FloatingLocation"
    public void setFloatingLocation(_package.component.gUI.Point pFloatingLocation)
        {
        __m_FloatingLocation = (pFloatingLocation);
        
        _JToolBar      _toolbar = (_JToolBar) get_Feed();
        BasicToolBarUI ui       = (BasicToolBarUI) _toolbar.getUI();
        
        ui.setFloatingLocation(pFloatingLocation.getX(), pFloatingLocation.getY());
        }
    
    // Accessor for the property "Margin"
    public void setMargin(_package.component.gUI.Insets pMargin)
        {
        set_Margin(pMargin == null ? null : pMargin.get_Insets());
        }
    
    // Accessor for the property "RolloverBorders"
    public void setRolloverBorders(boolean pRolloverBorders)
        {
        ((_JToolBar) get_Feed()).putClientProperty("JToolBar.isRollover",
            new Boolean(pRolloverBorders));
        }
    }
