/* Class
*     _package.component.gUI.control.container.jComponent.JSlider
*/

package _package.component.gUI.control.container.jComponent;

/**
* Component integrating javax.swing.JSlider
*/
/*
* Integrates
*     javax.swing.JSlider
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JSlider
        extends    _package.component.gUI.control.container.JComponent
        implements javax.swing.event.ChangeListener
    {
    // Fields declarations
    
    /**
    * Property Extent
    *
    * Specifies the "extent" -- the range of values "covered" by the knob. Most
    * look and feel implementations will change the value by this amount if the
    * user clicks on either side of the knob.
    */
    private int __m_Extent;
    
    /**
    * Property Inverted
    *
    * Set to true if the value-range shown for the slider is reversed, with the
    * maximum value at the left end of a horizontal slider or at the bottom of
    * a vertical one.
    */
    private boolean __m_Inverted;
    
    /**
    * Property MajorTickSpacing
    *
    * Specifies the number of values between the major tick marks -- the larger
    * marks that break up the minor tick marks.
    */
    private int __m_MajorTickSpacing;
    
    /**
    * Property Maximum
    *
    * Specifies the maximum value supported by the slider.
    * 
    * Default value is 100.
    */
    private int __m_Maximum;
    
    /**
    * Property Minimum
    *
    * Specifies the minimum value supported by the slider.
    * 
    * Default value is 0.
    */
    private int __m_Minimum;
    
    /**
    * Property MinorTickSpacing
    *
    * Specifies the number of values between the minor tick marks -- the
    * smaller marks that occur between the major tick marks.
    */
    private int __m_MinorTickSpacing;
    
    /**
    * Property Orientation
    *
    * Specifies the slider orientation. The valid values are:
    * 
    * HORIZONTAL = 0
    * VERTICAL = 1
    */
    private int __m_Orientation;
    
    /**
    * Property PaintLabels
    *
    * Specifies whether or not labels are to be painted.
    */
    private boolean __m_PaintLabels;
    
    /**
    * Property PaintTicks
    *
    * Specifies whether or not tick marks are to be painted.
    */
    private boolean __m_PaintTicks;
    
    /**
    * Property PaintTrack
    *
    * Specifies whether or not the track (area the slider slides in) is to be
    * painted.
    */
    private boolean __m_PaintTrack;
    
    /**
    * Property SnapToTicks
    *
    * Specifies whether or not the knob (and the data value it represents)
    * should resolve to the closest tick mark next to where the user positioned
    * the knob.
    */
    private boolean __m_SnapToTicks;
    
    /**
    * Property Value
    *
    * Specifies the slider's current value.
    * 
    * Default initial value is 50.
    */
    private int __m_Value;
    
    /**
    * Property ValueAdjusting
    *
    * Specifies whether or not the slider knob is being dragged. The
    * slider model will not generate ChangeEvents while the ValueAdjusting is
    * true.
    */
    private boolean __m_ValueAdjusting;
    
    // fields used by the integration model:
    private sink_JSlider __sink;
    private javax.swing.JSlider __feed;
    
    // Default constructor
    public JSlider()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JSlider(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JSlider.__tloPeer.setObject(this);
            new jb_JSlider(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        super.__initEvents();
        
        addChangeListener(this);
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JSlider();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/JSlider".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ ChangeListener dispatcher
    private com.tangosol.util.Listeners __ChangeListeners;
    private void addChangeListener$Router(javax.swing.event.ChangeListener l)
        {
        __sink.addChangeListener(l);
        }
    public void addChangeListener(javax.swing.event.ChangeListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __ChangeListeners;
        if (_listeners == null)
            {
            __ChangeListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addChangeListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeChangeListener$Router(javax.swing.event.ChangeListener l)
        {
        __sink.removeChangeListener(l);
        }
    public void removeChangeListener(javax.swing.event.ChangeListener l)
        {
        com.tangosol.util.Listeners _listeners = __ChangeListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeChangeListener$Router(this);
            }
        }
    private void stateChanged$Dispatch(javax.swing.event.ChangeEvent e)
        {
        java.util.EventListener[] targets = __ChangeListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            javax.swing.event.ChangeListener target = (javax.swing.event.ChangeListener) targets[i];
            if (target != this)
                {
                target.stateChanged(e);
                }
            }
        }
    public void stateChanged(javax.swing.event.ChangeEvent e)
        {
        try
            {
            if (is_Constructed())
                {
                onValueChanged();
                }
            }
        catch (com.tangosol.run.component.EventDeathException x)
            {
            return;
            }
        
        stateChanged$Dispatch(e);
        }
    //-- ChangeListener dispatcher
    
    //++ javax.swing.JSlider integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JSlider) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JSlider) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public int getExtent()
        {
        return __sink.getExtent();
        }
    public boolean isInverted()
        {
        return __sink.getInverted();
        }
    public int getMajorTickSpacing()
        {
        return __sink.getMajorTickSpacing();
        }
    public int getMaximum()
        {
        return __sink.getMaximum();
        }
    public int getMinimum()
        {
        return __sink.getMinimum();
        }
    public int getMinorTickSpacing()
        {
        return __sink.getMinorTickSpacing();
        }
    public int getOrientation()
        {
        return __sink.getOrientation();
        }
    public boolean isPaintLabels()
        {
        return __sink.getPaintLabels();
        }
    public boolean isPaintTicks()
        {
        return __sink.getPaintTicks();
        }
    public boolean isPaintTrack()
        {
        return __sink.getPaintTrack();
        }
    public boolean isSnapToTicks()
        {
        return __sink.getSnapToTicks();
        }
    public int getValue()
        {
        return __sink.getValue();
        }
    public boolean isValueAdjusting()
        {
        return __sink.getValueIsAdjusting();
        }
    public void setExtent(int pExtent)
        {
        __sink.setExtent(pExtent);
        }
    public void setInverted(boolean pInverted)
        {
        __sink.setInverted(pInverted);
        }
    public void setMajorTickSpacing(int pMajorTickSpacing)
        {
        __sink.setMajorTickSpacing(pMajorTickSpacing);
        }
    public void setMaximum(int pMaximum)
        {
        __sink.setMaximum(pMaximum);
        }
    public void setMinimum(int pMinimum)
        {
        __sink.setMinimum(pMinimum);
        }
    public void setMinorTickSpacing(int pMinorTickSpacing)
        {
        __sink.setMinorTickSpacing(pMinorTickSpacing);
        }
    public void setOrientation(int pOrientation)
        {
        __sink.setOrientation(pOrientation);
        }
    public void setPaintLabels(boolean pPaintLabels)
        {
        __sink.setPaintLabels(pPaintLabels);
        }
    public void setPaintTicks(boolean pPaintTicks)
        {
        __sink.setPaintTicks(pPaintTicks);
        }
    public void setPaintTrack(boolean pPaintTrack)
        {
        __sink.setPaintTrack(pPaintTrack);
        }
    public void setSnapToTicks(boolean pSnapToTicks)
        {
        __sink.setSnapToTicks(pSnapToTicks);
        }
    private void setValue$Router(int pValue)
        {
        __sink.setValue(pValue);
        }
    public void setValue(int pValue)
        {
        setValue$Router(pValue);
        
        // TODO: remove when fixed bug ID 95339:
        // the thumb doesn't move according to the Value.
        // To repaint the thumb, we need to force a call to the protected method
        // BasicSliderUI.calculateThumbLocation() that is called by protected method
        // BasicSliderUI.calculateGeometry()
        
        // the easiest work around follows...
        setInverted(!isInverted());
        setInverted(!isInverted());
        

        }
    public void setValueAdjusting(boolean pValueAdjusting)
        {
        __sink.setValueIsAdjusting(pValueAdjusting);
        }
    //-- javax.swing.JSlider integration
    
    /**
    * Notification sent when any of the JSlider's Value, Minimum, Maximum,
    * Extent or Adjusting properties have been changed.
    * 
    * @see #stateChanged
    */
    public void onValueChanged()
        {
        }
    }
