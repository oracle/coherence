/* Class
*     _package.component.gUI.control.container.jComponent.jPanel.FindText
*/

package _package.component.gUI.control.container.jComponent.jPanel;

import _package.component.gUI.control.container.JComponent;
import _package.component.gUI.control.container.jComponent.JTextComponent;

public class FindText
        extends    _package.component.gUI.control.container.jComponent.JPanel
    {
    // Fields declarations
    
    /**
    * Property DIRECTION_DOWN
    *
    */
    public static final int DIRECTION_DOWN = 0;
    
    /**
    * Property DIRECTION_UP
    *
    */
    public static final int DIRECTION_UP = 1;
    
    /**
    * Property Host
    *
    * Specifies a "host" component for this FindText [dialog box] panel. 
    * @see #onInit
    */
    private transient _package.component.gUI.control.container.JComponent __m_Host;
    
    /**
    * Property MAX_PATTERN
    *
    * Max number of patterns cached by this dialog.
    */
    
    /**
    * Property SearchCaseSensitive
    *
    * Specifies whether the search should be case sensitive.
    */
    private transient boolean __m_SearchCaseSensitive;
    
    /**
    * Property SearchDirection
    *
    * Specifies the search direction: 1 for DOWN and 0 for UP.
    */
    private transient int __m_SearchDirection;
    
    /**
    * Property SearchPattern
    *
    * Specifies the current search pattern.
    */
    private transient String __m_SearchPattern;
    
    /**
    * Property SearchRegularExpression
    *
    * Specifies whether the search pattern is a regular expression.
    */
    private transient boolean __m_SearchRegularExpression;
    
    /**
    * Property SearchWords
    *
    * Specifies whether the search should only look for whole words.
    */
    private transient boolean __m_SearchWords;
    
    // Default constructor
    public FindText()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public FindText(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setResizable(false);
            setTBounds("0,0,395,115");
            setTConstraints("Center");
            setTitle("Find");
            setTLayout(null);
            setVisible(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new FindText$BG_Direction("BG_Direction", this, true), "BG_Direction");
        _addChild(new FindText$BTN_Cancel("BTN_Cancel", this, true), "BTN_Cancel");
        _addChild(new FindText$BTN_Next("BTN_Next", this, true), "BTN_Next");
        _addChild(new FindText$CBX_Find("CBX_Find", this, true), "CBX_Find");
        _addChild(new FindText$CHK_Case("CHK_Case", this, true), "CHK_Case");
        _addChild(new FindText$CHK_Reg("CHK_Reg", this, true), "CHK_Reg");
        _addChild(new FindText$CHK_Word("CHK_Word", this, true), "CHK_Word");
        _addChild(new FindText$KeyFind("KeyFind", this, true), "KeyFind");
        _addChild(new FindText$KeyFindNext("KeyFindNext", this, true), "KeyFindNext");
        _addChild(new FindText$KeyFindPrev("KeyFindPrev", this, true), "KeyFindPrev");
        _addChild(new FindText$KeyFindSelection("KeyFindSelection", this, true), "KeyFindSelection");
        _addChild(new FindText$LBL_Find("LBL_Find", this, true), "LBL_Find");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant MAX_PATTERN
    public int getMAX_PATTERN()
        {
        return 10;
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new FindText();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jPanel/FindText".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent;
        // import Component.GUI.Control.Container.JComponent.JTextComponent;
        

        }
    
    // Declared at the super level
    public void addNotify()
        {
        super.addNotify();
        
        (($CBX_Find) _findName("CBX_Find")).requestFocus();
        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        $CBX_Find CBX_Find = ($CBX_Find) _findName("CBX_Find");
        
        // only appy configuration info if the controls are empty
        
        // Pattern
        if (getSearchPattern().length() == 0)
            {
            String sPattern = config.getString(sPrefix + ".Pattern");
            if (sPattern != null && sPattern.length() > 0)
                {
                setSearchPattern(sPattern);
                }
            }
        
        // History
        if (CBX_Find.getItemCount() == 0)
            {
            String[] asItem = config.getStringArray(sPrefix + ".History", '\t');
            if (asItem != null && asItem.length > 0)
                {
                CBX_Find.setList(asItem);
                }
            }
        
        // SearchWords, CaseSensitive, RegularExpression
        setSearchWords            (config.getBoolean(sPrefix + ".Words" , isSearchWords()));
        setSearchCaseSensitive    (config.getBoolean(sPrefix + ".Case"  , isSearchCaseSensitive()));
        setSearchRegularExpression(config.getBoolean(sPrefix + ".RegExp", isSearchRegularExpression()));
        
        super.applyConfig(config, sPrefix);
        }
    
    /**
    * Brings up the "FindText" dialog box and performs a "find" operation on
    * the TextHost.
    * 
    * @param sPattern  (optional) the text to look for; if null the attempt
    * will be made to retrieve it from the host
    */
    public void doFind(String sPattern)
        {
        Component parent = get_Parent();
        String    sName  = null;
        
        JComponent host = getHost();
        
        if (sPattern == null || sPattern.length() == 0)
            {
            if (host instanceof JTextComponent)
                {
                sPattern = ((JTextComponent) host).getSelectedText();
                }
            else
                {
                sPattern = "";
                }
            }
        
        $CBX_Find CBX_Find = ($CBX_Find) _findName("CBX_Find");
        $BTN_Next BTN_Next = ($BTN_Next) _findName("BTN_Next");
        
        if (sPattern.length() == 0)
            {
            sPattern = CBX_Find.getText();
            }
        CBX_Find.setText(sPattern);
        
        BTN_Next.setEnabled(CBX_Find.getText().length() > 0);
        
        if (parent != null)
            {
            sName = get_Name();
            parent._removeChild(this);
            }
        
        setVisible(true);
        
        Object oAction = host.dialogBox(this, null);
        
        setVisible(false);
        
        if (parent != null)
            {
            get_Parent()._removeChild(this); // get_Parent() != parent
            parent._addChild(this, sName);
            }
        
        if (host.isEnabled())
            {
            host.requestFocus();
            }
        
        if (oAction != null)
            {
            performSearch(oAction);
            }
        }
    
    /**
    * Performs a "find next" operation on the TextHost.
    */
    public void doFindNext()
        {
        setSearchDirection(DIRECTION_DOWN);
        performSearch(null);
        }
    
    /**
    * Performs a "find previous" operation on the TextHost.
    */
    public void doFindPrev()
        {
        setSearchDirection(DIRECTION_UP);
        performSearch(null);
        }
    
    public void doFindSelection()
        {
        JComponent host = getHost();
        
        if (host instanceof JTextComponent)
            {
            setSearchPattern(((JTextComponent) host).getSelectedText());
            doFindNext();
            }

        }
    
    /**
    * Find the specified pattern on the specified text. This method could be
    * overriten if the host is not one of the component types that the FindText
    * is aware of and for which the sText parameter could be passed as null.
    * 
    * //TODO: when JDK 1.4 is out, change this to support regular expressions
    * and return value to java.lang.CharSequence
    * 
    * @return position of the match if found; -1 otherwise
    * 
    * @see #performSearch
    */
    public static int findMatch(String sText, String sPattern, int ofStart, boolean fCaseSens, boolean fRegExpr, boolean fWord, int iDir)
        {
        if (sText    == null || sText   .length() == 0 ||
            sPattern == null || sPattern.length() == 0)
            {
            return -1;
            }
        
        if (!fCaseSens)
            {
            sText    = sText   .toUpperCase();
            sPattern = sPattern.toUpperCase();
            }
        
        if (fRegExpr)
            {
            // TODO: 
            }
        
        if (fWord)
            {
            // TODO: whole word
            }
        
        int ofHit;
        
        if (iDir == DIRECTION_DOWN)
            {
            ofHit = sText.indexOf(sPattern, ofStart);
            if (ofHit == -1)
                {
                ofHit = sText.indexOf(sPattern);
                }
            }
        else
            {
            ofHit = sText.lastIndexOf(sPattern, ofStart);
            if (ofHit == -1)
                {
                ofHit = sText.lastIndexOf(sPattern);
                }
            }
        
        return ofHit;
        }
    
    // Declared at the super level
    /**
    * This method is called by  Component.Control.Container#addControl() as a
    * last chance to intervene during the construction/integration cycle.
    * A Control would override this if more than one AWT components should be
    * created for one Control or if the component should not be added to the
    * container (see Component...Window or Component...TabbedPanel).
    * This method can also be used to make sure that the parent is of the
    * allowed type (i.e. TabbedPanel is only allowed to be added into the
    * JTabbedPane).
    *  
    * @param  fAdd is true <b>only</b> when this is the frist call (from
    * addControl()) and an override is supposed to tie all the pieces together;
    * false in all other situations
    * 
    * @return AWT component that is added to a container [integratee].
    * 
    * @see Component.Control.Container.Window
    * @see Component.GUI.Control.Container.JComponent
    * @see
    * Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem.JMenu
    * @see Component.GUI.Control.Container.JComponent.JPanel.ButtonGroupPanel
    */
    public java.awt.Component getAWTContainee(boolean fAdd)
        {
        return isVisible() ? super.getAWTContainee(fAdd) : null;
        }
    
    // Accessor for the property "Host"
    /**
    * Getter for property Host.<p>
    * Specifies a "host" component for this FindText [dialog box] panel. 
    * @see #onInit
    */
    public _package.component.gUI.control.container.JComponent getHost()
        {
        return __m_Host;
        }
    
    // Accessor for the property "SearchDirection"
    /**
    * Getter for property SearchDirection.<p>
    * Specifies the search direction: 1 for DOWN and 0 for UP.
    */
    public int getSearchDirection()
        {
        return (($RB_Down) _findName("RB_Down")).isSelected() ? DIRECTION_DOWN : DIRECTION_UP;
        }
    
    // Accessor for the property "SearchPattern"
    /**
    * Getter for property SearchPattern.<p>
    * Specifies the current search pattern.
    */
    public String getSearchPattern()
        {
        return (($CBX_Find) _findName("CBX_Find")).getText();
        }
    
    // Accessor for the property "SearchCaseSensitive"
    /**
    * Getter for property SearchCaseSensitive.<p>
    * Specifies whether the search should be case sensitive.
    */
    public boolean isSearchCaseSensitive()
        {
        return (($CHK_Case) _findName("CHK_Case")).isSelected();
        }
    
    // Accessor for the property "SearchRegularExpression"
    /**
    * Getter for property SearchRegularExpression.<p>
    * Specifies whether the search pattern is a regular expression.
    */
    public boolean isSearchRegularExpression()
        {
        return (($CHK_Reg) _findName("CHK_Reg")).isSelected();
        }
    
    // Accessor for the property "SearchWords"
    /**
    * Getter for property SearchWords.<p>
    * Specifies whether the search should only look for whole words.
    */
    public boolean isSearchWords()
        {
        return (($CHK_Word) _findName("CHK_Word")).isSelected();
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        _assert(!isVisible(), "FindText must be initially invisible");
        
        super.onInit();
        
        setHost((JComponent) get_Parent());
        
        // see setHost for binding -- should be soft coded...
        }
    
    /**
    * Perform the search based on the current settings. This method could be
    * overriten if the host is not one of the component types that the FindText
    * is aware of.
    * 
    * @param oAction  if the search is initiated by the dialog box, this
    * carries the value returned by the dialogBox() call; otherwise is null.
    */
    protected void performSearch(Object oAction)
        {
        String sPattern = getSearchPattern();
        if (sPattern.length() == 0)
            {
            return;
            }
        
        updateSearchHistory(sPattern);
        
        JComponent host      = getHost();
        boolean    fCaseSens = isSearchCaseSensitive();
        boolean    fRegExpr  = isSearchRegularExpression();
        boolean    fWord     = isSearchWords();
        int        iDir      = getSearchDirection();
        String     sText     = null;
        int        ofStart   = 0;
        
        if (host instanceof JTextComponent)
            {
            // look up now
            JTextComponent Text = (JTextComponent) host;
            
            sText   = Text.getText();
            ofStart = iDir == DIRECTION_DOWN ?
                Text.getSelectionEnd() : Text.getSelectionStart() - 1;
        
            if (ofStart < 0 || ofStart >= sText.length())
                {
                ofStart = 0;
                }
            }
        
        int ofHit = findMatch(sText, sPattern, ofStart, fCaseSens, fRegExpr, fWord, iDir);
        
        if (ofHit >= 0)
            {
            if (host instanceof JTextComponent)
                {
                ((JTextComponent) host).select(ofHit, ofHit + sPattern.length());
                }
            }
        else
            {
            _beep();
            }
        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        $CBX_Find CBX_Find = ($CBX_Find) _findName("CBX_Find");
        
        // Pattern
        String sPattern = CBX_Find.getText();
        if (sPattern.length() > 0)
            {
            config.putString(sPrefix + ".Pattern", sPattern);
            }
        
        // History
        String[] asItem = CBX_Find.getList();
        
        if (asItem.length > 0)
            {
            config.putStringArray(sPrefix + ".History", asItem, '\t');
            }
        
        // SearchWords, CaseSensitive, RegularExpression
        config.putBoolean(sPrefix + ".Words" , isSearchWords());
        config.putBoolean(sPrefix + ".Case"  , isSearchCaseSensitive());
        config.putBoolean(sPrefix + ".RegExp", isSearchRegularExpression());
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "Host"
    /**
    * Setter for property Host.<p>
    * Specifies a "host" component for this FindText [dialog box] panel. 
    * @see #onInit
    */
    public void setHost(_package.component.gUI.control.container.JComponent pHost)
        {
        JComponent hostOld = getHost();
        JComponent hostNew = pHost;
        
        if (hostNew == hostOld)
            {
            return;
            }
        
        if (hostOld != null)
            {
            (($KeyFind)          _findName("KeyFind"))         .unbind(hostOld);
            (($KeyFindNext)      _findName("KeyFindNext"))     .unbind(hostOld);
            (($KeyFindPrev)      _findName("KeyFindPrev"))     .unbind(hostOld);
            (($KeyFindSelection) _findName("KeyFindSelection")).unbind(hostOld);
            }
        
        __m_Host = (hostNew);
        
        if (hostNew != null)
            {
            (($KeyFind)          _findName("KeyFind"))         .bind(hostNew);
            (($KeyFindNext)      _findName("KeyFindNext"))     .bind(hostNew);
            (($KeyFindPrev)      _findName("KeyFindPrev"))     .bind(hostNew);
            (($KeyFindSelection) _findName("KeyFindSelection")).bind(hostNew);
            }
        }
    
    // Accessor for the property "SearchCaseSensitive"
    /**
    * Setter for property SearchCaseSensitive.<p>
    * Specifies whether the search should be case sensitive.
    */
    public void setSearchCaseSensitive(boolean pSearchCaseSensitive)
        {
        (($CHK_Case) _findName("CHK_Case")).setSelected(pSearchCaseSensitive);
        }
    
    // Accessor for the property "SearchDirection"
    /**
    * Setter for property SearchDirection.<p>
    * Specifies the search direction: 1 for DOWN and 0 for UP.
    */
    public void setSearchDirection(int pSearchDirection)
        {
        if (pSearchDirection == DIRECTION_DOWN)
            {
            (($RB_Down) _findName("RB_Down")).setSelected(true);
            }
        else
            {
            (($RB_Up) _findName("RB_Up")).setSelected(true);
            }
        }
    
    // Accessor for the property "SearchPattern"
    /**
    * Setter for property SearchPattern.<p>
    * Specifies the current search pattern.
    */
    public void setSearchPattern(String pSearchPattern)
        {
        (($CBX_Find) _findName("CBX_Find")).setText(pSearchPattern);
        }
    
    // Accessor for the property "SearchRegularExpression"
    /**
    * Setter for property SearchRegularExpression.<p>
    * Specifies whether the search pattern is a regular expression.
    */
    public void setSearchRegularExpression(boolean pSearchRegularExpression)
        {
        (($CHK_Reg) _findName("CHK_Reg")).setSelected(pSearchRegularExpression);
        }
    
    // Accessor for the property "SearchWords"
    /**
    * Setter for property SearchWords.<p>
    * Specifies whether the search should only look for whole words.
    */
    public void setSearchWords(boolean pSearchWords)
        {
        (($CHK_Word) _findName("CHK_Word")).setSelected(pSearchWords);
        }
    
    protected void updateSearchHistory(String sPattern)
        {
        (($CBX_Find) _findName("CBX_Find")).
            updateMRUList(sPattern, getMAX_PATTERN());
        }
    }
