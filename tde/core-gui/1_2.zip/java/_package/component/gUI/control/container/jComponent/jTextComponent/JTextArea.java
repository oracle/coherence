/* Class
*     _package.component.gUI.control.container.jComponent.jTextComponent.JTextArea
*/

package _package.component.gUI.control.container.jComponent.jTextComponent;

import com.tangosol.run.component.EventDeathException;
import java.awt.Event;
import java.awt.event.KeyEvent;
import javax.swing.JTextArea; // as _JTextArea
import javax.swing.text.BadLocationException;

/*
* Integrates
*     javax.swing.JTextArea
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class JTextArea
        extends    _package.component.gUI.control.container.jComponent.JTextComponent
    {
    // Fields declarations
    
    /**
    * Property AutoIndent
    *
    * If set to true, the JTextArea component will indent each newly entered
    * line according to the previous line.
    */
    private boolean __m_AutoIndent;
    
    /**
    * Property LineCount
    *
    * Calculates the number of lines contained in the area.
    */
    
    /**
    * Property LineWrap
    *
    * Specifies the line-wrapping policy of the text area.  If set to true the
    * lines will be wrapped if they are too long to fit within the allocated
    * width.  If set to false, the lines will always be unwrapped.
    * 
    * @see #WrapStyleWord property
    */
    private transient boolean __m_LineWrap;
    
    /**
    * Property TabAllowed
    *
    * Specifies whether tab charachters are allowed or should be automatically
    * replaced with a number of spaces (according to the TabSize property)
    */
    private boolean __m_TabAllowed;
    
    /**
    * Property TabSize
    *
    */
    private transient int __m_TabSize;
    
    /**
    * Property WrapStyleWord
    *
    * Specifies the style of wrapping used if the text area is wrapping lines. 
    * If set to true the lines will be wrapped at word boundries (i.e.
    * whitespace) if they are too long to fit within the allocated width.  If
    * set to false, the lines will be wrapped at character boundries.
    * 
    * @see #LineWrap property
    */
    private transient boolean __m_WrapStyleWord;
    
    // fields used by the integration model:
    private sink_JTextArea __sink;
    private javax.swing.JTextArea __feed;
    
    // Default constructor
    public JTextArea()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JTextArea(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            setScrollable(true);
            setTabAllowed(false);
            setTabSize(4);
            setTBounds("0,20,100,100");
            setTFont("DefaultProportional");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new _package.component.gUI.control.container.jComponent.JTextComponent$KeyRedo("KeyRedo", this, true), "KeyRedo");
        _addChild(new _package.component.gUI.control.container.jComponent.JTextComponent$KeyUndo("KeyUndo", this, true), "KeyUndo");
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_JTextArea.__tloPeer.setObject(this);
            new jb_JTextArea(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new JTextArea();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/jComponent/jTextComponent/JTextArea".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.JTextArea integration
    // Access optimization
    /**
    * Setter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Sink(Object pSink)
        {
        __sink = (sink_JTextArea) pSink;
        super.set_Sink(pSink);
        }
    /**
    * Setter for property _Feed.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.JTextArea) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    /**
    * Setter for property Text.<p>
    * Specifies the text contained in this TextComponent.
    */
    public void setText(String pText)
        {
        super.setText(pText);
        
        select(0, 0);
        }
    /**
    * Getter for property LineCount.<p>
    * Calculates the number of lines contained in the area.
    */
    public int getLineCount()
        {
        return __sink.getLineCount();
        }
    /**
    * Getter for property LineWrap.<p>
    * Specifies the line-wrapping policy of the text area.  If set to true the
    * lines will be wrapped if they are too long to fit within the allocated
    * width.  If set to false, the lines will always be unwrapped.
    * 
    * @see #WrapStyleWord property
    */
    public boolean isLineWrap()
        {
        return __sink.getLineWrap();
        }
    protected int getRowHeight()
        {
        return __sink.getRowHeight();
        }
    public int getVisibleRows()
        {
        return __sink.getRows();
        }
    /**
    * Getter for property TabSize.<p>
    */
    public int getTabSize()
        {
        return __sink.getTabSize();
        }
    /**
    * Getter for property WrapStyleWord.<p>
    * Specifies the style of wrapping used if the text area is wrapping lines. 
    * If set to true the lines will be wrapped at word boundries (i.e.
    * whitespace) if they are too long to fit within the allocated width.  If
    * set to false, the lines will be wrapped at character boundries.
    * 
    * @see #LineWrap property
    */
    public boolean isWrapStyleWord()
        {
        return __sink.getWrapStyleWord();
        }
    /**
    * Setter for property LineWrap.<p>
    * Specifies the line-wrapping policy of the text area.  If set to true the
    * lines will be wrapped if they are too long to fit within the allocated
    * width.  If set to false, the lines will always be unwrapped.
    * 
    * @see #WrapStyleWord property
    */
    public void setLineWrap(boolean pLineWrap)
        {
        __sink.setLineWrap(pLineWrap);
        }
    public void setVisibleRows(int pVisibleRows)
        {
        __sink.setRows(pVisibleRows);
        }
    /**
    * Setter for property TabSize.<p>
    */
    public void setTabSize(int pTabSize)
        {
        __sink.setTabSize(pTabSize);
        }
    /**
    * Setter for property WrapStyleWord.<p>
    * Specifies the style of wrapping used if the text area is wrapping lines. 
    * If set to true the lines will be wrapped at word boundries (i.e.
    * whitespace) if they are too long to fit within the allocated width.  If
    * set to false, the lines will be wrapped at character boundries.
    * 
    * @see #LineWrap property
    */
    public void setWrapStyleWord(boolean pWrapStyleWord)
        {
        __sink.setWrapStyleWord(pWrapStyleWord);
        }
    //-- javax.swing.JTextArea integration
    
    // Declared at the super level
    public void _imports()
        {
        // import com.tangosol.run.component.EventDeathException;
        // import javax.swing.JTextArea as _JTextArea;
        // import javax.swing.text.BadLocationException;
        
        

        }
    
    /**
    * Determines the offset of the end of the given line.
    * 
    * @param iLine  the line number to translate >= 0
    * 
    * @return the offset >= 0
    * 
    * @exception BadLocationException thrown if the line is less than zero or
    * greater or equal to the number of lines contained in the document (as
    * reported by getLineCount).
    */
    public int getLineEndOffset(int iLine)
        {
        try
            {
            int of = ((_JTextArea) get_Feed()).getLineEndOffset(iLine);
        
            // patch for a JDK bug
            int cLen = getTextLength();
            return of < cLen ? of : cLen;
            }
        catch (BadLocationException e)
            {
            return -1;
            }
        }
    
    /**
    * Translates an offset into the components text to a  line number.
    * 
    * @param ofPos the offset >= 0
    * 
    * @return the line number >= 0
    * 
    * @exception BadLocationException thrown if the offset is  less than zero
    * or greater than the document length.
    */
    public int getLineOfOffset(int ofPos)
        {
        try
            {
            return ((_JTextArea) get_Feed()).getLineOfOffset(ofPos);
            }
        catch (BadLocationException e)
            {
            return -1;
            }
        }
    
    /**
    * Determines the offset of the start of the given line.
    * 
    * @param iLine  the line number to translate >= 0
    * 
    * @return the offset >= 0
    * 
    * @exception BadLocationException thrown if the line is less than zero or
    * greater or equal to the number of lines contained in the document (as
    * reported by getLineCount).
    */
    public int getLineStartOffset(int iLine)
        {
        try
            {
            return ((_JTextArea) get_Feed()).getLineStartOffset(iLine);
            }
        catch (BadLocationException e)
            {
            return -1;
            }
        }
    
    // Accessor for the property "AutoIndent"
    /**
    * Getter for property AutoIndent.<p>
    * If set to true, the JTextArea component will indent each newly entered
    * line according to the previous line.
    */
    public boolean isAutoIndent()
        {
        return __m_AutoIndent;
        }
    
    // Accessor for the property "TabAllowed"
    /**
    * Getter for property TabAllowed.<p>
    * Specifies whether tab charachters are allowed or should be automatically
    * replaced with a number of spaces (according to the TabSize property)
    */
    public boolean isTabAllowed()
        {
        return __m_TabAllowed;
        }
    
    // Declared at the super level
    public void onKeyPressed(char keyChar, int keyCode, int modifiers)
        {
        // import java.awt.Event;
        // import java.awt.event.KeyEvent;
        
        super.onKeyPressed(keyChar, keyCode, modifiers);
        
        if (keyChar == KeyEvent.VK_TAB         &&
           (modifiers & Event.CTRL_MASK) == 0  &&
           !isTabAllowed()                     &&
           getSelectedText().indexOf('\n') >= 0)
            {
            // suppress the regular TAB processing
            throw new EventDeathException();
            }
        }
    
    // Declared at the super level
    /**
    * JTextComponents almost never gets the keyTyped event (except BackSpace,
    * Enter...) !!!
    * 
    * @see http://developer.java.sun.com/developer/bugParade/bugs/4197167.html
    */
    public void onKeyTyped(char keyChar, int modifiers)
        {
        // import java.awt.Event;
        // import java.awt.event.KeyEvent;
        
        super.onKeyTyped(keyChar, modifiers);
        
        if (!isEditable())
            {
            return;
            }
        
        if (keyChar == KeyEvent.VK_TAB         &&
            (modifiers & Event.CTRL_MASK) == 0 && // "Ctrl-Tab" is for navigation
            !isTabAllowed())
            {
            if (getSelectedText().indexOf('\n') >= 0)
                {
                boolean fForward = (modifiers & Event.SHIFT_MASK) == 0;
        
                shiftSelection(fForward);
        
                throw new EventDeathException(); // suppress the regular "TAB" processing
                }
            else
                {
                int    nTabSize = getTabSize();
                char[] PAD      = new char[nTabSize];
                for (int i = 0; i < nTabSize; i++)
                    {
                    PAD[i] = ' ';
                    }
        
                // since we are processing the keyTyped event, the CaretPosition must be > 0
                int iPos  = getCaretPosition() - 1;
                int iLine = getLineOfOffset(iPos);
        
                if (iLine >= 0)
                    {
                    // replace the tab with spaces
                    int iOff  = iPos - getLineStartOffset(iLine);
                    replaceRange(new String(PAD, 0, nTabSize - iOff % nTabSize), iPos, iPos+1);
                    }
                }
            }
        
        if (keyChar == KeyEvent.VK_ENTER                            &&
            (modifiers & (Event.CTRL_MASK | Event.SHIFT_MASK)) == 0 &&
            isAutoIndent())
            {
        	// since we are processing the keyTyped event, the CaretPosition must be > 0
            int iPos  = getCaretPosition() - 1;
            int iLine = getLineOfOffset(iPos);
        
        	String sText = getText();
        
            // work-around a JDK bug 4135578 -- TODO: remove when fixed
            if (sText.charAt(iPos) != '\n')
                {
                throw new EventDeathException();
                }
        
            if (iLine >= 0)
                {
                int iStart = getLineStartOffset(iLine);
                int iEnd   = getLineEndOffset  (iLine);
        
                if (iEnd - iStart > 1)
                    {
                    char[] acLine = sText.substring(iStart, iEnd - 1).toCharArray();
        
                    // get the indent from the previous line
                    int  iIndent;
                    for (iIndent = 0;
                         iIndent < acLine.length && Character.isWhitespace(acLine[iIndent]);
                         iIndent++)
                        {}
        
                    if (iIndent > 0)
                        {
                        // indent
                        insert(new String(acLine, 0, iIndent), iPos + 1);
                        setCaretPosition(iPos + 1 + iIndent);
                        }
        
                    // remove trailing spaces
                    int  iTrail;
                    for (iTrail = acLine.length - 1;
                         iTrail >= 0 && Character.isWhitespace(acLine[iTrail]);
                         iTrail--)
                        {}
        
                    if (iTrail < acLine.length - 1)
                        {
                        replaceRange("", iStart + iTrail + 1, iEnd - 1);
                        }
                    }
                }
            }
        }
    
    /**
    * Helper method that selects (highlights) the entire line
    * 
    * @param iLine the number of the line to be selected.
    */
    public void selectLine(int iLine)
        {
        int ofStart = getLineStartOffset(iLine);
        int ofEnd   = getLineEndOffset  (iLine);
        
        if (ofStart >= 0 && ofEnd > ofStart)
            {
            select(ofStart, ofEnd - 1);
            }
        }
    
    // Accessor for the property "AutoIndent"
    /**
    * Setter for property AutoIndent.<p>
    * If set to true, the JTextArea component will indent each newly entered
    * line according to the previous line.
    */
    public void setAutoIndent(boolean pAutoIndent)
        {
        __m_AutoIndent = pAutoIndent;
        }
    
    // Accessor for the property "TabAllowed"
    /**
    * Setter for property TabAllowed.<p>
    * Specifies whether tab charachters are allowed or should be automatically
    * replaced with a number of spaces (according to the TabSize property)
    */
    public void setTabAllowed(boolean pTabAllowed)
        {
        __m_TabAllowed = pTabAllowed;
        }
    
    /**
    * Shifts the selected text in this JTextArea component.
    * 
    * @param fForward  if set to true shifts the selection forward (according
    * to the value of TabSize property); otherwise shifts backward.
    */
    public void shiftSelection(boolean fForward)
        {
        int    nTabSize = getTabSize();
        char[] PAD      = new char[nTabSize];
        for (int i = 0; i < nTabSize; i++)
            {
            PAD[i] = ' ';
            }
        
        // we may need to extend selection to capture the
        // first and last lines entirely
        String sText      = getText();
        int    ofStart    = getSelectionStart();
        int    ofEnd      = getSelectionEnd();
        int    iLineStart = getLineOfOffset(ofStart);
        int    iLineEnd   = getLineOfOffset(ofEnd);
        
        boolean fAdjustLastLine = (sText.charAt(ofEnd - 1) == '\n');
        if (fAdjustLastLine)
            {
            iLineEnd--;
            ofEnd--;
            }
        
        ofStart = getLineStartOffset(iLineStart);
        ofEnd   = getLineEndOffset  (iLineEnd);
        
        StringBuffer sb = new StringBuffer();
        for (int iLine = iLineStart; iLine <= iLineEnd; iLine++)
            {
            int    ofLineStart = iLine == iLineStart ? ofStart : getLineStartOffset(iLine);
            int    ofLineEnd   = iLine == iLineEnd   ? ofEnd   : getLineEndOffset  (iLine);
            String sLine       = sText.substring(ofLineStart, ofLineEnd);
        
            if (fForward)
                {
                if (sLine.trim().length() > 0)
                    {
                    sb.append(PAD);
                    }
                sb.append(sLine);
                }
            else
                {
                int ofCut = Math.min(nTabSize, sLine.length());
                for (int of = 0; of < ofCut; of++)
                    {
                    char ch = sLine.charAt(of);
                    if (ch == '\n' || ch > ' ')
                        {
                        ofCut = of;
                        break;
                        }
                    }
                sb.append(sLine.substring(ofCut));
                }
            }
        
        replaceRange(sb.toString(), ofStart, ofEnd);
        select(ofStart, ofStart + sb.length());
        }
    }
