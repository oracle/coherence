/* Class
*      sink_JWindow
*
* automatically generated "Sink" which
* represents a footprint of the class
*      javax.swing.JWindow
* when used as a component callback by 
*      Component.GUI.Control.Container.Window.JWindow
*/

package _package.component.gUI.control.container.window;

public class sink_JWindow
       extends _package.component.gUI.control.container.sink_Window
    {
    private jb_JWindow __peer;
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_JWindow()
        {
        }
    
    // this (protected) constructor is used by the feed
    protected sink_JWindow(jb_JWindow feed)
        {
        super();
        __peer = feed;
        }
    
    // Retrieves the feed object for this sink
    public Object get_Feed()
        {
        return __peer;
        }
    
    // methods integrated and/or remoted
    public void add(java.awt.Component comp, Object constraints, int index)
        {
        __peer.super$add(comp, constraints, index);
        }
    public void remove(java.awt.Component comp)
        {
        __peer.super$remove(comp);
        }
    public void addFocusListener(java.awt.event.FocusListener l)
        {
        __peer.super$addFocusListener(l);
        }
    public void addKeyListener(java.awt.event.KeyListener l)
        {
        __peer.super$addKeyListener(l);
        }
    public void addMouseListener(java.awt.event.MouseListener l)
        {
        __peer.super$addMouseListener(l);
        }
    public void addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        __peer.super$addMouseMotionListener(l);
        }
    public void addNotify()
        {
        __peer.super$addNotify();
        }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        __peer.super$addPropertyChangeListener(l);
        }
    public void addWindowListener(java.awt.event.WindowListener l)
        {
        __peer.super$addWindowListener(l);
        }
    public void dispose()
        {
        __peer.super$dispose();
        }
    public void doLayout()
        {
        __peer.super$doLayout();
        }
    public java.awt.Color getBackground()
        {
        return __peer.super$getBackground();
        }
    public java.awt.Rectangle getBounds()
        {
        return __peer.super$getBounds();
        }
    public java.awt.Cursor getCursor()
        {
        return __peer.super$getCursor();
        }
    public java.awt.Font getFont()
        {
        return __peer.super$getFont();
        }
    public java.awt.Color getForeground()
        {
        return __peer.super$getForeground();
        }
    public java.awt.Insets getInsets()
        {
        return __peer.super$getInsets();
        }
    public java.awt.LayoutManager getLayout()
        {
        return __peer.super$getLayout();
        }
    public java.awt.Point getLocation()
        {
        return __peer.super$getLocation();
        }
    public java.awt.Point getLocationOnScreen()
        {
        return __peer.super$getLocationOnScreen();
        }
    public java.awt.Window getOwner()
        {
        return __peer.super$getOwner();
        }
    public java.awt.Dimension getSize()
        {
        return __peer.super$getSize();
        }
    public boolean isEnabled()
        {
        return __peer.super$isEnabled();
        }
    public boolean isFocusTraversable()
        {
        return __peer.super$isFocusTraversable();
        }
    public boolean isShowing()
        {
        return __peer.super$isShowing();
        }
    public boolean isVisible()
        {
        return __peer.super$isVisible();
        }
    public void paint(java.awt.Graphics g)
        {
        __peer.super$paint(g);
        }
    public void removeFocusListener(java.awt.event.FocusListener l)
        {
        __peer.super$removeFocusListener(l);
        }
    public void removeKeyListener(java.awt.event.KeyListener l)
        {
        __peer.super$removeKeyListener(l);
        }
    public void removeMouseListener(java.awt.event.MouseListener l)
        {
        __peer.super$removeMouseListener(l);
        }
    public void removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        __peer.super$removeMouseMotionListener(l);
        }
    public void removeNotify()
        {
        __peer.super$removeNotify();
        }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        __peer.super$removePropertyChangeListener(l);
        }
    public void removeWindowListener(java.awt.event.WindowListener l)
        {
        __peer.super$removeWindowListener(l);
        }
    public void requestFocus()
        {
        __peer.super$requestFocus();
        }
    public void setBackground(java.awt.Color p_Background)
        {
        __peer.super$setBackground(p_Background);
        }
    public void setBounds(java.awt.Rectangle p_Bounds)
        {
        __peer.super$setBounds(p_Bounds);
        }
    public void setCursor(java.awt.Cursor p_Cursor)
        {
        __peer.super$setCursor(p_Cursor);
        }
    public void setFont(java.awt.Font p_Font)
        {
        __peer.super$setFont(p_Font);
        }
    public void setForeground(java.awt.Color p_Foreground)
        {
        __peer.super$setForeground(p_Foreground);
        }
    public void setLayout(java.awt.LayoutManager p_Layout)
        {
        __peer.super$setLayout(p_Layout);
        }
    public void setLocation(java.awt.Point p_Location)
        {
        __peer.super$setLocation(p_Location);
        }
    public void setSize(java.awt.Dimension p_Size)
        {
        __peer.super$setSize(p_Size);
        }
    public void setEnabled(boolean pEnabled)
        {
        __peer.super$setEnabled(pEnabled);
        }
    public void setVisible(boolean pVisible)
        {
        __peer.super$setVisible(pVisible);
        }
    public void toFront()
        {
        __peer.super$toFront();
        }
    public void validate()
        {
        __peer.super$validate();
        }
    }
