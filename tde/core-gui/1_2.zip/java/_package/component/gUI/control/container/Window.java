/* Class
*     _package.component.gUI.control.container.Window
*/

package _package.component.gUI.control.container;

import _package.component.Application;
import _package.component.application.GUI;
import _package.component.gUI.Control;
import _package.component.gUI.Dimension;
import _package.component.gUI.Point;
import _package.component.gUI.control.container.jComponent.JPanel;
import _package.component.gUI.control.container.window.dialog.JDialog;
import _package.component.gUI.control.container.window.frame.JFrame;
import com.tangosol.run.component.EventDeathException;
import java.awt.Toolkit;
import java.awt.Window; // as _Window
import java.awt.event.WindowEvent;

/*
* Integrates
*     java.awt.Window
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class Window
        extends    _package.component.gUI.control.Container
        implements java.awt.event.WindowListener
    {
    // Fields declarations
    
    /**
    * Property _Owner
    *
    */
    
    /**
    * Property Owner
    *
    * Specifies the owner window for this dialog
    */
    private Window __m_Owner;
    
    /**
    * Property VisibleDeferred
    *
    */
    private transient boolean __m_VisibleDeferred;
    
    // fields used by the integration model:
    private sink_Window __sink;
    private java.awt.Window __feed;
    
    // Default constructor
    public Window()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Window(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setFocusable(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // event initialization
        __initEvents();
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        super.__initEvents();
        
        addWindowListener(this);
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Window();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/control/container/Window".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ WindowListener dispatcher
    private com.tangosol.util.Listeners __WindowListeners;
    private void addWindowListener$Router(java.awt.event.WindowListener l)
        {
        __sink.addWindowListener(l);
        }
    public void addWindowListener(java.awt.event.WindowListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __WindowListeners;
        if (_listeners == null)
            {
            __WindowListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addWindowListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeWindowListener$Router(java.awt.event.WindowListener l)
        {
        __sink.removeWindowListener(l);
        }
    public void removeWindowListener(java.awt.event.WindowListener l)
        {
        com.tangosol.util.Listeners _listeners = __WindowListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeWindowListener$Router(this);
            }
        }
    private void windowActivated$Dispatch(java.awt.event.WindowEvent evt)
        {
        java.util.EventListener[] targets = __WindowListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.WindowListener target = (java.awt.event.WindowListener) targets[i];
            if (target != this)
                {
                target.windowActivated(evt);
                }
            }
        }
    public void windowActivated(java.awt.event.WindowEvent evt)
        {
        try
            {
            onWindowActivated();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        windowActivated$Dispatch(evt);
        }
    private void windowClosed$Dispatch(java.awt.event.WindowEvent evt)
        {
        java.util.EventListener[] targets = __WindowListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.WindowListener target = (java.awt.event.WindowListener) targets[i];
            if (target != this)
                {
                target.windowClosed(evt);
                }
            }
        }
    public void windowClosed(java.awt.event.WindowEvent evt)
        {
        try
            {
            onWindowClosed();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        windowClosed$Dispatch(evt);

        }
    private void windowClosing$Dispatch(java.awt.event.WindowEvent evt)
        {
        java.util.EventListener[] targets = __WindowListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.WindowListener target = (java.awt.event.WindowListener) targets[i];
            if (target != this)
                {
                target.windowClosing(evt);
                }
            }
        }
    public void windowClosing(java.awt.event.WindowEvent evt)
        {
        try
            {
            onWindowClosing();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        windowClosing$Dispatch(evt);

        }
    private void windowDeactivated$Dispatch(java.awt.event.WindowEvent evt)
        {
        java.util.EventListener[] targets = __WindowListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.WindowListener target = (java.awt.event.WindowListener) targets[i];
            if (target != this)
                {
                target.windowDeactivated(evt);
                }
            }
        }
    public void windowDeactivated(java.awt.event.WindowEvent evt)
        {
        try
            {
            onWindowDeactivated();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        windowDeactivated$Dispatch(evt);

        }
    private void windowDeiconified$Dispatch(java.awt.event.WindowEvent evt)
        {
        java.util.EventListener[] targets = __WindowListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.WindowListener target = (java.awt.event.WindowListener) targets[i];
            if (target != this)
                {
                target.windowDeiconified(evt);
                }
            }
        }
    public void windowDeiconified(java.awt.event.WindowEvent evt)
        {
        try
            {
            onWindowDeiconified();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        windowDeiconified$Dispatch(evt);

        }
    private void windowIconified$Dispatch(java.awt.event.WindowEvent evt)
        {
        java.util.EventListener[] targets = __WindowListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.WindowListener target = (java.awt.event.WindowListener) targets[i];
            if (target != this)
                {
                target.windowIconified(evt);
                }
            }
        }
    public void windowIconified(java.awt.event.WindowEvent evt)
        {
        try
            {
            onWindowIconified();
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        windowIconified$Dispatch(evt);

        }
    private void windowOpened$Dispatch(java.awt.event.WindowEvent evt)
        {
        java.util.EventListener[] targets = __WindowListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.WindowListener target = (java.awt.event.WindowListener) targets[i];
            if (target != this)
                {
                target.windowOpened(evt);
                }
            }
        }
    public void windowOpened(java.awt.event.WindowEvent evt)
        {
        try
            {
            // this event could be sent twice in the case when the window was
            // initialized invisible (see #setVisible and #onInit):
        
            boolean fVisible = isVisible(); // could be changed by onInitUI
            
            if (!isVisibleDeferred())
                {
                if (get_Parent() == null)
                    {
                    setVisibleDeferred(true);
                    onInitUI();
                    }
                }
        
            if (fVisible)
                {
                onWindowOpened();
                }
            }
        catch (EventDeathException ex)
            {
            return;
            }
        
        windowOpened$Dispatch(evt);
        }
    //-- WindowListener dispatcher
    
    //++ java.awt.Window integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_Window) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (java.awt.Window) pFeed;
        super.set_Feed(pFeed);
        }
    private void _initFeed$AutoGen(java.awt.Frame _ownerFrame)
        {
        jb_Window.__tloPeer.setObject(this);
        new jb_Window(_ownerFrame, this, false); // this sets the Sink which sets the Feed
        __init();
        }
    public void _initFeed(java.awt.Frame _ownerFrame)
        {
        _initFeed$AutoGen(_ownerFrame);
        setOwner((Window) _findFeed(_ownerFrame));

        }
    private void _initFeed$AutoGen(java.awt.Window _ownerWindow)
        {
        jb_Window.__tloPeer.setObject(this);
        new jb_Window(_ownerWindow, this, false); // this sets the Sink which sets the Feed
        __init();
        }
    public void _initFeed(java.awt.Window _ownerWindow)
        {
        _initFeed$AutoGen(_ownerWindow);
        setOwner((Window) _findFeed(_ownerWindow));

        }
    // properties integration
    // methods integration
    public void setVisible(boolean pVisible)
        {
        if (is_Constructed())
            {
            super.setVisible(pVisible);
            }
        else
            {
            setVisibleDeferred(pVisible);
            }
        }
    /**
    * Releases all of the native screen resources used by this Window,  its
    * subcomponents, and all of its owned children. That is, the resources for
    * these Components will be destroyed, any memory they consume will be
    * returned to the OS, and they will be marked as undisplayable. As a result
    * of this, the removeNotify will be called (possibly on a different thread).
    */
    public void dispose()
        {
        __sink.dispose();
        }
    public java.awt.Window get_Owner()
        {
        return __sink.getOwner();
        }
    public void toFront()
        {
        __sink.toFront();
        }
    //-- java.awt.Window integration
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.Application;
        // import Component.GUI.Control;
        // import Component.GUI.Control.Container.JComponent.JPanel;
        // import Component.GUI.Control.Container.Window.Dialog.JDialog;
        // import com.tangosol.run.component.EventDeathException;
        // import java.awt.Window as _Window;
        
        

        }
    
    /**
    * Brings up a [modeless] dialog box.
    * 
    * @see #dialogBox
    */
    public _package.component.gUI.control.container.window.dialog.JDialog createDialogBox(_package.component.gUI.control.container.jComponent.JPanel panel, Object oDialogPrm, boolean fModal)
        {
        JDialog dlg = createDialogInvisible(panel, oDialogPrm, fModal);
        
        dlg.setVisible(true);
        return dlg;
        }
    
    /**
    * Window specific dialogBox implementation.
    */
    private _package.component.gUI.control.container.window.dialog.JDialog createDialogInvisible(_package.component.gUI.control.container.jComponent.JPanel panel, Object oDialogPrm, boolean fModal)
        {
        panel.setDialogParam(oDialogPrm);
        
        JDialog dlg = panel.makeDialog(this);
        
        dlg.setModal(fModal);
        
        // if dialog is modal     -- the frame is disabled
        // if dialog is not modal -- the frame is enabled
        setEnabled(!fModal);
        
        return dlg;
        }
    
    // Declared at the super level
    /**
    * Bring up the specified dialog box.
    * 
    * @param panel  the dialog's main panel
    * @param oDialogPrm  dialog parameter (often an array of objects)
    * 
    * @return result of the dialog's execution (value of dialog main panel's
    * property DialogResult)
    * 
    * @see Window#dialogBox
    * @see JDesktopPane#dialogBox
    */
    public Object dialogBox(_package.component.gUI.control.container.jComponent.JPanel panel, Object oDialogPrm)
        {
        JDialog dlg = createDialogInvisible(panel, oDialogPrm, true);
        
        try
            {
            // the following is a blocking call!
            dlg.setVisible(true);
        
            // the dialog box is hidden now!!
            }
        finally
            {
            // re-enable the owner frame (disabled by createDialog())
            setEnabled(true);
            }
        
        // JDialog.endDialog() should have already called "dlg.dispose();"
        return dlg.getHostedPanel().getDialogResult();
        }
    
    // Declared at the super level
    /**
    * This method is called by  Component.Control.Container#addControl() as a
    * last chance to intervene during the construction/integration cycle.
    * A Control would override this if more than one AWT components should be
    * created for one Control or if the component should not be added to the
    * container (see Component...Window or Component...TabbedPanel).
    * This method can also be used to make sure that the parent is of the
    * allowed type (i.e. TabbedPanel is only allowed to be added into the
    * JTabbedPane).
    *  
    * @param  fAdd is true <b>only</b> when this is the frist call (from
    * addControl()) and an override is supposed to tie all the pieces together;
    * false in all other situations
    * 
    * @return AWT component that is added to a container [integratee].
    * 
    * @see Component.Control.Container.Window
    * @see Component.GUI.Control.Container.JComponent
    * @see
    * Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem.JMenu
    * @see Component.GUI.Control.Container.JComponent.JPanel.ButtonGroupPanel
    */
    public java.awt.Component getAWTContainee(boolean fAdd)
        {
        // Window is an exception -- it is not "contained" but "owned"
        return null;
        }
    
    // Accessor for the property "Owner"
    public Window getOwner()
        {
        return __m_Owner;
        }
    
    // Declared at the super level
    /**
    * Hosts (adds as a child) the specified JPanel and make the client area of
    * this container equal to the size of the hosted panel.
    * 
    * @see #getHostedPanel
    */
    public void hostPanel(_package.component.gUI.control.container.jComponent.JPanel panel)
        {
        // we have to force the creation of the window peer
        // which sets the valid Insets.
        
        setSize(panel.getSize()); // without this we would get Insets off by 2
        addNotify(); 
        
        super.hostPanel(panel);
        }
    
    // Accessor for the property "VisibleDeferred"
    private boolean isVisibleDeferred()
        {
        return __m_VisibleDeferred;
        }
    
    /**
    * Moves this window to the center of the screen
    */
    public void moveToCenter()
        {
        // import Component.Application.GUI;
        // import Component.GUI.Dimension;
        // import Component.GUI.Point;
        
        Dimension dimWindow = getSize();
        Dimension dimScreen = ((GUI) GUI.get_Instance()).getScreenSize();
        Point     ptLoc     = Point.instantiate(
            (dimScreen.getWidth()  - dimWindow.getWidth())  / 2,
            (dimScreen.getHeight() - dimWindow.getHeight()) / 2);
        setLocation(ptLoc);

        }
    
    // Declared at the super level
    /**
    * Brings up a message box specified by the panel name.
    * 
    * @see JFrame#msg
    * @see JDesktopPane#msg
    */
    public Object msg(String sMsgId, Object oMsgPrm)
        {
        // import Component.GUI.Control.Container.Window.Frame.JFrame;
        
        if (this instanceof JDialog || this instanceof JFrame)
            {
            //++ temorary hack until we know what to do
        
            if (sMsgId.startsWith("Confirm"))
                {
                Object[] aoMsgPrm  = (Object[]) oMsgPrm;
                String   sMsgText  = (String)   aoMsgPrm[0];
                String   sMsgTitle = (String)   aoMsgPrm[1];
                int      sMsgType  = aoMsgPrm.length == 2 ? javax.swing.JOptionPane.YES_NO_CANCEL_OPTION :
                                     ((Integer) aoMsgPrm[2]).intValue();
        
                return new Integer(javax.swing.JOptionPane.showConfirmDialog(
                    (_Window) get_Feed(), sMsgText, sMsgTitle, sMsgType));
                }
            else if (sMsgId.startsWith("Input"))
                {
                Object[] aoMsgPrm  = (Object[]) oMsgPrm;
                String   sMsgText  = (String)   aoMsgPrm[0];
                String   sMsgTitle = (String)   aoMsgPrm[1];
                int      sMsgType  = ((Integer) aoMsgPrm[2]).intValue();
                String   sMsgInit  = (String)   aoMsgPrm[3];
        
                return javax.swing.JOptionPane.showInputDialog(
                    (_Window) get_Feed(), sMsgText, sMsgTitle, sMsgType, null, null, sMsgInit);
                }
            else if (sMsgId.startsWith("Message"))
                {
                Object[] aoMsgPrm  = (Object[]) oMsgPrm;
                String   sMsgText  = (String)   aoMsgPrm[0];
                String   sMsgTitle = (String)   aoMsgPrm[1];
                int      sMsgType  = aoMsgPrm.length == 2 ? javax.swing.JOptionPane.INFORMATION_MESSAGE :
                                     ((Integer) aoMsgPrm[2]).intValue();
        
                javax.swing.JOptionPane.showMessageDialog(
                    (_Window) get_Feed(), sMsgText, sMsgTitle, sMsgType);
                return null;
                }
            //--
            
            final String MSG_PANEL = "Component.GUI.Control.Container.JComponent.JPanel.MsgPanel.";
            if (!sMsgId.startsWith(MSG_PANEL))
                {
                sMsgId = MSG_PANEL + sMsgId;
                }
            return dialogBox((JPanel) _newInstance(sMsgId), oMsgPrm);
            }
        else
            {
            return super.msg(sMsgId, oMsgPrm);
            }
        }
    
    /**
    * A simple helper around msg.
    */
    public Object msg(String sMsgId, String sMsgText, String sMsgTitle)
        {
        return msg(sMsgId, new Object[] {sMsgText, sMsgTitle});
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import java.awt.event.WindowEvent;
        // import java.awt.Toolkit;
        
        // First we have to propagate the onInit call, and the caveat is
        // that though the window may have been designed visible
        // it has not been made visible yet ...
        // We could call super.onInit() after the window made visible, but then
        // its possible that components will be called into doLayout() BEFORE the call to onInit
        // which is not ideologically correct
        super.onInit();
        
        // java.awt.Window is constructed initially invisible
        // and during construction of this component all calls to setVisible()
        // were redirected to DeferredVisible property
        // Now we apply the deferred value to the actual thing
        
        boolean fVisible = isVisibleDeferred();
        setVisibleDeferred(false);
        setVisible(fVisible);
        
        // If the window is visible, this event is posted out of setVisible
        // (see java.awt.Window#show); otherwise we force it now
        
        if (!fVisible)
            {
            Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(
                new WindowEvent((_Window) get_Feed(), WindowEvent.WINDOW_OPENED));
            }
        }
    
    public void onWindowActivated()
        {
        }
    
    public void onWindowClosed()
        {
        }
    
    public void onWindowClosing()
        {
        setVisible(false);
        dispose();
        }
    
    public void onWindowDeactivated()
        {
        }
    
    public void onWindowDeiconified()
        {
        }
    
    public void onWindowIconified()
        {
        }
    
    public void onWindowOpened()
        {
        }
    
    // Accessor for the property "Owner"
    public void setOwner(Window pOwner)
        {
        __m_Owner = pOwner;
        }
    
    // Accessor for the property "VisibleDeferred"
    private void setVisibleDeferred(boolean pVisibleDeferred)
        {
        __m_VisibleDeferred = pVisibleDeferred;
        }
    }
