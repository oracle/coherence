/* Class
*     _package.component.gUI.text.defaultEditorKit.AlternatingColor$View
*/

package _package.component.gUI.text.defaultEditorKit;

import _package.component.gUI.Color;
import _package.component.gUI.control.container.jComponent.jTextComponent.JEditorPane;
import java.awt.Color; // as _Color

public class AlternatingColor$View
        extends    _package.component.gUI.text.view.boxView.WrappedPlainView
    {
    // Fields declarations
    
    /**
    * Property TextColor
    *
    * Array of colors to be used for this kit.
    */
    private _package.component.gUI.Color[] __m_TextColor;
    
    // Default constructor
    public AlternatingColor$View()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public AlternatingColor$View(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            _package.component.gUI.Color[] a0 = new _package.component.gUI.Color[2];
                {
                a0[0] = new _package.component.gUI.color.Black();
                a0[1] = new _package.component.gUI.color.Red();
                }
            setTextColor(a0);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new AlternatingColor$View();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/text/defaultEditorKit/AlternatingColor$View".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    /**
    * Renders the given range in the model as normal unselected text.
    */
    protected int drawUnselectedText(java.awt.Graphics g, int x, int y, int p0, int p1)
            throws javax.swing.text.BadLocationException
        {
        // import Component.GUI.Control.Container.JComponent.JTextComponent.JEditorPane;
        // import Component.GUI.Color;
        // import java.awt.Color as _Color;
        
        import javax.swing.text.Document;
        import javax.swing.text.Element;
        import javax.swing.text.Segment;
        import javax.swing.text.Utilities;
        
        Document doc        = getDocument();
        Element  root       = doc.getDefaultRootElement();
        int      nLineStart = root.getElementIndex(p0);
        int      nLineEnd   = root.getElementIndex(p1 - 1); // p1 is exclusive offset
        Segment  buffer     = get_LineBuffer();
        
        for (int nLine = nLineStart; nLine <= nLineEnd; nLine++)
            {		    
            // get the offsets for the line
            Element elLine  = root.getElement(nLine);
            int     ofStart = elLine.getStartOffset();
            int     ofEnd   = elLine.getEndOffset();
        
            ofStart = Math.max(ofStart, p0);
            ofEnd   = Math.min(p1, ofEnd);
            
            if (ofStart < ofEnd)
                {
                Color[] aColor  = getTextColor();
                int     cColors = aColor == null ? 0 : aColor.length;
                Color  color    = cColors == 0 ? new Color.Black() : aColor[nLine % cColors];
        
                g.setColor(color.get_Color());
        
                doc.getText(ofStart, ofEnd - ofStart, buffer);
                x = Utilities.drawTabbedText(buffer, x, y, g, this, ofStart);
                }
            }
        
        return x;
        }
    
    // Accessor for the property "TextColor"
    /**
    * Getter for property TextColor.<p>
    * Array of colors to be used for this kit.
    */
    public _package.component.gUI.Color[] getTextColor()
        {
        return __m_TextColor;
        }
    
    // Accessor for the property "TextColor"
    /**
    * Getter for property TextColor.<p>
    * Array of colors to be used for this kit.
    */
    public _package.component.gUI.Color getTextColor(int pIndex)
        {
        return getTextColor()[pIndex];
        }
    
    // Accessor for the property "TextColor"
    /**
    * Setter for property TextColor.<p>
    * Array of colors to be used for this kit.
    */
    public void setTextColor(_package.component.gUI.Color[] pTextColor)
        {
        __m_TextColor = pTextColor;
        }
    
    // Accessor for the property "TextColor"
    /**
    * Setter for property TextColor.<p>
    * Array of colors to be used for this kit.
    */
    public void setTextColor(int pIndex, _package.component.gUI.Color pTextColor)
        {
        getTextColor()[pIndex] = pTextColor;
        }
    }
