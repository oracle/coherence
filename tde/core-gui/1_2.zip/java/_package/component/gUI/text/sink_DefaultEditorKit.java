/* Class
*      sink_DefaultEditorKit
*
* automatically generated "Sink" which
* represents a footprint of the class
*      javax.swing.text.DefaultEditorKit
* when used as a component callback by 
*      Component.GUI.Text.DefaultEditorKit
*/

package _package.component.gUI.text;

public class sink_DefaultEditorKit
       extends com.tangosol.run.component.CallbackSink
    {
    private jb_DefaultEditorKit __peer;
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_DefaultEditorKit()
        {
        }
    
    // this (protected) constructor is used by the feed
    protected sink_DefaultEditorKit(jb_DefaultEditorKit feed)
        {
        super();
        __peer = feed;
        }
    
    // Retrieves the feed object for this sink
    public Object get_Feed()
        {
        return __peer;
        }
    
    // methods integrated and/or remoted
    public String getContentType()
        {
        return __peer.super$getContentType();
        }
    public javax.swing.text.ViewFactory getViewFactory()
        {
        return __peer.super$getViewFactory();
        }
    }
