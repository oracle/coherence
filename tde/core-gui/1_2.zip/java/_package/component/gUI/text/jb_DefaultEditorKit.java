/* Class
*      jb_DefaultEditorKit
*
* automatically generated "Feed" which
* a) extends an external bean:
*      javax.swing.text.DefaultEditorKit
* b) delegates to the peer component:
*      Component.GUI.Text.DefaultEditorKit
*/

package _package.component.gUI.text;

public class jb_DefaultEditorKit
        extends    javax.swing.text.DefaultEditorKit
        implements com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected DefaultEditorKit __peer;
    
    private static DefaultEditorKit __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            DefaultEditorKit peer = (DefaultEditorKit)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // default (JavaBean) constructor
    public jb_DefaultEditorKit()
        {
        this(DefaultEditorKit.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_DefaultEditorKit(Class clzPeer)
        {
        this(__createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_DefaultEditorKit(DefaultEditorKit peer, boolean fInit)
        {
        super();
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private DefaultEditorKit __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (DefaultEditorKit) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_DefaultEditorKit(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    public String getContentType()
        {
        DefaultEditorKit peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getContentType();
        }
    String super$getContentType()
        {
        return super.getContentType();
        }
    public javax.swing.text.ViewFactory getViewFactory()
        {
        DefaultEditorKit peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getViewFactory();
        }
    javax.swing.text.ViewFactory super$getViewFactory()
        {
        return super.getViewFactory();
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
