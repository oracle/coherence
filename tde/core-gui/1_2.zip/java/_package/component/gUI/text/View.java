/* Class
*     _package.component.gUI.text.View
*/

package _package.component.gUI.text;

import _package.component.gUI.control.container.jComponent.jTextComponent.JEditorPane;
import _package.component.gUI.text.DefaultEditorKit;

/**
* View components integrate javax.swing.text.View or any of its subclasses. The
* only currently supported design pattern is a [subcomponent of] View component
* being a static child of a [subcomponent of] DefaultEditorKit component being
* in turn a child of JEditorPane.
*/
/*
* Integrates
*     javax.swing.text.View
*     using Component.Dev.Compiler.Integrator.AbstractBean
*/
public abstract class View
        extends    _package.component.gUI.Text
    {
    // Fields declarations
    
    /**
    * Property Document
    *
    * Helper property returning a javax.swing.text.Document object, which is a
    * model associated with the JEditorPane this component is a grand child of.
    */
    
    // fields used by the integration model:
    private sink_View __sink;
    private javax.swing.text.View __feed;
    
    // Initializing constructor
    public View(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/text/View".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.text.View integration
    // Access optimization
    /**
    * Setter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Sink(Object pSink)
        {
        __sink = (sink_View) pSink;
        super.set_Sink(pSink);
        }
    /**
    * Setter for property _Feed.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.text.View) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    /**
    * Renders using the given rendering surface and area on that surface. The
    * view may need to do layout and create child views to enable itself to
    * render into the given allocation.
    */
    public void paint(java.awt.Graphics g, java.awt.Shape a)
        {
        __sink.paint(g, a);
        }
    //-- javax.swing.text.View integration
    
    /**
    * Class javax.swing.text.BoxView doesn't have a default constructor. This
    * method serves as one.
    */
    public void _initFeed(javax.swing.text.Element el)
        {
        super._initFeed(el);
        }
    
    // Accessor for the property "Document"
    /**
    * Getter for property Document.<p>
    * Helper property returning a javax.swing.text.Document object, which is a
    * model associated with the JEditorPane this component is a grand child of.
    */
    public javax.swing.text.Document getDocument()
        {
        // import Component.GUI.Text.DefaultEditorKit;
        // import Component.GUI.Control.Container.JComponent.JTextComponent.JEditorPane;
        
        try
            {
            Component kit    = get_Parent();     // DefaultEditorKit
            Component editor = kit.get_Parent(); // JEditorPane
        
            return ((JEditorPane) editor).get_Document();
            }
        catch (RuntimeException e) // ClassCastException, NullPointer
            {
            throw new RuntimeException(get_Name() +
                " must be a grand child of JEditorPane");
            }

        }
    
    /**
    * This method serves a virtual default constructor. Subcomponents must
    * override ot callin the most appropriate _initFeed.
    */
    public void initialize(javax.swing.text.Element el)
        {
        _initFeed(el);
        }
    }
