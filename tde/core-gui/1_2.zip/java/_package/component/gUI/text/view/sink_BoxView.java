/* Class
*      sink_BoxView
*
* automatically generated "Sink" which
* represents a footprint of the class
*      javax.swing.text.BoxView
* when used as a component callback by 
*      Component.GUI.Text.View.BoxView
*/

package _package.component.gUI.text.view;

public class sink_BoxView
       extends _package.component.gUI.text.sink_View
    {
    private jb_BoxView __peer;
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_BoxView()
        {
        }
    
    // this (protected) constructor is used by the feed
    protected sink_BoxView(jb_BoxView feed)
        {
        super();
        __peer = feed;
        }
    
    // Retrieves the feed object for this sink
    public Object get_Feed()
        {
        return __peer;
        }
    
    // methods integrated and/or remoted
    protected void baselineLayout(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        __peer.super$baselineLayout(targetSpan, axis, offsets, spans);
        }
    public int getAxis()
        {
        return __peer.super$getAxis();
        }
    public int getHeight()
        {
        return __peer.super$getHeight();
        }
    protected int getOffset(int axis, int childIndex)
        {
        return __peer.super$getOffset(axis, childIndex);
        }
    protected int getSpan(int axis, int childIndex)
        {
        return __peer.super$getSpan(axis, childIndex);
        }
    public int getWidth()
        {
        return __peer.super$getWidth();
        }
    protected void layout(int width, int height)
        {
        __peer.super$layout(width, height);
        }
    public void layoutChanged(int axis)
        {
        __peer.super$layoutChanged(axis);
        }
    protected void layoutMajorAxis(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        __peer.super$layoutMajorAxis(targetSpan, axis, offsets, spans);
        }
    protected void layoutMinorAxis(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        __peer.super$layoutMinorAxis(targetSpan, axis, offsets, spans);
        }
    public void paint(java.awt.Graphics g, java.awt.Shape a)
        {
        __peer.super$paint(g, a);
        }
    protected void paintChild(java.awt.Graphics g, java.awt.Rectangle alloc, int index)
        {
        __peer.super$paintChild(g, alloc, index);
        }
    public void setAxis(int pAxis)
        {
        __peer.super$setAxis(pAxis);
        }
    }
