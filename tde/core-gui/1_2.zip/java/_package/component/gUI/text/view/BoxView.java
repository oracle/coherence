/* Class
*     _package.component.gUI.text.view.BoxView
*/

package _package.component.gUI.text.view;

import javax.swing.text.View; // as _View

/*
* Integrates
*     javax.swing.text.BoxView
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class BoxView
        extends    _package.component.gUI.text.View
    {
    // Fields declarations
    
    /**
    * Property Axis
    *
    */
    private transient int __m_Axis;
    
    /**
    * Property Height
    *
    */
    
    /**
    * Property Width
    *
    */
    
    // fields used by the integration model:
    private sink_BoxView __sink;
    private javax.swing.text.BoxView __feed;
    
    // Default constructor
    public BoxView()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public BoxView(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            _init();
            }
        }
    
    // Main initializer's proxy
    private void _init$Default()
        {
        }
    /**
    * This method is a very special one. If implemented (even with a trivial
    * implementation "super._init()"), the class generation will make sure this
    * script is called right after the component allocation has been made but
    * prior to any state initialization (except the constant properties that
    * are "inlined"). This gives the component a chance to stop or defer
    * initalization by not calling the super.
    * Very important note: this method is very similar to a Java constructor:
    * during construction it's only called at the level where it's declared.
    * However, this method could be called directly to reset the state of the
    * component (given the component itself or any of its super components do
    * have an implementation).
    * 
    * There is an analogous initialization methods that you can declare for any
    * integrating component:
    * 
    *     void _initFeed(<parameters>)
    * 
    * where <parameters> could be empty.
    * 
    * If such a method is declared, the class generation doesn't initialize the
    * component's state during _init()'s call to it's super.  Instead, state
    * initialization is performed when the _initFeed(<parameters>) script
    * call's it's super.
    * 
    * Currently, there are two ways this is being used.  The first is when the
    * integrated class doesn't have a default constructor, but could be
    * constructed with a constant (virtual or java).  This is done by
    * implementing _init() to call the appropriate _initFeed.  For example,
    * _init() would loook like:
    * 
    *     _initFeed(getVirtualConstantValue(), OTHER_CONSTANT);
    * 
    * The other use is to allow the script allocating the component to create
    * to corresponding feed directly with an explicit call.   For example:
    * 
    *     MyComponent myc = new MyComponent();
    *     myc._initFeed(aValue);
    * 
    * See generated java listings for implementation details.
    */
    protected void _init()
        {
        _init$Default();
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new BoxView();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/text/view/BoxView".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.text.BoxView integration
    // Access optimization
    /**
    * Setter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Sink(Object pSink)
        {
        __sink = (sink_BoxView) pSink;
        super.set_Sink(pSink);
        }
    /**
    * Setter for property _Feed.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.text.BoxView) pFeed;
        super.set_Feed(pFeed);
        }
    private void _initFeed$AutoGen(javax.swing.text.Element el, int axis)
        {
        jb_BoxView.__tloPeer.setObject(this);
        new jb_BoxView(el, axis, this, false); // this sets the Sink which sets the Feed
        __init();
        }
    /**
    * Class javax.swing.text.BoxView doesn't have a default constructor. This
    * method serves as one.
    * 
    * @param el  the element this view is responsible for
    * @param axis the alignment axis for the children elements. The only valid
    * values are: View.X_AXIS or View.Y_AXIS.
    */
    public void _initFeed(javax.swing.text.Element el, int axis)
        {
        _initFeed$AutoGen(el, axis);

        }
    // properties integration
    // methods integration
    protected void baselineLayout(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        __sink.baselineLayout(targetSpan, axis, offsets, spans);
        }
    /**
    * Getter for property Axis.<p>
    */
    public int getAxis()
        {
        return __sink.getAxis();
        }
    /**
    * Getter for property Height.<p>
    */
    public int getHeight()
        {
        return __sink.getHeight();
        }
    protected int getOffset(int axis, int childIndex)
        {
        return __sink.getOffset(axis, childIndex);
        }
    protected int getSpan(int axis, int childIndex)
        {
        return __sink.getSpan(axis, childIndex);
        }
    /**
    * Getter for property Width.<p>
    */
    public int getWidth()
        {
        return __sink.getWidth();
        }
    protected void layout(int width, int height)
        {
        __sink.layout(width, height);
        }
    public void layoutChanged(int axis)
        {
        __sink.layoutChanged(axis);
        }
    protected void layoutMajorAxis(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        __sink.layoutMajorAxis(targetSpan, axis, offsets, spans);
        }
    protected void layoutMinorAxis(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        __sink.layoutMinorAxis(targetSpan, axis, offsets, spans);
        }
    protected void paintChild(java.awt.Graphics g, java.awt.Rectangle alloc, int index)
        {
        __sink.paintChild(g, alloc, index);
        }
    /**
    * Setter for property Axis.<p>
    */
    public void setAxis(int pAxis)
        {
        __sink.setAxis(pAxis);
        }
    //-- javax.swing.text.BoxView integration
    
    // Declared at the super level
    /**
    * This method serves a virtual default constructor. Subcomponents must
    * override ot callin the most appropriate _initFeed.
    */
    public void initialize(javax.swing.text.Element el)
        {
        // import javax.swing.text.View as _View;
        
        _initFeed(el, _View.Y_AXIS);
        }
    }
