/* Class
*      sink_WrappedPlainView
*
* automatically generated "Sink" which
* represents a footprint of the class
*      javax.swing.text.WrappedPlainView
* when used as a component callback by 
*      Component.GUI.Text.View.BoxView.WrappedPlainView
*/

package _package.component.gUI.text.view.boxView;

public class sink_WrappedPlainView
       extends _package.component.gUI.text.view.sink_BoxView
    {
    private jb_WrappedPlainView __peer;
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_WrappedPlainView()
        {
        }
    
    // this (protected) constructor is used by the feed
    protected sink_WrappedPlainView(jb_WrappedPlainView feed)
        {
        super();
        __peer = feed;
        }
    
    // Retrieves the feed object for this sink
    public Object get_Feed()
        {
        return __peer;
        }
    
    // methods integrated and/or remoted
    protected void baselineLayout(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        __peer.super$baselineLayout(targetSpan, axis, offsets, spans);
        }
    protected void drawLine(int p0, int p1, java.awt.Graphics g, int x, int y)
        {
        __peer.super$drawLine(p0, p1, g, x, y);
        }
    protected int drawSelectedText(java.awt.Graphics g, int x, int y, int p0, int p1)
            throws javax.swing.text.BadLocationException
        {
        return __peer.super$drawSelectedText(g, x, y, p0, p1);
        }
    protected int drawUnselectedText(java.awt.Graphics g, int x, int y, int p0, int p1)
            throws javax.swing.text.BadLocationException
        {
        return __peer.super$drawUnselectedText(g, x, y, p0, p1);
        }
    public javax.swing.text.Segment getLineBuffer()
        {
        return __peer.super$getLineBuffer();
        }
    public int getAxis()
        {
        return __peer.super$getAxis();
        }
    public javax.swing.text.Element getElement()
        {
        return __peer.super$getElement();
        }
    public int getHeight()
        {
        return __peer.super$getHeight();
        }
    protected int getOffset(int axis, int childIndex)
        {
        return __peer.super$getOffset(axis, childIndex);
        }
    protected int getSpan(int axis, int childIndex)
        {
        return __peer.super$getSpan(axis, childIndex);
        }
    public int getWidth()
        {
        return __peer.super$getWidth();
        }
    protected void layout(int width, int height)
        {
        __peer.super$layout(width, height);
        }
    public void layoutChanged(int axis)
        {
        __peer.super$layoutChanged(axis);
        }
    protected void layoutMajorAxis(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        __peer.super$layoutMajorAxis(targetSpan, axis, offsets, spans);
        }
    protected void layoutMinorAxis(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        __peer.super$layoutMinorAxis(targetSpan, axis, offsets, spans);
        }
    public float nextTabStop(float x, int of)
        {
        return __peer.super$nextTabStop(x, of);
        }
    public void paint(java.awt.Graphics g, java.awt.Shape a)
        {
        __peer.super$paint(g, a);
        }
    protected void paintChild(java.awt.Graphics g, java.awt.Rectangle alloc, int index)
        {
        __peer.super$paintChild(g, alloc, index);
        }
    public void setAxis(int pAxis)
        {
        __peer.super$setAxis(pAxis);
        }
    }
