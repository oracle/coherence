/* Class
*      jb_BoxView
*
* automatically generated "Feed" which
* a) extends an external bean:
*      javax.swing.text.BoxView
* b) delegates to the peer component:
*      Component.GUI.Text.View.BoxView
*/

package _package.component.gUI.text.view;

public class jb_BoxView
        extends    javax.swing.text.BoxView
        implements com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected BoxView __peer;
    
    private static BoxView __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            BoxView peer = (BoxView)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // parameterized constructor
    public jb_BoxView(javax.swing.text.Element Param_1, int Param_2)
        {
        this(Param_1, Param_2, BoxView.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_BoxView(javax.swing.text.Element Param_1, int Param_2, Class clzPeer)
        {
        this(Param_1, Param_2, __createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_BoxView(javax.swing.text.Element Param_1, int Param_2, BoxView peer, boolean fInit)
        {
        super(Param_1, Param_2);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private BoxView __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (BoxView) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_BoxView(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    protected void baselineLayout(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        BoxView peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.baselineLayout(targetSpan, axis, offsets, spans);
        }
    void super$baselineLayout(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        super.baselineLayout(targetSpan, axis, offsets, spans);
        }
    public int getAxis()
        {
        BoxView peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getAxis();
        }
    int super$getAxis()
        {
        return super.getAxis();
        }
    public int getHeight()
        {
        BoxView peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getHeight();
        }
    int super$getHeight()
        {
        return super.getHeight();
        }
    protected int getOffset(int axis, int childIndex)
        {
        BoxView peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getOffset(axis, childIndex);
        }
    int super$getOffset(int axis, int childIndex)
        {
        return super.getOffset(axis, childIndex);
        }
    protected int getSpan(int axis, int childIndex)
        {
        BoxView peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSpan(axis, childIndex);
        }
    int super$getSpan(int axis, int childIndex)
        {
        return super.getSpan(axis, childIndex);
        }
    public int getWidth()
        {
        BoxView peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getWidth();
        }
    int super$getWidth()
        {
        return super.getWidth();
        }
    protected void layout(int width, int height)
        {
        BoxView peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.layout(width, height);
        }
    void super$layout(int width, int height)
        {
        super.layout(width, height);
        }
    public void layoutChanged(int axis)
        {
        BoxView peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.layoutChanged(axis);
        }
    void super$layoutChanged(int axis)
        {
        super.layoutChanged(axis);
        }
    protected void layoutMajorAxis(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        BoxView peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.layoutMajorAxis(targetSpan, axis, offsets, spans);
        }
    void super$layoutMajorAxis(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        super.layoutMajorAxis(targetSpan, axis, offsets, spans);
        }
    protected void layoutMinorAxis(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        BoxView peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.layoutMinorAxis(targetSpan, axis, offsets, spans);
        }
    void super$layoutMinorAxis(int targetSpan, int axis, int[] offsets, int[] spans)
        {
        super.layoutMinorAxis(targetSpan, axis, offsets, spans);
        }
    public void paint(java.awt.Graphics g, java.awt.Shape a)
        {
        BoxView peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paint(g, a);
        }
    void super$paint(java.awt.Graphics g, java.awt.Shape a)
        {
        super.paint(g, a);
        }
    protected void paintChild(java.awt.Graphics g, java.awt.Rectangle alloc, int index)
        {
        BoxView peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.paintChild(g, alloc, index);
        }
    void super$paintChild(java.awt.Graphics g, java.awt.Rectangle alloc, int index)
        {
        super.paintChild(g, alloc, index);
        }
    public void setAxis(int pAxis)
        {
        BoxView peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.setAxis(pAxis);
        }
    void super$setAxis(int pAxis)
        {
        super.setAxis(pAxis);
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
