/* Class
*     _package.component.gUI.text.view.boxView.WrappedPlainView
*/

package _package.component.gUI.text.view.boxView;

/*
* Integrates
*     javax.swing.text.WrappedPlainView
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class WrappedPlainView
        extends    _package.component.gUI.text.view.BoxView
        implements javax.swing.text.TabExpander
    {
    // Fields declarations
    
    /**
    * Property _LineBuffer
    *
    * Provides access to a buffer that can be used to fetch text from the
    * associated document.
    * 
    * Note: getter for this property is marked as final on the feed
    * (javax.swing.text.WrappedPlainView)
    */
    
    /**
    * Property Element
    *
    */
    
    // fields used by the integration model:
    private sink_WrappedPlainView __sink;
    private javax.swing.text.WrappedPlainView __feed;
    
    // Default constructor
    public WrappedPlainView()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public WrappedPlainView(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            _init();
            }
        }
    
    // Main initializer's proxy
    private void _init$Default()
        {
        }
    /**
    * This method is a very special one. If implemented (even with a trivial
    * implementation "super._init()"), the class generation will make sure this
    * script is called right after the component allocation has been made but
    * prior to any state initialization (except the constant properties that
    * are "inlined"). This gives the component a chance to stop or defer
    * initalization by not calling the super.
    * Very important note: this method is very similar to a Java constructor:
    * during construction it's only called at the level where it's declared.
    * However, this method could be called directly to reset the state of the
    * component (given the component itself or any of its super components do
    * have an implementation).
    * 
    * There is an analogous initialization methods that you can declare for any
    * integrating component:
    * 
    *     void _initFeed(<parameters>)
    * 
    * where <parameters> could be empty.
    * 
    * If such a method is declared, the class generation doesn't initialize the
    * component's state during _init()'s call to it's super.  Instead, state
    * initialization is performed when the _initFeed(<parameters>) script
    * call's it's super.
    * 
    * Currently, there are two ways this is being used.  The first is when the
    * integrated class doesn't have a default constructor, but could be
    * constructed with a constant (virtual or java).  This is done by
    * implementing _init() to call the appropriate _initFeed.  For example,
    * _init() would loook like:
    * 
    *     _initFeed(getVirtualConstantValue(), OTHER_CONSTANT);
    * 
    * The other use is to allow the script allocating the component to create
    * to corresponding feed directly with an explicit call.   For example:
    * 
    *     MyComponent myc = new MyComponent();
    *     myc._initFeed(aValue);
    * 
    * See generated java listings for implementation details.
    */
    protected void _init()
        {
        _init$Default();
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new WrappedPlainView();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/text/view/boxView/WrappedPlainView".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.text.WrappedPlainView integration
    // Access optimization
    /**
    * Setter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Sink(Object pSink)
        {
        __sink = (sink_WrappedPlainView) pSink;
        super.set_Sink(pSink);
        }
    /**
    * Setter for property _Feed.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.text.WrappedPlainView) pFeed;
        super.set_Feed(pFeed);
        }
    private void _initFeed$AutoGen(javax.swing.text.Element el)
        {
        jb_WrappedPlainView.__tloPeer.setObject(this);
        new jb_WrappedPlainView(el, this, false); // this sets the Sink which sets the Feed
        __init();
        }
    /**
    * Class javax.swing.text.BoxView doesn't have a default constructor. This
    * method serves as one.
    * Creates a new WrappedPlainView feed. Lines will be wrapped on character
    * boundaries.
    */
    public void _initFeed(javax.swing.text.Element el)
        {
        _initFeed$AutoGen(el);
        }
    private void _initFeed$AutoGen(javax.swing.text.Element el, boolean fWordWrap)
        {
        jb_WrappedPlainView.__tloPeer.setObject(this);
        new jb_WrappedPlainView(el, fWordWrap, this, false); // this sets the Sink which sets the Feed
        __init();
        }
    /**
    * Class javax.swing.text.WrappedPlainView doesn't have teh default
    * constructor. This method serves a the constructor that
    * creates a new WrappedPlainView feed. Lines can be wrapped on either
    * character or word boundaries depending upon the setting of the fWordWrap
    * parameter.
    * 
    * @param el the element this view is responsible for
    * @param fWordWrap should lines be wrapped on word boundaries
    */
    public void _initFeed(javax.swing.text.Element el, boolean fWordWrap)
        {
        _initFeed$AutoGen(el, fWordWrap);
        }
    // properties integration
    // methods integration
    /**
    * Renders a line of text, suppressing whitespace at the end and expanding
    * any tabs. This is implemented to make calls to the methods
    * drawUnselectedText and drawSelectedText so that the way selected and
    * unselected text are rendered can be customized.
    */
    protected void drawLine(int p0, int p1, java.awt.Graphics g, int x, int y)
        {
        __sink.drawLine(p0, p1, g, x, y);
        }
    /**
    * Renders the given range in the model as selected text. This is
    * implemented to render the text in the color specified in the hosting
    * component. It assumes the highlighter will render the selected
    * background.
    */
    protected int drawSelectedText(java.awt.Graphics g, int x, int y, int p0, int p1)
            throws javax.swing.text.BadLocationException
        {
        return __sink.drawSelectedText(g, x, y, p0, p1);
        }
    /**
    * Renders the given range in the model as normal unselected text.
    */
    protected int drawUnselectedText(java.awt.Graphics g, int x, int y, int p0, int p1)
            throws javax.swing.text.BadLocationException
        {
        return __sink.drawUnselectedText(g, x, y, p0, p1);
        }
    /**
    * Getter for property Element.<p>
    */
    public javax.swing.text.Element getElement()
        {
        return __sink.getElement();
        }
    /**
    * Getter for property _LineBuffer.<p>
    * Provides access to a buffer that can be used to fetch text from the
    * associated document.
    * 
    * Note: getter for this property is marked as final on the feed
    * (javax.swing.text.WrappedPlainView)
    */
    public javax.swing.text.Segment get_LineBuffer()
        {
        return __sink.getLineBuffer();
        }
    public float nextTabStop(float x, int of)
        {
        return __sink.nextTabStop(x, of);
        }
    //-- javax.swing.text.WrappedPlainView integration
    
    // Declared at the super level
    /**
    * This method serves a virtual default constructor. Subcomponents must
    * override ot callin the most appropriate _initFeed.
    */
    public void initialize(javax.swing.text.Element el)
        {
        _initFeed(el, true);
        }
    }
