/* Class
*     _package.component.gUI.text.DefaultEditorKit
*/

package _package.component.gUI.text;

import _package.component.gUI.control.container.jComponent.jTextComponent.JEditorPane;
import _package.component.gUI.text.View;
import javax.swing.JEditorPane; // as _JEditorPane
import javax.swing.text.DefaultEditorKit; // as _DefaultEditorKit
import javax.swing.text.View; // as _View

/**
* DefaultEditorKit component integrates javax.swing.text.DefaultEditorKit and
* serves as a ViewFactory by implementing the javax.swing.text.ViewFactory
* interface. The view associated with this kit is expected to be a static child
*  component named "View" that could be overriden at any place where this kit
* gets used (usually a child of JEditorPane).
*/
/*
* Integrates
*     javax.swing.text.DefaultEditorKit
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class DefaultEditorKit
        extends    _package.component.gUI.Text
        implements javax.swing.text.ViewFactory
    {
    // Fields declarations
    
    /**
    * Property ContentType
    *
    * Calcultaed property returning the MIME type of the data that this kit
    * represents support for.  The default is <code>text/plain</code>.
    */
    
    /**
    * Property ViewFactory
    *
    * Factory that is suitable for producing views of any models that are
    * produced by this kit. Subcomponents should implement the accessor for
    * this integrated property
    */
    
    // fields used by the integration model:
    private sink_DefaultEditorKit __sink;
    private javax.swing.text.DefaultEditorKit __feed;
    
    // Default constructor
    public DefaultEditorKit()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public DefaultEditorKit(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_DefaultEditorKit.__tloPeer.setObject(this);
            new jb_DefaultEditorKit(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new DefaultEditorKit();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/text/DefaultEditorKit".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.text.DefaultEditorKit integration
    // Access optimization
    /**
    * Setter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Sink(Object pSink)
        {
        __sink = (sink_DefaultEditorKit) pSink;
        super.set_Sink(pSink);
        }
    /**
    * Setter for property _Feed.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.text.DefaultEditorKit) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    /**
    * Getter for property ContentType.<p>
    * Calcultaed property returning the MIME type of the data that this kit
    * represents support for.  The default is <code>text/plain</code>.
    */
    public String getContentType()
        {
        return __sink.getContentType();
        }
    private javax.swing.text.ViewFactory getViewFactory$Router()
        {
        return __sink.getViewFactory();
        }
    /**
    * Getter for property ViewFactory.<p>
    * Factory that is suitable for producing views of any models that are
    * produced by this kit. Subcomponents should implement the accessor for
    * this integrated property
    */
    public javax.swing.text.ViewFactory getViewFactory()
        {
        return this;
        }
    //-- javax.swing.text.DefaultEditorKit integration
    
    // From interface: javax.swing.text.ViewFactory
    /**
    * Creates a view from the given structural element of a document.
    * 
    * @param el  the piece of the document to build a view of
    * 
    * @return the view
    */
    public javax.swing.text.View create(javax.swing.text.Element el)
        {
        // import Component.GUI.Text.View;
        // import javax.swing.text.View as _View;
        
        View view = (View) _newChild("View");
        _assert(view != null, get_Name() + " must have a child named \"View\"");
        
        // see _init() documentation
        view.initialize(el);
        
        return (_View) view.get_Feed();

        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import Component.GUI.Control.Container.JComponent.JTextComponent.JEditorPane;
        // import javax.swing.JEditorPane as _JEditorPane;
        // import javax.swing.text.DefaultEditorKit as _DefaultEditorKit;
        
        super.onInit();
        
        Component parent = get_Parent();
        if (parent instanceof JEditorPane)
            {
            _JEditorPane _pane = (_JEditorPane) parent.get_Feed();
            _pane.setEditorKit((_DefaultEditorKit) get_Feed());
            }

        }
    }
