/* Class
*      sink_View
*
* automatically generated "Sink" which
* represents a footprint of the class
*      javax.swing.text.View
* when used as a component callback by 
*      Component.GUI.Text.View
*/

package _package.component.gUI.text;

public abstract class sink_View
       extends com.tangosol.run.component.CallbackSink
    {
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_View()
        {
        }
    
    // methods integrated and/or remoted
    public abstract void paint(java.awt.Graphics g, java.awt.Shape a);
    }
