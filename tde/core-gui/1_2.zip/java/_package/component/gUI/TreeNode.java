/* Class
*     _package.component.gUI.TreeNode
*/

package _package.component.gUI;

import _package.component.gUI.control.container.jComponent.JTree;
import _package.component.util.Config;
import com.tangosol.util.SimpleEnumerator;
import java.text.CollationKey;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Enumeration;
import javax.swing.JTree; // as _JTree
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

/*
* Integrates
*     javax.swing.tree.DefaultMutableTreeNode
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class TreeNode
        extends    _package.component.GUI
    {
    // Fields declarations
    
    /**
    * Property AllowsChildren
    *
    */
    private transient boolean __m_AllowsChildren;
    
    /**
    * Property CaseSensitive
    *
    * Specifies whether the sorting should be case sensitive (assuming there is
    * no Collator specified).
    * 
    * @see #locateNode
    * @see JTree#CaseSensitive
    * @see JTree#makeNode
    */
    private boolean __m_CaseSensitive;
    
    /**
    * Property ChildCount
    *
    */
    
    /**
    * Property Collapsed
    *
    * Specifies whether or not this node is collapses.
    * 
    * @see #Expanded
    */
    private transient boolean __m_Collapsed;
    
    /**
    * Property Collator
    *
    * Collator used to sort the leaf nodes in this node. If not specified  the
    * default string comparison (String.compareTo()) is used.
    * 
    * @see #locateNode
    * @see JTree#makeNode
    */
    private java.text.Collator __m_Collator;
    
    /**
    * Property Editable
    *
    * Specifies whether or not this node is editable. (The node is not editable
    * if the tree is not editable).
    * 
    * @see JTree#makeNode
    * @see #isEditable
    */
    private boolean __m_Editable;
    
    /**
    * Property Editing
    *
    * (Calculated) Specifies whether this node is currently editing.
    * 
    * @see JTree#startEditingAtPath
    * @see JTree#editingStopped
    * @see JTree#editingCanceled
    */
    
    /**
    * Property ENUM_BREADTH_FIRST
    *
    */
    public static final int ENUM_BREADTH_FIRST = 2;
    
    /**
    * Property ENUM_DEPTH_FIRST
    *
    */
    public static final int ENUM_DEPTH_FIRST = 1;
    
    /**
    * Property ENUM_IMMEDIATE
    *
    */
    public static final int ENUM_IMMEDIATE = 0;
    
    /**
    * Property Expanded
    *
    * Specifies whether or not this node is expanded
    * 
    * @see #Collapsed
    */
    private transient boolean __m_Expanded;
    
    /**
    * Property Id
    *
    */
    
    /**
    * Property Index
    *
    * @see #getIndex
    */
    
    /**
    * Property Leaf
    *
    */
    
    /**
    * Property MutableNode
    *
    */
    private transient javax.swing.tree.DefaultMutableTreeNode __m_MutableNode;
    
    /**
    * Property Parent
    *
    */
    private transient TreeNode __m_Parent;
    
    /**
    * Property Path
    *
    */
    
    /**
    * Property Selected
    *
    */
    
    /**
    * Property Sorted
    *
    * Specifies whether the node is sorted. If set to true and then all newly
    * added leaf nodes will be placed accordingly.
    * 
    * @see #add
    * @see JTree#Sorted
    */
    private boolean __m_Sorted;
    
    /**
    * Property Tree
    *
    */
    private transient _package.component.gUI.control.container.jComponent.JTree __m_Tree;
    
    /**
    * Property UserObject
    *
    * (Integrated) Specifies an arbitrary Object associated with the
    * DefaultMutableTreeNode object that this TreeNode integrates.
    */
    private transient Object __m_UserObject;
    
    /**
    * Property Visible
    *
    */
    private transient boolean __m_Visible;
    
    // Default constructor
    public TreeNode()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TreeNode(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAllowsChildren(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new TreeNode();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/TreeNode".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.tree.DefaultMutableTreeNode integration
    // Access optimization
    // properties integration
    // methods integration
    public boolean isAllowsChildren()
        {
        return getMutableNode().getAllowsChildren();
        }
    public int getChildCount()
        {
        return getMutableNode().getChildCount();
        }
    public Object getUserObject()
        {
        return getMutableNode().getUserObject();
        }
    public boolean isLeaf()
        {
        return getMutableNode().isLeaf();
        }
    private void removeAllChildren$Router()
        {
        getMutableNode().removeAllChildren();
        }
    public void removeAllChildren()
        {
        removeAllChildren$Router();
        
        // bug ? JTree doesn't work without reload, updateUI or rebuild
        reload();
        }
    public void setAllowsChildren(boolean pAllowsChildren)
        {
        getMutableNode().setAllowsChildren(pAllowsChildren);
        }
    public void setUserObject(Object pUserObject)
        {
        getMutableNode().setUserObject(pUserObject);
        }
    //-- javax.swing.tree.DefaultMutableTreeNode integration
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent.JTree;
        // import javax.swing.tree.DefaultMutableTreeNode;
        // import javax.swing.tree.TreePath;
        // import javax.swing.JTree as _JTree;

        }
    
    /**
    * Adds a child node to this node
    */
    public TreeNode add(TreeNode nodeChild)
        {
        int iPos = -1;
        if (isSorted())
            {
            iPos = locateNode(nodeChild);
            }
        return insert(nodeChild, iPos);
        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        // import java.util.Enumeration;
        
        if (!isLeaf())
            {
            if (config.getBoolean(sPrefix + getId()))
                {
                setExpanded(true);
                }
        
            for (Enumeration enum = children(); enum.hasMoreElements();)
                {
                TreeNode child = (TreeNode) enum.nextElement();
        
                child.applyConfig(config, sPrefix);
                }
            }
        
        super.applyConfig(config, sPrefix);
        }
    
    /**
    * Return an enumeration of all the children nodes for this node.
    */
    public java.util.Enumeration children()
        {
        // import com.tangosol.util.SimpleEnumerator;
        // import java.util.ArrayList;
        // import java.util.Enumeration;
        
        JTree     tree = getTree();
        ArrayList list = new ArrayList();
        
        for (Enumeration enum = getMutableNode().children(); enum.hasMoreElements();)
            {
            TreeNode node = tree.makeNode(enum.nextElement());
            list.add(node);
            }
        
        return new SimpleEnumerator(list.toArray());
        }
    
    // Declared at the super level
    /**
    * Compares this object with the specified object for order.  Returns a
    * negative integer, zero, or a positive integer as this object is less
    * than, equal to, or greater than the specified object.
    * 
    * @param o  the Object to be compared.
    * @return  a negative integer, zero, or a positive integer as this object
    * is less than, equal to, or greater than the specified object.
    * 
    * @throws ClassCastException if the specified object's type prevents it
    * from being compared to this Object.
    */
    public int compareTo(Object o)
        {
        // import java.text.Collator;
        // import java.text.CollationKey;
        
        if (!(o instanceof TreeNode))
            {
            return super.compareTo(o);
            }
        
        TreeNode nodeParent = getParent();
        if (nodeParent == null)
            {
            nodeParent = ((TreeNode) o).getParent();
            if (nodeParent == null)
                {
                return super.compareTo(o);
                }
            }
            
        String sKeyThis = this.toString();
        String sKeyThat = ((TreeNode) o).toString();
        
        if (sKeyThis == null)
            {
            return -1;
            }
        if (sKeyThat == null)
            {
            return 1;
            }
        
        Collator collator = nodeParent.getCollator();
        
        if (collator != null)
            {
            CollationKey ckNodeThis = collator.getCollationKey(sKeyThis);
            CollationKey ckNodeThat = collator.getCollationKey(sKeyThat);
            return ckNodeThis.compareTo(ckNodeThat);
            }
        else
            {
            if (!nodeParent.isCaseSensitive())
                {
                sKeyThis = sKeyThis.toUpperCase();
                sKeyThat = sKeyThat.toUpperCase();
                }
            return sKeyThis.compareTo(sKeyThat);
            }
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof TreeNode)
            {
            Object oThis = getUserObject();
            Object oThat = ((TreeNode) obj).getUserObject();
        
            return oThis == null ?
                oThat == null : oThis.equals(oThat);
             }
        else
            {
            return false;
            }
        }
    
    /**
    * Expand all the children nodes for this node.
    */
    public void expandAll()
        {
        // import java.util.Enumeration;
        
        if (!isLeaf())
            {
            setExpanded(true);
        
            for (Enumeration enum = children(); enum.hasMoreElements();)
                {
                TreeNode node = (TreeNode) enum.nextElement();
                node.expandAll();
                }
            }
        }
    
    /**
    * Find a child node that has a specified composite id.
    * 
    * @param path  path of simple node ids
    * @param index  index at the path to start from
    */
    private TreeNode findNode(String[] path, int index)
        {
        // import java.util.Enumeration;
        
        String   name = path[index];
        TreeNode node = null;
        
        for (Enumeration enum = children(); enum.hasMoreElements();)
            {
            TreeNode child = (TreeNode) enum.nextElement();
        
            if (child.toString().equals(name))
                {
                node = child;
                break;
                }
            }
        
        if (node != null && ++index < path.length)
            {
            node = node.findNode(path, index);
            }
        return node;
        }
    
    /**
    * Find a child node that "equals" to the specified object
    * 
    * @param obj  object to look for
    * @param nMethod  specifies the way in which the children are enumerated
    *                  ENUM_IMMEDIATE  (0) -- looks up only immediate children
    *                  ENUM_DEPTH_FIRST  (1) -- uses the depth first
    * enumeration
    *                  ENUM_BREADTH_FIRST  (2) -- uses the breadtf first
    * enumeration
    * 
    * @see equals()
    * @see SimpleNode#equals()
    */
    public TreeNode findNode(Object obj, int nEnumMethod)
        {
        // import java.util.Enumeration;
        
        JTree tree = getTree();
        
        Enumeration enum;
        
        switch (nEnumMethod)
            {
            case ENUM_IMMEDIATE:
                enum = getMutableNode().children();
                break;
            case ENUM_DEPTH_FIRST:
                enum = getMutableNode().depthFirstEnumeration();
                break;
            case ENUM_BREADTH_FIRST:
                enum = getMutableNode().breadthFirstEnumeration();
                break;
            default:
                throw new IllegalArgumentException(get_Name() + 
                    ".findNode: " + "Invalid enumeration method " + nEnumMethod);
            }
        
        while (enum.hasMoreElements())
            {
            TreeNode node = tree.makeNode(enum.nextElement());
            if (node.equals(obj))
                {
                return node;
                }
            }
        
        return null;
        }
    
    /**
    * Find a node by its composite id.
    * 
    * @param sNodeId -- node's composite id as produced by getId()
    *  
    * Note: This function is always called with "this" being the root. However,
    * it's written to allow a relative look up, where the nodeId should start
    * with this node Id as a first part of composite id.
    * 
    * @see getId()
    * @see JTree#findNodeId()
    */
    public TreeNode findNodeId(String sNodeId)
        {
        String sRootId = getId();
        
        if (sNodeId == null)
            {
            return sRootId == null ? this : null;
            }
        
        char   cSep    = getTree().getSeparator();
        char[] achPath = sNodeId.toCharArray();
        int    iLen    = achPath.length;
        int    iCnt    = 1;
        
        for (int i = 0; i < iLen; i++)
            {
            if (achPath[i] == cSep)
                {
                iCnt++;
                }
            }
        
        String[] asPath = new String[iCnt];
        
        if (iCnt == 1)
            {
            if (sRootId != null)
                {
                return sNodeId.equals(sRootId) ? this : null;
                }
        
            asPath[0] = sNodeId;
            }
        else
            {
            int iStart = 0;
            int iPath  = 0;
        
            for (int i = 0; i < iLen; i++)
                {
                if (achPath[i] == cSep)
                    {
                    asPath[iPath++] = new String(achPath, iStart, i - iStart);
                    iStart = i + 1;
                    }
                }
        
            // last field
            asPath[iPath] = new String(achPath, iStart, iLen - iStart);
            }
        
        return sRootId == null           ? findNode(asPath, 0) :
               sRootId.equals(asPath[0]) ? findNode(asPath, 1) :
                                           null;
        }
    
    /**
    * Returns the child node at the specified index in this node's child array.
    * @param index  an index into this node's child array
    * 
    * @exception ArrayIndexOutOfBoundsException if <code>index</code>  is out
    * of bounds
    * 
    * @return the TreeNode in this node's child array at the specified index
    */
    public TreeNode getChildAt(int index)
        {
        return getTree().makeNode(getMutableNode().getChildAt(index));
        }
    
    // Accessor for the property "Collator"
    public java.text.Collator getCollator()
        {
        return __m_Collator;
        }
    
    // Accessor for the property "Id"
    public String getId()
        {
        char         chSep = getTree().getSeparator();
        StringBuffer sb    = new StringBuffer();
        TreeNode     node  = this;
        
        do
            {
            String   sName      = node.toString();
            TreeNode nodeParent = node.getParent();
            
            if (sName == null)
                {
                if (nodeParent == null)
                    {
                    // root has no name -- skip it
                    break;
                    }
                sName = "";
                }
            sb.insert(0, chSep + sName);
            node = nodeParent;
            } while (node != null);
        
        // remove the leading separator
        return sb.length() > 0 ? sb.substring(1) : null;
        }
    
    // Accessor for the property "Index"
    /**
    * Calculates the index of this node among its siblings (in this node's
    * parent child array). If the specified node is root (has no parent)
    * returns -1.  This method performs a linear search and is O(n) where n is
    * the number of siblings.
    */
    public int getIndex()
        {
        TreeNode nodeParent = getParent();
        return nodeParent == null ? -1 :
            nodeParent.getMutableNode().getIndex(getMutableNode());
        }
    
    // Accessor for the property "MutableNode"
    public javax.swing.tree.DefaultMutableTreeNode getMutableNode()
        {
        DefaultMutableTreeNode _node = (DefaultMutableTreeNode) get_Sink();
        if (_node == null)
            {
            setMutableNode(_node = new DefaultMutableTreeNode());
            }
        return _node;
        }
    
    // Accessor for the property "Parent"
    public TreeNode getParent()
        {
        DefaultMutableTreeNode _parent = (DefaultMutableTreeNode) getMutableNode().getParent();
        
        if (_parent != null)
            {
            JTree tree = getTree();
            if (tree != null)
                {
                return tree.makeNode(_parent);
                }
            }
        
        return null;
        }
    
    // Accessor for the property "Path"
    public javax.swing.tree.TreePath getPath()
        {
        return new TreePath(getMutableNode().getPath());
        }
    
    // Accessor for the property "Tree"
    public _package.component.gUI.control.container.jComponent.JTree getTree()
        {
        return __m_Tree;
        }
    
    /**
    * Inserts a child node to this node at the specified position. Pass -1 to
    * append a child node at the end.
    */
    public TreeNode insert(TreeNode nodeChild, int index)
        {
        // import Component.Util.Config;
        // import javax.swing.tree.DefaultTreeModel;
        
        DefaultMutableTreeNode _nodeThis  = this     .getMutableNode();
        DefaultMutableTreeNode _nodeChild = nodeChild.getMutableNode();
        
        if (index == -1)
            {
            index = getChildCount();
            _nodeThis.add(_nodeChild);
            }
        else
            {
            _nodeThis.insert(_nodeChild, index);
            }
        
        JTree tree = getTree();
        
        nodeChild.setTree(tree);
        
        if (tree != null && tree.isRedraw())
            {
            if (getParent() != null)
                {
                _JTree _tree = (_JTree) tree.get_Feed();
                ((DefaultTreeModel) _tree.getModel()).nodesWereInserted(
                    _nodeThis, new int[] {index});
                }
            else
                {
                // bug in DefaultTreeModel -- the above logic is not working for the root node
                // TODO: remove when fixed or find a cheaper way...
                Config cfg = new Config();
                tree.saveConfig(cfg, "");
                reload();
                tree.applyConfig(cfg, "");
                }
            }
        
        return nodeChild;
        }
    
    // Accessor for the property "CaseSensitive"
    public boolean isCaseSensitive()
        {
        return __m_CaseSensitive;
        }
    
    // Accessor for the property "Collapsed"
    public boolean isCollapsed()
        {
        JTree tree = getTree();
        
        return tree == null ? true :
            ((javax.swing.JTree) tree.get_Feed()).isCollapsed(getPath());
        }
    
    // Accessor for the property "Editable"
    public boolean isEditable()
        {
        JTree tree = getTree();
        
        return __m_Editable && tree != null && tree.isEditable();
        }
    
    // Accessor for the property "Editing"
    public boolean isEditing()
        {
        JTree tree = getTree();
        
        return tree != null && tree.getEditingNode() == this;
        }
    
    // Accessor for the property "Expanded"
    public boolean isExpanded()
        {
        JTree tree = getTree();
        
        return tree == null ? false :
            ((javax.swing.JTree) tree.get_Feed()).isExpanded(getPath());
        }
    
    // Accessor for the property "Selected"
    public boolean isSelected()
        {
        JTree tree = getTree();
        
        return tree == null ? false :
            ((javax.swing.JTree) tree.get_Feed()).isPathSelected(getPath());
        }
    
    // Accessor for the property "Sorted"
    public boolean isSorted()
        {
        return __m_Sorted;
        }
    
    // Accessor for the property "Visible"
    public boolean isVisible()
        {
        JTree tree = getTree();
        
        return tree == null ? false :
            ((javax.swing.JTree) tree.get_Feed()).isVisible(getPath());

        }
    
    /**
    * Locate the position for the specified node such that the sort
    * requirements are satisfied.
    * 
    * Note: we cannot use binary search here, because a node's content could be
    * changed breaking the existing order and thus compareTo can return 0
    * prematurely (update() compensates for this).
    * 
    * @return an index of a new position or -1 if an item has to be added to
    * the end
    * 
    * @see #update
    */
    protected int locateNode(TreeNode node)
        {
        int cNodes = getChildCount();
        
        // optimization for definite "add to the end"
        if (cNodes == 0 || getChildAt(cNodes - 1).compareTo(node) < 0)
            {
            return -1;
            }
        
        for (int i = 0; i < cNodes; i++)
            {
            if (getChildAt(i).compareTo(node) > 0)
                {
                return i;
                }
            }
        
        return -1;
        
        /*
        *  binary search doesn't work because the order could be broken
        
        if (cNodes == 0)
            {
            return -1;
            }
        
        if (getChildAt(0).compareTo(node) > 0)
            {
            return 0;
            }
        if (getChildAt(cNodes - 1).compareTo(node) <= 0)
            {
            // if an order is broken by this item -- could be a mistake!
            _trace("ret -1! " + " should " + iRes);
            return -1;
            }
        
        int i0 = 0;
        int i2 = cNodes - 1;
        while (true)
            {
            int i = (i0 + i2) / 2;
            if (i == i0)
                {
                _trace("ret " + i2 + " should " + iRes);
                return i2;
                }
            int iComp = getChildAt(i).compareTo(node);
        
            if (iComp > 0)
                {
                i2 = i;
                }
            else if (iComp < 0)
                {
                i0 = i;
                }
            else
                {
                 // if an order is broken by this item, what to do?!
                }
            }
        */
        }
    
    public void reload()
        {
        // JDK 1.2 beta 4 has identical implemenation for both
        //     DefaultTreeModel.reload(DefaultMutableTreeNode) and
        //     DefaultTreeModel.nodeStructureChanged(DefaultMutableTreeNode)
        
        JTree tree = getTree();
        if (tree != null && tree.isRedraw())
            {
            tree.getModel().reload(getMutableNode());
            }

        }
    
    public void remove()
        {
        // import javax.swing.tree.DefaultTreeModel;
        
        TreeNode parent = getParent();
        
        // if a selected item gets removed will try to select a node in the following order:
        // a) next sibling item
        // b) previous sibling item
        // c) the parent
        
        JTree    tree    = getTree();
        boolean  fSelect = tree != null && isSelected();
        int      iNode   = getIndex();
        
        if (tree == null || !tree.isRedraw())
            {
            getMutableNode().removeFromParent();
            }
        else
            {
            _JTree _tree = (_JTree) tree.get_Feed();
            ((DefaultTreeModel) _tree.getModel()).removeNodeFromParent(getMutableNode());
            }
        
        setTree(null);
        
        if (fSelect)
            {
            int cNodes = parent.getChildCount();
            if (iNode < cNodes)
                {
                tree.setSelectionNode(parent.getChildAt(iNode));
                }
            else if (cNodes > 0)
                {
                tree.setSelectionNode(parent.getChildAt(cNodes - 1));
                }
            else
                {
                tree.setSelectionNode(parent);
                }
            }
        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        // import java.util.Enumeration;
        
        if (!isLeaf())
            {
            config.putBoolean(sPrefix + getId(), isExpanded());
        
            for (Enumeration enum = children(); enum.hasMoreElements();)
                {
                TreeNode child = (TreeNode) enum.nextElement();
        
                child.saveConfig(config, sPrefix);
                }
            }
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "CaseSensitive"
    public void setCaseSensitive(boolean pCaseSensitive)
        {
        __m_CaseSensitive = pCaseSensitive;
        }
    
    // Accessor for the property "Collapsed"
    public void setCollapsed(boolean pCollapsed)
        {
        JTree tree = getTree();
        
        if (tree != null)
            {
            _JTree _tree = (_JTree) tree.get_Feed();
            if (pCollapsed)
                {
                _tree.collapsePath(getPath());
                }
            else
                {
                _tree.expandPath(getPath());
                }
            }
        }
    
    // Accessor for the property "Collator"
    public void setCollator(java.text.Collator pCollator)
        {
        __m_Collator = pCollator;
        }
    
    // Accessor for the property "Editable"
    public void setEditable(boolean pEditable)
        {
        __m_Editable = pEditable;
        }
    
    // Accessor for the property "Expanded"
    public void setExpanded(boolean pExpanded)
        {
        JTree tree = getTree();
        
        if (tree != null)
            {
            _JTree _tree = (_JTree) tree.get_Feed();
            if (pExpanded)
                {
                _tree.expandPath(getPath());
                }
            else
                {
                _tree.collapsePath(getPath());
                }
            }
        }
    
    // Accessor for the property "MutableNode"
    public void setMutableNode(javax.swing.tree.DefaultMutableTreeNode pMutableNode)
        {
        set_Sink(pMutableNode);
        }
    
    // Accessor for the property "Parent"
    public void setParent(TreeNode pParent)
        {
        getMutableNode().setParent(pParent.getMutableNode());
        setTree(pParent.getTree());
        }
    
    // Accessor for the property "Sorted"
    public void setSorted(boolean pSorted)
        {
        __m_Sorted = pSorted;
        }
    
    // Accessor for the property "Tree"
    public void setTree(_package.component.gUI.control.container.jComponent.JTree pTree)
        {
        __m_Tree = pTree;
        }
    
    // Accessor for the property "Visible"
    public void setVisible(boolean pVisible)
        {
        // we can only make the node visible
        if (pVisible)
            {
            JTree tree = getTree();
            if (tree != null)
                {
                // _JTree#makeVisible() just expands if needed;
                // _JTree#scrollPathToVisible() calls makeVisible() internally
        
                ((_JTree) tree.get_Feed()).scrollPathToVisible(getPath());
                }
            }
        }
    
    /**
    * Initiates editing for this node.  The edit-attempt fails if the
    * CellEditor does not allow editing for the specified item.
    */
    public void startEditing()
        {
        JTree tree = getTree();
        if (tree != null)
            {
            tree.startEditingAtPath(getPath());
            }
        }
    
    // Declared at the super level
    public String toString()
        {
        // In some situations we store the reference to the TreeNode itself
        // as the UserObject property of MutableNode property,
        // which could cause the infinite recursion
        // (DefualtMutableNode.toString() calls UserObject.toString())
        
        Object obj = getUserObject();
        if (obj instanceof TreeNode)
            {
            return get_Name();
            }
        else
            {
            return obj == null ? null : obj.toString();
            }
        }
    
    public void update()
        {
        TreeNode nodeParent = getParent();
        if (nodeParent != null && nodeParent.isSorted())
            {
            int indexOld = getIndex();
            int indexNew = nodeParent.locateNode(this);
        
            if (indexNew > indexOld)
                {
                indexNew--;
                }
            else if (indexNew == -1 && indexOld == nodeParent.getChildCount() - 1)
                {
                indexNew = indexOld;
                }
        
            if (indexNew != indexOld)
                {
                // the state re-setting should be done with save/applyConfig
                boolean fSelect = isSelected();
                boolean fExpand = isExpanded();
        
                remove();
                nodeParent.insert(this, indexNew);
        
                if (fSelect)
                    {
                    getTree().setSelectionNode(this);
                    }
                if (fExpand)
                    {
                    setExpanded(true);
                    }
                }
            }
        
        JTree tree = getTree();
        if (tree != null && tree.isRedraw())
            {
            tree.getModel().nodeChanged(getMutableNode());
            }
        }
    
    /**
    * Update this node's leafes according to the specified node array.
    */
    public void update(TreeNode[] nodes, boolean fAddEmptyNodes)
        {
        // import Component.GUI.Control.Container.JComponent.JTree;
        // import java.util.Enumeration;
        
        // Note: this operation has a side effect for the "nodes" array
        
        JTree   tree         = getTree();
        boolean fWasExpanded = isExpanded(); // to work around JTree bug
        
        if (nodes == null || nodes.length == 0)
            {
            removeAllChildren();
            }
        else
            {
        EnumerateChildren:
            for (Enumeration enum = children(); enum.hasMoreElements();)
                {
                TreeNode node = (TreeNode) enum.nextElement();
                for (int i = 0; i < nodes.length; i++)
                    {
                    if (node.equals(nodes[i]))
                        {
                        // matching sub component is found
                        nodes[i] = null;
                        continue EnumerateChildren;
                        }
                    }
        
                // no matching subcomponent was found -- remove the node
                node.remove();
                }
        
            // add the subcomponents without matching nodes
            for (int i = 0; i < nodes.length; i++)
                {
                if (nodes[i] != null)
                    {
                    add(nodes[i]);
        
                    if (fAddEmptyNodes)
                        {
                        // to deffer parsing out the subtree
                        // lets add an empty sub-node
                        nodes[i].add(tree.makeNode(null));
                        }
                    }
                }
            }
        
        // removing all children could collapse the node
        if (fWasExpanded != isExpanded() && !isLeaf())
            {
            setExpanded(true);
            }
        }
    }
