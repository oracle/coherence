/* Class
*     _package.component.gUI.Control
*/

package _package.component.gUI;

import _package.component.gUI.Color;
import _package.component.gUI.Constraints;
import _package.component.gUI.Dimension;
import _package.component.gUI.Font;
import _package.component.gUI.Point;
import _package.component.gUI.Rectangle;
import _package.component.gUI.control.Container;
import _package.component.gUI.control.container.Window;
import _package.component.gUI.control.container.window.frame.JFrame;
import _package.component.gUI.image.Cursor;
import com.tangosol.run.component.EventDeathException;
import java.awt.Component; // as _Control
import java.awt.Cursor; // as _Cursor
import java.awt.Event;
import java.awt.datatransfer.Transferable;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetListener;
import java.util.Enumeration;
import javax.swing.SwingUtilities;

/*
* Integrates
*     java.awt.Component
*     using Component.Dev.Compiler.Integrator.AbstractBean
*/
public abstract class Control
        extends    _package.component.GUI
        implements java.awt.dnd.DragGestureListener,
                   java.awt.dnd.DragSourceListener,
                   java.awt.dnd.DropTargetListener,
                   java.awt.event.FocusListener,
                   java.awt.event.KeyListener,
                   java.awt.event.MouseListener,
                   java.awt.event.MouseMotionListener,
                   java.beans.PropertyChangeListener
    {
    // Fields declarations
    
    /**
    * Property _Background
    *
    */
    private transient java.awt.Color __m__Background;
    
    /**
    * Property _Bounds
    *
    */
    private transient java.awt.Rectangle __m__Bounds;
    
    /**
    * Property _Cursor
    *
    */
    private transient java.awt.Cursor __m__Cursor;
    
    /**
    * Property _FocusOwner
    *
    * Specifies itself or the child component which has focus, if any.
    * 
    * @see #FocusOwner property
    */
    
    /**
    * Property _Font
    *
    */
    private transient java.awt.Font __m__Font;
    
    /**
    * Property _Foreground
    *
    */
    private transient java.awt.Color __m__Foreground;
    
    /**
    * Property _Location
    *
    */
    private transient java.awt.Point __m__Location;
    
    /**
    * Property _LocationOnScreen
    *
    * Gets the location of this component in the form of a point specifying the
    * component's top-left corner in the screen's coordinate space.
    * 
    * @return An instance of <code>java.awt.Point</code> representing the
    * top-left corner of the component's bounds in the coordinate space of the
    * screen.
    */
    
    /**
    * Property _Size
    *
    */
    private transient java.awt.Dimension __m__Size;
    
    /**
    * Property Background
    *
    */
    private transient Color __m_Background;
    
    /**
    * Property Bounds
    *
    */
    private transient Rectangle __m_Bounds;
    
    /**
    * Property Constraints
    *
    */
    private Constraints __m_Constraints;
    
    /**
    * Property Displayable
    *
    * Determines whether this component is displayable. A component is
    * displayable when it is connected to a native screen resource. <p>
    *     A component is made displayable either when it is added to a
    * displayable containment hierarchy or when its containment hierarchy is
    * made displayable. A containment hierarchy is made displayable when its
    * ancestor window is either packed or made visible. <p>
    *     A component is made undisplayable either when it is removed from a
    * displayable containment hierarchy or when its containment hierarchy is
    * made undisplayable.  A containment hierarchy is made undisplayable when
    * its ancestor window is disposed.
    * 
    * @see java.awt.Component#isDisplayable
    */
    
    /**
    * Property DnDDraggingActive
    *
    * (Calulated) Specifies whether a dragging operation is currently in
    * progress.
    */
    
    /**
    * Property DnDDroppingActive
    *
    * (Calulated) Specifies whether a dropping operation is currently in
    * progress.
    */
    
    /**
    * Property DnDGlobalDragSource
    *
    * (Privately used static) Specifies the currently dragged control.
    */
    private static transient Control __s_DnDGlobalDragSource;
    
    /**
    * Property DnDGlobalDropTarget
    *
    * (Privately used static) Specifies the currently dropped onto control.
    */
    private static transient Control __s_DnDGlobalDropTarget;
    
    /**
    * Property DragActions
    *
    * Represents allowed Drag actions for this component. The values are:
    * ACTION_NONE = 0x0
    * ACTION_COPY = 0x1
    * ACTION_MOVE = 0x2
    * ACTION_COPY_OR_MOVE = ACTION_COPY | ACTION_MOVE
    * 
    * @see java.awt.dnd.DnDConstants
    */
    private int __m_DragActions;
    
    /**
    * Property DragAllowed
    *
    * Specifies whether this component allows "Dragging" from (i.e. being a
    * DragSource)
    */
    private boolean __m_DragAllowed;
    
    /**
    * Property DragCursor
    *
    * Calculated property that provides cursors for Drag and Drop actions.
    * Index will represent a Drag&Drop action.
    * 
    * In java.awt.dnd.DragSource there are six default cursors that are usually
    * used:
    * 
    * DefaultCopyDrop
    * DefaultMoveDrop
    * DefaultLinkDrop
    * DefaultCopyNoDrop
    * DefaultMoveNoDrop
    * DefaultLinkNoDrop
    * 
    * @see java.awt.dnd.DragSource
    */
    
    /**
    * Property DropActions
    *
    * Represents allowed Drop actions for this component. The values are:
    * ACTION_NONE = 0x0
    * ACTION_COPY = 0x1
    * ACTION_MOVE = 0x2
    * ACTION_COPY_OR_MOVE = ACTION_COPY | ACTION_MOVE
    * 
    * @see java.awt.dnd.DnDConstants
    */
    private int __m_DropActions;
    
    /**
    * Property DropAllowed
    *
    * Specifies whether this component allows "Dropping" into (i.e. being a
    * DropTarget)
    */
    private boolean __m_DropAllowed;
    
    /**
    * Property Enabled
    *
    */
    private transient boolean __m_Enabled;
    
    /**
    * Property Focusable
    *
    * Specifies whether or not this component can receive the focus. This
    * property serves as a designable helper for the actually integrated
    * calculated property "FocusTraversable". Even though the default value of
    * this property is true, the actual value of "FocusTraversable" property
    * depends on the integrated visual component. Setting this property to
    * false makes the component "un-focusable".
    * 
    * @see #isFocusTraversable
    * @see #requestFocus
    */
    private boolean __m_Focusable;
    
    /**
    * Property FocusOwner
    *
    * Specifies itself or the child control which has focus, if any.
    */
    
    /**
    * Property FocusTraversable
    *
    * (Integrated calculated property) Specifies whether or not this component
    * can be traversed using Tab or Shift-Tab keyboard focus traversal. In
    * swing, this is a calculated property. We could not make it designable (by
    * adding a setter) because a call to super.isFocusTraversable() should go
    * to the integratee instead. Instead we added the standard property
    * "Focusable" that controls the behavior of "isFocusTraversable" and
    * "requestFocus".
    * 
    * @see #Focusable property
    * @see #isFocusTraversable
    * @see #requestFocus
    */
    
    /**
    * Property Font
    *
    */
    private transient Font __m_Font;
    
    /**
    * Property Foreground
    *
    */
    private transient Color __m_Foreground;
    
    /**
    * Property Frame
    *
    * (Calculated) Parent frame or an owner frame of a parent window.
    */
    
    /**
    * Property INVOKE_NONE
    *
    */
    public static final int INVOKE_NONE = 0;
    
    /**
    * Property INVOKE_ON_PRESSED
    *
    */
    public static final int INVOKE_ON_PRESSED = 1;
    
    /**
    * Property INVOKE_ON_RELEASED
    *
    */
    public static final int INVOKE_ON_RELEASED = 2;
    
    /**
    * Property InvokePopup
    *
    * Specifies whether a popup [menu] should be invoked when the
    * "popupTrigger" button is pressed or released.
    * 
    * Valid values are:
    * INVOKE_NONE (0) -- Don't invoke
    * INVOKE_ON_PRESSED (1) -- Invoke when mouse pressed
    * INVOKE_ON_RELEASED (2) -- Invoke when mouse released
    * 
    * @see onMousePressed
    * @see onMouseReleased
    */
    private int __m_InvokePopup;
    
    /**
    * Property Location
    *
    */
    private transient Point __m_Location;
    
    /**
    * Property LocationOnScreen
    *
    * Gets the location of this component in the form of a point specifying the
    * component's top-left corner in the screen's
    * coordinate space.
    * @return An instance of <code>Component.GUI.Point</code> representing the
    * top-left corner of the component's bounds in the coordinate space of the
    * screen.
    */
    
    /**
    * Property ParentWindow
    *
    * (Calculated) Closest parent window.
    */
    
    /**
    * Property Showing
    *
    */
    
    /**
    * Property Size
    *
    */
    private transient Dimension __m_Size;
    
    /**
    * Property TBounds
    *
    */
    private String __m_TBounds;
    
    /**
    * Property TConstraints
    *
    */
    
    /**
    * Property TFont
    *
    */
    
    /**
    * Property Visible
    *
    */
    private transient boolean __m_Visible;
    
    // fields used by the integration model:
    private sink_Control __sink;
    private java.awt.Component __feed;
    
    // Initializing constructor
    public Control(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Event initializer
    protected void __initEvents()
        {
        addFocusListener(this);
        addKeyListener(this);
        addMouseListener(this);
        addMouseMotionListener(this);
        addPropertyChangeListener(this);
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/Control".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ FocusListener dispatcher
    private com.tangosol.util.Listeners __FocusListeners;
    private void addFocusListener$Router(java.awt.event.FocusListener l)
        {
        __sink.addFocusListener(l);
        }
    public void addFocusListener(java.awt.event.FocusListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __FocusListeners;
        if (_listeners == null)
            {
            __FocusListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addFocusListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeFocusListener$Router(java.awt.event.FocusListener l)
        {
        __sink.removeFocusListener(l);
        }
    public void removeFocusListener(java.awt.event.FocusListener l)
        {
        com.tangosol.util.Listeners _listeners = __FocusListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeFocusListener$Router(this);
            }
        }
    private void focusGained$Dispatch(java.awt.event.FocusEvent e)
        {
        java.util.EventListener[] targets = __FocusListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.FocusListener target = (java.awt.event.FocusListener) targets[i];
            if (target != this)
                {
                target.focusGained(e);
                }
            }
        }
    public void focusGained(java.awt.event.FocusEvent e)
        {
        try
            {
            onFocusGained();
            }
        catch (EventDeathException x)
            {
            return;
            }
        
        focusGained$Dispatch(e);
        }
    private void focusLost$Dispatch(java.awt.event.FocusEvent e)
        {
        java.util.EventListener[] targets = __FocusListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.FocusListener target = (java.awt.event.FocusListener) targets[i];
            if (target != this)
                {
                target.focusLost(e);
                }
            }
        }
    public void focusLost(java.awt.event.FocusEvent e)
        {
        try
            {
            // Note: no one seems to be setting the Temporary flag
            if (!e.isTemporary())
                {
                onFocusLost();
                }
            }
        catch (EventDeathException x)
            {
            return;
            }
        
        focusLost$Dispatch(e);
        }
    //-- FocusListener dispatcher
    
    //++ KeyListener dispatcher
    private com.tangosol.util.Listeners __KeyListeners;
    private void addKeyListener$Router(java.awt.event.KeyListener l)
        {
        __sink.addKeyListener(l);
        }
    public void addKeyListener(java.awt.event.KeyListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __KeyListeners;
        if (_listeners == null)
            {
            __KeyListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addKeyListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeKeyListener$Router(java.awt.event.KeyListener l)
        {
        __sink.removeKeyListener(l);
        }
    public void removeKeyListener(java.awt.event.KeyListener l)
        {
        com.tangosol.util.Listeners _listeners = __KeyListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeKeyListener$Router(this);
            }
        }
    private void keyPressed$Dispatch(java.awt.event.KeyEvent e)
        {
        java.util.EventListener[] targets = __KeyListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.KeyListener target = (java.awt.event.KeyListener) targets[i];
            if (target != this)
                {
                target.keyPressed(e);
                }
            }
        }
    public void keyPressed(java.awt.event.KeyEvent e)
        {
        try
            {
            onKeyPressed(e.getKeyChar(), e.getKeyCode(), e.getModifiers());
            }
        catch (EventDeathException x)
            {
            e.consume();
            return;
            }
        
        keyPressed$Dispatch(e);

        }
    private void keyReleased$Dispatch(java.awt.event.KeyEvent e)
        {
        java.util.EventListener[] targets = __KeyListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.KeyListener target = (java.awt.event.KeyListener) targets[i];
            if (target != this)
                {
                target.keyReleased(e);
                }
            }
        }
    public void keyReleased(java.awt.event.KeyEvent e)
        {
        try
            {
            onKeyReleased(e.getKeyChar(), e.getKeyCode(), e.getModifiers());
            }
        catch (EventDeathException x)
            {
            e.consume();
            return;
            }
        
        keyReleased$Dispatch(e);

        }
    private void keyTyped$Dispatch(java.awt.event.KeyEvent e)
        {
        java.util.EventListener[] targets = __KeyListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.KeyListener target = (java.awt.event.KeyListener) targets[i];
            if (target != this)
                {
                target.keyTyped(e);
                }
            }
        }
    public void keyTyped(java.awt.event.KeyEvent e)
        {
        try
            {
            onKeyTyped(e.getKeyChar(), e.getModifiers());
            }
        catch (EventDeathException x)
            {
            e.consume();
            return;
            }
        
        keyTyped$Dispatch(e);

        }
    //-- KeyListener dispatcher
    
    //++ MouseListener dispatcher
    private com.tangosol.util.Listeners __MouseListeners;
    private void addMouseListener$Router(java.awt.event.MouseListener l)
        {
        __sink.addMouseListener(l);
        }
    public void addMouseListener(java.awt.event.MouseListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __MouseListeners;
        if (_listeners == null)
            {
            __MouseListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addMouseListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeMouseListener$Router(java.awt.event.MouseListener l)
        {
        __sink.removeMouseListener(l);
        }
    public void removeMouseListener(java.awt.event.MouseListener l)
        {
        com.tangosol.util.Listeners _listeners = __MouseListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeMouseListener$Router(this);
            }
        }
    private void mouseClicked$Dispatch(java.awt.event.MouseEvent e)
        {
        java.util.EventListener[] targets = __MouseListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.MouseListener target = (java.awt.event.MouseListener) targets[i];
            if (target != this)
                {
                target.mouseClicked(e);
                }
            }
        }
    public void mouseClicked(java.awt.event.MouseEvent e)
        {
        try
            {
            onMouseClicked(Point.instantiate(e.getX(), e.getY()),
                e.getModifiers(), e.getClickCount());
            }
        catch (EventDeathException x)
            {
            return;
            }
        
        mouseClicked$Dispatch(e);
        }
    private void mouseEntered$Dispatch(java.awt.event.MouseEvent e)
        {
        java.util.EventListener[] targets = __MouseListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.MouseListener target = (java.awt.event.MouseListener) targets[i];
            if (target != this)
                {
                target.mouseEntered(e);
                }
            }
        }
    public void mouseEntered(java.awt.event.MouseEvent e)
        {
        try
            {
            onMouseEntered(Point.instantiate(e.getX(), e.getY()), e.getModifiers());
            }
        catch (EventDeathException x)
            {
            return;
            }
        
        mouseEntered$Dispatch(e);

        }
    private void mouseExited$Dispatch(java.awt.event.MouseEvent e)
        {
        java.util.EventListener[] targets = __MouseListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.MouseListener target = (java.awt.event.MouseListener) targets[i];
            if (target != this)
                {
                target.mouseExited(e);
                }
            }
        }
    public void mouseExited(java.awt.event.MouseEvent e)
        {
        try
            {
            onMouseExited(Point.instantiate(e.getX(), e.getY()), e.getModifiers());
            }
        catch (EventDeathException x)
            {
            return;
            }
        
        mouseExited$Dispatch(e);

        }
    private void mousePressed$Dispatch(java.awt.event.MouseEvent e)
        {
        java.util.EventListener[] targets = __MouseListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.MouseListener target = (java.awt.event.MouseListener) targets[i];
            if (target != this)
                {
                target.mousePressed(e);
                }
            }
        }
    public void mousePressed(java.awt.event.MouseEvent e)
        {
        // import java.awt.Event;
        
        try
            {
            // Note: e.isPopupTrigger() is always false for mousePressed
            onMousePressed(Point.instantiate(e.getX(), e.getY()),
                e.getModifiers(), e.getClickCount(),
                e.isPopupTrigger() || (e.getModifiers() & Event.META_MASK) != 0);
            }
        catch (EventDeathException x)
            {
            return;
            }
        
        mousePressed$Dispatch(e);
        }
    private void mouseReleased$Dispatch(java.awt.event.MouseEvent e)
        {
        java.util.EventListener[] targets = __MouseListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.MouseListener target = (java.awt.event.MouseListener) targets[i];
            if (target != this)
                {
                target.mouseReleased(e);
                }
            }
        }
    public void mouseReleased(java.awt.event.MouseEvent e)
        {
        // import java.awt.Event;
        
        try
            {
            onMouseReleased(Point.instantiate(e.getX(), e.getY()),
                e.getModifiers(), e.getClickCount(),
                e.isPopupTrigger() || (e.getModifiers() & Event.META_MASK) != 0);
            }
        catch (EventDeathException x)
            {
            return;
            }
        
        mouseReleased$Dispatch(e);

        }
    //-- MouseListener dispatcher
    
    //++ MouseMotionListener dispatcher
    private com.tangosol.util.Listeners __MouseMotionListeners;
    private void addMouseMotionListener$Router(java.awt.event.MouseMotionListener l)
        {
        __sink.addMouseMotionListener(l);
        }
    public void addMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __MouseMotionListeners;
        if (_listeners == null)
            {
            __MouseMotionListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addMouseMotionListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removeMouseMotionListener$Router(java.awt.event.MouseMotionListener l)
        {
        __sink.removeMouseMotionListener(l);
        }
    public void removeMouseMotionListener(java.awt.event.MouseMotionListener l)
        {
        com.tangosol.util.Listeners _listeners = __MouseMotionListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removeMouseMotionListener$Router(this);
            }
        }
    private void mouseDragged$Dispatch(java.awt.event.MouseEvent e)
        {
        java.util.EventListener[] targets = __MouseMotionListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.MouseMotionListener target = (java.awt.event.MouseMotionListener) targets[i];
            if (target != this)
                {
                target.mouseDragged(e);
                }
            }
        }
    public void mouseDragged(java.awt.event.MouseEvent e)
        {
        try
            {
            onMouseDragged(Point.instantiate(e.getX(), e.getY()), e.getModifiers());
            }
        catch (EventDeathException x)
            {
            return;
            }
        
        mouseDragged$Dispatch(e);

        }
    private void mouseMoved$Dispatch(java.awt.event.MouseEvent e)
        {
        java.util.EventListener[] targets = __MouseMotionListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.awt.event.MouseMotionListener target = (java.awt.event.MouseMotionListener) targets[i];
            if (target != this)
                {
                target.mouseMoved(e);
                }
            }
        }
    public void mouseMoved(java.awt.event.MouseEvent e)
        {
        try
            {
            onMouseMoved(Point.instantiate(e.getX(), e.getY()), e.getModifiers());
            }
        catch (EventDeathException x)
            {
            return;
            }
        
        mouseMoved$Dispatch(e);

        }
    //-- MouseMotionListener dispatcher
    
    //++ PropertyChangeListener dispatcher
    private com.tangosol.util.Listeners __PropertyChangeListeners;
    private void addPropertyChangeListener$Router(java.beans.PropertyChangeListener l)
        {
        __sink.addPropertyChangeListener(l);
        }
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        if (l == null)
            {
            return;
            }
        com.tangosol.util.Listeners _listeners = __PropertyChangeListeners;
        if (_listeners == null)
            {
            __PropertyChangeListeners = _listeners = new com.tangosol.util.Listeners();
            }
        if (_listeners.listeners().length == 0)
            {
            addPropertyChangeListener$Router(this);
            }
        _listeners.add(l);
        }
    private void removePropertyChangeListener$Router(java.beans.PropertyChangeListener l)
        {
        __sink.removePropertyChangeListener(l);
        }
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l)
        {
        com.tangosol.util.Listeners _listeners = __PropertyChangeListeners;
        if (_listeners == null)
            {
            return; // there is nothing to remove yet
            }
        _listeners.remove(l);
        if (_listeners.listeners().length == 0)
            {
            removePropertyChangeListener$Router(this);
            }
        }
    private void propertyChange$Dispatch(java.beans.PropertyChangeEvent e)
        {
        java.util.EventListener[] targets = __PropertyChangeListeners.listeners();
        for (int i = targets.length; --i >= 0;)
            {
            java.beans.PropertyChangeListener target = (java.beans.PropertyChangeListener) targets[i];
            if (target != this)
                {
                target.propertyChange(e);
                }
            }
        }
    public void propertyChange(java.beans.PropertyChangeEvent e)
        {
        try
            {
            if (is_Constructed())
                {
                onPropertyChange(e.getPropertyName(), e.getNewValue(), e.getOldValue());
                }
            }
        catch (EventDeathException x)
            {
            return;
            }
        
        propertyChange$Dispatch(e);
        }
    //-- PropertyChangeListener dispatcher
    
    //++ java.awt.Component integration
    // Access optimization
    /**
    * Setter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Sink(Object pSink)
        {
        __sink = (sink_Control) pSink;
        super.set_Sink(pSink);
        }
    /**
    * Setter for property _Feed.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Feed(Object pFeed)
        {
        __feed = (java.awt.Component) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public void addNotify()
        {
        __sink.addNotify();
        }
    public void doLayout()
        {
        __sink.doLayout();
        }
    /**
    * Getter for property _Background.<p>
    */
    public java.awt.Color get_Background()
        {
        return __sink.getBackground();
        }
    /**
    * Getter for property _Bounds.<p>
    */
    public java.awt.Rectangle get_Bounds()
        {
        return __sink.getBounds();
        }
    /**
    * Getter for property _Cursor.<p>
    */
    public java.awt.Cursor get_Cursor()
        {
        return __sink.getCursor();
        }
    /**
    * Getter for property _Font.<p>
    */
    public java.awt.Font get_Font()
        {
        return __sink.getFont();
        }
    /**
    * Getter for property _Foreground.<p>
    */
    public java.awt.Color get_Foreground()
        {
        return __sink.getForeground();
        }
    /**
    * Getter for property _Location.<p>
    */
    public java.awt.Point get_Location()
        {
        return __sink.getLocation();
        }
    /**
    * Getter for property _LocationOnScreen.<p>
    * Gets the location of this component in the form of a point specifying the
    * component's top-left corner in the screen's coordinate space.
    * 
    * @return An instance of <code>java.awt.Point</code> representing the
    * top-left corner of the component's bounds in the coordinate space of the
    * screen.
    */
    public java.awt.Point get_LocationOnScreen()
        {
        return __sink.getLocationOnScreen();
        }
    /**
    * Getter for property _Size.<p>
    */
    public java.awt.Dimension get_Size()
        {
        return __sink.getSize();
        }
    /**
    * Getter for property Enabled.<p>
    */
    public boolean isEnabled()
        {
        return __sink.isEnabled();
        }
    private boolean isFocusTraversable$Router()
        {
        return __sink.isFocusTraversable();
        }
    /**
    * Returns the value of a flag that indicates whether this component can be
    * traversed using Tab or Shift-Tab keyboard focus traversal. If this method
    * returns "false", this component may still request the keyboard focus
    * using <code>requestFocus()</code>, but it will not automatically be
    * assigned focus during tab traversal.
    * 
    * @see #Focusable property
    */
    public boolean isFocusTraversable()
        {
        return isFocusable() && isFocusTraversable$Router();
        }
    /**
    * Getter for property Showing.<p>
    */
    public boolean isShowing()
        {
        return __sink.isShowing();
        }
    /**
    * Getter for property Visible.<p>
    */
    public boolean isVisible()
        {
        return __sink.isVisible();
        }
    public void paint(java.awt.Graphics g)
        {
        __sink.paint(g);
        }
    public void removeNotify()
        {
        __sink.removeNotify();
        }
    private void requestFocus$Router()
        {
        __sink.requestFocus();
        }
    /**
    * Requests that this component get the input focus. The component must be
    * visible on the screen for this request to be granted.
    * 
    * @see JComponent#requestDefaultFocus
    */
    public void requestFocus()
        {
        if (isFocusable())
            {
            // if this call is made in a process of DnD in progress
            // the AWT thread hangs with the following trace
            //(with some irrelevant lines removed):
            
            /*
            "AWT-EventQueue-0" prio=7 tid=0x85dbf0 nid=0x97 runnable [0x1aaef000..0x1aaefe44]    
                at sun.awt.windows.WInputMethod.disableNativeIME(Native Method)
                at sun.awt.windows.WInputMethod.deactivate(WInputMethod.java:239)
                at sun.awt.im.InputContext.deactivate(InputContext.java:213)
                at sun.awt.im.InputContext.dispatchEvent(InputContext.java:146)
                at sun.awt.im.InputMethodContext.dispatchEvent(InputMethodContext.java:148)
                at java.awt.Component.dispatchEventImpl(Component.java:2338)
                at java.awt.Container.dispatchEventImpl(Container.java:1035)
                at java.awt.Component.dispatchEvent(Component.java:2307)
                at java.awt.LightweightDispatcher.setFocusRequest(Container.java:1700)
                at java.awt.Container.proxyRequestFocus(Container.java:1215)
                ...
                at java.awt.Container.proxyRequestFocus(Container.java:1210)
                at java.awt.Component.requestFocus(Component.java:3529)
                at javax.swing.JComponent.requestFocus(JComponent.java:754)
                ...
                at _package.Component.GUI.Control.Container.JComponent.JPanel.ToolSite.LayoutDesigner$ScrollPane$Workspace$Lid.prepareTransferAtLocation(LayoutDesigner.CDB:3)
                at _package.Component.GUI.Control.dragOver(Control.CDB:1)
                at java.awt.dnd.DropTarget.dragOver(DropTarget.java:327)
                at sun.awt.windows.WDropTargetContextPeer.processMotionMessage(WDropTargetContextPeer.java:786)
                at sun.awt.windows.WDropTargetContextPeer.run(WDropTargetContextPeer.java:464)
                at javax.swing.SystemEventQueueUtilities.processRunnableEvent(SystemEventQueueUtilities.java:366)
                at javax.swing.SystemEventQueueUtilities.access$0(SystemEventQueueUtilities.java:362)
                at javax.swing.SystemEventQueueUtilities$RunnableTarget.processEvent(SystemEventQueueUtilities.java:403)
                at java.awt.Component.dispatchEventImpl(Component.java:2394)
                at java.awt.Component.dispatchEvent(Component.java:2307)
                at java.awt.EventQueue.dispatchEvent(EventQueue.java:287)
                at java.awt.EventDispatchThread.pumpOneEvent(EventDispatchThread.java:101)
                at java.awt.EventDispatchThread.pumpEvents(EventDispatchThread.java:92)
                at java.awt.EventDispatchThread.run(EventDispatchThread.java:83)
            */
        
            // TODO: this is a workaround for DnD bug -- remove when fixed
            if (isDnDDroppingActive())
                {
                // _trace("Cannot set focus to " + get_Name() + " due to the DnD bug");
                }
            else
                {
                requestFocus$Router();
                }
            }
        }
    /**
    * Setter for property _Background.<p>
    */
    public void set_Background(java.awt.Color p_Background)
        {
        __sink.setBackground(p_Background);
        }
    /**
    * Setter for property _Bounds.<p>
    */
    public void set_Bounds(java.awt.Rectangle p_Bounds)
        {
        __sink.setBounds(p_Bounds);
        }
    /**
    * The following is a quote from java.awt.Component#setCursor:
    * 
    * "Setting the cursor of a <code>Container</code> causes that cursor  to be
    * displayed within all of the container's subcomponents,  except for any
    * subcomponents that are using a non-default cursor."
    * 
    * However, that functionality is not implemented, and may never be,
    * because, for example, if the parent is a JSplitPane, using its cursor is
    * wrong for the contained panels.
    */
    public void set_Cursor(java.awt.Cursor p_Cursor)
        {
        __sink.setCursor(p_Cursor);
        }
    /**
    * Setter for property Enabled.<p>
    */
    public void setEnabled(boolean pEnabled)
        {
        __sink.setEnabled(pEnabled);
        }
    /**
    * Setter for property _Font.<p>
    */
    public void set_Font(java.awt.Font p_Font)
        {
        __sink.setFont(p_Font);
        }
    /**
    * Setter for property _Foreground.<p>
    */
    public void set_Foreground(java.awt.Color p_Foreground)
        {
        __sink.setForeground(p_Foreground);
        }
    /**
    * Setter for property _Location.<p>
    */
    public void set_Location(java.awt.Point p_Location)
        {
        __sink.setLocation(p_Location);
        }
    /**
    * Setter for property _Size.<p>
    */
    public void set_Size(java.awt.Dimension p_Size)
        {
        __sink.setSize(p_Size);
        }
    /**
    * Setter for property Visible.<p>
    */
    public void setVisible(boolean pVisible)
        {
        __sink.setVisible(pVisible);
        }
    public void validate()
        {
        __sink.validate();
        }
    //-- java.awt.Component integration
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Dimension;
        // import Component.GUI.Rectangle;
        // import Component.GUI.Point;
        // import com.tangosol.run.component.EventDeathException;
        // import java.awt.Component as _Control;
        

        }
    
    /**
    * Bring up the specified dialog box.
    * 
    * @param panel  the dialog's main panel
    * @param oDialogPrm  dialog parameter (often an array of objects)
    * 
    * @return result of the dialog's execution (value of dialog main panel's
    * property DialogResult)
    * 
    * @see Window#dialogBox
    * @see JDesktopPane#dialogBox
    */
    public Object dialogBox(_package.component.gUI.control.container.jComponent.JPanel panel, Object oDialogPrm)
        {
        // import Component.GUI.Control.Container;
        
        Container parent = (Container) get_Parent();
        _assert(parent != null, "Parentless control " + get_Name());
        
        return parent.dialogBox(panel, oDialogPrm);
        }
    
    // From interface: java.awt.dnd.DragSourceListener
    public void dragDropEnd(java.awt.dnd.DragSourceDropEvent dsde)
        {
        setDnDGlobalDragSource(null);
        }
    
    // From interface: java.awt.dnd.DragSourceListener
    public void dragEnter(java.awt.dnd.DragSourceDragEvent dsde)
        {
        }
    
    // From interface: java.awt.dnd.DropTargetListener
    public void dragEnter(java.awt.dnd.DropTargetDragEvent dtde)
        {
        setDnDGlobalDropTarget(this);
        }
    
    // From interface: java.awt.dnd.DragSourceListener
    public void dragExit(java.awt.dnd.DragSourceEvent dse)
        {
        }
    
    // From interface: java.awt.dnd.DropTargetListener
    public void dragExit(java.awt.dnd.DropTargetEvent dte)
        {
        setDnDGlobalDropTarget(null);
        }
    
    // From interface: java.awt.dnd.DragGestureListener
    public void dragGestureRecognized(java.awt.dnd.DragGestureEvent dge)
        {
        // import Component.GUI.Image.Cursor;
        // import java.awt.datatransfer.Transferable;
        
        Transferable transfer = getTransferAtLocation(
            Point.instantiate(dge.getDragOrigin()));
        
        if (transfer != null)
            {
            setDnDGlobalDragSource(this);
        
            // if we set the cursor here, we should update it in dragOver
            // as well as dragEnter; null here specifies the "default" handling
            // (see Bug Id 4455820, 4217416)
            dge.startDrag(/*(_Cursor)*/ null, transfer, /*(DragSourceListener)*/ this);
            }
        }
    
    // From interface: java.awt.dnd.DragSourceListener
    public void dragOver(java.awt.dnd.DragSourceDragEvent dsde)
        {
        }
    
    // From interface: java.awt.dnd.DropTargetListener
    public void dragOver(java.awt.dnd.DropTargetDragEvent dtde)
        {
        boolean fAccept = false;
        int     iAction = dtde.getDropAction();
        
        try
            {
            if ((iAction & getDropActions()) != 0)
                {
                fAccept = prepareTransferAtLocation(Point.instantiate(dtde.getLocation()),
                    iAction, dtde.getCurrentDataFlavorsAsList());
                }
            }
        finally
            {
            if (fAccept)
                {
                dtde.acceptDrag(iAction);
                }
            else
                {
                dtde.rejectDrag();
                }
            }
        }
    
    // From interface: java.awt.dnd.DropTargetListener
    public void drop(java.awt.dnd.DropTargetDropEvent dtde)
        {
        boolean fComplete = false;
        int     iAction   = dtde.getDropAction();
        
        try
            {
            if ((iAction & getDropActions()) != 0)
                {
                // the spec requires that, but DnD works without this as well
                dtde.acceptDrop(iAction);
        
                fComplete = putTransferAtLocation(
                    dtde.getTransferable(), Point.instantiate(dtde.getLocation()), iAction);
                }
            }
        finally
            {
            if (!fComplete)
                {
                dtde.rejectDrop();
                }
            dtde.dropComplete(fComplete);
            }
        }
    
    // From interface: java.awt.dnd.DragSourceListener
    public void dropActionChanged(java.awt.dnd.DragSourceDragEvent dsde)
        {
        }
    
    // From interface: java.awt.dnd.DropTargetListener
    public void dropActionChanged(java.awt.dnd.DropTargetDragEvent dtde)
        {
        }
    
    // Accessor for the property "_FocusOwner"
    /**
    * Getter for property _FocusOwner.<p>
    * Specifies itself or the child component which has focus, if any.
    * 
    * @see #FocusOwner property
    */
    public java.awt.Component get_FocusOwner()
        {
        // import javax.swing.SwingUtilities;
        
        return SwingUtilities.findFocusOwner((_Control) get_Feed());
        }
    
    /**
    * This method is called by  Component.Control.Container#addControl() as a
    * last chance to intervene during the construction/integration cycle.
    * A Control would override this if more than one AWT components should be
    * created for one Control or if the component should not be added to the
    * container (see Component...Window or Component...TabbedPanel).
    * This method can also be used to make sure that the parent is of the
    * allowed type (i.e. TabbedPanel is only allowed to be added into the
    * JTabbedPane).
    *  
    * @param  fAdd is true <b>only</b> when this is the frist call (from
    * addControl()) and an override is supposed to tie all the pieces together;
    * false in all other situations
    * 
    * @return AWT component that is added to a container [integratee].
    * 
    * @see Component.Control.Container.Window
    * @see Component.GUI.Control.Container.JComponent
    * @see
    * Component.GUI.Control.Container.JComponent.AbstractButton.JMenuItem.JMenu
    * @see Component.GUI.Control.Container.JComponent.JPanel.ButtonGroupPanel
    */
    public java.awt.Component getAWTContainee(boolean fAdd)
        {
        return (java.awt.Component) get_Feed();
        }
    
    // Accessor for the property "Background"
    /**
    * Getter for property Background.<p>
    */
    public Color getBackground()
        {
        // import Component.GUI.Color;
        Color color = __m_Background;
        if (color == null)
            {
            color = new Color();
            color.set_Color(get_Background());
            }
        return color;
        }
    
    // Accessor for the property "Bounds"
    /**
    * Getter for property Bounds.<p>
    */
    public Rectangle getBounds()
        {
        return Rectangle.instantiate(get_Bounds());
        }
    
    // Accessor for the property "Constraints"
    /**
    * Getter for property Constraints.<p>
    */
    public Constraints getConstraints()
        {
        return __m_Constraints;
        }
    
    // Accessor for the property "DnDGlobalDragSource"
    /**
    * Getter for property DnDGlobalDragSource.<p>
    * (Privately used static) Specifies the currently dragged control.
    */
    private static Control getDnDGlobalDragSource()
        {
        return __s_DnDGlobalDragSource;
        }
    
    // Accessor for the property "DnDGlobalDropTarget"
    /**
    * Getter for property DnDGlobalDropTarget.<p>
    * (Privately used static) Specifies the currently dropped onto control.
    */
    private static Control getDnDGlobalDropTarget()
        {
        return __s_DnDGlobalDropTarget;
        }
    
    // Accessor for the property "DragActions"
    /**
    * Getter for property DragActions.<p>
    * Represents allowed Drag actions for this component. The values are:
    * ACTION_NONE = 0x0
    * ACTION_COPY = 0x1
    * ACTION_MOVE = 0x2
    * ACTION_COPY_OR_MOVE = ACTION_COPY | ACTION_MOVE
    * 
    * @see java.awt.dnd.DnDConstants
    */
    public int getDragActions()
        {
        return __m_DragActions;
        }
    
    // Accessor for the property "DragCursor"
    /**
    * Returns a cursors for Drag and Drop actions. Index represents a Drag&Drop
    * action.
    * 
    * @see #DragCursor property
    */
    public _package.component.gUI.image.Cursor getDragCursor(int pIndex)
        {
        // import Component.GUI.Image.Cursor;
        // import java.awt.Cursor as _Cursor;
        // import java.awt.dnd.DnDConstants;
        // import java.awt.dnd.DragSource;
        
        int     iAction = pIndex;
        _Cursor _cursor;
        
        switch (iAction)
            {
            default:
            case DnDConstants.ACTION_MOVE:
                _cursor = DragSource.DefaultMoveDrop;
                break;
        
            case DnDConstants.ACTION_COPY:
                _cursor = DragSource.DefaultCopyDrop;
                break;
            }
        
        return Cursor.instantiate(_cursor);
        }
    
    // Accessor for the property "DropActions"
    /**
    * Getter for property DropActions.<p>
    * Represents allowed Drop actions for this component. The values are:
    * ACTION_NONE = 0x0
    * ACTION_COPY = 0x1
    * ACTION_MOVE = 0x2
    * ACTION_COPY_OR_MOVE = ACTION_COPY | ACTION_MOVE
    * 
    * @see java.awt.dnd.DnDConstants
    */
    public int getDropActions()
        {
        return __m_DropActions;
        }
    
    // Accessor for the property "FocusOwner"
    /**
    * Getter for property FocusOwner.<p>
    * Specifies itself or the child control which has focus, if any.
    */
    public Control getFocusOwner()
        {
        return (Control) _findFeed(get_FocusOwner());
        }
    
    // Accessor for the property "Font"
    /**
    * Getter for property Font.<p>
    */
    public Font getFont()
        {
        // import Component.GUI.Font;
        
        Font font = __m_Font;
        if (font == null)
            {
            font = new Font();
            font.set_Font(get_Font()); // font._Font = _Font;
            }
        return font;
        }
    
    // Accessor for the property "Foreground"
    /**
    * Getter for property Foreground.<p>
    */
    public Color getForeground()
        {
        // import Component.GUI.Color;
        
        Color color = __m_Foreground;
        if (color == null)
            {
            color = new Color();
            color.set_Color(get_Foreground());
            }
        return color;
        }
    
    // Accessor for the property "Frame"
    /**
    * Returns the parent frame or an owner frame of a parent window.
    */
    public _package.component.gUI.control.container.window.frame.JFrame getFrame()
        {
        // import Component.GUI.Control.Container.Window;
        // import Component.GUI.Control.Container.Window.Frame.JFrame;
        
        Window w = getParentWindow();
        
        while (w != null && !(w instanceof JFrame))
            {
            w = w.getOwner();
            }
        
        return (JFrame) w;
        }
    
    // Accessor for the property "InvokePopup"
    /**
    * Getter for property InvokePopup.<p>
    * Specifies whether a popup [menu] should be invoked when the
    * "popupTrigger" button is pressed or released.
    * 
    * Valid values are:
    * INVOKE_NONE (0) -- Don't invoke
    * INVOKE_ON_PRESSED (1) -- Invoke when mouse pressed
    * INVOKE_ON_RELEASED (2) -- Invoke when mouse released
    * 
    * @see onMousePressed
    * @see onMouseReleased
    */
    public int getInvokePopup()
        {
        return __m_InvokePopup;
        }
    
    // Accessor for the property "Location"
    /**
    * Getter for property Location.<p>
    */
    public Point getLocation()
        {
        return Point.instantiate(get_Location());
        }
    
    // Accessor for the property "LocationOnScreen"
    /**
    * Gets the location of this component in the form of a point specifying the
    * component's top-left corner in the screen's coordinate space.
    * 
    * @see JComponent#convertPointToScreen
    */
    public Point getLocationOnScreen()
        {
        // import Component.GUI.Point;
        
        // TO DO: overwrite at JComponent?
        
        return Point.instantiate(((_Control) get_Feed()).getLocationOnScreen());
        }
    
    // Accessor for the property "ParentWindow"
    /**
    * Returns the closest "Window" parent.
    */
    public _package.component.gUI.control.container.Window getParentWindow()
        {
        // import Component.GUI.Control.Container.Window;
        
        return (Window) _findAncestor(Window.class);
        }
    
    /**
    * Gets the location of this component in the form of a point specifying the
    * component's top-left corner in the specified Container's coordinate
    * space.
    * 
    * @see JComponent#convertPointToScreen
    * 
    * @throws IllegalArgumentException if the specified Container does not
    * contain this Control
    */
    public Point getRelativeLocation(_package.component.gUI.control.Container parent)
        {
        // import Component.GUI.Point;
        
        Control child = this;
        Point   pt    = getLocation();
        
        while (true)
            {
            child = (Control) child.get_Parent();
            if (child == parent)
                {
                return pt;
                }
            if (child == null)
                {
                throw new IllegalArgumentException(
                    parent.get_Name() + " is not a parent of " + this.get_Name());
                }
            pt.add(child.getLocation());
            }
        }
    
    // Accessor for the property "Size"
    /**
    * Getter for property Size.<p>
    */
    public Dimension getSize()
        {
        return Dimension.instantiate(get_Size());

        }
    
    // Accessor for the property "TBounds"
    /**
    * Getter for property TBounds.<p>
    */
    private String getTBounds()
        {
        return __m_TBounds;
        }
    
    /**
    * Gets (drags) a Transferable object from a given location.
    * 
    * @return Transferable object at given location; null if there is nothing
    * to transfer
    * 
    * @see dragGestureRecognized()
    */
    protected java.awt.datatransfer.Transferable getTransferAtLocation(Point point)
        {
        return null;
        }
    
    public void invalidate()
        {
        // TO DO: do we want to integrate this?
        // see JComponent#revalidate()
        ((_Control) get_Feed()).invalidate();

        }
    
    /**
    * Invoke a popup (usually a context menu) for this component at the
    * specified location. Default implementation looks for a child Control
    * named "Context" and tries to instantiate it.
    */
    protected void invokePopup(Point point)
        {
        Control popup = (Control) _findChild("Context");
        if (popup != null && !popup.isVisible())
            {
            popup.setLocation(point);
            popup.setVisible(true);
        
            if (getInvokePopup() == INVOKE_ON_PRESSED)
                {
                // without the following the popup would be closed right away
                throw new EventDeathException();
                }
            }
        }
    
    // Accessor for the property "Displayable"
    /**
    * Getter for property Displayable.<p>
    * Determines whether this component is displayable. A component is
    * displayable when it is connected to a native screen resource. <p>
    *     A component is made displayable either when it is added to a
    * displayable containment hierarchy or when its containment hierarchy is
    * made displayable. A containment hierarchy is made displayable when its
    * ancestor window is either packed or made visible. <p>
    *     A component is made undisplayable either when it is removed from a
    * displayable containment hierarchy or when its containment hierarchy is
    * made undisplayable.  A containment hierarchy is made undisplayable when
    * its ancestor window is disposed.
    * 
    * @see java.awt.Component#isDisplayable
    */
    public boolean isDisplayable()
        {
        return ((_Control) get_Feed()).isDisplayable();

        }
    
    // Accessor for the property "DnDDraggingActive"
    /**
    * Getter for property DnDDraggingActive.<p>
    * (Calulated) Specifies whether a dragging operation is currently in
    * progress.
    */
    public boolean isDnDDraggingActive()
        {
        return getDnDGlobalDragSource() != null;
        }
    
    // Accessor for the property "DnDDroppingActive"
    /**
    * Getter for property DnDDroppingActive.<p>
    * (Calulated) Specifies whether a dropping operation is currently in
    * progress.
    */
    public boolean isDnDDroppingActive()
        {
        return getDnDGlobalDropTarget() != null;
        }
    
    // Accessor for the property "DragAllowed"
    /**
    * Getter for property DragAllowed.<p>
    * Specifies whether this component allows "Dragging" from (i.e. being a
    * DragSource)
    */
    public boolean isDragAllowed()
        {
        return __m_DragAllowed;
        }
    
    // Accessor for the property "DropAllowed"
    /**
    * Getter for property DropAllowed.<p>
    * Specifies whether this component allows "Dropping" into (i.e. being a
    * DropTarget)
    */
    public boolean isDropAllowed()
        {
        return __m_DropAllowed;
        }
    
    // Accessor for the property "Focusable"
    /**
    * Getter for property Focusable.<p>
    * Specifies whether or not this component can receive the focus. This
    * property serves as a designable helper for the actually integrated
    * calculated property "FocusTraversable". Even though the default value of
    * this property is true, the actual value of "FocusTraversable" property
    * depends on the integrated visual component. Setting this property to
    * false makes the component "un-focusable".
    * 
    * @see #isFocusTraversable
    * @see #requestFocus
    */
    public boolean isFocusable()
        {
        return __m_Focusable;
        }
    
    /**
    * Brings up a message box specified by the panel name.
    * 
    * @see JFrame#msg
    * @see JDesktopPane#msg
    */
    public Object msg(String sMsgId, Object oMsgPrm)
        {
        // import Component.GUI.Control.Container;
        
        Container parent = (Container) get_Parent();
        _assert(parent != null, "Parentless control " + get_Name());
        
        return parent.msg(sMsgId, oMsgPrm);
        }
    
    public void onFocusGained()
        {
        }
    
    public void onFocusLost()
        {
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import java.awt.dnd.DragSource;
        // import java.awt.dnd.DragGestureListener;
        // import java.awt.dnd.DropTarget;
        // import java.awt.dnd.DropTargetListener;
        
        super.onInit();
        
        if (isDragAllowed())
            {
            // we cannot do this at setDragAllowed(),
            // because of dependence on DragActions property
        
            DragSource source = new DragSource();
            source.createDefaultDragGestureRecognizer(
                (_Control) get_Feed(), getDragActions(), (DragGestureListener) this);
            }
        
        if (isDropAllowed())
            {
            // we cannot do this at setDropAllowed(),
            // because it dependence on DropActions property
        
            DropTarget target = new DropTarget(
                (_Control) get_Feed(), getDropActions(), (DropTargetListener) this, true);
            }
        }
    
    /**
    * The "visual component has been created" method-notification (kind of
    * WM_CREATE event) posted by the topmost heavy weight visual component and
    * that in turn notifies all the children. <p>
    *     This notification gets called after (or at the same time as)  the
    * control [flow] returns back to the instatiator and possibly on a
    * different thread. <p>
    * 
    * NOTE: this notification is not sent to lightweight visual components that
    * are instantiated and added to a container programmatically.
    * 
    * @see Component#onInit
    * @see Component.GUI.Control.Container.Window#onInit
    * @see Component.GUI.Control.Container.Panel.Applet#onInit
    */
    public void onInitUI()
        {
        // import java.util.Enumeration;
        
        for (Enumeration enum = _enumChildren(); enum.hasMoreElements();)
            {
            Component child = ((Component) enum.nextElement());
            if (child instanceof Control)
                {
                ((Control) child).onInitUI();
                }
            }
        }
    
    public void onKeyPressed(char keyChar, int keyCode, int modifiers)
        {
        // import java.awt.Event;
        
        if ((modifiers & Event.CTRL_MASK)  != 0 &&
            (modifiers & Event.SHIFT_MASK) != 0 &&
            keyChar == '?')
            {
            // For debugging purposes only
            _trace("keyPressed (" + keyChar + " " + keyCode + ") @" + get_Name());
            }

        }
    
    public void onKeyReleased(char keyChar, int keyCode, int modifiers)
        {
        }
    
    public void onKeyTyped(char keyChar, int modifiers)
        {
        }
    
    public void onMouseClicked(Point point, int modifiers, int clickCount)
        {
        }
    
    public void onMouseDragged(Point point, int modifiers)
        {
        // import java.awt.Event;
        
        if ((modifiers & Event.CTRL_MASK) != 0 &&
            (modifiers & Event.SHIFT_MASK) != 0)
            {
            // For debugging purposes only
            _trace("mouseDragged (" + point  + ") @" + get_Name());
            }
        }
    
    public void onMouseEntered(Point point, int modifiers)
        {
        }
    
    public void onMouseExited(Point point, int modifiers)
        {
        }
    
    public void onMouseMoved(Point point, int modifiers)
        {
        // import java.awt.Event;
        
        if ((modifiers & Event.CTRL_MASK) != 0 &&
            (modifiers & Event.SHIFT_MASK) != 0)
            {
            // For debugging purposes only
            _trace("mouseMoved (" + point  + ") @" + get_Name());
            }
        }
    
    public void onMousePressed(Point point, int modifiers, int clickCount, boolean popupTrigger)
        {
        if (popupTrigger && getInvokePopup() == INVOKE_ON_PRESSED)
            {
            invokePopup(point);
            }
        }
    
    public void onMouseReleased(Point point, int modifiers, int clickCount, boolean popupTrigger)
        {
        if (popupTrigger && getInvokePopup() == INVOKE_ON_RELEASED)
            {
            invokePopup(point);
            }
        }
    
    /**
    * Method notification specifying that a property with the specified name
    * changed the value.
    */
    public void onPropertyChange(String sName, Object oNewValue, Object oOldValue)
        {
        }
    
    /**
    * Prepares to transfer something at the specified location for the
    * specified action
    * 
    * @return true if transfer is going to be accepted; false otherwise
    * 
    * @see dragOver()
    */
    protected boolean prepareTransferAtLocation(Point point, int iAction, java.util.List listFlavors)
        {
        return false;
        }
    
    /**
    * Puts (drops) the specified Transferable object at the specified location
    * for the specified action
    * 
    * @return true if transfer is accepted; false otherwise
    * 
    * @see drop()
    */
    protected boolean putTransferAtLocation(java.awt.datatransfer.Transferable transfer, Point point, int iAction)
        {
        return false;
        }
    
    /**
    * Repaints this component. <p>
    * This method causes a call to this component's <code>update</code> method
    * as soon as possible.
    */
    public void repaint()
        {
        // we don't want to integrate this method because
        // a) there is so many ways to force the repaint and there is no reason
        //    to intercept this particular call
        // b) if getAWTContainee is overridden it could cause an infinite loop
        //    (see Container.JComponent)
        
        getAWTContainee(false).repaint();
        }
    
    // Accessor for the property "Background"
    /**
    * Setter for property Background.<p>
    */
    public void setBackground(Color pBackground)
        {
        set_Background(pBackground == null ? null : pBackground.get_Color());
        __m_Background = (pBackground);
        }
    
    // Accessor for the property "Bounds"
    /**
    * Setter for property Bounds.<p>
    */
    public void setBounds(Rectangle pBounds)
        {
        set_Bounds(pBounds.get_Rectangle());
        }
    
    // Accessor for the property "Constraints"
    /**
    * Setter for property Constraints.<p>
    */
    public void setConstraints(Constraints pConstraints)
        {
        __m_Constraints = pConstraints;
        }
    
    // Accessor for the property "DnDGlobalDragSource"
    /**
    * Setter for property DnDGlobalDragSource.<p>
    * (Privately used static) Specifies the currently dragged control.
    */
    private static void setDnDGlobalDragSource(Control pDnDGlobalDragSource)
        {
        __s_DnDGlobalDragSource = pDnDGlobalDragSource;
        }
    
    // Accessor for the property "DnDGlobalDropTarget"
    /**
    * Setter for property DnDGlobalDropTarget.<p>
    * (Privately used static) Specifies the currently dropped onto control.
    */
    private static void setDnDGlobalDropTarget(Control pDnDGlobalDropTarget)
        {
        __s_DnDGlobalDropTarget = pDnDGlobalDropTarget;
        }
    
    // Accessor for the property "DragActions"
    /**
    * Setter for property DragActions.<p>
    * Represents allowed Drag actions for this component. The values are:
    * ACTION_NONE = 0x0
    * ACTION_COPY = 0x1
    * ACTION_MOVE = 0x2
    * ACTION_COPY_OR_MOVE = ACTION_COPY | ACTION_MOVE
    * 
    * @see java.awt.dnd.DnDConstants
    */
    public void setDragActions(int pDragActions)
        {
        __m_DragActions = pDragActions;
        }
    
    // Accessor for the property "DragAllowed"
    /**
    * Setter for property DragAllowed.<p>
    * Specifies whether this component allows "Dragging" from (i.e. being a
    * DragSource)
    */
    public void setDragAllowed(boolean pDragAllowed)
        {
        __m_DragAllowed = pDragAllowed;
        }
    
    // Accessor for the property "DropActions"
    /**
    * Setter for property DropActions.<p>
    * Represents allowed Drop actions for this component. The values are:
    * ACTION_NONE = 0x0
    * ACTION_COPY = 0x1
    * ACTION_MOVE = 0x2
    * ACTION_COPY_OR_MOVE = ACTION_COPY | ACTION_MOVE
    * 
    * @see java.awt.dnd.DnDConstants
    */
    public void setDropActions(int pDropActions)
        {
        __m_DropActions = pDropActions;
        }
    
    // Accessor for the property "DropAllowed"
    /**
    * Setter for property DropAllowed.<p>
    * Specifies whether this component allows "Dropping" into (i.e. being a
    * DropTarget)
    */
    public void setDropAllowed(boolean pDropAllowed)
        {
        __m_DropAllowed = pDropAllowed;
        }
    
    // Accessor for the property "Focusable"
    /**
    * Setter for property Focusable.<p>
    * Specifies whether or not this component can receive the focus. This
    * property serves as a designable helper for the actually integrated
    * calculated property "FocusTraversable". Even though the default value of
    * this property is true, the actual value of "FocusTraversable" property
    * depends on the integrated visual component. Setting this property to
    * false makes the component "un-focusable".
    * 
    * @see #isFocusTraversable
    * @see #requestFocus
    */
    public void setFocusable(boolean pFocusable)
        {
        __m_Focusable = pFocusable;
        }
    
    // Accessor for the property "Font"
    /**
    * Setter for property Font.<p>
    */
    public void setFont(Font pFont)
        {
        set_Font(pFont == null ? null : pFont.get_Font());
        __m_Font = (pFont);
        }
    
    // Accessor for the property "Foreground"
    /**
    * Setter for property Foreground.<p>
    */
    public void setForeground(Color pForeground)
        {
        set_Foreground(pForeground == null ? null : pForeground.get_Color());
        __m_Foreground = (pForeground);

        }
    
    // Accessor for the property "InvokePopup"
    /**
    * Setter for property InvokePopup.<p>
    * Specifies whether a popup [menu] should be invoked when the
    * "popupTrigger" button is pressed or released.
    * 
    * Valid values are:
    * INVOKE_NONE (0) -- Don't invoke
    * INVOKE_ON_PRESSED (1) -- Invoke when mouse pressed
    * INVOKE_ON_RELEASED (2) -- Invoke when mouse released
    * 
    * @see onMousePressed
    * @see onMouseReleased
    */
    public void setInvokePopup(int pInvokePopup)
        {
        __m_InvokePopup = pInvokePopup;
        }
    
    // Accessor for the property "Location"
    /**
    * Setter for property Location.<p>
    */
    public void setLocation(Point pLocation)
        {
        set_Location(pLocation.get_Point());

        }
    
    // Accessor for the property "Size"
    /**
    * Setter for property Size.<p>
    */
    public void setSize(Dimension pSize)
        {
        set_Size(pSize.get_Dimension());

        }
    
    // Accessor for the property "TBounds"
    /**
    * Setter for property TBounds.<p>
    */
    public void setTBounds(String pTBounds)
        {
        String s = pTBounds;
        try
            {
            int iStart = 0;
            int[] crds = new int[4];
            for (int i = 0; i < 4; i++)
                {
                int iEnd;
                iEnd = (i == 3) ? s.length() : s.indexOf(',', iStart);
                crds[i] = Integer.parseInt(s.substring(iStart, iEnd));
                iStart = iEnd + 1;
                }
            Rectangle rect = Rectangle.instantiate(crds[0],crds[1],crds[2],crds[3]);
            setBounds(rect);
            }
        catch (Exception e)
            {
            _trace(get_Name() + ": Invalid TBounds: " + e, 1);
            }
        }
    
    // Accessor for the property "TConstraints"
    /**
    * Setter for property TConstraints.<p>
    */
    public void setTConstraints(String pTConstraints)
        {
        // import Component.GUI.Constraints;
        
        if (pTConstraints == null)
            {
            return;
            }
        
        Constraints constraints = null;
        
        if (pTConstraints.startsWith("Anchor"))
            {
            constraints = (Constraints.AnchorConstraints) _newInstance("Component.GUI.Constraints.AnchorConstraints." + pTConstraints);
            }
        else
            {
            constraints = (Constraints.NamedConstraints) _newInstance("Component.GUI.Constraints.NamedConstraints." + pTConstraints);
            }
        
        if (constraints == null)
            {
            constraints = new Constraints.NamedConstraints();
            ((Constraints.NamedConstraints) constraints).setName(pTConstraints);
            }
        setConstraints(constraints);

        }
    
    // Accessor for the property "TFont"
    /**
    * Setter for property TFont.<p>
    */
    public void setTFont(String pTFont)
        {
        // import Component.GUI.Font;
        
        String s = pTFont;
        try
            {
            Font f;
            
            int of1 = s.indexOf(',');
            if (of1 >= 0)
                {
                // Syntax ::= <FontName>,<Style>,<Size>
                f = new Font();
                f.setName(s.substring(0, of1));
        
                int of2 = s.indexOf(',', ++of1);
        
                f.setStyle(Integer.parseInt(s.substring(of1, of2)));
                f.setSize(Integer.parseInt(s.substring(++of2)));
                }
            else
                {
                // Syntax ::= <CompName>[-<Style>-<Size>]
                of1 = s.indexOf('-');
                
                String sFont = of1 < 0 ? s : s.substring(0, of1);
                f = (Font) _newInstance("Component.GUI.Font." + sFont);
                if (f == null)
                    {
                    throw new ClassNotFoundException();
                    }
        
                if (of1 > 0)
                    {
                    int of2 = s.indexOf('-', ++of1);
        
                    f.setStyle(Integer.parseInt(s.substring(of1, of2)));
                    f.setSize(Integer.parseInt(s.substring(++of2)));
                    }
                }
        
            setFont(f);
            }
        catch (Exception e)
            {
            _trace("Invalid TFont: " + pTFont, 1);
            }
        }
    }
