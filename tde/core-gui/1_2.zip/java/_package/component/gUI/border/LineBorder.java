/* Class
*     _package.component.gUI.border.LineBorder
*/

package _package.component.gUI.border;

import _package.component.gUI.Color;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class LineBorder
        extends    _package.component.gUI.Border
    {
    // Fields declarations
    
    /**
    * Property Color
    *
    */
    private _package.component.gUI.Color __m_Color;
    
    /**
    * Property Thickness
    *
    */
    private int __m_Thickness;
    
    // Default constructor
    public LineBorder()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public LineBorder(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setThickness(1);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new LineBorder();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/border/LineBorder".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public javax.swing.border.Border get_Border()
        {
        // import Component.GUI.Color;
        // import javax.swing.border.Border;
        // import javax.swing.border.LineBorder;
        
        Border _border = super.get_Border();
        if (_border == null)
            {
            Color color = getColor();
            if (color == null)
                {
                color = new Color.Black();
                }
            
            _border = new LineBorder(color.get_Color(), getThickness());
            set_Border(_border);
            }
        return _border;
        }
    
    // Accessor for the property "Color"
    public _package.component.gUI.Color getColor()
        {
        return __m_Color;
        }
    
    // Accessor for the property "Thickness"
    public int getThickness()
        {
        return __m_Thickness;
        }
    
    // Accessor for the property "Color"
    public void setColor(_package.component.gUI.Color pColor)
        {
        __m_Color = (pColor);
        set_Border(null);
        }
    
    // Accessor for the property "Thickness"
    public void setThickness(int pThickness)
        {
        __m_Thickness = (pThickness);
        set_Border(null);
        }
    }
