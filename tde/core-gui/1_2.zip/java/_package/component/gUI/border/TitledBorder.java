/* Class
*     _package.component.gUI.border.TitledBorder
*/

package _package.component.gUI.border;

import _package.component.gUI.Color;
import _package.component.gUI.Font;
import javax.swing.border.Border; // as _Border
import javax.swing.border.TitledBorder; // as _TitledBorder

/*
* Integrates
*     javax.swing.border.TitledBorder
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class TitledBorder
        extends    _package.component.gUI.Border
    {
    // Fields declarations
    
    /**
    * Property ABOVE_BOTTOM
    *
    */
    public static final int ABOVE_BOTTOM = 4; // javax.swing.border.TitledBorder.ABOVE_BOTTOM;
    
    /**
    * Property ABOVE_TOP
    *
    */
    public static final int ABOVE_TOP = 1; // javax.swing.border.TitledBorder.ABOVE_TOP;
    
    /**
    * Property BELOW_BOTTOM
    *
    */
    public static final int BELOW_BOTTOM = 6; // javax.swing.border.TitledBorder.BELOW_BOTTOM;
    
    /**
    * Property BELOW_TOP
    *
    */
    public static final int BELOW_TOP = 3; // javax.swing.border.TitledBorder.BELOW_TOP;
    
    /**
    * Property Border
    *
    */
    private _package.component.gUI.Border __m_Border;
    
    /**
    * Property BOTTOM
    *
    */
    public static final int BOTTOM = 5; // javax.swing.border.TitledBorder.BOTTOM;
    
    /**
    * Property CENTER
    *
    */
    public static final int CENTER = 2; // javax.swing.border.TitledBorder.CENTER;
    
    /**
    * Property DEFAULT_JUSTIFICATION
    *
    */
    public static final int DEFAULT_JUSTIFICATION = 0; // javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION;
    
    /**
    * Property DEFAULT_POSITION
    *
    */
    public static final int DEFAULT_POSITION = 0; // javax.swing.border.TitledBorder.DEFAULT_POSITION;
    
    /**
    * Property LEFT
    *
    */
    public static final int LEFT = 1; // javax.swing.border.TitledBorder.LEFT;
    
    /**
    * Property RIGHT
    *
    */
    public static final int RIGHT = 3; // javax.swing.border.TitledBorder.RIGHT;
    
    /**
    * Property Title
    *
    */
    private String __m_Title;
    
    /**
    * Property TitleColor
    *
    */
    private _package.component.gUI.Color __m_TitleColor;
    
    /**
    * Property TitleFont
    *
    */
    private _package.component.gUI.Font __m_TitleFont;
    
    /**
    * Property TitleJustification
    *
    */
    private int __m_TitleJustification;
    
    /**
    * Property TitlePosition
    *
    */
    private int __m_TitlePosition;
    
    /**
    * Property TOP
    *
    */
    public static final int TOP = 2; // javax.swing.border.TitledBorder.TOP;
    
    // Default constructor
    public TitledBorder()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TitledBorder(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setTitle("");
            setTitleJustification(1);
            setTitlePosition(2);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new TitledBorder();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/border/TitledBorder".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.border.TitledBorder integration
    // Access optimization
    // properties integration
    // methods integration
    public String getTitle()
        {
        return ((javax.swing.border.TitledBorder) get_Border()).getTitle();
        }
    public int getTitleJustification()
        {
        return ((javax.swing.border.TitledBorder) get_Border()).getTitleJustification();
        }
    public int getTitlePosition()
        {
        return ((javax.swing.border.TitledBorder) get_Border()).getTitlePosition();
        }
    public void setTitle(String pTitle)
        {
        ((javax.swing.border.TitledBorder) get_Border()).setTitle(pTitle);
        }
    public void setTitleJustification(int pTitleJustification)
        {
        ((javax.swing.border.TitledBorder) get_Border()).setTitleJustification(pTitleJustification);
        }
    public void setTitlePosition(int pTitlePosition)
        {
        ((javax.swing.border.TitledBorder) get_Border()).setTitlePosition(pTitlePosition);
        }
    //-- javax.swing.border.TitledBorder integration
    
    // Declared at the super level
    public javax.swing.border.Border get_Border()
        {
        // import javax.swing.border.Border as _Border;
        // import javax.swing.border.TitledBorder as _TitledBorder;
        
        _Border _titledBorder = (_Border) super.get_Border();
        if (_titledBorder == null)
            {
            _Border _border = getBorder() == null ? null : getBorder().get_Border();
        
            set_Border(_titledBorder = new _TitledBorder(_border));
            }
        return _titledBorder;
        }
    
    // Accessor for the property "Border"
    public _package.component.gUI.Border getBorder()
        {
        return __m_Border;
        }
    
    // Accessor for the property "TitleColor"
    public _package.component.gUI.Color getTitleColor()
        {
        // import Component.GUI.Color;
        // import javax.swing.border.TitledBorder as _TitledBorder;
        
        Color color = __m_TitleColor;
        if (color == null)
            {
            color = new Color();
            color.set_Color(((_TitledBorder) get_Border()).getTitleColor());
            }
        return color;
        }
    
    // Accessor for the property "TitleFont"
    public _package.component.gUI.Font getTitleFont()
        {
        // import Component.GUI.Font;
        // import javax.swing.border.TitledBorder as _TitledBorder;
        
        Font font = __m_TitleFont;
        if (font == null)
            {
            font = new Font();
            font.set_Font(((_TitledBorder) get_Border()).getTitleFont());
            }
        return font;
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // TO DO: remove after the composite properties are implemented
        super.onInit();
        setBorder(new Component.GUI.Border.EtchedSimple());
        }
    
    // Accessor for the property "Border"
    public void setBorder(_package.component.gUI.Border pBorder)
        {
        __m_Border = pBorder;
        }
    
    // Accessor for the property "TitleColor"
    public void setTitleColor(_package.component.gUI.Color pColor)
        {
        __m_TitleColor = pColor;
        }
    
    // Accessor for the property "TitleFont"
    public void setTitleFont(_package.component.gUI.Font pFont)
        {
        __m_TitleFont = pFont;
        }
    }
