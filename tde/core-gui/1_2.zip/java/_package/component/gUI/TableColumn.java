/* Class
*     _package.component.gUI.TableColumn
*/

package _package.component.gUI;

import _package.component.gUI.control.container.jComponent.JComboBox;
import _package.component.gUI.control.container.jComponent.JTable;
import _package.component.gUI.renderer.icon.Choice;
import java.awt.Component;
import java.text.CollationKey;
import java.text.Collator;
import java.util.Enumeration;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox; // as _JComboBox
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTable; // as _JTable
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

/*
* Integrates
*     javax.swing.table.TableColumn
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class TableColumn
        extends    _package.component.GUI
    {
    // Fields declarations
    
    /**
    * Property _CellEditor
    *
    * Cell editor for this column.
    */
    private transient javax.swing.table.TableCellEditor __m__CellEditor;
    
    /**
    * Property _CellRenderer
    *
    * Cell renderer for this column.
    */
    private transient javax.swing.table.TableCellRenderer __m__CellRenderer;
    
    /**
    * Property _HeaderRenderer
    *
    * Header renderer for this column.
    */
    private transient javax.swing.table.TableCellRenderer __m__HeaderRenderer;
    
    /**
    * Property CaseSensitive
    *
    * Specifies whether the sorting should be case sensitive (assuming there is
    * no specified Collator).
    */
    private boolean __m_CaseSensitive;
    
    /**
    * Property CellHorizontalAlignment
    *
    * This property specifies the the alignment of the cells' content along the
    * X axis. A corresponding CellRenderer and CellEditor should use this
    * property to align cells content.
    * 
    * The valid values are (see javax.swing.SwingConstants):
    * CENTER = 0
    * LEFT = 2
    * RIGHT = 4
    */
    private int __m_CellHorizontalAlignment;
    
    /**
    * Property Choice
    *
    * This property specifies whether the appropriate CellRender should
    * indicate the fact that there is a selection of items to choose from and
    * the CellEditor should somehow show the selection set.
    */
    private boolean __m_Choice;
    
    /**
    * Property ChoiceEditable
    *
    * This property specifies whether the choice Editor should allow an
    * arbitrary input or limit the selection to the list of choices specifed by
    * ChoiceList property.
    * 
    * @see #instantiate_Editor
    */
    private boolean __m_ChoiceEditable;
    
    /**
    * Property ChoiceIcon
    *
    * Icon to place on the renderer if Choice property is set.
    */
    private transient javax.swing.Icon __m_ChoiceIcon;
    
    /**
    * Property ChoiceList
    *
    * This property holds on a [default] list of items that a CellEditor should
    * present to a user to choose from. Since the type of this property is
    * Object[] it is not designable, use the ChoiceStrings property which is a
    * simple wrapper around ChoiceList. 
    * 
    * @see #instantiate_Editor
    */
    private Object[] __m_ChoiceList;
    
    /**
    * Property ChoiceStrings
    *
    * This functional property represents a <b>designable</b> list of strings
    * that a CellEditor should present to a user to choose from in case the
    * column data type is String and the Choice property is set to  true.
    * 
    * This property is a simple wrapper around the ChoiceList property.
    * 
    * Sub-components (i.e. IntegerColumn) have to override the setter for this
    * property to convert the values into  appropriate data type.
    * 
    * @see #ChoiceList property
    */
    
    /**
    * Property Collator
    *
    * Collator used to sort the items in this column. If not specified, the
    * default string comparison (String.compareTo()) is used.
    * 
    * @see #narrowInsertionRange
    */
    private java.text.Collator __m_Collator;
    
    /**
    * Property DefaultValue
    *
    * This is a convinience [calculated] property that could be used by some
    * generic implementations (like TcTable)  to allow adding an empty row of
    * data.
    * 
    * @see JTable.getDefaultRowValue()
    */
    
    /**
    * Property Editable
    *
    */
    private boolean __m_Editable;
    
    /**
    * Property HeaderValue
    *
    * Specifies an <B>Object</B> used as the value for the header renderer.
    */
    private transient Object __m_HeaderValue;
    
    /**
    * Property HorizontalAlignment
    *
    * This property specifies the the alignment of the column's header along
    * the X axis. A corresponding HeaderRenderer should use this property to
    * align header's content.
    * 
    * The valid values are (see javax.swing.SwingConstants):
    * CENTER = 0
    * LEFT = 2
    * RIGHT = 4
    */
    private int __m_HorizontalAlignment;
    
    /**
    * Property Identifier
    *
    * Specifies the <B>TableColumn</B>'s identifier. Note that identifiers are
    * not used by the JTable, they are purely a convenience for the external
    * tagging and location of columns.
    */
    private transient Object __m_Identifier;
    
    /**
    * Property Index
    *
    * Specifies an index of this column in the ColumnModel (view).
    * This value is used for Columns that are created dynamically at run time
    * and should not be used for designed columns. Designed columns use the
    * _Order property to "order" the columns.
    * 
    * @see JTable#_addChild
    * @see JTable#insertColumn
    */
    private transient int __m_Index;
    
    /**
    * Property MaxWidth
    *
    * Specifies the maximum width for the <B>TableColumn</B>. The
    * <B>TableColumn's</B> width can't be made larger than this either by the
    * user or programmatically.  The default MaxWidth is 2000.
    */
    private transient int __m_MaxWidth;
    
    /**
    * Property MinWidth
    *
    * Specifies the minimum width for the <B>TableColumn</B>. The
    * <B>TableColumn's</B> width can't be made less than this either by the
    * user or programmatically.  The default MinWidth is 15.
    */
    private transient int __m_MinWidth;
    
    /**
    * Property ModelIndex
    *
    * The index of the column in the model which is to be displayed by this
    * TableColumn. As columns are moved around in the view the model index
    * remains constant.
    */
    private transient int __m_ModelIndex;
    
    /**
    * Property Name
    *
    */
    
    /**
    * Property PreferredWidth
    *
    * Specifies this column's preferred width. Setting this property sets this
    * column's preferred width to a new width.  If <I>PreferredWidth</I>
    * exceeds the minimum or maximum width, it's adjusted to the appropriate
    * limiting value.
    */
    private transient int __m_PreferredWidth;
    
    /**
    * Property Resizable
    *
    * Specifies whether or not the user is allowed to resize the
    * <B>TableColumn</B> width. You can change the width programmatically
    * regardless of this setting.  The default is true.
    */
    private transient boolean __m_Resizable;
    
    /**
    * Property Sorted
    *
    * Specifies whether the column is sorted. If set to true and the table
    * itself is sorted then a newly added row will be placed accordingly.
    * 
    * @see #narrowInsertionRange
    * @see JTable#Sorted
    * @see JTable#addRow
    */
    private boolean __m_Sorted;
    
    /**
    * Property Table
    *
    */
    
    /**
    * Property Title
    *
    */
    private transient String __m_Title;
    
    /**
    * Property Width
    *
    * This property specifies the width of the column (in pixels). It should
    * not be used to set the widths of columns in the JTable - use
    * PreferredWidth instead. Like a layout manager in the AWT, the JTable
    * adjusts a column's width automatically whenever the  table itself changes
    * size, or a column's preferred width is changed.  Setting widths
    * programmatically therefore has no long term effect.
    * Setting this property sets this column's width to a new width.  If  the
    * new width exceeds the minimum or maximum width, it's adjusted to the
    * appropriate limiting value.
    */
    private transient int __m_Width;
    
    // fields used by the integration model:
    private sink_TableColumn __sink;
    private javax.swing.table.TableColumn __feed;
    
    // Default constructor
    public TableColumn()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TableColumn(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setCellHorizontalAlignment(2);
            setHorizontalAlignment(0);
            setIndex(-1);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_TableColumn.__tloPeer.setObject(this);
            new jb_TableColumn(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new TableColumn();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/TableColumn".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ javax.swing.table.TableColumn integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_TableColumn) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = (javax.swing.table.TableColumn) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    private javax.swing.table.TableCellEditor get_CellEditor$Router()
        {
        return __sink.getCellEditor();
        }
    public javax.swing.table.TableCellEditor get_CellEditor()
        {
        // import java.awt.Component;
        // import javax.swing.DefaultCellEditor;
        // import javax.swing.JComponent;
        // import javax.swing.JTextField;
        // import javax.swing.table.TableCellEditor;
        
        TableCellEditor _editor = get_CellEditor$Router();
        
        if (_editor == null)
            {
            set_CellEditor(_editor = instantiate_Editor());
            }
        
        if (_editor instanceof DefaultCellEditor)
            {
            Component _editorComponent = ((DefaultCellEditor) _editor).getComponent();
            if (_editorComponent instanceof JTextField)
                {
                ((JTextField) _editorComponent).
                    setHorizontalAlignment(getCellHorizontalAlignment());
                }
            }
        
        return _editor;
        }
    private javax.swing.table.TableCellRenderer get_CellRenderer$Router()
        {
        return __sink.getCellRenderer();
        }
    public javax.swing.table.TableCellRenderer get_CellRenderer()
        {
        // import javax.swing.JLabel;
        // import javax.swing.table.DefaultTableCellRenderer;
        // import javax.swing.table.TableCellRenderer;
        
        TableCellRenderer _renderer = get_CellRenderer$Router();
        
        if (_renderer == null)
            {
            set_CellRenderer(_renderer = instantiate_Renderer());
            }
        
        if (_renderer instanceof JLabel) // DefaultTableCellRenderer
            {
            JLabel _label = (JLabel) _renderer;
            _label.setHorizontalAlignment(getCellHorizontalAlignment());
            _label.setHorizontalTextPosition(DefaultTableCellRenderer.LEFT);
            _label.setIcon(isChoice() ? getChoiceIcon() : null);
            }
        
        return _renderer;
        }
    public javax.swing.table.TableCellRenderer get_HeaderRenderer()
        {
        return __sink.getHeaderRenderer();
        }
    public Object getHeaderValue()
        {
        return __sink.getHeaderValue();
        }
    public Object getIdentifier()
        {
        return __sink.getIdentifier();
        }
    public int getMaxWidth()
        {
        return __sink.getMaxWidth();
        }
    public int getMinWidth()
        {
        return __sink.getMinWidth();
        }
    public int getModelIndex()
        {
        return __sink.getModelIndex();
        }
    public int getPreferredWidth()
        {
        return __sink.getPreferredWidth();
        }
    public boolean isResizable()
        {
        return __sink.getResizable();
        }
    public int getWidth()
        {
        return __sink.getWidth();
        }
    public void set_CellEditor(javax.swing.table.TableCellEditor p_CellEditor)
        {
        __sink.setCellEditor(p_CellEditor);
        }
    public void set_CellRenderer(javax.swing.table.TableCellRenderer p_CellRenderer)
        {
        __sink.setCellRenderer(p_CellRenderer);
        }
    public void set_HeaderRenderer(javax.swing.table.TableCellRenderer p_HeaderRenderer)
        {
        __sink.setHeaderRenderer(p_HeaderRenderer);
        }
    public void setHeaderValue(Object pHeaderValue)
        {
        __sink.setHeaderValue(pHeaderValue);
        }
    public void setIdentifier(Object pIdentifier)
        {
        __sink.setIdentifier(pIdentifier);
        }
    public void setMaxWidth(int pMaxWidth)
        {
        __sink.setMaxWidth(pMaxWidth);
        }
    public void setMinWidth(int pMinWidth)
        {
        __sink.setMinWidth(pMinWidth);
        }
    public void setModelIndex(int pModelIndex)
        {
        __sink.setModelIndex(pModelIndex);
        }
    public void setPreferredWidth(int pPreferredWidth)
        {
        __sink.setPreferredWidth(pPreferredWidth);
        }
    public void setResizable(boolean pResizable)
        {
        __sink.setResizable(pResizable);
        }
    private void setWidth$Router(int pWidth)
        {
        __sink.setWidth(pWidth);
        }
    /**
    * This methods, sets this column's width to <I>pWidth</I>.  If
    * <I>pWidth</I> exceeds the minimum or maximum width, it's adjusted to the
    * appropriate limiting value. 
    * 
    * @see property #Width
    * @see proeprty #PreferredWidth
    */
    public void setWidth(int pWidth)
        {
        setWidth$Router(pWidth);
        
        if (!is_Constructed() && getPreferredWidth() == 0)
            {
            setPreferredWidth(pWidth);
            }

        }
    /**
    * Resizes the <B>TableColumn</B> to fit the width of its header cell. If
    * the maximum width is less than the width of the header, the maximum is
    * increased to the header's width. Similarly, if the minimum width is
    * greater than the width of the header, the minimum is reduced to the
    * header's width.
    * 
    * @see property #PreferredWidth
    */
    public void sizeWidthToFit()
        {
        __sink.sizeWidthToFit();
        }
    //-- javax.swing.table.TableColumn integration
    
    // Declared at the super level
    public void _imports()
        {
        // import Component.GUI.Control.Container.JComponent.JTable;
        // import javax.swing.JTable as _JTable;

        }
    
    // Declared at the super level
    /**
    * Apply configuration information about this component from the specified
    * property table using the specified string to prefix the property names.
    * 
    * For example, to retrieve a value of Enabled property it's recommended to
    * write:
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    * or
    *     boolean fEnabled = config.getBoolean(sPrefix + ".Enabled",
    * isEnabled());
    * or
    *     if (config.containsKey(sPrefix + ".Enabled"))
    *         {
    *         boolean fEnabled = config.getBoolean(sPrefix + ".Enabled");
    *         }
    * 
    * Note: this method's access is declared as protected at the root Component
    * level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the access to
    * public.
    * 
    * @param config  a Config component used to retrieve the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #saveConfig
    * @see Component.Util.Config
    */
    public void applyConfig(_package.component.util.Config config, String sPrefix)
        {
        int iWidth = config.getInt(sPrefix + ".Width", -1);
        if (iWidth != -1)
            {
            setWidth(iWidth);
            }
        
        super.applyConfig(config, sPrefix);
        }
    
    /**
    * Return a row number for a cell that is "equal" to the specified item;
    * returns -1 if the item is not found.
    */
    public int findItem(Object item)
        {
        JTable table = getTable();
        int    iCol = getModelIndex();
        
        int cRows = table.getRowCount();
        for (int iRow = 0; iRow < cRows; iRow++)
            {
            if (table.getValueAt(iRow, iCol).equals(item))
                {
                return iRow;
                }
            }
        return table.ITEM_NOT_FOUND;
        }
    
    /**
    * This method is called by the JTable.setValueAt() to give the TableColumn 
    * component a chance to validate and format the incoming value. Returning
    * null will discard the change.
    * 
    * Default implementation returns the passed in value without any changes
    * 
    * @param oValue  a new value that is about to be set for row number iRow at
    * this column
    * @param iRow  the row number for the new value
    * 
    * @return a formatted value or null to discard the change
    */
    public Object format(Object oValue, int iRow)
        {
        return oValue;
        }
    
    // Accessor for the property "CellHorizontalAlignment"
    public int getCellHorizontalAlignment()
        {
        return __m_CellHorizontalAlignment;
        }
    
    // Accessor for the property "ChoiceIcon"
    public javax.swing.Icon getChoiceIcon()
        {
        // import Component.GUI.Renderer.Icon.Choice;
        
        javax.swing.Icon icon = __m_ChoiceIcon;
        if (icon == null)
            {
            icon = (Choice) Choice.get_Instance();
            setChoiceIcon(icon);
            }
        return icon;

        }
    
    // Accessor for the property "ChoiceList"
    public Object[] getChoiceList()
        {
        return __m_ChoiceList;
        }
    
    // Accessor for the property "Collator"
    public java.text.Collator getCollator()
        {
        return __m_Collator;
        }
    
    // Accessor for the property "DefaultValue"
    /**
    * This is an accessor that could be used by some generic implementations
    * (like TcTable)  to allow adding an empty row of data. For consistency teh
    * default implementation returns am empty string instead of null which
    * would be shown as an empty string by the default renderer and converted
    * by the default editor anyway (see
    * javax.swing.DefaultTableCellRenderer#setValue()), but would cause
    */
    public Object getDefaultValue()
        {
        return "";
        }
    
    // Accessor for the property "HorizontalAlignment"
    public int getHorizontalAlignment()
        {
        return __m_HorizontalAlignment;
        }
    
    // Accessor for the property "Index"
    public int getIndex()
        {
        JTable table = getTable();
        if (table == null)
            {
            // column is not added to a table yet
            return __m_Index;
            }
        
        javax.swing.table.TableColumnModel _cm = table.get_ColumnModel();
        int cCols = _cm.getColumnCount();
        
        for (int iCol = 0; iCol < cCols; iCol++)
            {
            if (_cm.getColumn(iCol) == get_Feed())
                {
                return iCol;
                }
            }
        
        throw new IllegalStateException("Column not found in the ColumnModel " + this);
        }
    
    // Accessor for the property "Name"
    public String getName()
        {
        Object oID = getIdentifier();
        return oID != null ? oID.toString() : null;
        }
    
    // Accessor for the property "Table"
    public _package.component.gUI.control.container.jComponent.JTable getTable()
        {
        return (JTable) get_Parent();
        }
    
    // Accessor for the property "Title"
    public String getTitle()
        {
        Object oVal = getHeaderValue();
        return oVal != null ? oVal.toString() : null;
        

        }
    
    /**
    * Create a cell editor for this column. This method is intended to be
    * overriden by the TableColumn's subclasses.
    */
    protected javax.swing.table.TableCellEditor instantiate_Editor()
        {
        // import Component.GUI.Control.Container.JComponent.JComboBox;
        // import javax.swing.JComboBox as _JComboBox;
        // import javax.swing.DefaultCellEditor;
        
        if (isChoice())
            {
            JComboBox combo = new JComboBox();
            combo.setEditable(isChoiceEditable());
            combo.setItems(getChoiceList());
            return new DefaultCellEditor((_JComboBox) combo.get_Feed());
            }
        else
            {
            return ((_JTable) getTable().get_Feed()).
                getDefaultEditor(Object.class);
            }
        }
    
    /**
    * Create a cell renderer for this column. This method is intended to be
    * overriden by the TableColumn's subclasses.
    */
    protected javax.swing.table.TableCellRenderer instantiate_Renderer()
        {
        return ((_JTable) getTable().get_Feed()).
            getDefaultRenderer(Object.class);
        }
    
    // Accessor for the property "CaseSensitive"
    public boolean isCaseSensitive()
        {
        return __m_CaseSensitive;
        }
    
    // Accessor for the property "Choice"
    public boolean isChoice()
        {
        return __m_Choice;
        }
    
    // Accessor for the property "ChoiceEditable"
    public boolean isChoiceEditable()
        {
        return __m_ChoiceEditable;
        }
    
    // Accessor for the property "Editable"
    public boolean isEditable()
        {
        return __m_Editable;
        }
    
    // Accessor for the property "Sorted"
    public boolean isSorted()
        {
        return __m_Sorted;
        }
    
    /**
    * Narrows the insertion range for the specified item by modifying the
    * specified array of two integers, where:
    *     [0] - first possible insertion position
    *     [1] - last  possible insertion position
    */
    public void narrowInsertionRange(Object item, int[] range)
        {
        // import java.text.Collator;
        // import java.text.CollationKey;
        
        JTable table = getTable();
        int    iCol  = getModelIndex();
        
        if (isSorted())
            {
            boolean  ignoreCase = !isCaseSensitive();
            String   sItem      = item.toString();
            Collator collator   = getCollator();
            CollationKey ckItem = null;
        
            if (collator != null)
                {
                ckItem = collator.getCollationKey(sItem);
                }
            else
                {
                if (ignoreCase)
                    {
                    sItem = sItem.toUpperCase();
                    }
                }
        
            for (int iRow = range[0]; iRow < range[1]; iRow++)
                {
                String s = table.getValueAt(iRow, iCol).toString();
        
                int iCompare;
                if (collator != null)
                    {
                    iCompare = collator.getCollationKey(s).compareTo(ckItem);
                    }
                else
                    {
                    if (ignoreCase)
                        {
                        s = s.toUpperCase();
                        }
                    iCompare = s.compareTo(sItem);
                    }
        
                if (iCompare < 0)
                    {
                    range[0] = iRow + 1;
                    continue;
                    }
                else if (iCompare > 0)
                    {
                    range[1] = iRow;
                    break;
                    }
                }
            }
        }
    
    // Declared at the super level
    /**
    * Save configuration information about this component into the specified
    * Config component using the specified string to prefix the property names.
    * 
    * For example, to store values of Enabled and Text properties it's
    * recommended to write:
    *     config.putBoolean(sPrefix + ".Enabled", isEnabled());
    *     config.putString(sPrefix + ".Text", getText());
    * 
    * Note: this method's access is declared as "advanced" at the root
    * Component level. Any component that wants to expose the "configurable"
    * functionality should implement this method and/or change the "visibility"
    * to public.
    * 
    * @param config  a Config component used to store the configuration info
    * for this component
    * @param sPrefix  a prefix used by this component for properties
    * identification
    * 
    * @see #applyConfig
    * @see Component.Util.Config
    */
    public void saveConfig(_package.component.util.Config config, String sPrefix)
        {
        config.putInt(sPrefix + ".Width", getWidth());
        
        super.saveConfig(config, sPrefix);
        }
    
    // Accessor for the property "CaseSensitive"
    public void setCaseSensitive(boolean pCaseSensitive)
        {
        __m_CaseSensitive = pCaseSensitive;
        }
    
    // Accessor for the property "CellHorizontalAlignment"
    public void setCellHorizontalAlignment(int pCellHorizontalAlignment)
        {
        __m_CellHorizontalAlignment = pCellHorizontalAlignment;
        }
    
    // Accessor for the property "Choice"
    public void setChoice(boolean pChoice)
        {
        __m_Choice = pChoice;
        }
    
    // Accessor for the property "ChoiceEditable"
    public void setChoiceEditable(boolean pChoiceEditable)
        {
        __m_ChoiceEditable = pChoiceEditable;
        }
    
    // Accessor for the property "ChoiceIcon"
    public void setChoiceIcon(javax.swing.Icon pChoiceIcon)
        {
        __m_ChoiceIcon = pChoiceIcon;
        }
    
    // Accessor for the property "ChoiceList"
    public void setChoiceList(Object[] pChoiceList)
        {
        __m_ChoiceList = pChoiceList;
        }
    
    // Accessor for the property "ChoiceStrings"
    public void setChoiceStrings(String[] pChoiceStrings)
        {
        setChoiceList(pChoiceStrings);
        }
    
    // Accessor for the property "Collator"
    public void setCollator(java.text.Collator pCollator)
        {
        __m_Collator = pCollator;
        }
    
    // Accessor for the property "Editable"
    public void setEditable(boolean pEditable)
        {
        __m_Editable = pEditable;
        }
    
    // Accessor for the property "HorizontalAlignment"
    public void setHorizontalAlignment(int pHorizontalAlignment)
        {
        // import javax.swing.JLabel;
        // import javax.swing.table.TableCellRenderer;
        
        __m_HorizontalAlignment = (pHorizontalAlignment);
        
        TableCellRenderer _renderer = get_HeaderRenderer();
        if (_renderer instanceof JLabel)
            {
            ((JLabel) _renderer).setHorizontalAlignment(pHorizontalAlignment);
            }
        }
    
    // Accessor for the property "Index"
    public void setIndex(int pIndex)
        {
        JTable table = getTable();
        if (!is_Constructed() || table == null)
            {
            // column is not added to a table yet
            __m_Index = (pIndex);
            }
        else
            {
            int indexOld = getIndex();
            table.moveColumn(indexOld, pIndex);
            }
        }
    
    // Accessor for the property "Sorted"
    public void setSorted(boolean pSorted)
        {
        // import java.util.Enumeration;
        
        if (pSorted == isSorted())
            {
            return;
            }
        
        __m_Sorted = (pSorted);
        
        JTable table = getTable();
        if (table != null)
            {
            if (pSorted)
                {
                // this column became sorted -- mark the table as sorted
                table.setSorted(true);
                }
            else
                {
                for (Enumeration enum = table._enumChildren(); enum.hasMoreElements();)
                    {
                    if (((TableColumn) enum.nextElement()).isSorted())
                        {
                        return;
                        }
                    }
                table.setSorted(false);
                }
            }
        }
    
    // Accessor for the property "Title"
    public void setTitle(String pTitle)
        {
        setHeaderValue(pTitle);
        }
    }
