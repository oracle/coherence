/* Class
*      sink_Control
*
* automatically generated "Sink" which
* represents a footprint of the class
*      java.awt.Component
* when used as a component callback by 
*      Component.GUI.Control
*/

package _package.component.gUI;

public abstract class sink_Control
       extends com.tangosol.run.component.CallbackSink
    {
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_Control()
        {
        }
    
    // methods integrated and/or remoted
    public abstract void addFocusListener(java.awt.event.FocusListener l);
    public abstract void addKeyListener(java.awt.event.KeyListener l);
    public abstract void addMouseListener(java.awt.event.MouseListener l);
    public abstract void addMouseMotionListener(java.awt.event.MouseMotionListener l);
    public abstract void addNotify();
    public abstract void addPropertyChangeListener(java.beans.PropertyChangeListener l);
    public abstract void doLayout();
    public abstract java.awt.Color getBackground();
    public abstract java.awt.Rectangle getBounds();
    public abstract java.awt.Cursor getCursor();
    public abstract java.awt.Font getFont();
    public abstract java.awt.Color getForeground();
    public abstract java.awt.Point getLocation();
    public abstract java.awt.Point getLocationOnScreen();
    public abstract java.awt.Dimension getSize();
    public abstract boolean isEnabled();
    public abstract boolean isFocusTraversable();
    public abstract boolean isShowing();
    public abstract boolean isVisible();
    public abstract void paint(java.awt.Graphics g);
    public abstract void removeFocusListener(java.awt.event.FocusListener l);
    public abstract void removeKeyListener(java.awt.event.KeyListener l);
    public abstract void removeMouseListener(java.awt.event.MouseListener l);
    public abstract void removeMouseMotionListener(java.awt.event.MouseMotionListener l);
    public abstract void removeNotify();
    public abstract void removePropertyChangeListener(java.beans.PropertyChangeListener l);
    public abstract void requestFocus();
    public abstract void setBackground(java.awt.Color p_Background);
    public abstract void setBounds(java.awt.Rectangle p_Bounds);
    public abstract void setCursor(java.awt.Cursor p_Cursor);
    public abstract void setFont(java.awt.Font p_Font);
    public abstract void setForeground(java.awt.Color p_Foreground);
    public abstract void setLocation(java.awt.Point p_Location);
    public abstract void setSize(java.awt.Dimension p_Size);
    public abstract void setEnabled(boolean pEnabled);
    public abstract void setVisible(boolean pVisible);
    public abstract void validate();
    }
