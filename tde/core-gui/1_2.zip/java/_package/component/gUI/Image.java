/* Class
*     _package.component.gUI.Image
*/

package _package.component.gUI;

import _package.component.Application;
import _package.component.net.URL;
import com.tangosol.util.Base;
import java.awt.Image; // as _Image
import java.awt.Toolkit;
import java.awt.image.ImageObserver;
import java.io.InputStream;
import java.net.URL; // as _URL

/*
* Integrates
*     java.awt.Image
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class Image
        extends    _package.component.GUI
        implements java.awt.image.ImageObserver
    {
    // Fields declarations
    
    /**
    * Property _Image
    *
    */
    private java.awt.Image __m__Image;
    
    /**
    * Property Height
    *
    */
    
    /**
    * Property ImagePath
    *
    * The path of the image.
    */
    private String __m_ImagePath;
    
    /**
    * Property ImageURL
    *
    * The URL of the image.
    */
    private _package.component.net.URL __m_ImageURL;
    
    /**
    * Property Width
    *
    */
    
    // Default constructor
    public Image()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Image(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Image();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/Image".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.awt.Image integration
    // Access optimization
    // properties integration
    // methods integration
    public java.awt.Graphics getGraphics()
        {
        return get_Image().getGraphics();
        }
    //-- java.awt.Image integration
    
    // Accessor for the property "_Image"
    /**
    * Getter for property _Image.<p>
    */
    public java.awt.Image get_Image()
        {
        // import Component.Application;
        // import Component.Net.URL;
        // import com.tangosol.util.Base;
        // import java.awt.Image as _Image;
        // import java.awt.Toolkit;
        // import java.io.InputStream;
        // import java.net.URL as _URL;
        
        _Image _image = __m__Image;
        if (_image == null)
            {
            // attempt 1 -- check the path
            String sPath = getImagePath();
            if (sPath != null)
                {
                InputStream stream = ((Application) Application.get_Instance()).getResourceAsStream(sPath);
                if (stream != null)
                    {
                    try
                        {
                        set_Image(_image = Toolkit.getDefaultToolkit().
                            createImage(Base.read(stream)));
                        }
                    catch (Exception ex) {}
                    return _image;
                    }
                }
            // attempt 2 -- check the url
            URL url = getImageURL();
            if (url != null)
                {
                _URL _url = url.get_URL();
                if (_url != null)
                    {
                    try
                        {
                        set_Image(_image = Toolkit.getDefaultToolkit().
                            createImage(_url));
                        }
                    catch (Exception ex) {}
                    return _image;
                    }
                }
            }
        
        return _image;
        }
    
    // Accessor for the property "Height"
    /**
    * Getter for property Height.<p>
    */
    public int getHeight()
        {
        return get_Image().getHeight(this);
        }
    
    // Accessor for the property "ImagePath"
    /**
    * Getter for property ImagePath.<p>
    * The path of the image.
    */
    public String getImagePath()
        {
        return __m_ImagePath;
        }
    
    // Accessor for the property "ImageURL"
    /**
    * Getter for property ImageURL.<p>
    * The URL of the image.
    */
    public _package.component.net.URL getImageURL()
        {
        return __m_ImageURL;
        }
    
    public Object getProperty(String name)
        {
        return get_Image().getProperty(name, this);
        }
    
    // Accessor for the property "Width"
    /**
    * Getter for property Width.<p>
    */
    public int getWidth()
        {
        return get_Image().getWidth(this);
        }
    
    // From interface: java.awt.image.ImageObserver
    public boolean imageUpdate(java.awt.Image img, int infoFlags, int x, int y, int w, int h)
        {
        // import java.awt.image.ImageObserver;
        
        /*
            this does get called sometimes, though extremely rarely.
            In fact once I saw a trace like this:
        
            Contain.imageUpdate 3 (0,0,16,16)
            Contain.imageUpdate 4 (0,0,0,0)
            Contain.imageUpdate 8 (0,0,16,1)
            Contain.imageUpdate 8 (0,1,16,1)
            Contain.imageUpdate 8 (0,2,16,1)
            Contain.imageUpdate 8 (0,3,16,1)
            Contain.imageUpdate 8 (0,4,16,1)
            Contain.imageUpdate 8 (0,5,16,1)
            Contain.imageUpdate 8 (0,6,16,1)
            Contain.imageUpdate 8 (0,7,16,1)
            Contain.imageUpdate 8 (0,8,16,1)
            Contain.imageUpdate 8 (0,9,16,1)
            Contain.imageUpdate 8 (0,10,16,1)
            Contain.imageUpdate 8 (0,11,16,1)
            Contain.imageUpdate 8 (0,12,16,1)
            Contain.imageUpdate 8 (0,13,16,1)
            Contain.imageUpdate 8 (0,14,16,1)
            Contain.imageUpdate 8 (0,15,16,1)
            Contain.imageUpdate 32 (0,0,16,16)
        */
        
        // _trace(get_Name() + ".imageUpdate " + infoFlags + " (" + x + "," + y + "," + w + "," + h + ")");
        
        return (infoFlags & (ImageObserver.ALLBITS | ImageObserver.ABORT)) == 0;

        }
    
    // Accessor for the property "_Image"
    /**
    * Setter for property _Image.<p>
    */
    public void set_Image(java.awt.Image p_Image)
        {
        __m__Image = p_Image;
        }
    
    // Accessor for the property "ImagePath"
    /**
    * Setter for property ImagePath.<p>
    * The path of the image.
    */
    public void setImagePath(String pImagePath)
        {
        __m_ImagePath = (pImagePath);
        setImageURL(null);
        }
    
    // Accessor for the property "ImageURL"
    /**
    * Setter for property ImageURL.<p>
    * The URL of the image.
    */
    public void setImageURL(_package.component.net.URL pImageURL)
        {
        __m_ImageURL = (pImageURL);
        set_Image(null);
        }
    }
