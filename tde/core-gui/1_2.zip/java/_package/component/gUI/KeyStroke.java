/* Class
*     _package.component.gUI.KeyStroke
*/

package _package.component.gUI;

import javax.swing.KeyStroke; // as _KeyStroke

/**
* This component is a designable wrapper around javax.swing.KeyStroke that
* represents a key being typed on the keyboard. The KeyStroke component is
* meant to be a child of KeyAction component.
*/
public class KeyStroke
        extends    _package.component.GUI
    {
    // Fields declarations
    
    /**
    * Property _KeyStroke
    *
    */
    private transient javax.swing.KeyStroke __m__KeyStroke;
    
    /**
    * Property KeyChar
    *
    * Specifies the character value for a keyboard key. If this property is set
    * to a non-zero value, the values of Modifiers and KeyCode properties are
    * ignored.
    * 
    * @see java.awt.event.KeyEvent
    * 
    * Note: if this property is set programmatically, it should be unbound
    * first with a call to <code>unbind</code> method and rebound afterwards
    * with a call to <code>bind</code> method.
    */
    private char __m_KeyChar;
    
    /**
    * Property KeyCode
    *
    * Specifies the numeric code for a keyboard key. This property is only used
    * when the KeyChar property is set to zero.
    * 
    * Note: if this property is set programmatically, it should be unbound
    * first with a call to <code>unbind</code> method and rebound afterwards
    * with a call to <code>bind</code> method.
    */
    private int __m_KeyCode;
    
    /**
    * Property Modifiers
    *
    * Specifies any combination of the key modifiers. Key modifiers are:
    * 
    * SHIFT_MASK (1)
    * CTRL_MASK (2)
    * META_MASK (4)
    * ALT_MASK (8)
    * 
    * This property is only used when the KeyChar property is set to zero.
    * 
    * @see java.awt.Event
    * 
    * Note: if this property is set programmatically, it should be unbound
    * first with a call to <code>unbind</code> method and rebound afterwards
    * with a call to <code>bind</code> method.
    */
    private int __m_Modifiers;
    
    /**
    * Property OnKeyRelease
    *
    * If set to true, specifies that the key is active when it is released.
    * 
    * Note: if this property is set programmatically, it should be unbound
    * first with a call to <code>unbind</code> method and rebound afterwards
    * with a call to <code>bind</code> method.
    */
    private boolean __m_OnKeyRelease;
    
    // Default constructor
    public KeyStroke()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public KeyStroke(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new KeyStroke();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/KeyStroke".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import javax.swing.KeyStroke as _KeyStroke;
        

        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof KeyStroke)
            {
            return get_KeyStroke().equals(((KeyStroke) obj).get_KeyStroke());
            }
        else if (obj instanceof _KeyStroke)
            {
            return get_KeyStroke().equals(obj);
            }
        else
            {
            return false;
            }
        }
    
    // Accessor for the property "_KeyStroke"
    public javax.swing.KeyStroke get_KeyStroke()
        {
        _KeyStroke _keystroke = __m__KeyStroke;
        if (_keystroke == null)
            {
            char chKey = getKeyChar();
            if (chKey != '\0')
                {
                _keystroke = _KeyStroke.getKeyStroke(chKey);
                }
            else
                {
                _keystroke = _KeyStroke.getKeyStroke(
                    getKeyCode(), getModifiers(), isOnKeyRelease());
                }
        
            set_KeyStroke(_keystroke);
            }
        return _keystroke;
        }
    
    // Accessor for the property "KeyChar"
    public char getKeyChar()
        {
        return __m_KeyChar;
        }
    
    // Accessor for the property "KeyCode"
    public int getKeyCode()
        {
        return __m_KeyCode;
        }
    
    // Accessor for the property "Modifiers"
    public int getModifiers()
        {
        return __m_Modifiers;
        }
    
    // Accessor for the property "OnKeyRelease"
    public boolean isOnKeyRelease()
        {
        return __m_OnKeyRelease;
        }
    
    // Accessor for the property "_KeyStroke"
    public void set_KeyStroke(javax.swing.KeyStroke p_KeyStroke)
        {
        __m__KeyStroke = p_KeyStroke;
        }
    
    // Accessor for the property "KeyChar"
    public void setKeyChar(char pKeyChar)
        {
        __m_KeyChar = (pKeyChar);
        
        set_KeyStroke(null);
        }
    
    // Accessor for the property "KeyCode"
    public void setKeyCode(int pKeyCode)
        {
        __m_KeyCode = (pKeyCode);
        
        set_KeyStroke(null);
        }
    
    // Accessor for the property "Modifiers"
    public void setModifiers(int pModifiers)
        {
        __m_Modifiers = (pModifiers);
        
        set_KeyStroke(null);
        }
    
    // Accessor for the property "OnKeyRelease"
    public void setOnKeyRelease(boolean pOnKeyRelease)
        {
        __m_OnKeyRelease = (pOnKeyRelease);
        
        set_KeyStroke(null);
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_KeyStroke().toString();
        }
    }
