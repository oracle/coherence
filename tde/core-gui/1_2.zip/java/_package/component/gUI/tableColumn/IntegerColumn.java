/* Class
*     _package.component.gUI.tableColumn.IntegerColumn
*/

package _package.component.gUI.tableColumn;

/**
* TableColumn that maintains java.lang.Long type for all its cells
*/
public class IntegerColumn
        extends    _package.component.gUI.TableColumn
    {
    // Fields declarations
    
    // Default constructor
    public IntegerColumn()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public IntegerColumn(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setCellHorizontalAlignment(4);
            setEditable(true);
            setHorizontalAlignment(0);
            setIndex(-1);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new IntegerColumn();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/tableColumn/IntegerColumn".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * This method is called by the JTable.setValueAt() to give the TableColumn 
    * component a chance to validate and format the incoming value. Returning
    * null will discard the change.
    * 
    * Default implementation returns the passed in value without any changes
    * 
    * @param oValue  a new value that is about to be set for row number iRow at
    * this column
    * @param iRow  the row number for the new value
    * 
    * @return a formatted value or null to discard the change
    */
    public Object format(Object oValue, int iRow)
        {
        if (oValue instanceof Long)
            {
            return super.format(oValue, iRow);
            }
        else
            {
            String sValue = String.valueOf(oValue);
            try
                {
                return new Long(Long.parseLong(sValue));
                }
            catch (NumberFormatException e)
                {
                return null;
                }
            }
        }
    
    // Declared at the super level
    /**
    * This is an accessor that could be used by some generic implementations
    * (like TcTable)  to allow adding an empty row of data. For consistency teh
    * default implementation returns am empty string instead of null which
    * would be shown as an empty string by the default renderer and converted
    * by the default editor anyway (see
    * javax.swing.DefaultTableCellRenderer#setValue()), but would cause
    */
    public Object getDefaultValue()
        {
        return new Long(0l);
        }
    
    // Declared at the super level
    public void setChoiceStrings(String[] pChoiceStrings)
        {
        if (pChoiceStrings == null)
            {
            setChoiceList(null);
            }
        else
            {
            int     c  = pChoiceStrings.length;
            Long[]  al = new Long[c];
            for (int i = 0; i < c; i++)
                {
                try
                    {
                    al[i] = Long.valueOf(pChoiceStrings[i]);
                    }
                catch (NumberFormatException e) {}
                }
            setChoiceList(al);
            }
        }
    }
