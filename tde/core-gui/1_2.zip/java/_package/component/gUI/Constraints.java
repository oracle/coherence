/* Class
*     _package.component.gUI.Constraints
*/

package _package.component.gUI;

public abstract class Constraints
        extends    _package.component.GUI
    {
    // Fields declarations
    
    /**
    * Property _Constraints
    *
    */
    private Object __m__Constraints;
    
    // Initializing constructor
    public Constraints(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/gUI/Constraints".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        Object _this = get_Constraints();
        Object _that = obj != null ? ((Constraints) obj).get_Constraints() : null;
        
        return _this == null ? _that == null : _this.equals(_that);
        }
    
    // Accessor for the property "_Constraints"
    public Object get_Constraints()
        {
        return __m__Constraints;
        }
    
    // Accessor for the property "_Constraints"
    public void set_Constraints(Object p_Constraints)
        {
        __m__Constraints = p_Constraints;
        }
    }
