/* Class
*     _package.component.util.format.javaFormat.CurrencyFormat
*/

package _package.component.util.format.javaFormat;

import java.text.NumberFormat;

/**
* Formats a java.util.Date object as a date String.
*/
/*
* Integrates
*     java.text.NumberFormat
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class CurrencyFormat
        extends    _package.component.util.format.JavaFormat
    {
    // Fields declarations
    
    /**
    * Property GroupingUsed
    *
    */
    private transient boolean __m_GroupingUsed;
    
    /**
    * Property MaximumFractionDigits
    *
    */
    private transient int __m_MaximumFractionDigits;
    
    /**
    * Property MaximumIntegerDigits
    *
    */
    private transient int __m_MaximumIntegerDigits;
    
    /**
    * Property MinimumFractionDigits
    *
    */
    private transient int __m_MinimumFractionDigits;
    
    /**
    * Property MinimumIntegerDigits
    *
    */
    private transient int __m_MinimumIntegerDigits;
    
    // Default constructor
    public CurrencyFormat()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CurrencyFormat(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new CurrencyFormat();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/format/javaFormat/CurrencyFormat".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ java.text.NumberFormat integration
    // Access optimization
    // properties integration
    // methods integration
    public int getMaximumFractionDigits()
        {
        return ((java.text.NumberFormat) getFormat()).getMaximumFractionDigits();
        }
    public int getMaximumIntegerDigits()
        {
        return ((java.text.NumberFormat) getFormat()).getMaximumIntegerDigits();
        }
    public int getMinimumFractionDigits()
        {
        return ((java.text.NumberFormat) getFormat()).getMinimumFractionDigits();
        }
    public int getMinimumIntegerDigits()
        {
        return ((java.text.NumberFormat) getFormat()).getMinimumIntegerDigits();
        }
    public boolean isGroupingUsed()
        {
        return ((java.text.NumberFormat) getFormat()).isGroupingUsed();
        }
    public void setGroupingUsed(boolean fUsed)
        {
        ((java.text.NumberFormat) getFormat()).setGroupingUsed(fUsed);
        }
    public void setMaximumFractionDigits(int nDigits)
        {
        ((java.text.NumberFormat) getFormat()).setMaximumFractionDigits(nDigits);
        }
    public void setMaximumIntegerDigits(int nDigits)
        {
        ((java.text.NumberFormat) getFormat()).setMaximumIntegerDigits(nDigits);
        }
    public void setMinimumFractionDigits(int nDigits)
        {
        ((java.text.NumberFormat) getFormat()).setMinimumFractionDigits(nDigits);
        }
    public void setMinimumIntegerDigits(int nDigits)
        {
        ((java.text.NumberFormat) getFormat()).setMinimumIntegerDigits(nDigits);
        }
    //-- java.text.NumberFormat integration
    
    // Declared at the super level
    public java.text.Format instantiateFormat()
        {
        // import java.text.NumberFormat;
        
        return NumberFormat.getCurrencyInstance(getLocale());
        }
    }
