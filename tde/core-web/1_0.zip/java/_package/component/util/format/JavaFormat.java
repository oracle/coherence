/* Class
*     _package.component.util.format.JavaFormat
*/

package _package.component.util.format;

import java.text.Format;
import java.text.ParseException;
import java.util.Locale;

/**
* 
* The JavaFormat component extends the abstract Format component to tie into
* the java.text.Format class.
*/
public abstract class JavaFormat
        extends    _package.component.util.Format
    {
    // Fields declarations
    
    /**
    * Property Format
    *
    */
    private java.text.Format __m_Format;
    
    /**
    * Property PreviousLocale
    *
    */
    private java.util.Locale __m_PreviousLocale;
    
    // Initializing constructor
    public JavaFormat(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/format/JavaFormat".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Formats the passed Object into a String.
    * 
    * @param o  the Object to format
    * 
    * @return the result of formatting the Object into a String
    * 
    * @exception IllegalArgumentException is thrown if the passed Object is
    * null or an unsupported type for this format
    */
    public String format(Object o)
        {
        if (o == null)
            {
            throw new IllegalArgumentException("JavaFormat.parse:  Object is null");
            }
        
        return getFormat().format(o);
        }
    
    // Accessor for the property "Format"
    public java.text.Format getFormat()
        {
        // import java.text.Format;
        // import java.util.Locale;
        
        Format format = __m_Format;
        Locale locale = getLocale();
        
        if (format == null || !locale.equals(getPreviousLocale()))
            {
            format = instantiateFormat();
            setFormat(format);
            setPreviousLocale(locale);
            }
        
        return format;
        }
    
    // Accessor for the property "PreviousLocale"
    public java.util.Locale getPreviousLocale()
        {
        return __m_PreviousLocale;
        }
    
    public java.text.Format instantiateFormat()
        {
        return null;
        }
    
    // Declared at the super level
    /**
    * Determines whether the passed String can be successfully parsed into an
    * Object by the parse method of this Format component.
    * 
    * @param s  the String to test
    * 
    * @return true if the passed String is non-null and can be successfully
    * parsed into an Object by the parse method
    * 
    * @see parse
    */
    public boolean isValid(String s)
        {
        try
            {
            parse(s);
            return true;
            }
        catch (IllegalArgumentException e)
            {
            return false;
            }
        }
    
    // Declared at the super level
    /**
    * Formats the passed Object into a String.
    * 
    * @param s  the String to parse
    * 
    * @return the non-null Object parsed from the String
    * 
    * @exception IllegalArgumentException is thrown if the passed String is
    * null or if the passed String is not parseable (meaning that isValid for
    * the String would return false)
    * 
    * @see isValid
    */
    public Object parse(String s)
        {
        // import java.text.ParseException;
        
        if (s == null)
            {
            throw new IllegalArgumentException("JavaFormat.parse:  String is null");
            }
        
        try
            {
            return getFormat().parseObject(s);
            }
        catch (ParseException e)
            {
            throw new IllegalArgumentException(e.toString());
            }
        catch (RuntimeException e)
            {
            throw e instanceof IllegalArgumentException ? (IllegalArgumentException) e
                                                        : new IllegalArgumentException(e.toString());
            }
        }
    
    // Accessor for the property "Format"
    protected void setFormat(java.text.Format format)
        {
        __m_Format = format;
        }
    
    // Accessor for the property "PreviousLocale"
    public void setPreviousLocale(java.util.Locale locale)
        {
        __m_PreviousLocale = locale;
        }
    }
