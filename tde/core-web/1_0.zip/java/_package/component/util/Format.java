/* Class
*     _package.component.util.Format
*/

package _package.component.util;

import _package.component.Application;
import java.util.Locale;

/**
* The Format component is the abstract root of all Object-to-String and
* String-to-Object conversion helpers.  A Format component must provide an
* implementation for the following methods:
* 
* format
* isValid
* parse
* 
* The Format component also supports a configurable Locale property.  If not
* configured, the Locale is obtained from the Application component.
* 
* Use a Format component to convert an Object to a String as follows:
* 
* Format f = ...
* String s = f.format(o);
* 
* The Format component itself abstract and simple to allow for extensions that
* tie into the Java formatting implementations (java.text.Format,
* java.text.NumberFormat and java.text.DateFormat).
*/
public abstract class Format
        extends    _package.component.Util
    {
    // Fields declarations
    
    /**
    * Property Locale
    *
    * The Locale that the format will use if it is Locale-specific.
    */
    private java.util.Locale __m_Locale;
    
    /**
    * Property LocaleSpecified
    *
    * Set to true when the default Locale is over-ridden.
    */
    private boolean __m_LocaleSpecified;
    
    // Initializing constructor
    public Format(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/Format".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Formats the passed Object into a String.
    * 
    * @param o  the Object to format
    * 
    * @return the result of formatting the Object into a String
    * 
    * @exception IllegalArgumentException is thrown if the passed Object is
    * null or an unsupported type for this format
    */
    public String format(Object o)
        {
        return null;
        }
    
    // Accessor for the property "Locale"
    public java.util.Locale getLocale()
        {
        // import Component.Application;
        // import java.util.Locale;
        
        Locale locale = __m_Locale;
        
        if (locale == null)
            {
            Application app = (Application) Application.get_Instance();
            locale = app.getLocale();
            }
        
        return locale;
        }
    
    // Accessor for the property "LocaleSpecified"
    public boolean isLocaleSpecified()
        {
        return __m_LocaleSpecified;
        }
    
    /**
    * Determines whether the passed String can be successfully parsed into an
    * Object by the parse method of this Format component.
    * 
    * @param s  the String to test
    * 
    * @return true if the passed String is non-null and can be successfully
    * parsed into an Object by the parse method
    * 
    * @see parse
    */
    public boolean isValid(String s)
        {
        return false;
        }
    
    /**
    * Formats the passed Object into a String.
    * 
    * @param s  the String to parse
    * 
    * @return the non-null Object parsed from the String
    * 
    * @exception IllegalArgumentException is thrown if the passed String is
    * null or if the passed String is not parseable (meaning that isValid for
    * the String would return false)
    * 
    * @see isValid
    */
    public Object parse(String s)
        {
        return null;
        }
    
    // Accessor for the property "Locale"
    public void setLocale(java.util.Locale locale)
        {
        __m_Locale = (locale);
        setLocaleSpecified(locale != null);
        }
    
    // Accessor for the property "LocaleSpecified"
    protected void setLocaleSpecified(boolean f)
        {
        __m_LocaleSpecified = f;
        }
    }
