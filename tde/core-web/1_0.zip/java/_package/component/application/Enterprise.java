/* Class
*     _package.component.application.Enterprise
*/

package _package.component.application;

import _package.component.web.RequestContext;
import _package.component.web.Server;
import _package.component.web.requestContext.JspTagContext;
import _package.component.web.requestContext.ServletRequestContext;
import com.tangosol.run.component.ExecutionContext;
import com.tangosol.util.WrapperException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.Principal;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Map;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
* An Enterprise Application component is used to package an Enterprise ARchive
* (EAR) file for a Java 2 Enterprise Edition (J2EE) application.
* 
* An Enterprise Application is built by dragging "modules" into the application
* component.  Supported module types are:
* 
* Component.Library.Ejb
* Component.Library.Web
*/
public class Enterprise
        extends    _package.component.Application
    {
    // Fields declarations
    
    /**
    * Property ContextCache
    *
    * The current thread's cached javax.naming.Context object.  This is used if
    * the ContextCaching option evaluates to "Thread".
    */
    private transient javax.naming.Context __m_ContextCache;
    
    /**
    * Property ContextCacheTLO
    *
    * A thread-local object for caching javax.naming.Context objects on a
    * per-thread basis.  This is used if the ContextCaching option evaluates to
    * "Thread".
    */
    private com.tangosol.util.ThreadLocalObject __m_ContextCacheTLO;
    
    /**
    * Property ContextCaching
    *
    * This option is used to determine if the Context property will be cached. 
    * The options are:
    * 
    * None - do not cache the Context property
    * Thread - cache the Context property on a per-thread basis
    * Global - cache the Context property globally (all threads will use the
    * same javax.naming.Context object)
    * Server Default - ask the application's Server object for the caching
    * option
    */
    private int __m_ContextCaching;
    
    /**
    * Property ContextCachingWeb
    *
    * This option is used to determine if the Context property will be cached
    * in the web tier.  The options are:
    * 
    * None - do not cache the Context property in the web tier (which means
    * that the web tier will use the caching option specified by the
    * ContextCaching property)
    * Page - cache the Context property on the page scope only (not suggested)
    * Request - cache the Context property in the current HttpRequest object
    * Session - cache the Context property in the user's HttpSession object
    * Application - cache the Context property in the ServletContext (which is
    * shared by all users of the web container)
    * 
    * This option takes precedence over the ContextCaching option.  Under most
    * situations, this property should be set to None in order to use the
    * caching strategy suggested by the Server object.  In cases where the web
    * tier should have its own javax.naming.Context object, for example for
    * specifying specific security attributes for the naming context in the web
    * tier only, this property should be set to Request, Session, or
    * Application, and the instantiateInitialContext method should be
    * overridden to return the proper javax.naming.Context object for the web
    * tier based on the value of the ProcessingWeb property.
    */
    private int __m_ContextCachingWeb;
    
    /**
    * Property ContextPathMap
    *
    * The ContextPathMap is a map of context paths (String objects)  to context
    * route maps (Map objects).  The route maps are built by the Servlet
    * component.
    * 
    * @see #getContextRouteMap(String)
    * @see Component.Web.Http.Servlet#instantiateRouteMap
    */
    private com.tangosol.util.ListMap __m_ContextPathMap;
    
    /**
    * Property CTXCACHE_ATTRIBUTE
    *
    * The name of the attribute that is used to cache the javax.naming.Context
    * object if the ContextCachingWeb option indicates that caching should be
    * used.
    */
    public static final String CTXCACHE_ATTRIBUTE = "application.context";
    
    /**
    * Property CTXCACHE_GLOBAL
    *
    * Global - cache the Context property globally (all threads will use the
    * same javax.naming.Context object).
    * 
    * @see ContextCaching
    */
    public static final int CTXCACHE_GLOBAL = 2;
    
    /**
    * Property CTXCACHE_NONE
    *
    * None - do not cache the Context property.
    * 
    * @see ContextCaching
    */
    public static final int CTXCACHE_NONE = 0;
    
    /**
    * Property CTXCACHE_SERVERDEFAULT
    *
    * Server Default - ask the application's Server object for the caching
    * option.
    * 
    * @see ContextCaching
    */
    public static final int CTXCACHE_SERVERDEFAULT = 3;
    
    /**
    * Property CTXCACHE_THREAD
    *
    * Thread - cache the Context property on a per-thread basis.
    * 
    * @see ContextCaching
    */
    public static final int CTXCACHE_THREAD = 1;
    
    /**
    * Property DefaultEnvironment
    *
    * The environment to use when instantiating an InitialContext object.
    * 
    * @see instantiateInitialContext
    */
    private java.util.Hashtable __m_DefaultEnvironment;
    
    /**
    * Property EnableConsole
    *
    * If true, the application will log debug output to the console (System.out
    * or System.err).
    */
    private boolean __m_EnableConsole;
    
    /**
    * Property EnableDebugEcho
    *
    * If true, the application will log debug output to the current
    * RequestContext object.
    */
    private boolean __m_EnableDebugEcho;
    
    /**
    * Property EnableLogging
    *
    * If true, the application will log debug output to the application's
    * Server object.
    */
    private boolean __m_EnableLogging;
    
    /**
    * Property ExecutionContext
    *
    * This property provides the current ExecutionContext object for the
    * current thread.
    * 
    * Unless the caller is responsible for the ExecutionContext, the caller
    * should only assume that the toString() method of the ExecutionContext is
    * available, which is to say that the explicit methods of the interface
    * should only be called by the Enterprise Application component that
    * registers/unregisters the context.  It is expected that the class of the
    * ExecutionContext object will be used to determine the type of processing
    * that is occurring, and furthermore that components which understand
    * certain classes of ExecutionContext objects will be able to cast the
    * context to the appropriate class and obtain the information that they
    * need.  See isProcessingServlet() for an example.
    */
    private transient com.tangosol.run.component.ExecutionContext __m_ExecutionContext;
    
    /**
    * Property ExecutionContextTLO
    *
    * This is a private thread-local object that holds an ExecutionContext
    * object for each thread. This object is also maintained as a current
    * request attribute.
    * 
    * @see registerContext
    */
    private transient com.tangosol.util.ThreadLocalObject __m_ExecutionContextTLO;
    
    /**
    * Property Processing
    *
    * Determine if the current thread is processing a service request.  In an
    * Enterprise (J2EE server-based) application, each service has a different
    * mechanism for being invoked.  (For example, HTTP Servlets provide the
    * Servlet interface to an HTTP server, and EJB objects provide an
    * implementation class for the EJB container to invoke.)  Components that
    * provide "enterprise services" are responsible for registering an
    * ExecutionContext for the duration of the service of the request.  If an
    * ExecutionContext exists for the current thread, then the current thread
    * is assumed to be processing and this property will return true.
    */
    
    /**
    * Property ProcessingJspTag
    *
    * This property returns true if the current thread is processing a JSP tag
    * component.
    * 
    * Note that if the tag component uses EJB components, the execution context
    * will be an EJB execution context for the duration of any EJB invocation.
    */
    
    /**
    * Property ProcessingServlet
    *
    * This property returns true if the current thread is processing a Servlet
    * request.
    * 
    * Note that if the Servlet has forwarded to a JSP that is using JSP tag
    * components, the current execution context will be a JSP request context
    * while the tags are being processed, not a servlet request context. 
    * Similarly, if the Servlet uses EJB components, the execution context will
    * be an EJB execution context for the duration of any EJB invocation.
    */
    
    /**
    * Property ProcessingWeb
    *
    * This property returns true if the current thread is processing a web
    * (Servlet or JSP tag) request.
    */
    
    /**
    * Property RequestContext
    *
    * If the current execution is the result of an HTTP request (has at some
    * point in its execution stack a RequestContext) then return the inner-most
    * RequestContext (the one closest to the top of the context stack).  Note
    * that the property can be null, for example if a client has called an EJB
    * directly without going through a Servlet or JSP.  Note that this property
    * can be non-null even if ProcessingWeb returns false, since ProcessingWeb
    * evaluates using the current execution context object and does not check
    * the entire stack.
    */
    
    /**
    * Property Server
    *
    * The Server component represents the environment within which the
    * application is running.  Although the type of Server is
    * Component.Web.Server, it does not necessarily imply that the application
    * is HTTP based.  The value of this property can be assumed to be non-null.
    */
    private _package.component.web.Server __m_Server;
    
    // Default constructor
    public Enterprise()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Enterprise(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // singleton initialization
        if (__singleton != null)
            {
            throw new IllegalStateException("A singleton for \"Enterprise\" has already been set");
            }
        __singleton = this;
        
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setContextCaching(3);
            setContextCachingWeb(0);
            setEnableConsole(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        
        // state initialization: private properties
        try
            {
            __m_ContextCacheTLO = new com.tangosol.util.ThreadLocalObject();
            __m_ContextPathMap = new com.tangosol.util.ListMap();
            __m_ExecutionContextTLO = new com.tangosol.util.ThreadLocalObject();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    //++ getter for static property _Instance
    /**
    * Instantiate an Application component or return the previously
    * instantiated singleton.
    * 
    * The implementation of the get_Instance accessor on the Application
    * component is more complex than that of most other singleton components. 
    * First, it must be able to determine what application to instantiate. 
    * Secondly, it works with the _Reference property of the root component to
    * maintain a reference to the resulting application component until the
    * very last component instance is garbage-collected.
    * 
    * 1)  The _Reference property is static and located on the root component.
    * 2)  The accessor and mutator for the _Reference property are protected
    * and thus the property value can be obtained or modified by any component.
    *  (Specifically, it is set initially by Component.<init>, obtained by
    * Application.get_Instance, and set by Application.onInit.)
    * 3)  Component.<init> (the constructor of the root component) sets the
    * _Reference property to the instance of the component being constructed if
    * and only if the _Reference property is null; this guarantees that a
    * reference to the very first component to be instantiated is initially
    * stored in the _Reference property.
    * 4)  When an application component is instantiated, the Application.onInit
    * method stores a reference to that application in the _Reference property;
    * this ensures that a reference to the application will exist as long as
    * any component instance exists (because the root component class will not
    * be garbage-collectable until all component instances are determined to be
    * garbage-collectable and until all of its sub-classes are determined to be
    * garbage-collectable).  Since Application is a singleton, it is not
    * possible for a second instance of Application to exist, so once an
    * Application component has been instantiated, the _Reference property's
    * value will refer to that application until the root component class is
    * garbage-collected.
    * 5)  When Application.get_Instance() is invoked, if no singleton
    * application (Application.__singleton) has been created, then
    * Application.get_Instance is responsible for instantiating an application,
    * which will result in _Reference being set to the application instance (by
    * way of Application.onInit).
    * 
    * The implementation of Application.get_Instance is expected to take the
    * the following steps in order to instantiate the correct application
    * component:
    * 1) If the value of the _Reference property is non-null, it cannot be an
    * instance of Component.Application, because the __init method of an
    * Application component would have set the Application.__singleton field to
    * reference itself.  Application thus assumes that a non-null _Reference
    * value refers to the first component to be instantiated, and invokes the
    * _makeApplication instance method of that component.  If the return value
    * from _makeApplication is non-null, then it is returned by
    * Application.get_Instance.
    * 2)  Application.get_Instance is now in a catch-22.  No instance of
    * Component.Application exists, which means that the entry point (the
    * initially instantiated) component was not an application component, and
    * the component that was the entry point has denied knowledge of what
    * application should be instantiated.  At this point, the
    * Application.get_Instance method must determine the name of the
    * application component to instantiate without any help.  So it drops back
    * and punts.  First, it checks for an environment setting, then it checks
    * for a properties file setting, and if either one exists, then it
    * instantiates the component specified by that setting and returns it.
    * 3)  Finally, without so much as a clue telling Application.get_Instance
    * what to instantiate, it instantiates the default application context.
    * 
    * Note that in any of the above scenarios, by the time the value is
    * returned by Application.get_Instance, the value of the _Reference
    * property would have been set to the application instance by
    * Application.onInit, thus fulfilling the goal of holding a reference to
    * the application.
    * 
    * Any other case in which a reference must be maintained should be done by
    * having the application hold that reference.  In other words, as long as
    * the application doesn't go away, any reference that it holds won't go
    * away either.
    * 
    * @see Component#_Reference
    */
    public static _package.Component get_Instance()
        {
        _package.Component singleton = __singleton;
        
        if (singleton == null)
            {
            singleton = new Enterprise();
            }
        else if (!(singleton instanceof Enterprise))
            {
            throw new IllegalStateException("A singleton for \"Enterprise\" has already been set to a different type");
            }
        return singleton;
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/application/Enterprise".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Prints out the specified message according to the Application context. 
    * Derived applications should provide an appropriate implementation for
    * this method if the output should not be sent to the standard output and
    * error output.  For example, if an application wanted to log output, this
    * would be the method to override.
    * 
    * @param message  the text message to display
    * @param severity  0 for informational, ascending for more serious output
    * (the default implementation assumes anything not 0 is an error and should
    * be printed to the system error stream)
    */
    public void debugOutput(String message, int severity)
        {
        // import Component.Web.RequestContext;
        
        if (isEnableConsole())
            {
            super.debugOutput(message, severity);
            }
        
        if (isEnableLogging())
            {
            getServer().log(message, severity);
            }
        
        if (isEnableDebugEcho())
            {
            RequestContext ctx = getRequestContext();
            if (ctx != null)
                {
                ctx.log(message, severity);
                }
            }
        }
    
    // Declared at the super level
    /**
    * Produces a sound. Derived components should provide an appropriate
    * implementation for this method.  For example, graphical applications can
    * use the AWT toolkit to produce a beep.  Server applications may not have
    * any way of beeping (or no one to hear it if they can).
    */
    public void debugSound()
        {
        // import Component.Web.RequestContext;
        
        if (isEnableConsole())
            {
            super.debugSound();
            }
        
        if (isEnableLogging())
            {
            getServer().log("Beep!", 0);
            }
        
        if (isEnableDebugEcho())
            {
            RequestContext ctx = getRequestContext();
            if (ctx != null)
                {
                ctx.log("Beep!", 0);
                }
            }
        }
    
    // Declared at the super level
    /**
    * Returns the current naming context. If not specified, initializes it with
    *  javax.naming.InitialContext object.
    * 
    * Derived application components may want to initialize the Context in
    * other ways, e.g., using an applicaiton-specific configuration file, or
    * application server context information.
    */
    public javax.naming.Context getContext()
        {
        // import Component.Web.RequestContext;
        // import com.tangosol.run.component.ExecutionContext;
        // import javax.naming.Context;
        
        ExecutionContext ctxExec = getExecutionContext();
        if (ctxExec == null)
            {
            // not in execution context; use default implementation
            return super.getContext();
            }
        
        // first check to see if the context might be cached in the web tier
        int nContextScope = getContextCachingWeb();
        if (ctxExec instanceof RequestContext
                && nContextScope != RequestContext.SCOPE_NONE)
            {
            RequestContext ctxReq = (RequestContext) ctxExec;
            Context ctx = (Context) ctxReq.getAttribute(CTXCACHE_ATTRIBUTE, nContextScope);
            if (ctx != null)
                {
                return ctx;
                }
            }
        
        // next check the thread/global caching option
        int nCacheStrategy = getContextCaching();
        if (nCacheStrategy == CTXCACHE_SERVERDEFAULT)
            {
            nCacheStrategy = getServer().getContextCaching();
            }
        switch (nCacheStrategy)
            {
            case CTXCACHE_GLOBAL:
                {
                Context ctx = super.getContext();
                if (ctx != null)
                    {
                    return ctx;
                    }
                }
                break;
        
            case CTXCACHE_THREAD:
                {
                Context ctx = getContextCache();
                if (ctx != null)
                    {
                    return ctx;
                    }
                }
                break;
        
            case CTXCACHE_NONE:
                break;
        
            default:
                throw new IllegalStateException("Unsupported ContextCaching option: "
                        + getContextCaching());
            }
        
        // no context is cached; instantiate a new one
        Context ctx = instantiateInitialContext();
        setContext(ctx);
        return ctx;
        }
    
    // Accessor for the property "ContextCache"
    private javax.naming.Context getContextCache()
        {
        // import javax.naming.Context;
        
        return (Context) getContextCacheTLO().get();
        }
    
    // Accessor for the property "ContextCacheTLO"
    private com.tangosol.util.ThreadLocalObject getContextCacheTLO()
        {
        return __m_ContextCacheTLO;
        }
    
    // Accessor for the property "ContextCaching"
    public int getContextCaching()
        {
        return __m_ContextCaching;
        }
    
    // Accessor for the property "ContextCachingWeb"
    public int getContextCachingWeb()
        {
        return __m_ContextCachingWeb;
        }
    
    // Accessor for the property "ContextPathMap"
    private com.tangosol.util.ListMap getContextPathMap()
        {
        return __m_ContextPathMap;
        }
    
    public java.util.Map getContextRouteMap(String sContextPath)
        {
        // import java.util.Map;
        
        return (Map) getContextPathMap().get(sContextPath);
        }
    
    // Accessor for the property "DefaultEnvironment"
    public java.util.Hashtable getDefaultEnvironment()
        {
        // import java.util.Hashtable;
        
        Hashtable tbl = __m_DefaultEnvironment;
        if (tbl == null)
            {
            tbl = instantiateDefaultEnvironment();
            setDefaultEnvironment(tbl);
            }
        
        return tbl;
        }
    
    // Accessor for the property "ExecutionContext"
    private com.tangosol.run.component.ExecutionContext getExecutionContext()
        {
        // import com.tangosol.run.component.ExecutionContext;
        
        return (ExecutionContext) getExecutionContextTLO().get();

        }
    
    // Accessor for the property "ExecutionContextTLO"
    private com.tangosol.util.ThreadLocalObject getExecutionContextTLO()
        {
        return __m_ExecutionContextTLO;
        }
    
    // Declared at the super level
    public java.util.Locale getLocale()
        {
        // import Component.Web.RequestContext;
        // import com.tangosol.run.component.ExecutionContext;
        // import java.util.Locale;
        
        Locale locale = null;
        
        ExecutionContext ctx = getExecutionContext();
        if (ctx instanceof RequestContext)
            {
            locale = ((RequestContext) ctx).getRequest().getLocale();
            }
        
        if (locale == null)
            {
            locale = super.getLocale();
            }
        
        return locale;
        }
    
    // Declared at the super level
    public java.security.Principal getPrincipal()
        {
        // import Component.Web.RequestContext;
        // import com.tangosol.run.component.ExecutionContext;
        // import java.security.Principal;
        
        Principal principal = null;
        
        ExecutionContext ctx = getExecutionContext();
        if (ctx instanceof RequestContext)
            {
            principal = ((RequestContext) ctx).getRequest().getUserPrincipal();
            }
        // TODO ejb can get principal as well
        
        if (principal == null)
            {
            principal = super.getPrincipal();
            }
        
        return principal;
        }
    
    // Accessor for the property "RequestContext"
    public _package.component.web.RequestContext getRequestContext()
        {
        // import Component.Web.RequestContext;
        // import com.tangosol.run.component.ExecutionContext;
        
        ExecutionContext ctx = getExecutionContext();
        while (ctx != null)
            {
            if (ctx instanceof RequestContext)
                {
                return (RequestContext) ctx;
                }
            ctx = ctx.getOuterContext();
            }
        
        return null;
        }
    
    // Declared at the super level
    /**
    * Finds an application resource with a given name for a specified class. 
    * This method returns null if no resource with this name is found.  The
    * rules for searching resources associated with the specified class are
    * implemented by the defining class loader of the class. If no class is
    * specified, the system class loader is asked.
    * 
    * Example of use:
    *     Application app =(Application) Application.get_Instance();
    *     URL url = app.getResource(sName);
    * 
    * @param sName  the name of the resource
    * 
    * @return URL for the specified resource of null if the resource cannot be
    * found
    * 
    * @see java.lang.Class#getResource(String)
    */
    public java.net.URL getResource(String sName)
        {
        // import Component.Web.RequestContext;
        // import java.net.URL;
        // import java.net.MalformedURLException;
        
        URL url = super.getResource(sName);
        if (url == null)
            {
            RequestContext ctx = getRequestContext();
            if (ctx != null)
                {
                try
                    {
                    url = ctx.getServletContext().getResource(sName);
                    }
                catch (MalformedURLException e) {}
                }
            }
        
        return url;
        }
    
    // Declared at the super level
    /**
    * Finds a resource with a given name for a specified class.  This method
    * returns null if no resource with this name is found.  The rules for
    * searching resources associated with the specified class are implemented
    * by the defining class loader of the class. If no class is specified, the
    * system class loader is asked.
    * 
    * Example of use:
    *     Application app =(Application) Application.get_Instance();
    *     InputStream stream = app.getResourceAsStream(sName, get_CLASS());
    * 
    * @param sName  the name of the resource
    * @param clazz  (optional) the class that is looking for the resource
    * 
    * @return InputStream for the specified resource of null if the resource
    * cannot be found
    * 
    * @see java.lang.Class#getResourceAsStream(String)
    */
    public java.io.InputStream getResourceAsStream(String sName)
        {
        // import Component.Web.RequestContext;
        // import java.io.InputStream;
        
        InputStream stream = super.getResourceAsStream(sName);
        if (stream == null)
            {
            RequestContext ctx = getRequestContext();
            if (ctx != null)
                {
                stream = ctx.getServletContext().getResourceAsStream(sName);
                }
            }
        
        return stream;
        }
    
    // Accessor for the property "Server"
    public _package.component.web.Server getServer()
        {
        // import Component.Web.Server;
        
        Server server = __m_Server;
        
        if (server == null)
            {
            server = instantiateServer();
            setServer(server);
            }
        
        return server;
        }
    
    protected java.util.Hashtable instantiateDefaultEnvironment()
        {
        // import java.util.Hashtable;
        
        // default implementation:  empty environment
        return new Hashtable(7);
        }
    
    // Declared at the super level
    protected javax.naming.Context instantiateInitialContext()
        {
        // import com.tangosol.util.WrapperException;
        // import java.util.Hashtable;
        // import javax.naming.InitialContext;
        // import javax.naming.NamingException;
        
        if (isProcessing())
            {
            Hashtable tblEnv = getDefaultEnvironment();
        
        /* TODO - where do we get user/password from, or are they filled in for us?
            String sName = getLoginName();
            if (sName != null)
                {
                // include authentification information
                tblEnv = (Hashtable) tblEnv.clone();
                tblEnv.put(Context.SECURITY_PRINCIPAL, sName);
        
                String sPassword = getLoginPassword();
                if (sPassword != null)
                    {
                    tblEnv.put(Context.SECURITY_CREDENTIALS, sPassword);
                    }
                }
        */
        
            try
                {
                if (tblEnv == null || tblEnv.isEmpty())
                    {
                    return new InitialContext();
                    }
                else
                    {
                    return new InitialContext(tblEnv);
                    }
                }
            catch (NamingException e)
                {
                throw new WrapperException(e);
                }
            }
        else
            {
            // not in request context; use default implementation
            return super.instantiateInitialContext();
            }
        }
    
    protected _package.component.web.Server instantiateServer()
        {
        // import Component.Web.Server;
        
        // TODO
        return new Server();
        }
    
    // Accessor for the property "EnableConsole"
    public boolean isEnableConsole()
        {
        return __m_EnableConsole;
        }
    
    // Accessor for the property "EnableDebugEcho"
    public boolean isEnableDebugEcho()
        {
        return __m_EnableDebugEcho;
        }
    
    // Accessor for the property "EnableLogging"
    public boolean isEnableLogging()
        {
        return __m_EnableLogging;
        }
    
    // Accessor for the property "Processing"
    public boolean isProcessing()
        {
        return getExecutionContext() != null;
        }
    
    // Accessor for the property "ProcessingJspTag"
    public boolean isProcessingJspTag()
        {
        // import Component.Web.RequestContext.JspTagContext;
        
        return getExecutionContext() instanceof JspTagContext;
        }
    
    // Accessor for the property "ProcessingServlet"
    public boolean isProcessingServlet()
        {
        // import Component.Web.RequestContext.ServletRequestContext;
        
        return getExecutionContext() instanceof ServletRequestContext;
        }
    
    // Accessor for the property "ProcessingWeb"
    public boolean isProcessingWeb()
        {
        // import Component.Web.RequestContext;
        
        return getExecutionContext() instanceof RequestContext;
        }
    
    /**
    * Register the specified ExecutionContext object
    */
    public void registerContext(com.tangosol.run.component.ExecutionContext ctx)
        {
        // import Component.Web.RequestContext;
        // import com.tangosol.run.component.ExecutionContext;
        
        ExecutionContext ctxOuter = null;
        
        if (ctx instanceof RequestContext)
            {
            ctxOuter = ((RequestContext) ctx).getCallingContext();
            }
        
        if (ctxOuter == null)
            {
            ctxOuter = getExecutionContext();
            }
        
        if (ctxOuter != null)
            {
            try
                {
                ctxOuter.executionSuspended(ctx);
                }
            catch (Throwable e)
                {
                _trace("Application.Enterprise:  Unhandled exception invoking"
                        + " ExecutionContext.executionSuspended() on \""
                        + ctxOuter + "\":");
                _trace(e);
                _trace("(Exception has been ignored.)");
                }
            }
        
        setExecutionContext(ctx);
        
        try
            {
            ctx.executionInitialized(ctxOuter);
            }
        catch (Throwable e)
            {
            _trace("Application.Enterprise:  Unhandled exception invoking"
                    + " ExecutionContext.executionInitialized() on \""
                    + ctx + "\":");
            _trace(e);
            _trace("(Exception has been ignored.)");
            }

        }
    
    public void resumeContext(com.tangosol.run.component.ExecutionContext ctxOuter)
        {
        // import com.tangosol.run.component.ExecutionContext;
        
        ExecutionContext ctx = getExecutionContext();
        int cPop = 0;
        while (ctx != null)
            {
            if (ctx.equals(ctxOuter))
                {
                break;
                }
            cPop++;
            ctx = ctx.getOuterContext();
            }
        
        if (ctx == null)
            {
            // could not find the specified context
            throw new IllegalArgumentException("Application.Enterprise: "
                        + " The specified context to resume is not registered!"
                        + "(\"" + ctxOuter + "\")");
            }
        
        // unregister contexts until we have popped off "up to" the specified context
        for (int i = 0; i < cPop; ++i)
            {
            unregisterContext();
            }
        }
    
    // Declared at the super level
    public void setContext(javax.naming.Context ctx)
        {
        // import Component.Web.RequestContext;
        // import com.tangosol.run.component.ExecutionContext;
        // import javax.naming.Context;
        
        ExecutionContext ctxExec = getExecutionContext();
        if (ctxExec == null)
            {
            // not in execution context; use default implementation
            super.setContext(ctx);
            return;
            }
        
        // application may cache the context in the web tier
        int nContextScope = getContextCachingWeb();
        if (ctxExec instanceof RequestContext
                && nContextScope != RequestContext.SCOPE_NONE)
            {
            RequestContext ctxReq = (RequestContext) ctxExec;
            ctxReq.setAttribute(CTXCACHE_ATTRIBUTE, ctx, nContextScope);
            return;
            }
        
        // check the thread/global caching option
        int nCacheStrategy = getContextCaching();
        if (nCacheStrategy == CTXCACHE_SERVERDEFAULT)
            {
            nCacheStrategy = getServer().getContextCaching();
            }
        switch (nCacheStrategy)
            {
            case CTXCACHE_GLOBAL:
                super.setContext(ctx);
                return;
        
            case CTXCACHE_THREAD:
                setContextCache(ctx);
                return;
        
            case CTXCACHE_NONE:
                break;
        
            default:
                throw new IllegalStateException("Unsupported ContextCaching option: "
                        + getContextCaching());
            }
        }
    
    // Accessor for the property "ContextCache"
    private void setContextCache(javax.naming.Context ctx)
        {
        getContextCacheTLO().set(ctx);
        }
    
    // Accessor for the property "ContextCacheTLO"
    private void setContextCacheTLO(com.tangosol.util.ThreadLocalObject tlo)
        {
        __m_ContextCacheTLO = tlo;
        }
    
    // Accessor for the property "ContextCaching"
    public void setContextCaching(int pContextCaching)
        {
        __m_ContextCaching = pContextCaching;
        }
    
    // Accessor for the property "ContextCachingWeb"
    public void setContextCachingWeb(int pContextCachingWeb)
        {
        __m_ContextCachingWeb = pContextCachingWeb;
        }
    
    // Accessor for the property "ContextPathMap"
    private void setContextPathMap(com.tangosol.util.ListMap map)
        {
        __m_ContextPathMap = map;
        }
    
    public void setContextRouteMap(String sContextPath, java.util.Map map)
        {
        // import java.util.Map;
        
        Map mapPath = getContextPathMap();
        synchronized (mapPath)
            {
            mapPath.put(sContextPath, map);
            }
        }
    
    // Accessor for the property "DefaultEnvironment"
    public void setDefaultEnvironment(java.util.Hashtable tbl)
        {
        __m_DefaultEnvironment = tbl;
        }
    
    // Accessor for the property "EnableConsole"
    public void setEnableConsole(boolean pEnableConsole)
        {
        __m_EnableConsole = pEnableConsole;
        }
    
    // Accessor for the property "EnableDebugEcho"
    public void setEnableDebugEcho(boolean pEnableDebugEcho)
        {
        __m_EnableDebugEcho = pEnableDebugEcho;
        }
    
    // Accessor for the property "EnableLogging"
    public void setEnableLogging(boolean pEnableLogging)
        {
        __m_EnableLogging = pEnableLogging;
        }
    
    // Accessor for the property "ExecutionContext"
    private void setExecutionContext(com.tangosol.run.component.ExecutionContext ctx)
        {
        getExecutionContextTLO().set(ctx);
        }
    
    // Accessor for the property "ExecutionContextTLO"
    private void setExecutionContextTLO(com.tangosol.util.ThreadLocalObject pExecutionContextTLO)
        {
        __m_ExecutionContextTLO = pExecutionContextTLO;
        }
    
    // Accessor for the property "Server"
    public void setServer(_package.component.web.Server server)
        {
        __m_Server = server;
        }
    
    protected void unregisterContext()
        {
        // import Component.Web.RequestContext;
        // import com.tangosol.run.component.ExecutionContext;
        
        ExecutionContext ctx = getExecutionContext();
        if (ctx == null)
            {
            throw new IllegalStateException("Application.Enterprise: "
                + " No current context to unregister!");
            }
        
        ExecutionContext ctxOuter = ctx.getOuterContext();
        
        try
            {
            ctx.executionTerminated(ctxOuter);
            }
        catch (Throwable e)
            {
            _trace("Application.Enterprise:  Unhandled exception invoking"
                    + " ExecutionContext.executionTerminated() on \""
                    + ctx + "\":");
            _trace(e);
            _trace("(Exception has been ignored.)");
            }
        
        setExecutionContext(ctxOuter);
        
        if (ctxOuter == null)
            {
            // if this is the last execution context that is terminating,
            // destroy the cached naming context
            if (getContextCaching() == CTXCACHE_THREAD)
                {
                setContextCache(null);
                }
            }
        else
            {
            try
                {
                ctxOuter.executionResumed(ctx);
                }
            catch (Throwable e)
                {
                _trace("Application.Enterprise:  Unhandled exception invoking"
                        + " ExecutionContext.executionResumed() on \""
                        + ctxOuter + "\":");
                _trace(e);
                _trace("(Exception has been ignored.)");
                }
            }
        }
    
    public void unregisterContext(com.tangosol.run.component.ExecutionContext ctxOuter)
        {
        // unregister contexts until we have popped off the specified context
        
        resumeContext(ctxOuter);
        
        unregisterContext();

        }
    }
