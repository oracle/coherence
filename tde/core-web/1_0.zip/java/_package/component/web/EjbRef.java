/* Class
*     _package.component.web.EjbRef
*/

package _package.component.web;

import _package.component.Application;
import _package.component.Ejb;
import _package.component.web.RequestContext;
import com.tangosol.util.WrapperException;
import java.lang.reflect.Method;
import javax.ejb.SessionBean;

public class EjbRef
        extends    _package.component.Web
    {
    // Fields declarations
    
    /**
    * Property Createable
    *
    */
    
    /**
    * Property EjbClass
    *
    */
    private static final Class __s_EjbClass;
    
    /**
    * Property METHOD_CREATE
    *
    */
    public static final String METHOD_CREATE = "ejbCreate";
    
    /**
    * Property RequestScope
    *
    */
    
    /**
    * Property Role
    *
    */
    
    /**
    * Property ROLE_CONTROLLER
    *
    */
    public static final int ROLE_CONTROLLER = 2;
    
    /**
    * Property ROLE_DUAL
    *
    */
    public static final int ROLE_DUAL = 3;
    
    /**
    * Property ROLE_MODEL
    *
    */
    public static final int ROLE_MODEL = 1;
    
    // Static initializer
    static
        {
        try
            {
            __s_EjbClass = null;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public EjbRef()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public EjbRef(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant EjbClass
    public Class getEjbClass()
        {
        return null;
        }
    
    // Getter for virtual constant RequestScope
    public boolean isRequestScope()
        {
        return true;
        }
    
    // Getter for virtual constant Role
    public int getRole()
        {
        return 2;
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new EjbRef();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/EjbRef".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    protected void configureEjb(_package.component.Ejb ejb)
        {
        // import Component.Ejb;
        // import com.tangosol.util.WrapperException;
        // import java.lang.reflect.Method;
        
        // the default implementation uses the no-parameter ejbCreate method
        try
            {
            Method method = ejb.getClass().getMethod(METHOD_CREATE, new Class [0]);
            method.invoke(ejb, new Object[0]);
            }
        catch (Exception e)
            {
            throw e instanceof RuntimeException ? (RuntimeException) e
                                                : new WrapperException(e);
            }
        }
    
    public _package.component.Ejb getEjb()
        {
        // import Component.Application;
        // import Component.Ejb;
        // import Component.Web.RequestContext;
        // import javax.ejb.SessionBean;
        
        if (isCreateable())
            {
            Ejb ejb = instantiateEjb();
            configureEjb(ejb);
        
            // session beans need to be released at the end of the request (assuming they
            // are marked as request scope)
            if (isRequestScope() && ejb instanceof SessionBean)
                {
                throw new UnsupportedOperationException("TODO: Cam");
                // WebSite app = (WebSite) Application.get_Instance();
                // app.getRequestContext().registerEjb((SessionBean) ejb);
                }
        
            return ejb;
            }
        else
            {
            return null;
            }
        }
    
    protected _package.component.Ejb instantiateEjb()
        {
        // import Component.Ejb;
        // import com.tangosol.util.WrapperException;
        
        try
            {
            Class clz = getEjbClass();
            return (Ejb) clz.newInstance();
            }
        catch (Exception e)
            {
            throw e instanceof RuntimeException ? (RuntimeException) e
                                                : new WrapperException(e);
            }
        }
    
    // Accessor for the property "Createable"
    public boolean isCreateable()
        {
        // default implementation uses a no-parameter create, so there are no dependencies
        return true;
        }
    }
