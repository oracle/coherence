/* Class
*     _package.component.web.requestContext.JspTagContext
*/

package _package.component.web.requestContext;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest; // as Request
import javax.servlet.http.HttpServletResponse; // as Response

/**
* To configure the JspTagContext, set the PageContext attribute.
*/
public class JspTagContext
        extends    _package.component.web.RequestContext
    {
    // Fields declarations
    
    /**
    * Property ErrorText
    *
    */
    private String __m_ErrorText;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("CookieConfig", _package.component.web.RequestContext$CookieConfig.get_CLASS());
        }
    
    // Default constructor
    public JspTagContext()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JspTagContext(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JspTagContext();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/requestContext/JspTagContext".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Accessor for the property "ErrorText"
    public String getErrorText()
        {
        return __m_ErrorText;
        }
    
    // Declared at the super level
    public void sendError(int nStatus, String sDesc)
        {
        if (!isError())
            {
            setErrorText("Code=" + nStatus + ", Description="
                    + (sDesc == null ? "<no description>" : sDesc));
            }
        
        super.sendError(nStatus, sDesc);
        }
    
    // Accessor for the property "ErrorText"
    public void setErrorText(String pErrorText)
        {
        __m_ErrorText = pErrorText;
        }
    
    // Declared at the super level
    public void setOuterContext(com.tangosol.run.component.ExecutionContext ctx)
        {
        super.setOuterContext(ctx);
        }
    
    // Declared at the super level
    public void setPageContext(javax.servlet.jsp.PageContext ctx)
        {
        // import javax.servlet.ServletConfig;
        // import javax.servlet.ServletContext;
        // import javax.servlet.http.HttpServletRequest as Request;
        // import javax.servlet.http.HttpServletResponse as Response;
        
        super.setPageContext(ctx);
        
        Request        req  = null;
        Response       resp = null;
        ServletConfig  cfg  = null;
        ServletContext ctxS = null;
        
        if (ctx != null)
            {
            req  = (Request)  ctx.getRequest();
            resp = (Response) ctx.getResponse();
            cfg  = ctx.getServletConfig();
            ctxS = ctx.getServletContext();
            }
        
        setRequest(req);
        setResponse(resp);
        setServletConfig(cfg);
        setServletContext(ctxS);
        }
    }
