/* Class
*     _package.component.web.requestContext.ServletRequestContext
*/

package _package.component.web.requestContext;

import com.tangosol.util.Base;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest; // as Request

/**
* To configure the ServletRequestContext, set the Servlet, Request, and
* Response properties.
*/
public class ServletRequestContext
        extends    _package.component.web.RequestContext
    {
    // Fields declarations
    
    /**
    * Property PREFIX_EVENT
    *
    */
    public static final String PREFIX_EVENT = "submit";
    
    /**
    * Property ROUTE_PARENT
    *
    */
    public static final String ROUTE_PARENT = "..";
    
    /**
    * Property RouteList
    *
    */
    private java.util.List __m_RouteList;
    
    /**
    * Property Servlet
    *
    */
    private transient _package.component.web.http.Servlet __m_Servlet;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("CookieConfig", _package.component.web.RequestContext$CookieConfig.get_CLASS());
        }
    
    // Default constructor
    public ServletRequestContext()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ServletRequestContext(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ServletRequestContext();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/requestContext/ServletRequestContext".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    public java.util.List ensureRouteList()
        {
        // import java.util.List;
        
        List list = getRouteList();
        
        if (list == null)
            {
            list = instantiateRouteList();
            setRouteList(list);
            }
        
        return list;
        }
    
    // Accessor for the property "RouteList"
    public java.util.List getRouteList()
        {
        return __m_RouteList;
        }
    
    // Accessor for the property "Servlet"
    public _package.component.web.http.Servlet getServlet()
        {
        return __m_Servlet;
        }
    
    protected java.util.List instantiateRouteList()
        {
        // import com.tangosol.util.Base;
        // import java.util.Enumeration;
        // import javax.servlet.http.HttpServletRequest as Request;
        
        // use the elements of the request "path" to determine what child to forward
        // the event to, e.g. "/product-123.display.ts"
        Request request = getRequest();
        String  sPath   = request.getPathInfo();
        
        // WebLogic can return null
        if (sPath == null)
            {
            sPath = request.getServletPath();
            }
        
        // get the elements of the path (delimited by '/' and '.')
        int cchPath = sPath.length();
        int ofStart = (cchPath > 0 && sPath.charAt(0) == '/') ? 1 : 0;
        int ofEnd   = (cchPath > 0 && sPath.charAt(cchPath - 1) == '/') ? cchPath - 1 : cchPath;
        
        sPath = ofEnd > ofStart ? sPath.substring(ofStart, ofEnd).replace('/', '.') : "";
        
        // check for an extension used to map to the servlet; remove it if it exists
        sPath = removeServletSuffix(sPath);
        
        // form actions can use a "dummy" path (e.g. "submit.ts") just to invoke the
        // servlet, letting the input control, such as a submit button, identify the
        // entire routing path
        if (sPath.equals(PREFIX_EVENT))
            {
            sPath = "";
            }
        cchPath = sPath.length();
        
        // scan for the first "submit" parameter to supplement the path information
        // (note:  this is for form actions that use submit or image buttons etc.)
        final String sPrefix = PREFIX_EVENT + '.';
        for (Enumeration enum = request.getParameterNames(); enum.hasMoreElements(); )
            {
            String sName = (String) enum.nextElement();
            if (sName.startsWith(sPrefix))
                {
                sName   = sName.substring(sPrefix.length());
                sPath   = cchPath == 0 ? sName : sPath + '.' + sName;
                cchPath = sPath.length();
                break;
                }
            }
        
        String[] asSegment = cchPath > 0 ? Base.parseDelimitedString(sPath, '.') : null;
        return makeRouteList(asSegment);
        }
    
    public static java.util.List makeRouteList(String[] asRoutingSegments)
        {
        // import java.util.Arrays;
        // import java.util.Collections;
        // import java.util.LinkedList;
        
        if (asRoutingSegments == null || asRoutingSegments.length == 0)
            {
            return Collections.EMPTY_LIST;
            }
        else
            {
            return new LinkedList(Arrays.asList(asRoutingSegments));
            }
        }
    
    public String removeServletSuffix(String sPath)
        {
        if (sPath != null && sPath.length() > 0)
            {
            String sAnonSuffix = getServlet().getAnonymousExtension();
            if (sAnonSuffix != null && sPath.endsWith(sAnonSuffix))
                {
                return sPath.substring(0, sPath.length() - sAnonSuffix.length());
                }
        
            String sAuthSuffix = getServlet().getAuthenticatingExtension();
            if (sAuthSuffix != null && sPath.endsWith(sAuthSuffix))
                {
                return sPath.substring(0, sPath.length() - sAuthSuffix.length());
                }
            }
        
        return sPath;
        }
    
    // Accessor for the property "RouteList"
    public void setRouteList(java.util.List pRouteList)
        {
        __m_RouteList = pRouteList;
        }
    
    // Accessor for the property "Servlet"
    public void setServlet(_package.component.web.http.Servlet servlet)
        {
        // import javax.servlet.ServletConfig;
        // import javax.servlet.ServletContext;
        
        __m_Servlet = (servlet);
        
        ServletConfig  cfg = null;
        ServletContext ctx = null;
        
        if (servlet != null)
            {
            cfg = servlet.getServletConfig();
            ctx = cfg.getServletContext();
            }
        
        setServletConfig(cfg);
        setServletContext(ctx);
        }
    }
