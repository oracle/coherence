/* Class
*     _package.component.web.UrlFieldEncoder
*/

package _package.component.web;

import _package.component.web.urlFieldEncoder.Array; // as ArrayEncoder
import _package.component.web.urlFieldEncoder.Class; // as ClassEncoder
import _package.component.web.urlFieldEncoder.primitive.Boolean; // as BooleanEncoder
import _package.component.web.urlFieldEncoder.primitive.Byte; // as ByteEncoder
import _package.component.web.urlFieldEncoder.primitive.Char; // as CharEncoder
import _package.component.web.urlFieldEncoder.primitive.Double; // as DoubleEncoder
import _package.component.web.urlFieldEncoder.primitive.Float; // as FloatEncoder
import _package.component.web.urlFieldEncoder.primitive.Int; // as IntEncoder
import _package.component.web.urlFieldEncoder.primitive.Long; // as LongEncoder
import _package.component.web.urlFieldEncoder.primitive.Short; // as ShortEncoder
import com.tangosol.util.SafeHashMap;
import java.util.Map;

/**
* This component is used to convert a field of a URL ID to and from a Java
* object.  An example of a URL ID field is a string of digits is the encoded
* for of an Integer object, and decodes to an Integer object.
* 
* For URI encoding rules, see http://www.ietf.org/rfc/rfc2396.txt. Addtionally,
* the following "mark" characters are reserved for special use:
* 
* -   delimits between a name and an id and between id parts
* .   delimits between name sections
* !   signifies a null value
* ~   delimits between array elements
*/
public abstract class UrlFieldEncoder
        extends    _package.component.Web
    {
    // Fields declarations
    
    /**
    * Property Cacheable
    *
    */
    
    /**
    * Property EncoderCache
    *
    * A cache of encoder objects, used by getEncoder().
    */
    private static transient java.util.Map __s_EncoderCache;
    
    /**
    * Property FieldClass
    *
    */
    private Class __m_FieldClass;
    
    // Initializing constructor
    public UrlFieldEncoder(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant Cacheable
    public boolean isCacheable()
        {
        return true;
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/UrlFieldEncoder".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    protected void configure()
        {
        }
    
    public Object decode(String sId)
        {
        return null;
        }
    
    public String encode(Object o)
        {
        return null;
        }
    
    public static UrlFieldEncoder getEncoder(Class clz)
        {
        // import java.util.Map;
        // import Component.Web.UrlFieldEncoder.Array as ArrayEncoder;
        // import Component.Web.UrlFieldEncoder.Class as ClassEncoder;
        // import Component.Web.UrlFieldEncoder.Primitive.Boolean as BooleanEncoder;
        // import Component.Web.UrlFieldEncoder.Primitive.Byte as ByteEncoder;
        // import Component.Web.UrlFieldEncoder.Primitive.Char as CharEncoder;
        // import Component.Web.UrlFieldEncoder.Primitive.Double as DoubleEncoder;
        // import Component.Web.UrlFieldEncoder.Primitive.Float as FloatEncoder;
        // import Component.Web.UrlFieldEncoder.Primitive.Int as IntEncoder;
        // import Component.Web.UrlFieldEncoder.Primitive.Long as LongEncoder;
        // import Component.Web.UrlFieldEncoder.Primitive.Short as ShortEncoder;
        
        Map map = getEncoderCache();
        UrlFieldEncoder encoder = (UrlFieldEncoder) map.get(clz);
        
        if (encoder == null && !map.containsKey(clz))
            {
            _assert(clz != null);
        
            if (clz.isArray())
                {
                encoder = getEncoder(clz.getComponentType());
                if (encoder != null)
                    {
                    ArrayEncoder arrayEncoder = new ArrayEncoder();
                    arrayEncoder.setElementEncoder(encoder);
                    encoder = arrayEncoder;
                    }
                }
            else if (clz.isPrimitive())
                {
                switch (clz.getName().charAt(0))
                    {
                    case 'b':
                        if (clz == Boolean.TYPE)
                            {
                            encoder = new BooleanEncoder();
                            }
                        else if (clz == Byte.TYPE)
                            {
                            encoder = new ByteEncoder();
                            }
                        break;
        
                    case 'c':
                        if (clz == Character.TYPE)
                            {
                            encoder = new CharEncoder();
                            }
                        break;
        
                    case 'd':
                        if (clz == Double.TYPE)
                            {
                            encoder = new DoubleEncoder();
                            }
                        break;
        
                    case 'f':
                        if (clz == Float.TYPE)
                            {
                            encoder = new FloatEncoder();
                            }
                        break;
        
                    case 'i':
                        if (clz == Integer.TYPE)
                            {
                            encoder = new IntEncoder();
                            }
                        break;
        
                    case 'l':
                        if (clz == Long.TYPE)
                            {
                            encoder = new LongEncoder();
                            }
                        break;
        
                    case 's':
                        if (clz == Short.TYPE)
                            {
                            encoder = new ShortEncoder();
                            }
                        break;
                    }
                }
            else
                {
                String sName = clz.getName().replace('.', '_').replace('$', '_');
                sName = "Component.Web.UrlFieldEncoder.Class.L" + sName;
                try
                    {
                    encoder = (ClassEncoder) _newInstance(sName);
                    }
                catch (Exception e)
                    {
                    }
                }
        
            if (encoder != null)
                {
                encoder.setFieldClass(clz);
                encoder.configure();
        
                do
                    {
                    UrlFieldEncoder substitute = encoder.resolveEncoder();
                    if (encoder == substitute)
                        {
                        break;
                        }
        
                    encoder = substitute;
                    }
                while (encoder != null);
                }
        
            if (encoder == null || encoder.isCacheable())
                {
                map.put(clz, encoder);
                }
            }
        
        return encoder;
        }
    
    // Accessor for the property "EncoderCache"
    private static java.util.Map getEncoderCache()
        {
        // import java.util.Map;
        // import com.tangosol.util.SafeHashMap;
        
        Map map = __s_EncoderCache;
        
        if (map == null)
            {
            map = new SafeHashMap();
            setEncoderCache(map);
            }
        
        return map;
        }
    
    // Accessor for the property "FieldClass"
    public Class getFieldClass()
        {
        return __m_FieldClass;
        }
    
    protected UrlFieldEncoder resolveEncoder()
        {
        return this;
        }
    
    // Accessor for the property "EncoderCache"
    private static void setEncoderCache(java.util.Map map)
        {
        __s_EncoderCache = map;
        }
    
    // Accessor for the property "FieldClass"
    private void setFieldClass(Class clz)
        {
        __m_FieldClass = clz;
        }
    }
