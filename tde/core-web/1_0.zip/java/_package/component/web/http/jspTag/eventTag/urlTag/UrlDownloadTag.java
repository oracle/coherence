/* Class
*     _package.component.web.http.jspTag.eventTag.urlTag.UrlDownloadTag
*/

package _package.component.web.http.jspTag.eventTag.urlTag;

import com.tangosol.util.WrapperException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.servlet.http.HttpServletResponse; // as Response

public class UrlDownloadTag
        extends    _package.component.web.http.jspTag.eventTag.UrlTag
    {
    // Fields declarations
    
    /**
    * Property BlockSize
    *
    */
    
    /**
    * Property MimeType
    *
    * The mime type for the file being transfered to the client.  For example,
    * a .zip extension in Windows has a mime type of
    * "application/x-zip-compressed".
    */
    private String __m_MimeType;
    
    /**
    * Property SourcePath
    *
    * If the SourcePath is specified and the SourceStream is null, the default
    * implementation for getSourceStream will open a FileInputStream on the
    * path specified by SourcePath.
    */
    private String __m_SourcePath;
    
    /**
    * Property SourceStream
    *
    * The stream from which the download is read.
    */
    private transient java.io.InputStream __m_SourceStream;
    
    /**
    * Property SuggestedFileName
    *
    * This is the name that will be suggested in a "save download as" dialog in
    * the browser.
    */
    private String __m_SuggestedFileName;
    
    // Default constructor
    public UrlDownloadTag()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public UrlDownloadTag(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setDirty(false);
            setOut(null);
            setSkipBody(false);
            setTerminatePage(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant BlockSize
    public int getBlockSize()
        {
        return 512;
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new UrlDownloadTag();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/http/jspTag/eventTag/urlTag/UrlDownloadTag".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    protected Object evaluate()
        {
        return buildUrlDownload(getSuggestedFileName());
        }
    
    // Accessor for the property "MimeType"
    public String getMimeType()
        {
        return __m_MimeType;
        }
    
    // Accessor for the property "SourcePath"
    public String getSourcePath()
        {
        return __m_SourcePath;
        }
    
    // Accessor for the property "SourceStream"
    public java.io.InputStream getSourceStream()
        {
        // import com.tangosol.util.WrapperException;
        // import java.io.File;
        // import java.io.FileInputStream;
        // import java.io.InputStream;
        // import java.io.IOException;
        
        InputStream stream = __m_SourceStream;
        if (stream == null)
            {
            String sPath = getSourcePath();
            if (sPath != null)
                {
                File file = new File(sPath);
                if (file.exists() && file.isFile() && file.canRead())
                    {
                    try
                        {
                        stream = new FileInputStream(file);
                        }
                    catch (IOException e)
                        {
                        onError(SC_INTERNAL_SERVER_ERROR, e.getMessage());
                        }
                    setSourceStream(stream);
                    }
                else
                    {
                    _trace("UrlDownloadTag.getSourceStream:  Invalid path " + sPath, 1);
                    onError(SC_NOT_FOUND, getSuggestedFileName());
                    }
                }
            }
        
        return stream;
        }
    
    // Accessor for the property "SuggestedFileName"
    public String getSuggestedFileName()
        {
        String sName = __m_SuggestedFileName;
        if (sName != null)
            {
            return sName;
            }
        
        String sPath = getSourcePath();
        if (sPath != null)
            {
            sPath = sPath.substring(sPath.lastIndexOf('/') + 1);
            int of = sPath.lastIndexOf('.');
            if (of > 0)
                {
                sPath = sPath.substring(0, of);
                }
            return sPath;
            }
        
        return "download";
        }
    
    // Declared at the super level
    public void onRequest(_package.component.web.requestContext.ServletRequestContext ctx)
            throws javax.servlet.ServletException
        {
        // import java.io.File;
        // import java.io.IOException;
        // import java.io.InputStream;
        // import java.io.FileInputStream;
        // import java.io.OutputStream;
        // import javax.servlet.http.HttpServletResponse as Response;
        
        try
            {
            Response     response  = ctx.getResponse();
            String       sMime     = getMimeType();
            InputStream  streamIn  = getSourceStream();
            OutputStream streamOut = response.getOutputStream();
            int          cbBlock   = getBlockSize();
        
            // validate that the download has enough data to get going
            if (sMime == null)
                {
                onError(SC_INTERNAL_SERVER_ERROR, "Missing mime type");
                }
            if (streamIn == null)
                {
                onError(SC_INTERNAL_SERVER_ERROR, "Missing download contents");
                }
            if (streamOut == null)
                {
                onError(SC_INTERNAL_SERVER_ERROR, "Missing download stream");
                }
        
            // default block size
            if (cbBlock <= 0)
                {
                cbBlock = 512;
                }
            byte[] abBlock = new byte[cbBlock];
        
            response.setContentType(getMimeType());
        
            int cbRead = 0;
            do
                {
                cbRead = streamIn.read(abBlock);
        
                if (cbRead > 0)
                    {
                    streamOut.write(abBlock, 0, cbRead);
                    }
                }
            while (cbRead >= 0);
        
            streamOut.flush();
            streamOut.close();
        
            streamIn.close();
            }
        catch (IOException e)
            {
            onError(SC_INTERNAL_SERVER_ERROR, "IOException (" + e.getClass().getName() + ") in download:  " + e.getMessage());
            }
        }
    
    // Accessor for the property "MimeType"
    public void setMimeType(String sMime)
        {
        __m_MimeType = sMime;
        }
    
    // Accessor for the property "SourcePath"
    public void setSourcePath(String sPath)
        {
        __m_SourcePath = sPath;
        }
    
    // Accessor for the property "SourceStream"
    public void setSourceStream(java.io.InputStream stream)
        {
        __m_SourceStream = stream;
        }
    
    // Accessor for the property "SuggestedFileName"
    public void setSuggestedFileName(String sFile)
        {
        __m_SuggestedFileName = sFile;
        }
    }
