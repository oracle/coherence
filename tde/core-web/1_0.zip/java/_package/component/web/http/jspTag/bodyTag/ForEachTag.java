/* Class
*     _package.component.web.http.jspTag.bodyTag.ForEachTag
*/

package _package.component.web.http.jspTag.bodyTag;

import com.tangosol.util.IteratorEnumerator;
import com.tangosol.util.NullImplementation;
import com.tangosol.util.SimpleEnumerator;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.NoSuchElementException;
import javax.servlet.jsp.tagext.BodyTag;

public class ForEachTag
        extends    _package.component.web.http.jspTag.BodyTag
        implements java.util.Iterator
    {
    // Fields declarations
    
    /**
    * Property Array
    *
    */
    
    /**
    * Property Collection
    *
    */
    
    /**
    * Property Enumeration
    *
    */
    private java.util.Enumeration __m_Enumeration;
    
    /**
    * Property Iterator
    *
    */
    private java.util.Iterator __m_Iterator;
    
    // Default constructor
    public ForEachTag()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ForEachTag(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setBodyContent(null);
            setDirty(false);
            setIterator(null);
            setOut(null);
            setRepeatBody(true);
            setSkipBody(false);
            setTerminatePage(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant TagPrefix
    public String getTagPrefix()
        {
        return "ForEach";
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new ForEachTag();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/http/jspTag/bodyTag/ForEachTag".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void _imports()
        {
        // import com.tangosol.util.IteratorEnumerator;
        // import com.tangosol.util.NullImplementation;
        // import com.tangosol.util.SimpleEnumerator;
        // import java.util.Collection;
        // import java.util.Enumeration;
        // import java.util.Iterator;
        // import java.util.NoSuchElementException;
        // import javax.servlet.jsp.tagext.BodyTag;

        }
    
    // Declared at the super level
    public int doAfterBody()
            throws javax.servlet.jsp.JspException
        {
        int nResult = super.doAfterBody();
        
        // either load the next current item or clear the current item
        setResult(nResult == BodyTag.EVAL_BODY_TAG ? next() : null);
        
        return nResult;
        }
    
    // Accessor for the property "Enumeration"
    public java.util.Enumeration getEnumeration()
        {
        Iterator iterator = getIterator();
        if (iterator == null)
            {
            return null;
            }
        else if (iterator instanceof Enumeration)
            {
            return (Enumeration) iterator;
            }
        else
            {
            return new IteratorEnumerator(iterator);
            }
        }
    
    // Accessor for the property "Iterator"
    public java.util.Iterator getIterator()
        {
        return __m_Iterator;
        }
    
    // Declared at the super level
    public String getResultViewName()
        {
        String sName = super.getResultViewName();
        
        if (sName == null)
            {
            sName = getImpliedName();
            }
        
        return sName;
        }
    
    // From interface: java.util.Iterator
    public boolean hasNext()
        {
        Iterator iterator = getIterator();
        return iterator != null && iterator.hasNext();
        }
    
    // Declared at the super level
    public boolean isRepeatBody()
        {
        return super.isRepeatBody() && hasNext();
        }
    
    // Declared at the super level
    protected boolean isSkipBody()
        {
        return super.isSkipBody() || !hasNext();
        }
    
    // From interface: java.util.Iterator
    public Object next()
        {
        Iterator iterator = getIterator();
        if (iterator == null)
            {
            throw new NoSuchElementException();
            }
        return iterator.next();
        }
    
    // Declared at the super level
    public void onInitBody()
            throws javax.servlet.jsp.JspException
        {
        super.onInitBody();
        
        // load the first item ("prime the loop")
        setResult(next());
        }
    
    // Declared at the super level
    public void onStartTag()
            throws javax.servlet.jsp.JspException
        {
        super.onStartTag();
        
        // get value to use as basis for iteration
        Object o = evaluate();
        if (o == null)
            {
            setSkipBody(true);
            }
        else if (o instanceof Iterator)
            {
            setIterator((Iterator) o);
            }
        else if (o instanceof Enumeration)
            {
            setEnumeration((Enumeration) o);
            }
        else if (o instanceof Collection)
            {
            setCollection((Collection) o);
            }
        else if (o instanceof Object[])
            {
            setArray((Object[]) o);
            }
        else
            {
            throw new RuntimeException("onStartTag():  The result of evaluate() is not supported ("
                    + o.getClass() + ")");
            }
        }
    
    // From interface: java.util.Iterator
    public void remove()
        {
        throw new UnsupportedOperationException();
        }
    
    // Accessor for the property "Array"
    public void setArray(Object[] ao)
        {
        setIterator(ao == null || ao.length == 0 ? NullImplementation.getIterator()
                                                 : (Iterator) new SimpleEnumerator(ao));
        }
    
    // Accessor for the property "Collection"
    public void setCollection(java.util.Collection collection)
        {
        setIterator(collection.iterator());
        }
    
    // Accessor for the property "Enumeration"
    public void setEnumeration(java.util.Enumeration enum)
        {
        if (enum == null)
            {
            setIterator(null);
            }
        else if (enum instanceof Iterator)
            {
            setIterator((Iterator) enum);
            }
        else
            {
            setIterator(new SimpleEnumerator(enum));
            }
        }
    
    // Accessor for the property "Iterator"
    public void setIterator(java.util.Iterator iterator)
        {
        __m_Iterator = iterator;
        }
    }
