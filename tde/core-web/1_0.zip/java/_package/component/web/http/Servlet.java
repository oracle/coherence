/* Class
*     _package.component.web.http.Servlet
*/

package _package.component.web.http;

import _package.component.Application;
import _package.component.util.Config;
import _package.component.web.requestContext.ServletRequestContext;
import com.tangosol.run.component.EventDeathException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletContext;
import javax.servlet.UnavailableException;
import javax.servlet.http.HttpServletRequest; // as Request
import javax.servlet.http.HttpServletResponse; // as Response

public class Servlet
        extends    _package.component.web.Http
        implements java.lang.Cloneable,
                   javax.servlet.Servlet
    {
    // Fields declarations
    
    /**
    * Property AnonymousExtension
    *
    */
    
    /**
    * Property ATTR_CONTEXTPATH
    *
    */
    public static final String ATTR_CONTEXTPATH = "ContextPath";
    
    /**
    * Property ATTR_ROUTEPREFIX
    *
    */
    public static final String ATTR_ROUTEPREFIX = "Route-";
    
    /**
    * Property AuthenticatingExtension
    *
    */
    
    /**
    * Property ContextPath
    *
    */
    private String __m_ContextPath;
    
    /**
    * Property RouteMap
    *
    * A map that has routing names that are defined in the servlet context as
    * keys and corresponding Class objects as values
    */
    private java.util.Map __m_RouteMap;
    
    /**
    * Property ServletConfig
    *
    */
    private transient javax.servlet.ServletConfig __m_ServletConfig;
    
    /**
    * Property ServletInfo
    *
    */
    private transient String __m_ServletInfo;
    
    // Default constructor
    public Servlet()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Servlet(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant AnonymousExtension
    public String getAnonymousExtension()
        {
        return ".ts";
        }
    
    // Getter for virtual constant AuthenticatingExtension
    public String getAuthenticatingExtension()
        {
        return ".tsa";
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Servlet();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/http/Servlet".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Used by Application.get_Instance to create an instance of the correct
    * application.  This method is only called against the very first component
    * to be instantiated (an "entry point"), and only if it is not an
    * Application component. An entry point component can implement this method
    * if it knows what application should be instantiated.
    * 
    * @return an appropriate Application component, or null if this component
    * does not know what Application component should be instantiated
    * 
    * @see #_Reference
    */
    public _package.component.Application _makeApplication()
        {
        // import Component.Application;
        // import Component.Util.Config;
        // import java.io.InputStream;
        // import java.io.IOException;
        
        // load initial configuration from preset location
        String      s  = Config.resolveName(Application.FILE_CFG_INITIAL);
        InputStream in = getServletConfig().getServletContext().getResourceAsStream(s);
        
        if (in != null)
            {
            try
                {
                Config config = new Config();
                config.load(in);
                Application.setInitialConfig(config);
                }
            catch (IOException e)
                {
                // do not use _trace (Application is not yet instantiated)
                System.err.println("Exception loading configuration:");
                e.printStackTrace(System.err);
                }
            }
        
        return null;
        }
    
    // Declared at the super level
    protected Object clone()
        {
        try
            {
            return super.clone();
            }
        catch (java.lang.CloneNotSupportedException e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // From interface: javax.servlet.Servlet
    public void destroy()
        {
        onServletDestroy();
        }
    
    // Accessor for the property "ContextPath"
    public String getContextPath()
        {
        return __m_ContextPath;
        }
    
    // Accessor for the property "RouteMap"
    public java.util.Map getRouteMap()
        {
        return __m_RouteMap;
        }
    
    // From interface: javax.servlet.Servlet
    // Accessor for the property "ServletConfig"
    public javax.servlet.ServletConfig getServletConfig()
        {
        return __m_ServletConfig;
        }
    
    // From interface: javax.servlet.Servlet
    // Accessor for the property "ServletInfo"
    public String getServletInfo()
        {
        String s = __m_ServletInfo;
        
        if (s == null)
            {
            s = getServletConfig().getServletName();
            }
        
        if (s == null)
            {
            String sBase = get_CLASS().getName();
            s = get_Name() + " " + sBase.substring(sBase.lastIndexOf('.') + 1);
            }
        
        return s;
        }
    
    // From interface: javax.servlet.Servlet
    public void init(javax.servlet.ServletConfig config)
            throws javax.servlet.ServletException
        {
        // import java.util.Map;
        // import javax.servlet.UnavailableException;
        
        setServletConfig(config);
        
        // TODO: review (not currently used)
        String sPath = config.getInitParameter(ATTR_CONTEXTPATH);
        if (sPath == null)
            {
            String sMsg = "Missing ServletContext parameter \"" + ATTR_CONTEXTPATH + "\"";
            System.err.println(sMsg);
            throw new UnavailableException(sMsg);
            }
        setContextPath(sPath);
        
        Map mapRoute = getApplication().getContextRouteMap(sPath);
        if (mapRoute == null)
            {
            mapRoute = instantiateRouteMap(config);
            getApplication().setContextRouteMap(sPath, mapRoute);
            }
        setRouteMap(mapRoute);
        
        onServletInit();
        }
    
    protected java.util.Map instantiateRouteMap(javax.servlet.ServletConfig config)
        {
        // import java.util.Map;
        // import java.util.HashMap;
        // import java.util.Enumeration;
        // import javax.servlet.ServletContext;
        
        Map map = new HashMap(101);
        
        // load the routing configuration information for the current
        // Servlet from the ServletContext
        ServletContext ctx = config.getServletContext();
        for (Enumeration enum = ctx.getInitParameterNames(); enum.hasMoreElements();)
            {
            String sParam = (String) enum.nextElement();
            if (sParam.startsWith(ATTR_ROUTEPREFIX))
                {
                String sName  = sParam.substring(ATTR_ROUTEPREFIX.length());
                String sClass = ctx.getInitParameter(sParam);
                try
                    {
                    // load the class and associate it with the routing name
                    map.put(sName, Class.forName(sClass));
                    }
                catch (Throwable e)
                    {
                    _trace("Servlet.instantiateRouteMap:  Unable to load class: \""
                            + sClass + "\" for routing name \"" + sName + "\"", 1);
                    }
                }
            }
        
        return map;

        }
    
    // Declared at the super level
    public void onError(int nStatus, String sDesc)
        {
        // import com.tangosol.run.component.EventDeathException;
        
        super.onError(nStatus, sDesc);
        
        // terminate request handling
        String sMsg = "Servlet.onError:  " + nStatus;
        if (sDesc != null)
            {
            sMsg += ' ' + sDesc;
            }
        throw new EventDeathException(sMsg);
        }
    
    public void onServletDestroy()
        {
        }
    
    public void onServletInit()
        {
        }
    
    // Declared at the super level
    public void onUnhandledRequest(_package.component.web.requestContext.ServletRequestContext ctx)
            throws javax.servlet.ServletException
        {
        // import java.util.Date;
        
        if (getApplication().isEnableDebugEcho())
            {
            _trace("Servlet.onUnhandledRequest invoked at " + new Date() + ':', 1);
            _trace(ctx.toString() + '\n', 1);
            }
        
        super.onUnhandledRequest(ctx);
        }
    
    // From interface: javax.servlet.Servlet
    public void service(javax.servlet.ServletRequest request, javax.servlet.ServletResponse response)
            throws java.io.IOException,
                   javax.servlet.ServletException
        {
        // import Component.Web.RequestContext.ServletRequestContext;
        // import com.tangosol.run.component.EventDeathException;
        // import javax.servlet.http.HttpServletRequest as Request;
        // import javax.servlet.http.HttpServletResponse as Response;
        
        Request  httpRequest  = (Request)  request;
        Response httpResponse = (Response) response;
        Servlet  servlet      = (Servlet) clone();
        
        // register servlet request context; use a clone of this servlet
        // so that it can have its own request context
        ServletRequestContext ctx = new ServletRequestContext();
        ctx.setServlet(servlet);
        ctx.setRequest(httpRequest);
        ctx.setResponse(httpResponse);
        
        getApplication().registerContext(ctx);
        
        try
            {
            servlet.setRequestContext(ctx);
            servlet.prerouteRequest(ctx, null);
            servlet.routeRequest(ctx);
        
            if (ctx.getOuterContext() == null && ctx.getCookieConfig().isModified())
                {
                httpResponse.addCookie(ctx.getCookieConfig().getCookie());
                }
            }
        catch (Exception e)
            {
            if (!ctx.isError())
                {
                try
                    {
                    _trace("Unhandled exception processing servlet:", 1);
                    _trace(e);
        
                    servlet.onError(SC_INTERNAL_SERVER_ERROR, e.getMessage());
                    }
                catch (EventDeathException e2)
                    {
                    // this exception is always expected
                    }
                }
            }
        finally
            {
            // Some app servers implement the "forward" calls by posting them in a queue
            // and invoking on different threads after this "service" method returns.
            // However, there is some design information on the Servlet that we want
            // to be able to get during the "show" phase. To do so, we don't unregister
            // the servlet context here ...
        
            // getApplication().unregisterContext(ctx);
            }
        }
    
    // Accessor for the property "ContextPath"
    protected void setContextPath(String sPath)
        {
        __m_ContextPath = sPath;
        }
    
    // Accessor for the property "RouteMap"
    protected void setRouteMap(java.util.Map map)
        {
        __m_RouteMap = map;
        }
    
    // Accessor for the property "ServletConfig"
    protected void setServletConfig(javax.servlet.ServletConfig config)
        {
        __m_ServletConfig = config;
        }
    
    // Accessor for the property "ServletInfo"
    public void setServletInfo(String info)
        {
        __m_ServletInfo = info;
        }
    }
