/* Class
*     _package.component.web.http.JspTag
*/

package _package.component.web.http;

import _package.component.Application;
import _package.component.util.Config;
import _package.component.web.RequestContext;
import _package.component.web.http.View;
import _package.component.web.requestContext.JspTagContext;
import com.tangosol.util.Base;
import java.io.IOException;
import java.io.InputStream;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.Tag;

/**
* The JspTag component is used in the web container to provide data from the
* application "model" (typically EJBs) to the JSP processor, which replaces
* "tags" with data output from the JspTag implementation.  The general flow is
* this:
* 
* 1)  The JSP processor instantiates the tag implementation (i.e. a component
* that inherits from this component);
* 2)  The JSP processor initializes the tag implementation;
* 3)  The tag implementation, upon various invocations, uses the JspTag.print
* method to send data to the JSP processor to replace the tag located in the
* .jsp file, and/or the tag implementation controls inclusion of chunks of the
* .jsp file and/or controls iteration of chunks of the .jsp file.
* 
* JspTag is not usually designed from directly; it is very general in its
* implementation.  The design intention is that various sub-components of
* JspTag be used:
* 
* 1)  IncludeTag:  Used to conditionally include or exclude chunks of the .jsp
* file that are eclosed by the opening and closing tag.
* 2)  PropertyTag:  Used to obtain a property of the tag's target object
* without any code, for example, obtaining a property value from an EJB.
* 3)  ForEachTag:  An iterating tag that uses one of the following as its
* source of data:  a java.util.Iterator, a java.util.Enumeration, a
* java.util.Collection, or a Java array.
* 
* The following is an excerpt from the documentation for
* javax.servlet.jsp.tagext.Tag:
* 
* The Tag interface defines the basic protocol between a Tag handler and JSP
* page implementation class. It defines the life cycle and the methods to be
* invoked at start and end tag.
* 
* There are several methods that get invoked to set the state of a Tag handler.
* The Tag handler is required to keep this state so the page compiler can
* choose not to reinvoke some of the state setting.
* 
* The page compiler guarantees that setPageContext and setParent will all be
* invoked on the Tag handler, in that order, before doStartTag() or doEndTag()
* are invoked on it. The page compiler also guarantees that release will be
* invoked on the Tag handler before the end of the page.
*/
public class JspTag
        extends    _package.component.web.Http
        implements javax.servlet.jsp.tagext.Tag
    {
    // Fields declarations
    
    /**
    * Property BodyContentType
    *
    * Quote from web-jsptaglibrary_1_1.tld:
    * 
    * "Provides a hint as to the content of the body of this tag. Primarily
    * intended for use by page composition tools.
    * 
    * There are currently three values specified:
    * 
    * tagdependent	The body of the tag is interpreted by the tag
    * 		implementation itself, and is most likely in a
    * 		different "langage", e.g embedded SQL statements.
    * 
    * JSP		The body of the tag contains nested JSP syntax
    * 
    * empty		The body must be empty
    * 
    * The default (if not defined) is JSP."
    * 
    * The value of this virtual constant is used by the Packager to generate
    * the correct tag library entry for this JSP tag.
    */
    
    /**
    * Property Dirty
    *
    */
    private boolean __m_Dirty;
    
    /**
    * Property ImpliedName
    *
    */
    
    /**
    * Property Out
    *
    * The JSP Writer to use (an instance of JspWriter).
    */
    private transient javax.servlet.jsp.JspWriter __m_Out;
    
    /**
    * Property PageContext
    *
    * The PageContext for the current response.
    * Initialization of a JSP tag is done by the JSP processor setting the
    * properties PageContext and Parent, in that order.
    */
    private transient javax.servlet.jsp.PageContext __m_PageContext;
    
    /**
    * Property Parameters
    *
    */
    private static final String[] __s_Parameters;
    
    /**
    * Property Parent
    *
    * The tag instance that contains this nested tag instance.
    * Initialization of a JSP tag is done by the JSP processor setting the
    * properties PageContext and Parent, in that order.
    */
    private transient javax.servlet.jsp.tagext.Tag __m_Parent;
    
    /**
    * Property ProcessingJspTag
    *
    */
    
    /**
    * Property ProcessingRequest
    *
    */
    
    /**
    * Property PropertyBoolean
    *
    */
    
    /**
    * Property PropertyName
    *
    */
    private String __m_PropertyName;
    
    /**
    * Property Result
    *
    */
    private Object __m_Result;
    
    /**
    * Property ResultView
    *
    */
    private View __m_ResultView;
    
    /**
    * Property ResultViewName
    *
    * The View name that the body will configure if the tag configures a view
    * (e.g. for nested tags).  For example, a "for each" tag will iterate over
    * a collection of items, and for each item, will provide a view for that
    * item to nested tags.
    * 
    * If the name starts with '/' then it must be a global view name registered
    * in Servlet's RoutMap. Otherwise it should be a name of a View component
    * that is a sibling of this JspTag or a global one.
    */
    private String __m_ResultViewName;
    
    /**
    * Property SkipBody
    *
    * Determines whether the body of the JSP tag will be skipped or evaluated.
    */
    private boolean __m_SkipBody;
    
    /**
    * Property TagParent
    *
    */
    
    /**
    * Property TagPrefix
    *
    */
    
    /**
    * Property TagSuffix
    *
    * Used by ImpliedName calculated property.
    */
    
    /**
    * Property TerminatePage
    *
    * Determines whether the remainder of the page will be evaluated after the
    * JSP tag completes its evaluation.
    */
    private boolean __m_TerminatePage;
    
    // Static initializer
    static
        {
        try
            {
            __s_Parameters = null;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public JspTag()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public JspTag(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setDirty(false);
            setOut(null);
            setSkipBody(false);
            setTerminatePage(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant BodyContentType
    public String getBodyContentType()
        {
        return null;
        }
    
    // Getter for virtual constant Parameters
    public String[] getParameters()
        {
        return null;
        }
    
    // Getter for virtual constant PropertyBoolean
    public boolean isPropertyBoolean()
        {
        return false;
        }
    
    // Getter for virtual constant Routeable
    public boolean isRouteable()
        {
        return false;
        }
    
    // Getter for virtual constant TagPrefix
    public String getTagPrefix()
        {
        return null;
        }
    
    // Getter for virtual constant TagSuffix
    public String getTagSuffix()
        {
        return null;
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new JspTag();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/http/JspTag".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Used by Application.get_Instance to create an instance of the correct
    * application.  This method is only called against the very first component
    * to be instantiated (an "entry point"), and only if it is not an
    * Application component. An entry point component can implement this method
    * if it knows what application should be instantiated.
    * 
    * @return an appropriate Application component, or null if this component
    * does not know what Application component should be instantiated
    * 
    * @see #_Reference
    */
    public _package.component.Application _makeApplication()
        {
        // import Component.Application;
        // import Component.Util.Config;
        // import java.io.InputStream;
        // import java.io.IOException;
        
        // load initial configuration from preset location
        String      s  = Config.resolveName(Application.FILE_CFG_INITIAL);
        InputStream in = getPageContext().getServletContext().getResourceAsStream(s);
        
        if (in != null)
            {
            try
                {
                Config config = new Config();
                config.load(in);
                Application.setInitialConfig(config);
                }
            catch (IOException e)
                {
                // do not use _trace (Application is not yet instantiated)
                System.err.println("Exception loading configuration:");
                e.printStackTrace(System.err);
                }
            }
        
        return null;
        }
    
    // From interface: javax.servlet.jsp.tagext.Tag
    public int doEndTag()
            throws javax.servlet.jsp.JspException
        {
        // import Component.Web.RequestContext.JspTagContext;
        // import javax.servlet.jsp.JspException;
        // import javax.servlet.jsp.tagext.Tag;
        
        try
            {
            onEndTag();
            }
        catch (Exception e)
            {
            onTagException(e);
            }
        
        JspTag tagParent = getTagParent();
        if (tagParent == null)
            {
            // unregister JSP context
            JspTagContext ctx = (JspTagContext) getRequestContext();
            getApplication().unregisterContext(ctx);
            
            if (ctx.isError())
                {
                throw new JspException(ctx.getErrorText());
                }
            }
        
        // determine return value (is this tag terminating the page?)
        int nRet = isTerminatePage() ? Tag.SKIP_PAGE : Tag.EVAL_PAGE;
        
        // the tag is done being used; anything it is carrying is dirty
        setDirty(true);
        setRequestContext(null);
        
        return nRet;
        }
    
    // From interface: javax.servlet.jsp.tagext.Tag
    public int doStartTag()
            throws javax.servlet.jsp.JspException
        {
        // import Component.Web.RequestContext.JspTagContext;
        // import javax.servlet.jsp.tagext.Tag;
        
        JspTag tagParent = getTagParent();
        if (tagParent == null)
            {
            // register JSP context
            JspTagContext ctx = new JspTagContext();
            ctx.setPageContext(getPageContext());
        
            getApplication().registerContext(ctx);
        
            setRequestContext(ctx);
            }
        else
            {
            setRequestContext(tagParent.getRequestContext());
            }
        
        if (isDirty())
            {
            // tag instance is being re-used
            onResetTag();
            }
        
        try
            {
            onStartTag();
            }
        catch (Exception e)
            {
            onTagException(e);
            }
        
        return isSkipBody() ? Tag.SKIP_BODY : Tag.EVAL_BODY_INCLUDE;
        }
    
    protected Object evaluate()
        {
        // import Component.Web.Http.View;
        
        View view = getView();
        return view == null ? null :
            view.getTagData(getPropertyName(), isPropertyBoolean());

        }
    
    // Declared at the super level
    public void forward(String url, _package.component.web.Http httpOrigin)
            throws javax.servlet.ServletException
        {
        // if acting as a JSP tag, forward directly
        if (isProcessingJspTag())
            {
            getRequestContext().forward(url, httpOrigin);
            }
        else
            {
            super.forward(url, httpOrigin);
            }
        }
    
    // Declared at the super level
    public _package.component.web.Http getHttpParent()
        {
        // import Component.Web.RequestContext;
        
        if (isProcessingJspTag())
            {
            JspTag tagParent = getTagParent();
            if (tagParent != null)
                {
                return tagParent;
                }
        
            // get the Http that forwarded to or included the JSP that this tag is on
            return getRequestContext().getEntryHttp();
            }
        else
            {
            return super.getHttpParent();
            }
        }
    
    // Accessor for the property "ImpliedName"
    public String getImpliedName()
        {
        String sName   = null;
        String sPrefix = getTagPrefix();
        String sSuffix = getTagSuffix();
        if (sPrefix != null || sSuffix != null)
            {
            String sClass    = getClass().getName();
            String sTag      = sClass.substring(sClass.lastIndexOf('$') + 1);
            int    cchTag    = sTag.length();
            int    cchPrefix = sPrefix == null ? 0 : sPrefix.length();
            int    cchSuffix = sSuffix == null ? 0 : sSuffix.length();
            if (   (cchPrefix == 0 || cchTag > cchPrefix
                    && sTag.regionMatches(true, 0, sPrefix, 0, cchPrefix))
                && (cchSuffix == 0 || cchTag > cchSuffix
                    && sTag.regionMatches(true, cchTag - cchSuffix, sSuffix, 0, cchSuffix)) )
                {
                sName = sTag.substring(cchPrefix, cchTag - cchSuffix);
                }
            }
        
        return sName;
        }
    
    // Accessor for the property "Out"
    public javax.servlet.jsp.JspWriter getOut()
        {
        // import javax.servlet.jsp.JspWriter;
        
        JspWriter out = __m_Out;
        
        if (out == null)
            {
            out = getPageContext().getOut();
            }
        
        return out;
        }
    
    // Accessor for the property "PageContext"
    public javax.servlet.jsp.PageContext getPageContext()
        {
        return __m_PageContext;
        }
    
    // From interface: javax.servlet.jsp.tagext.Tag
    // Accessor for the property "Parent"
    public javax.servlet.jsp.tagext.Tag getParent()
        {
        return __m_Parent;
        }
    
    // Accessor for the property "PropertyName"
    public String getPropertyName()
        {
        String sName = __m_PropertyName;
        
        if (sName == null)
            {
            sName = getImpliedName();
            }
        
        return sName;
        }
    
    // Accessor for the property "Result"
    public Object getResult()
        {
        return __m_Result;
        }
    
    // Accessor for the property "ResultView"
    public View getResultView()
        {
        return __m_ResultView;
        }
    
    // Accessor for the property "ResultViewName"
    public String getResultViewName()
        {
        return __m_ResultViewName;
        }
    
    // Accessor for the property "TagParent"
    public JspTag getTagParent()
        {
        // import javax.servlet.jsp.tagext.Tag;
        
        Tag tagParent = getParent();
        while (tagParent != null)
            {
            if (tagParent instanceof JspTag)
                {
                return (JspTag) tagParent;
                }
        
            tagParent = tagParent.getParent();
            }
        
        return null;
        }
    
    // Declared at the super level
    /**
    * Return a View component that belongs to the specified Class
    */
    public View getView(Class clz)
        {
        // import Component.Web.Http.View;
        
        View view = getResultView();
        if (view == null || !clz.isAssignableFrom(view.getClass()))
            {
            view = super.getView(clz);
            }
        return view;

        }
    
    // Declared at the super level
    public void include(String url, _package.component.web.Http httpOrigin)
            throws javax.servlet.ServletException
        {
        // if acting as a JSP tag, include directly
        if (isProcessingJspTag())
            {
            getRequestContext().include(url, httpOrigin);
            }
        else
            {
            super.include(url, httpOrigin);
            }
        }
    
    /**
    * This method is just a helper function to obtain the view that supports
    * this JSP tag based on the value of the Result property
    * 
    * @return the Component.Web.Http.View instance that is the design parent
    * (or grandparent, etc.) for the JSP tag
    * 
    * @see the documentation for the ViewClass property
    */
    protected View instantiateView()
        {
        // import Component.Web.Http.View;
        
        Object result = getResult();
        View   view   = null;
        
        if (result instanceof View)
            {
            view = (View) result;
            }
        else
            {
            String sView = getResultViewName();
            if (sView != null)
                {
                view = instantiateView(sView);
                view.setDefaultModel(result);
                }
            }
        
        return view;
        }
    
    /**
    * This method is just a helper function to obtain the view that supports
    * this JSP tag.
    * 
    * @param sName the name of the View to be instantiated
    * 
    * @return the Component.Web.Http.View instance that is the design parent
    * (or grandparent, etc.) for the JSP tag
    * 
    * @see the documentation for the ResultViewName property
    */
    protected View instantiateView(String sName)
        {
        // import Component.Web.Http.View;
        // import com.tangosol.util.Base;
        
        // TODO: review
        
        try
            {
            View view = null;
        
            if (sName.startsWith("/"))
                {
                sName = sName.substring(1);
                }
            else
                {
                view = (View) getView()._newChild(sName);
                }
            
            if (view == null)
                {
                Class clzView = (Class) getServlet().getRouteMap().get(sName);
        
                view = (View) clzView.newInstance();
                }
            view.setRequestContext(getRequestContext());
        
            return view;
            }
        catch (NullPointerException e)
            {
            throw new RuntimeException("Failed to instantiate view: " + sName);
            }
        catch (Throwable e)
            {
            throw Base.ensureRuntimeException(e);
            }
        }
    
    // Accessor for the property "Dirty"
    public boolean isDirty()
        {
        return __m_Dirty;
        }
    
    // Accessor for the property "ProcessingJspTag"
    public boolean isProcessingJspTag()
        {
        return getPageContext() != null;
        }
    
    // Accessor for the property "ProcessingRequest"
    public boolean isProcessingRequest()
        {
        return !isProcessingJspTag() && getRequestContext() != null;
        }
    
    // Accessor for the property "SkipBody"
    protected boolean isSkipBody()
        {
        return __m_SkipBody;
        }
    
    // Accessor for the property "TerminatePage"
    protected boolean isTerminatePage()
        {
        return __m_TerminatePage;
        }
    
    public void onEndTag()
            throws javax.servlet.jsp.JspException
        {
        }
    
    public void onResetTag()
        {
        // reset all instance properties with non-"[none]" design values to their design values
        _assert(isProcessingJspTag());
        _init();
        }
    
    public void onStartTag()
            throws javax.servlet.jsp.JspException
        {
        }
    
    public void onTagException(Throwable e)
        {
        _trace("Unhandled tag exception:", 1);
        _trace(e);
        
        onError(SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    
    protected void print(int i)
            throws javax.servlet.jsp.JspTagException
        {
        // import javax.servlet.jsp.JspTagException;
        
        try
            {
            getOut().print(i);
            }
        catch (java.io.IOException e)
            {
            throw new JspTagException(e.getMessage());
            }
        }
    
    protected void print(Object o)
            throws javax.servlet.jsp.JspTagException
        {
        // import javax.servlet.jsp.JspTagException;
        
        try
            {
            getOut().print(o);
            }
        catch (java.io.IOException e)
            {
            throw new JspTagException(e.getMessage());
            }
        }
    
    protected void print(String s)
            throws javax.servlet.jsp.JspTagException
        {
        // import javax.servlet.jsp.JspTagException;
        
        try
            {
            getOut().print(s);
            }
        catch (java.io.IOException e)
            {
            throw new JspTagException(e.getMessage());
            }
        }
    
    // From interface: javax.servlet.jsp.tagext.Tag
    public void release()
        {
        }
    
    // Accessor for the property "Dirty"
    public void setDirty(boolean fDirty)
        {
        __m_Dirty = fDirty;
        }
    
    // Accessor for the property "Out"
    public void setOut(javax.servlet.jsp.JspWriter out)
        {
        __m_Out = out;
        }
    
    // From interface: javax.servlet.jsp.tagext.Tag
    // Accessor for the property "PageContext"
    public void setPageContext(javax.servlet.jsp.PageContext ctx)
        {
        __m_PageContext = ctx;
        }
    
    // From interface: javax.servlet.jsp.tagext.Tag
    // Accessor for the property "Parent"
    public void setParent(javax.servlet.jsp.tagext.Tag tagParent)
        {
        __m_Parent = tagParent;
        }
    
    // Accessor for the property "PropertyName"
    public void setPropertyName(String sName)
        {
        __m_PropertyName = sName;
        }
    
    // Declared at the super level
    public void setRequestContext(_package.component.web.RequestContext ctx)
        {
        super.setRequestContext(ctx);
        
        // TODO: remove
        /*
        if (ctx != null)
            {
            _trace(get_Name() + (isProcessingRequest() ? " request " : " tag ") +
                (getHttpParent() == null    ? " without parent "         : "with parent " + getHttpParent().get_Name()) +
                (getContextParent() == null ? " without context parent " : "with context parent " + getContextParent().get_Name())
                );
            }
        */
        }
    
    // Accessor for the property "Result"
    public void setResult(Object result)
        {
        __m_Result = (result);
        
        setResultView(result == null ? null : instantiateView());
        }
    
    // Accessor for the property "ResultView"
    public void setResultView(View view)
        {
        __m_ResultView = view;
        }
    
    // Accessor for the property "ResultViewName"
    public void setResultViewName(String pResultViewName)
        {
        __m_ResultViewName = pResultViewName;
        }
    
    // Accessor for the property "SkipBody"
    protected void setSkipBody(boolean fSkip)
        {
        __m_SkipBody = fSkip;
        }
    
    // Accessor for the property "TerminatePage"
    protected void setTerminatePage(boolean fTerminate)
        {
        __m_TerminatePage = fTerminate;
        }
    }
