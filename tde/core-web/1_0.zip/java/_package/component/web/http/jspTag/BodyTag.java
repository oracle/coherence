/* Class
*     _package.component.web.http.jspTag.BodyTag
*/

package _package.component.web.http.jspTag;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTag;
import javax.servlet.jsp.tagext.Tag;

public class BodyTag
        extends    _package.component.web.http.JspTag
        implements javax.servlet.jsp.tagext.BodyTag
    {
    // Fields declarations
    
    /**
    * Property BodyContent
    *
    * The BodyContent object represents the information located in the JSP
    * between the starting JSP tag and the ending JSP tag.  BodyContent itself
    * extends the JspWriter class and while the body is being evaluated the
    * BodyContent instance replaces the PageContext's writer.  To obtain the
    * writer that was replaced by the BodyContent, use the
    * BodyContent.getEnclosingWriter method.
    */
    private transient javax.servlet.jsp.tagext.BodyContent __m_BodyContent;
    
    /**
    * Property RepeatBody
    *
    * If the body of the tag gets evaluated, it will be evaluated repeatedly as
    * long as RepeatBody is set to true.  If RepeatBody is never set to true
    * (i.e. it is false for the life of the tag) then the body will be
    * evaluated once.  Remember that the body of the tag is never evaluated if
    * SkipBody is true (i.e. if the doStartTag() method returns SKIP_BODY.)
    */
    private transient boolean __m_RepeatBody;
    
    // Default constructor
    public BodyTag()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public BodyTag(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setDirty(false);
            setOut(null);
            setRepeatBody(false);
            setSkipBody(false);
            setTerminatePage(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant BodyContentType
    public String getBodyContentType()
        {
        return "JSP";
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new BodyTag();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/http/jspTag/BodyTag".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: javax.servlet.jsp.tagext.BodyTag
    public int doAfterBody()
            throws javax.servlet.jsp.JspException
        {
        // import javax.servlet.jsp.tagext.Tag;
        // import javax.servlet.jsp.tagext.BodyTag;
        
        try
            {
            onAfterBody();
            }
        catch (Exception e)
            {
            onTagException(e);
            }
        
        return isRepeatBody() ? BodyTag.EVAL_BODY_TAG : Tag.SKIP_BODY;
        }
    
    // From interface: javax.servlet.jsp.tagext.BodyTag
    public void doInitBody()
            throws javax.servlet.jsp.JspException
        {
        try
            {
            onInitBody();
            }
        catch (Exception e)
            {
            onTagException(e);
            }
        }
    
    // From interface: javax.servlet.jsp.tagext.BodyTag
    // Declared at the super level
    public int doStartTag()
            throws javax.servlet.jsp.JspException
        {
        // import javax.servlet.jsp.tagext.Tag;
        // import javax.servlet.jsp.tagext.BodyTag;
        
        int nResult = super.doStartTag();
        
        // use EVAL_BODY_TAG instead of EVAL_BODY_INCLUDE to denote that the
        // body needs to be evaluated using a BodyContent instance
        return nResult == Tag.EVAL_BODY_INCLUDE ? BodyTag.EVAL_BODY_TAG : nResult;
        }
    
    protected void flushBodyContent()
            throws javax.servlet.jsp.JspTagException
        {
        // import javax.servlet.jsp.tagext.BodyContent;
        // import javax.servlet.jsp.JspTagException;
        
        BodyContent body = getBodyContent();
        if (body != null)
            {
            try
                {
                body.writeOut(body.getEnclosingWriter());
                }
            catch (java.io.IOException e)
                {
                throw new JspTagException(e.getMessage());
                }
        
            body.clearBody();
            }
        }
    
    // Accessor for the property "BodyContent"
    public javax.servlet.jsp.tagext.BodyContent getBodyContent()
        {
        return __m_BodyContent;
        }
    
    // Accessor for the property "RepeatBody"
    public boolean isRepeatBody()
        {
        return __m_RepeatBody;
        }
    
    public void onAfterBody()
            throws javax.servlet.jsp.JspException
        {
        // default implementation is to write the evaluated body out to the
        // enclosing JspWriter
        flushBodyContent();
        }
    
    // Declared at the super level
    public void onEndTag()
            throws javax.servlet.jsp.JspException
        {
        setResultView(null);
        
        super.onEndTag();
        }
    
    public void onInitBody()
            throws javax.servlet.jsp.JspException
        {
        }
    
    // From interface: javax.servlet.jsp.tagext.BodyTag
    // Accessor for the property "BodyContent"
    public void setBodyContent(javax.servlet.jsp.tagext.BodyContent content)
        {
        __m_BodyContent = content;
        }
    
    // Accessor for the property "RepeatBody"
    public void setRepeatBody(boolean fRepeat)
        {
        __m_RepeatBody = fRepeat;
        }
    }
