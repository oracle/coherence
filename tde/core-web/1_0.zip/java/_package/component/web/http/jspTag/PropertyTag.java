/* Class
*     _package.component.web.http.jspTag.PropertyTag
*/

package _package.component.web.http.jspTag;

import _package.component.util.Format;
import com.tangosol.run.xml.XmlValue;

public class PropertyTag
        extends    _package.component.web.http.JspTag
    {
    // Fields declarations
    
    /**
    * Property Format
    *
    */
    private _package.component.util.Format __m_Format;
    
    // Default constructor
    public PropertyTag()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PropertyTag(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setDirty(false);
            setOut(null);
            setSkipBody(false);
            setTerminatePage(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant BodyContentType
    public String getBodyContentType()
        {
        return "empty";
        }
    
    // Getter for virtual constant TagPrefix
    public String getTagPrefix()
        {
        return "";
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new PropertyTag();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/http/jspTag/PropertyTag".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "Format"
    public _package.component.util.Format getFormat()
        {
        return __m_Format;
        }
    
    // Declared at the super level
    public void onStartTag()
            throws javax.servlet.jsp.JspException
        {
        // import Component.Util.Format;
        // import com.tangosol.run.xml.XmlValue;
        
        super.onStartTag();
        
        Object o = evaluate();
        
        if (o instanceof XmlValue)
            {
            o = ((XmlValue) o).getString();
            }
        
        if (o != null)
            {
            Format format = getFormat();
            print(format == null ? o : format.format(o));
            }
        }
    
    // Accessor for the property "Format"
    public void setFormat(_package.component.util.Format format)
        {
        __m_Format = format;
        }
    }
