/* Class
*     _package.component.web.http.jspTag.EventTag
*/

package _package.component.web.http.jspTag;

import _package.component.web.Http;
import _package.component.web.http.JspTag;
import _package.component.web.http.Servlet;
import _package.component.web.http.View;
import _package.component.web.http.jspTag.eventTag.FormTag;
import _package.component.web.requestContext.ServletRequestContext;
import com.tangosol.util.Base;
import java.util.Map;

public abstract class EventTag
        extends    _package.component.web.http.JspTag
    {
    // Fields declarations
    
    /**
    * Property Authenticate
    *
    * Set to true to require authentification for routing to this EventTag
    * component.
    */
    
    /**
    * Property DefaultForward
    *
    */
    private String __m_DefaultForward;
    
    /**
    * Property ID_NEVER
    *
    */
    public static final int ID_NEVER = 2;
    
    /**
    * Property ID_REQUIRED
    *
    */
    public static final int ID_REQUIRED = 1;
    
    /**
    * Property ID_SUPPORTS
    *
    */
    public static final int ID_SUPPORTS = 0;
    
    /**
    * Property IdPassable
    *
    * TODO:
    */
    
    /**
    * Property InFormTag
    *
    * True if this submit event is designed inside a form tag.  False otherwise
    * (i.e. designed directly inside a view.)
    */
    
    /**
    * Property InFormTagCache
    *
    * Map from submit tag class to Boolean; caches answers as to whether submit
    * tags are designed within form tags.
    */
    private static com.tangosol.util.SafeHashMap __s_InFormTagCache;
    
    /**
    * Property JspName
    *
    * Name of the jsp that this event should forward to.
    */
    
    /**
    * Property Secure
    *
    * Set to true to require a secure connection for routing to this EventTag
    * component.
    */
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // state initialization: static properties
        try
            {
            setInFormTagCache(new com.tangosol.util.SafeHashMap());
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Initializing constructor
    public EventTag(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant Authenticate
    public boolean isAuthenticate()
        {
        return false;
        }
    
    // Getter for virtual constant BodyContentType
    public String getBodyContentType()
        {
        return "empty";
        }
    
    // Getter for virtual constant IdPassable
    public int getIdPassable()
        {
        return 0;
        }
    
    // Getter for virtual constant JspName
    public String getJspName()
        {
        return null;
        }
    
    // Getter for virtual constant Routeable
    public boolean isRouteable()
        {
        return true;
        }
    
    // Getter for virtual constant Secure
    public boolean isSecure()
        {
        return false;
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/http/jspTag/EventTag".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    protected String buildSubmit()
        {
        // import Component.Web.RequestContext.ServletRequestContext;
        // import com.tangosol.util.Base;
        
        // build a URL that will route back to this component
        // example if designed in a form tag:
        //   action="/demo/product-123.ts"
        //   name="submit.display"
        // example if designed directly in a view:
        //   action="/demo/submit.ts"
        //   name="submit.product-123.display"
        
        // start with the prefix that identifies the URI as an event to the servlet
        StringBuffer sb = new StringBuffer(ServletRequestContext.PREFIX_EVENT);
        sb.append('.');
        
        if (!isInFormTag())
            {
            sb.append(buildUrlBody())
              .append('.');
            }
        
        // add the event name
        sb.append(getImpliedName());
        
        return sb.toString();
        }
    
    /**
    * Build a URL that will route back to this component.
    */
    protected String buildUrl()
        {
        // import Component.Web.Http.Servlet;
        
        Servlet servlet = getServlet();
        _assert(servlet != null, "Cannot find servlet for: " + this);
        
        String sSuffix = isAuthenticate() ?
            servlet.getAuthenticatingExtension() : servlet.getAnonymousExtension();
        
        String sPath = getRequest().getContextPath();
        
        return sPath + '/' + buildUrlBody() + sSuffix;

        }
    
    protected String buildUrlBody()
        {
        // import Component.Web.Http;
        // import Component.Web.Http.View;
        // import com.tangosol.util.Base;
        
        StringBuffer sb = new StringBuffer();
        
        Http hop  = this;
        View view = hop.getView();
        
        while (true)
            {
            _assert(view != null, "View is missing for " + hop);
        
            Class  clzHop   = hop.getClass();
            Class  clzView  = view.getClass();
            String sClzHop  = clzHop.getName();
            String sHop     = null;
        
            // due to design requirements the name of the sClzHop
            // has to start with sClzView or one of its supers
            for (Class clz = clzView; true; clz = clz.getSuperclass())
                {
                _assert(clz != null, "View name mismatch: " + sClzHop +
                        " expected to be a child of " + clzView.getName());
                String sClzView = clz.getName();
                if (sClzHop.startsWith(sClzView))
                    {
                    sHop = sClzHop.substring(sClzView.length()).replace('$', '.');
                    _assert(sHop.charAt(0) == '.');
                    break;
                    }
                }
        
            // processing back to front
            sb.insert(0, sHop);
        
            String sId = getUrlId(view);
            if (sId != null)
                {
                sb.insert(0, '-' + sId);
                }
        
            hop  = view;
            view = hop.getView();
        
            if (view == null)
                {
                // the topmost view must be registered in the RouteMap
                String sClzView = clzView.getName();
                String sView    = sClzView.substring(sClzView.lastIndexOf('.') + 1);
                if (!clzView.equals(getServlet().getRouteMap().get(sView)))
                    {
                    onError(SC_INTERNAL_SERVER_ERROR, "Missing or conflicting url: " +
                        sView + " != " + getServlet().getRouteMap().get(sView));
                    }
                sb.insert(0, sView);
                break;
                }
            }
        
        return sb.toString();

        }
    
    protected String buildUrlDownload(String sFile)
        {
        // import Component.Web.Http.Servlet;
        
        Servlet servlet = getServlet();
        String  sSuffix = isAuthenticate() ?
            servlet.getAuthenticatingExtension() : servlet.getAnonymousExtension();
        
        String sPath = getRequest().getContextPath();
        
        return sPath + '/' + buildUrlBody() + '/' + sFile + sSuffix;
        

        }
    
    // Declared at the super level
    protected Object evaluate()
        {
        return buildUrl();
        }
    
    // Accessor for the property "DefaultForward"
    public String getDefaultForward()
        {
        String sUrl = __m_DefaultForward;
        if (sUrl == null)
            {
            sUrl = getJspName();
            if (sUrl != null && !sUrl.endsWith(".jsp"))
                {
                sUrl += ".jsp";
                }
            }
        
        if (sUrl != null)
            {
            // must start with '/'
            if (sUrl.length() > 0 && sUrl.charAt(0) != '/')
                {
                sUrl = '/' + sUrl;
                }
            }
        
        return sUrl;
        }
    
    // Accessor for the property "InFormTagCache"
    public static com.tangosol.util.SafeHashMap getInFormTagCache()
        {
        return __s_InFormTagCache;
        }
    
    private String getUrlId(_package.component.web.http.View view)
        {
        String sId   = null;
        int    iPass = getIdPassable();
        
        switch (iPass)
            {
            case ID_NEVER:    // the id must not be used
                break;
        
            case ID_SUPPORTS: // whether sId is present or not present, the event will work
            case ID_REQUIRED: // the id must be present
                sId = view.getId();
                if (sId == null && iPass == ID_REQUIRED)
                    {
                    onError(SC_INTERNAL_SERVER_ERROR, "Missing identifier for " + view);
                    }
                break;
        
            default:
                onError(SC_INTERNAL_SERVER_ERROR, "Illegal identifier option (" + iPass + ')');
                break;
            }
        
        return sId;
        }
    
    // Accessor for the property "InFormTag"
    protected boolean isInFormTag()
        {
        // import Component.Web.Http.JspTag.EventTag.FormTag;
        // import com.tangosol.util.Base;
        // import java.util.Map;
        
        // determine if the design parent is a form tag
        Map     map     = getInFormTagCache();
        Class   clz     = getClass();
        Boolean BInForm = (Boolean) map.get(clz);
        if (BInForm == null)
            {
            // get design parent's class (note:  we don't need to worry here if the submit
            // tag has been optimized out on subsequent levels)
            String sClz  = getClass().getName();
            int    ofEnd = sClz.lastIndexOf('$');
            _assert(ofEnd > 0);
            sClz = sClz.substring(0, ofEnd);
        
            // check if that class is a form
            try
                {
                clz = Class.forName(sClz);
                BInForm = FormTag.class.isAssignableFrom(clz) ? Boolean.TRUE : Boolean.FALSE;
                }
            catch (Throwable e)
                {
                throw Base.ensureRuntimeException(e);
                }
        
            map.put(clz, BInForm);
            }
        
        return BInForm.booleanValue();
        }
    
    // Declared at the super level
    public void onRequest(_package.component.web.requestContext.ServletRequestContext ctx)
            throws javax.servlet.ServletException
        {
        String sForward = getDefaultForward();
        if (sForward != null)
            {
            forward(sForward);
            }
        else
            {
            super.onRequest(ctx);
            }
        }
    
    // Declared at the super level
    public void onStartTag()
            throws javax.servlet.jsp.JspException
        {
        print(evaluate());
        }
    
    // Declared at the super level
    public void prerouteRequest(_package.component.web.RequestContext ctx, String sId)
        {
        super.prerouteRequest(ctx, sId);
        
        if (isAuthenticate() && !ctx.isAuthenticated())
            {
            onError(SC_UNAUTHORIZED, null);
            }
        
        if (isSecure() && !ctx.isSecure())
            {
            onError(SC_FORBIDDEN, null);
            }
        
        switch (getIdPassable())
            {
            case ID_NEVER:
                if (!validateViewIds(false))
                    {
                    onError(SC_BAD_REQUEST, "Identifier not supported");
                    }
                break;
        
            case ID_REQUIRED:
                if (!validateViewIds(true))
                    {
                    onError(SC_BAD_REQUEST, "Identifier required");
                    }
                break;
            }
        }
    
    // Accessor for the property "DefaultForward"
    public void setDefaultForward(String sUrl)
        {
        __m_DefaultForward = sUrl;
        }
    
    // Accessor for the property "InFormTagCache"
    public static void setInFormTagCache(com.tangosol.util.SafeHashMap map)
        {
        __s_InFormTagCache = map;
        }
    
    protected boolean validateViewIds(boolean fPresent)
        {
        // import Component.Web.Http;
        // import Component.Web.Http.View;
        // import Component.Web.Http.JspTag;
        
        Http http = getHttpParent();
        while (http instanceof EventTag)
            {
            http = http.getContextParent();
            }
        
        while (http instanceof View)
            {
            View    view    = (View) http;
            String  sId     = view.getId();
            boolean fExists = (sId != null);
            if (fPresent != fExists)
                {
                return false;
                }
        
            http = http.getContextParent();
            }
        
        return true;
        }
    }
