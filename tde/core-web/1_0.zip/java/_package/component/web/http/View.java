/* Class
*     _package.component.web.http.View
*/

package _package.component.web.http;

import com.tangosol.run.xml.SimpleElement;
import com.tangosol.run.xml.UriSerializable;
import com.tangosol.run.xml.XmlElement;
import com.tangosol.util.Base;
import java.lang.reflect.Method;

public class View
        extends    _package.component.web.Http
    {
    // Fields declarations
    
    /**
    * Property ControllerCache
    *
    */
    private transient com.tangosol.util.SafeHashMap __m_ControllerCache;
    
    /**
    * Property DefaultModel
    *
    * This view's model (since we cannot add a setter to a derived Model
    * property)
    */
    private transient Object __m_DefaultModel;
    
    /**
    * Property Id
    *
    */
    
    // Default constructor
    public View()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public View(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        _addChild(new View$DataMapper("DataMapper", this, true), "DataMapper");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        
        // state initialization: private properties
        try
            {
            __m_ControllerCache = new com.tangosol.util.SafeHashMap();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new View();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/http/View".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "ControllerCache"
    private com.tangosol.util.SafeHashMap getControllerCache()
        {
        return __m_ControllerCache;
        }
    
    // Accessor for the property "DefaultModel"
    public Object getDefaultModel()
        {
        // import com.tangosol.run.xml.SimpleElement;
        
        $DataMapper mapper = ($DataMapper) _findChild("DataMapper");
        return mapper.get_MasterValue();
        
        // return model == null ? new SimpleElement(get_Name()) : model;

        }
    
    // Accessor for the property "Id"
    public String getId()
        {
        // import com.tangosol.run.xml.UriSerializable;
        
        Object model = getDefaultModel();
        if (model instanceof UriSerializable)
            {
            return ((UriSerializable) model).toUri();
            }
        else
            {
            return (($DataMapper) _findName("DataMapper")).toUri();
            }
        }
    
    // Declared at the super level
    public Object getModel()
        {
        return getDefaultModel();

        }
    
    /**
    * @see JspTag#evaluate
    */
    public Object getTagData(String sPropertyName, boolean fPropertyBoolean)
        {
        // import com.tangosol.util.Base;
        // import com.tangosol.run.xml.XmlElement;
        // import java.lang.reflect.Method;
        
        if (sPropertyName != null)
            {
            // get the source for the invocation
            Object model = getDefaultModel();
        
            if (model instanceof XmlElement)
                {
                Object o = ((XmlElement) model).getElement(sPropertyName);
        
                if (o != null)
                    {
                    return o;
                    }
                }
        
            String sMethod = (fPropertyBoolean ? "is" : "get") + sPropertyName;
            Method method  = null;
        
            if (model != null)
                {
                try
                    {
                    method = model.getClass().getMethod(sMethod, new Class [0]);
                    }
                catch (NoSuchMethodException e) {}
            
                if (method != null)
                    {
                    try
                        {
                        return method.invoke(model, new Object[0]);
                        }
                    catch (Exception e)
                        {
                        throw Base.ensureRuntimeException(e);
                        }
                    }
                }
        
            // the default model could not be used -- try the DataMapper itself instead
            $DataMapper mapper = ($DataMapper) _findChild("DataMapper");
        
            try
                {
                method = mapper.getClass().getMethod(sMethod, new Class [0]);
                }
            catch (NoSuchMethodException e) {}
        
            if (method != null)
                {
                try
                    {
                    return method.invoke(mapper, new Object[0]);
                    }
                catch (Exception e)
                    {
                    throw Base.ensureRuntimeException(e);
                    }
                }
            }
        return null;
        }
    
    // Declared at the super level
    /**
    * Return a View component that belongs to the specified Class
    */
    public View getView(Class clz)
        {
        return clz.isAssignableFrom(getClass()) ? this : super.getView(clz);
        }
    
    /**
    * Find the target and instantiate it if it does not already exist.
    * 
    * @return  the target or null if no one knows how to instantiate the target
    */
    protected Object instantiateController(String sName)
        {
        // default controller is this
        return sName == null ? this : null;
        }
    
    /**
    * Instantiate and load the model using the specified Id
    * 
    * @return  the newly instantiated model
    */
    protected Object instantiateModel(String sId)
        {
        // TODO: review
        
        // by default there is no model, but the DataMapper serves
        // as a model itself (see #getTagData)
        
        (($DataMapper) _findName("DataMapper")).fromUri(sId);
        
        return null;

        }
    
    protected boolean isControllerCached(String sName)
        {
        return getControllerCache().containsKey(sName);
        }
    
    // Declared at the super level
    public void prerouteRequest(_package.component.web.RequestContext ctx, String sId)
        {
        super.prerouteRequest(ctx, sId);
        
        setDefaultModel(instantiateModel(sId));

        }
    
    // Accessor for the property "Controller"
    protected void setController(String sName, Object controller)
        {
        if (controller == null)
            {
            getControllerCache().remove(sName);
            }
        else
            {
            getControllerCache().put(sName, controller);
            }
        }
    
    // Accessor for the property "ControllerCache"
    private void setControllerCache(com.tangosol.util.SafeHashMap map)
        {
        __m_ControllerCache = map;
        }
    
    // Accessor for the property "DefaultModel"
    public void setDefaultModel(Object model)
        {
        $DataMapper mapper = ($DataMapper) _findChild("DataMapper");
        
        mapper.set_MasterValue(model);
        }
    }
