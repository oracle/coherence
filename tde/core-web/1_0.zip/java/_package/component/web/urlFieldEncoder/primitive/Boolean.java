/* Class
*     _package.component.web.urlFieldEncoder.primitive.Boolean
*/

package _package.component.web.urlFieldEncoder.primitive;

public class Boolean
        extends    _package.component.web.urlFieldEncoder.Primitive
    {
    // Fields declarations
    
    /**
    * Property DEFAULT
    *
    */
    public static final Boolean DEFAULT;
    
    // Static initializer
    static
        {
        try
            {
            DEFAULT = new java.lang.Boolean(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public Boolean()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Boolean(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Boolean();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/urlFieldEncoder/primitive/Boolean".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public Object decode(String sId)
        {
        if (sId.length() == 0)
            {
            return DEFAULT;
            }
        
        if (sId.length() == 1)
            {
            switch (sId.charAt(0))
                {
                case '0':
                    return Boolean.FALSE;
                case '1':
                    return Boolean.TRUE;
                }
            }
        
        throw new IllegalArgumentException("Unable to parse boolean (" + sId + ")");
        }
    
    // Declared at the super level
    public String encode(Object o)
        {
        return ((Boolean) o).booleanValue() ? "1" : "0";
        }
    }
