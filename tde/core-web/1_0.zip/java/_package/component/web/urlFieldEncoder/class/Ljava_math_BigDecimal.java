/* Class
*     _package.component.web.urlFieldEncoder.class.Ljava_math_BigDecimal
*/

package _package.component.web.urlFieldEncoder.class;

import _package.component.web.UrlFieldEncoder;
import java.math.BigDecimal;
import java.math.BigInteger;

public class Ljava_math_BigDecimal
        extends    _package.component.web.urlFieldEncoder.Class
    {
    // Fields declarations
    
    /**
    * Property BigIntegerEncoder
    *
    */
    private _package.component.web.UrlFieldEncoder __m_BigIntegerEncoder;
    
    /**
    * Property DEFAULT
    *
    */
    public static final java.math.BigDecimal DEFAULT;
    
    /**
    * Property DELIM
    *
    */
    public static final char DELIM = '*';
    
    /**
    * Property IntEncoder
    *
    */
    private _package.component.web.UrlFieldEncoder __m_IntEncoder;
    
    // Static initializer
    static
        {
        try
            {
            DEFAULT = new java.math.BigDecimal("0");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public Ljava_math_BigDecimal()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Ljava_math_BigDecimal(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Ljava_math_BigDecimal();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/urlFieldEncoder/class/Ljava_math_BigDecimal".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public Object decode(String sId)
        {
        // import java.math.BigDecimal;
        // import java.math.BigInteger;
        
        if (sId.length() == 0)
            {
            return DEFAULT;
            }
        
        int of = sId.indexOf(DELIM);
        _assert(of > 0);
        
        BigInteger bigI   = (BigInteger) getBigIntegerEncoder().decode(sId.substring(0, of ));
        Integer    IScale = (Integer   ) getIntEncoder       ().decode(sId.substring(of + 1));
        
        return new BigDecimal(bigI, IScale.intValue());
        }
    
    // Declared at the super level
    public String encode(Object o)
        {
        // import java.math.BigDecimal;
        
        BigDecimal big = (BigDecimal) o;
        return   getBigIntegerEncoder().encode(big.unscaledValue())
               + DELIM
               + getIntEncoder().encode(new Integer(big.scale()));
        }
    
    // Accessor for the property "BigIntegerEncoder"
    protected _package.component.web.UrlFieldEncoder getBigIntegerEncoder()
        {
        // import Component.Web.UrlFieldEncoder;
        // import java.math.BigInteger;
        
        UrlFieldEncoder enc = __m_BigIntegerEncoder;
        
        if (enc == null)
            {
            enc = getEncoder(BigInteger.class);
            setBigIntegerEncoder(enc);
            }
        
        return enc;
        }
    
    // Accessor for the property "IntEncoder"
    protected _package.component.web.UrlFieldEncoder getIntEncoder()
        {
        // import Component.Web.UrlFieldEncoder;
        
        UrlFieldEncoder enc = __m_IntEncoder;
        
        if (enc == null)
            {
            enc = getEncoder(Integer.TYPE);
            setIntEncoder(enc);
            }
        
        return enc;
        }
    
    // Accessor for the property "BigIntegerEncoder"
    protected void setBigIntegerEncoder(_package.component.web.UrlFieldEncoder enc)
        {
        __m_BigIntegerEncoder = enc;
        }
    
    // Accessor for the property "IntEncoder"
    protected void setIntEncoder(_package.component.web.UrlFieldEncoder enc)
        {
        __m_IntEncoder = enc;
        }
    }
