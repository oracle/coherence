/* Class
*     _package.component.web.urlFieldEncoder.Array
*/

package _package.component.web.urlFieldEncoder;

import _package.component.web.UrlFieldEncoder;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class Array
        extends    _package.component.web.UrlFieldEncoder
    {
    // Fields declarations
    
    /**
    * Property DELIM
    *
    */
    public static final char DELIM = '~';
    
    /**
    * Property ElementEncoder
    *
    */
    private _package.component.web.UrlFieldEncoder __m_ElementEncoder;
    
    /**
    * Property TYPE_BOOLEAN
    *
    */
    private static final int TYPE_BOOLEAN = 1;
    
    /**
    * Property TYPE_BYTE
    *
    */
    private static final int TYPE_BYTE = 2;
    
    /**
    * Property TYPE_CHAR
    *
    */
    private static final int TYPE_CHAR = 3;
    
    /**
    * Property TYPE_DOUBLE
    *
    */
    private static final int TYPE_DOUBLE = 4;
    
    /**
    * Property TYPE_FLOAT
    *
    */
    private static final int TYPE_FLOAT = 5;
    
    /**
    * Property TYPE_INT
    *
    */
    private static final int TYPE_INT = 6;
    
    /**
    * Property TYPE_LONG
    *
    */
    private static final int TYPE_LONG = 7;
    
    /**
    * Property TYPE_SHORT
    *
    */
    private static final int TYPE_SHORT = 8;
    
    /**
    * Property TypeEnum
    *
    */
    private int __m_TypeEnum;
    
    // Default constructor
    public Array()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Array(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant Cacheable
    public boolean isCacheable()
        {
        return false;
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Array();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/urlFieldEncoder/Array".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    protected void configure()
        {
        super.configure();
        
        Class clz = getElementEncoder().getFieldClass();
        if (clz.isPrimitive())
            {
            int n;
            if (clz.equals(Boolean.TYPE))
                {
                n = TYPE_BOOLEAN;
                }
            else if (clz.equals(Byte.TYPE))
                {
                n = TYPE_BYTE;
                }
            else if (clz.equals(Character.TYPE))
                {
                n = TYPE_CHAR;
                }
            else if (clz.equals(Double.TYPE))
                {
                n = TYPE_DOUBLE;
                }
            else if (clz.equals(Float.TYPE))
                {
                n = TYPE_FLOAT;
                }
            else if (clz.equals(Integer.TYPE))
                {
                n = TYPE_INT;
                }
            else if (clz.equals(Long.TYPE))
                {
                n = TYPE_LONG;
                }
            else if (clz.equals(Short.TYPE))
                {
                n = TYPE_SHORT;
                }
            else
                {
                throw new IllegalStateException("Unsupported primitive type:  " + clz);
                }
            setTypeEnum(n);
            }
        }
    
    // Declared at the super level
    public Object decode(String sId)
        {
        // import Component.Web.UrlFieldEncoder;
        // import java.lang.reflect.Array;
        // import java.util.ArrayList;
        
        _assert(sId.length() >= 2 && sId.charAt(0) == '(' && sId.charAt(sId.length() - 1) == ')');
        
        UrlFieldEncoder encoder = getElementEncoder();
        
        // clip off the front and back parens
        sId = sId.substring(0, sId.length() - 1);
        
        Object[] a;
        int      c;
        if (sId.length() == 0)
            {
            c = 0;
            a = new Object[c];
            }
        else
            {
            ArrayList list    = new ArrayList();
            char[]    ach     = sId.toCharArray();
            int       cch     = ach.length;
            int       cOpen   = 0;
            int       ofDelim = -1;
            for (int of = 0; of < cch; ++of)
                {
                switch (ach[of])
                    {
                    case '(':
                        ++cOpen;
                        break;
                    case ')':
                        --cOpen;
                        _assert(cOpen >=0 );
                        break;
                    case DELIM:
                        if (cOpen == 0)
                            {
                            list.add(sId.substring(ofDelim + 1, of));
                            ofDelim = of;
                            }
                        break;
                    }
                }
            _assert(cOpen == 0);
            list.add(sId.substring(ofDelim + 1));
            String[] asId = (String[]) list.toArray(new String[list.size()]);
        
            c = asId.length;
            a = new Object[c];
            for (int i = 0; i < c; ++i)
                {
                String s = asId[i];
                a[i] = s.equals("!") ? null : encoder.decode(s);
                }
            }
        
        switch (getTypeEnum())
            {
            case TYPE_BOOLEAN:
                {
                boolean[] aResult = (boolean[]) Array.newInstance(encoder.getFieldClass(), c);
                for (int i = 0; i < c; ++i)
                    {
                    aResult[i] = ((Boolean) a[i]).booleanValue();
                    }
                return aResult;
                }
        
            case TYPE_BYTE:
                {
                byte[] aResult = (byte[]) Array.newInstance(encoder.getFieldClass(), c);
                for (int i = 0; i < c; ++i)
                    {
                    aResult[i] = ((Byte) a[i]).byteValue();
                    }
                return aResult;
                }
        
            case TYPE_CHAR:
                {
                char[] aResult = (char[]) Array.newInstance(encoder.getFieldClass(), c);
                for (int i = 0; i < c; ++i)
                    {
                    aResult[i] = ((Character) a[i]).charValue();
                    }
                return aResult;
                }
        
            case TYPE_DOUBLE:
                {
                double[] aResult = (double[]) Array.newInstance(encoder.getFieldClass(), c);
                for (int i = 0; i < c; ++i)
                    {
                    aResult[i] = ((Double) a[i]).doubleValue();
                    }
                return aResult;
                }
        
            case TYPE_FLOAT:
                {
                float[] aResult = (float[]) Array.newInstance(encoder.getFieldClass(), c);
                for (int i = 0; i < c; ++i)
                    {
                    aResult[i] = ((Float) a[i]).floatValue();
                    }
                return aResult;
                }
        
            case TYPE_INT:
                {
                int[] aResult = (int[]) Array.newInstance(encoder.getFieldClass(), c);
                for (int i = 0; i < c; ++i)
                    {
                    aResult[i] = ((Integer) a[i]).intValue();
                    }
                return aResult;
                }
        
            case TYPE_LONG:
                {
                long[] aResult = (long[]) Array.newInstance(encoder.getFieldClass(), c);
                for (int i = 0; i < c; ++i)
                    {
                    aResult[i] = ((Long) a[i]).longValue();
                    }
                return aResult;
                }
        
            case TYPE_SHORT:
                {
                short[] aResult = (short[]) Array.newInstance(encoder.getFieldClass(), c);
                for (int i = 0; i < c; ++i)
                    {
                    aResult[i] = ((Short) a[i]).shortValue();
                    }
                return aResult;
                }
        
            default:
                {
                // just copy result objects over to the new array
                Object[] aResult = (Object[]) Array.newInstance(encoder.getFieldClass(), c);
                System.arraycopy(a, 0, aResult, 0, c);
                return aResult;
                }
            }
        }
    
    // Declared at the super level
    public String encode(Object o)
        {
        // import Component.Web.UrlFieldEncoder;
        
        UrlFieldEncoder encoder = getElementEncoder();
        final char DELIM = this.DELIM;
        
        StringBuffer sb = new StringBuffer();
        sb.append('(');
        
        switch (getTypeEnum())
            {
            case TYPE_BOOLEAN:
                {
                boolean[] a = (boolean[]) o;
                for (int i = 0, c = a.length; i < c; ++i)
                    {
                    if (i > 0)
                        {
                        sb.append(DELIM);
                        }
                    sb.append(encoder.encode(a[i] ? Boolean.TRUE : Boolean.FALSE));
                    }
                }
                break;
        
            case TYPE_BYTE:
                {
                byte[] a = (byte[]) o;
                for (int i = 0, c = a.length; i < c; ++i)
                    {
                    if (i > 0)
                        {
                        sb.append(DELIM);
                        }
                    sb.append(encoder.encode(new Byte(a[i])));
                    }
                }
                break;
        
            case TYPE_CHAR:
                {
                char[] a = (char[]) o;
                for (int i = 0, c = a.length; i < c; ++i)
                    {
                    if (i > 0)
                        {
                        sb.append(DELIM);
                        }
                    sb.append(encoder.encode(new Character(a[i])));
                    }
                }
                break;
        
            case TYPE_DOUBLE:
                {
                double[] a = (double[]) o;
                for (int i = 0, c = a.length; i < c; ++i)
                    {
                    if (i > 0)
                        {
                        sb.append(DELIM);
                        }
                    sb.append(encoder.encode(new Double(a[i])));
                    }
                }
                break;
        
            case TYPE_FLOAT:
                {
                float[] a = (float[]) o;
                for (int i = 0, c = a.length; i < c; ++i)
                    {
                    if (i > 0)
                        {
                        sb.append(DELIM);
                        }
                    sb.append(encoder.encode(new Float(a[i])));
                    }
                }
                break;
        
            case TYPE_INT:
                {
                int[] a = (int[]) o;
                for (int i = 0, c = a.length; i < c; ++i)
                    {
                    if (i > 0)
                        {
                        sb.append(DELIM);
                        }
                    sb.append(encoder.encode(new Integer(a[i])));
                    }
                }
                break;
        
            case TYPE_LONG:
                {
                long[] a = (long[]) o;
                for (int i = 0, c = a.length; i < c; ++i)
                    {
                    if (i > 0)
                        {
                        sb.append(DELIM);
                        }
                    sb.append(encoder.encode(new Long(a[i])));
                    }
                }
                break;
        
            case TYPE_SHORT:
                {
                short[] a = (short[]) o;
                for (int i = 0, c = a.length; i < c; ++i)
                    {
                    if (i > 0)
                        {
                        sb.append(DELIM);
                        }
                    sb.append(encoder.encode(new Short(a[i])));
                    }
                }
                break;
        
            default:
                {
                Object[] a = (Object[]) o;
                for (int i = 0, c = a.length; i < c; ++i)
                    {
                    if (i > 0)
                        {
                        sb.append(DELIM);
                        }
                    Object oElem = a[i];
                    sb.append(oElem == null ? "!" : encoder.encode(oElem));
                    }
                }
                break;
            }
        
        sb.append(')');
        return sb.toString();
        }
    
    // Accessor for the property "ElementEncoder"
    public _package.component.web.UrlFieldEncoder getElementEncoder()
        {
        return __m_ElementEncoder;
        }
    
    // Accessor for the property "TypeEnum"
    private int getTypeEnum()
        {
        return __m_TypeEnum;
        }
    
    // Accessor for the property "ElementEncoder"
    public void setElementEncoder(_package.component.web.UrlFieldEncoder pElementEncoder)
        {
        __m_ElementEncoder = pElementEncoder;
        }
    
    // Accessor for the property "TypeEnum"
    private void setTypeEnum(int n)
        {
        __m_TypeEnum = n;
        }
    }
