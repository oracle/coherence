/* Class
*     _package.component.web.urlFieldEncoder.primitive.Char
*/

package _package.component.web.urlFieldEncoder.primitive;

import com.tangosol.util.Base;

public class Char
        extends    _package.component.web.urlFieldEncoder.Primitive
    {
    // Fields declarations
    
    /**
    * Property DEFAULT
    *
    */
    public static final Character DEFAULT;
    
    /**
    * Property HEX
    *
    */
    private static final char[] HEX;
    
    // Static initializer
    static
        {
        try
            {
            DEFAULT = new java.lang.Character(' ');
            char[] a0 = new char[16];
                {
                a0[0] = '0';
                a0[1] = '1';
                a0[2] = '2';
                a0[3] = '3';
                a0[4] = '4';
                a0[5] = '5';
                a0[6] = '6';
                a0[7] = '7';
                a0[8] = '8';
                a0[9] = '9';
                a0[10] = 'A';
                a0[11] = 'B';
                a0[12] = 'C';
                a0[13] = 'D';
                a0[14] = 'E';
                a0[15] = 'F';
                }
            HEX = a0;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public Char()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Char(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Char();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/urlFieldEncoder/primitive/Char".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public Object decode(String sId)
        {
        // import com.tangosol.util.Base;
        
        switch (sId.length())
            {
            case 0:
                return DEFAULT;
        
            case 1:
                return new Character(sId.charAt(0));
        
            case 3:
                if (sId.charAt(0) == '%')
                    {
                    return new Character((char) (  Base.hexValue(sId.charAt(1)) * 0x10
                                                 + Base.hexValue(sId.charAt(2))       ));
                    }
                break;
        
            case 5:
                {
                char ch = sId.charAt(0);
                if (ch == 'U' || ch == 'u')
                    {
                    return new Character((char) (  Base.hexValue(sId.charAt(1)) * 0x1000
                                                 + Base.hexValue(sId.charAt(2)) * 0x0100
                                                 + Base.hexValue(sId.charAt(3)) * 0x0010
                                                 + Base.hexValue(sId.charAt(4))         ));
                    }
                }
                break;
            }
        
        throw new IllegalArgumentException("Unable to parse char (" + sId + ")");
        }
    
    // Declared at the super level
    public String encode(Object o)
        {
        char ch = ((Character) o).charValue();
        
        if (ch > 0xFF)
            {
            int    n   = ch;
            char[] ach = new char[5];
            char[] HEX = this.HEX;
            ach[0] = 'u';
            ach[1] = HEX[(n & 0xF000) >> 12];
            ach[2] = HEX[(n & 0x0F00) >>  8];
            ach[3] = HEX[(n & 0x00F0) >>  4];
            ach[4] = HEX[(n & 0x000F)      ];
            return new String(ach);
            }
        
        // @see http://www.ietf.org/rfc/rfc2396.txt
        switch (ch)
            {
            // "control"
            case 0x00: case 0x01: case 0x02: case 0x03:
            case 0x04: case 0x05: case 0x06: case 0x07:
            case 0x08: case 0x09: case 0x0A: case 0x0B:
            case 0x0C: case 0x0D: case 0x0E: case 0x0F:
            case 0x10: case 0x11: case 0x12: case 0x13:
            case 0x14: case 0x15: case 0x16: case 0x17:
            case 0x18: case 0x19: case 0x1A: case 0x1B:
            case 0x1C: case 0x1D: case 0x1E: case 0x1F:
        
            // "space"
            case ' ':
        
            // "reserved"
            case ';': case '/': case '?': case ':': case '@':
            case '&': case '=': case '+': case '$': case ',':
        
            // "mark" (only ones that we reserve)
            case '-': case '.': case '!': case '~':
        
            // "delims"
            case '<': case '>': case '#': case '%': case '"':
        
            // "unwise"
            case '{': case '}': case '|': case '\\':
            case '^': case '[': case ']': case '`':
        
            // parens are escaped because they are used for
            // arrays and must all be matched
            case '(': case ')':
        
                {
                int    n   = ch;
                char[] ach = new char[3];
                char[] HEX = this.HEX;
                ach[0] = '%';
                ach[1] = HEX[(n & 0xF0) >> 4];
                ach[2] = HEX[(n & 0x0F)     ];
                return new String(ach);
                }
            }
        
        return o.toString();
        }
    }
