/* Class
*     _package.component.web.urlFieldEncoder.class.Ljava_lang_Double
*/

package _package.component.web.urlFieldEncoder.class;

public class Ljava_lang_Double
        extends    _package.component.web.urlFieldEncoder.Class
    {
    // Fields declarations
    
    // Default constructor
    public Ljava_lang_Double()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Ljava_lang_Double(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Ljava_lang_Double();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/urlFieldEncoder/class/Ljava_lang_Double".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    protected _package.component.web.UrlFieldEncoder resolveEncoder()
        {
        return getEncoder(Double.TYPE);
        }
    }
