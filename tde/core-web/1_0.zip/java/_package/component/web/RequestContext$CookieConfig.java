/* Class
*     _package.component.web.RequestContext$CookieConfig
*/

package _package.component.web;

import _package.component.Application;
import _package.component.application.Enterprise;
import com.tangosol.util.Base;
import java.util.Enumeration;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest; // as Request

public class RequestContext$CookieConfig
        extends    _package.component.util.Config
    {
    // Fields declarations
    
    /**
    * Property Application
    *
    */
    
    /**
    * Property Cookie
    *
    */
    private transient javax.servlet.http.Cookie __m_Cookie;
    
    /**
    * Property Lifespan
    *
    */
    private transient int __m_Lifespan;
    
    /**
    * Property Modified
    *
    */
    private transient boolean __m_Modified;
    
    /**
    * Property Name
    *
    */
    private transient String __m_Name;
    
    /**
    * Property Path
    *
    */
    
    /**
    * Property RequestContext
    *
    */
    
    // Default constructor
    public RequestContext$CookieConfig()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public RequestContext$CookieConfig(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setArrayDelimiter(':');
            setLifespan(31536000);
            setName("application");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new RequestContext$CookieConfig();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/RequestContext$CookieConfig".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    public void clear()
        {
        if (!isEmpty())
            {
            super.clear();
            setModified(true);
            }
        }
    
    public static String decodeString(String s)
        {
        // import com.tangosol.util.Base;
        
        _assert(s != null);
        if (s.length() == 0)
            {
            return s;
            }
        
        char[] ach = s.toCharArray();
        int    cch = ach.length;
        
        StringBuffer sb = null;
        
        // scan for characters to un-escape
        int ofPrev = 0;
        for (int ofCur = 0; ofCur < cch; ++ofCur)
            {
            if (ach[ofCur] == '\\')
                {
                if (sb == null)
                    {
                    sb = new StringBuffer(cch);
                    }
        
                // copy up to this point
                if (ofCur > ofPrev)
                    {
                    sb.append(ach, ofPrev, ofCur - ofPrev);
                    }
        
                // unescape the character or sequence
                char ch = ach[++ofCur];
                switch (ch)
                    {
                    case '0':
                        // unambiguous 3-digit octal escape starting with '0'
                        sb.append((char) (8 * Base.octalValue(ach[++ofCur])
                                            + Base.octalValue(ach[++ofCur]) ) );
                        break;
        
                    case '\\':
                        sb.append('\\');
                        break;
                    
                    case 'b':
                        sb.append('\b');
                        break;
        
                    case 't':
                        sb.append('\t');
                        break;
        
                    case 'n':
                        sb.append('\n');
                        break;
        
                    case 'f':
                        sb.append('\f');
                        break;
        
                    case 'r':
                        sb.append('\r');
                        break;
        
                    case 'l':
                        sb.append('<');
                        break;
        
                    case 'g':
                        sb.append('>');
                        break;
        
                    case 'a':
                        sb.append('&');
                        break;
        
                    case 'q':
                        sb.append('\"');
                        break;
        
                    case 's':
                        sb.append(';');
                        break;
        
                    case 'c':
                        sb.append(',');
                        break;
        
                    case 'e':
                        sb.append('=');
                        break;
                    }
        
                // processed up to the following character
                ofPrev = ofCur + 1;
                }
            }
        
        // copy the remainder of the string
        if (sb != null && ofPrev < cch)
            {
            sb.append(ach, ofPrev, cch - ofPrev);
            }
        
        return sb == null ? s : sb.toString();
        }
    
    public static String encodeString(String s)
        {
        _assert(s != null);
        if (s.length() == 0)
            {
            return s;
            }
        
        char[] ach = s.toCharArray();
        int    cch = ach.length;
        
        StringBuffer sb = null;
        
        // scan for characters to escape
        int ofPrev = 0;
        for (int ofCur = 0; ofCur < cch; ++ofCur)
            {
            char ch = ach[ofCur];
        
            switch (ch)
                {
                case 0x00:  case 0x01: case 0x02: case 0x03:
                case 0x04:  case 0x05: case 0x06: case 0x07:
                case 0x08:  case 0x09: case 0x0A: case 0x0B:
                case 0x0C:  case 0x0D: case 0x0E: case 0x0F:
                case 0x10:  case 0x11: case 0x12: case 0x13:
                case 0x14:  case 0x15: case 0x16: case 0x17:
                case 0x18:  case 0x19: case 0x1A: case 0x1B:
                case 0x1C:  case 0x1D: case 0x1E: case 0x1F:
                case '<':   case '>':  case '&':  case '\"':    // HTML special characters
                case ';':                                       // cookie barf characters
                case '=':   case ',':  case '\\':               // delimiter and escape characters
                    {
                    if (sb == null)
                        {
                        sb = new StringBuffer(cch + 32);
                        }
        
                    // copy up to this point
                    if (ofCur > ofPrev)
                        {
                        sb.append(ach, ofPrev, ofCur - ofPrev);
                        }
        
                    // process escape
                    switch (ch)
                        {
                        case '\b':
                            sb.append("\\b");
                            break;
                        case '\t':
                            sb.append("\\t");
                            break;
                        case '\n':
                            sb.append("\\n");
                            break;
                        case '\f':
                            sb.append("\\f");
                            break;
                        case '\r':
                            sb.append("\\r");
                            break;
                        case '<':
                            sb.append("\\l");
                            break;
                        case '>':
                            sb.append("\\g");
                            break;
                        case '&':
                            sb.append("\\a");
                            break;
                        case '\"':
                            sb.append("\\q");
                            break;
                        case ';':
                            sb.append("\\s");
                            break;
                        case ',':
                            sb.append("\\c");
                            break;
                        case '=':
                            sb.append("\\e");
                            break;
                        case '\\':
                            sb.append("\\\\");
                            break;
                        default:
                            // use non-ambiguous (3-digit) octal escape
                            sb.append('\\')
                              .append('0')
                              .append((char)(ch / 8 + '0'))
                              .append((char)(ch % 8 + '0'));
                            break;
                        }
        
                    // processed up to the following character
                    ofPrev = ofCur + 1;
                    }
                }
            }
        
        // copy the remainder of the string
        if (sb != null && ofPrev < cch)
            {
            sb.append(ach, ofPrev, cch - ofPrev);
            }
        
        return sb == null ? s : sb.toString();
        }
    
    // Accessor for the property "Application"
    public _package.component.application.Enterprise getApplication()
        {
        // import Component.Application;
        // import Component.Application.Enterprise;
        
        return (Enterprise) Application.get_Instance();
        }
    
    // Accessor for the property "Cookie"
    public javax.servlet.http.Cookie getCookie()
        {
        // import java.util.Enumeration;
        // import javax.servlet.http.Cookie;
        
        // set up empty ("please delete me") cookie
        String  sName    = getName();
        String  sValue   = "";
        int     cSeconds = 0;
        String  sPath    = getPath();
        
        // validate path (and adjust if necessary)
        if (sPath != null && sPath.length() != 0 && !sPath.equals("/"))
            {
            if (sPath.charAt(0) != '/')
                {
                sPath = '/' + sPath;
                }
            if (sPath.charAt(sPath.length() - 1) == '/')
                {
                sPath = sPath.substring(0, sPath.length() - 1);
                }
            }
        
        // build the cookie value
        if (!isEmpty())
            {
            StringBuffer sb = new StringBuffer(1024);
            boolean fFirst = true;
            for (Enumeration enum = keys(); enum.hasMoreElements(); )
                {
                String sKey = (String) enum.nextElement();
                String sVal = getString(sKey);
        
                if (fFirst)
                    {
                    fFirst = false;
                    }
                else
                    {
                    sb.append(',');
                    }
        
                sb.append(encodeString(sKey))
                  .append('=')
                  .append(encodeString(sVal));
                }
        
            sValue   = sb.toString();
            cSeconds = getLifespan();
            }
        
        // instantiate and configure the cookie
        Cookie cookie = new Cookie(sName, sValue);
        cookie.setMaxAge(cSeconds);
        cookie.setPath(sPath);
        
        return cookie;
        }
    
    // Accessor for the property "Lifespan"
    public int getLifespan()
        {
        return __m_Lifespan;
        }
    
    // Accessor for the property "Name"
    public String getName()
        {
        return __m_Name;
        }
    
    // Accessor for the property "Path"
    public String getPath()
        {
        return getRequestContext().getRequest().getContextPath();
        }
    
    // Accessor for the property "RequestContext"
    public RequestContext getRequestContext()
        {
        $Module ctx = ($Module) get_Module();
        return ctx == null ? getApplication().getRequestContext() : ctx;
        }
    
    // Accessor for the property "Modified"
    public boolean isModified()
        {
        return __m_Modified;
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import javax.servlet.http.Cookie;
        // import javax.servlet.http.HttpServletRequest as Request;
        
        super.onInit();
        
        // find the cookie
        Cookie  cookie  = null;
        Request request = getRequestContext().getRequest();
        if (request == null)
            {
            _trace("CookieConfig instantiated without a request:", 1);
            _trace(get_StackTrace(), 1);
            }
        else
            {
            Cookie[] aCookie = request.getCookies();
            String   sName   = getName();
            if (aCookie != null)
                {
                for (int i = 0, c = aCookie.length; i < c; ++i)
                    {
                    if (aCookie[i].getName().equals(sName))
                        {
                        cookie = aCookie[i];
                        break;
                        }
                    }
                }
            }
        
        // configure this Config from the cookie
        try
            {
            setCookie(cookie);
            }
        catch (Exception e)
            {
            _trace("Corrupt cookie or other exception setting cookie (" + cookie + "):", 1);
            _trace(e);
        
            // corrupted cookie; delete the corrupt cookie
            setCookie(null);
            setModified(true);
            }
        }
    
    // Declared at the super level
    public void putBoolean(String sKey, boolean fValue)
        {
        super.putBoolean(sKey, fValue);
        setModified(true);
        }
    
    // Declared at the super level
    public void putConfig(String sKey, _package.component.util.Config config)
        {
        super.putConfig(sKey, config);
        setModified(true);
        }
    
    // Declared at the super level
    public void putInt(String sKey, int iValue)
        {
        super.putInt(sKey, iValue);
        setModified(true);
        }
    
    // Declared at the super level
    public void putIntArray(String sKey, int[] aiValue)
        {
        super.putIntArray(sKey, aiValue);
        setModified(true);
        }
    
    // Declared at the super level
    public void putString(String sKey, String sValue)
        {
        super.putString(sKey, sValue);
        setModified(true);
        }
    
    // Declared at the super level
    public void putStringArray(String sKey, String[] asValue)
        {
        super.putStringArray(sKey, asValue);
        setModified(true);
        }
    
    // Declared at the super level
    public void remove(String sName)
        {
        if (containsKey(sName))
            {
            super.remove(sName);
            setModified(true);
            }
        }
    
    // Accessor for the property "Cookie"
    public void setCookie(javax.servlet.http.Cookie cookie)
        {
        clear();
        
        if (cookie != null)
            {
            String s = cookie.getValue();
            if (s != null && s.length() > 0)
                {
                for (int ofName = 0, cch = s.length(); ofName < cch; )
                    {
                    int ofAssign = s.indexOf('=', ofName);
                    if (ofAssign < 0)
                        {
                        // corrupt cookie
                        throw new IllegalStateException("Cookie is corrupt (" + s + ')');
                        }
        
                    int ofValue = ofAssign + 1;
                    int ofDelim = s.indexOf(',', ofValue);
                    if (ofDelim < 0)
                        {
                        ofDelim = cch;
                        }
        
                    String sName  = decodeString(s.substring(ofName, ofAssign));
                    String sValue = decodeString(s.substring(ofValue, ofDelim));
                    if (sName != null && sName.length() > 0 && sValue != null)
                        {
                        putString(sName, sValue);
                        }
        
                    ofName = ofDelim + 1;
                    }
                }
            }
        
        setModified(false);
        }
    
    // Accessor for the property "Lifespan"
    public void setLifespan(int cSeconds)
        {
        __m_Lifespan = cSeconds;
        }
    
    // Accessor for the property "Modified"
    public void setModified(boolean fModified)
        {
        __m_Modified = fModified;
        }
    
    // Accessor for the property "Name"
    public void setName(String sName)
        {
        __m_Name = sName;
        }
    }
