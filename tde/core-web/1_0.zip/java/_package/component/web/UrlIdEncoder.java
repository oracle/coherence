/* Class
*     _package.component.web.UrlIdEncoder
*/

package _package.component.web;

import _package.component.web.UrlFieldEncoder; // as Encoder
import com.tangosol.util.Base;
import com.tangosol.util.SafeHashMap;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
* This component is used to convert URL ID's to and from JavaBean objects.  URL
* ID's are character data that is embedable in a URL that represents the state
* of a JavaBean, for example of an entity EJB primary key object.  Consider the
* following JavaBean:
* 
* public class PurchaseOrderPK implements Serializable {
*     public PurchaseOrderPK();
* 
*     private int Year;
*     public int getYear() {return Year;}
*     public void setYear(int Year) {this.Year = Year;}
* 
*     private int Period;
*     public int getPeriod() {return Period;}
*     public void setPeriod(int Period) {this.Period = Period;}
* 
*     private int Number;
*     public int getNumber() {return Number;}
*     public void setNumber(int Number) {this.Number = Number;}
* 
*     ...
* }
* 
* This class can be encoded in a URL as follows:
* 
* Year-Period-Number
* 
* Using a convention, a URL can be constructed that identifies the data on
* which an event should act:
* 
* /purchasing/order-2000-6-90.display.cpg
* 
* The converse is true; the URL ID (e.g. "2000-6-90") can be parsed into a
* JavaBean (e.g. an instance of PurchaseOrderPK).
* 
* Example usage of a UrlIdEncoder is as follows:
* 
* 1.  Construction:
* 
* Class clz = PurchaseOrderPK.class;
* String[] asProps = new String[] {"Year", "Period", "Number"};
* UrlIdEncoder encoder = UrlIdEncoder.getEncoder(clz, asProps);
* 
* 2.  Invocation to encode a URL:
* 
* PurchaseOrderPK key = ...
* String sId = encoder.encode(key);
* 
* 3.  Invocation to decode a URL:
* 
* String sId = ...
* PurchaseOrderPK key = (PurchaseOrderPK) encoder.decode(sId);
* 
* The contract supplied by the UrlIdEncoder is as follows:
* 1.  id.equals(encode(decode(id)))
* 2.  bean.equals(decode(encode(bean)))
* (The second rule is true iff the implementation of bean.equals uses only the
* property values that the encoder was constructed with.)
*/
public class UrlIdEncoder
        extends    _package.component.Web
    {
    // Fields declarations
    
    /**
    * Property EncoderCache
    *
    * A cache of encoder objects, used by getEncoder().
    */
    private static transient java.util.Map __s_EncoderCache;
    
    /**
    * Property HashCode
    *
    */
    private int __m_HashCode;
    
    /**
    * Property IdDelimiter
    *
    */
    
    /**
    * Property JavaBeanClass
    *
    * The class of the JavaBean that the encoder instance is intended to work
    * with.  When converting from a URL ID to a JavaBean, the encoder
    * instantiates the JavaBean and uses its mutators to configure the JavaBean
    * from the data in the URL ID.  When converting from a JavaBean to a URL
    * ID, the encoder uses the JavaBean accessors to obtain data from the
    * JavaBean and builds a URL ID out of that data.
    */
    private Class __m_JavaBeanClass;
    
    /**
    * Property PropertyAccessor
    *
    * An array of Method objects which are used to invoke the accessor ("get")
    * methods of the JavaBean.  This array corresponds to the PropertyName
    * array.
    */
    private java.lang.reflect.Method[] __m_PropertyAccessor;
    
    /**
    * Property PropertyClass
    *
    * An array of property types corresponding to PropertyName.
    */
    private Class[] __m_PropertyClass;
    
    /**
    * Property PropertyCount
    *
    * The number of properties on the JavaBean that this encoder is configured
    * to process.  This corresponds to the size of the PropertyName array.
    */
    private int __m_PropertyCount;
    
    /**
    * Property PropertyEncoder
    *
    * An array of UrlFieldEncoder objects which handle the type-specific
    * encoding and decoding of a property's value.  This array corresponds to
    * the PropertyName array.
    */
    private UrlFieldEncoder[] __m_PropertyEncoder;
    
    /**
    * Property PropertyMutator
    *
    * An array of Method objects which are used to invoke the mutator ("set")
    * methods of the JavaBean.  This array corresponds to the PropertyName
    * array.
    */
    private java.lang.reflect.Method[] __m_PropertyMutator;
    
    /**
    * Property PropertyName
    *
    * An array of property names that this encoder will access/mutate on the
    * JavaBean.
    */
    private String[] __m_PropertyName;
    
    // Default constructor
    public UrlIdEncoder()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public UrlIdEncoder(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant IdDelimiter
    public char getIdDelimiter()
        {
        return '~';
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new UrlIdEncoder();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/UrlIdEncoder".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    private void configure()
        {
        // import Component.Web.UrlFieldEncoder as Encoder;
        // import java.lang.reflect.Method;
        // import java.util.Map;
        // import java.util.HashMap;
        
        Class    clz    = getJavaBeanClass();
        String[] asName = getPropertyName();
        
        int       cProps    = asName.length;
        Class[]   aclz      = new Class[cProps];
        Method[]  aAccessor = new Method[cProps];
        Method[]  aMutator  = new Method[cProps];
        Encoder[] aEncoder  = new Encoder[cProps];
        
        // build a lookup table from property name to index
        Map map = new HashMap();
        for (int i = 0; i < cProps; ++i)
            {
            map.put(asName[i], new Integer(i));
            }
        
        // determine the property accessors, and thus the property types
        Method[] aMethod = clz.getMethods();
        for (int i = 0, c = aMethod.length; i < c; ++i)
            {
            Method method = aMethod[i];
            if (method.getParameterTypes().length == 0)
                {
                String sName = method.getName();
                if (sName.startsWith("is"))
                    {
                    sName = sName.substring(2);
                    }
                else if (sName.startsWith("get"))
                    {
                    sName = sName.substring(3);
                    }
                else
                    {
                    sName = null;
                    }
        
                // check if this method is one of the accessors
                if (sName != null)
                    {
                    Integer IProp = (Integer) map.get(sName);
                    if (IProp != null)
                        {
                        int     iProp   = IProp.intValue();
                        Class   clzProp = method.getReturnType();
                        Encoder encoder = Encoder.getEncoder(clzProp);
                        if (encoder == null)
                            {
                            throw new IllegalStateException(
                                "No suitable UrlFieldEncoder located for class (" + clzProp.getName() + ")");
                            }
        
                        aclz     [iProp] = clzProp;
                        aAccessor[iProp] = method;
                        aEncoder [iProp] = encoder;
                        }
                    }
                }
            }
        
        // locate mutators
        Class[] aclzParam = new Class[1];
        for (int i = 0; i < cProps; ++i)
            {
            String sName   = asName[i];
            Class  clzProp = aclz  [i];
            if (clzProp == null)
                {
                throw new IllegalStateException(
                    "No property accessor method located (" + clz.getName() + "." + sName + ")");
                }
        
            aclzParam[0] = clzProp;
            Method method = null;
            try
                {
                method = clz.getMethod("set" + sName, aclzParam);
                }
            catch (NoSuchMethodException e)
                {
                }
        
            if (method == null || !method.getReturnType().equals(Void.TYPE))
                {
                throw new IllegalStateException(
                    "No property mutator method located (" + clz.getName() + "." + sName + ")");
                }
        
            aMutator[i] = method;
            }
        
        setPropertyCount(cProps);
        setPropertyClass(aclz);
        setPropertyAccessor(aAccessor);
        setPropertyMutator(aMutator);
        setPropertyEncoder(aEncoder);
        }
    
    public Object decode(Object o, String sId)
        {
        // import Component.Web.UrlFieldEncoder as Encoder;
        // import com.tangosol.util.Base;
        // import java.lang.reflect.Method;
        
        _assert(o != null && o.getClass().isAssignableFrom(getJavaBeanClass()));
        
        try
            {
            Encoder[] aEncoder  = getPropertyEncoder();
            Method[]  aMethod   = getPropertyMutator();
            Object[]  aoParam   = new Object[1];
        
            String[]  asElement = Base.parseDelimitedString(sId, getIdDelimiter());
            int       cElements = asElement.length;
        
            for (int i = 0, c = getPropertyCount(); i < c; ++i)
                {
                String sElement = i < cElements ? asElement[i] : "";
                Object value = null;
                if (!(sElement.length() == 1 && sElement.charAt(0) == '!'))
                    {
                    value = aEncoder[i].decode(sElement);
                    }
                aoParam[0] = value;
                aMethod[i].invoke(o, aoParam);
                }
        
            return o;
            }
        catch (Exception e)
            {
            throw Base.ensureRuntimeException(e);
            }
        }
    
    public Object decode(String sId)
        {
        // import Component.Web.UrlFieldEncoder as Encoder;
        // import com.tangosol.util.Base;
        // import java.lang.reflect.Method;
        
        try
            {
            Object o = getJavaBeanClass().newInstance();
        
            decode(o, sId);
        
            return o;
            }
        catch (Exception e)
            {
            throw Base.ensureRuntimeException(e);
            }
        }
    
    public String encode(Object o)
        {
        // import Component.Web.UrlFieldEncoder as Encoder;
        // import com.tangosol.util.Base;
        // import java.lang.reflect.Method;
        
        _assert(o != null);
        
        Method[]  aMethod  = getPropertyAccessor();
        Encoder[] aEncoder = getPropertyEncoder();
        char      chDelim  = getIdDelimiter();
        Object[]  aoParam  = new Object[0];
        
        StringBuffer sb = new StringBuffer();
        for (int i = 0, c = getPropertyCount(); i < c; ++i)
            {
            if (i > 0)
                {
                sb.append(chDelim);
                }
        
            Object value = null;
            try
                {
                value = aMethod[i].invoke(o, aoParam);
                }
            catch (Exception e)
                {
                throw Base.ensureRuntimeException(e);
                }
        
            if (value == null)
                {
                sb.append('!');
                }
            else
                {
                sb.append(aEncoder[i].encode(value));
                }
            }
        
        return sb.toString();
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof UrlIdEncoder)
            {
            UrlIdEncoder that = (UrlIdEncoder) obj;
            if (this.hashCode() != that.hashCode() ||
                this.getJavaBeanClass() != that.getJavaBeanClass())
                {
                return false;
                }
        
            String[] asThis = getPropertyName();
            String[] asThat = getPropertyName();
            int cThis = asThis == null ? 0 : asThis.length;
            int cThat = asThat == null ? 0 : asThat.length;
            if (cThis != cThat)
                {
                return false;
                }
        
            for (int i = 0, c = cThis; i < c; ++i)
                {
                if (!asThis[i].equals(asThat[i]))
                    {
                    return false;
                    }
                }
        
            return true;
            }
        
        return false;
        }
    
    public static UrlIdEncoder getEncoder(Class clz, String[] asPropertyName)
        {
        // import java.util.Map;
        
        _assert(clz != null && asPropertyName != null && asPropertyName.length > 0);
        
        // create encoder (unconfigured)
        UrlIdEncoder encoder = new UrlIdEncoder();
        encoder.setJavaBeanClass(clz);
        encoder.setPropertyName(asPropertyName);
        
        // check cache
        Map map = getEncoderCache();
        UrlIdEncoder encoderCached = (UrlIdEncoder) map.get(encoder);
        if (encoderCached != null)
            {
            return encoderCached;
            }
        
        // finish configuring new encoder and store it in the cache
        encoder.configure();
        map.put(clz, encoder);
        return encoder;
        }
    
    // Accessor for the property "EncoderCache"
    private static java.util.Map getEncoderCache()
        {
        // import java.util.Map;
        // import com.tangosol.util.SafeHashMap;
        
        Map map = __s_EncoderCache;
        
        if (map == null)
            {
            map = new SafeHashMap();
            setEncoderCache(map);
            }
        
        return map;
        }
    
    // Accessor for the property "HashCode"
    public int getHashCode()
        {
        int n = __m_HashCode;
        if (n == 0)
            {
            n = getJavaBeanClass().hashCode();
        
            String[] asName = getPropertyName();
            for (int i = 0, c = asName.length; i < c; ++i)
                {
                n ^= asName[i].hashCode();
                }
        
            setHashCode(n);
            }
        
        return n;
        }
    
    // Accessor for the property "JavaBeanClass"
    public Class getJavaBeanClass()
        {
        return __m_JavaBeanClass;
        }
    
    // Accessor for the property "PropertyAccessor"
    private java.lang.reflect.Method[] getPropertyAccessor()
        {
        return __m_PropertyAccessor;
        }
    
    // Accessor for the property "PropertyAccessor"
    public java.lang.reflect.Method getPropertyAccessor(int i)
        {
        return getPropertyAccessor()[i];
        }
    
    // Accessor for the property "PropertyClass"
    private Class[] getPropertyClass()
        {
        return __m_PropertyClass;
        }
    
    // Accessor for the property "PropertyClass"
    public Class getPropertyClass(int i)
        {
        return getPropertyClass()[i];
        }
    
    // Accessor for the property "PropertyCount"
    public int getPropertyCount()
        {
        return __m_PropertyCount;
        }
    
    // Accessor for the property "PropertyEncoder"
    private UrlFieldEncoder[] getPropertyEncoder()
        {
        return __m_PropertyEncoder;
        }
    
    // Accessor for the property "PropertyEncoder"
    public UrlFieldEncoder getPropertyEncoder(int i)
        {
        return getPropertyEncoder()[i];
        }
    
    // Accessor for the property "PropertyMutator"
    private java.lang.reflect.Method[] getPropertyMutator()
        {
        return __m_PropertyMutator;
        }
    
    // Accessor for the property "PropertyMutator"
    public java.lang.reflect.Method getPropertyMutator(int i)
        {
        return getPropertyMutator()[i];
        }
    
    // Accessor for the property "PropertyName"
    private String[] getPropertyName()
        {
        return __m_PropertyName;
        }
    
    // Accessor for the property "PropertyName"
    public String getPropertyName(int i)
        {
        return getPropertyName()[i];
        }
    
    // Declared at the super level
    public int hashCode()
        {
        return getHashCode();
        }
    
    // Accessor for the property "EncoderCache"
    private static void setEncoderCache(java.util.Map map)
        {
        __s_EncoderCache = map;
        }
    
    // Accessor for the property "HashCode"
    public void setHashCode(int n)
        {
        __m_HashCode = n;
        }
    
    // Accessor for the property "JavaBeanClass"
    private void setJavaBeanClass(Class clz)
        {
        __m_JavaBeanClass = clz;
        }
    
    // Accessor for the property "PropertyAccessor"
    private void setPropertyAccessor(java.lang.reflect.Method[] aMethod)
        {
        __m_PropertyAccessor = aMethod;
        }
    
    // Accessor for the property "PropertyAccessor"
    private void setPropertyAccessor(int i, java.lang.reflect.Method method)
        {
        getPropertyAccessor()[i] = method;
        }
    
    // Accessor for the property "PropertyClass"
    private void setPropertyClass(Class[] aclz)
        {
        __m_PropertyClass = aclz;
        }
    
    // Accessor for the property "PropertyClass"
    private void setPropertyClass(int i, Class clz)
        {
        getPropertyClass()[i] = clz;
        }
    
    // Accessor for the property "PropertyCount"
    private void setPropertyCount(int c)
        {
        __m_PropertyCount = c;
        }
    
    // Accessor for the property "PropertyEncoder"
    private void setPropertyEncoder(UrlFieldEncoder[] aEncoder)
        {
        __m_PropertyEncoder = aEncoder;
        }
    
    // Accessor for the property "PropertyEncoder"
    private void setPropertyEncoder(int i, UrlFieldEncoder encoder)
        {
        getPropertyEncoder()[i] = encoder;
        }
    
    // Accessor for the property "PropertyMutator"
    private void setPropertyMutator(java.lang.reflect.Method[] aMethod)
        {
        __m_PropertyMutator = aMethod;
        }
    
    // Accessor for the property "PropertyMutator"
    private void setPropertyMutator(int i, java.lang.reflect.Method method)
        {
        getPropertyMutator()[i] = method;
        }
    
    // Accessor for the property "PropertyName"
    private void setPropertyName(String[] asName)
        {
        __m_PropertyName = asName;
        }
    
    // Accessor for the property "PropertyName"
    private void setPropertyName(int i, String sName)
        {
        getPropertyName()[i] = sName;
        }
    }
