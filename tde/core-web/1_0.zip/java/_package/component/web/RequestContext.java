/* Class
*     _package.component.web.RequestContext
*/

package _package.component.web;

import _package.component.Application;
import _package.component.application.Enterprise;
import com.tangosol.run.component.ExecutionContext;
import com.tangosol.run.component.ExecutionContextAware;
import com.tangosol.util.ErrorList$Constants; // as Constants
import com.tangosol.util.ErrorList;
import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.PageContext;

public class RequestContext
        extends    _package.component.Web
        implements com.tangosol.run.component.ExecutionContext
    {
    // Fields declarations
    
    /**
    * Property Application
    *
    * Obtains the Enterprise Application component for the application.
    */
    
    /**
    * Property ATTR_AWARE_LIST
    *
    * Attribute name used to store the list of ExecutionContextAware objects
    */
    private static final String ATTR_AWARE_LIST = "RequestContext.AwareList";
    
    /**
    * Property ATTR_CALLING_CONTEXT
    *
    * Attribute name used to store the caling context assosiated with a current
    * http request.
    * 
    * @see Application.Enterprise#registerContext
    */
    private static final String ATTR_CALLING_CONTEXT = "RequestContext.CallingContext";
    
    /**
    * Property ATTR_ERROR_LIST
    *
    * Attribute name used to store the error list
    */
    private static final String ATTR_ERROR_LIST = "RequestContext.ErrorList";
    
    /**
    * Property Authenticated
    *
    */
    
    /**
    * Property AwareList
    *
    * A list of objects implementing ExecutionContextAware interface that are
    * to be notified when the request terminates
    */
    private transient java.util.List __m_AwareList;
    
    /**
    * Property CallingContext
    *
    * Helper property retrieving the calling context form the request
    * attribute.
    * 
    * @see also #executionInitialized
    */
    
    /**
    * Property CookieConfig
    *
    */
    private transient RequestContext$CookieConfig __m_CookieConfig;
    
    /**
    * Property EntryHttp
    *
    */
    private transient Http __m_EntryHttp;
    
    /**
    * Property Error
    *
    * Set to true when an error is logged that should stop request processing.
    */
    private boolean __m_Error;
    
    /**
    * Property ErrorList
    *
    */
    private transient com.tangosol.util.ErrorList __m_ErrorList;
    
    /**
    * Property ExitHttp
    *
    */
    private transient Http __m_ExitHttp;
    
    /**
    * Property OuterContext
    *
    */
    private transient com.tangosol.run.component.ExecutionContext __m_OuterContext;
    
    /**
    * Property PageContext
    *
    */
    private transient javax.servlet.jsp.PageContext __m_PageContext;
    
    /**
    * Property Request
    *
    */
    private transient javax.servlet.http.HttpServletRequest __m_Request;
    
    /**
    * Property Response
    *
    */
    private transient javax.servlet.http.HttpServletResponse __m_Response;
    
    /**
    * Property SCOPE_APPLICATION
    *
    */
    public static final int SCOPE_APPLICATION = 5;
    
    /**
    * Property SCOPE_COOKIE
    *
    */
    public static final int SCOPE_COOKIE = 4;
    
    /**
    * Property SCOPE_NONE
    *
    */
    public static final int SCOPE_NONE = 0;
    
    /**
    * Property SCOPE_PAGE
    *
    */
    public static final int SCOPE_PAGE = 1;
    
    /**
    * Property SCOPE_REQUEST
    *
    */
    public static final int SCOPE_REQUEST = 2;
    
    /**
    * Property SCOPE_SESSION
    *
    */
    public static final int SCOPE_SESSION = 3;
    
    /**
    * Property Secure
    *
    */
    
    /**
    * Property ServletConfig
    *
    */
    private transient javax.servlet.ServletConfig __m_ServletConfig;
    
    /**
    * Property ServletContext
    *
    */
    private transient javax.servlet.ServletContext __m_ServletContext;
    
    /**
    * Property Session
    *
    */
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("CookieConfig", RequestContext$CookieConfig.get_CLASS());
        }
    
    // Default constructor
    public RequestContext()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public RequestContext(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new RequestContext();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/RequestContext".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    public javax.servlet.http.HttpSession ensureSession()
        {
        return getRequest().getSession();
        }
    
    // From interface: com.tangosol.run.component.ExecutionContext
    public void executionInitialized(com.tangosol.run.component.ExecutionContext ctxOuter)
        {
        if (ctxOuter instanceof RequestContext)
            {
            RequestContext ctx = (RequestContext) ctxOuter;
            setOuterContext(ctx);
            setEntryHttp(ctx.getExitHttp());
            }
        ensureSession().removeAttribute(ATTR_CALLING_CONTEXT);

        }
    
    // From interface: com.tangosol.run.component.ExecutionContext
    public void executionResumed(com.tangosol.run.component.ExecutionContext ctxInner)
        {
        }
    
    // From interface: com.tangosol.run.component.ExecutionContext
    public void executionSuspended(com.tangosol.run.component.ExecutionContext ctxInner)
        {
        }
    
    // From interface: com.tangosol.run.component.ExecutionContext
    public void executionTerminated(com.tangosol.run.component.ExecutionContext ctxOuter)
        {
        // import com.tangosol.util.ErrorList;
        // import java.io.PrintWriter;
        
        RequestContext ctx =
            ctxOuter instanceof RequestContext ? (RequestContext) ctxOuter : null;
        
        // check if this is the outer-most context for this request
        if (ctx == null || ctx.getRequest() != getRequest())
            {
            // handle automatic cleanup of objects that are used in request scope
            unregisterAwareList();
        
            // debug echo to the browser if possible
            if (getApplication().isEnableDebugEcho())
                {
                ErrorList errlist = getErrorList();
                if (errlist != null && !errlist.isEmpty())
                    {
                    try
                        {
                        // this is certain suicide if the stream has been
                        // closed or an error has been sent or the response
                        // is not HTML etc. etc. but it is for debugging
                        // purposes only
                        PrintWriter writer = getResponse().getWriter();
                        writer.println("\n<hr>\n");
                        writer.println(errlist.toString());
                        }
                    catch (Exception e) {}
                    }
                }
            }
        
        // transfer error state up
        if (ctx != null && isError() && !ctx.isError())
            {
            ctx.setError(true);
            }
        
        setEntryHttp(null);
        setOuterContext(null);

        }
    
    public void forward(String url, Http httpOrigin)
            throws javax.servlet.ServletException
        {
        // import java.io.IOException;
        // import javax.servlet.RequestDispatcher;
        // import javax.servlet.ServletException;
        
        // url must start with a forward slash
        if (url != null && url.length() > 0 && url.charAt(0) != '/')
            {
            url = '/' + url;
            }
        
        RequestDispatcher disp = getServletContext().getRequestDispatcher(url);
        if (disp == null)
            {
            throw new ServletException("RequestContext.forward:  Unable to obtain a"
                    + " RequestDispatcher for the URL \"" + url + "\"");
            }
        
        // Unfortuantely the "forward" call doesn't preserve the
        // request-scope attributes and we have to put this context into
        // the session-scope attribute for the short time until the "receiver"
        // picks it up (see "getCallingContext" and "executionInitialized")
        // This could create a race condition with another request of the same session...
        ensureSession().setAttribute(ATTR_CALLING_CONTEXT, this);
        
        setExitHttp(httpOrigin);
        try
            {
            disp.forward(getRequest(), getResponse());
            }
        catch (IOException e)
            {
            _trace("forward failed: " + url);
            throw new ServletException(e);
            }
        finally
            {
            // Some app servers implement the "forward" calls by posting them in a queue
            // and invoking on different threads after the "forward" method returns.
            // To preserve the logical flow, we don't unregister here ...
        
            // getApplication().resumeContext(this);
            // setExitHttp(null);
            }
        }
    
    // Accessor for the property "Application"
    public _package.component.application.Enterprise getApplication()
        {
        // import Component.Application;
        // import Component.Application.Enterprise;
        
        return (Enterprise) Application.get_Instance();
        }
    
    public Object getAttribute(String sName)
        {
        // import javax.servlet.http.HttpSession;
        // import javax.servlet.jsp.PageContext;
        
        // note the blanket runtime exception catch for getAttribute calls; the
        // assumption is that another thread could remove the same attribute; also,
        // there are web container implementation-specific abnormalities regarding
        // attribute access
        
        Object o = null;
        
        // SCOPE_PAGE
        PageContext ctx = getPageContext();
        if (ctx != null)
            {
            try
                {
                o = ctx.getAttribute(sName);
                if (o != null)
                    {
                    return o;
                    }
                }
            catch (Exception e) {}
            }
        
        // SCOPE_REQUEST
        try
            {
            o = getRequest().getAttribute(sName);
            if (o != null)
                {
                return o;
                }
            }
        catch (Exception e) {}
        
        // SCOPE_SESSION
        HttpSession session = getSession();
        if (session != null)
            {
            try
                {
                o = session.getAttribute(sName);
                if (o != null)
                    {
                    return o;
                    }
                }
            catch (Exception e) {}
            }
        
        // SCOPE_APPLICATION
        try
            {
            o = getServletContext().getAttribute(sName);
            if (o != null)
                {
                return o;
                }
            }
        catch (Exception e) {}
        
        // SCOPE_NONE
        return null;
        }
    
    public Object getAttribute(String sName, int nScope)
        {
        // import javax.servlet.http.HttpSession;
        // import javax.servlet.jsp.PageContext;
        
        // note the blanket runtime exception catch for getAttribute calls; the
        // assumption is that another thread could remove the same attribute; also,
        // there are web container implementation-specific abnormalities regarding
        // attribute access
        
        switch (nScope)
            {
            case SCOPE_NONE:
                return null;
        
            case SCOPE_PAGE:
                {
                PageContext ctx = getPageContext();
                if (ctx == null)
                    {
                    return null;
                    }
        
                try
                    {
                    return ctx.getAttribute(sName);
                    }
                catch (Exception e)
                    {
                    return null;
                    }
                }
        
            case SCOPE_REQUEST:
                try
                    {
                    return getRequest().getAttribute(sName);
                    }
                catch (Exception e)
                    {
                    return null;
                    }
        
            case SCOPE_SESSION:
                {
                HttpSession session = getSession();
                if (session == null)
                    {
                    return null;
                    }
        
                try
                    {
                    return getSession().getAttribute(sName);
                    }
                catch (Exception e)
                    {
                    return null;
                    }
                }
        
            case SCOPE_APPLICATION:
                try
                    {
                    return getServletContext().getAttribute(sName);
                    }
                catch (Exception e)
                    {
                    return null;
                    }
            
            case SCOPE_COOKIE:
            default:
                throw new IllegalStateException("getAttribute(sName, request, nScope):  "
                        + "Scope not supported (" + nScope + ")");
            }
        }
    
    public int getAttributeScope(String sName)
        {
        // import javax.servlet.http.HttpSession;
        // import javax.servlet.jsp.PageContext;
        
        // note the blanket runtime exception catch for getAttribute calls; the
        // assumption is that another thread could remove the same attribute; also,
        // there are web container implementation-specific abnormalities regarding
        // attribute access
        
        PageContext ctx = getPageContext();
        if (ctx != null)
            {
            try
                {
                if (ctx.getAttribute(sName) != null)
                    {
                    return SCOPE_PAGE;
                    }
                }
            catch (Exception e) {}
            }
        
        try
            {
            if (getRequest().getAttribute(sName) != null)
                {
                return SCOPE_REQUEST;
                }
            }
        catch (Exception e) {}
        
        HttpSession session = getSession();
        if (session != null)
            {
            try
                {
                if (session.getAttribute(sName) != null)
                    {
                    return SCOPE_SESSION;
                    }
                }
            catch (Exception e) {}
            }
        
        try
            {
            if (getServletContext().getAttribute(sName) != null)
                {
                return SCOPE_APPLICATION;
                }
            }
        catch (Exception e) {}
        
        return SCOPE_NONE;
        }
    
    // Accessor for the property "AwareList"
    public java.util.List getAwareList()
        {
        // import java.util.List;
        
        return (List) getRequest().getAttribute(ATTR_AWARE_LIST);
        }
    
    // Accessor for the property "CallingContext"
    /**
    * Obtains the RequestContext component for the current request
    */
    public RequestContext getCallingContext()
        {
        // import javax.servlet.http.HttpSession;
        
        HttpSession session = getSession();
        return session == null ? null :
            (RequestContext) session.getAttribute(ATTR_CALLING_CONTEXT);

        }
    
    // Accessor for the property "CookieConfig"
    public RequestContext$CookieConfig getCookieConfig()
        {
        // import javax.servlet.http.Cookie;
        // import com.tangosol.run.component.ExecutionContext;
        
        $CookieConfig cfg = __m_CookieConfig;
        
        if (cfg == null)
            {
            ExecutionContext ctx = getOuterContext();
            cfg = ctx instanceof RequestContext ?
                ((RequestContext) ctx).getCookieConfig() : instantiateCookieConfig();
            setCookieConfig(cfg);
            }
        
        return cfg;
        }
    
    // Accessor for the property "EntryHttp"
    public Http getEntryHttp()
        {
        return __m_EntryHttp;
        }
    
    // Accessor for the property "ErrorList"
    public com.tangosol.util.ErrorList getErrorList()
        {
        // import com.tangosol.util.ErrorList;
        
        return (ErrorList) getRequest().getAttribute(ATTR_ERROR_LIST);
        }
    
    // Accessor for the property "ExitHttp"
    public Http getExitHttp()
        {
        return __m_ExitHttp;
        }
    
    // From interface: com.tangosol.run.component.ExecutionContext
    // Accessor for the property "OuterContext"
    public com.tangosol.run.component.ExecutionContext getOuterContext()
        {
        return __m_OuterContext;
        }
    
    // Accessor for the property "PageContext"
    public javax.servlet.jsp.PageContext getPageContext()
        {
        return __m_PageContext;
        }
    
    // Accessor for the property "Request"
    public javax.servlet.http.HttpServletRequest getRequest()
        {
        return __m_Request;
        }
    
    // Accessor for the property "Response"
    public javax.servlet.http.HttpServletResponse getResponse()
        {
        return __m_Response;
        }
    
    // Accessor for the property "ServletConfig"
    public javax.servlet.ServletConfig getServletConfig()
        {
        return __m_ServletConfig;
        }
    
    // Accessor for the property "ServletContext"
    public javax.servlet.ServletContext getServletContext()
        {
        return __m_ServletContext;
        }
    
    // Accessor for the property "Session"
    public javax.servlet.http.HttpSession getSession()
        {
        return getRequest().getSession(false);
        }
    
    public void include(String url, Http httpOrigin)
            throws javax.servlet.ServletException
        {
        // import java.io.IOException;
        // import javax.servlet.RequestDispatcher;
        // import javax.servlet.ServletException;
        
        // url must start with a forward slash
        if (url != null && url.length() > 0 && url.charAt(0) != '/')
            {
            url = '/' + url;
            }
        
        RequestDispatcher disp = getServletContext().getRequestDispatcher(url);
        if (disp == null)
            {
            throw new ServletException("RequestContext.include:  Unable to obtain a"
                    + " RequestDispatcher for the URL \"" + url + "\"");
            }
        
        setExitHttp(httpOrigin);
        try
            {
            disp.include(getRequest(), getResponse());
            }
        catch (IOException e)
            {
            throw new ServletException(e);
            }
        finally
            {
            getApplication().resumeContext(this);
            setExitHttp(null);
            }
        }
    
    protected RequestContext$CookieConfig instantiateCookieConfig()
        {
        // the cookie comes from the request, so the request is required
        _assert(getRequest() != null);
        
        $CookieConfig cfg = ($CookieConfig) _newChild("CookieConfig");
        return cfg;
        }
    
    // Accessor for the property "Authenticated"
    public boolean isAuthenticated()
        {
        return getRequest().getRemoteUser() != null;
        }
    
    // Accessor for the property "Error"
    public boolean isError()
        {
        return __m_Error;
        }
    
    // Accessor for the property "Secure"
    public boolean isSecure()
        {
        return getRequest().isSecure();
        }
    
    public void log(String sMessage, int nSeverity)
        {
        // import com.tangosol.util.ErrorList;
        // import com.tangosol.util.ErrorList$Constants as Constants;
        
        ErrorList errlist = getErrorList();
        if (errlist == null)
            {
            errlist = new ErrorList();
            setErrorList(errlist);
            }
        
        if (nSeverity == 0)
            {
            errlist.addInfo(sMessage);
            }
        else
            {
            errlist.addError(sMessage);
            }
        }
    
    /**
    * TODO: unused
    */
    public void registerObject(com.tangosol.run.component.ExecutionContextAware oAware)
        {
        // import java.util.List;
        // import java.util.LinkedList;
        
        List list = getAwareList();
        if (list == null)
            {
            list = new LinkedList();
            setAwareList(list);
            }
        
        list.add(oAware);
        
        try
            {
            oAware.valueBound(this);
            }
        catch (Exception e)
            {
            _trace("An exception occurred while binding an"
                + " ExecutionContextAware object:", 1);
            _trace(e);
            }
        }
    
    public void removeAttribute(String sName)
        {
        removeAttribute(sName, getAttributeScope(sName));
        }
    
    public void removeAttribute(String sName, int nScope)
        {
        // import javax.servlet.http.HttpSession;
        // import javax.servlet.jsp.PageContext;
        
        // note the blanket runtime exception catch for getAttribute calls; the
        // assumption is that another thread could remove the same attribute; also,
        // there are web container implementation-specific abnormalities regarding
        // attribute access
        
        switch (nScope)
            {
            case SCOPE_NONE:
                break;
        
            case SCOPE_PAGE:
                {
                PageContext ctx = getPageContext();
                if (ctx != null)
                    {
                    try
                        {
                        ctx.removeAttribute(sName);
                        }
                    catch (Exception e) {}
                    }
                }
                break;
        
            case SCOPE_REQUEST:
                try
                    {
                    getRequest().removeAttribute(sName);
                    }
                catch (Exception e) {}
                break;
        
            case SCOPE_SESSION:
                {
                HttpSession session = getSession();
                if (session != null)
                    {
                    try
                        {
                        session.removeAttribute(sName);
                        }
                    catch (Exception e) {}
                    }
                }
                break;
        
            case SCOPE_APPLICATION:
                try
                    {
                    getServletContext().removeAttribute(sName);
                    }
                catch (Exception e) {}
                break;
            
            default:
                throw new IllegalStateException("removeAttribute(sName, request):  "
                    + "Scope not supported (" + nScope + ")");
            }
        }
    
    public void sendError(int nStatus, String sDesc)
        {
        boolean fFirstError = !isError();
        boolean fDebugEcho  = getApplication().isEnableDebugEcho();
        
        if (fFirstError)
            {
            setError(true);
        
            // debug echo may end up going back to the browser
            if (!fDebugEcho)
                {
                // send error back to client, closing the response
                try
                    {
                    nStatus = translateError(nStatus);
                    if (sDesc == null || sDesc.length() == 0)
                        {
                        getResponse().sendError(nStatus);
                        }
                    else
                        {
                        getResponse().sendError(nStatus, sDesc);
                        }
                    }
                catch (Exception e)
                    {
                    // ingore; too late to send an error to the client
                    // (see doc for javax.servlet.http.HttpServletResponse)
                    }
                }
            }
        
        if (fDebugEcho)
            {
            _trace("RequestContext.sendError(" + nStatus + ", \"" + sDesc + "\") "
                    + (fFirstError ? "" : " --> additional error"), 1);
            }
        }
    
    public void setAttribute(String sName, Object oValue)
        {
        setAttribute(sName, oValue, getPageContext() == null ? SCOPE_REQUEST : SCOPE_PAGE);
        }
    
    public void setAttribute(String sName, Object oValue, int nScope)
        {
        // import javax.servlet.jsp.PageContext;
        
        _assert(sName != null);
        
        if (oValue == null)
            {
            // value must not be null, so assume null value implies remove
            removeAttribute(sName);
            }
        else
            {
            // the spec states that there exists a name-space composed of request, session, and
            // application attributes, and that a name cannot therefore exist at multiple levels
            // within that namespace
            int nPrevScope = getAttributeScope(sName);
            if (nPrevScope != SCOPE_NONE && nScope != nPrevScope)
                {
                if (nScope > nPrevScope)
                    {
                    // scope is increasing; this is supported; remove the attribute from
                    // the smaller scope so that it is legal to add it to the larger scope
                    removeAttribute(sName, nPrevScope);
                    }
                else if (nPrevScope == SCOPE_APPLICATION)
                    {
                    // automatic scope reduction from application-level is not supported;
                    // (because it probably is a bug wherein the name of an attribute was
                    // accidently re-used)
                    throw new IllegalArgumentException("setAttribute(sName, oValue, nScope):  "
                            + "Application attribute " + sName + " cannot be hidden");
                    }
                else
                    {
                    // previous scope was larger so use it (i.e. session instead of request)
                    nScope = nPrevScope;
                    }
                }
        
            // store the attribute
            switch (nScope)
                {
                case SCOPE_NONE:
                    break;
        
                case SCOPE_PAGE:
                    PageContext ctx = getPageContext();
                    if (ctx != null)
                        {
                        ctx.setAttribute(sName, oValue);
                        break;
                        }
                    // fall through
        
                case SCOPE_REQUEST:
                    getRequest().setAttribute(sName, oValue);
                    break;
        
                case SCOPE_SESSION:
                    ensureSession().setAttribute(sName, oValue);
                    break;
        
                case SCOPE_APPLICATION:
                    getServletContext().setAttribute(sName, oValue);
                    break;
        
                default:
                    throw new IllegalArgumentException("setAttribute(sName, oValue, nScope):  "
                            + "Unsupported scope (" + nScope + ")");
                }
            }
        }
    
    // Accessor for the property "AwareList"
    protected void setAwareList(java.util.List list)
        {
        getRequest().setAttribute(ATTR_AWARE_LIST, list);
        }
    
    // Accessor for the property "CookieConfig"
    public void setCookieConfig(RequestContext$CookieConfig cfg)
        {
        __m_CookieConfig = cfg;
        }
    
    // Accessor for the property "EntryHttp"
    public void setEntryHttp(Http pEntryHttp)
        {
        __m_EntryHttp = pEntryHttp;
        }
    
    // Accessor for the property "Error"
    public void setError(boolean f)
        {
        __m_Error = f;
        }
    
    // Accessor for the property "ErrorList"
    public void setErrorList(com.tangosol.util.ErrorList errlist)
        {
        getRequest().setAttribute(ATTR_ERROR_LIST, errlist);
        }
    
    // Accessor for the property "ExitHttp"
    public void setExitHttp(Http pExitHttp)
        {
        __m_ExitHttp = pExitHttp;
        }
    
    // Accessor for the property "OuterContext"
    protected void setOuterContext(com.tangosol.run.component.ExecutionContext ctx)
        {
        __m_OuterContext = ctx;
        }
    
    // Accessor for the property "PageContext"
    public void setPageContext(javax.servlet.jsp.PageContext ctx)
        {
        __m_PageContext = ctx;
        }
    
    // Accessor for the property "Request"
    public void setRequest(javax.servlet.http.HttpServletRequest request)
        {
        __m_Request = request;
        }
    
    // Accessor for the property "Response"
    public void setResponse(javax.servlet.http.HttpServletResponse response)
        {
        __m_Response = response;
        }
    
    // Accessor for the property "ServletConfig"
    public void setServletConfig(javax.servlet.ServletConfig cfg)
        {
        __m_ServletConfig = cfg;
        }
    
    // Accessor for the property "ServletContext"
    public void setServletContext(javax.servlet.ServletContext ctx)
        {
        __m_ServletContext = ctx;
        }
    
    // Declared at the super level
    public String toString()
        {
        return toString(getRequest());
        }
    
    public static String toString(Object[] ao)
        {
        // import javax.servlet.http.Cookie;
        
        if (ao == null)
            {
            return String.valueOf(ao);
            }
        
        StringBuffer sb = new StringBuffer();
        
        for (int i = 0, c = ao.length; i < c; ++i)
            {
            sb.append("\n    [")
              .append(i)
              .append("]=");
        
            Object o = ao[i];
            if (o instanceof Cookie)
                {
                sb.append(toString((Cookie) o));
                }
            else
                {
                sb.append(ao[i]);
                }
            }
        
        return sb.toString();
        }
    
    public static String toString(java.util.Enumeration enum)
        {
        if (enum == null)
            {
            return String.valueOf(enum);
            }
        
        return toString(com.tangosol.util.SimpleEnumerator.toArray(enum));
        }
    
    public static String toString(javax.servlet.http.Cookie cookie)
        {
        if (cookie == null)
            {
            return String.valueOf(cookie);
            }
        
        StringBuffer sb = new StringBuffer();
        
        sb.append(cookie)
          .append("\n        getComment()=" + cookie.getComment())
          .append("\n        getDomain()=" + cookie.getDomain())
          .append("\n        getMaxAge()=" + cookie.getMaxAge())
          .append("\n        getName()=" + cookie.getName())
          .append("\n        getPath()=" + cookie.getPath())
          .append("\n        getSecure()=" + cookie.getSecure())
          .append("\n        getValue()=" + cookie.getValue())
          .append("\n        getVersion()=" + cookie.getVersion());
        
        return sb.toString();
        }
    
    public static String toString(javax.servlet.http.HttpServletRequest request)
        {
        // import java.util.Enumeration;
        
        StringBuffer sb = new StringBuffer();
        
        sb.append("getAttributeNames()=")
          .append(toString(request.getAttributeNames()));
        
        for (Enumeration enum = request.getAttributeNames(); enum.hasMoreElements(); )
            {
            // despite our expectations weblogic may put an object
            // of type weblogic.security.acl.internal.AuthenticatedUser
            // into this enumeration instead of the name ...
            Object oName = enum.nextElement();
            if (oName instanceof String)
                {
                String sName = (String) oName;
                Object oAttr = request.getAttribute(sName);
        
                sb.append("\ngetAttribute(\"")
                  .append(sName)
                  .append("\")=");
        
                if (oAttr == null || oAttr instanceof String)
                    {
                    sb.append(oAttr);
                    }
                else
                    {
                    sb.append("Value of class " + oAttr.getClass().getName());
                    }
                }
            else
                {
                sb.append("\nAttribute " + oName.toString() +
                    " of class " + oName.getClass().getName());
                }
            }
        
        sb.append("\ngetAuthType()=")
          .append(request.getAuthType())
          .append("\ngetCharacterEncoding()=")
          .append(request.getCharacterEncoding())
          .append("\ngetContentLength()=")
          .append(request.getContentLength())
          .append("\ngetContextPath()=")
          .append(request.getContextPath())
          .append("\ngetContentType()=")
          .append(request.getContentType())
          .append("\ngetCookies()=")
          .append(toString(request.getCookies()))
          .append("\ngetHeaderNames()=")
          .append(toString(request.getHeaderNames()));
        
        for (Enumeration enum = request.getHeaderNames(); enum.hasMoreElements(); )
            {
            String sName = (String) enum.nextElement();
            sb.append("\ngetHeaders(\"")
              .append(sName)
              .append("\")=")
              .append(toString(request.getHeaders(sName)));
            }
        
        sb.append("\ngetLocale()=")
          .append(request.getLocale())
          .append("\ngetLocales()=")
          .append(toString(request.getLocales()))
          .append("\ngetMethod()=")
          .append(request.getMethod())
          .append("\ngetParameterNames()=")
          .append(toString(request.getParameterNames()));
        
        for (Enumeration enum = request.getParameterNames(); enum.hasMoreElements(); )
            {
            String sName = (String) enum.nextElement();
            sb.append("\ngetParameterValues(\"")
              .append(sName)
              .append("\")=")
              .append(toString(request.getParameterValues(sName)));
            }
        
        sb.append("\ngetPathInfo()=")
          .append(request.getPathInfo())
          .append("\ngetPathTranslated()=")
          .append(request.getPathTranslated())
          .append("\ngetProtocol()=")
          .append(request.getProtocol())
          .append("\ngetQueryString()=")
          .append(request.getQueryString())
          .append("\ngetRemoteAddr()=")
          .append(request.getRemoteAddr())
          .append("\ngetRemoteHost()=")
          .append(request.getRemoteHost())
          .append("\ngetRemoteUser()=")
          .append(request.getRemoteUser())
          .append("\ngetRequestedSessionId()=")
          .append(request.getRequestedSessionId())
          .append("\ngetRequestURI()=")
          .append(request.getRequestURI())
          .append("\ngetScheme()=")
          .append(request.getScheme())
          .append("\ngetServerName()=")
          .append(request.getServerName())
          .append("\ngetServerPort()=")
          .append(request.getServerPort())
          .append("\ngetServletPath()=")
          .append(request.getServletPath())
          .append("\ngetSession()=")
          .append(toString(request.getSession(false)))
          .append("\ngetUserPrincipal()=")
          .append(request.getUserPrincipal())
          .append("\nisRequestedSessionIdFromCookie()=")
          .append(request.isRequestedSessionIdFromCookie())
          .append("\nisRequestedSessionIdFromURL()=")
          .append(request.isRequestedSessionIdFromURL())
          .append("\nisRequestedSessionIdValid()=")
          .append(request.isRequestedSessionIdValid())
          .append("\nisSecure()=")
          .append(request.isSecure());
        
        return sb.toString();
        }
    
    public static String toString(javax.servlet.http.HttpSession session)
        {
        // import java.util.Date;
        // import java.util.Enumeration;
        
        if (session == null)
            {
            return String.valueOf(session);
            }
        
        StringBuffer sb = new StringBuffer();
        
        sb.append(session)
          .append("\n    getAttributeNames()=");
        
        int i = 0;
        for (Enumeration enum = session.getAttributeNames(); enum.hasMoreElements(); )
            {
            sb.append("\n        [")
              .append(i)
              .append("]=")
              .append(enum.nextElement());
            }
        
        for (Enumeration enum = session.getAttributeNames(); enum.hasMoreElements(); )
            {
            String sName = (String) enum.nextElement();
            Object oAttr = session.getAttribute(sName);
        
            sb.append("\n    getAttribute(\"")
              .append(sName)
              .append("\")=");
        
            if (oAttr == null || oAttr instanceof String)
                {
                sb.append(oAttr);
                }
            else
                {
                sb.append("Value of class " + oAttr.getClass().getName());
                }
            }
        
        sb.append("\n    getCreationTime()=" + new Date(session.getCreationTime()))
          .append("\n    getId()=" + session.getId())
          .append("\n    getLastAccessedTime()=" + new Date(session.getLastAccessedTime()))
          .append("\n    getMaxInactiveInterval()=" + session.getMaxInactiveInterval())
          .append("\n    isNew()=" + session.isNew());
        
        return sb.toString();
        }
    
    public static String toString(javax.servlet.jsp.PageContext page)
        {
        StringBuffer sb = new StringBuffer();
        
        sb.append("Scope: PAGE")
          .append(toString(page, SCOPE_PAGE))
          .append("\nScope: REQUEST")
          .append(toString(page, SCOPE_REQUEST))
          .append("\nScope: SESSION")
          .append(toString(page, SCOPE_SESSION));
        
        return sb.toString();
        }
    
    public static String toString(javax.servlet.jsp.PageContext page, int iScope)
        {
        // import java.util.Enumeration;
        
        StringBuffer sb = new StringBuffer();
        
        for (Enumeration enum = page.getAttributeNamesInScope(iScope); enum.hasMoreElements(); )
            {
            String sName = (String) enum.nextElement();
        
            sb.append("\ngetAttribute(\"")
              .append(sName)
              .append("\")=")
              .append(page.getAttribute(sName, iScope));
            }
        
        return sb.toString();
        }
    
    public static String toString(javax.servlet.ServletConfig config)
        {
        // import java.util.Enumeration;
        
        StringBuffer sb = new StringBuffer();
        
        sb.append("getServletName()=")
          .append(config.getServletName());
        
        for (Enumeration enum = config.getInitParameterNames(); enum.hasMoreElements(); )
            {
            String sName = (String) enum.nextElement();
        
            sb.append("\ngetInitParameter(\"")
              .append(sName)
              .append("\")=")
              .append(config.getInitParameter(sName));
            }
        
        return sb.toString();
        }
    
    public static String toString(javax.servlet.ServletContext context)
        {
        // import java.util.Enumeration;
        
        StringBuffer sb = new StringBuffer();
        
        sb.append("getMajorVersion()=")
          .append(context.getMajorVersion())
          .append("\ngetMinorVersion()=")
          .append(context.getMinorVersion());
        
        for (Enumeration enum = context.getInitParameterNames(); enum.hasMoreElements(); )
            {
            String sName = (String) enum.nextElement();
        
            sb.append("\ngetInitParameter(\"")
              .append(sName)
              .append("\")=")
              .append(context.getInitParameter(sName));
            }
        
        for (Enumeration enum = context.getAttributeNames(); enum.hasMoreElements(); )
            {
            String sName = (String) enum.nextElement();
        
            sb.append("\ngetAttribute(\"")
              .append(sName)
              .append("\")=")
              .append(context.getAttribute(sName));
            }
        
        return sb.toString();
        }
    
    public int translateError(int nStatus)
        {
        // import javax.servlet.http.HttpServletResponse;
        
        switch (nStatus)
            {
            // Status code (100) indicating the client can continue.
            case HttpServletResponse.SC_CONTINUE:
        
            // Status code (101) indicating the server is switching protocols
            // according to Upgrade header.
            case HttpServletResponse.SC_SWITCHING_PROTOCOLS:
        
            // Status code (200) indicating the request succeeded normally.
            case HttpServletResponse.SC_OK:
        
            // Status code (201) indicating the request succeeded and created
            // a new resource on the server.
            case HttpServletResponse.SC_CREATED:
        
            // Status code (202) indicating that a request was accepted for
            // processing, but was not completed.
            case HttpServletResponse.SC_ACCEPTED:
        
            // Status code (203) indicating that the meta information presented
            // by the client did not originate from the server.
            case HttpServletResponse.SC_NON_AUTHORITATIVE_INFORMATION:
        
            // Status code (204) indicating that the request succeeded but that
            // there was no new information to return.
            case HttpServletResponse.SC_NO_CONTENT:
        
            // Status code (205) indicating that the agent <em>SHOULD</em> reset
            // the document view which caused the request to be sent.
            case HttpServletResponse.SC_RESET_CONTENT:
        
            // Status code (206) indicating that the server has fulfilled
            // the partial GET request for the resource.
            case HttpServletResponse.SC_PARTIAL_CONTENT:
        
            // Status code (300) indicating that the requested resource
            // corresponds to any one of a set of representations, each with
            // its own specific location.
            case HttpServletResponse.SC_MULTIPLE_CHOICES:
        
            // Status code (301) indicating that the resource has permanently
            // moved to a new location, and that future references should use a
            // new URI with their requests.
            case HttpServletResponse.SC_MOVED_PERMANENTLY:
        
            // Status code (302) indicating that the resource has temporarily
            // moved to another location, but that future references should
            // still use the original URI to access the resource.
            case HttpServletResponse.SC_MOVED_TEMPORARILY:
        
            // Status code (303) indicating that the response to the request
            // can be found under a different URI.
            case HttpServletResponse.SC_SEE_OTHER:
        
            // Status code (304) indicating that a conditional GET operation
            // found that the resource was available and not modified.
            case HttpServletResponse.SC_NOT_MODIFIED:
        
            // Status code (305) indicating that the requested resource
            // <em>MUST</em> be accessed through the proxy given by the
            // <code><em>Location</em></code> field.
            case HttpServletResponse.SC_USE_PROXY:
        
            // Status code (400) indicating the request sent by the client was
            // syntactically incorrect.
            case HttpServletResponse.SC_BAD_REQUEST:
        
            // Status code (401) indicating that the request requires HTTP
            // authentication.
            case HttpServletResponse.SC_UNAUTHORIZED:
        
            // Status code (402) reserved for future use.
            case HttpServletResponse.SC_PAYMENT_REQUIRED:
        
            // Status code (403) indicating the server understood the request
            // but refused to fulfill it.
            case HttpServletResponse.SC_FORBIDDEN:
        
            // Status code (404) indicating that the requested resource is not
            // available.
            case HttpServletResponse.SC_NOT_FOUND:
        
            // Status code (405) indicating that the method specified in the
            // <code><em>Request-Line</em></code> is not allowed for the resource
            // identified by the <code><em>Request-URI</em></code>.
            case HttpServletResponse.SC_METHOD_NOT_ALLOWED:
        
            // Status code (406) indicating that the resource identified by the
            // request is only capable of generating response entities which have
            // content characteristics not acceptable according to the accept
            // headerssent in the request.
            case HttpServletResponse.SC_NOT_ACCEPTABLE:
        
            // Status code (407) indicating that the client <em>MUST</em> first
            // authenticate itself with the proxy.
            case HttpServletResponse.SC_PROXY_AUTHENTICATION_REQUIRED:
        
            // Status code (408) indicating that the client did not produce a
            // requestwithin the time that the server was prepared to wait.
            case HttpServletResponse.SC_REQUEST_TIMEOUT:
        
            // Status code (409) indicating that the request could not be
            // completed due to a conflict with the current state of the
            // resource.
            case HttpServletResponse.SC_CONFLICT:
        
            // Status code (410) indicating that the resource is no longer
            // available at the server and no forwarding address is known.
            // This condition <em>SHOULD</em> be considered permanent.
            case HttpServletResponse.SC_GONE:
        
            // Status code (411) indicating that the request cannot be handled
            // without a defined <code><em>Content-Length</em></code>.
            case HttpServletResponse.SC_LENGTH_REQUIRED:
        
            // Status code (412) indicating that the precondition given in one
            // or more of the request-header fields evaluated to false when it
            // was tested on the server.
            case HttpServletResponse.SC_PRECONDITION_FAILED:
        
            // Status code (413) indicating that the server is refusing to process
            // the request because the request entity is larger than the server is
            // willing or able to process.
            case HttpServletResponse.SC_REQUEST_ENTITY_TOO_LARGE:
        
            // Status code (414) indicating that the server is refusing to service
            // the request because the <code><em>Request-URI</em></code> is longer
            // than the server is willing to interpret.
            case HttpServletResponse.SC_REQUEST_URI_TOO_LONG:
        
            // Status code (415) indicating that the server is refusing to service
            // the request because the entity of the request is in a format not
            // supported by the requested resource for the requested method.
            case HttpServletResponse.SC_UNSUPPORTED_MEDIA_TYPE:
        
            // Status code (500) indicating an error inside the HTTP server
            // which prevented it from fulfilling the request.
            case HttpServletResponse.SC_INTERNAL_SERVER_ERROR:
        
            // Status code (501) indicating the HTTP server does not support
            // the functionality needed to fulfill the request.
            case HttpServletResponse.SC_NOT_IMPLEMENTED:
        
            // Status code (502) indicating that the HTTP server received an
            // invalid response from a server it consulted when acting as a
            // proxy or gateway.
            case HttpServletResponse.SC_BAD_GATEWAY:
        
            // Status code (503) indicating that the HTTP server is
            // temporarily overloaded, and unable to handle the request.
            case HttpServletResponse.SC_SERVICE_UNAVAILABLE:
        
            // Status code (504) indicating that the server did not receive
            // a timely response from the upstream server while acting as
            // a gateway or proxy.
            case HttpServletResponse.SC_GATEWAY_TIMEOUT:
        
            // Status code (505) indicating that the server does not support
            // or refuses to support the HTTP protocol version that was used
            // in the request message.
            case HttpServletResponse.SC_HTTP_VERSION_NOT_SUPPORTED:
        
                // the specified error is legal
                return nStatus;
        
            default:
        
                // map unknown error to the "default" web error
                return HttpServletResponse.SC_NOT_FOUND;
            }
        }
    
    protected void unregisterAwareList()
        {
        // import com.tangosol.run.component.ExecutionContextAware;
        // import java.rmi.RemoteException;
        // import java.util.Iterator;
        // import java.util.List;
        // import javax.ejb.SessionBean;
        // import javax.ejb.EJBException;
        
        List list = getAwareList();
        if (list != null)
            {
            for (Iterator iter = list.iterator(); iter.hasNext(); )
                {
                ExecutionContextAware oAware = (ExecutionContextAware) iter.next();
                try 
                    {
                    oAware.valueUnbound(this);
                    }
                catch (Exception e)
                    {
                    _trace("An exception occurred while unbinding an"
                        + " ExecutionContextAware object:", 1);
                    _trace(e);
                    }
                }
            setAwareList(null);
            }
        }
    }
