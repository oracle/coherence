/* Class
*     _package.component.web.Http
*/

package _package.component.web;

import _package.component.Application;
import _package.component.application.Enterprise;
import _package.component.web.RequestContext;
import _package.component.web.http.Servlet;
import _package.component.web.http.View;
import _package.component.web.requestContext.ServletRequestContext;
import com.tangosol.util.Base;
import java.util.List;

public class Http
        extends    _package.component.Web
    {
    // Fields declarations
    
    /**
    * Property Application
    *
    * A helper property that provides a reference to the Application.Enterprise
    * component.
    */
    
    /**
    * Property ContextParent
    *
    * Finds the Http parent component for this Http object, but will not return
    * an Http parent that is not within the same RequestContext.
    */
    
    /**
    * Property Controller
    *
    * A helper property that provides a reference to the default controller.
    */
    
    /**
    * Property HttpParent
    *
    * Finds the Http parent component of this Http component.  For example,
    * when routing a request from a Servlet to a View to an EventTag, the
    * EventTag's parent is the View and the View's parent is the Servlet.  If
    * the EventTag forwards to a JSP and the page evaluates a BodyTag that
    * includes a PropertyTag, the PropertyTag's parent is the BodyTag and the
    * BodyTag's parent is the EventTag.  (Note:  The difference in this example
    * between HttpParent and ContextParent is that the BodyTag has no
    * ContextParent, because the BodyTag has a JspTagContext and the EventTag
    * has a ServletRequestContext.)
    */
    
    /**
    * Property Model
    *
    * A helper property that provides a reference to the default model.
    */
    
    /**
    * Property Request
    *
    * A helper property that provides a reference to the HTTP request object.
    */
    
    /**
    * Property RequestContext
    *
    * The RequestContext component for this Http component.
    * 
    * Http components almost always operate within a request context, which is
    * to say that they rarely are used except to respond to an HTTP request. 
    * When an HTTP request is received, it is typically handled by a Servlet
    * component.  The Servlet creates a ServletRequestContext instance to
    * represent the context of the request.  Often, the handling of the request
    * requires forwarding to a JSP.  The JSP gets its own request context;
    * however it is nested under the Servlet's request context.
    * 
    * Many useful properties and methods are available on the RequestContext,
    * including access to the request, response, session, cookie, attributes,
    * etc.
    * 
    * @see ContextParent
    */
    private transient RequestContext __m_RequestContext;
    
    /**
    * Property Response
    *
    * A helper property that provides a reference to the HTTP response object.
    */
    
    /**
    * Property Routeable
    *
    * If set to false, the Http component cannot be routed to or through.  This
    * is typically false for JspTags that are not EventTags.  It can also be
    * set to false for View or EventTag components to disable part of the
    * application.
    */
    
    /**
    * Property SC_BAD_REQUEST
    *
    * Status code (400) indicating the request sent by the client was
    * syntactically incorrect.
    */
    public static final int SC_BAD_REQUEST = 400;
    
    /**
    * Property SC_FORBIDDEN
    *
    * Status code (403) indicating the server understood the request but
    * refused to fulfill it.
    */
    public static final int SC_FORBIDDEN = 403;
    
    /**
    * Property SC_INTERNAL_SERVER_ERROR
    *
    * Status code (500) indicating an error inside the HTTP server which
    * prevented it from fulfilling the request.
    */
    public static final int SC_INTERNAL_SERVER_ERROR = 500;
    
    /**
    * Property SC_NOT_FOUND
    *
    * Status code (404) indicating that the requested resource is not available.
    */
    public static final int SC_NOT_FOUND = 404;
    
    /**
    * Property SC_SERVICE_UNAVAILABLE
    *
    * Status code (503) indicating that the HTTP server is temporarily
    * overloaded, and unable to handle the request.
    */
    public static final int SC_SERVICE_UNAVAILABLE = 503;
    
    /**
    * Property SC_UNAUTHORIZED
    *
    * Status code (401) indicating that the request requires HTTP
    * authentication.
    */
    public static final int SC_UNAUTHORIZED = 401;
    
    /**
    * Property Servlet
    *
    * Finds the closest HttpParent component that is a Servlet component.
    */
    
    /**
    * Property View
    *
    * Obtains the View component that this Http component relies upon.  This
    * property can provides a null answer, meaning there is no View component
    * for the current Http component.  Typically, the returned View component
    * is obtained by walking up the linked list of HttpParents looking for the
    * View, although JspTag components override this behavior.
    */
    
    /**
    * Property ViewClass
    *
    * The Class object of the View component that this Http component relies
    * on.  This class is determined by the design-time View parent of this Http
    * component.  The Http component can be recursively contained within View
    * and non-View components, which means the immediate design parent may not
    * be the View component. In other words, the following holds true:
    * 
    * 1)  the View itself is contained by another component or is a global
    * component that is specified as a "root" component in the Packager and is
    * registered as an entry in the front servlet's RouteMap.
    * 2)  this Http component is a direct or nested child within the View
    * 3)  from the point in the designed containment tree where the View exists
    * to the point in the designed containment tree where this Http component
    * exists, there are no other View components
    * 
    * Note that View components do not return their own classes, but rather the
    * class (if any) of their outer View.
    */
    
    /**
    * Property ViewClassCache
    *
    * [internal implementation static property] Cache map keyed by Http class,
    * with a corresponding value of the View class.
    */
    private static transient com.tangosol.util.SafeHashMap __s_ViewClassCache;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // state initialization: static properties
        try
            {
            __s_ViewClassCache = new com.tangosol.util.SafeHashMap();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public Http()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Http(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant Routeable
    public boolean isRouteable()
        {
        return true;
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new Http();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/web/Http".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    public void forward(String url)
            throws javax.servlet.ServletException
        {
        forward(url, this);
        }
    
    public void forward(String url, Http httpOrigin)
            throws javax.servlet.ServletException
        {
        // import Component.Web.RequestContext;
        
        Http parent = getContextParent();
        if (parent == null)
            {
            RequestContext ctx = getRequestContext();
            _assert(ctx != null);
            ctx.forward(url, httpOrigin);
            }
        else
            {
            parent.forward(url, httpOrigin);
            }
        }
    
    // Accessor for the property "Application"
    public _package.component.application.Enterprise getApplication()
        {
        // import Component.Application;
        // import Component.Application.Enterprise;
        
        return (Enterprise) Application.get_Instance();
        }
    
    public Object getAttribute(String sName)
        {
        // import Component.Web.RequestContext;
        
        RequestContext ctx = getRequestContext();
        return ctx == null ? null : ctx.getAttribute(sName);
        }
    
    public int getAttributeScope(String sName)
        {
        // import Component.Web.RequestContext;
        
        RequestContext ctx = getRequestContext();
        return ctx == null ? RequestContext.SCOPE_NONE : ctx.getAttributeScope(sName);
        }
    
    // Accessor for the property "ContextParent"
    public Http getContextParent()
        {
        Http parent = getHttpParent();
        if (parent != null && parent.getRequestContext() == getRequestContext())
            {
            return parent;
            }
        
        return null;
        }
    
    // Accessor for the property "Controller"
    public Object getController()
        {
        // TODO review
        
        // pass the request up to the View (this implementation is overridden by
        // View, which is responsible for the controller, and by JspTag, which has
        // to explicitly find its View)
        Http parent = getHttpParent();
        return parent == null ? null : parent.getController();
        }
    
    protected Http getHttpHop(_package.component.web.requestContext.ServletRequestContext ctx)
        {
        // import Component.Web.Http.View;
        // import Component.Web.RequestContext.ServletRequestContext;
        // import java.util.List;
        
        List list = ctx.ensureRouteList();
        if (list == null || list.isEmpty())
            {
            return null;
            }
        
        // target is the first name in the list
        // target can contain an ID, '-' delimited
        String sTarget = (String) list.get(0);
        String sId     = null;
        int    of      = sTarget.indexOf('-');
        if (of >= 0)
            {
            sId     = sTarget.substring(of + 1);
            sTarget = sTarget.substring(0, of);
            }
        
        // find or instantiate the target
        Component target = null;
        if (sTarget.equals(ServletRequestContext.ROUTE_PARENT))
            {
            target = getHttpParent();
            }
        else
            {
            target = _findChild(sTarget);
            if (target == null)
                {
                target = instantiateTarget(sTarget);
                }
            }
        
        if (target instanceof Http)
            {
            Http hop = (Http) target;
            hop.setRequestContext(ctx);
        
            hop.prerouteRequest(ctx, sId);
        
            list.remove(0);
            return hop;
            }
        
        return null;
        }
    
    // Accessor for the property "HttpParent"
    public Http getHttpParent()
        {
        // import Component.Web.RequestContext;
        
        // determine the Http component instance that instantiated this child (this implementation
        // is overridden by JspTag, which exists in a tag hierarchy managed by the JSP servlet)
        Component parent = get_Parent();
        if (parent instanceof Http)
            {
            return (Http) parent;
            }
        
        // get the Http component that included/forwarded to cause this request
        RequestContext ctx = getRequestContext();
        return ctx == null ? null : ctx.getEntryHttp();
        }
    
    // Accessor for the property "Model"
    public Object getModel()
        {
        // TODO review
        
        import Component.Web.Http.View;
        
        // pass the request up to the View (this implementation is overridden by
        // View, which is responsible for the model)
        View view = getView();
        return view == null ? null : view.getModel();
        }
    
    // Accessor for the property "Request"
    public javax.servlet.http.HttpServletRequest getRequest()
        {
        // import Component.Web.RequestContext;
        
        RequestContext ctx = getRequestContext();
        return ctx == null ? null : ctx.getRequest();
        }
    
    // Accessor for the property "RequestContext"
    public RequestContext getRequestContext()
        {
        return __m_RequestContext;
        }
    
    // Accessor for the property "Response"
    public javax.servlet.http.HttpServletResponse getResponse()
        {
        // import Component.Web.RequestContext;
        
        RequestContext ctx = getRequestContext();
        return ctx == null ? null : ctx.getResponse();
        }
    
    // Accessor for the property "Servlet"
    public _package.component.web.http.Servlet getServlet()
        {
        // import Component.Web.Http.Servlet;
        
        Http hop = this;
        do
            {
            if (hop instanceof Servlet)
                {
                return (Servlet) hop;
                }
            hop = hop.getHttpParent();
            } while (hop != null);
        
        return null;
        }
    
    // Accessor for the property "View"
    public _package.component.web.http.View getView()
        {
        // TODO review
        
        Class clzView = getViewClass();
        return clzView == null ? null : getView(clzView);

        }
    
    // Accessor for the property "View"
    /**
    * Return a View component that belongs to the specified Class
    */
    public _package.component.web.http.View getView(Class clz)
        {
        // TODO review
        
        // pass the request up to context parent (this implementation is overridden by
        // JspTag which could return a ResultView and View that could return itself)
        Http parent = getHttpParent();
        return parent == null ? null : parent.getView(clz);

        }
    
    // Accessor for the property "ViewClass"
    public Class getViewClass()
        {
        // TODO review
        
        import Component.Web.Http.View;
        import com.tangosol.util.Base;
        import java.util.Map;
        
        Map   map     = getViewClassCache();
        Class clzThis = getClass();
        Class clzView = (Class) map.get(clzThis);
        
        if (clzView == null)
            {
            final Class CLZ_VIEW = View.class;
            String sClz  = clzThis.getName();
            int    of    = sClz.lastIndexOf('$');
            while (of >= 0)
                {
                // remove child from the end of the class name
                sClz = sClz.substring(0, of);
        
                // check if that class is a view
                try
                    {
                    Class clz = Class.forName(sClz);
                    if (CLZ_VIEW.isAssignableFrom(clz))
                        {
                        map.put(clzThis, clzView = clz);
                        break;
                        }
                    }
                catch (Throwable e)
                    {
                    throw Base.ensureRuntimeException(e);
                    }
                of = sClz.lastIndexOf('$');
                }
            }
        
        return clzView;
        }
    
    // Accessor for the property "ViewClassCache"
    private static com.tangosol.util.SafeHashMap getViewClassCache()
        {
        return __s_ViewClassCache;
        }
    
    public void include(String url)
            throws javax.servlet.ServletException
        {
        include(url, this);
        }
    
    public void include(String url, Http httpOrigin)
            throws javax.servlet.ServletException
        {
        // import Component.Web.RequestContext;
        
        Http parent = getContextParent();
        if (parent == null)
            {
            RequestContext ctx = getRequestContext();
            _assert(ctx != null);
            ctx.include(url, httpOrigin);
            }
        else
            {
            parent.include(url, httpOrigin);
            }
        }
    
    protected _package.Component instantiateTarget(String sName)
        {
        // import com.tangosol.util.Base;
        
        // TODO - review
        
        // first try to instantiate child
        Component target = _newChild(sName);
        
        // second try to use routing information
        if (target == null)
            {
            Class clzTarget = (Class) getServlet().getRouteMap().get(sName);
        
            if (clzTarget != null)
                {
                try
                    {
                    target = (Component) clzTarget.newInstance();
        
                    _addChild(target, sName);
                    }
                catch (Exception e)
                    {
                    throw Base.ensureRuntimeException(e);
                    }
                }
            }
        
        return target;

        }
    
    public void onError(int nStatus, String sDesc)
        {
        Http parent = getContextParent();
        if (parent == null)
            {
            getRequestContext().sendError(nStatus, sDesc);
            }
        else
            {
            parent.onError(nStatus, sDesc);
            }
        }
    
    public void onRequest(_package.component.web.requestContext.ServletRequestContext ctx)
            throws javax.servlet.ServletException
        {
        // inheriting implementations should override this
        onUnhandledRequest(ctx);
        }
    
    public void onUnhandledRequest(_package.component.web.requestContext.ServletRequestContext ctx)
            throws javax.servlet.ServletException
        {
        Http parent = getContextParent();
        if (parent == null)
            {
            // default error for unhandled request is 404 "not found"
            onError(SC_NOT_FOUND, null);
            }
        else
            {
            parent.onUnhandledRequest(ctx);
            }
        }
    
    public void prerouteRequest(RequestContext ctx, String sId)
        {
        if (!isRouteable())
            {
            onError(SC_NOT_FOUND, null);
            }
        }
    
    public void removeAttribute(String sName)
        {
        // import Component.Web.RequestContext;
        
        RequestContext ctx = getRequestContext();
        _assert(ctx != null);
        ctx.removeAttribute(sName);
        }
    
    public void routeRequest(_package.component.web.requestContext.ServletRequestContext ctx)
            throws javax.servlet.ServletException
        {
        Http httpNextHop = getHttpHop(ctx);
        if (httpNextHop == null)
            {
            onRequest(ctx);
            }
        else
            {
            httpNextHop.routeRequest(ctx);
            }
        }
    
    public void setAttribute(String sName, Object oValue)
        {
        // import Component.Web.RequestContext;
        
        setAttribute(sName, oValue, RequestContext.SCOPE_REQUEST);
        }
    
    public void setAttribute(String sName, Object oValue, int nScope)
        {
        // import Component.Web.RequestContext;
        
        RequestContext ctx = getRequestContext();
        _assert(ctx != null);
        ctx.setAttribute(sName, oValue, nScope);
        }
    
    // Accessor for the property "RequestContext"
    public void setRequestContext(RequestContext ctx)
        {
        __m_RequestContext = ctx;
        }
    
    // Accessor for the property "ViewClassCache"
    private static void setViewClassCache(com.tangosol.util.SafeHashMap pViewClassCache)
        {
        __s_ViewClassCache = pViewClassCache;
        }
    }
