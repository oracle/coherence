/* Class
*     _package.component.xml.XmlBean
*/

package _package.component.xml;

import _package.component.web.UrlIdEncoder;

public class XmlBean
        extends    _package.component.Xml
        implements com.tangosol.run.xml.UriSerializable,
                   com.tangosol.run.xml.XmlSerializable
    {
    // Fields declarations
    
    /**
    * Property _KeyFields
    *
    */
    private static final String[] __s__KeyFields;
    
    // Static initializer
    static
        {
        try
            {
            __s__KeyFields = null;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public XmlBean()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public XmlBean(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant _KeyFields
    public String[] get_KeyFields()
        {
        return null;
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new XmlBean();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/xml/XmlBean".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.run.xml.UriSerializable
    public void fromUri(String sUri)
        {
        // import Component.Web.UrlIdEncoder;
        
        UrlIdEncoder encoder = UrlIdEncoder.getEncoder(getClass(), get_KeyFields());
        
        encoder.decode(this, sUri);
        }
    
    // From interface: com.tangosol.run.xml.XmlSerializable
    public void fromXml(com.tangosol.run.xml.XmlElement xml)
        {
        }
    
    // From interface: com.tangosol.run.xml.UriSerializable
    public String toUri()
        {
        // import Component.Web.UrlIdEncoder;
        
        UrlIdEncoder encoder = UrlIdEncoder.getEncoder(getClass(), get_KeyFields());
        
        return encoder.encode(this);
        }
    
    // From interface: com.tangosol.run.xml.XmlSerializable
    public com.tangosol.run.xml.XmlElement toXml()
        {
        return null;
        }
    }
