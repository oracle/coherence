/* Class
*     _package.component.ejb.Session
*/

package _package.component.ejb;

/*
* Integrates
*     java.lang.Object
*     using 
*/
/*
* This component is remoted according to the
* Enterprise Javabean specification
*     Session Bean
*/
public abstract class Session
        extends    _package.component.Ejb
        implements javax.ejb.SessionBean
    {
    // Fields declarations
    
    /**
    * Property SessionContext
    *
    */
    private transient javax.ejb.SessionContext __m_SessionContext;
    
    /**
    * Property Stateful
    *
    */
    
    // fields used by the integration model:
    private sink_Session __sink;
    private Object __feed;
    
    // Initializing constructor
    public Session(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant Stateful
    public boolean isStateful()
        {
        return false;
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/ejb/Session".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ Object integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_Session) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    //-- Object integration
    
    // From interface: javax.ejb.SessionBean
    public void ejbActivate()
        {
        onActivate();
        }
    
    // From interface: javax.ejb.SessionBean
    public void ejbPassivate()
        {
        onPassivate();
        }
    
    // From interface: javax.ejb.SessionBean
    protected void ejbRemove$RemoteEntry()
        {
        onRemove();
        }
    /**
    * This method is analagous to the ejbCreate(...) method(s). On a client
    * it's routed through the remove method on the EJBObject interface
    * (implemented by the ejbStub). Any implementations supplied are only to be
    * executed in a server context. Class generation recognizes this method and
    * provides special handling as required by the EJB spec.
    * 
    * This method is called with an unspecified transaction context.
    * 
    * @see  EJB 1.1 specification: section 6.5.1, 6.5.7
    */
    public final void ejbRemove()
        {
        if (__feed == null
            && __sink != null)
            {
            __sink.ejbRemove();
            return;
            }
        ejbRemove$RemoteEntry();
        }
    
    // Accessor for the property "SessionContext"
    public javax.ejb.SessionContext getSessionContext()
        {
        return __m_SessionContext;
        }
    
    /**
    * Method notification that signals the instance it has just been
    * reactivated.
    * This method is called with an unspecified transaction context.
    * 
    * @see  EJB 1.1 specification: section 6.5.1, 6.5.7
    * 
    */
    protected void onActivate()
        {
        }
    
    /**
    * Method notification that signals the intent of the container to passivate
    * the instance.
    * This method is called with an unspecified transaction context.
    * 
    * @see  EJB 1.1 specification: section 6.5.1, 6.5.7
    */
    protected void onPassivate()
        {
        }
    
    // From interface: javax.ejb.SessionBean
    // Accessor for the property "SessionContext"
    public void setSessionContext(javax.ejb.SessionContext ctx)
            throws javax.ejb.EJBException
        {
        __m_SessionContext = ctx;
        }
    }
