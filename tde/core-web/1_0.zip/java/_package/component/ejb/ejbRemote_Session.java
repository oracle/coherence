/* Interface
*      ejbRemote_Session
*
* automatically generated "EJBObject" interface
* for the remoted component:
*      Component.Ejb.Session
*/

package _package.component.ejb;

public interface ejbRemote_Session
        extends javax.ejb.EJBObject
    {
    }
