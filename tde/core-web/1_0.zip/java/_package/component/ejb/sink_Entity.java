/* Interface
*      sink_Entity
*
* automatically generated "interface Sink"
* which defines the set of methods used by the
*     Component.Ejb.Entity
* component to route methods out of the component
*/

package _package.component.ejb;

public interface sink_Entity
         extends com.tangosol.run.component.RemoteSink
    {
    // remoted method
    /**
    * This method is analagous to the ejbCreate(...) method(s). On a client
    * it's routed through the remove method on the EJBObject interface
    * (implemented by the ejbStub). Any implementations supplied are only to be
    * executed in a server context. Class generation recognizes this method and
    * provides special handling as required by the EJB spec.
    * 
    * This method executes in the transaction context determined by the
    * transaction attribute of the remove method that triggered the ejbRemove
    * method.
    */
    public void ejbRemove()
            throws javax.ejb.RemoveException;
    }
