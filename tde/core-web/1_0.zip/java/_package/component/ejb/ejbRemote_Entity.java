/* Interface
*      ejbRemote_Entity
*
* automatically generated "EJBObject" interface
* for the remoted component:
*      Component.Ejb.Entity
*/

package _package.component.ejb;

public interface ejbRemote_Entity
        extends javax.ejb.EJBObject
    {
    }
