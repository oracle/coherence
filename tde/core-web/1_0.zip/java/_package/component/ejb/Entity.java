/* Class
*     _package.component.ejb.Entity
*/

package _package.component.ejb;

import _package.component.ejb.PrimaryKeyExtractor; // as Extractor

/**
* The Entity component is the design root for all Entity EJB components. 
* Entity EJBs implement the javax.ejb.EntityBean interface, which allows an
* Entity EJB to persist itself (using Bean-Managed Persistence, or BMP), or to
* be persisted by the EJB container (using Container-Managed Persistence, or
* CMP).  It is suggested that Entity EJB components be designed as
* Container-Managed (by setting the ContainerManaged property to true); this
* allows the generic Container-Managed EJB component to be inherited from, with
* the inheriting component providing a Bean-Managed Persistence implementation
* by coding the ejbLoad, ejbStore, ejbRemove, and all ejbCreate methods.  It is
* also suggested that the child component Key be used as the primary key class,
* even in cases where the key is a single-part and can be represented by a
* supported Java class, such as String; this enables creative use of
* polymorphism, since each entity EJB will have a primary key component with
* properties representing the primary key values.
*/
/*
* Integrates
*     java.lang.Object
*     using 
*/
/*
* This component is remoted according to the
* Enterprise Javabean specification
*     Entity Bean
*     Primary Key Class "Component.Ejb.Entity$Key"
*     Container Managed Persistence
*     Data Fields:
*/
public abstract class Entity
        extends    _package.component.Ejb
        implements javax.ejb.EntityBean
    {
    // Fields declarations
    
    /**
    * Property ContainerManaged
    *
    */
    
    /**
    * Property ContainerManagedColumns
    *
    * For CMP entity beans, this is a list of columns corresponding to the
    * DataFields property.  If this value is not filled in, the packager
    * produces a CMP map assuming that the ContainerManagedColumns are
    * identical to the DataFields.
    */
    private static final String[] __s_ContainerManagedColumns;
    
    /**
    * Property ContainerManagedDatasource
    *
    * For CMP entity beans, this is the data source name that provides access
    * to the ContainerManagedTable.  If this value is not filled in, the
    * packager produces a CMP map assuming that the ContainerManagedDatasource
    * is identical to the application name plus the suffix "Pool".
    * 
    * In WebLogic, the data source name is called a pool name.
    */
    
    /**
    * Property ContainerManagedTable
    *
    * For CMP entity beans, this is the table name corresponding to the entity
    * bean.  If this value is not filled in, the packager produces a CMP map
    * assuming that the ContainerManagedTable is identical to the component
    * name.
    */
    
    /**
    * Property DataFields
    *
    */
    private static final String[] __s_DataFields;
    
    /**
    * Property EntityContext
    *
    */
    private javax.ejb.EntityContext __m_EntityContext;
    
    /**
    * Property PrimaryKey
    *
    */
    
    /**
    * Property PrimaryKeyField
    *
    */
    private static com.tangosol.util.ListMap __mapChildren;
    
    // fields used by the integration model:
    private sink_Entity __sink;
    private Object __feed;
    
    // Static initializer
    static
        {
        try
            {
            __s_ContainerManagedColumns = null;
            __s_DataFields = null;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Key", Entity$Key.get_CLASS());
        }
    
    // Initializing constructor
    public Entity(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant ContainerManaged
    public boolean isContainerManaged()
        {
        return true;
        }
    
    // Getter for virtual constant ContainerManagedColumns
    protected String[] getContainerManagedColumns()
        {
        return null;
        }
    
    // Getter for virtual constant ContainerManagedDatasource
    protected String getContainerManagedDatasource()
        {
        return null;
        }
    
    // Getter for virtual constant ContainerManagedTable
    protected String getContainerManagedTable()
        {
        return null;
        }
    
    // Getter for virtual constant DataFields
    public String[] getDataFields()
        {
        return null;
        }
    
    // Getter for virtual constant PrimaryKeyField
    public String getPrimaryKeyField()
        {
        return "$Key";
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/ejb/Entity".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    //++ Object integration
    // Access optimization
    public void set_Sink(Object pSink)
        {
        __sink = (sink_Entity) pSink;
        super.set_Sink(pSink);
        }
    public void set_Feed(Object pFeed)
        {
        __feed = pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    //-- Object integration
    
    // From interface: javax.ejb.EntityBean
    public void ejbActivate()
        {
        onActivate();
        }
    
    // From interface: javax.ejb.EntityBean
    public void ejbLoad()
        {
        onLoad();
        }
    
    // From interface: javax.ejb.EntityBean
    public void ejbPassivate()
        {
        onPassivate();
        }
    
    // From interface: javax.ejb.EntityBean
    protected void ejbRemove$RemoteEntry()
            throws javax.ejb.RemoveException
        {
        }
    /**
    * This method is analagous to the ejbCreate(...) method(s). On a client
    * it's routed through the remove method on the EJBObject interface
    * (implemented by the ejbStub). Any implementations supplied are only to be
    * executed in a server context. Class generation recognizes this method and
    * provides special handling as required by the EJB spec.
    * 
    * This method executes in the transaction context determined by the
    * transaction attribute of the remove method that triggered the ejbRemove
    * method.
    */
    public final void ejbRemove()
            throws javax.ejb.RemoveException
        {
        if (__feed == null
            && __sink != null)
            {
            __sink.ejbRemove();
            return;
            }
        ejbRemove$RemoteEntry();
        }
    
    // From interface: javax.ejb.EntityBean
    public void ejbStore()
        {
        onStore();
        }
    
    // Accessor for the property "EntityContext"
    public javax.ejb.EntityContext getEntityContext()
        {
        return __m_EntityContext;
        }
    
    // Accessor for the property "PrimaryKey"
    public Entity$Key getPrimaryKey()
        {
        // import Component.Ejb.PrimaryKeyExtractor as Extractor;
        
        // TODO first try to use ejb object and __convert
        
        $Key key = instantiateKey();
        
        Extractor extractor = Extractor.getExtractor(getClass(), key.getClass(), key.getKeyFields());
        extractor.extract(this, key);
        
        return key;
        }
    
    public Entity$Key instantiateKey()
        {
        return ($Key) _newChild("Key");
        }
    
    /**
    * This method is called on the instance when the container picks the
    * instance from the pool and assigns it to a specific entity object
    * identity. This method gives the entity bean instance the chance to
    * acquire additional resources that it needs while it is in the ready
    * state.
    * This method executes with an unspecified transaction context.
    * 
    * @see EJB 1.1 specifiecation: section 9.1.5.1
    */
    protected void onActivate()
        {
        }
    
    /**
    * This method is called on an instance in the ready state to inform the
    * instance that it must synchronize the entity state cached in its instance
    * variables from the entity state in the database. The instance must be
    * prepared for the container to invoke this method at any time that the
    * instance is in the ready state.
    * This method executes in the transaction context determined by the
    * transaction attribute of the business method that triggered the ejbLoad
    * method.
    * 
    * @see EJB 1.1 specifiecation: section 9.1.5.1
    */
    protected void onLoad()
        {
        }
    
    /**
    * Ths method is called on an instance when the container decides to
    * disassociate the instance from an entity object identity, and to put the
    * instance back into the pool of avail-able instances. This method gives
    * the instance the chance to release any resources that should not be held
    * while the instance is in the pool. (These resources typically had been
    * allocated during the ejb activation).
    * This method executes with an unspecified transaction context.
    * 
    * @see EJB 1.1 specifiecation: section 9.1.5.1
    */
    protected void onPassivate()
        {
        }
    
    /**
    * This method is called on an instance to inform the instance that the
    * instance must synchronize the entity state in the database with the
    * entity state cached in its instance variables.
    * The instance must be prepared for the container to invoke this method at
    * any time that the instance is in the ready state.
    * 
    * This method executes in the same transaction context as the previous
    * ejbLoad or ejbCreate method invoked on the instance. All business methods
    * invoked between the previous ejbLoad or ejbCreate method and this
    * ejbStore method are also invoked in the same transaction context.
    * 
    * @see EJB 1.1 specifiecation: section 9.1.5.1
    */
    protected void onStore()
        {
        }
    
    // From interface: javax.ejb.EntityBean
    // Accessor for the property "EntityContext"
    public void setEntityContext(javax.ejb.EntityContext ctx)
        {
        __m_EntityContext = ctx;
        }
    
    // From interface: javax.ejb.EntityBean
    public void unsetEntityContext()
        {
        setEntityContext(null);
        }
    }
