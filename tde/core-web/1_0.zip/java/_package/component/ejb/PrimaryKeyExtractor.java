/* Class
*     _package.component.ejb.PrimaryKeyExtractor
*/

package _package.component.ejb;

import com.tangosol.util.SafeHashMap;
import com.tangosol.util.WrapperException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/**
* This component extracts entity EJB primary key fields into a primary key
* object using reflection.
*/
public class PrimaryKeyExtractor
        extends    _package.component.Ejb
    {
    // Fields declarations
    
    /**
    * Property EntityBeanClass
    *
    * The Entity EJB class that the key is to be extracted from.
    */
    private Class __m_EntityBeanClass;
    
    /**
    * Property ExtractorCache
    *
    * A cache of extractor objects, used by getExtractor().
    */
    private static transient java.util.Map __s_ExtractorCache;
    
    /**
    * Property PrimaryKeyClass
    *
    * The class of the primary key JavaBean that the extractor instance is
    * intended to work with.
    */
    private Class __m_PrimaryKeyClass;
    
    /**
    * Property PropertyAccessor
    *
    * An array of Method objects which are used to invoke the accessor ("get")
    * methods of the entity EJB.  This array corresponds to the PropertyName
    * array.
    */
    private java.lang.reflect.Method[] __m_PropertyAccessor;
    
    /**
    * Property PropertyClass
    *
    * An array of property types corresponding to PropertyName.
    */
    private Class[] __m_PropertyClass;
    
    /**
    * Property PropertyCount
    *
    * The number of properties on the primary key that this encoder is
    * configured to process.  This corresponds to the size of the PropertyName
    * array.
    */
    private int __m_PropertyCount;
    
    /**
    * Property PropertyMutator
    *
    * An array of Method objects which are used to invoke the mutator ("set")
    * methods of the primary key class.  This array corresponds to the
    * PropertyName array.
    */
    private java.lang.reflect.Method[] __m_PropertyMutator;
    
    /**
    * Property PropertyName
    *
    * An array of property names that this encoder will access/mutate on the
    * entity EJB/primary key.
    */
    private String[] __m_PropertyName;
    
    // Default constructor
    public PrimaryKeyExtractor()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PrimaryKeyExtractor(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    public static _package.Component get_Instance()
        {
        return new PrimaryKeyExtractor();
        }
    
    //++ getter for static property _CLASS
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/ejb/PrimaryKeyExtractor".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    private void configure()
        {
        // import java.lang.reflect.Method;
        // import java.util.Map;
        // import java.util.HashMap;
        
        Class    clz    = getEntityBeanClass();
        String[] asName = getPropertyName();
        _assert(clz != null && asName != null && asName.length > 0);
        
        int       cProps    = asName.length;
        Class[]   aclz      = new Class[cProps];
        Method[]  aAccessor = new Method[cProps];
        Method[]  aMutator  = new Method[cProps];
        
        // build a lookup table from property name to index
        Map map = new HashMap();
        for (int i = 0; i < cProps; ++i)
            {
            map.put(asName[i], new Integer(i));
            }
        
        // determine the property accessors, and thus the property types
        Method[] aMethod = clz.getMethods();
        for (int i = 0, c = aMethod.length; i < c; ++i)
            {
            Method method = aMethod[i];
            if (method.getParameterTypes().length == 0)
                {
                String sName = method.getName();
                if (sName.startsWith("is"))
                    {
                    sName = sName.substring(2);
                    }
                else if (sName.startsWith("get"))
                    {
                    sName = sName.substring(3);
                    }
                else
                    {
                    sName = null;
                    }
        
                // check if this method is one of the accessors
                if (sName != null)
                    {
                    Integer IProp = (Integer) map.get(sName);
                    if (IProp != null)
                        {
                        int     iProp   = IProp.intValue();
                        Class   clzProp = method.getReturnType();
        
                        aclz     [iProp] = clzProp;
                        aAccessor[iProp] = method;
                        }
                    }
                }
            }
        
        // locate mutators
        clz = getPrimaryKeyClass();
        Class[] aclzParam = new Class[1];
        for (int i = 0; i < cProps; ++i)
            {
            String sName   = asName[i];
            Class  clzProp = aclz  [i];
            if (clzProp == null)
                {
                throw new IllegalStateException(
                    "No property accessor method located (" + clz.getName() + "." + sName + ")");
                }
        
            aclzParam[0] = clzProp;
            Method method = null;
            try
                {
                method = clz.getMethod("set" + sName, aclzParam);
                }
            catch (NoSuchMethodException e)
                {
                }
        
            if (method == null || !method.getReturnType().equals(Void.TYPE))
                {
                throw new IllegalStateException(
                    "No property mutator method located (" + clz.getName() + "." + sName + ")");
                }
        
            aMutator[i] = method;
            }
        
        setPropertyCount(cProps);
        setPropertyClass(aclz);
        setPropertyAccessor(aAccessor);
        setPropertyMutator(aMutator);
        }
    
    public void extract(Entity ejb, Entity$Key key)
        {
        // import com.tangosol.util.WrapperException;
        // import java.lang.reflect.Method;
        
        _assert(ejb != null && key != null);
        
        Method[]  aGetter    = getPropertyAccessor();
        Method[]  aSetter    = getPropertyMutator();
        Object[]  aoGetParam = new Object[0];
        Object[]  aoSetParam = new Object[1];
        
        try
            {
            for (int i = 0, c = getPropertyCount(); i < c; ++i)
                {
                Object value = aGetter[i].invoke(ejb, aoGetParam);
                aoSetParam[0] = value;
                aSetter[i].invoke(key, aoSetParam);
                }
            }
        catch (Exception e)
            {
            throw e instanceof RuntimeException ? (RuntimeException) e
                                                : new WrapperException(e);
            }
        }
    
    // Accessor for the property "EntityBeanClass"
    public Class getEntityBeanClass()
        {
        return __m_EntityBeanClass;
        }
    
    public static PrimaryKeyExtractor getExtractor(Class clzEjb, Class clzKey, String[] asPropertyName)
        {
        // import java.util.Map;
        
        Map map = getExtractorCache();
        PrimaryKeyExtractor extractor = (PrimaryKeyExtractor) map.get(clzEjb);
        
        if (extractor == null)
            {
            _assert(clzEjb != null && clzKey != null && asPropertyName != null);
        
            extractor = new PrimaryKeyExtractor();
            extractor.setEntityBeanClass(clzEjb);
            extractor.setPrimaryKeyClass(clzKey);
            extractor.setPropertyName(asPropertyName);
            extractor.configure();
        
            map.put(clzEjb, extractor);
            }
        
        return extractor;
        }
    
    // Accessor for the property "ExtractorCache"
    private static java.util.Map getExtractorCache()
        {
        // import java.util.Map;
        // import com.tangosol.util.SafeHashMap;
        
        Map map = __s_ExtractorCache;
        
        if (map == null)
            {
            map = new SafeHashMap();
            setExtractorCache(map);
            }
        
        return map;
        }
    
    // Accessor for the property "PrimaryKeyClass"
    public Class getPrimaryKeyClass()
        {
        return __m_PrimaryKeyClass;
        }
    
    // Accessor for the property "PropertyAccessor"
    private java.lang.reflect.Method[] getPropertyAccessor()
        {
        return __m_PropertyAccessor;
        }
    
    // Accessor for the property "PropertyAccessor"
    public java.lang.reflect.Method getPropertyAccessor(int i)
        {
        return getPropertyAccessor()[i];
        }
    
    // Accessor for the property "PropertyClass"
    private Class[] getPropertyClass()
        {
        return __m_PropertyClass;
        }
    
    // Accessor for the property "PropertyClass"
    public Class getPropertyClass(int i)
        {
        return getPropertyClass()[i];
        }
    
    // Accessor for the property "PropertyCount"
    public int getPropertyCount()
        {
        return __m_PropertyCount;
        }
    
    // Accessor for the property "PropertyMutator"
    private java.lang.reflect.Method[] getPropertyMutator()
        {
        return __m_PropertyMutator;
        }
    
    // Accessor for the property "PropertyMutator"
    public java.lang.reflect.Method getPropertyMutator(int i)
        {
        return getPropertyMutator()[i];
        }
    
    // Accessor for the property "PropertyName"
    private String[] getPropertyName()
        {
        return __m_PropertyName;
        }
    
    // Accessor for the property "PropertyName"
    public String getPropertyName(int i)
        {
        return getPropertyName()[i];
        }
    
    // Accessor for the property "EntityBeanClass"
    public void setEntityBeanClass(Class pEntityBeanClass)
        {
        __m_EntityBeanClass = pEntityBeanClass;
        }
    
    // Accessor for the property "ExtractorCache"
    private static void setExtractorCache(java.util.Map pExtractorCache)
        {
        __s_ExtractorCache = pExtractorCache;
        }
    
    // Accessor for the property "PrimaryKeyClass"
    private void setPrimaryKeyClass(Class pPrimaryKeyClass)
        {
        __m_PrimaryKeyClass = pPrimaryKeyClass;
        }
    
    // Accessor for the property "PropertyAccessor"
    private void setPropertyAccessor(java.lang.reflect.Method[] aMethod)
        {
        __m_PropertyAccessor = aMethod;
        }
    
    // Accessor for the property "PropertyAccessor"
    private void setPropertyAccessor(int i, java.lang.reflect.Method method)
        {
        getPropertyAccessor()[i] = method;
        }
    
    // Accessor for the property "PropertyClass"
    private void setPropertyClass(Class[] aclz)
        {
        __m_PropertyClass = aclz;
        }
    
    // Accessor for the property "PropertyClass"
    private void setPropertyClass(int i, Class clz)
        {
        getPropertyClass()[i] = clz;
        }
    
    // Accessor for the property "PropertyCount"
    private void setPropertyCount(int c)
        {
        __m_PropertyCount = c;
        }
    
    // Accessor for the property "PropertyMutator"
    private void setPropertyMutator(java.lang.reflect.Method[] aMethod)
        {
        __m_PropertyMutator = aMethod;
        }
    
    // Accessor for the property "PropertyMutator"
    private void setPropertyMutator(int i, java.lang.reflect.Method method)
        {
        getPropertyMutator()[i] = method;
        }
    
    // Accessor for the property "PropertyName"
    private void setPropertyName(String[] asName)
        {
        __m_PropertyName = asName;
        }
    
    // Accessor for the property "PropertyName"
    private void setPropertyName(int i, String sName)
        {
        getPropertyName()[i] = sName;
        }
    }
