/* Class
*     _package.component.net.Cluster$ClusterService
*/

package _package.component.net;

import _package.component.util.daemon.TcpRingListener;

public class Cluster$ClusterService
        extends    _package.component.util.daemon.queueProcessor.service.ClusterService
    {
    // Fields declarations
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("DispatchMemberEvent", Cluster$ClusterService$DispatchMemberEvent.get_CLASS());
        __mapChildren.put("MemberConfigRequest", Cluster$ClusterService$MemberConfigRequest.get_CLASS());
        __mapChildren.put("MemberConfigResponse", Cluster$ClusterService$MemberConfigResponse.get_CLASS());
        __mapChildren.put("MemberConfigUpdate", Cluster$ClusterService$MemberConfigUpdate.get_CLASS());
        __mapChildren.put("MemberHeartbeat", Cluster$ClusterService$MemberHeartbeat.get_CLASS());
        __mapChildren.put("MemberJoined", Cluster$ClusterService$MemberJoined.get_CLASS());
        __mapChildren.put("MemberLeaving", Cluster$ClusterService$MemberLeaving.get_CLASS());
        __mapChildren.put("MemberLeft", Cluster$ClusterService$MemberLeft.get_CLASS());
        __mapChildren.put("MemberLeftResponse", Cluster$ClusterService$MemberLeftResponse.get_CLASS());
        __mapChildren.put("NewMemberAcceptId", Cluster$ClusterService$NewMemberAcceptId.get_CLASS());
        __mapChildren.put("NewMemberAcceptIdReply", Cluster$ClusterService$NewMemberAcceptIdReply.get_CLASS());
        __mapChildren.put("NewMemberAnnounce", Cluster$ClusterService$NewMemberAnnounce.get_CLASS());
        __mapChildren.put("NewMemberAnnounceReply", Cluster$ClusterService$NewMemberAnnounceReply.get_CLASS());
        __mapChildren.put("NewMemberAnnounceWait", Cluster$ClusterService$NewMemberAnnounceWait.get_CLASS());
        __mapChildren.put("NewMemberRequestId", Cluster$ClusterService$NewMemberRequestId.get_CLASS());
        __mapChildren.put("NewMemberRequestIdReject", Cluster$ClusterService$NewMemberRequestIdReject.get_CLASS());
        __mapChildren.put("NewMemberRequestIdReply", Cluster$ClusterService$NewMemberRequestIdReply.get_CLASS());
        __mapChildren.put("NewMemberRequestIdWait", Cluster$ClusterService$NewMemberRequestIdWait.get_CLASS());
        __mapChildren.put("NewMemberWelcome", Cluster$ClusterService$NewMemberWelcome.get_CLASS());
        __mapChildren.put("NewMemberWelcomeAnnounce", Cluster$ClusterService$NewMemberWelcomeAnnounce.get_CLASS());
        __mapChildren.put("NewMemberWelcomeRequest", Cluster$ClusterService$NewMemberWelcomeRequest.get_CLASS());
        __mapChildren.put("NotifyMemberJoined", Cluster$ClusterService$NotifyMemberJoined.get_CLASS());
        __mapChildren.put("NotifyMemberLeaving", Cluster$ClusterService$NotifyMemberLeaving.get_CLASS());
        __mapChildren.put("NotifyMemberLeft", Cluster$ClusterService$NotifyMemberLeft.get_CLASS());
        __mapChildren.put("NotifyMessageReceipt", Cluster$ClusterService$NotifyMessageReceipt.get_CLASS());
        __mapChildren.put("NotifyPollClosed", Cluster$ClusterService$NotifyPollClosed.get_CLASS());
        __mapChildren.put("NotifyServiceAnnounced", Cluster$ClusterService$NotifyServiceAnnounced.get_CLASS());
        __mapChildren.put("NotifyServiceJoined", Cluster$ClusterService$NotifyServiceJoined.get_CLASS());
        __mapChildren.put("NotifyServiceLeaving", Cluster$ClusterService$NotifyServiceLeaving.get_CLASS());
        __mapChildren.put("NotifyServiceLeft", Cluster$ClusterService$NotifyServiceLeft.get_CLASS());
        __mapChildren.put("NotifyShutdown", Cluster$ClusterService$NotifyShutdown.get_CLASS());
        __mapChildren.put("NotifyStartup", Cluster$ClusterService$NotifyStartup.get_CLASS());
        __mapChildren.put("SeniorMemberHeartbeat", Cluster$ClusterService$SeniorMemberHeartbeat.get_CLASS());
        __mapChildren.put("SeniorMemberKill", Cluster$ClusterService$SeniorMemberKill.get_CLASS());
        __mapChildren.put("SeniorMemberPanic", Cluster$ClusterService$SeniorMemberPanic.get_CLASS());
        __mapChildren.put("ServiceConfigRequest", Cluster$ClusterService$ServiceConfigRequest.get_CLASS());
        __mapChildren.put("ServiceConfigResponse", Cluster$ClusterService$ServiceConfigResponse.get_CLASS());
        __mapChildren.put("ServiceConfigSync", Cluster$ClusterService$ServiceConfigSync.get_CLASS());
        __mapChildren.put("ServiceConfigUpdate", Cluster$ClusterService$ServiceConfigUpdate.get_CLASS());
        __mapChildren.put("ServiceJoined", Cluster$ClusterService$ServiceJoined.get_CLASS());
        __mapChildren.put("ServiceJoinRequest", Cluster$ClusterService$ServiceJoinRequest.get_CLASS());
        __mapChildren.put("ServiceLeaving", Cluster$ClusterService$ServiceLeaving.get_CLASS());
        __mapChildren.put("ServiceLeft", Cluster$ClusterService$ServiceLeft.get_CLASS());
        __mapChildren.put("ServiceRegister", Cluster$ClusterService$ServiceRegister.get_CLASS());
        __mapChildren.put("ServiceRegisterRequest", Cluster$ClusterService$ServiceRegisterRequest.get_CLASS());
        __mapChildren.put("ServiceSecureRequest", Cluster$ClusterService$ServiceSecureRequest.get_CLASS());
        __mapChildren.put("ServiceUpdateResponse", Cluster$ClusterService$ServiceUpdateResponse.get_CLASS());
        }
    
    // Default constructor
    public Cluster$ClusterService()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Cluster$ClusterService(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAcceptingClients(false);
            setAcceptingOthers(true);
            setBroadcastRepeatMillis(256);
            setBroadcastTimeoutMillis(32768);
            setClusterMemberSet(new _package.component.net.memberSet.actualMemberSet.MasterMemberSet());
            setPollArray(new _package.component.util.WindowedArray());
            setServiceId(0);
            setServiceName("Cluster");
            setTimestampMaxVariance(10);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new Cluster$ClusterService$DaemonPool("DaemonPool", this, true), "DaemonPool");
        _addChild(new Cluster$ClusterService$EventDispatcher("EventDispatcher", this, true), "EventDispatcher");
        _addChild(new _package.component.util.daemon.queueProcessor.Service$MemberConfigListener("MemberConfigListener", this, true), "MemberConfigListener");
        _addChild(new Cluster$ClusterService$Queue("Queue", this, true), "Queue");
        _addChild(new Cluster$ClusterService$ServiceConfigMap("ServiceConfigMap", this, true), "ServiceConfigMap");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Cluster$ClusterService();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/Cluster$ClusterService".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Declared at the super level
    /**
    * This event occurs when an exception is thrown from onEnter, onWait,
    * onNotify and onExit.
    * 
    * If the exception should terminate the daemon, call stop(). The default
    * implementation prints debugging information and terminates the daemon.
    * 
    * @param e  the Throwable object (a RuntimeException or an Error)
    * 
    * @throws RuntimeException may be thrown; will terminate the daemon
    * @throws Error may be thrown; will terminate the daemon
    */
    public void onException(Throwable e)
        {
        Cluster cluster = ($Module) get_Module();
        if (cluster.getState() < Cluster.STATE_RUNNING)
            {
            cluster.setStartException(e);
            }
        
        super.onException(e);
        
        if (cluster.getState() < Cluster.STATE_STOPPING)
            {
            _trace(get_Name() + ": stopping cluster.", 1);
            cluster.stop();
            }
        }
    
    // Declared at the super level
    /**
    * This event occurs when the member is part of a running cluster and the
    * timer fires.
    */
    public void onTimerRunning()
        {
        // import Component.Util.Daemon.TcpRingListener;
        
        super.onTimerRunning();
        
        if (isAcceptingClients())
            {
            TcpRingListener daemonTcpRingListener = (($Module) getCluster()).getTcpRingListener();
            if (daemonTcpRingListener.isStarted())
                {
                daemonTcpRingListener.checkConnections();
                }
            }
        }
    
    // Declared at the super level
    /**
    * Setter for property Service.<p>
    * Indexed property of Service daemons running on <b>this</b> Member.
    */
    protected synchronized void setService(int i, _package.component.util.daemon.queueProcessor.Service service)
        {
        super.setService(i, service);
        if (i > 0)
            {
            (($Module) getCluster()).getReceiver().setService(i, service);
            }
        }
    
    // Declared at the super level
    /**
    * Setter for property State.<p>
    * State of the ClusterService; one of:
    *     STATE_ANNOUNCE
    *     STATE_JOINING
    *     STATE_JOINED
    */
    public synchronized void setState(int nState)
        {
        super.setState(nState);
        
        if (nState == STATE_JOINED)
            {
            ((Cluster) getCluster()).getReceiver().onJoined();
            }
        }
    
    // Declared at the super level
    /**
    * Setter for property StatsCpu.<p>
    * Statistics: total time spent while processing messages.
    */
    public void setStatsCpu(long cMillis)
        {
        super.setStatsCpu(cMillis);
        }
    
    // Declared at the super level
    /**
    * Setter for property StatsReceived.<p>
    * Statistics: total number of received messages.
    */
    public void setStatsReceived(long cMsgs)
        {
        super.setStatsReceived(cMsgs);
        }
    
    // Declared at the super level
    /**
    * Stop this service on this Member.
    */
    public synchronized void shutdown()
        {
        super.shutdown();
        }
    
    // Declared at the super level
    public void waitAcceptingClients()
        {
        super.waitAcceptingClients();
        }
    }
