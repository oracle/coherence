/* Class
*     _package.component.net.Member
*/

package _package.component.net;

import com.tangosol.net.InetAddressHelper;
import com.tangosol.util.Base;
import com.tangosol.util.UID;
import com.tangosol.util.UUID;
import com.tangosol.util.WrapperException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;

public class Member
        extends    _package.component.Net
        implements com.tangosol.net.Member
    {
    // Fields declarations
    
    /**
    * Property Address
    *
    * The IP address of the member's DatagramSocket for point-to-point
    * communication. This is part of the unique identifier of the Member
    * (Timestamp, Address, Port, MachineId).
    */
    private transient java.net.InetAddress __m_Address;
    
    /**
    * Property ByteMask
    *
    * A 32-bit integer value between 1 and 128 inclusive, with only one bit
    * set. When bitanded with the byte value from ByteOffset in a byte array
    * holding member indicators, the value will = 0 (member not specified) or
    * != 0 (member specified).
    * 
    * (This is actually an "int mask", not a "byte mask".)
    */
    private transient int __m_ByteMask;
    
    /**
    * Property ByteOffset
    *
    * An offset into a byte array holding member indicators, used in
    * conjunction with the ByteMask property.
    * 
    * (This is actually an "int index", not a "byte offset".)
    */
    private transient int __m_ByteOffset;
    
    /**
    * Property Dead
    *
    * Set to true when the Member is determined to be dead.
    */
    private transient boolean __m_Dead;
    
    /**
    * Property Id
    *
    * A small number that uniquely identifies the Member at this point in time
    * and does not change for the life of this Member. This value does not
    * uniquely identify the Member throughout the duration of the cluster
    * because Members that existed but left the cluster before this Member
    * existed may have had the same mini-id value and the same goes for Members
    * that may join the cluster after this Member leaves the cluster.
    * 
    * (Sometimes referred to as a "MiniId" in comparison to the "Uid".)
    */
    private int __m_Id;
    
    /**
    * Property MachineId
    *
    * An identifier that should be the same for Members that are on the same
    * physical machine, and different for Members that are on different
    * physical machines. This is part of the unique identifier of the Member
    * (Timestamp, Address, Port, MachineId).
    */
    private transient int __m_MachineId;
    
    /**
    * Property Port
    *
    * The port of the member's DatagramSocket for point-to-point communication.
    * This is part of the unique identifier of the Member (Timestamp, Address,
    * Port, MachineId).
    */
    private transient int __m_Port;
    
    /**
    * Property Timestamp
    *
    * Date/time value that the Member was born. This is part of the unique
    * identifier of the Member (Timestamp, Address, Port, MachineId).
    * 
    * Note: If the Member is marked as Dead, the Timestamp value indicates the
    * departure time (local clock).
    */
    private transient long __m_Timestamp;
    
    /**
    * Property Uid
    *
    * The unique identifier of the Member (Timestamp, Address, Port, MachineId)
    * packed into a UID. This is an obsoleted 16 byte UID, which is left for
    * backward compatibility reason.
    */
    
    /**
    * Property Uid32
    *
    * The unique identifier of the Member (Timestamp, Address, Port, MachineId)
    * packed into a UID. This is a new 32 byte UID that replaced the old 16
    * bytes one.
    */
    private com.tangosol.util.UUID __m_Uid32;
    
    /**
    * Property Uuid
    *
    * The unique identifier of the Member (Timestamp, Address, Port, MachineId)
    * packed into a UID. This is a new 32 byte UID that replaced the old 16
    * bytes one.
    */
    
    // Default constructor
    public Member()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Member(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Member();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/Member".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    public static int calcByteMask(int nId)
        {
        return 1 << ((nId - 1) % 32);
        }
    
    public static int calcByteOffset(int nId)
        {
        return (nId - 1) / 32;
        }
    
    // Declared at the super level
    /**
    * Compares this object with the specified object for order.  Returns a
    * negative integer, zero, or a positive integer as this object is less
    * than, equal to, or greater than the specified object.
    * 
    * @param o  the Object to be compared.
    * @return  a negative integer, zero, or a positive integer as this object
    * is less than, equal to, or greater than the specified object.
    * 
    * @throws ClassCastException if the specified object's type prevents it
    * from being compared to this Object.
    */
    public int compareTo(Object o)
        {
        // import com.tangosol.util.UUID;
        
        UUID uidThis = getUid32();
        UUID uidThat = ((Member) o).getUid32();
        
        return uidThis.compareTo(uidThat);
        }
    
    public void configureFromUid(com.tangosol.util.UUID uid)
        {
        // import com.tangosol.net.InetAddressHelper;
        // import com.tangosol.util.WrapperException;
        // import java.net.InetAddress;
        // import java.net.UnknownHostException;
        
        _assert(uid != null);
        
        long   ldt        = uid.getTimestamp();
        byte[] abAddr     = uid.getAddress();
        int    nPort      = uid.getPort();
        int    nMachineId = uid.getCount();
        
        // convert address value into an InetAddress
        InetAddress addr;
        try
            {
            addr = InetAddressHelper.getByAddress(abAddr);
            }
        catch (UnknownHostException e)
            {
            throw new WrapperException(e);
            }
        
        // store member info
        setTimestamp(ldt);
        setAddress(addr);
        setPort(nPort);
        setMachineId(nMachineId);
        setUid32(uid);
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        // import com.tangosol.util.Base;
        
        if (this == obj)
            {
            return true;
            }
        
        if (obj instanceof Member)
            {
            Member that = (Member) obj;
            return Base.equals(this.getUid32(), that.getUid32());
            }
        
        return false;
        }
    
    // From interface: com.tangosol.net.Member
    // Accessor for the property "Address"
    /**
    * Getter for property Address.<p>
    * The IP address of the member's DatagramSocket for point-to-point
    * communication. This is part of the unique identifier of the Member
    * (Timestamp, Address, Port, MachineId).
    */
    public java.net.InetAddress getAddress()
        {
        return __m_Address;
        }
    
    // Accessor for the property "ByteMask"
    /**
    * Getter for property ByteMask.<p>
    * A 32-bit integer value between 1 and 128 inclusive, with only one bit
    * set. When bitanded with the byte value from ByteOffset in a byte array
    * holding member indicators, the value will = 0 (member not specified) or
    * != 0 (member specified).
    * 
    * (This is actually an "int mask", not a "byte mask".)
    */
    public int getByteMask()
        {
        return __m_ByteMask;
        }
    
    // Accessor for the property "ByteOffset"
    /**
    * Getter for property ByteOffset.<p>
    * An offset into a byte array holding member indicators, used in
    * conjunction with the ByteMask property.
    * 
    * (This is actually an "int index", not a "byte offset".)
    */
    public int getByteOffset()
        {
        return __m_ByteOffset;
        }
    
    // From interface: com.tangosol.net.Member
    // Accessor for the property "Id"
    /**
    * Getter for property Id.<p>
    * A small number that uniquely identifies the Member at this point in time
    * and does not change for the life of this Member. This value does not
    * uniquely identify the Member throughout the duration of the cluster
    * because Members that existed but left the cluster before this Member
    * existed may have had the same mini-id value and the same goes for Members
    * that may join the cluster after this Member leaves the cluster.
    * 
    * (Sometimes referred to as a "MiniId" in comparison to the "Uid".)
    */
    public int getId()
        {
        return __m_Id;
        }
    
    // From interface: com.tangosol.net.Member
    // Accessor for the property "MachineId"
    /**
    * Getter for property MachineId.<p>
    * An identifier that should be the same for Members that are on the same
    * physical machine, and different for Members that are on different
    * physical machines. This is part of the unique identifier of the Member
    * (Timestamp, Address, Port, MachineId).
    */
    public int getMachineId()
        {
        return __m_MachineId;
        }
    
    // From interface: com.tangosol.net.Member
    // Accessor for the property "Port"
    /**
    * Getter for property Port.<p>
    * The port of the member's DatagramSocket for point-to-point communication.
    * This is part of the unique identifier of the Member (Timestamp, Address,
    * Port, MachineId).
    */
    public int getPort()
        {
        return __m_Port;
        }
    
    // From interface: com.tangosol.net.Member
    // Accessor for the property "Timestamp"
    /**
    * Getter for property Timestamp.<p>
    * Date/time value that the Member was born. This is part of the unique
    * identifier of the Member (Timestamp, Address, Port, MachineId).
    * 
    * Note: If the Member is marked as Dead, the Timestamp value indicates the
    * departure time (local clock).
    */
    public long getTimestamp()
        {
        return __m_Timestamp;
        }
    
    // From interface: com.tangosol.net.Member
    // Accessor for the property "Uid"
    /**
    * Getter for property Uid.<p>
    * The unique identifier of the Member (Timestamp, Address, Port, MachineId)
    * packed into a UID. This is an obsoleted 16 byte UID, which is left for
    * backward compatibility reason.
    */
    public com.tangosol.util.UID getUid()
        {
        // import com.tangosol.net.InetAddressHelper;
        // import com.tangosol.util.UID;
        // import java.net.InetAddress;
        
        // for backward compatibility only
        // _trace("An obsolete getUid() call; Use getUuid() instead\n" + get_StackTrace(), 4);
        
        long        ldt        = getTimestamp();
        InetAddress addr       = getAddress();
        int         nPort      = getPort();
        int         nMachineId = getMachineId();
        
        int nAddr  = (int) (InetAddressHelper.toLong(addr) & 0xFFFFFFFFL);
        int nCount = (nPort & 0xFFFF) | ((nMachineId & 0xFFFF) << 16);
        return new UID(nAddr, ldt, nCount);
        }
    
    // Accessor for the property "Uid32"
    /**
    * Getter for property Uid32.<p>
    * The unique identifier of the Member (Timestamp, Address, Port, MachineId)
    * packed into a UID. This is a new 32 byte UID that replaced the old 16
    * bytes one.
    */
    public com.tangosol.util.UUID getUid32()
        {
        // import com.tangosol.util.UUID;
        // import java.net.InetAddress;
        
        UUID uid = __m_Uid32;
        
        if (uid == null)
            {
            long        ldt        = getTimestamp();
            InetAddress addr       = getAddress();
            int         nPort      = getPort();
            int         nMachineId = getMachineId();
        
            _assert(ldt != 0);
            _assert(addr != null);
            _assert(nPort != 0);
            _assert(nMachineId != 0);
        
            uid = new UUID(ldt, addr, nPort, nMachineId);
            setUid32(uid);
            }
        
        return uid;
        }
    
    // Accessor for the property "Uuid"
    /**
    * Getter for property Uuid.<p>
    * The unique identifier of the Member (Timestamp, Address, Port, MachineId)
    * packed into a UID. This is a new 32 byte UID that replaced the old 16
    * bytes one.
    */
    public com.tangosol.util.UUID getUuid()
        {
        return getUid32();
        }
    
    // Declared at the super level
    public int hashCode()
        {
        // Member id's are unique, so they should make good hash codes
        return getId();
        }
    
    // Accessor for the property "Dead"
    /**
    * Getter for property Dead.<p>
    * Set to true when the Member is determined to be dead.
    */
    public boolean isDead()
        {
        return __m_Dead;
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        if (is_Deserialized())
            {
            configureFromUid(getUid32());
        
            int nId = getId();
            setByteOffset(calcByteOffset(nId));
            setByteMask(calcByteMask(nId));
            }
        super.onInit();
        }
    
    // Accessor for the property "Address"
    /**
    * Setter for property Address.<p>
    * The IP address of the member's DatagramSocket for point-to-point
    * communication. This is part of the unique identifier of the Member
    * (Timestamp, Address, Port, MachineId).
    */
    public void setAddress(java.net.InetAddress addr)
        {
        _assert(addr != null);
        _assert(getAddress() == null || addr.equals(getAddress()));
        
        __m_Address = (addr);
        }
    
    // Accessor for the property "ByteMask"
    /**
    * Setter for property ByteMask.<p>
    * A 32-bit integer value between 1 and 128 inclusive, with only one bit
    * set. When bitanded with the byte value from ByteOffset in a byte array
    * holding member indicators, the value will = 0 (member not specified) or
    * != 0 (member specified).
    * 
    * (This is actually an "int mask", not a "byte mask".)
    */
    protected void setByteMask(int nMask)
        {
        __m_ByteMask = nMask;
        }
    
    // Accessor for the property "ByteOffset"
    /**
    * Setter for property ByteOffset.<p>
    * An offset into a byte array holding member indicators, used in
    * conjunction with the ByteMask property.
    * 
    * (This is actually an "int index", not a "byte offset".)
    */
    protected void setByteOffset(int nOffset)
        {
        __m_ByteOffset = nOffset;
        }
    
    // Accessor for the property "Dead"
    /**
    * Setter for property Dead.<p>
    * Set to true when the Member is determined to be dead.
    */
    public void setDead(boolean fDead)
        {
        _assert(fDead);
        
        if (!isDead())
            {
            __m_Dead = (fDead);
            setTimestamp(System.currentTimeMillis());
            }
        }
    
    // Accessor for the property "Id"
    /**
    * Setter for property Id.<p>
    * A small number that uniquely identifies the Member at this point in time
    * and does not change for the life of this Member. This value does not
    * uniquely identify the Member throughout the duration of the cluster
    * because Members that existed but left the cluster before this Member
    * existed may have had the same mini-id value and the same goes for Members
    * that may join the cluster after this Member leaves the cluster.
    * 
    * (Sometimes referred to as a "MiniId" in comparison to the "Uid".)
    */
    public void setId(int nId)
        {
        _assert(nId > 0);
        _assert(getId() == 0 || nId == getId());
        
        __m_Id = (nId);
        
        setByteOffset(calcByteOffset(nId));
        setByteMask(calcByteMask(nId));
        }
    
    // Accessor for the property "MachineId"
    /**
    * Setter for property MachineId.<p>
    * An identifier that should be the same for Members that are on the same
    * physical machine, and different for Members that are on different
    * physical machines. This is part of the unique identifier of the Member
    * (Timestamp, Address, Port, MachineId).
    */
    public void setMachineId(int nId)
        {
        _assert(nId > 0 && nId <= 0xFFFF);
        _assert(getMachineId() == 0 || nId == getMachineId());
        
        __m_MachineId = (nId);
        }
    
    // Accessor for the property "Port"
    /**
    * Setter for property Port.<p>
    * The port of the member's DatagramSocket for point-to-point communication.
    * This is part of the unique identifier of the Member (Timestamp, Address,
    * Port, MachineId).
    */
    public void setPort(int nPort)
        {
        _assert(nPort > 0 && nPort <= 0xFFFF);
        _assert(getPort() == 0 || nPort == getPort());
        
        __m_Port = (nPort);
        }
    
    // Accessor for the property "Timestamp"
    /**
    * Setter for property Timestamp.<p>
    * Date/time value that the Member was born. This is part of the unique
    * identifier of the Member (Timestamp, Address, Port, MachineId).
    * 
    * Note: If the Member is marked as Dead, the Timestamp value indicates the
    * departure time (local clock).
    */
    public void setTimestamp(long cMillis)
        {
        _assert(cMillis > 0);
        _assert(isDead() || getTimestamp() == 0 || cMillis == getTimestamp());
        
        __m_Timestamp = (cMillis);
        }
    
    // Accessor for the property "Uid32"
    /**
    * Setter for property Uid32.<p>
    * The unique identifier of the Member (Timestamp, Address, Port, MachineId)
    * packed into a UID. This is a new 32 byte UID that replaced the old 16
    * bytes one.
    */
    protected void setUid32(com.tangosol.util.UUID uid)
        {
        __m_Uid32 = uid;
        }
    
    // Declared at the super level
    public String toString()
        {
        // import com.tangosol.net.InetAddressHelper;
        // import java.util.Date;
        
        long ldt = getTimestamp();
        
        return "Member(Id="   + getId()
             + ", Timestamp=" + (ldt == 0 ? "0" : new Date(ldt).toString())
             + ", Address="   + InetAddressHelper.toString(getAddress())
             + ", Port="      + getPort()
             + ", MachineId=" + getMachineId()
             + ")";
        }
    }
