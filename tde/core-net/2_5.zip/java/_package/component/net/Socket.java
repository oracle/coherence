/* Class
*     _package.component.net.Socket
*/

package _package.component.net;

import com.tangosol.net.InetAddressHelper;
import com.tangosol.util.WrapperException;

public abstract class Socket
        extends    _package.component.Net
    {
    // Fields declarations
    
    /**
    * Property Description
    *
    * Human readable socekt description.
    */
    
    /**
    * Property InetAddress
    *
    * The IP address that the socket uses if it is a socket that connects to an
    * IP address. This property must be configured before the socket is opened.
    */
    private java.net.InetAddress __m_InetAddress;
    
    /**
    * Property LastOpenMillis
    *
    * This property is set to the current time when the socket is opened.
    * 
    * @see open
    */
    private long __m_LastOpenMillis;
    
    /**
    * Property Lock
    *
    * The object that is used for synchronization. By default, it is this
    * socket. This property must be configured before the socket is opened.
    */
    private Object __m_Lock;
    
    /**
    * Property Port
    *
    * The network port number that the socket uses if it is a socket that opens
    * on a network port number. This property must be configured before the
    * socket is opened.
    */
    private int __m_Port;
    
    /**
    * Property PortAutoSelect
    *
    * The PortAutoSelect element could be used if it is a socket that opens on
    * a network port number. It specifies whether or not the 
    * port will be automatically incremented if the specified 
    * Port cannot be bound to because it is already in use.
    * 
    * Number of attempts is currently limited by 256.
    */
    private boolean __m_PortAutoSelect;
    
    /**
    * Property Reopen
    *
    * Set to true to allow for auto reopen. This property must be configured
    * before the socket is opened.
    */
    private boolean __m_Reopen;
    
    /**
    * Property ReopenTimeout
    *
    * This value indicates the timeout for re-open operation. If the socket can
    * be open within the specified time interval all the exceptions are
    * discarded.
    * 
    * @see #onException
    */
    private int __m_ReopenTimeout;
    
    /**
    * Property SoTimeout
    *
    * Enable/disable SO_TIMEOUT with the specified timeout, in milliseconds.
    * With this value set to a non-zero timeout, a call to read(), receive() or
    * accept() for TcpSocket,  UdpSocket or TcpSecketAccepter will block for
    * only this amount of time. If the timeout expires, an 
    * java.io.InterruptedIOException is raised and onInterruptedIOException
    * event is called, though the Socket is still valid. The option must be
    * enabled prior to entering the blocking operation to have effect. The
    * timeout value must be > 0. A timeout of zero is interpreted as an
    * infinite timeout.
    */
    private int __m_SoTimeout;
    
    /**
    * Property State
    *
    * One of STATE_INITIAL, STATE_OPEN and STATE_CLOSED. Configurable
    * properties should be set while the state is still STATE_INITIAL (before
    * the socket is first opened).
    */
    private int __m_State;
    
    /**
    * Property STATE_CLOSED
    *
    * Signifies that the socket is in a closed state.
    */
    public static final int STATE_CLOSED = 2;
    
    /**
    * Property STATE_INITIAL
    *
    * The initial state of the socket before it is opened for the first time.
    */
    public static final int STATE_INITIAL = 0;
    
    /**
    * Property STATE_OPEN
    *
    * Signifies that the socket is in an open state.
    */
    public static final int STATE_OPEN = 1;
    
    // Initializing constructor
    public Socket(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/Socket".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    public void close()
        {
        }
    
    // Declared at the super level
    protected void finalize()
            throws java.lang.Throwable
        {
        close();
        }
    
    public static String formatStateName(int nState)
        {
        switch (nState)
            {
            case STATE_INITIAL:
                return "STATE_INITIAL";
            case STATE_OPEN:
                return "STATE_OPEN";
            case STATE_CLOSED:
                return "STATE_CLOSED";
            default:
                return "<unknown>";
            }

        }
    
    // Accessor for the property "Description"
    /**
    * Getter for property Description.<p>
    * Human readable socekt description.
    */
    public String getDescription()
        {
        return "address:port=" + toString(getInetAddress()) + ":" + getPort();
        }
    
    // Accessor for the property "InetAddress"
    /**
    * Getter for property InetAddress.<p>
    * The IP address that the socket uses if it is a socket that connects to an
    * IP address. This property must be configured before the socket is opened.
    */
    public java.net.InetAddress getInetAddress()
        {
        return __m_InetAddress;
        }
    
    // Accessor for the property "LastOpenMillis"
    /**
    * Getter for property LastOpenMillis.<p>
    * This property is set to the current time when the socket is opened.
    * 
    * @see open
    */
    public long getLastOpenMillis()
        {
        return __m_LastOpenMillis;
        }
    
    // Accessor for the property "Lock"
    /**
    * Getter for property Lock.<p>
    * The object that is used for synchronization. By default, it is this
    * socket. This property must be configured before the socket is opened.
    */
    public Object getLock()
        {
        Object lock = __m_Lock;
        return lock == null ? this : lock;
        }
    
    // Accessor for the property "Port"
    /**
    * Getter for property Port.<p>
    * The network port number that the socket uses if it is a socket that opens
    * on a network port number. This property must be configured before the
    * socket is opened.
    */
    public int getPort()
        {
        return __m_Port;
        }
    
    // Accessor for the property "ReopenTimeout"
    /**
    * Getter for property ReopenTimeout.<p>
    * This value indicates the timeout for re-open operation. If the socket can
    * be open within the specified time interval all the exceptions are
    * discarded.
    * 
    * @see #onException
    */
    public int getReopenTimeout()
        {
        return __m_ReopenTimeout;
        }
    
    // Accessor for the property "SoTimeout"
    /**
    * Getter for property SoTimeout.<p>
    * Enable/disable SO_TIMEOUT with the specified timeout, in milliseconds.
    * With this value set to a non-zero timeout, a call to read(), receive() or
    * accept() for TcpSocket,  UdpSocket or TcpSecketAccepter will block for
    * only this amount of time. If the timeout expires, an 
    * java.io.InterruptedIOException is raised and onInterruptedIOException
    * event is called, though the Socket is still valid. The option must be
    * enabled prior to entering the blocking operation to have effect. The
    * timeout value must be > 0. A timeout of zero is interpreted as an
    * infinite timeout.
    */
    public int getSoTimeout()
        {
        return __m_SoTimeout;
        }
    
    // Accessor for the property "State"
    /**
    * Getter for property State.<p>
    * One of STATE_INITIAL, STATE_OPEN and STATE_CLOSED. Configurable
    * properties should be set while the state is still STATE_INITIAL (before
    * the socket is first opened).
    */
    public int getState()
        {
        return __m_State;
        }
    
    // Accessor for the property "PortAutoSelect"
    /**
    * Getter for property PortAutoSelect.<p>
    * The PortAutoSelect element could be used if it is a socket that opens on
    * a network port number. It specifies whether or not the 
    * port will be automatically incremented if the specified 
    * Port cannot be bound to because it is already in use.
    * 
    * Number of attempts is currently limited by 256.
    */
    public boolean isPortAutoSelect()
        {
        return __m_PortAutoSelect;
        }
    
    // Accessor for the property "Reopen"
    /**
    * Getter for property Reopen.<p>
    * Set to true to allow for auto reopen. This property must be configured
    * before the socket is opened.
    */
    public boolean isReopen()
        {
        return __m_Reopen;
        }
    
    /**
    * Generic level for handling a Socket exception that may indicate that the
    * socket is closed or inoperable (i.e. maybe it should be re-opened)
    * 
    * @param eException  the causal exception
    * @param lSocketActionMillis  the time that the exception occurred (or the
    * enclosing operation began or was in progress)
    */
    protected void onException(java.io.IOException eException, long lSocketActionMillis)
        {
        // import com.tangosol.util.WrapperException;
        
        if (lSocketActionMillis < getLastOpenMillis())
            {
            // socket has already been re-opened
            return;
            }
        
        close();
        
        if (isReopen())
            {
            long lTimeout = System.currentTimeMillis() + getReopenTimeout();
            do
                {
                try
                    {
                    open();
                    return;
                    }
                catch (Exception e)
                    {
                    Thread.yield();
                    }
                }
            while (System.currentTimeMillis() < lTimeout);
        
            throw new WrapperException(eException);
            }
        }
    
    /**
    * InterruptedIOException could be raised only when SoTimeout value is
    * greater then zero, and the timeout expires during a call to receive() for
    * a DatagramSocket, accept() for ServerSocket or getInputStream().read()
    * for Socket. The underlying socket remains valid.
    * 
    * @param eException  the causal exception
    * @param lSocketActionMillis  the time that the exception occurred (or the
    * enclosing operation began or was in progress)
    * 
    * @see SoTimeout property
    */
    protected void onInterruptedIOException(java.io.InterruptedIOException eException, long lSocketActionMillis)
        {
        onException(eException, lSocketActionMillis);
        }
    
    public void open()
            throws java.io.IOException
        {
        }
    
    // Accessor for the property "InetAddress"
    /**
    * Setter for property InetAddress.<p>
    * The IP address that the socket uses if it is a socket that connects to an
    * IP address. This property must be configured before the socket is opened.
    */
    public void setInetAddress(java.net.InetAddress addr)
        {
        synchronized (getLock())
            {
            _assert(getState() == STATE_INITIAL,
                "InetAddress cannot be modified once the socket has been opened");
        
            __m_InetAddress = (addr);
            }
        }
    
    // Accessor for the property "LastOpenMillis"
    /**
    * Setter for property LastOpenMillis.<p>
    * This property is set to the current time when the socket is opened.
    * 
    * @see open
    */
    protected void setLastOpenMillis(long lMillis)
        {
        __m_LastOpenMillis = lMillis;
        }
    
    // Accessor for the property "Lock"
    /**
    * Setter for property Lock.<p>
    * The object that is used for synchronization. By default, it is this
    * socket. This property must be configured before the socket is opened.
    */
    public void setLock(Object oLock)
        {
        _assert(getState() == STATE_INITIAL,
            "Lock cannot be modified once the socket has been opened");
        
        __m_Lock = (oLock);
        }
    
    // Accessor for the property "Port"
    /**
    * Setter for property Port.<p>
    * The network port number that the socket uses if it is a socket that opens
    * on a network port number. This property must be configured before the
    * socket is opened.
    */
    public void setPort(int nPort)
        {
        synchronized (getLock())
            {
            _assert(getState() == STATE_INITIAL,
                "Port cannot be modified once the socket has been opened");
        
            __m_Port = (nPort);
            }
        }
    
    // Accessor for the property "PortAutoSelect"
    /**
    * Setter for property PortAutoSelect.<p>
    * The PortAutoSelect element could be used if it is a socket that opens on
    * a network port number. It specifies whether or not the 
    * port will be automatically incremented if the specified 
    * Port cannot be bound to because it is already in use.
    * 
    * Number of attempts is currently limited by 256.
    */
    public void setPortAutoSelect(boolean fAuto)
        {
        synchronized (getLock())
            {
            _assert(getState() == STATE_INITIAL,
                "PortAutoSelect cannot be modified once the socket has been opened");
        
            __m_PortAutoSelect = (fAuto);
            }
        }
    
    // Accessor for the property "Reopen"
    /**
    * Setter for property Reopen.<p>
    * Set to true to allow for auto reopen. This property must be configured
    * before the socket is opened.
    */
    public void setReopen(boolean fReopen)
        {
        synchronized (getLock())
            {
            _assert(getState() == STATE_INITIAL,
                "Reopen cannot be modified once the socket has been opened");
        
            __m_Reopen = (fReopen);
            }

        }
    
    // Accessor for the property "ReopenTimeout"
    /**
    * Setter for property ReopenTimeout.<p>
    * This value indicates the timeout for re-open operation. If the socket can
    * be open within the specified time interval all the exceptions are
    * discarded.
    * 
    * @see #onException
    */
    public void setReopenTimeout(int cMillis)
        {
        synchronized (getLock())
            {
            _assert(getState() == STATE_INITIAL,
                "ReopenTimeout cannot be modified once the socket has been opened");
        
            __m_ReopenTimeout = (cMillis);
            }
        }
    
    // Accessor for the property "SoTimeout"
    /**
    * Setter for property SoTimeout.<p>
    * Enable/disable SO_TIMEOUT with the specified timeout, in milliseconds.
    * With this value set to a non-zero timeout, a call to read(), receive() or
    * accept() for TcpSocket,  UdpSocket or TcpSecketAccepter will block for
    * only this amount of time. If the timeout expires, an 
    * java.io.InterruptedIOException is raised and onInterruptedIOException
    * event is called, though the Socket is still valid. The option must be
    * enabled prior to entering the blocking operation to have effect. The
    * timeout value must be > 0. A timeout of zero is interpreted as an
    * infinite timeout.
    */
    public void setSoTimeout(int cMillis)
        {
        __m_SoTimeout = cMillis;
        }
    
    // Accessor for the property "State"
    /**
    * Setter for property State.<p>
    * One of STATE_INITIAL, STATE_OPEN and STATE_CLOSED. Configurable
    * properties should be set while the state is still STATE_INITIAL (before
    * the socket is first opened).
    */
    protected void setState(int nState)
        {
        __m_State = nState;
        }
    
    // Declared at the super level
    public String toString()
        {
        StringBuffer sb = new StringBuffer(get_Name());
        
        sb.append("{State=")
          .append(formatStateName(getState()))
          .append(", ")
          .append(getDescription())
          .append('}');
        
        return sb.toString();
        }
    
    public static String toString(java.net.InetAddress addr)
        {
        // import com.tangosol.net.InetAddressHelper;
        
        // prevent the addr.getHostName() call which could be very expensive
        
        return InetAddressHelper.toString(addr);
        }
    
    protected void validateBufferSize(int cbSendSize, int cbReceiveSize, int cbRequiredSize)
        {
        if (cbSendSize < cbRequiredSize || cbReceiveSize < cbRequiredSize)
            {
            throw new RuntimeException("Failed to set BufferSize to " + cbRequiredSize +
                "; actual send size="     + cbSendSize +
                ", actual receive size="  + cbReceiveSize);
            }

        }
    
    protected void validateSoTimeout(int cActual, int cRequired)
        {
        if (cActual != cRequired)
            {
            throw new RuntimeException("Failed to set SoTimeout to " +
                cRequired + "; actual value is " + cActual);
            }
        }
    }
