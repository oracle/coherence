/* Class
*     _package.component.net.memberSet.actualMemberSet.ServiceMemberSet
*/

package _package.component.net.memberSet.actualMemberSet;

import _package.component.net.Member;
import com.tangosol.util.Base;
import com.tangosol.util.NullImplementation;
import com.tangosol.util.ObservableHashMap;
import com.tangosol.util.ObservableMap;
import java.util.Date;
import java.util.Iterator;

public class ServiceMemberSet
        extends    _package.component.net.memberSet.ActualMemberSet
    {
    // Fields declarations
    
    /**
    * Property MemberConfigMap
    *
    * A map of configuration data local to the Service and specific to the
    * Member. This data is maintained by (and mutable only by) the Member that
    * it represents.
    */
    private com.tangosol.util.ObservableMap[] __m_MemberConfigMap;
    
    /**
    * Property OldestMember
    *
    * The ServiceMemberSet keeps track of the "most senior" Member that is
    * running the Service, to which special synchronization tasks can be
    * delegated. It's maintained for all services except the ClusterService
    * (id=0) for which the MasterMemberSet#getOldestMember must be used.
    */
    private _package.component.net.Member __m_OldestMember;
    
    /**
    * Property ServiceId
    *
    * The ServiceId.
    * 
    * @see ServiceInfo#setServiceId
    */
    private transient int __m_ServiceId;
    
    /**
    * Property ServiceJoined
    *
    * The cluster time that each Member joined the Service, indexed by Member
    * id.
    */
    private long[] __m_ServiceJoined;
    
    /**
    * Property ServiceLeaving
    *
    * True when the Member is already known to be leaving the Service, indexed
    * by Member id.
    */
    private boolean[] __m_ServiceLeaving;
    
    /**
    * Property ServiceName
    *
    * The ServiceName.
    * 
    * @see ServiceInfo#setServiceName
    */
    private transient String __m_ServiceName;
    
    /**
    * Property ServiceVersion
    *
    * The Service version string that each Member is running, indexed by Member
    * id.
    */
    private String[] __m_ServiceVersion;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Iterator", _package.component.net.MemberSet$Iterator.get_CLASS());
        }
    
    // Default constructor
    public ServiceMemberSet()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ServiceMemberSet(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ServiceMemberSet();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/memberSet/actualMemberSet/ServiceMemberSet".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Declared at the super level
    public synchronized void clear()
        {
        throw new UnsupportedOperationException();
        }
    
    public synchronized com.tangosol.util.ObservableMap ensureMemberConfigMap(int i)
        {
        // import com.tangosol.util.ObservableMap;
        // import com.tangosol.util.ObservableHashMap;
        
        ObservableMap[] amap = getMemberConfigMap();
        ObservableMap   map  = (amap == null || i >= amap.length ? null : amap[i]);
        
        if (map == null)
            {
            map = new ObservableHashMap();
            setMemberConfigMap(i, map);
            }
        
        return map;
        }
    
    // Accessor for the property "MemberConfigMap"
    /**
    * Getter for property MemberConfigMap.<p>
    * A map of configuration data local to the Service and specific to the
    * Member. This data is maintained by (and mutable only by) the Member that
    * it represents.
    */
    protected com.tangosol.util.ObservableMap[] getMemberConfigMap()
        {
        return __m_MemberConfigMap;
        }
    
    // Accessor for the property "MemberConfigMap"
    /**
    * Getter for property MemberConfigMap.<p>
    * A map of configuration data local to the Service and specific to the
    * Member. This data is maintained by (and mutable only by) the Member that
    * it represents.
    */
    public com.tangosol.util.ObservableMap getMemberConfigMap(int i)
        {
        // import com.tangosol.util.ObservableMap;
        // import com.tangosol.util.NullImplementation;
        
        ObservableMap[] amap = getMemberConfigMap();
        ObservableMap   map  = (amap == null || i >= amap.length ? null : amap[i]);
        
        if (map == null)
            {
            map = NullImplementation.getObservableMap();
            }
        
        return map;
        }
    
    // Accessor for the property "OldestMember"
    /**
    * Getter for property OldestMember.<p>
    * The ServiceMemberSet keeps track of the "most senior" Member that is
    * running the Service, to which special synchronization tasks can be
    * delegated. It's maintained for all services except the ClusterService
    * (id=0) for which the MasterMemberSet#getOldestMember must be used.
    */
    public _package.component.net.Member getOldestMember()
        {
        if (getServiceId() == 0)
            {
            throw new UnsupportedOperationException("Use ClusterOldestMember instead");
            }
        return __m_OldestMember;
        }
    
    // Accessor for the property "ServiceId"
    /**
    * Getter for property ServiceId.<p>
    * The ServiceId.
    * 
    * @see ServiceInfo#setServiceId
    */
    public int getServiceId()
        {
        return __m_ServiceId;
        }
    
    // Accessor for the property "ServiceJoined"
    /**
    * Getter for property ServiceJoined.<p>
    * The cluster time that each Member joined the Service, indexed by Member
    * id.
    */
    protected long[] getServiceJoined()
        {
        return __m_ServiceJoined;
        }
    
    // Accessor for the property "ServiceJoined"
    /**
    * Getter for property ServiceJoined.<p>
    * The cluster time that each Member joined the Service, indexed by Member
    * id.
    */
    public long getServiceJoined(int i)
        {
        long[] alMillis = getServiceJoined();
        return alMillis == null || i >= alMillis.length ? 0L : alMillis[i];
        }
    
    // Accessor for the property "ServiceName"
    /**
    * Getter for property ServiceName.<p>
    * The ServiceName.
    * 
    * @see ServiceInfo#setServiceName
    */
    public String getServiceName()
        {
        return __m_ServiceName;
        }
    
    // Accessor for the property "ServiceVersion"
    /**
    * Getter for property ServiceVersion.<p>
    * The Service version string that each Member is running, indexed by Member
    * id.
    */
    protected String[] getServiceVersion()
        {
        return __m_ServiceVersion;
        }
    
    // Accessor for the property "ServiceVersion"
    /**
    * Getter for property ServiceVersion.<p>
    * The Service version string that each Member is running, indexed by Member
    * id.
    */
    public String getServiceVersion(int i)
        {
        String[] asVersion = getServiceVersion();
        return asVersion == null || i >= asVersion.length ? null : asVersion[i];
        }
    
    // Accessor for the property "ServiceLeaving"
    /**
    * Getter for property ServiceLeaving.<p>
    * True when the Member is already known to be leaving the Service, indexed
    * by Member id.
    */
    protected boolean[] isServiceLeaving()
        {
        return __m_ServiceLeaving;
        }
    
    // Accessor for the property "ServiceLeaving"
    /**
    * Getter for property ServiceLeaving.<p>
    * True when the Member is already known to be leaving the Service, indexed
    * by Member id.
    */
    public boolean isServiceLeaving(int i)
        {
        boolean[] afLeaving = isServiceLeaving();
        return afLeaving == null || i >= afLeaving.length ? false : afLeaving[i];
        }
    
    // Declared at the super level
    public synchronized boolean remove(Object o)
        {
        // import Component.Net.Member;
        // import java.util.Iterator;
        
        if (super.remove(o))
            {
            Member memberLeft = (Member) o;
            int    nId        = memberLeft.getId();
        
            setServiceVersion (nId, null);
            setServiceJoined  (nId, 0L);
            setServiceLeaving (nId, false);
            setMemberConfigMap(nId, null);
        
            if (getServiceId() > 0 && memberLeft == getOldestMember())
                {
                // find next-oldest member
                Member memberOldest  = null;
                long   lOldestJoined = Long.MAX_VALUE;
                int    nOldestId     = 0;
        
                for (Iterator iter = iterator(); iter.hasNext(); )
                    {
                    Member member        = (Member) iter.next();
                    int    nMemberId     = member.getId();
                    long   lMemberJoined = getServiceJoined(member.getId());
        
                    _assert(lMemberJoined > 0L && lMemberJoined != lOldestJoined);
        
                    if (lMemberJoined < lOldestJoined)
                        {
                        memberOldest  = member;
                        nOldestId     = nMemberId;
                        lOldestJoined = lMemberJoined;
                        }
                    }
        
                setOldestMember(memberOldest);
                }
        
            return true;
            }
        else
            {
            return false;
            }
        }
    
    // Accessor for the property "MemberConfigMap"
    /**
    * Setter for property MemberConfigMap.<p>
    * A map of configuration data local to the Service and specific to the
    * Member. This data is maintained by (and mutable only by) the Member that
    * it represents.
    */
    protected void setMemberConfigMap(com.tangosol.util.ObservableMap[] amap)
        {
        __m_MemberConfigMap = amap;
        }
    
    // Accessor for the property "MemberConfigMap"
    /**
    * Setter for property MemberConfigMap.<p>
    * A map of configuration data local to the Service and specific to the
    * Member. This data is maintained by (and mutable only by) the Member that
    * it represents.
    */
    protected synchronized void setMemberConfigMap(int i, com.tangosol.util.ObservableMap map)
        {
        // import com.tangosol.util.ObservableMap;
        
        ObservableMap[] amap = getMemberConfigMap();
        
        // resize if storing non-null beyond bounds
        boolean fBeyondBounds = (amap == null || i >= amap.length);
        if (map != null && fBeyondBounds)
            {
            // resize
            ObservableMap[] amapNew = new ObservableMap[i + 8];
        
            // copy original data
            if (amap != null)
                {
                System.arraycopy(amap, 0, amapNew, 0, amap.length);
                }
        
            // store array
            amap = amapNew;
            setMemberConfigMap(amap);
        
            fBeyondBounds = false;
            }
        
        if (!fBeyondBounds)
            {
            amap[i] = map;
            }
        }
    
    // Accessor for the property "OldestMember"
    /**
    * Setter for property OldestMember.<p>
    * The ServiceMemberSet keeps track of the "most senior" Member that is
    * running the Service, to which special synchronization tasks can be
    * delegated. It's maintained for all services except the ClusterService
    * (id=0) for which the MasterMemberSet#getOldestMember must be used.
    */
    protected void setOldestMember(_package.component.net.Member member)
        {
        __m_OldestMember = member;
        }
    
    // Accessor for the property "ServiceId"
    /**
    * Setter for property ServiceId.<p>
    * The ServiceId.
    * 
    * @see ServiceInfo#setServiceId
    */
    public void setServiceId(int nId)
        {
        __m_ServiceId = nId;
        }
    
    // Accessor for the property "ServiceJoined"
    /**
    * Setter for property ServiceJoined.<p>
    * The cluster time that each Member joined the Service, indexed by Member
    * id.
    */
    protected void setServiceJoined(long[] alMillis)
        {
        __m_ServiceJoined = alMillis;
        }
    
    // Accessor for the property "ServiceJoined"
    /**
    * Setter for property ServiceJoined.<p>
    * The cluster time that each Member joined the Service, indexed by Member
    * id.
    */
    public synchronized void setServiceJoined(int i, long lMillis)
        {
        // import Component.Net.Member;
        
        long[] alMillis = getServiceJoined();
        
        // resize if storing non-null beyond bounds
        boolean fBeyondBounds = (alMillis == null || i >= alMillis.length);
        if (lMillis != 0L && fBeyondBounds)
            {
            // resize
            long[] alMillisNew = new long[i + 8];
        
            // copy original data
            if (alMillis != null)
                {
                System.arraycopy(alMillis, 0, alMillisNew, 0, alMillis.length);
                }
        
            // store array
            alMillis = alMillisNew;
            setServiceJoined(alMillis);
        
            fBeyondBounds = false;
            }
        
        if (!fBeyondBounds)
            {
            if (lMillis > 0L && getServiceId() > 0)
                {
                Member memberOldest = getOldestMember();
                if (memberOldest == null)
                    {
                    setOldestMember(getMember(i));
                    }
                else
                    {
                    // seniority can never be revoked; the only case when the oldest
                    // member could be replaced is during original "en mass" update
                    // (see ClusterService$NewMemberWelcome#onReceived)
                    int  nMemberId     = i;
                    long lMemberJoined = lMillis;
                    int  nOldestId     = memberOldest.getId();
                    long lOldestJoined = alMillis[nOldestId];
        
                    _assert(nMemberId != nOldestId && lMemberJoined != lOldestJoined,
                        "Member=" + nMemberId + "(Joined=" + lMemberJoined +
                        "), Oldest=" + nOldestId + "(Joined=" + lOldestJoined + ')');
        
                    if (lMemberJoined < lOldestJoined)
                        {
                        setOldestMember(getMember(nMemberId));
                        }
                    }
                }
            alMillis[i] = lMillis;
            }
        }
    
    // Accessor for the property "ServiceLeaving"
    /**
    * Setter for property ServiceLeaving.<p>
    * True when the Member is already known to be leaving the Service, indexed
    * by Member id.
    */
    protected void setServiceLeaving(boolean[] afLeaving)
        {
        __m_ServiceLeaving = afLeaving;
        }
    
    // Accessor for the property "ServiceLeaving"
    /**
    * Setter for property ServiceLeaving.<p>
    * True when the Member is already known to be leaving the Service, indexed
    * by Member id.
    */
    public synchronized void setServiceLeaving(int i, boolean fLeaving)
        {
        boolean[] afLeaving = isServiceLeaving();
        
        // resize if storing true beyond bounds
        boolean fBeyondBounds = (afLeaving == null || i >= afLeaving.length);
        if (fLeaving && fBeyondBounds)
            {
            // resize
            boolean[] afLeavingNew = new boolean[i + 8];
        
            // copy original data
            if (afLeaving != null)
                {
                System.arraycopy(afLeaving, 0, afLeavingNew, 0, afLeaving.length);
                }
        
            // store array
            afLeaving = afLeavingNew;
            setServiceLeaving(afLeaving);
        
            fBeyondBounds = false;
            }
        
        if (!fBeyondBounds)
            {
            afLeaving[i] = fLeaving;
            }
        }
    
    // Accessor for the property "ServiceName"
    /**
    * Setter for property ServiceName.<p>
    * The ServiceName.
    * 
    * @see ServiceInfo#setServiceName
    */
    public void setServiceName(String sName)
        {
        __m_ServiceName = sName;
        }
    
    // Accessor for the property "ServiceVersion"
    /**
    * Setter for property ServiceVersion.<p>
    * The Service version string that each Member is running, indexed by Member
    * id.
    */
    protected void setServiceVersion(String[] asVersion)
        {
        __m_ServiceVersion = asVersion;
        }
    
    // Accessor for the property "ServiceVersion"
    /**
    * Setter for property ServiceVersion.<p>
    * The Service version string that each Member is running, indexed by Member
    * id.
    */
    public synchronized void setServiceVersion(int i, String sVersion)
        {
        String[] asVersion = getServiceVersion();
        
        // resize if storing non-null beyond bounds
        boolean fBeyondBounds = (asVersion == null || i >= asVersion.length);
        if (sVersion != null && fBeyondBounds)
            {
            // resize
            String[] asVersionNew = new String[i + 8];
        
            // copy original data
            if (asVersion != null)
                {
                System.arraycopy(asVersion, 0, asVersionNew, 0, asVersion.length);
                }
        
            // store array
            asVersion = asVersionNew;
            setServiceVersion(asVersion);
        
            fBeyondBounds = false;
            }
        
        if (!fBeyondBounds)
            {
            asVersion[i] = sVersion;
            }
        }
    
    // Declared at the super level
    public String toString()
        {
        // import Component.Net.Member;
        // import com.tangosol.util.Base;
        // import java.util.Date;
        // import java.util.Iterator;
        
        StringBuffer sb = new StringBuffer();
        sb.append("ServiceMemberSet(")
          .append("\n  OldestMember="    + (getServiceId() == 0 ? "n/a" : String.valueOf(getOldestMember())))
          .append("\n  ActualMemberSet=" + Base.indentString(super.toString(), "  ", false))
          .append("\n  MemberId/ServiceVersion/ServiceJoined/ServiceLeaving")
          // .append(/MemberConfigMap[]="
          ;
        
        boolean fFirst = true;
        for (Iterator iter = iterator(); iter.hasNext(); )
            {
            if (fFirst)
                {
                fFirst = false;
                }
            else
                {
                sb.append(',');
                }
        
            int nMember = ((Member) iter.next()).getId();
            sb.append("\n    ")
              .append(nMember)
              .append('/')
              .append(getServiceVersion(nMember))
              .append('/')
              .append(new Date(getServiceJoined(nMember)))
              .append('/')
              .append(isServiceLeaving(nMember))
              // .append('/')
              // .append(getMemberConfigMap(nMember)
              ;
            }
        
        sb.append("\n  )");
        return sb.toString();
        }
    }
