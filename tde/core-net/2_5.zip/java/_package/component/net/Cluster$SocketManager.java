/* Class
*     _package.component.net.Cluster$SocketManager
*/

package _package.component.net;

import _package.component.net.Socket;
import _package.component.net.socket.UdpSocket;
import java.util.Collection;
import java.util.Iterator;

public class Cluster$SocketManager
        extends    _package.component.Util
    {
    // Fields declarations
    
    /**
    * Property AttemptCount
    *
    * The count of socket collection refresh attempts. The reason for this
    * count is that depending on the cause of a problem, the socket re-openning
    * could be successful, but a very first send() or receive() call fails, in
    * which case we could get to an infinite loop of successful
    * refreshSockets() calls that follow and foloowed by failed send() or
    * receive() calls. This count is reset if a socket that caused the refresh
    * to occur had at least one successful send() and receive() operation.
    * 
    * @see #refreshSockets
    */
    private transient int __m_AttemptCount;
    
    /**
    * Property MulticastUdpSocket
    *
    */
    
    /**
    * Property RegisteredSockets
    *
    */
    private java.util.Collection __m_RegisteredSockets;
    
    /**
    * Property TcpSocketAccepter
    *
    */
    
    /**
    * Property UnicastUdpSocket
    *
    */
    
    // Default constructor
    public Cluster$SocketManager()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Cluster$SocketManager(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setRegisteredSockets(new com.tangosol.util.SafeLinkedList());
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new Cluster$SocketManager$MulticastUdpSocket("MulticastUdpSocket", this, true), "MulticastUdpSocket");
        _addChild(new Cluster$SocketManager$TcpSocketAccepter("TcpSocketAccepter", this, true), "TcpSocketAccepter");
        _addChild(new Cluster$SocketManager$UnicastUdpSocket("UnicastUdpSocket", this, true), "UnicastUdpSocket");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Cluster$SocketManager();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/Cluster$SocketManager".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    private void forceGC()
        {
        // attempt to force garbage-collection (note: JVM-specific behavior)
        // TODO: this should be configurable or something
        Runtime.getRuntime().gc();
        Thread.yield();
        try
            {
            Thread.sleep(50);
            }
        catch (InterruptedException e)
            {
            Thread.currentThread().interrupt();
            }
        }
    
    // Accessor for the property "AttemptCount"
    /**
    * Getter for property AttemptCount.<p>
    * The count of socket collection refresh attempts. The reason for this
    * count is that depending on the cause of a problem, the socket re-openning
    * could be successful, but a very first send() or receive() call fails, in
    * which case we could get to an infinite loop of successful
    * refreshSockets() calls that follow and foloowed by failed send() or
    * receive() calls. This count is reset if a socket that caused the refresh
    * to occur had at least one successful send() and receive() operation.
    * 
    * @see #refreshSockets
    */
    public int getAttemptCount()
        {
        return __m_AttemptCount;
        }
    
    // Accessor for the property "MulticastUdpSocket"
    /**
    * Getter for property MulticastUdpSocket.<p>
    */
    public Cluster$SocketManager$MulticastUdpSocket getMulticastUdpSocket()
        {
        return ($MulticastUdpSocket) _findChild("MulticastUdpSocket");
        }
    
    // Accessor for the property "RegisteredSockets"
    /**
    * Getter for property RegisteredSockets.<p>
    */
    public java.util.Collection getRegisteredSockets()
        {
        return __m_RegisteredSockets;
        }
    
    // Accessor for the property "TcpSocketAccepter"
    /**
    * Getter for property TcpSocketAccepter.<p>
    */
    public Cluster$SocketManager$TcpSocketAccepter getTcpSocketAccepter()
        {
        return ($TcpSocketAccepter) _findChild("TcpSocketAccepter");
        }
    
    // Accessor for the property "UnicastUdpSocket"
    /**
    * Getter for property UnicastUdpSocket.<p>
    */
    public Cluster$SocketManager$UnicastUdpSocket getUnicastUdpSocket()
        {
        return ($UnicastUdpSocket) _findChild("UnicastUdpSocket");
        }
    
    public void refreshSockets(java.io.IOException eCause, Socket socketCause)
        {
        // import Component.Net.Socket;
        // import Component.Net.Socket.UdpSocket;
        // import java.util.Collection;
        // import java.util.Iterator;
        
        Cluster    cluster   = ($Module) get_Module();
        Socket     socket    = socketCause;
        Exception  eLast     = eCause;
        long       lTimeout  = 0L;
        
        Collection collection = getRegisteredSockets();
        synchronized (collection)
            {
            int cMaxTries = 8;
        
            if (socketCause instanceof UdpSocket)
                {
                UdpSocket socketUdp = (UdpSocket) socketCause;
                if (socketUdp.getCountReceived() == 0 ||
                    socketUdp.getCountSent()     == 0)
                    {
                    // the socket was not fully "established"
                    int cAttempts  = getAttemptCount() + 1;
                    setAttemptCount(cAttempts);
                    cMaxTries -= cAttempts;
                    }
                else
                    {
                    // the socket was established; reset the attempt count
                    setAttemptCount(0);
                    }
                }
        
            for (int iTry = 0; iTry < cMaxTries; iTry++)
                {
                try
                    {
                    if (collection.isEmpty())
                        {
                        return;
                        }
        
                    // format the message before the sockets state changes
                    String sMsg = "Attempt to refresh sockets: " + collection +
                                  " caused by " + socket + "; exception " + eLast;
                    for (Iterator iter = collection.iterator(); iter.hasNext();)
                        {
                        socket = (Socket) iter.next();
                        if (lTimeout == 0L)
                            {
                            lTimeout = System.currentTimeMillis() + socket.getReopenTimeout();
                            }
                        socket.close();
                        }
        
                    if (cluster.getState() < Cluster.STATE_STOPPING)
                        {
                        _trace(sMsg, 5);
                        forceGC();
        
                        for (Iterator iter = collection.iterator(); iter.hasNext();)
                            {
                            socket = (Socket) iter.next();
                            socket.open();
                            }
                        }
                    return;
                    }
                catch (Exception e)
                    {
                    eLast = e;
                    forceGC();
                    _assert(lTimeout != 0L);
                    if (System.currentTimeMillis() > lTimeout)
                        {
                        break;
                        }
                    }
                }
            }
        
        _trace("Unable to refresh sockets: " + collection + '\n' +
               "Last exception on " + socket + " was:\n" + getStackTrace(eLast), 1);
        _trace("Stopping cluster", 1);
        cluster.stop();
        }
    
    public void registerSocket(Socket socket)
        {
        // import java.util.Collection;
        
        _assert(socket != null);
        
        Collection collection = getRegisteredSockets();
        synchronized (collection)
            {
            socket.setLock(collection);
            if (!collection.contains(socket))
                {
                collection.add(socket);
                }
            }
        }
    
    public void releaseSockets()
        {
        // import Component.Net.Socket;
        // import java.util.Collection;
        // import java.util.Iterator;
        
        Collection collection = getRegisteredSockets();
        synchronized (collection)
            {
            for (Iterator iter = collection.iterator(); iter.hasNext(); )
                {
                Socket socket = (Socket) iter.next();
                socket.close();
                }
            collection.clear();
            }
        }
    
    // Accessor for the property "AttemptCount"
    /**
    * Setter for property AttemptCount.<p>
    * The count of socket collection refresh attempts. The reason for this
    * count is that depending on the cause of a problem, the socket re-openning
    * could be successful, but a very first send() or receive() call fails, in
    * which case we could get to an infinite loop of successful
    * refreshSockets() calls that follow and foloowed by failed send() or
    * receive() calls. This count is reset if a socket that caused the refresh
    * to occur had at least one successful send() and receive() operation.
    * 
    * @see #refreshSockets
    */
    protected void setAttemptCount(int c)
        {
        __m_AttemptCount = c;
        }
    
    // Accessor for the property "RegisteredSockets"
    /**
    * Setter for property RegisteredSockets.<p>
    */
    protected void setRegisteredSockets(java.util.Collection collection)
        {
        __m_RegisteredSockets = collection;
        }
    
    public void unregisterSocket(Socket socket)
        {
        // import java.util.Collection;
        
        Collection collection = getRegisteredSockets();
        synchronized (collection)
            {
            collection.remove(socket);
            }
        }
    }
