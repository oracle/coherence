/* Class
*     _package.component.net.Security
*/

package _package.component.net;

import _package.component.application.console.Coherence;
import com.tangosol.net.ClusterPermission;
import com.tangosol.run.xml.XmlElement;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;

/**
* The base component for the Coherence Security framework implementation.
* 
* The basic pattern of usage is:
* 
*     Security security = Security.getInstance();
*     if (security != null)
*         {
*         security.checkPermission(cluster, 
*             new ClusterPermission(sTarget, sAction));
*         }
* 
* alternatively there is a helper method:
* 
*     Security.checkPermission(cluster, sService, sCache, sAction);
* 
* that incapsulates the above logic where basically:
*     sTarget = sService +'/' + sCache;
* 
* The Security component itself MUST NOT be J2SE 1.4 dependent.
*/
public abstract class Security
        extends    _package.component.Net
    {
    // Fields declarations
    
    /**
    * Property Configured
    *
    * Is security already configured?
    */
    private static transient boolean __s_Configured;
    
    /**
    * Property Instance
    *
    * The Security instance.
    */
    private static transient Security __s_Instance;
    
    /**
    * Property SubjectSecure
    *
    * Subject object assosiated with the current thread.
    */
    private transient Object __m_SubjectSecure;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("RefAction", Security$RefAction.get_CLASS());
        }
    
    // Initializing constructor
    public Security(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/Security".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    /**
    * Security API exposed to the all Service components. Called on a client
    * thread.
    */
    public void checkPermission(com.tangosol.net.Cluster cluster, com.tangosol.net.ClusterPermission permission)
        {
        }
    
    /**
    * Helper method around "Security API".
    */
    public static void checkPermission(com.tangosol.net.Cluster cluster, String sServiceName, String sCacheName, String sAction)
        {
        // import com.tangosol.net.ClusterPermission;
        
        Security security = Security.getInstance();
        if (security != null)
            {
            _assert(sServiceName != null, "Service must be specified");
            
            String sTarget = "service=" + sServiceName +
                (sCacheName == null ? "" : ",cache=" + sCacheName);
        
            security.checkPermission(cluster, new ClusterPermission(sTarget, sAction));
            }
        }
    
    protected void configure(com.tangosol.run.xml.XmlElement xmlConfig)
        {
        if (isConfigured())
            {
            throw new IllegalStateException("Already configured");
            }
        }
    
    protected static synchronized void configureSecurity()
        {
        // import Component.Application.Console.Coherence;
        // import com.tangosol.run.xml.XmlElement;
        
        if (isConfigured())
            {
            return;
            }
        
        try
            {
            // internal call equivalent to "CacheFactory.getSecurityConfig();"
            XmlElement xmlConfig = Coherence.getServiceConfig("$Security");
            if (xmlConfig != null)
                {
                if (!xmlConfig.getSafeElement("enabled").getBoolean())
                    {
                    return;
                    }
        
                // "model" element is not documented for now
                String   sImpl = xmlConfig.getSafeElement("model").getString("Standard");
                Security security = (Security) _newInstance("Component.Net.Security." + sImpl);
        
                // any exception coming from "configure" call will turn the Security off
                security.configure(xmlConfig);
                setInstance(security);
                }
            }
        finally
            {
            setConfigured(true);
            }
        }
    
    /**
    * Helper method.
    */
    public static java.security.PrivilegedAction createPrivilegedAction(java.lang.reflect.Method method)
        {
        $RefAction action = new $RefAction();
        
        action.setMethod(method);
        
        return action;
        }
    
    /**
    * Helper method.
    */
    public static java.security.PrivilegedAction createPrivilegedAction(java.lang.reflect.Method method, Object oTarget, Object[] aoArg)
        {
        $RefAction action = new $RefAction();
        
        action.setMethod(method);
        action.setTarget(oTarget);
        action.setArguments(aoArg);
        
        return action;
        }
    
    // Accessor for the property "Instance"
    /**
    * Getter for property Instance.<p>
    * The Security instance.
    */
    public static Security getInstance()
        {
        if (!isConfigured())
            {
            try
                {
                configureSecurity();
                }
            catch (RuntimeException e)
                {
                _trace("Failed to configure the Security module", 1);
                _trace(e);
                }
            }
        return __s_Instance;
        }
    
    // Accessor for the property "SubjectSecure"
    /**
    * Getter for property SubjectSecure.<p>
    * Subject object assosiated with the current thread.
    */
    protected Object getSubjectSecure()
        {
        return __m_SubjectSecure;
        }
    
    /**
    * Security debugging helper. Not used for anything else!
    */
    public Object impersonate(Object oSubject, String sNameOld, String sNameNew)
        {
        return null;
        }
    
    // Accessor for the property "Configured"
    /**
    * Getter for property Configured.<p>
    * Is security already configured?
    */
    protected static boolean isConfigured()
        {
        return __s_Configured;
        }
    
    /**
    * @param oHandler  a CallbackHandler object
    * 
    * @see com.tangosol.net.security.Security
    */
    public static Object login(Object oHandler)
        {
        Security security = getInstance();
        return security == null ? null : security.loginSecure(oHandler);
        }
    
    /**
    * Subclassing support.
    */
    public Object loginSecure(Object oHandler)
        {
        return null;
        }
    
    /**
    * Callback API used to validate and respond to a security related request.
    * Called on a cluster service thread.
    * 
    * @param service  the ClusterService
    */
    public Object processSecureRequest(com.tangosol.net.Service service, Member memberFrom, Object oRequestInfo)
        {
        return null;
        }
    
    /**
    * Security API used by the Service components. Called on a service thread
    * upon the service termination.
    * 
    * @param sServiceName  the relevant Service name
    */
    public void releaseSecureContext(String sServiceName)
        {
        }
    
    /**
    * Helper method.
    */
    protected static Object runAnonymously(Object oAction)
            throws java.security.PrivilegedActionException
        {
        // import java.security.PrivilegedAction;
        // import java.security.PrivilegedActionException;
        // import java.security.PrivilegedExceptionAction;
        
        if (oAction instanceof PrivilegedAction)
            {
            return ((PrivilegedAction) oAction).run();
            }
        else
            {
            try
                {
                return ((PrivilegedExceptionAction) oAction).run();
                }
            catch (Exception e)
                {
                throw new PrivilegedActionException(e);
                }
            }
        }
    
    /**
    * @param oSubject  a Subject object (optional)
    * @param oAction  a PrivilegedAction or PrivilegedExceptionAction object
    * 
    * @see com.tangosol.net.security.Security
    */
    public static Object runAs(Object oSubject, Object oAction)
            throws java.security.PrivilegedActionException
        {
        Security security = getInstance();
        return security == null ?
            runAnonymously(oAction) : security.runSecure(oSubject, oAction);
        }
    
    /**
    * Subclassing support.
    */
    protected Object runSecure(Object oSubject, Object oAction)
            throws java.security.PrivilegedActionException
        {
        return null;
        }
    
    // Accessor for the property "Configured"
    /**
    * Setter for property Configured.<p>
    * Is security already configured?
    */
    protected static void setConfigured(boolean fConfig)
        {
        __s_Configured = fConfig;
        }
    
    // Accessor for the property "Instance"
    /**
    * Setter for property Instance.<p>
    * The Security instance.
    */
    protected static void setInstance(Security security)
        {
        __s_Instance = security;
        }
    
    // Accessor for the property "SubjectSecure"
    /**
    * Setter for property SubjectSecure.<p>
    * Subject object assosiated with the current thread.
    */
    protected void setSubjectSecure(Object subject)
        {
        __m_SubjectSecure = subject;
        }
    
    /**
    * Callback API used  to verify that the joining service member has passed
    * the authentication step. Called on a cluster service thread.
    * 
    * @param service  the ClusterService
    */
    public void verifySecureContext(com.tangosol.net.Service service, String sServiceName, Member memberFrom)
        {
        }
    }
