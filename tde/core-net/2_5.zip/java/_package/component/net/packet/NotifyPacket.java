/* Class
*     _package.component.net.packet.NotifyPacket
*/

package _package.component.net.packet;

public abstract class NotifyPacket
        extends    _package.component.net.Packet
    {
    // Fields declarations
    
    /**
    * Property MessageId
    *
    * The Message Id that specifies the Packet being acknowledged or requested.
    * 
    * This indexed property is in the range 0..NotifyCount-1.
    */
    private int[] __m_MessageId;
    
    /**
    * Property MessagePartIndex
    *
    * A 0-based index of the Message part that specifies the Packet being
    * requested or acknowledged; only non-zero to acknowledge a Sequel Packet.
    * Corresponds to MessageId property.
    * 
    * This indexed property is in the range 0..NotifyCount-1.
    */
    private int[] __m_MessagePartIndex;
    
    /**
    * Property NotifyCount
    *
    * The number of items in the MessageId and MessagePartIndex properties.
    * (The number of Packets being requested or acknowledged.)
    */
    private int __m_NotifyCount;
    
    /**
    * Property ScheduledMillis
    *
    * The time, in milliseconds, when this packet is scheduled to be sent.
    */
    private long __m_ScheduledMillis;
    
    // Initializing constructor
    public NotifyPacket(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/packet/NotifyPacket".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Add the passed Packet information to the notification Packet.
    * 
    * @param nMsgId  the Message id to add to this notification Packet
    * @param nMsgPart  the Message part number to add to this notification
    * Packet, or zero if n/a
    */
    public void addPacket(int nMsgId, int nMsgPart)
        {
        _assert(isOutgoing());
        
        int c = getNotifyCount();
        
        setMessageId       (c, nMsgId);
        setMessagePartIndex(c, nMsgPart);
        
        // if case any of the above causes OutOfMemory, this should be last
        // to prevent the ArrayIndexOutOfBounds during write
        setNotifyCount(c + 1);
        }
    
    /**
    * Add the passed Packet information to the notification Packet.
    * 
    * @param packet  the Packet whose information should be added to this
    * notification Packet
    */
    public void addPacket(MessagePacket packet)
        {
        addPacket(makeTrint(packet.getFromMessageId()),
                packet.getMessagePartIndex());
        }
    
    // Declared at the super level
    /**
    * Getter for property Description.<p>
    * Human-readable description of attributes added to the sub-class of
    * Packet; used by toString for debugging purposes.
    */
    public String getDescription()
        {
        StringBuffer sb = new StringBuffer();
        
        int c = getNotifyCount();
        sb.append("NotifyCount=")
          .append(c);
        
        if (c > 0)
            {
            sb.append(", MessageId:MessagePartIndex=[");
            for (int i = 0; i < c; ++i)
                {
                if (i > 0)
                    {
                    sb.append(", ");
                    }
                sb.append(getMessageId(i))
                  .append(':')
                  .append(getMessagePartIndex(i));
                }
            sb.append("]");
            }
        
        return sb.toString();
        }
    
    // Accessor for the property "MessageId"
    /**
    * Getter for property MessageId.<p>
    * The Message Id that specifies the Packet being acknowledged or requested.
    * 
    * This indexed property is in the range 0..NotifyCount-1.
    */
    protected int[] getMessageId()
        {
        return __m_MessageId;
        }
    
    // Accessor for the property "MessageId"
    /**
    * Getter for property MessageId.<p>
    * The Message Id that specifies the Packet being acknowledged or requested.
    * 
    * This indexed property is in the range 0..NotifyCount-1.
    */
    public int getMessageId(int i)
        {
        return getMessageId()[i];
        }
    
    // Accessor for the property "MessagePartIndex"
    /**
    * Getter for property MessagePartIndex.<p>
    * A 0-based index of the Message part that specifies the Packet being
    * requested or acknowledged; only non-zero to acknowledge a Sequel Packet.
    * Corresponds to MessageId property.
    * 
    * This indexed property is in the range 0..NotifyCount-1.
    */
    protected int[] getMessagePartIndex()
        {
        return __m_MessagePartIndex;
        }
    
    // Accessor for the property "MessagePartIndex"
    /**
    * Getter for property MessagePartIndex.<p>
    * A 0-based index of the Message part that specifies the Packet being
    * requested or acknowledged; only non-zero to acknowledge a Sequel Packet.
    * Corresponds to MessageId property.
    * 
    * This indexed property is in the range 0..NotifyCount-1.
    */
    public int getMessagePartIndex(int i)
        {
        return getMessagePartIndex()[i];
        }
    
    // Accessor for the property "NotifyCount"
    /**
    * Getter for property NotifyCount.<p>
    * The number of items in the MessageId and MessagePartIndex properties.
    * (The number of Packets being requested or acknowledged.)
    */
    public int getNotifyCount()
        {
        return __m_NotifyCount;
        }
    
    // Accessor for the property "ScheduledMillis"
    /**
    * Getter for property ScheduledMillis.<p>
    * The time, in milliseconds, when this packet is scheduled to be sent.
    */
    public long getScheduledMillis()
        {
        return __m_ScheduledMillis;
        }
    
    // Declared at the super level
    /**
    * Read the Packet (not counting the Packet type id) from a Stream.
    * 
    * Note: The read method is not responsible for configuring the "To" portion
    * of the packet.
    * 
    * @param stream  the DataInputStream to read from
    * @param nMemberId  this Member's id if known, otherwise zero
    */
    public void read(java.io.DataInputStream stream, int nMemberId)
            throws java.io.IOException
        {
        setToId  (stream.readUnsignedShort());
        setFromId(stream.readUnsignedShort());
        
        int c = stream.readUnsignedShort();
        setNotifyCount(c);
        
        // presize indexed props
        setMessageId       (new int[c]);
        setMessagePartIndex(new int[c]);
        
        for (int i = 0; i < c; ++i)
            {
            setMessageId       (i, readUnsignedTrint(stream));
            setMessagePartIndex(i, readUnsignedTrint(stream));
            }
        }
    
    // Accessor for the property "MessageId"
    /**
    * Setter for property MessageId.<p>
    * The Message Id that specifies the Packet being acknowledged or requested.
    * 
    * This indexed property is in the range 0..NotifyCount-1.
    */
    protected void setMessageId(int[] anMsgId)
        {
        __m_MessageId = anMsgId;
        }
    
    // Accessor for the property "MessageId"
    /**
    * Setter for property MessageId.<p>
    * The Message Id that specifies the Packet being acknowledged or requested.
    * 
    * This indexed property is in the range 0..NotifyCount-1.
    */
    protected void setMessageId(int i, int nMsgId)
        {
        int[] an = getMessageId();
        
        if (an == null || i >= an.length)
            {
            // resize, making the array bigger than necessary (avoid resizes)
            int   cNew  = Math.max(i + (i >>> 1), 16);
            int[] anNew = new int[cNew];
        
            // copy original data
            if (an != null)
                {
                System.arraycopy(an, 0, anNew, 0, an.length);
                }
        
            setMessageId(an = anNew);
            }
        
        an[i] = nMsgId;
        }
    
    // Accessor for the property "MessagePartIndex"
    /**
    * Setter for property MessagePartIndex.<p>
    * A 0-based index of the Message part that specifies the Packet being
    * requested or acknowledged; only non-zero to acknowledge a Sequel Packet.
    * Corresponds to MessageId property.
    * 
    * This indexed property is in the range 0..NotifyCount-1.
    */
    protected void setMessagePartIndex(int[] anMsgPart)
        {
        __m_MessagePartIndex = anMsgPart;
        }
    
    // Accessor for the property "MessagePartIndex"
    /**
    * Setter for property MessagePartIndex.<p>
    * A 0-based index of the Message part that specifies the Packet being
    * requested or acknowledged; only non-zero to acknowledge a Sequel Packet.
    * Corresponds to MessageId property.
    * 
    * This indexed property is in the range 0..NotifyCount-1.
    */
    protected void setMessagePartIndex(int i, int nMsgPart)
        {
        int[] an = getMessagePartIndex();
        
        if (an == null || i >= an.length)
            {
            // resize, making the array bigger than necessary (avoid resizes)
            int   cNew  = Math.max(i + (i >>> 1), 16);
            int[] anNew = new int[cNew];
        
            // copy original data
            if (an != null)
                {
                System.arraycopy(an, 0, anNew, 0, an.length);
                }
        
            setMessagePartIndex(an = anNew);
            }
        
        an[i] = nMsgPart;
        }
    
    // Accessor for the property "NotifyCount"
    /**
    * Setter for property NotifyCount.<p>
    * The number of items in the MessageId and MessagePartIndex properties.
    * (The number of Packets being requested or acknowledged.)
    */
    protected void setNotifyCount(int c)
        {
        __m_NotifyCount = c;
        }
    
    // Accessor for the property "ScheduledMillis"
    /**
    * Setter for property ScheduledMillis.<p>
    * The time, in milliseconds, when this packet is scheduled to be sent.
    */
    public void setScheduledMillis(long cMillis)
        {
        __m_ScheduledMillis = cMillis;
        }
    
    // Declared at the super level
    /**
    * Write the Packet to a Stream.
    * 
    * @param stream  the DataOutputStream to write to
    * @param nMemberId  if non-zero, it indicates that the Packet should be
    * addressed only to one member
    */
    public void write(java.io.DataOutputStream stream, _package.component.net.MemberSet setTo)
            throws java.io.IOException
        {
        stream.writeInt(getPacketType());
        stream.writeShort(getToId());
        stream.writeShort(getFromId());
        
        int   c         = getNotifyCount();
        int[] anMsgId   = getMessageId();
        int[] anMsgPart = getMessagePartIndex();
        
        stream.writeShort(c);
        for (int i = 0; i < c; ++i)
            {
            writeTrint(stream, anMsgId  [i]);
            writeTrint(stream, anMsgPart[i]);
            }
        }
    }
