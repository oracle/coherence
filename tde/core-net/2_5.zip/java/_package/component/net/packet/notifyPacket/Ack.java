/* Class
*     _package.component.net.packet.notifyPacket.Ack
*/

package _package.component.net.packet.notifyPacket;

public class Ack
        extends    _package.component.net.packet.NotifyPacket
    {
    // Fields declarations
    
    /**
    * Property LENGTH_FIXED
    *
    * Fixed size (in bytes) of the Ack header.
    */
    public static final int LENGTH_FIXED = 10;
    
    /**
    * Property LENGTH_VARIABLE
    *
    * Variable size (in bytes) of the Ack for each message ID and part that is
    * ack'd.
    */
    public static final int LENGTH_VARIABLE = 6;
    
    // Default constructor
    public Ack()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Ack(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setPacketType(232718545);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Ack();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/packet/notifyPacket/Ack".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    }
