/* Class
*     _package.component.net.packet.messagePacket.Directed
*/

package _package.component.net.packet.messagePacket;

import _package.component.net.Member;
import _package.component.net.MemberSet;
import _package.component.net.memberSet.DependentMemberSet;
import com.tangosol.util.Base;
import java.io.IOException;
import java.sql.Time;
import java.util.Iterator;

public class Directed
        extends    _package.component.net.packet.MessagePacket
    {
    // Fields declarations
    
    /**
    * Property DestimationMessageId
    *
    * Indexed by destination Member, returns the "to" Message Id.
    */
    
    /**
    * Property ToMessageId
    *
    * If ToId is used, this is the corresponding destination Message id.
    */
    private int __m_ToMessageId;
    
    // Default constructor
    public Directed()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Directed(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setPacketType(232718548);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant ConfirmationRequired
    public boolean isConfirmationRequired()
        {
        return true;
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Directed();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/packet/messagePacket/Directed".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Getter for property Description.<p>
    * Human-readable description of attributes added to the sub-class of
    * Packet; used by toString for debugging purposes.
    */
    public String getDescription()
        {
        // import Component.Net.Member;
        // import Component.Net.MemberSet.DependentMemberSet;
        // import com.tangosol.util.Base;
        // import java.sql.Time;
        // import java.util.Iterator;
        
        StringBuffer sb = new StringBuffer();
        
        sb.append("ToMemberSet=");
        DependentMemberSet setMember = getToMemberSet();
        if (setMember == null)
            {
            sb.append("null");
            }
        else
            {
            sb.append('[');
            boolean fFirst = true;
            for (Iterator iter = setMember.iterator(); iter.hasNext(); )
                {
                if (fFirst)
                    {
                    fFirst = false;
                    }
                else
                    {
                    sb.append(", ");
                    }
        
                Member member  = (Member) iter.next();
                int    nMember = member.getId();
                sb.append(nMember);
        
                int nToMsgId = setMember.getDestinationMessageId(nMember);
                if (nToMsgId != 0)
                    {
                    sb.append('(')
                      .append(nToMsgId)
                      .append(')');
                    }
                }
            sb.append(']');
            }
        
        sb.append(", ServiceId=")
          .append(getServiceId())
          .append(", MessageType=")
          .append(getMessageType())
          .append(", FromMessageId=")
          .append(getFromMessageId())
          .append(", ToMessageId=")
          .append(getToMessageId())
          .append(", MessagePartCount=")
          .append(getMessagePartCount())
          .append(", MessagePartIndex=")
          .append(getMessagePartIndex())
          .append(", ResendRequestInProgress=")
          .append(isResendRequestInProgress())
          .append(", ResendScheduled=")
          .append(getResendScheduled())
          .append(", ResendSkip=")
          .append(isResendSkip())
          .append(", Body=");
        
        byte[] ab = getBody();
        if (ab == null)
            {
            sb.append("null");
            }
        else
            {
            if (ab.length > 128)
                {
                sb.append(Base.toHexEscape(ab, 0, 128))
                  .append("...");
                }
            else
                {
                sb.append(Base.toHexEscape(ab));
                }
            sb.append(", Body.length=")
              .append(ab.length);
            }
        
        return sb.toString();

        }
    
    // Accessor for the property "DestimationMessageId"
    /**
    * Getter for property DestimationMessageId.<p>
    * Indexed by destination Member, returns the "to" Message Id.
    */
    public int getDestimationMessageId(int nMemberId)
        {
        // import Component.Net.MemberSet.DependentMemberSet;
        
        if (nMemberId == getToId())
            {
            return getToMessageId();
            }
        
        DependentMemberSet setMember = getToMemberSet();
        if (setMember != null)
            {
            return setMember.getDestinationMessageId(nMemberId);
            }
        
        return 0;
        }
    
    // Accessor for the property "ToMessageId"
    /**
    * Getter for property ToMessageId.<p>
    * If ToId is used, this is the corresponding destination Message id.
    */
    public int getToMessageId()
        {
        return __m_ToMessageId;
        }
    
    // Declared at the super level
    /**
    * Read the Packet (not counting the Packet type id) from a Stream.
    * 
    * Note: The read method is not responsible for configuring the "To" portion
    * of the packet.
    * 
    * @param stream  the DataInputStream to read from
    * @param nMemberId  this Member's id if known, otherwise zero
    */
    public void read(java.io.DataInputStream stream, int nMemberId)
            throws java.io.IOException
        {
        // import Component.Net.Member;
        // import Component.Net.MemberSet;
        // import java.io.IOException;
        
        // determine how many members are addressed in the Packet and
        // what position (the "nth") is the specified Member addressed
        // (Note: ToId is set by the Packet.instantiate method)
        int cMembers = 0;
        int iMember  = -1;
        switch (getPacketType())
            {
            case TYPE_DIRECTED_ONE:
                _assert(stream.readUnsignedShort() == nMemberId);
                cMembers = 1;
                iMember  = 0;
                break;
        
            case TYPE_DIRECTED_FEW:
                cMembers = stream.readUnsignedByte();
                for (int i = 0; i < cMembers; ++i)
                    {
                    if (stream.readUnsignedShort() == nMemberId)
                        {
                        iMember = i;
                        }
                    }
                break;
        
            case TYPE_DIRECTED_MANY:
                {
                // bits-count (1 byte)
                //    bits (4 bytes) --> note: implies member-count
                // member-count (2 bytes)
                //    ...
                int cBitSets = stream.readUnsignedByte();
        
                // calculate which set number) and bit mask identifies
                // the specified Member id
                int nTheSet  = Member.calcByteOffset(nMemberId);
                int nTheMask = Member.calcByteMask(nMemberId);
        
                // all bits less significant than the one bit in "the mask"
                int nPartial = nTheMask >>> 1;
                for (int i = 1, iShift = 1; i <= 5; ++i, iShift <<= 1)
                    {
                    nPartial |= nPartial >>> iShift;
                    }
        
                // count all members (cMembers) and determine the number
                // of members in the bit-set before the specified member
                // (iMember)
                for (int i = 0; i < cBitSets; ++i)
                    {
                    int nBits = stream.readInt();
                    if (i == nTheSet)
                        {
                        _assert((nBits & nTheMask) != 0);
                        iMember = cMembers + MemberSet.countBits(nBits & nPartial);
                        }
                    cMembers += MemberSet.countBits(nBits);
                    }
        
                // skip the number of "to" Members (it's only there
                // to allow rapid scanning through the stream)
                _assert(cMembers == stream.readUnsignedShort());
                }
                break;
        
            default:
                throw new IOException("unknown packet type: " + getPacketType());
            }
        _assert(cMembers > 0 && iMember >= 0 && iMember < cMembers);
        
        // skip up to the "to message id"
        int cbSkip = iMember * 3;
        if (cbSkip > 0)
            {
            _assert(stream.skip(cbSkip) == cbSkip);
            }
        
        // read the "to message id"
        setToMessageId(readUnsignedTrint(stream));
        
        // skip the rest of the "to message ids"
        cbSkip = (cMembers - iMember - 1) * 3;
        if (cbSkip > 0)
            {
            _assert(stream.skip(cbSkip) == cbSkip);
            }
        
        setFromId(stream.readUnsignedShort());
        setFromMessageId(readUnsignedTrint(stream));
        setMessagePartCount(readUnsignedTrint(stream));
        setServiceId(stream.readUnsignedShort());
        setMessageType(stream.readShort());
        readBody(stream);

        }
    
    // Declared at the super level
    public int selectType(_package.component.net.MemberSet memberSet)
        {
        // decide on the best format to use to write the directed packet
        int cMembers = memberSet.size();
        switch (cMembers)
            {
            case 0:
                throw new IllegalArgumentException("no members in set!");
        
            case 1:
                return TYPE_DIRECTED_ONE;
        
            case 2:
            case 3:
                // as small or smaller for 2-3 Members to send a "few" Packet
                return TYPE_DIRECTED_FEW;
        
            default:
                {
                if (cMembers > 255)
                    {
                    // "few" Packets only support up to 255 Members
                    return TYPE_DIRECTED_MANY;
                    }
        
                // calculate the optimum packing for the specified number
                // of Members
                int cbFew  = 19 + 5 * cMembers;
                int cbMany = 21 + 3 * cMembers + 4 * (memberSet.getLastId() / 32 + 1);
                return cbFew <= cbMany ? TYPE_DIRECTED_FEW : TYPE_DIRECTED_MANY;
                }
            }
        }
    
    // Accessor for the property "ToMessageId"
    /**
    * Setter for property ToMessageId.<p>
    * If ToId is used, this is the corresponding destination Message id.
    */
    public void setToMessageId(int nId)
        {
        __m_ToMessageId = nId;
        }
    
    // Declared at the super level
    /**
    * Write the Packet to a Stream.
    * 
    * @param stream  the DataOutputStream to write to
    * @param nMemberId  if non-zero, it indicates that the Packet should be
    * addressed only to one member
    */
    public void write(java.io.DataOutputStream stream, _package.component.net.MemberSet setTo)
            throws java.io.IOException
        {
        // import java.io.IOException;
        // import Component.Net.MemberSet.DependentMemberSet;
        
        int nType = selectType(setTo);
        setPacketType(nType);
        stream.writeInt(nType);
        
        DependentMemberSet setMember = getToMemberSet();
        switch (nType)
            {
            case TYPE_DIRECTED_ONE:
                setTo.writeOne(stream);
                if (setMember == null)
                    {
                    writeTrint(stream, getToMessageId());
                    }
                else
                    {
                    setMember.writeOneToMessageId(stream, setTo);
                    }
                break;
        
            case TYPE_DIRECTED_FEW:
                setTo.writeFew(stream);
                setMember.writeFewToMessageId(stream, setTo);
                break;
        
            case TYPE_DIRECTED_MANY:
                setTo.writeMany(stream);
                setMember.writeManyToMessageId(stream, setTo);
                break;
        
            default:
                throw new IOException("unknown packet type: " + nType);
            }
        
        stream.writeShort(getFromId());
        writeTrint(stream, getFromMessageId());
        writeTrint(stream, getMessagePartCount());
        stream.writeShort(getServiceId());
        stream.writeShort(getMessageType());
        writeBody(stream);
        }
    }
