/* Class
*     _package.component.net.packet.messagePacket.Sequel
*/

package _package.component.net.packet.messagePacket;

import _package.component.net.Member;
import _package.component.net.memberSet.DependentMemberSet;
import com.tangosol.util.Base;
import java.io.IOException;
import java.sql.Time;
import java.util.Iterator;

public class Sequel
        extends    _package.component.net.packet.MessagePacket
    {
    // Fields declarations
    
    // Default constructor
    public Sequel()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Sequel(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setPacketType(232718552);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant ConfirmationRequired
    public boolean isConfirmationRequired()
        {
        return true;
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Sequel();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/packet/messagePacket/Sequel".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Getter for property Description.<p>
    * Human-readable description of attributes added to the sub-class of
    * Packet; used by toString for debugging purposes.
    */
    public String getDescription()
        {
        // import Component.Net.Member;
        // import Component.Net.MemberSet.DependentMemberSet;
        // import com.tangosol.util.Base;
        // import java.sql.Time;
        // import java.util.Iterator;
        
        StringBuffer sb = new StringBuffer();
        
        sb.append("ToMemberSet=");
        DependentMemberSet setMember = getToMemberSet();
        if (setMember == null)
            {
            sb.append("null");
            }
        else
            {
            sb.append('[');
            boolean fFirst = true;
            for (Iterator iter = setMember.iterator(); iter.hasNext(); )
                {
                if (fFirst)
                    {
                    fFirst = false;
                    }
                else
                    {
                    sb.append(", ");
                    }
        
                Member member  = (Member) iter.next();
                int    nMember = member.getId();
                sb.append(nMember);
                }
            sb.append(']');
            }
        
        sb.append(", ServiceId=")
          .append(getServiceId())
          .append(", MessageType=")
          .append(getMessageType())
          .append(", FromMessageId=")
          .append(getFromMessageId())
          .append(", MessagePartCount=")
          .append(getMessagePartCount())
          .append(", MessagePartIndex=")
          .append(getMessagePartIndex())
          .append(", ResendRequestInProgress=")
          .append(isResendRequestInProgress())
          .append(", ResendScheduled=")
          .append(getResendScheduled())
          .append(", ResendSkip=")
          .append(isResendSkip())
          .append(", Body=");
        
        byte[] ab = getBody();
        if (ab == null)
            {
            sb.append("null");
            }
        else
            {
            if (ab.length > 40)
                {
                sb.append(Base.toHexEscape(ab, 0, 40))
                  .append("...");
                }
            else
                {
                sb.append(Base.toHexEscape(ab));
                }
        
            sb.append(", Body.length=")
              .append(ab.length);
            }
        
        return sb.toString();
        }
    
    // Declared at the super level
    /**
    * Read the Packet (not counting the Packet type id) from a Stream.
    * 
    * Note: The read method is not responsible for configuring the "To" portion
    * of the packet.
    * 
    * @param stream  the DataInputStream to read from
    * @param nMemberId  this Member's id if known, otherwise zero
    */
    public void read(java.io.DataInputStream stream, int nMemberId)
            throws java.io.IOException
        {
        // import java.io.IOException;
        
        // skip "to" stuff -- the Packet is supposed to be for this Member
        // (ToId is set by the Packet.instantiate method)
        switch (getPacketType())
            {
            case TYPE_SEQUEL_ONE:
                stream.readUnsignedShort();
                break;
        
            case TYPE_SEQUEL_FEW:
                stream.skip(stream.readUnsignedByte() << 1);
                break;
        
            case TYPE_SEQUEL_MANY:
                stream.skip(stream.readUnsignedByte() << 2);
                break;
        
            default:
                throw new IOException("unknown packet type: " + getPacketType());
            }
        
        setFromId(stream.readUnsignedShort());
        setFromMessageId(readUnsignedTrint(stream));
        setMessagePartIndex(readUnsignedTrint(stream));
        readBody(stream);

        }
    
    // Declared at the super level
    public int selectType(_package.component.net.MemberSet memberSet)
        {
        // decide on the best format to use to write the Sequel Packet
        int cMembers = memberSet.size();
        switch (cMembers)
            {
            case 0:
                throw new IllegalArgumentException("no members in set!");
        
            case 1:
                return TYPE_SEQUEL_ONE;
        
            case 2:
                // as small for 2 Members to send a "few" Packet
                return TYPE_SEQUEL_FEW;
        
            default:
                {
                if (cMembers > 255)
                    {
                    // "few" Packets only support up to 255 Members
                    return TYPE_SEQUEL_MANY;
                    }
        
                // calculate the optimum packing for the specified number
                // of Members
                int cbFew  = 15 + 2 * cMembers;
                int cbMany = 15 + 4 * (memberSet.getLastId() / 32 + 1);
                return cbFew <= cbMany ? TYPE_SEQUEL_FEW : TYPE_SEQUEL_MANY;
                }
            }

        }
    
    // Declared at the super level
    /**
    * Write the Packet to a Stream.
    * 
    * @param stream  the DataOutputStream to write to
    * @param nMemberId  if non-zero, it indicates that the Packet should be
    * addressed only to one member
    */
    public void write(java.io.DataOutputStream stream, _package.component.net.MemberSet setTo)
            throws java.io.IOException
        {
        // import java.io.IOException;
        
        int nType = selectType(setTo);
        setPacketType(nType);
        stream.writeInt(nType);
        
        switch (nType)
            {
            case TYPE_SEQUEL_ONE:
                setTo.writeOne(stream);
                break;
        
            case TYPE_SEQUEL_FEW:
                setTo.writeFew(stream);
                break;
        
            case TYPE_SEQUEL_MANY:
                setTo.writeMany(stream);
                break;
        
            default:
                throw new IOException("unknown packet type: " + nType);
            }
        
        stream.writeShort(getFromId());
        writeTrint(stream, getFromMessageId());
        writeTrint(stream, getMessagePartIndex());
        writeBody(stream);

        }
    }
