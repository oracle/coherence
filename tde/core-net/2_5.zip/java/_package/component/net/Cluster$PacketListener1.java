/* Class
*     _package.component.net.Cluster$PacketListener1
*/

package _package.component.net;

import _package.component.net.member.ClusterMember;

public class Cluster$PacketListener1
        extends    _package.component.util.daemon.queueProcessor.packetProcessor.PacketListener
    {
    // Fields declarations
    
    /**
    * Property IgnoreReceiveExceptions
    *
    * If true, receive exceptions are ignored. If false, receive exceptions are
    * logged against the member that the packet was being sent to (best guess)
    * and if that member gets too many logged against it in a row, it's removed
    * from the cluster.
    */
    private boolean __m_IgnoreReceiveExceptions;
    
    /**
    * Property MaxReceiveExceptions
    *
    * The maximum number of socket exceptions during receive calls when sending
    * to a particular member before that member is known to be dead.
    */
    private int __m_MaxReceiveExceptions;
    
    // Default constructor
    public Cluster$PacketListener1()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Cluster$PacketListener1(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setIgnoreReceiveExceptions(false);
            setMaxReceiveExceptions(4);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new Cluster$PacketListener1$Queue("Queue", this, true), "Queue");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Cluster$PacketListener1();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/Cluster$PacketListener1".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Accessor for the property "MaxReceiveExceptions"
    /**
    * Getter for property MaxReceiveExceptions.<p>
    * The maximum number of socket exceptions during receive calls when sending
    * to a particular member before that member is known to be dead.
    */
    public int getMaxReceiveExceptions()
        {
        return __m_MaxReceiveExceptions;
        }
    
    // Accessor for the property "IgnoreReceiveExceptions"
    /**
    * Getter for property IgnoreReceiveExceptions.<p>
    * If true, receive exceptions are ignored. If false, receive exceptions are
    * logged against the member that the packet was being sent to (best guess)
    * and if that member gets too many logged against it in a row, it's removed
    * from the cluster.
    */
    public boolean isIgnoreReceiveExceptions()
        {
        return __m_IgnoreReceiveExceptions;
        }
    
    // Declared at the super level
    /**
    * This event occurs when an exception is thrown from onEnter, onWait,
    * onNotify and onExit.
    * 
    * If the exception should terminate the daemon, call stop(). The default
    * implementation prints debugging information and terminates the daemon.
    * 
    * @param e  the Throwable object (a RuntimeException or an Error)
    * 
    * @throws RuntimeException may be thrown; will terminate the daemon
    * @throws Error may be thrown; will terminate the daemon
    */
    protected void onException(Throwable e)
        {
        Cluster cluster = ($Module) get_Module();
        int     nState  = cluster.getState();
        
        if (nState < Cluster.STATE_RUNNING)
            {
            cluster.setStartException(e);
            }
        
        super.onException(e);
        
        if (nState < Cluster.STATE_STOPPING)
            {
            _trace(get_Name() + ": stopping cluster.", 1);
            cluster.stop();
            }
        }
    
    // Declared at the super level
    public void onReceiveException(Exception e)
        {
        // import Component.Net.Member.ClusterMember;
        
        if (!isIgnoreReceiveExceptions())
            {
            Cluster       cluster = ($Module) get_Module();
            ClusterMember member  = (ClusterMember)
                     cluster.getPublisher().getDatagramRecipient();
        
            if (member != null && getMemberSet().contains(member))
                {
                member.addSendFailure();
                if (member.getSendFailureCount() >= getMaxReceiveExceptions())
                    {
                    _trace("Number of socket exceptions exceeded maximum" +
                           "; last cause: " + e + 
                           "; removing the member: " + member, 4);
                    cluster.getClusterService().doMemberLeft(member);
                    }
                }
            }
        
        super.onReceiveException(e);
        }
    
    // Accessor for the property "IgnoreReceiveExceptions"
    /**
    * Setter for property IgnoreReceiveExceptions.<p>
    * If true, receive exceptions are ignored. If false, receive exceptions are
    * logged against the member that the packet was being sent to (best guess)
    * and if that member gets too many logged against it in a row, it's removed
    * from the cluster.
    */
    public void setIgnoreReceiveExceptions(boolean pIgnoreReceiveExceptions)
        {
        __m_IgnoreReceiveExceptions = pIgnoreReceiveExceptions;
        }
    
    // Accessor for the property "MaxReceiveExceptions"
    /**
    * Setter for property MaxReceiveExceptions.<p>
    * The maximum number of socket exceptions during receive calls when sending
    * to a particular member before that member is known to be dead.
    */
    public void setMaxReceiveExceptions(int pMaxReceiveExceptions)
        {
        __m_MaxReceiveExceptions = pMaxReceiveExceptions;
        }
    
    // Declared at the super level
    /**
    * Setter for property StatsCpu.<p>
    * Statistics: total time spent processing packets.
    */
    public void setStatsCpu(long cMillis)
        {
        super.setStatsCpu(cMillis);
        }
    }
