/* Class
*     _package.component.net.MemberSet$Iterator
*/

package _package.component.net;

public class MemberSet$Iterator
        extends    _package.component.util.Iterator
    {
    // Fields declarations
    
    // Default constructor
    public MemberSet$Iterator()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public MemberSet$Iterator(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new MemberSet$Iterator();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/MemberSet$Iterator".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        setItem((($Module) get_Module()).toArray());
        
        super.onInit();
        }
    
    // Declared at the super level
    /**
    * Removes from the underlying collection the last element returned by the
    * iterator (optional operation).  This method can be called only once per
    * call to <tt>next</tt>.  The behavior of an iterator is unspecified if the
    * underlying collection is modified while the iteration is in progress in
    * any way other than by calling this method.
    * 
    * @exception UnsupportedOperationException if the <tt>remove</tt> operation
    * is not supported by this Iterator
    * @exception IllegalStateException if the <tt>next</tt> method has not yet
    * been called, or the <tt>remove</tt> method has already been called after
    * the last call to the <tt>next</tt> method
    */
    public void remove()
        {
        if (isCanRemove())
            {
            setCanRemove(false);
            (($Module) get_Module()).remove((Member) getItem(getNextIndex()-1));
            }
        else
            {
            throw new IllegalStateException();
            }

        }
    }
