/* Class
*     _package.component.net.Cluster$PacketListenerN
*/

package _package.component.net;

public class Cluster$PacketListenerN
        extends    _package.component.util.daemon.queueProcessor.packetProcessor.PacketListener
    {
    // Fields declarations
    
    // Default constructor
    public Cluster$PacketListenerN()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Cluster$PacketListenerN(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        _addChild(new Cluster$PacketListenerN$Queue("Queue", this, true), "Queue");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Cluster$PacketListenerN();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/Cluster$PacketListenerN".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    /**
    * This event occurs when an exception is thrown from onEnter, onWait,
    * onNotify and onExit.
    * 
    * If the exception should terminate the daemon, call stop(). The default
    * implementation prints debugging information and terminates the daemon.
    * 
    * @param e  the Throwable object (a RuntimeException or an Error)
    * 
    * @throws RuntimeException may be thrown; will terminate the daemon
    * @throws Error may be thrown; will terminate the daemon
    */
    protected void onException(Throwable e)
        {
        Cluster cluster = ($Module) get_Module();
        int     nState  = cluster.getState();
        
        if (nState < Cluster.STATE_RUNNING)
            {
            cluster.setStartException(e);
            }
        
        super.onException(e);
        
        if (nState < Cluster.STATE_STOPPING)
            {
            _trace(get_Name() + ": stopping cluster.", 1);
            cluster.stop();
            }
        }
    
    // Declared at the super level
    /**
    * Setter for property StatsCpu.<p>
    * Statistics: total time spent processing packets.
    */
    public void setStatsCpu(long cMillis)
        {
        super.setStatsCpu(cMillis);
        }
    }
