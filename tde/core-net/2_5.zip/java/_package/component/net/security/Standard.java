/* Class
*     _package.component.net.security.Standard
*/

package _package.component.net.security;

import _package.component.net.Cluster;
import _package.component.net.Member;
import _package.component.net.MemberSet;
import _package.component.net.ServiceInfo;
import _package.component.net.memberSet.DependentMemberSet;
import _package.component.util.daemon.queueProcessor.Service;
import _package.component.util.daemon.queueProcessor.service.ClusterService;
import com.tangosol.net.ClusterPermission;
import com.tangosol.net.ClusterPermission; // as Permission
import com.tangosol.net.security.AccessController; // as Controller
import com.tangosol.run.xml.XmlElement;
import com.tangosol.run.xml.XmlHelper;
import com.tangosol.util.Base;
import com.tangosol.util.ClassHelper;
import java.security.AccessControlContext;
import java.security.AccessControlException;
import java.security.AccessController;
import java.security.DomainCombiner;
import java.security.GeneralSecurityException;
import java.security.Principal;
import java.security.PrivilegedAction;
import java.security.PrivilegedExceptionAction;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import javax.security.auth.AuthPermission;
import javax.security.auth.Subject;
import javax.security.auth.SubjectDomainCombiner;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginContext;

/**
* 
* The Security.Standard component is dependent on JAAS framework, which is
* currently a part of J2SE 1.4
*/
public class Standard
        extends    _package.component.net.Security
    {
    // Fields declarations
    
    /**
    * Property AccessController
    *
    * (Private) The AccessController
    */
    private transient com.tangosol.net.security.AccessController __m_AccessController;
    
    /**
    * Property CallbackHandler
    *
    * The default CallbackHandler
    */
    private transient javax.security.auth.callback.CallbackHandler __m_CallbackHandler;
    
    /**
    * Property ModuleName
    *
    * The login module name
    */
    private transient String __m_ModuleName;
    
    /**
    * Property ServiceContext
    *
    * (Private) A map of Service related Subject objects keyed by the service
    * name. Used by the client threads.
    */
    private transient java.util.Map __m_ServiceContext;
    
    /**
    * Property ServiceMemberContext
    *
    * (Private) A map of MemberSet objects keyed by the service name. Each set
    * contains ONLY the members that have already sent and passed the secure
    * request. Used by the cluster service thread.
    */
    private transient java.util.Map __m_ServiceMemberContext;
    
    /**
    * Property ThreadContext
    *
    * (Private) ThreadLocal holding the Subject. Used by the client threads.
    */
    private transient ThreadLocal __m_ThreadContext;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("PermissionInfo", Standard$PermissionInfo.get_CLASS());
        __mapChildren.put("RefAction", _package.component.net.Security$RefAction.get_CLASS());
        }
    
    // Default constructor
    public Standard()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Standard(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        
        // state initialization: private properties
        try
            {
            __m_ServiceContext = new com.tangosol.util.SafeHashMap();
            __m_ServiceMemberContext = new com.tangosol.util.SafeHashMap();
            __m_ThreadContext = new java.lang.ThreadLocal();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Standard();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/security/Standard".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Declared at the super level
    /**
    * Security API exposed to the all Service components. Called on a client
    * thread.
    */
    public void checkPermission(com.tangosol.net.Cluster cluster, com.tangosol.net.ClusterPermission permission)
        {
        // import Component.Net.Cluster;
        // import Component.Net.Member;
        // import Component.Net.ServiceInfo;
        // import Component.Util.Daemon.QueueProcessor.Service;
        // import Component.Util.Daemon.QueueProcessor.Service.ClusterService;
        // import com.tangosol.net.ClusterPermission;
        // import com.tangosol.net.security.AccessController as Controller;
        // import com.tangosol.util.Base;
        // import java.security.AccessControlException;
        // import java.security.GeneralSecurityException;
        // import javax.security.auth.Subject;
        
        Controller controller = getAccessController();
        Subject    subject    = (Subject) getThreadContext().get();
        if (subject == null)
            {
            // the call was made in an old-fashioned way (without using "runAs")
            subject = getTempSubject();
            }
        
        String sService = permission.getServiceName();
        _assert(sService != null);
        
        validateSubject(sService, subject);
        
        // TODO: leave the audit trail?
        // _trace("checkPermission: " + permission, 3);
        
        // local check
        controller.checkPermission(permission, subject);
        
        if (cluster == null || !cluster.isRunning())
            {
            // strict check is not required or the cluster is not running yet
            return;
            }
        
        ClusterService clusterservice = ((Cluster) cluster).getClusterService();
        Service        service        = clusterservice.getService(sService);
        if (service != null && service.isRunning())
            {
            // we must have already proved the trustworthiness
            return;
            }
        
        ServiceInfo info = clusterservice.getServiceInfo(sService);
        if (info == null)
            {
            // this is a new service, this node is going to become a senior
            return;
            }
        
        // prepare and send the request to the senior service member
        Object oResponse;
        do
            {
            Member memberSenior = (Member) info.getOldestMember();
            if (memberSenior == null)
                {
                // no senior, this node is going to become one
                return;
                }
        
            // the reponse will be null only if the senior fails to respond
            oResponse = clusterservice.pollSecure(
                memberSenior, encryptPermissionInfo(permission, subject));
            }
        while (oResponse == null);
        
        if (oResponse instanceof Throwable)
            {
            throw Base.ensureRuntimeException((Throwable) oResponse);
            }
        
        $PermissionInfo   responseInfo       = ($PermissionInfo) oResponse;
        ClusterPermission permissionResponse = responseInfo.getPermission();
        if (permissionResponse == null)
            {
            // response came from another node
            try
                {
                permissionResponse = (ClusterPermission) controller.decrypt(
                    responseInfo.getSignedPermission(), responseInfo.getSubject(), subject);
                }
            catch (GeneralSecurityException e)
                {
                throw new AccessControlException(
                    "Security configuration mismatch or break-in attempt", permission);
                }
            catch (Exception e) // ClassNotFoundException, IOException
                {
                throw Base.ensureRuntimeException(e, "Security configuration mismatch");
                }
            }
        
        if (!Base.equals(permission, permissionResponse))
            {
            // should not happen; this is rather an assersion
            throw new AccessControlException(
                "Permission mismatch or break-in attempt", permission);
            }
        }
    
    // Declared at the super level
    protected void configure(com.tangosol.run.xml.XmlElement xmlConfig)
        {
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.run.xml.XmlHelper;
        // import com.tangosol.net.security.AccessController;
        // import javax.security.auth.callback.CallbackHandler;
        
        super.configure(xmlConfig);
        
        if (xmlConfig != null)
            {
            boolean fEnabled = xmlConfig.getSafeElement("enabled").getBoolean();
            if (fEnabled)
                {
                String     sModule = xmlConfig.getSafeElement("login-module-name").getString("Coherence");
                XmlElement xmlAC   = xmlConfig.getSafeElement("access-controller");
                XmlElement xmlCH   = xmlConfig.getSafeElement("callback-handler");
                        
                CallbackHandler  handler    = (CallbackHandler)  newInstance(xmlCH);
                AccessController controller = (AccessController) newInstance(xmlAC);
                if (controller == null)
                    {
                    throw new RuntimeException(
                        "The 'access-controller' configuration element must be specified");
                    }
        
                setAccessController(controller);
                setCallbackHandler(handler);
                setModuleName(sModule);
                }
            }
        }
    
    protected Standard$PermissionInfo encryptPermissionInfo(com.tangosol.net.ClusterPermission permission, javax.security.auth.Subject subject)
        {
        // import com.tangosol.util.Base;
        
        $PermissionInfo info = new $PermissionInfo();
        
        try
            {
            info.setPermission(permission);
            info.setServiceName(permission.getServiceName());
            info.setSignedPermission(getAccessController().encrypt(permission, subject));
            info.setSubject(subject);
        
            return info;
            }
        catch (Exception e) // GeneralSecurityException, IOException
            {
            throw new SecurityException("Invalid subject credentials: " + e);
            // throw Base.ensureRuntimeException(e);
            }
        }
    
    // Accessor for the property "AccessController"
    /**
    * Getter for property AccessController.<p>
    * (Private) The AccessController
    */
    public com.tangosol.net.security.AccessController getAccessController()
        {
        return __m_AccessController;
        }
    
    // Accessor for the property "CallbackHandler"
    /**
    * Getter for property CallbackHandler.<p>
    * The default CallbackHandler
    */
    protected javax.security.auth.callback.CallbackHandler getCallbackHandler()
        {
        return __m_CallbackHandler;
        }
    
    // Accessor for the property "ModuleName"
    /**
    * Getter for property ModuleName.<p>
    * The login module name
    */
    public String getModuleName()
        {
        return __m_ModuleName;
        }
    
    // Accessor for the property "ServiceContext"
    /**
    * Getter for property ServiceContext.<p>
    * (Private) A map of Service related Subject objects keyed by the service
    * name. Used by the client threads.
    */
    private java.util.Map getServiceContext()
        {
        return __m_ServiceContext;
        }
    
    // Accessor for the property "ServiceMemberContext"
    /**
    * Getter for property ServiceMemberContext.<p>
    * (Private) A map of MemberSet objects keyed by the service name. Each set
    * contains ONLY the members that have already sent and passed the secure
    * request. Used by the cluster service thread.
    */
    private java.util.Map getServiceMemberContext()
        {
        return __m_ServiceMemberContext;
        }
    
    // Declared at the super level
    /**
    * Getter for property SubjectSecure.<p>
    * Subject object assosiated with the current thread.
    */
    protected Object getSubjectSecure()
        {
        // import javax.security.auth.AuthPermission;
        // import javax.security.auth.Subject;
        
        SecurityManager manager = System.getSecurityManager();
        if (manager != null)
            {
            manager.checkPermission(
                new AuthPermission("coherence.getSubject"));
            }
        
        // Note: Subject iteslef protects private credentials by
        //   javax.security.auth.PrivateCredentialPermission
        return (Subject) getThreadContext().get();
        }
    
    /**
    * Obtain the Subject object by alternative means.
    */
    protected javax.security.auth.Subject getTempSubject()
        {
        // import javax.security.auth.Subject;
        // import java.security.AccessControlContext;
        // import java.security.AccessController;
        // import java.security.DomainCombiner;
        // import javax.security.auth.SubjectDomainCombiner;
        // import javax.security.auth.callback.CallbackHandler;
        
        CallbackHandler handler = getCallbackHandler();
        if (handler != null)
            {
            return (Subject) loginSecure(handler);
            }
        
        // no default handler to fall back onto;
        // as a last resource assume the caller was using "subject.runAs()" construct
        SecurityManager manager = System.getSecurityManager();
        Object oContext = manager == null ?
            AccessController.getContext() : manager.getSecurityContext();
        
        if (oContext instanceof AccessControlContext)
            {
            DomainCombiner dc = ((AccessControlContext) oContext).getDomainCombiner();
            if (dc instanceof SubjectDomainCombiner)
                {
                return ((SubjectDomainCombiner) dc).getSubject();
                }
            }
        
        throw new SecurityException(
            "Attempt to access a protected resource was made without credentials and " +
            "the default 'callback-handler' was not configured");
        }
    
    // Accessor for the property "ThreadContext"
    /**
    * Getter for property ThreadContext.<p>
    * (Private) ThreadLocal holding the Subject. Used by the client threads.
    */
    private ThreadLocal getThreadContext()
        {
        return __m_ThreadContext;
        }
    
    // Declared at the super level
    /**
    * Security debugging helper. Not used for anything else!
    */
    public Object impersonate(Object oSubject, String sNameOld, String sNameNew)
        {
        // import com.tangosol.util.Base;
        // import com.tangosol.util.ClassHelper;
        // import java.security.Principal;
        // import javax.security.auth.Subject;
        // import java.util.HashSet;
        // import java.util.Iterator;
        // import java.util.Set;
        
        Subject subject    = (Subject) oSubject;
        Subject subjectNew = new Subject();
        
        for (Iterator iter = subject.getPrincipals().iterator(); iter.hasNext();)
            {
            Principal p = (Principal) iter.next();
        
            String sName = p.getName();
            if (sName.indexOf(sNameOld) >= 0)
                {
                try
                    {
                    sName = Base.replace(sName, sNameOld, sNameNew);
                    p = (Principal) ClassHelper.newInstance(p.getClass(),
                        new Object[] {sName});
                    _trace("Successfully impersonated " + p + "@" + p.getClass());
                    }
                catch (Exception e)
                    {
                    _trace("Cannot impersonate " + p + "@" + p.getClass());
                    }
                }
            subjectNew.getPrincipals().add(p);
            }
        subjectNew.getPublicCredentials().addAll(subject.getPublicCredentials());
        subjectNew.getPrivateCredentials().addAll(subject.getPrivateCredentials());
        
        return subjectNew;
        }
    
    // Declared at the super level
    /**
    * Subclassing support.
    */
    public Object loginSecure(Object oHandler)
        {
        // import com.tangosol.util.Base;
        // import javax.security.auth.AuthPermission;
        // import javax.security.auth.Subject;
        // import javax.security.auth.callback.CallbackHandler;
        // import javax.security.auth.login.LoginContext;
        
        SecurityManager manager = System.getSecurityManager();
        if (manager != null)
            {
            manager.checkPermission(
                new AuthPermission("coherence.login"));
            }
        
        CallbackHandler handler = (CallbackHandler) oHandler;
        LoginContext lc;
        try
            {
            lc = new LoginContext(getModuleName(), handler);
            }
        catch (Exception e)
            {
            throw Base.ensureRuntimeException(e, "Failed to create LoginContext");
            }
        
        try
            {
            lc.login();
            Subject subject = lc.getSubject();
        
            // make immutable from now on
            subject.setReadOnly();
            return subject;
            }
        catch (Exception e)
            {
            throw new SecurityException("Authentication failed");
            }
        }
    
    /**
    * Instantiate an object described by the XML descriptor.
    */
    protected static Object newInstance(com.tangosol.run.xml.XmlElement xmlConfig)
        {
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.run.xml.XmlHelper;
        // import com.tangosol.util.ClassHelper;
        // import com.tangosol.util.Base;
        
        String sClass = xmlConfig.getSafeElement("class-name").getString();
        if (sClass.length() > 0)
            {
            XmlElement xmlParams = xmlConfig.getSafeElement("init-params");
            Object[]   aoParam   = XmlHelper.parseInitParams(xmlParams);
            try
                {
                return ClassHelper.newInstance(Class.forName(sClass), aoParam);
                }
            catch (Exception e)
                {
                throw Base.ensureRuntimeException(e);
                }
            }
        else
            {
            return null;
            }
        }
    
    // Declared at the super level
    /**
    * Callback API used to validate and respond to a security related request.
    * Called on a cluster service thread.
    * 
    * @param service  the ClusterService
    */
    public Object processSecureRequest(com.tangosol.net.Service service, _package.component.net.Member memberFrom, Object oRequestInfo)
        {
        // import Component.Net.Member;
        // import Component.Net.MemberSet;
        // import Component.Net.MemberSet.DependentMemberSet;
        // import Component.Net.ServiceInfo;
        // import Component.Util.Daemon.QueueProcessor.Service.ClusterService;
        // import com.tangosol.net.ClusterPermission as Permission;
        // import com.tangosol.net.security.AccessController as Controller;
        // import com.tangosol.util.Base;
        // import javax.security.auth.Subject;
        
        ClusterService clusterservice = (ClusterService) service;
        _assert(Thread.currentThread() == clusterservice.getThread());
        
        Controller      controller  = getAccessController();
        $PermissionInfo infoRequest = ($PermissionInfo) oRequestInfo;
        
        String      sService    = infoRequest.getServiceName();
        ServiceInfo infoService = clusterservice.getServiceInfo(sService);
        Member      memberThis  = clusterservice.getThisMember();
        if (infoService == null || infoService.getOldestMember() != memberThis)
            {
            // force the caller to retry
            return null;
            }
        
        Subject    subjRequestor = infoRequest.getSubject();
        Subject    subjCurrent;
        Permission permission;
        try
            {
            subjCurrent = (Subject) getServiceContext().get(sService);
            if (subjCurrent == null)
                {
                return new RuntimeException("No service context");
                }
        
            if (memberFrom.equals(memberThis))
                {
                // no need to decrypt since there was no serialization
                permission = infoRequest.getPermission();
                }
            else
                {
                permission = (Permission) controller.decrypt(
                    infoRequest.getSignedPermission(), subjRequestor, subjCurrent);
                }
        
            _trace("Remote permission request: " + permission + " by " + memberFrom, 5);
        
            controller.checkPermission(permission, subjRequestor);
            }
        catch (Exception e)
            {
            // let the caller re-throw it
            return Base.ensureRuntimeException(e, "Remote permission check failed");
            }
        
        // register the successful secure request
        DependentMemberSet setMembers = (DependentMemberSet) getServiceMemberContext().get(sService);
        if (setMembers == null)
            {
            setMembers = new DependentMemberSet();
            setMembers.setBaseSet(infoService.getMemberSet());
            getServiceMemberContext().put(sService, setMembers);
            }
        else
            {
            setMembers.sync();
            }
        setMembers.add(memberFrom);
        
        try
            {
            return encryptPermissionInfo(permission, subjCurrent);
            }
        catch (Exception e)
            {
            return Base.ensureRuntimeException(e, "Remote encryption failed");
            }
        }
    
    // Declared at the super level
    /**
    * Security API used by the Service components. Called on a service thread
    * upon the service termination.
    * 
    * @param sServiceName  the relevant Service name
    */
    public void releaseSecureContext(String sServiceName)
        {
        getServiceContext().remove(sServiceName);
        }
    
    // Declared at the super level
    /**
    * Helper method.
    */
    public static Object runAnonymously(Object oAction)
            throws java.security.PrivilegedActionException
        {
        return _package.component.net.Security.runAnonymously(oAction);
        }
    
    // Declared at the super level
    /**
    * Subclassing support.
    */
    protected Object runSecure(Object oSubject, Object oAction)
            throws java.security.PrivilegedActionException
        {
        // import java.security.PrivilegedAction;
        // import java.security.PrivilegedExceptionAction;
        // import javax.security.auth.AuthPermission;
        // import javax.security.auth.Subject;
        // import javax.security.auth.callback.CallbackHandler;
        
        SecurityManager manager = System.getSecurityManager();
        if (manager != null)
            {
            manager.checkPermission(
                new AuthPermission("coherence.runAs"));
            }
        
        Subject subject = (Subject) oSubject;
        
        // _trace("runSecure " + oAction + "\n as " + subject.getPrincipals(), 3);
        if (subject == null)
            {
            return runAnonymously(oAction);
            }
        
        getThreadContext().set(subject);
        try
            {
            return oAction instanceof PrivilegedAction ?
                Subject.doAs(subject, (PrivilegedAction) oAction) :
                Subject.doAs(subject, (PrivilegedExceptionAction) oAction);
            }
        finally
            {
            getThreadContext().set(null);
            }
        }
    
    // Accessor for the property "AccessController"
    /**
    * Setter for property AccessController.<p>
    * (Private) The AccessController
    */
    protected void setAccessController(com.tangosol.net.security.AccessController controller)
        {
        __m_AccessController = controller;
        }
    
    // Accessor for the property "CallbackHandler"
    /**
    * Setter for property CallbackHandler.<p>
    * The default CallbackHandler
    */
    protected void setCallbackHandler(javax.security.auth.callback.CallbackHandler handler)
        {
        __m_CallbackHandler = handler;
        }
    
    // Accessor for the property "ModuleName"
    /**
    * Setter for property ModuleName.<p>
    * The login module name
    */
    protected void setModuleName(String sName)
        {
        __m_ModuleName = sName;
        }
    
    // Accessor for the property "ServiceContext"
    /**
    * Setter for property ServiceContext.<p>
    * (Private) A map of Service related Subject objects keyed by the service
    * name. Used by the client threads.
    */
    private void setServiceContext(java.util.Map mapCtx)
        {
        __m_ServiceContext = mapCtx;
        }
    
    // Accessor for the property "ServiceMemberContext"
    /**
    * Setter for property ServiceMemberContext.<p>
    * (Private) A map of MemberSet objects keyed by the service name. Each set
    * contains ONLY the members that have already sent and passed the secure
    * request. Used by the cluster service thread.
    */
    private void setServiceMemberContext(java.util.Map map)
        {
        __m_ServiceMemberContext = map;
        }
    
    // Declared at the super level
    /**
    * Setter for property SubjectSecure.<p>
    * Subject object assosiated with the current thread.
    */
    protected void setSubjectSecure(Object subject)
        {
        // import javax.security.auth.AuthPermission;
        // import javax.security.auth.Subject;
        
        SecurityManager manager = System.getSecurityManager();
        if (manager != null)
            {
            manager.checkPermission(
                new AuthPermission("coherence.setSubject"));
            }
        
        // Note: Subject iteslef protects private credentials by
        //   javax.security.auth.PrivateCredentialPermission
        getThreadContext().set(subject);
        }
    
    // Accessor for the property "ThreadContext"
    /**
    * Setter for property ThreadContext.<p>
    * (Private) ThreadLocal holding the Subject. Used by the client threads.
    */
    private void setThreadContext(ThreadLocal ctx)
        {
        __m_ThreadContext = ctx;
        }
    
    /**
    * Prevent a security hole when a caller would construct a Subject object
    * with a Principal object that have a high security clearance, but provide
    * a valid cerificate representing a low security clearance Principal. The
    * very first validated subject becomes assosiated with the specified
    * service.
    */
    protected void validateSubject(String sService, javax.security.auth.Subject subject)
        {
        // import com.tangosol.net.security.AccessController as Controller;
        // import java.util.Map;
        // import java.util.Random;
        // import javax.security.auth.Subject;
        
        Map     mapContext  = getServiceContext();
        Subject subjCurrent = (Subject) mapContext.get(sService);
        
        if (subject != subjCurrent)
            {
            Controller controller = getAccessController();
            Object     oTest      = new Double(Math.random());
            try
                {
                Object o = controller.decrypt(
                    controller.encrypt(oTest, subject), subject, null);
                _assert(o.equals(oTest));
                }
            catch (Exception e)
                {
                throw new SecurityException("Failed to verify the subject; reason=" + e);
                }
            }
        
        if (subjCurrent == null)
            {
            mapContext.put(sService, subject);
            }
        }
    
    // Declared at the super level
    /**
    * Callback API used  to verify that the joining service member has passed
    * the authentication step. Called on a cluster service thread.
    * 
    * @param service  the ClusterService
    */
    public void verifySecureContext(com.tangosol.net.Service service, String sServiceName, _package.component.net.Member memberFrom)
        {
        // import Component.Net.Member;
        // import Component.Net.MemberSet;
        // import Component.Util.Daemon.QueueProcessor.Service.ClusterService;
        
        ClusterService clusterservice = (ClusterService) service;
        _assert(Thread.currentThread() == clusterservice.getThread());
        
        // a secure request had to be registered for "join" to proceed
        boolean   fSuccess   = false;
        MemberSet setMembers = (MemberSet) getServiceMemberContext().get(sServiceName);
        if (setMembers != null)
            {
            fSuccess = setMembers.remove(memberFrom);
            if (setMembers.isEmpty())
                {
                getServiceMemberContext().remove(sServiceName);
                }
            }
        
        if (!fSuccess)
            {
            String sMsg = "Security configuration mismatch or break-in attempt";
            _trace(sMsg, 1);
            throw new SecurityException(sMsg);
            }
        }
    }
