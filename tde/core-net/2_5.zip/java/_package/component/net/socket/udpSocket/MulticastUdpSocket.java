/* Class
*     _package.component.net.socket.udpSocket.MulticastUdpSocket
*/

package _package.component.net.socket.udpSocket;

import com.tangosol.net.InetAddressHelper;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class MulticastUdpSocket
        extends    _package.component.net.socket.UdpSocket
    {
    // Fields declarations
    
    /**
    * Property InterfaceInetAddress
    *
    * @see java.net.MulticastSocket#setInterface
    */
    private java.net.InetAddress __m_InterfaceInetAddress;
    
    /**
    * Property TimeToLive
    *
    * @see java.net.MulticastSocket#setTimeToLive
    */
    private int __m_TimeToLive;
    
    // Default constructor
    public MulticastUdpSocket()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public MulticastUdpSocket(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setBufferReceived(16);
            setBufferSent(8);
            setPacketLength(0);
            setPortAutoSelect(false);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new MulticastUdpSocket();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/socket/udpSocket/MulticastUdpSocket".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Getter for property Description.<p>
    * Human readable socekt description.
    */
    public String getDescription()
        {
        StringBuffer sb = new StringBuffer(super.getDescription());
        
        sb.append(", InterfaceAddress=")
          .append(toString(getInterfaceInetAddress()))
          .append(", TimeToLive=")
          .append(getTimeToLive());
        
        return sb.toString();
        }
    
    // Accessor for the property "InterfaceInetAddress"
    /**
    * Getter for property InterfaceInetAddress.<p>
    * @see java.net.MulticastSocket#setInterface
    */
    public java.net.InetAddress getInterfaceInetAddress()
        {
        return __m_InterfaceInetAddress;
        }
    
    // Accessor for the property "TimeToLive"
    /**
    * Getter for property TimeToLive.<p>
    * @see java.net.MulticastSocket#setTimeToLive
    */
    public int getTimeToLive()
        {
        return __m_TimeToLive;
        }
    
    // Declared at the super level
    /**
    * Instantiate an underlying java.net.DatagramSocket.
    */
    protected java.net.DatagramSocket instantiateDatagramSocket()
            throws java.io.IOException
        {
        // import com.tangosol.net.InetAddressHelper;
        // import java.net.InetAddress;
        // import java.net.MulticastSocket;
        
        InetAddress addr          = getInetAddress();
        InetAddress addrInterface = getInterfaceInetAddress();
        int         nPort         = getPort();
        
        // create the multicast socket
        MulticastSocket socket;
        if (nPort == 65536)
            {
            // for extremely rare customer's request:
            // automatic port assignment
            socket = new MulticastSocket();
            setPort(socket.getLocalPort());
            }
        else
            {
            socket = new MulticastSocket(nPort);
            }
        
        // for rare customer's request:
        // address "0.0.0.0" serves as is INADDR_ANY which allows the OS
        // to use the unicast routing table to select the interface
        // Note: calling socket.setInterface("0.0.0.0") appears
        // to have the same effect as not calling it at all
        if (addrInterface != null &&
                !InetAddressHelper.isAnyLocalAddress(addrInterface))
            {
            socket.setInterface(addrInterface);
            }
        socket.setTimeToLive(getTimeToLive());
        socket.joinGroup(addr);
        
        return socket;
        }
    
    // Declared at the super level
    /**
    * Setter for property InetAddress.<p>
    * The IP address that the socket uses if it is a socket that connects to an
    * IP address. This property must be configured before the socket is opened.
    */
    public void setInetAddress(java.net.InetAddress addr)
        {
        // import java.net.InetAddress;
        
        if (addr == null || !addr.isMulticastAddress())
            {
            throw new IllegalArgumentException(
                "MulticastUdpSocket.InetAddress is not in the multicast range: " + toString(addr));
            }
        
        super.setInetAddress(addr);
        }
    
    // Accessor for the property "InterfaceInetAddress"
    /**
    * Setter for property InterfaceInetAddress.<p>
    * @see java.net.MulticastSocket#setInterface
    */
    public void setInterfaceInetAddress(java.net.InetAddress addr)
        {
        // import java.net.InetAddress;
        
        if (addr != null && addr.isMulticastAddress())
            {
            throw new IllegalArgumentException(
                "MulticastUdpSocket.InterfaceInetAddress is in the multicast range: " + toString(addr));
            }
        
        synchronized (getLock())
            {
            _assert(getState() != STATE_OPEN,
                "InterfaceInetAddress cannot be modified once the socket is open");
        
            __m_InterfaceInetAddress = (addr);
            }
        }
    
    // Accessor for the property "TimeToLive"
    /**
    * Setter for property TimeToLive.<p>
    * @see java.net.MulticastSocket#setTimeToLive
    */
    public void setTimeToLive(int ttl)
        {
        if (ttl < 0 || ttl > 255)
            {
            throw new IllegalArgumentException(
                "MulticastUdpSocket.TimeToLive is out of range (0..255): " + ttl);
            }
        
        synchronized (getLock())
            {
            _assert(getState() != STATE_OPEN,
                "TimeToLive cannot be modified once the socket is open");
        
            __m_TimeToLive = (ttl);
            }
        }
    }
