/* Class
*     _package.component.net.socket.TcpSocketAccepter
*/

package _package.component.net.socket;

import com.tangosol.util.WrapperException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.BindException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

public class TcpSocketAccepter
        extends    _package.component.net.Socket
    {
    // Fields declarations
    
    /**
    * Property Backlog
    *
    * Specifies the maximum queue length for incoming connection indications (a
    * request to connect). If a connection indication arrives when the queue is
    * full, the connection is refused. 
    * 
    */
    private int __m_Backlog;
    
    /**
    * Property ServerSocket
    *
    */
    private java.net.ServerSocket __m_ServerSocket;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("TcpSocket", TcpSocketAccepter$TcpSocket.get_CLASS());
        }
    
    // Default constructor
    public TcpSocketAccepter()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public TcpSocketAccepter(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setBacklog(32);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new TcpSocketAccepter();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/socket/TcpSocketAccepter".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    /**
    * Wait for incoming request to create a (point-to-point) TcpSocket.
    * 
    * @return the new TcpSocket; null if timeout occured.
    */
    public TcpSocket accept()
        {
        // import java.io.InterruptedIOException;
        // import java.io.IOException;
        // import java.net.ServerSocket;
        // import java.net.Socket;
        
        while (true)
            {
            long        lCurrent = System.currentTimeMillis();
            IOException eIO      = null;
        
            try
                {
                ServerSocket socketSrv = getServerSocket();
                if (socketSrv != null)
                    {
                    Socket     socket    = socketSrv.accept();
                    $TcpSocket socketTcp = ($TcpSocket) _newChild("TcpSocket");
        
                    socketTcp.setSocket(socket);
                    return socketTcp;
                    }
                }
            catch (InterruptedIOException e)
                {
                onInterruptedIOException(e, lCurrent);
                return null;
                }
            catch (IOException e)
                {
                eIO = e;
                }
        
            synchronized (getLock())
                {
                switch (getState())
                    {
                    case STATE_OPEN:
                        // re-open the socket or take other action
                        onAcceptException(eIO, lCurrent);
                        break;
                    default:
                        throw new IllegalStateException("TcpSocketAccepter.accept: " +
                            "Exception " + eIO + "; State= " + formatStateName(getState()));
                    }
                }
            }
        }
    
    // Declared at the super level
    public void close()
        {
        // import java.net.ServerSocket;
        
        synchronized (getLock())
            {
            if (getState() != STATE_CLOSED)
                {
                ServerSocket socket = getServerSocket();
                if (socket != null)
                    {
                    try
                        {
                        socket.close();
                        }
                    catch (Exception e)
                        {
                        // ignore exception on close; assume the socket is
                        // closed since there is nothing else that can be
                        // done to close it
                        }
                    setServerSocket(null);
                    }
        
                setState(STATE_CLOSED);
                }
            }
        }
    
    // Accessor for the property "Backlog"
    /**
    * Getter for property Backlog.<p>
    * Specifies the maximum queue length for incoming connection indications (a
    * request to connect). If a connection indication arrives when the queue is
    * full, the connection is refused. 
    * 
    */
    public int getBacklog()
        {
        return __m_Backlog;
        }
    
    // Declared at the super level
    /**
    * Getter for property Description.<p>
    * Human readable socekt description.
    */
    public String getDescription()
        {
        // import java.net.ServerSocket;
        
        if (getState() == STATE_OPEN)
            {
            ServerSocket socket = getServerSocket();
            return "ServerSocket=" +
                toString(socket.getInetAddress()) + ':' + socket.getLocalPort();
            }
        else
            {
            return super.getDescription();
            }
        }
    
    // Accessor for the property "ServerSocket"
    /**
    * Getter for property ServerSocket.<p>
    */
    public java.net.ServerSocket getServerSocket()
        {
        return __m_ServerSocket;
        }
    
    protected java.net.ServerSocket instantiateServerSocket()
            throws java.io.IOException
        {
        // import java.net.BindException;
        // import java.net.InetAddress;
        // import java.net.ServerSocket;
        
        InetAddress addr   = getInetAddress();
        int         nPort  = getPort();
        int         cItems = getBacklog();
        
        _assert(addr != null, "TcpSocketAccepter.open: "
            + "InetAddress is required");
        _assert(nPort > 0 && nPort <= 65535, "TcpSocketAccepter.open: "
            + "Port out of range (" + nPort + ")");
        _assert(cItems > 0 && cItems <= 65535, "TcpSocketAccepter.open: "
            + "Backlog out of range (" + cItems + ")");
        
        int cAttempts = (isPortAutoSelect() && getState() == STATE_INITIAL) ? 256 : 1;
        int nPortOrig = nPort;
        
        while (true)
            {
            try
                {
                ServerSocket socket = new ServerSocket(nPort, cItems, addr);
                if (nPort != nPortOrig)
                    {
                    setPort(nPort);
                    }
                return socket;
                }
            catch (BindException e)
                {
                if (--cAttempts == 0)
                    {
                    throw e;
                    }
                nPort++;
                }
            }
        }
    
    /**
    * 
    * @param eException  the causal exception
    * @param lSocketActionMillis  the time that the exception occurred (or the
    * enclosing operation began or was in progress)
    */
    protected void onAcceptException(java.io.IOException eException, long lSocketActionMillis)
        {
        onException(eException, lSocketActionMillis);
        }
    
    // Declared at the super level
    public void open()
            throws java.io.IOException
        {
        // import com.tangosol.util.WrapperException;
        // import java.net.ServerSocket;
        // import java.net.SocketException;
        
        synchronized (getLock())
            {
            if (getState() != STATE_OPEN)
                {
                ServerSocket socket = instantiateServerSocket();
                try
                    {
                    try
                        {
                        int cMillis = getSoTimeout();
                        _assert(cMillis >= 0, "TcpSocketAccepter.open: "
                            + "ReceiveTimeout property must be greater than or equal to zero");
        
                        socket.setSoTimeout(cMillis);
                        validateSoTimeout(socket.getSoTimeout(), cMillis);
                        }
                    catch (SocketException e)
                        {
                        throw new WrapperException(e);
                        }
        
                    setServerSocket(socket);
                    setLastOpenMillis(System.currentTimeMillis());
                    }
                catch (RuntimeException e)
                    {
                    try
                        {
                        socket.close();
                        }
                    catch (Exception eIgnore) {}
                    setServerSocket(null);
                    throw e;
                    }
        
                setState(STATE_OPEN);
                }
            }
        }
    
    // Accessor for the property "Backlog"
    /**
    * Setter for property Backlog.<p>
    * Specifies the maximum queue length for incoming connection indications (a
    * request to connect). If a connection indication arrives when the queue is
    * full, the connection is refused. 
    * 
    */
    public void setBacklog(int cItems)
        {
        synchronized (getLock())
            {
            _assert(getState() == STATE_INITIAL,
                "Backlog cannot be modified once the socket has been opened");
        
            __m_Backlog = (cItems);
            }
        }
    
    // Accessor for the property "ServerSocket"
    /**
    * Setter for property ServerSocket.<p>
    */
    protected void setServerSocket(java.net.ServerSocket socket)
        {
        __m_ServerSocket = socket;
        }
    
    // Declared at the super level
    /**
    * Setter for property SoTimeout.<p>
    * Enable/disable SO_TIMEOUT with the specified timeout, in milliseconds.
    * With this value set to a non-zero timeout, a call to read(), receive() or
    * accept() for TcpSocket,  UdpSocket or TcpSecketAccepter will block for
    * only this amount of time. If the timeout expires, an 
    * java.io.InterruptedIOException is raised and onInterruptedIOException
    * event is called, though the Socket is still valid. The option must be
    * enabled prior to entering the blocking operation to have effect. The
    * timeout value must be > 0. A timeout of zero is interpreted as an
    * infinite timeout.
    */
    public void setSoTimeout(int cMillis)
        {
        // import com.tangosol.util.WrapperException;
        // import java.io.IOException;
        // import java.net.ServerSocket;
        
        synchronized (getLock())
            {
            _assert(cMillis >= 0);
        
            if (getState() == STATE_OPEN)
                {
                ServerSocket socket = getServerSocket();
                try
                    {
                    socket.setSoTimeout(cMillis);
                    validateSoTimeout(socket.getSoTimeout(), cMillis);
                    }
                catch (IOException e)
                    {
                    throw new WrapperException(e);
                    }
                }
        
            super.setSoTimeout(cMillis);
            }
        }
    }
