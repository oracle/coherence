/* Class
*     _package.component.net.message.requestMessage.DistributedCacheKeyRequest$Poll
*/

package _package.component.net.message.requestMessage;

import _package.component.net.message.DistributedCacheResponse; // as Response
import _package.component.util.daemon.queueProcessor.service.DistributedCache; // as Service
import com.tangosol.util.Base;
import com.tangosol.util.Binary;

public class DistributedCacheKeyRequest$Poll
        extends    _package.component.net.Poll
    {
    // Fields declarations
    
    // Default constructor
    public DistributedCacheKeyRequest$Poll()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public DistributedCacheKeyRequest$Poll(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new DistributedCacheKeyRequest$Poll();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/message/requestMessage/DistributedCacheKeyRequest$Poll".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    /**
    * This is the event that is executed when all the Members that were polled
    * have responded or have left the Service.
    */
    protected void onCompletion()
        {
        // import Component.Util.Daemon.QueueProcessor.Service.DistributedCache as Service;
        // import Component.Net.Message.DistributedCacheResponse as Response;
        // import com.tangosol.util.Binary;
        
        Service service    = (Service) getService();
        $Module msgRequest = ($Module) get_Parent();
        
        if (service.getServiceState() == Service.SERVICE_STOPPED)
            {
            setResult($Module.RESPONSE_UNKNOWN);
            }
        else
            {
            if (!msgRequest.isPrimary())
                {
                Response msgResponse = msgRequest.getPrimaryResponse();
                if (msgResponse != null)
                    {
                    if (getResult() == $Module.RESPONSE_UNKNOWN)
                        {
                        // the request was sent after this primary owner assigned
                        // the backup ownership but before the recepient
                        // had been notified about that ownership transfer
                        Binary binKey = msgRequest.getKey();
        
                        _trace("Resending " + msgRequest.get_Name() +
                               " due to backup ownership change: " +
                               service.reportBucketOwnership(service.getKeyBucket(binKey)), 4);
        
                        $Module msg = ($Module) msgRequest.cloneMessage();
                        msg.setToMemberSet(service.getBackupOwners(binKey));
        
                        service.send(msg);
                        }
                    else 
                        {
                        // the backup (not primary) request must never fail (RESULT_FAILURE);
                        // if any responder is dead (result is null) the data will be preserved
                        // by the standard distribution process
                        service.send(msgResponse);
                        }
                    }
                }
        
            if (!getLeftMemberSet().isEmpty())
                {
                // [at least one] responder is dead
                setResult($Module.RESPONSE_UNKNOWN);
                }
            }
        
        super.onCompletion();
        }
    
    // Declared at the super level
    /**
    * This event occurs for each response Message from each polled Member.
    */
    public void onResponse(_package.component.net.Message msg)
        {
        // import Component.Net.Message.DistributedCacheResponse as Response;
        // import com.tangosol.util.Base;
        
        Response response = (Response) msg;
        switch (response.getResult())
            {
            case Response.RESULT_SUCCESS:
                setResult(response.getValue());
                break;
        
            case Response.RESULT_RETRY:
                setResult($Module.RESPONSE_UNKNOWN);
                close();
                return;
        
            case Response.RESULT_FAILURE:
                {
                Object oResponse = response.getValue();
                if (oResponse instanceof Exception)
                    {
                    setResult(Base.ensureRuntimeException((Exception) oResponse));
                    }
                else
                    {
                    String sMsg = (String) oResponse;
                    setResult(new RuntimeException(sMsg));
                    }
                break;
                }
        
            default:
                throw new IllegalStateException();
            }
        
        super.onResponse(msg);

        }
    }
