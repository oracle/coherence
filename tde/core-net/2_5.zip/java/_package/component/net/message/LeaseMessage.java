/* Class
*     _package.component.net.message.LeaseMessage
*/

package _package.component.net.message;

import _package.component.net.Lease;
import _package.component.net.Member;
import _package.component.util.daemon.queueProcessor.Service;
import com.tangosol.run.component.EventDeathException;
import com.tangosol.util.Binary;
import com.tangosol.util.ExternalizableHelper;
import java.io.IOException;

/**
* LeaseMessage is the base component for Lease related messages used by
* ReplicatedCache service.
* 
* Attributes:
*     Lease
*/
public class LeaseMessage
        extends    _package.component.net.Message
    {
    // Fields declarations
    
    /**
    * Property Lease
    *
    * Reference to a Lease object that this message carries an information
    * about. This object is always just a copy of an actual Lease.
    */
    private transient _package.component.net.Lease __m_Lease;
    
    // Default constructor
    public LeaseMessage()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public LeaseMessage(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new LeaseMessage();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/message/LeaseMessage".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Getter for property Description.<p>
    * Used for debugging purposes (from toString). Create a human-readable
    * description of the specific Message data.
    */
    public String getDescription()
        {
        // import Component.Net.Lease;
        
        Lease lease = getLease();
        return lease == null ? "Lease: null" : lease.toString();
        }
    
    // Accessor for the property "Lease"
    /**
    * Getter for property Lease.<p>
    * Reference to a Lease object that this message carries an information
    * about. This object is always just a copy of an actual Lease.
    */
    public _package.component.net.Lease getLease()
        {
        return __m_Lease;
        }
    
    // Declared at the super level
    /**
    * This is the event that is executed when a Message is received.
    * <p>
    * It is the main processing event of the Message called by the
    * <code>Service.onMessage()</code> event. With regards to the use of
    * Message components within clustered Services, Services are designed by
    * dragging Message components into them as static children. These Messages
    * are the components that a Service can send to other running instances of
    * the same Service within a cluster. When the onReceived event is invoked
    * by a Service, it means that the Message has been received; the code in
    * the onReceived event is therefore the Message specific logic for
    * processing a received Message. For example, when onReceived is invoked on
    * a Message named FindData, the onReceived event should do the work to
    * "find the data", because it is being invoked by the Service that received
    * the "find the data" Message.
    */
    public void onReceived()
        {
        // import Component.Net.Member;
        // import Component.Util.Daemon.QueueProcessor.Service;
        // import com.tangosol.run.component.EventDeathException;
        
        super.onReceived();
        
        Member memberFrom = getFromMember();
        if (memberFrom == null ||
            getService().getServiceState() >= Service.SERVICE_STOPPING)
            {
            // the sender is gone or the service is stopping
            throw new EventDeathException();
            }

        }
    
    // Declared at the super level
    public void read(java.io.DataInputStream stream)
            throws java.io.IOException
        {
        // import Component.Net.Lease;
        // import com.tangosol.util.ExternalizableHelper;
        // import java.io.IOException;
        
        super.read(stream);
        
        int    iCache = ExternalizableHelper.readInt(stream);
        Object oKey;
        try
            {
            oKey = readObject(stream, getService().getContextClassLoader());
            }
        catch (IOException e)
            {
            _trace("Failed to deserialize a key for cache " +
                   Lease.formatCacheName(iCache, getService()), 1);
            throw e;
            }
        
        Lease lease = Lease.instantiate(iCache, oKey, getService());
        
        lease.read(stream);
        
        setLease(lease);
        }
    
    // Accessor for the property "Lease"
    /**
    * Setter for property Lease.<p>
    * Reference to a Lease object that this message carries an information
    * about. This object is always just a copy of an actual Lease.
    */
    public void setLease(_package.component.net.Lease lease)
        {
        // import Component.Net.Lease;
        
        // clone original lease, so this lease doesn't change
        
        __m_Lease = ((Lease) lease.clone());
        }
    
    // Declared at the super level
    public void write(java.io.DataOutputStream stream)
            throws java.io.IOException
        {
        // import Component.Net.Lease;
        // import com.tangosol.util.ExternalizableHelper;
        
        super.write(stream);
        
        Lease lease = getLease();
        _assert(lease != null);
        
        ExternalizableHelper.writeInt(stream, lease.getCacheIndex());
        writeObject(stream, lease.getResourceKey());
        
        lease.write(stream);
        }
    
    // Declared at the super level
    /**
    * Optimization method that writes the specified object to the specified
    * stream.
    * 
    * @param stream the stream to serialize the object into
    * @param o  the object to serialize
    * 
    * @see #readObject
    * Write the specified object to the specified stream.
    * 
    * @param stream the stream to serialize the object into
    * @param o  the object to serialize
    */
    public static void writeObject(java.io.DataOutputStream stream, Object o)
            throws java.io.IOException
        {
        // import com.tangosol.util.Binary;
        
        if (o instanceof Binary)
            {
            // write the Binary object's bytes, since it carries the serialized object
            Binary binValue = (Binary) o;
            binValue.writeTo(stream);
            }
        else
            {
            _package.component.net.Message.writeObject(stream, o);
            }
        }
    }
