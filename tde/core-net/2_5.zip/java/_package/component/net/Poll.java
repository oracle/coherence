/* Class
*     _package.component.net.Poll
*/

package _package.component.net;

import _package.component.net.MemberSet;
import _package.component.net.memberSet.EmptyMemberSet;
import _package.component.net.memberSet.SingleMemberSet;
import _package.component.util.daemon.queueProcessor.Service;
import com.tangosol.util.Base;

/**
* The Poll contains information regarding a request sent to one or more Cluster
* Members that require responses. A Service may poll other Members that are
* running the same Service, and the Poll is used to wait for and assemble the
* responses from each of those Members. A client thread may also use the Poll
* to block on a response or set of responses, thus waiting for the completion
* of the Poll. In its simplest form, which is a Poll that is sent to one Member
* of the Cluster, the Poll actually represents the request/response model.
*/
public class Poll
        extends    _package.component.Net
    {
    // Fields declarations
    
    /**
    * Property Closed
    *
    */
    private boolean __m_Closed;
    
    /**
    * Property Description
    *
    * Used for debugging purposes (from toString). Create a human-readable
    * description of the specific Message data.
    */
    
    /**
    * Property LeftMemberSet
    *
    * The Set of Members that left the cluster while the poll was open.
    */
    private MemberSet __m_LeftMemberSet;
    
    /**
    * Property PollId
    *
    * The Poll number assigned to this Poll by the Service.
    */
    private long __m_PollId;
    
    /**
    * Property RemainingMemberSet
    *
    * The Set of Members that have not yet responded to the poll and that are
    * still running the Service.
    */
    private MemberSet __m_RemainingMemberSet;
    
    /**
    * Property RespondedMemberSet
    *
    * The Set of Members that have responded to the poll request.
    */
    private MemberSet __m_RespondedMemberSet;
    
    /**
    * Property Result
    *
    * The result of the Poll. This property is used to collect the result of
    * the Poll and return it to the client thread that sent the original
    * RequestMessage.
    */
    private Object __m_Result;
    
    /**
    * Property Service
    *
    * The Service object that is managing the poll.
    */
    private _package.component.util.daemon.queueProcessor.Service __m_Service;
    
    // Default constructor
    public Poll()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Poll(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Poll();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/Poll".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Closes the poll, whether all Members have responded or not. The client of
    * the poll (or subclasses of the poll itself) can determine the results by
    * examining the Members that responded, left the service, or did neither by
    * the time the poll closed.
    * 
    * @see #LeftMemberSet
    * @see #RemainingMemberSet
    * @see #RespondedMemberSet
    */
    public synchronized void close()
        {
        // import Component.Util.Daemon.QueueProcessor.Service;
        
        if (!isClosed())
            {
            setClosed(true);
        
            Service svc = getService();
            if (svc != null)
                {
                svc.onPollClosed(this);
                }
        
            onCompletion();
            }
        }
    
    public void configureFrom(_package.component.net.message.RequestMessage msg)
        {
        // import Component.Net.MemberSet;
        // import Component.Net.MemberSet.SingleMemberSet;
        // import Component.Net.MemberSet.EmptyMemberSet;
        
        // build remaining set of Members to poll
        MemberSet setMsg = msg.getToMemberSet();
        MemberSet setPoll;
        switch (setMsg.size())
            {
            case 0:
                setPoll = (EmptyMemberSet) EmptyMemberSet.get_Instance();
                break;
        
            case 1:
                {
                MemberSet setMember = msg.getService().getServiceMemberSet();
                int       nId       = setMsg.getFirstId();
                Member    member    = setMember.getMember(nId);
                if (member == null)
                    {
                    setPoll = (EmptyMemberSet) EmptyMemberSet.get_Instance();
                    }
                else
                    {
                    setPoll = new SingleMemberSet();
                    setPoll.add(member);
                    }
                }
                break;
        
            default:
                setPoll = new MemberSet();
                setPoll.addAll(setMsg);
                break;
            }
        
        setRemainingMemberSet(setPoll);

        }
    
    // Accessor for the property "Description"
    /**
    * Getter for property Description.<p>
    * Used for debugging purposes (from toString). Create a human-readable
    * description of the specific Message data.
    */
    public String getDescription()
        {
        return null;
        }
    
    // Accessor for the property "LeftMemberSet"
    /**
    * Getter for property LeftMemberSet.<p>
    * The Set of Members that left the cluster while the poll was open.
    */
    public MemberSet getLeftMemberSet()
        {
        return __m_LeftMemberSet;
        }
    
    // Accessor for the property "PollId"
    /**
    * Getter for property PollId.<p>
    * The Poll number assigned to this Poll by the Service.
    */
    public long getPollId()
        {
        return __m_PollId;
        }
    
    // Accessor for the property "RemainingMemberSet"
    /**
    * Getter for property RemainingMemberSet.<p>
    * The Set of Members that have not yet responded to the poll and that are
    * still running the Service.
    */
    public MemberSet getRemainingMemberSet()
        {
        return __m_RemainingMemberSet;
        }
    
    // Accessor for the property "RespondedMemberSet"
    /**
    * Getter for property RespondedMemberSet.<p>
    * The Set of Members that have responded to the poll request.
    */
    public MemberSet getRespondedMemberSet()
        {
        return __m_RespondedMemberSet;
        }
    
    // Accessor for the property "Result"
    /**
    * Getter for property Result.<p>
    * The result of the Poll. This property is used to collect the result of
    * the Poll and return it to the client thread that sent the original
    * RequestMessage.
    */
    public Object getResult()
        {
        return __m_Result;
        }
    
    // Accessor for the property "Service"
    /**
    * Getter for property Service.<p>
    * The Service object that is managing the poll.
    */
    public _package.component.util.daemon.queueProcessor.Service getService()
        {
        return __m_Service;
        }
    
    // Accessor for the property "Closed"
    /**
    * Getter for property Closed.<p>
    */
    public boolean isClosed()
        {
        return __m_Closed;
        }
    
    /**
    * This is the event that is executed when all the Members that were polled
    * have responded or have left the Service.
    */
    protected synchronized void onCompletion()
        {
        notifyAll();
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import Component.Net.MemberSet.EmptyMemberSet;
        
        super.onInit();
        
        EmptyMemberSet setEmpty =
            (EmptyMemberSet) EmptyMemberSet.get_Instance();
        setRemainingMemberSet(setEmpty);
        setRespondedMemberSet(setEmpty);
        setLeftMemberSet(setEmpty);
        }
    
    /**
    * This event occurs when a Member has left the Service (or died) before
    * responding.
    */
    public synchronized void onLeft(Member member)
        {
        // import Component.Net.MemberSet;
        // import Component.Net.MemberSet.EmptyMemberSet;
        
        MemberSet setRemain = getRemainingMemberSet();
        MemberSet setLeft   = getLeftMemberSet();
        if (!isClosed() && setRemain.contains(member))
            {
            if (setRemain.size() == 1 && setLeft.isEmpty())
                {
                // most common case is a poll of one Member
                MemberSet setTemp = setLeft;
                setLeft   = setRemain;
                setRemain = setTemp;
        
                setLeftMemberSet(setLeft);
                setRemainingMemberSet(setRemain);
                }
            else
                {
                setRemain.remove(member);
                if (setLeft instanceof EmptyMemberSet)
                    {
                    setLeft = new MemberSet();
                    setLeftMemberSet(setLeft);
                    }
                setLeft.add(member);
                }
            
            if (setRemain.isEmpty())
                {
                close();
                }
            }
        }
    
    /**
    * This event occurs when a response from a Member is processed.
    */
    public synchronized void onResponded(Member member)
        {
        // import Component.Net.MemberSet;
        // import Component.Net.MemberSet.EmptyMemberSet;
        
        MemberSet setRemain    = getRemainingMemberSet();
        MemberSet setResponded = getRespondedMemberSet();
        
        if (!isClosed() && setRemain.contains(member))
            {
            if (setRemain.size() == 1 && setResponded.isEmpty())
                {
                // most common case is a poll of one Member
                MemberSet setTemp = setResponded;
                setResponded = setRemain;
                setRemain    = setTemp;
        
                setRespondedMemberSet(setResponded);
                setRemainingMemberSet(setRemain);
                }
            else
                {
                setRemain.remove(member);
                if (setResponded instanceof EmptyMemberSet)
                    {
                    setResponded = new MemberSet();
                    setRespondedMemberSet(setResponded);
                    }
                setResponded.add(member);
                }
        
            if (setRemain.isEmpty())
                {
                close();
                }
            }

        }
    
    /**
    * This event occurs for each response Message from each polled Member.
    */
    public void onResponse(Message msg)
        {
        if (!isClosed())
            {
            onResponded(msg.getFromMember());
            }
        }
    
    // Accessor for the property "Closed"
    /**
    * Setter for property Closed.<p>
    */
    private void setClosed(boolean fClosed)
        {
        __m_Closed = fClosed;
        }
    
    // Accessor for the property "LeftMemberSet"
    /**
    * Setter for property LeftMemberSet.<p>
    * The Set of Members that left the cluster while the poll was open.
    */
    protected void setLeftMemberSet(MemberSet setMember)
        {
        __m_LeftMemberSet = setMember;
        }
    
    // Accessor for the property "PollId"
    /**
    * Setter for property PollId.<p>
    * The Poll number assigned to this Poll by the Service.
    */
    public void setPollId(long lMsgId)
        {
        __m_PollId = lMsgId;
        }
    
    // Accessor for the property "RemainingMemberSet"
    /**
    * Setter for property RemainingMemberSet.<p>
    * The Set of Members that have not yet responded to the poll and that are
    * still running the Service.
    */
    protected void setRemainingMemberSet(MemberSet setMember)
        {
        __m_RemainingMemberSet = setMember;
        }
    
    // Accessor for the property "RespondedMemberSet"
    /**
    * Setter for property RespondedMemberSet.<p>
    * The Set of Members that have responded to the poll request.
    */
    protected void setRespondedMemberSet(MemberSet setMember)
        {
        __m_RespondedMemberSet = setMember;
        }
    
    // Accessor for the property "Result"
    /**
    * Setter for property Result.<p>
    * The result of the Poll. This property is used to collect the result of
    * the Poll and return it to the client thread that sent the original
    * RequestMessage.
    */
    public void setResult(Object oResult)
        {
        __m_Result = oResult;
        }
    
    // Accessor for the property "Service"
    /**
    * Setter for property Service.<p>
    * The Service object that is managing the poll.
    */
    public void setService(_package.component.util.daemon.queueProcessor.Service service)
        {
        // allow to be configured but not modified
        _assert(service != null && getService() == null);
        
        __m_Service = (service);
        }
    
    // Declared at the super level
    public String toString()
        {
        // import Component.Net.MemberSet;
        // import Component.Util.Daemon.QueueProcessor.Service;
        // import com.tangosol.util.Base;
        
        StringBuffer sb = new StringBuffer();
        
        sb.append("Poll")
          .append("\n  {")
          .append("\n  PollId=")
          .append(getPollId())
          .append(isClosed() ? ", closed" : ", active")
          .append("\n  Service=");
        
        Service service = getService();
        if (service == null)
            {
            sb.append("null");
            }
        else
            {
            sb.append(service.getServiceName())
              .append(" (")
              .append(service.getServiceId())
              .append(')');
            }
        
        sb.append("\n  RespondedMemberSet=[")
          .append(getRespondedMemberSet().getIdList())
          .append(']')
          .append("\n  LeftMemberSet=[")
          .append(getLeftMemberSet().getIdList())
          .append(']')
          .append("\n  RemainingMemberSet=[")
          .append(getRemainingMemberSet().getIdList())
          .append(']');
        
        String sDesc = getDescription();
        if (sDesc != null && sDesc.length() > 0)
            {
            sb.append('\n')
              .append(Base.indentString(sDesc, "  "));
            }
        
        sb.append("\n  }");
        
        return sb.toString();
        }
    }
