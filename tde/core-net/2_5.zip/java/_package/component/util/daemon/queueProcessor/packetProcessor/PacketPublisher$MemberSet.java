/* Class
*     _package.component.util.daemon.queueProcessor.packetProcessor.PacketPublisher$MemberSet
*/

package _package.component.util.daemon.queueProcessor.packetProcessor;

import _package.component.net.member.ClusterMember;
import _package.component.net.memberSet.ActualMemberSet;

/**
* 
* The Publisher's MemberSet child is used to get a snapshot of the "to" Members
* for each outgoing Packet.
* 
* @see PacketPublisher#onPacket
*/
public class PacketPublisher$MemberSet
        extends    _package.component.net.MemberSet
    {
    // Fields declarations
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Iterator", PacketPublisher$MemberSet$Iterator.get_CLASS());
        }
    
    // Default constructor
    public PacketPublisher$MemberSet()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PacketPublisher$MemberSet(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new PacketPublisher$MemberSet();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/daemon/queueProcessor/packetProcessor/PacketPublisher$MemberSet".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Declared at the super level
    public synchronized void clear()
        {
        int[] an = getBitSet();
        if (an != null)
            {
            for (int i = 0, c = an.length; i < c; ++i)
                {
                an[i] = 0;
                }
            }
        }
    
    public int[] toIdArray()
        {
        int   cIds   = size();
        int[] anId   = new int[cIds];
        
        if (cIds == 1)
            {
            anId[0] = getFirstId();
            }
        else
            {
            int[] anWord = getBitSet();
            int   iId    = 0;
            if (anWord != null)
                {
                for (int iWord = 0, cWords = anWord.length; iWord < cWords; ++iWord)
                    {
                    int nWord = anWord[iWord];
                    if (nWord != 0)
                        {
                        for (int of = 0, nMask = 1; of < 32; ++of, nMask <<= 1)
                            {
                            if ((nWord & nMask) != 0)
                                {
                                int nId = translateBit(iWord, nMask);
                                anId[iId++] = nId;
                                }
                            }
                        }
                    }
                }
            }
        
        return anId;
        }
    
    public synchronized void updateStats(long cMillis)
        {
        // import Component.Net.Member.ClusterMember;
        // import Component.Net.MemberSet.ActualMemberSet;
        
        ActualMemberSet setReal = (($Module) get_Module()).getMemberSet();
        
        int[] an = getBitSet();
        if (an != null)
            {
            for (int i = 0, c = an.length; i < c; ++i)
                {
                int n = an[i];
                if (n != 0)
                    {
                    for (int of = 0, nMask = 1; of < 32; ++of, nMask <<= 1)
                        {
                        if ((n & nMask) != 0)
                            {
                            int nId = translateBit(i, nMask);
                            ClusterMember member = (ClusterMember) setReal.getMember(nId);
                            if (member != null)
                                {
                                member.setLastOutgoingMillis(cMillis);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
