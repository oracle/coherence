/* Class
*     _package.component.util.daemon.queueProcessor.packetProcessor.PacketListener
*/

package _package.component.util.daemon.queueProcessor.packetProcessor;

import _package.component.net.Packet;
import _package.component.net.UdpPacket;
import _package.component.net.member.ClusterMember;
import _package.component.net.packet.messagePacket.Broadcast;
import _package.component.net.socket.UdpSocket;
import _package.component.util.Queue;
import com.tangosol.run.component.EventDeathException;
import com.tangosol.util.WrapperException;
import java.io.EOFException;
import java.io.IOException;

/**
* <br>
* A client of PacketListener must configure:<br>
* <br><ul>
* <li>DatagramSocket property</li>
* <li>ReceiveQueue property</li>
* </ul><br>
*/
public class PacketListener
        extends    _package.component.util.daemon.queueProcessor.PacketProcessor
    {
    // Fields declarations
    
    /**
    * Property ReceiveQueue
    *
    * The Queue object to which Packet objects will be appended.
    */
    private _package.component.util.Queue __m_ReceiveQueue;
    
    /**
    * Property StatsCpu
    *
    * Statistics: total time spent processing packets.
    */
    private transient long __m_StatsCpu;
    
    /**
    * Property StatsReset
    *
    * Statistics: Date/time value that the stats have been reset.
    */
    private transient long __m_StatsReset;
    
    /**
    * Property UdpPacket
    *
    */
    private _package.component.net.UdpPacket __m_UdpPacket;
    
    /**
    * Property UdpSocket
    *
    */
    private _package.component.net.socket.UdpSocket __m_UdpSocket;
    
    // Default constructor
    public PacketListener()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PacketListener(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        _addChild(new _package.component.util.daemon.QueueProcessor$Queue("Queue", this, true), "Queue");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new PacketListener();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/daemon/queueProcessor/packetProcessor/PacketListener".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    public String formatStats()
        {
        long   cCpu   = getStatsCpu();
        long   cTotal = System.currentTimeMillis() - getStartTimestamp();
        double dCpu   = cTotal == 0L ? 0.0 : ((double) cCpu)/((double) cTotal);
        
        return "Cpu=" + cCpu + "ms (" + (float) dCpu + "%)";
        }
    
    // Accessor for the property "ReceiveQueue"
    /**
    * Getter for property ReceiveQueue.<p>
    * The Queue object to which Packet objects will be appended.
    */
    public _package.component.util.Queue getReceiveQueue()
        {
        return __m_ReceiveQueue;
        }
    
    // Accessor for the property "StatsCpu"
    /**
    * Getter for property StatsCpu.<p>
    * Statistics: total time spent processing packets.
    */
    public long getStatsCpu()
        {
        return __m_StatsCpu;
        }
    
    // Accessor for the property "StatsReset"
    /**
    * Getter for property StatsReset.<p>
    * Statistics: Date/time value that the stats have been reset.
    */
    public long getStatsReset()
        {
        return __m_StatsReset;
        }
    
    // Accessor for the property "UdpPacket"
    /**
    * Getter for property UdpPacket.<p>
    */
    protected _package.component.net.UdpPacket getUdpPacket()
        {
        return __m_UdpPacket;
        }
    
    // Accessor for the property "UdpSocket"
    /**
    * Getter for property UdpSocket.<p>
    */
    public _package.component.net.socket.UdpSocket getUdpSocket()
        {
        return __m_UdpSocket;
        }
    
    // Declared at the super level
    /**
    * Event notification called once the daemon's thread starts and before the
    * daemon thread goes into the "wait - perform" loop. Unlike the
    * <code>onInit()</code> event, this method executes on the daemon's thread.
    * 
    * Note1: this method is called while the caller's thread is still waiting
    * for a notification to  "unblock" itself.
    * Note2: any exception thrown by this method will terminate the thread
    * immediately
    */
    protected void onEnter()
        {
        super.onEnter();
        
        resetStats();
        }
    
    // Declared at the super level
    /**
    * Event notification to perform a regular daemon activity. To get it
    * called, another thread has to set Notification to true:
    * <code>daemon.setNotification(true);</code>
    * 
    * @see #onWait
    */
    protected void onNotify()
        {
        // import Component.Net.Packet;
        // import Component.Net.UdpPacket;
        // import com.tangosol.util.WrapperException;
        // import java.io.EOFException;
        // import java.io.IOException;
        
        long lStart = System.currentTimeMillis();
        
        UdpPacket udppacket = getUdpPacket();
        
        // reset the data input to the start of the packet data
        udppacket.getInputStream().setOffset(0);
        
        // convert the raw packet data to a Packet component
        Packet packet = null;
        try
            {
            packet = readPacket(udppacket.getDataInputStream());
            }
        catch (IOException e)
            {
            if (!isExiting())
                {
                // ignore garbage data
                _trace("An exception occurred while processing a Packet a DatagramPacket{"
                    + "address=" + udppacket.getInetAddress().getHostAddress()
                    + ", port="  + udppacket.getPort() + "}:", 1);
                _trace(e);
                _trace("Exception will be ignored.", 1);
                }
            }
        
        // if it was a Packet for this listener, then process it
        if (packet != null)
            {
            packet.setFromAddress(udppacket.getInetAddress());
            packet.setFromPort(udppacket.getPort());
            onPacket(packet);
            }
        
        setStatsCpu(getStatsCpu() + (System.currentTimeMillis() - lStart));
        }
    
    /**
    * Process a Packet component that has been read from a DatagramPacket and
    * has been determined to be applicable to this Member.
    * 
    * @param packet  the Packet component that has been received
    */
    protected void onPacket(_package.component.net.Packet packet)
        {
        // import Component.Net.Member.ClusterMember;
        // import Component.Net.Packet.MessagePacket.Broadcast;
        // import Component.Util.Queue;
        
        // a Packet is either from a Member that has not joined the cluster yet,
        // so the FromId will be zero, or the Member is (or thinks it is)
        // part of the cluster, so the FromId will be non-zero
        int nId = packet.getFromId();
        if (nId != 0)
            {
            // verify that the Member that sent the Packet is known
            // to this Member
            ClusterMember member = getMember(nId);
            if (member == null)
                {
                // allow the Packet to be processed if it is a
                // broadcasted Packet (i.e. its ToId is zero)
                if (packet.getToId() != 0)
                    {
                    // cannot receive an addressed Packet from an unknown Member
                    return;
                    }
                }
            else
                {
                long          lRecvTime  = packet.getReceivedMillis();
                ClusterMember memberThis = getThisMember();
                if (member != memberThis)
                    {
                    // update point-to-point "last received"
                    member.setLastIncomingMillis(lRecvTime);
                    }
        
                if (memberThis != null)
                    {
                    // update global "last received" (don't count
                    // Broadcast Packets ... just those addressed
                    // specifically to this Member)
                    if (!(packet instanceof Broadcast))
                        {
                        memberThis.setLastIncomingMillis(lRecvTime);
                        }
                    }
                }
            }
        
        Queue queue = getReceiveQueue();
        if (queue != null)
            {
            queue.add(packet);
            }
        }
    
    public void onReceiveException(Exception e)
        {
        // import com.tangosol.run.component.EventDeathException;
        
        // not enough information here to determine why the receive
        // failed; however, it is likely that a packet send was
        // attempted to a non-existent member
        throw new EventDeathException(e.toString());
        }
    
    // Declared at the super level
    /**
    * Event notification called when  the daemon's Thread is waiting for work.
    * 
    * @see #run
    */
    protected void onWait()
            throws java.lang.InterruptedException
        {
        // import com.tangosol.run.component.EventDeathException;
        
        try
            {
            getUdpPacket().receive();
            }
        catch (Exception e)
            {
            throw new EventDeathException(e.toString());
            }
        }
    
    /**
    * Translate a DatagramPacket into a Packet component if the data is
    * intended for this PacketListener.
    * 
    * @param stream  a DataInputStream from which the packet data can be read
    * 
    * @return a Packet component or null if the DatagramPacket data is not
    * intended for this PacketListener
    */
    protected _package.component.net.Packet readPacket(java.io.DataInputStream stream)
            throws java.io.IOException
        {
        // import Component.Net.Packet;
        
        // first determine if the Packet is intended for this Member
        if (Packet.isForMember(stream, getMemberId()))
            {
            // rewind to the begining of the DatagramPacket's data
            stream.reset();
        
            // create and return a Packet component from the data
            // in the DatagramPacket
            return Packet.instantiate(stream, getMemberId());
            }
        else
            {
            return null;
            }
        }
    
    public void resetStats()
        {
        setStatsCpu(0L);
        setStatsReset(System.currentTimeMillis());
        }
    
    // Accessor for the property "ReceiveQueue"
    /**
    * Setter for property ReceiveQueue.<p>
    * The Queue object to which Packet objects will be appended.
    */
    public void setReceiveQueue(_package.component.util.Queue queue)
        {
        _assert(queue != null);
        _assert(getReceiveQueue() == null);
        
        __m_ReceiveQueue = (queue);
        }
    
    // Accessor for the property "StatsCpu"
    /**
    * Setter for property StatsCpu.<p>
    * Statistics: total time spent processing packets.
    */
    protected void setStatsCpu(long cMillis)
        {
        __m_StatsCpu = cMillis;
        }
    
    // Accessor for the property "StatsReset"
    /**
    * Setter for property StatsReset.<p>
    * Statistics: Date/time value that the stats have been reset.
    */
    protected void setStatsReset(long lMillis)
        {
        __m_StatsReset = lMillis;
        }
    
    // Accessor for the property "UdpPacket"
    /**
    * Setter for property UdpPacket.<p>
    */
    protected void setUdpPacket(_package.component.net.UdpPacket packet)
        {
        __m_UdpPacket = packet;
        }
    
    // Accessor for the property "UdpSocket"
    /**
    * Setter for property UdpSocket.<p>
    */
    public void setUdpSocket(_package.component.net.socket.UdpSocket socket)
        {
        // import Component.Net.Socket.UdpSocket;
        // import Component.Net.UdpPacket;
        
        _assert(getUdpSocket() == null);
        
        UdpPacket packet = null;
        if (socket != null)
            {
            packet = new UdpPacket();
            packet.setBufferLength(socket.getPacketLength());
            packet.setUdpSocket(socket);
            }
        
        setUdpPacket(packet);
        __m_UdpSocket = (socket);
        }
    
    // Declared at the super level
    /**
    * Starts the daemon thread associated with this component. If the thread is
    * already starting or has started, invoking this method has no effect.
    * 
    * Synchronization is used here to verify that the start of the thread
    * occurs; the lock is obtained before the thread is started, and the daemon
    * thread notifies back that it has started from the run() method.
    */
    public synchronized void start()
        {
        if (getUdpSocket() == null)
            {
            throw new IllegalStateException("DatagramSocket is required!");
            }
        
        if (getReceiveQueue() == null)
            {
            throw new IllegalStateException("ReceiveQueue is required!");
            }
        
        super.start();
        }
    
    // Declared at the super level
    /**
    * Stops the daemon thread associated with this component.
    */
    public synchronized void stop()
        {
        super.stop();
        
        try
            {
            getUdpSocket().close();
            }
        catch (Throwable e) {}
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_Name() + ':' + formatStats();
        }
    }
