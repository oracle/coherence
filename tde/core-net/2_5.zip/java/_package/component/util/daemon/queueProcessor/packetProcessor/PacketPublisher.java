/* Class
*     _package.component.util.daemon.queueProcessor.packetProcessor.PacketPublisher
*/

package _package.component.util.daemon.queueProcessor.packetProcessor;

import _package.component.net.Member;
import _package.component.net.MemberSet;
import _package.component.net.Packet;
import _package.component.net.UdpPacket;
import _package.component.net.packet.MessagePacket;
import _package.component.net.socket.UdpSocket;
import _package.component.util.Queue;
import com.tangosol.net.DatagramPacketOutputStream;
import com.tangosol.util.WrapperException;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;

/**
* <br>
* A client of PacketPublisher must additionally configure:<br>
* <br><ul>
* <li>DatagramSocket property</li>
* <li>MulticastAddress property</li>
* <li>MulticastSocket property</li>
* <li>MessageOutgoing property</li>
* </ul><br>
* A client of PacketPublisher may configure:<br>
* <br><ul>
* <li>ResendDelay property</li>
* <li>ResendTimeout property</li>
* <li>AckDelay property</li>
* <li>RequestDelay property</li>
* <li>BurstCount property</li>
* <li>BurstDelay property</li>
* </ul><br>
*/
public class PacketPublisher
        extends    _package.component.util.daemon.queueProcessor.PacketProcessor
    {
    // Fields declarations
    
    /**
    * Property AckDelay
    *
    * The minimum number of milliseconds between the queueing of an Ack packet
    * and the sending of the same.
    */
    private int __m_AckDelay;
    
    /**
    * Property AckQueue
    *
    * A reference to the AckQueue child, which is the Queue in which
    * Packet-notification Packets are placed so that they are automatically
    * after a configurable period of time.
    */
    private PacketPublisher$AckQueue __m_AckQueue;
    
    /**
    * Property BurstCount
    *
    * The maximum number of packets to send without pausing. Anything less than
    * one (e.g. zero) means no limit.
    */
    private int __m_BurstCount;
    
    /**
    * Property BurstDelay
    *
    * The number of milliseconds to pause between bursts. Anything less than
    * one (e.g. zero) is treated as one.
    */
    private int __m_BurstDelay;
    
    /**
    * Property CloggedCount
    *
    * The maximum number of packets in the send plus resend queues before
    * determining that the publisher is clogged. Zero means no limit.
    */
    private int __m_CloggedCount;
    
    /**
    * Property CloggedDelay
    *
    * The number of milliseconds to pause client threads when a clog occurs, to
    * wait for the clog to dissipate. (The pause is repeated until the clog is
    * gone.) Anything less than one (e.g. zero) is treated as one.
    */
    private int __m_CloggedDelay;
    
    /**
    * Property DatagramRecipient
    *
    * The Member to whom a directed packet is being sent, or null. Allows the
    * Datagram Listener to determine Member death on a blocking socket receive
    * call.
    */
    private _package.component.net.Member __m_DatagramRecipient;
    
    /**
    * Property ElementList
    *
    * The List that backs the Queue.
    */
    private java.util.List __m_ElementList;
    
    /**
    * Property MemberSetTemp
    *
    * A cached MemberSet object that is used to get a snap-shot of the
    * MemberSet that a Packet is being delivered to. Used by onPacket.
    */
    private PacketPublisher$MemberSet __m_MemberSetTemp;
    
    /**
    * Property MessageOutgoing
    *
    * The dispatcher's array of outgoing Message objects.
    */
    private _package.component.util.WindowedArray __m_MessageOutgoing;
    
    /**
    * Property MulticastThreshold
    *
    * The percentage (0.0 to 100.0) of the servers in the cluster that a packet
    * will be sent to, above which the packet will be multicasted and below
    * which it will be unicasted.
    */
    private double __m_MulticastThreshold;
    
    /**
    * Property RequestDelay
    *
    * The minimum number of milliseconds between the queueing of an Request
    * packet and the sending of the same.
    */
    private int __m_RequestDelay;
    
    /**
    * Property RequestQueue
    *
    * A reference to the AckQueue child, which is the Queue in which
    * Packet-notification Packets are placed so that they are automatically
    * after a configurable period of time.
    */
    private PacketPublisher$RequestQueue __m_RequestQueue;
    
    /**
    * Property ResendDelay
    *
    * The minimum number of milliseconds that a Packet will remain queued in
    * the ResendQueue before being removed from the front of the Queue to be
    * resent.
    * 
    * (2-way calculated; do not design.)
    */
    private int __m_ResendDelay;
    
    /**
    * Property ResendQueue
    *
    * A reference to the ResendQueue child, which is the Queue in which
    * guaranteed-delivery Packets are placed so that they are automatically
    * resent.
    */
    private PacketPublisher$ResendQueue __m_ResendQueue;
    
    /**
    * Property ResendTimeout
    *
    * The maximum number of milliseconds that a Packet will be resent before it
    * is assumed that the remaining unacknowledging Members have died.
    * 
    * (2-way calculated; do not design.)
    */
    private int __m_ResendTimeout;
    
    /**
    * Property StatsBurst
    *
    * Statistics: total number of "bursts".
    */
    private transient long __m_StatsBurst;
    
    /**
    * Property StatsCpu
    *
    * Statistics: total time spent while sending packets.
    */
    private transient long __m_StatsCpu;
    
    /**
    * Property StatsResent
    *
    * Statistics: total number of re-sent packets.
    */
    private transient long __m_StatsResent;
    
    /**
    * Property StatsReset
    *
    * Statistics: Date/time value that the stats have been reset.
    */
    private transient long __m_StatsReset;
    
    /**
    * Property StatsSent
    *
    * Statistics: total number of sent packets.
    */
    private transient long __m_StatsSent;
    
    /**
    * Property UdpPacketMulticast
    *
    */
    private _package.component.net.UdpPacket __m_UdpPacketMulticast;
    
    /**
    * Property UdpPacketUnicast
    *
    */
    private _package.component.net.UdpPacket __m_UdpPacketUnicast;
    
    /**
    * Property UdpSocketMulticast
    *
    */
    private _package.component.net.socket.udpSocket.MulticastUdpSocket __m_UdpSocketMulticast;
    
    /**
    * Property UdpSocketUnicast
    *
    */
    private _package.component.net.socket.udpSocket.UnicastUdpSocket __m_UdpSocketUnicast;
    
    // Default constructor
    public PacketPublisher()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PacketPublisher(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setBurstCount(0);
            setBurstDelay(7);
            setCloggedCount(1024);
            setCloggedDelay(32);
            setMulticastThreshold(0.25);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new PacketPublisher$AckQueue("AckQueue", this, true), "AckQueue");
        _addChild(new PacketPublisher$MemberSet("MemberSet", this, true), "MemberSet");
        _addChild(new PacketPublisher$Queue("Queue", this, true), "Queue");
        _addChild(new PacketPublisher$RequestQueue("RequestQueue", this, true), "RequestQueue");
        _addChild(new PacketPublisher$ResendQueue("ResendQueue", this, true), "ResendQueue");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new PacketPublisher();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/daemon/queueProcessor/packetProcessor/PacketPublisher".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * This method is mostly called on client threads.
    */
    public void drainOverflow()
        {
        if (Thread.currentThread().getThreadGroup() != getThreadGroup())
            {
            // slow down too agressive clients to prevent memory overflow
            int cMaxPackets  = getCloggedCount();
            int cPauseMillis = getCloggedDelay();
            while (isStarted())
                {
                int cPackets = getQueue().size() + getResendQueue().size();
                if (cPackets < cMaxPackets || cMaxPackets <= 0)
                    {
                    break;
                    }
        
                try
                    {
                    Thread.sleep(cPauseMillis);
                    }
                catch (InterruptedException e)
                    {
                    Thread.currentThread().interrupt();
                    return;
                    }
                }
            }
        }
    
    public String formatStats()
        {
        long   cCpu     = getStatsCpu();
        long   cTotal   = System.currentTimeMillis() - getStartTimestamp();
        long   lSent    = getStatsSent();
        long   lResent  = getStatsResent();
        long   lBurst   = getStatsBurst();
        double dCpu     = cTotal == 0L ? 0.0 : ((double) cCpu)/((double) cTotal);
        double dThru    = cCpu == 0L ? 0.0 : ((double) lSent*1000)/((double) cCpu);
        double dSuccess = lSent == 0L ? 1.0 : 1.0 - ((double) lResent)/((double) lSent);
        double dBurst   = lBurst == 0L ? 0.0 : ((double) lSent)/((double) lBurst);
        
        return "Cpu=" + cCpu + "ms (" + (float) dCpu + "%)"
               + ", PacketsSent="   + lSent
               + ", PacketsResent=" + lResent
               + ", Throughput="    + (float) dThru + "pkt/sec"
               + ", SuccessRate="   + (float) dSuccess
               + ", BurstAverage="  + (float) dBurst
               ;
        }
    
    // Accessor for the property "AckDelay"
    /**
    * Getter for property AckDelay.<p>
    * The minimum number of milliseconds between the queueing of an Ack packet
    * and the sending of the same.
    */
    public int getAckDelay()
        {
        return getAckQueue().getDelayMillis();
        }
    
    // Accessor for the property "AckQueue"
    /**
    * Getter for property AckQueue.<p>
    * A reference to the AckQueue child, which is the Queue in which
    * Packet-notification Packets are placed so that they are automatically
    * after a configurable period of time.
    */
    public PacketPublisher$AckQueue getAckQueue()
        {
        $AckQueue queue = __m_AckQueue;
        
        if (queue == null)
            {
            queue = ($AckQueue) _findName("AckQueue");
            setAckQueue(queue);
            }
        
        return queue;
        }
    
    // Accessor for the property "BurstCount"
    /**
    * Getter for property BurstCount.<p>
    * The maximum number of packets to send without pausing. Anything less than
    * one (e.g. zero) means no limit.
    */
    public int getBurstCount()
        {
        return __m_BurstCount;
        }
    
    // Accessor for the property "BurstDelay"
    /**
    * Getter for property BurstDelay.<p>
    * The number of milliseconds to pause between bursts. Anything less than
    * one (e.g. zero) is treated as one.
    */
    public int getBurstDelay()
        {
        return __m_BurstDelay;
        }
    
    // Accessor for the property "CloggedCount"
    /**
    * Getter for property CloggedCount.<p>
    * The maximum number of packets in the send plus resend queues before
    * determining that the publisher is clogged. Zero means no limit.
    */
    public int getCloggedCount()
        {
        return __m_CloggedCount;
        }
    
    // Accessor for the property "CloggedDelay"
    /**
    * Getter for property CloggedDelay.<p>
    * The number of milliseconds to pause client threads when a clog occurs, to
    * wait for the clog to dissipate. (The pause is repeated until the clog is
    * gone.) Anything less than one (e.g. zero) is treated as one.
    */
    public int getCloggedDelay()
        {
        return __m_CloggedDelay;
        }
    
    // Accessor for the property "DatagramRecipient"
    /**
    * Getter for property DatagramRecipient.<p>
    * The Member to whom a directed packet is being sent, or null. Allows the
    * Datagram Listener to determine Member death on a blocking socket receive
    * call.
    */
    public _package.component.net.Member getDatagramRecipient()
        {
        return __m_DatagramRecipient;
        }
    
    // Accessor for the property "ElementList"
    /**
    * Getter for property ElementList.<p>
    * The List that backs the Queue.
    */
    protected java.util.List getElementList()
        {
        return __m_ElementList;
        }
    
    // Accessor for the property "MemberSetTemp"
    /**
    * Getter for property MemberSetTemp.<p>
    * A cached MemberSet object that is used to get a snap-shot of the
    * MemberSet that a Packet is being delivered to. Used by onPacket.
    */
    protected PacketPublisher$MemberSet getMemberSetTemp()
        {
        $MemberSet set = __m_MemberSetTemp;
        
        if (set == null)
            {
            set = ($MemberSet) _findChild("MemberSet");
            setMemberSetTemp(set);
            }
        else
            {
            set.clear();
            }
        
        return set;
        }
    
    // Accessor for the property "MessageOutgoing"
    /**
    * Getter for property MessageOutgoing.<p>
    * The dispatcher's array of outgoing Message objects.
    */
    public _package.component.util.WindowedArray getMessageOutgoing()
        {
        return __m_MessageOutgoing;
        }
    
    // Accessor for the property "MulticastThreshold"
    /**
    * Getter for property MulticastThreshold.<p>
    * The percentage (0.0 to 100.0) of the servers in the cluster that a packet
    * will be sent to, above which the packet will be multicasted and below
    * which it will be unicasted.
    */
    public double getMulticastThreshold()
        {
        return __m_MulticastThreshold;
        }
    
    // Accessor for the property "RequestDelay"
    /**
    * Getter for property RequestDelay.<p>
    * The minimum number of milliseconds between the queueing of an Request
    * packet and the sending of the same.
    */
    public int getRequestDelay()
        {
        return getRequestQueue().getDelayMillis();
        }
    
    // Accessor for the property "RequestQueue"
    /**
    * Getter for property RequestQueue.<p>
    * A reference to the AckQueue child, which is the Queue in which
    * Packet-notification Packets are placed so that they are automatically
    * after a configurable period of time.
    */
    public PacketPublisher$RequestQueue getRequestQueue()
        {
        $RequestQueue queue = __m_RequestQueue;
        
        if (queue == null)
            {
            queue = ($RequestQueue) _findName("RequestQueue");
            setRequestQueue(queue);
            }
        
        return queue;
        }
    
    // Accessor for the property "ResendDelay"
    /**
    * Getter for property ResendDelay.<p>
    * The minimum number of milliseconds that a Packet will remain queued in
    * the ResendQueue before being removed from the front of the Queue to be
    * resent.
    * 
    * (2-way calculated; do not design.)
    */
    public int getResendDelay()
        {
        return getResendQueue().getResendMillis();
        }
    
    // Accessor for the property "ResendQueue"
    /**
    * Getter for property ResendQueue.<p>
    * A reference to the ResendQueue child, which is the Queue in which
    * guaranteed-delivery Packets are placed so that they are automatically
    * resent.
    */
    public PacketPublisher$ResendQueue getResendQueue()
        {
        $ResendQueue queue = __m_ResendQueue;
        
        if (queue == null)
            {
            queue = ($ResendQueue) _findName("ResendQueue");
            setResendQueue(queue);
            }
        
        return queue;
        }
    
    // Accessor for the property "ResendTimeout"
    /**
    * Getter for property ResendTimeout.<p>
    * The maximum number of milliseconds that a Packet will be resent before it
    * is assumed that the remaining unacknowledging Members have died.
    * 
    * (2-way calculated; do not design.)
    */
    public int getResendTimeout()
        {
        return getResendQueue().getTimeoutMillis();
        }
    
    // Accessor for the property "StatsBurst"
    /**
    * Getter for property StatsBurst.<p>
    * Statistics: total number of "bursts".
    */
    public long getStatsBurst()
        {
        return __m_StatsBurst;
        }
    
    // Accessor for the property "StatsCpu"
    /**
    * Getter for property StatsCpu.<p>
    * Statistics: total time spent while sending packets.
    */
    public long getStatsCpu()
        {
        return __m_StatsCpu;
        }
    
    // Accessor for the property "StatsResent"
    /**
    * Getter for property StatsResent.<p>
    * Statistics: total number of re-sent packets.
    */
    public long getStatsResent()
        {
        return __m_StatsResent;
        }
    
    // Accessor for the property "StatsReset"
    /**
    * Getter for property StatsReset.<p>
    * Statistics: Date/time value that the stats have been reset.
    */
    public long getStatsReset()
        {
        return __m_StatsReset;
        }
    
    // Accessor for the property "StatsSent"
    /**
    * Getter for property StatsSent.<p>
    * Statistics: total number of sent packets.
    */
    public long getStatsSent()
        {
        return __m_StatsSent;
        }
    
    // Accessor for the property "UdpPacketMulticast"
    /**
    * Getter for property UdpPacketMulticast.<p>
    */
    protected _package.component.net.UdpPacket getUdpPacketMulticast()
        {
        return __m_UdpPacketMulticast;
        }
    
    // Accessor for the property "UdpPacketUnicast"
    /**
    * Getter for property UdpPacketUnicast.<p>
    */
    protected _package.component.net.UdpPacket getUdpPacketUnicast()
        {
        return __m_UdpPacketUnicast;
        }
    
    // Accessor for the property "UdpSocketMulticast"
    /**
    * Getter for property UdpSocketMulticast.<p>
    */
    public _package.component.net.socket.udpSocket.MulticastUdpSocket getUdpSocketMulticast()
        {
        return __m_UdpSocketMulticast;
        }
    
    // Accessor for the property "UdpSocketUnicast"
    /**
    * Getter for property UdpSocketUnicast.<p>
    */
    public _package.component.net.socket.udpSocket.UnicastUdpSocket getUdpSocketUnicast()
        {
        return __m_UdpSocketUnicast;
        }
    
    // Declared at the super level
    /**
    * Getter for property WaitMillis.<p>
    * The number of milliseconds that the daemon will wait for notification.
    * Zero means to wait indefinitely. Negative value means to skip waiting
    * altogether.
    * 
    * @see onWait
    */
    public long getWaitMillis()
        {
        long lWaitResend  = getResendQueue().getWaitMillis();
        long lWaitAck     = getAckQueue().getWaitMillis();
        long lWaitRequest = getRequestQueue().getWaitMillis();
        
        if (lWaitResend == 0L && lWaitAck == 0L && lWaitRequest == 0L)
            {
            return 0L;
            }
        
        if (lWaitResend == 0L)
            {
            lWaitResend = 60000L;
            }
        
        if (lWaitAck == 0L)
            {
            lWaitAck = 60000L;
            }
        
        if (lWaitRequest == 0L)
            {
            lWaitRequest = 60000L;
            }
        
        return Math.min(Math.min(lWaitResend, lWaitAck), lWaitRequest);
        }
    
    /**
    * Determine if a Packet should be sent using a multi-cast socket. Do not
    * use the "to" information from the Packet to make the determination;
    * rather, used the passed set.
    * 
    * @param packet  the Packet to send
    * @param setTo  a Member Set of potentially multiple Members to send the
    * Packet to
    * 
    * @return true to multi-cast the Packet data
    */
    protected boolean isMulticast(_package.component.net.Packet packet, _package.component.net.MemberSet setTo)
        {
        // use multi-cast for any packet that must be delivered to more
        // than one member
        if (packet.isOutgoingBroadcast())
            {
            return true;
            }
        
        int cToMembers = setTo.size();
        if (cToMembers <= 1)
            {
            return false;
            }
        
        int    cOtherMembers         = getMemberSet().size() - 1;
        double dflMulticastThreshold = getMulticastThreshold();
        
        return cToMembers > (int) (dflMulticastThreshold * cOtherMembers);
        }
    
    // Declared at the super level
    /**
    * Event notification called once the daemon's thread starts and before the
    * daemon thread goes into the "wait - perform" loop. Unlike the
    * <code>onInit()</code> event, this method executes on the daemon's thread.
    * 
    * Note1: this method is called while the caller's thread is still waiting
    * for a notification to  "unblock" itself.
    * Note2: any exception thrown by this method will terminate the thread
    * immediately
    */
    protected void onEnter()
        {
        super.onEnter();
        
        resetStats();
        }
    
    protected void onNoRecipientPacket(_package.component.net.Packet packet)
        {
        // import Component.Net.Packet.MessagePacket;
        
        // we have to put it back to the queue
        // to have the corresponding message removed
        if (packet.isConfirmationRequired())
            {
            MessagePacket packetMsg = (MessagePacket) packet;
            packetMsg.setToId(0);
            packetMsg.setToMemberSet(null);
            packetMsg.setSentMillis(System.currentTimeMillis());
            getResendQueue().add(packetMsg);
            }
        }
    
    // Declared at the super level
    /**
    * Event notification to perform a regular daemon activity. To get it
    * called, another thread has to set Notification to true:
    * <code>daemon.setNotification(true);</code>
    * 
    * @see #onWait
    */
    protected void onNotify()
        {
        // import Component.Net.Packet;
        // import Component.Util.Queue;
        
        long  lStart = System.currentTimeMillis();
        
        Queue queueSend    = getQueue();
        Queue queueResend  = getResendQueue();
        Queue queueAck     = getAckQueue();
        Queue queueRequest = getRequestQueue();
        
        int   cMaxPackets    = getBurstCount();
        int   cSentPackets   = 0;
        int   cResentPackets = 0;
        
        boolean fMore;
        do
            {
            fMore = false;
            
            Packet packet = (Packet) queueSend.removeNoWait();
            if (packet != null)
                {
                onPacket(packet);
                fMore = true;
                ++cSentPackets;
                }
        
            packet = (Packet) queueResend.removeNoWait();
            if (packet != null)
                {
                onPacket(packet);
                fMore = true;
                ++cSentPackets;
                ++cResentPackets;
                }
        
            synchronized (queueSend) // see Receiver.confirm()
                {
                packet = (Packet) queueAck.removeNoWait();
                }
            if (packet != null)
                {
                onPacket(packet);
                fMore = true;
                ++cSentPackets;
                }
        
            synchronized (queueSend) // see Receiver.request()
                {
                packet = (Packet) queueRequest.removeNoWait();
                }
            if (packet != null)
                {
                onPacket(packet);
                fMore = true;
                ++cSentPackets;
                }
            }
        while (fMore && (cMaxPackets == 0 || cSentPackets < cMaxPackets));
        
        // a "burst" is anything more than half of the max burst
        if (cMaxPackets > 0 && cSentPackets > cMaxPackets >>> 1)
            {
            // if burst mode is configured and a burst occurred,
            // rest the thread
            try
                {
                Thread.sleep(getBurstDelay());
                }
            catch (InterruptedException e)
                {
                Thread.currentThread().interrupt();
                }
            }
        
        if (cSentPackets > 0)
            {
            setStatsBurst (getStatsBurst()  + 1);
            setStatsSent  (getStatsSent()   + cSentPackets);
            setStatsResent(getStatsResent() + cResentPackets);
            setStatsCpu   (getStatsCpu()    + (System.currentTimeMillis() - lStart));
            }
        }
    
    protected void onPacket(_package.component.net.Packet packetData)
        {
        // import Component.Net.Member;
        // import Component.Net.Packet.MessagePacket;
        // import Component.Net.Socket.UdpSocket;
        // import Component.Net.UdpPacket;
        // import com.tangosol.net.DatagramPacketOutputStream;
        // import com.tangosol.util.WrapperException;
        // import java.io.DataOutputStream;
        // import java.io.IOException;
        // import java.net.InetAddress;
        
        // determine to whom the packet will be sent
        $MemberSet setTo = getMemberSetTemp();
        if (packetData.isOutgoingMultipoint())
            {
            setTo.addAll(((MessagePacket) packetData).getToMemberSet());
            }
        else
            {
            Member member = getMember(packetData.getToId());
            if (member != null)
                {
                // configure a "to set" of one member
                setTo.add(member);
                }
            }
        
        // verify that there are any recipients
        if (setTo.isEmpty() && !packetData.isOutgoingBroadcast())
            {
            // this Packet has no one left to which it should be
            // delivered; clean it up
            onNoRecipientPacket(packetData);
            return;
            }
        
        // determine if the packet will be sent via multi-cast
        boolean fMulticast = isMulticast(packetData, setTo);
        
        // get the communication objects for the appropriate socket
        UdpPacket packet = (fMulticast ? getUdpPacketMulticast()
                                       : getUdpPacketUnicast());
        DatagramPacketOutputStream  streamRaw  = packet.getOutputStream();
        DataOutputStream            streamData = packet.getDataOutputStream();
        
        // stream the Packet data into the UdpPacket
        try
            {
            streamRaw.reset();
            packetData.write(streamData, setTo);
            streamRaw.flush();
            }
        catch (IOException e)
            {
            throw new WrapperException(e);
            }
        
        int   cIters = 1;
        int[] anToId = null;
        if (!fMulticast)
            {
            anToId = setTo.toIdArray();
            cIters = anToId.length;
            }
        
        boolean fAnyRecipients = fMulticast;
        for (int i = 0; i < cIters; ++i)
            {
            Member memberRecipient = null;
            if (!fMulticast)
                {
                Member member = getMember(anToId[i]);
                if (member == null)
                    {
                    continue;
                    }
        
                fAnyRecipients = true;
        
                packet.setInetAddress(member.getAddress());
                packet.setPort(member.getPort());
        
                memberRecipient = member;
                }
        
            // send the UdpPacket
            setDatagramRecipient(memberRecipient);
            try
                {
                packet.send();
                }
            catch (Exception e)
                {
                if (isExiting())
                    {
                    // ignore exception and don't bother with re-send or stats
                    return;
                    }
        
                // if the socket is closed ignore the exception
                // (either closed by the PacketListener or refreshing sockets)
                if (packet.getUdpSocket().getState() != UdpSocket.STATE_CLOSED)
                    {
                    _trace("PacketPublisher: An exception occurred sending a "
                            + (fMulticast ? "multicast" : "datagram") + " packet: " + e, 1);
                    }
                }
            finally
                {
                setDatagramRecipient(null);
                }
            }
        
        if (!fAnyRecipients)
            {
            // the Packet is addressed to a Member that is dead
            // (i.e. it isn't in the MasterMemberSet any more)
            onNoRecipientPacket(packetData);
            return;
            }
        
        // update stats
        long cMillis = System.currentTimeMillis();
        packetData.setSentMillis(cMillis);
        setTo.updateStats(cMillis);
        
        // requeue Packet for re-send if delivery is guaranteed
        if (packetData.isConfirmationRequired())
            {
            MessagePacket packetMsg = (MessagePacket) packetData;
            if (packetMsg.isResendRequestInProgress())
                {
                // if a resend is in progress because of a
                // Request Packet (instead of a timeout in the
                // resend Queue), the Packet is already in the
                // resend Queue and does not have to be re-queued
                packetMsg.setResendRequestInProgress(false);
                }
            else
                {
                getResendQueue().add(packetMsg);
                }
            }
        }
    
    public void onUndeliverablePacket(_package.component.net.packet.MessagePacket packet)
        {
        // import Component.Net.Member;
        // import Component.Net.MemberSet;
        
        // this should be over-ridden where applicable; this
        // implementation just kills all Members that have
        // not acknowledged the Packet
        
        int nMemberTo = packet.getToId();
        if (nMemberTo != 0)
            {
            Member member = getMember(nMemberTo);
            if (member != null)
                {
                getMemberSet().remove(member);
                }
            packet.setToId(0);
            }
        
        MemberSet setMemberTo = packet.getToMemberSet();
        if (setMemberTo != null)
            {
            getMemberSet().removeAll(setMemberTo);
            setMemberTo.clear();
            }

        }
    
    /**
    * Reset the statistics.
    */
    public void resetStats()
        {
        setStatsBurst (0L); 
        setStatsSent  (0L);
        setStatsResent(0L);
        setStatsCpu   (0L);
        setStatsReset (System.currentTimeMillis());
        }
    
    // Accessor for the property "AckDelay"
    /**
    * Setter for property AckDelay.<p>
    * The minimum number of milliseconds between the queueing of an Ack packet
    * and the sending of the same.
    */
    public void setAckDelay(int cMillis)
        {
        getAckQueue().setDelayMillis(cMillis);
        }
    
    // Accessor for the property "AckQueue"
    /**
    * Setter for property AckQueue.<p>
    * A reference to the AckQueue child, which is the Queue in which
    * Packet-notification Packets are placed so that they are automatically
    * after a configurable period of time.
    */
    private void setAckQueue(PacketPublisher$AckQueue queue)
        {
        __m_AckQueue = queue;
        }
    
    // Accessor for the property "BurstCount"
    /**
    * Setter for property BurstCount.<p>
    * The maximum number of packets to send without pausing. Anything less than
    * one (e.g. zero) means no limit.
    */
    public void setBurstCount(int cMaxPackets)
        {
        __m_BurstCount = cMaxPackets;
        }
    
    // Accessor for the property "BurstDelay"
    /**
    * Setter for property BurstDelay.<p>
    * The number of milliseconds to pause between bursts. Anything less than
    * one (e.g. zero) is treated as one.
    */
    public void setBurstDelay(int cMillis)
        {
        __m_BurstDelay = (Math.max(1, cMillis));
        }
    
    // Accessor for the property "CloggedCount"
    /**
    * Setter for property CloggedCount.<p>
    * The maximum number of packets in the send plus resend queues before
    * determining that the publisher is clogged. Zero means no limit.
    */
    public void setCloggedCount(int cMaxPackets)
        {
        __m_CloggedCount = cMaxPackets;
        }
    
    // Accessor for the property "CloggedDelay"
    /**
    * Setter for property CloggedDelay.<p>
    * The number of milliseconds to pause client threads when a clog occurs, to
    * wait for the clog to dissipate. (The pause is repeated until the clog is
    * gone.) Anything less than one (e.g. zero) is treated as one.
    */
    public void setCloggedDelay(int cMillis)
        {
        __m_CloggedDelay = (Math.max(1, cMillis));
        }
    
    // Accessor for the property "DatagramRecipient"
    /**
    * Setter for property DatagramRecipient.<p>
    * The Member to whom a directed packet is being sent, or null. Allows the
    * Datagram Listener to determine Member death on a blocking socket receive
    * call.
    */
    protected void setDatagramRecipient(_package.component.net.Member member)
        {
        __m_DatagramRecipient = member;
        }
    
    // Accessor for the property "ElementList"
    /**
    * Setter for property ElementList.<p>
    * The List that backs the Queue.
    */
    protected void setElementList(java.util.List pElementList)
        {
        __m_ElementList = pElementList;
        }
    
    // Accessor for the property "MemberSetTemp"
    /**
    * Setter for property MemberSetTemp.<p>
    * A cached MemberSet object that is used to get a snap-shot of the
    * MemberSet that a Packet is being delivered to. Used by onPacket.
    */
    protected void setMemberSetTemp(PacketPublisher$MemberSet set)
        {
        __m_MemberSetTemp = set;
        }
    
    // Accessor for the property "MessageOutgoing"
    /**
    * Setter for property MessageOutgoing.<p>
    * The dispatcher's array of outgoing Message objects.
    */
    public void setMessageOutgoing(_package.component.util.WindowedArray waMsg)
        {
        __m_MessageOutgoing = waMsg;
        }
    
    // Accessor for the property "MulticastThreshold"
    /**
    * Setter for property MulticastThreshold.<p>
    * The percentage (0.0 to 100.0) of the servers in the cluster that a packet
    * will be sent to, above which the packet will be multicasted and below
    * which it will be unicasted.
    */
    public void setMulticastThreshold(double dflThresholdPercent)
        {
        __m_MulticastThreshold = dflThresholdPercent;
        }
    
    // Accessor for the property "RequestDelay"
    /**
    * Setter for property RequestDelay.<p>
    * The minimum number of milliseconds between the queueing of an Request
    * packet and the sending of the same.
    */
    public void setRequestDelay(int cMillis)
        {
        getRequestQueue().setDelayMillis(cMillis);
        }
    
    // Accessor for the property "RequestQueue"
    /**
    * Setter for property RequestQueue.<p>
    * A reference to the AckQueue child, which is the Queue in which
    * Packet-notification Packets are placed so that they are automatically
    * after a configurable period of time.
    */
    private void setRequestQueue(PacketPublisher$RequestQueue queue)
        {
        __m_RequestQueue = queue;
        }
    
    // Accessor for the property "ResendDelay"
    /**
    * Setter for property ResendDelay.<p>
    * The minimum number of milliseconds that a Packet will remain queued in
    * the ResendQueue before being removed from the front of the Queue to be
    * resent.
    * 
    * (2-way calculated; do not design.)
    */
    public void setResendDelay(int cMillis)
        {
        $ResendQueue queue = getResendQueue();
        if (queue != null)
            {
            queue.setResendMillis(cMillis);
            }
        }
    
    // Accessor for the property "ResendQueue"
    /**
    * Setter for property ResendQueue.<p>
    * A reference to the ResendQueue child, which is the Queue in which
    * guaranteed-delivery Packets are placed so that they are automatically
    * resent.
    */
    private void setResendQueue(PacketPublisher$ResendQueue queue)
        {
        __m_ResendQueue = queue;
        }
    
    // Accessor for the property "ResendTimeout"
    /**
    * Setter for property ResendTimeout.<p>
    * The maximum number of milliseconds that a Packet will be resent before it
    * is assumed that the remaining unacknowledging Members have died.
    * 
    * (2-way calculated; do not design.)
    */
    public void setResendTimeout(int cMillis)
        {
        $ResendQueue queue = getResendQueue();
        if (queue != null)
            {
            queue.setTimeoutMillis(cMillis);
            }
        }
    
    // Accessor for the property "StatsBurst"
    /**
    * Setter for property StatsBurst.<p>
    * Statistics: total number of "bursts".
    */
    protected void setStatsBurst(long cPackets)
        {
        __m_StatsBurst = cPackets;
        }
    
    // Accessor for the property "StatsCpu"
    /**
    * Setter for property StatsCpu.<p>
    * Statistics: total time spent while sending packets.
    */
    protected void setStatsCpu(long cMillis)
        {
        __m_StatsCpu = cMillis;
        }
    
    // Accessor for the property "StatsResent"
    /**
    * Setter for property StatsResent.<p>
    * Statistics: total number of re-sent packets.
    */
    protected void setStatsResent(long cPackets)
        {
        __m_StatsResent = cPackets;
        }
    
    // Accessor for the property "StatsReset"
    /**
    * Setter for property StatsReset.<p>
    * Statistics: Date/time value that the stats have been reset.
    */
    protected void setStatsReset(long lMillis)
        {
        __m_StatsReset = lMillis;
        }
    
    // Accessor for the property "StatsSent"
    /**
    * Setter for property StatsSent.<p>
    * Statistics: total number of sent packets.
    */
    protected void setStatsSent(long cPackets)
        {
        __m_StatsSent = cPackets;
        }
    
    // Accessor for the property "UdpPacketMulticast"
    /**
    * Setter for property UdpPacketMulticast.<p>
    */
    protected void setUdpPacketMulticast(_package.component.net.UdpPacket packet)
        {
        __m_UdpPacketMulticast = packet;
        }
    
    // Accessor for the property "UdpPacketUnicast"
    /**
    * Setter for property UdpPacketUnicast.<p>
    */
    protected void setUdpPacketUnicast(_package.component.net.UdpPacket packet)
        {
        __m_UdpPacketUnicast = packet;
        }
    
    // Accessor for the property "UdpSocketMulticast"
    /**
    * Setter for property UdpSocketMulticast.<p>
    */
    public void setUdpSocketMulticast(_package.component.net.socket.udpSocket.MulticastUdpSocket socket)
        {
        // import Component.Net.Socket.UdpSocket;
        // import Component.Net.UdpPacket;
        
        _assert(getUdpSocketMulticast() == null);
        
        UdpPacket packet = null;
        if (socket != null)
            {
            packet = new UdpPacket();
            packet.setBufferLength(socket.getPacketLength());
            packet.setUdpSocket(socket);
            packet.setInetAddress(socket.getInetAddress());
            packet.setPort(socket.getPort());
            }
        
        setUdpPacketMulticast(packet);
        __m_UdpSocketMulticast = (socket);
        }
    
    // Accessor for the property "UdpSocketUnicast"
    /**
    * Setter for property UdpSocketUnicast.<p>
    */
    public void setUdpSocketUnicast(_package.component.net.socket.udpSocket.UnicastUdpSocket socket)
        {
        // import Component.Net.Socket.UdpSocket;
        // import Component.Net.UdpPacket;
        
        _assert(getUdpSocketUnicast() == null);
        
        UdpPacket packet = null;
        if (socket != null)
            {
            packet = new UdpPacket();
            packet.setBufferLength(socket.getPacketLength());
            packet.setUdpSocket(socket);
            }
        
        setUdpPacketUnicast(packet);
        __m_UdpSocketUnicast = (socket);
        }
    
    // Declared at the super level
    /**
    * Starts the daemon thread associated with this component. If the thread is
    * already starting or has started, invoking this method has no effect.
    * 
    * Synchronization is used here to verify that the start of the thread
    * occurs; the lock is obtained before the thread is started, and the daemon
    * thread notifies back that it has started from the run() method.
    */
    public synchronized void start()
        {
        if (getUdpSocketUnicast() == null)
            {
            throw new IllegalStateException("UdpSocketUnicast is required!");
            }
        
        if (getUdpSocketMulticast() == null)
            {
            throw new IllegalStateException("UdpSocketMulticast is required!");
            }
        
        super.start();
        }
    
    // Declared at the super level
    /**
    * Stops the daemon thread associated with this component.
    */
    public synchronized void stop()
        {
        super.stop();
        
        try
            {
            getUdpSocketMulticast().close();
            }
        catch (Throwable e) {}
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_Name() + ':' + formatStats();
        }
    }
