/* Class
*     _package.component.util.daemon.queueProcessor.PacketProcessor
*/

package _package.component.util.daemon.queueProcessor;

import _package.component.net.Member;
import _package.component.net.member.ClusterMember;

/**
* <br>
* A client of PacketProcessor must configure:<br>
* <br><ul>
* <li>MemberSet property</li>
* </ul><br>
* A client of PacketDispatcher may configure:<br>
* <br><ul>
* <li>Priority property</li>
* <li>ThreadGroup property</li>
* </ul><br>
* See the associated documentation for each.<br>
* <br>
* Once the PacketProcessor is configured, the client can start the processor
* using the start() method.<br>
*/
public class PacketProcessor
        extends    _package.component.util.daemon.QueueProcessor
    {
    // Fields declarations
    
    /**
    * Property Member
    *
    * Indexed property of Cluster Member objects based on the MemberSet
    * property.
    */
    
    /**
    * Property MemberId
    *
    * Once a Member id has been assigned to this Member, this property provides
    * that Member id; previous to assignment, this property evaluates to zero.
    */
    
    /**
    * Property MemberSet
    *
    * The master Member set of information about each Member.
    */
    private _package.component.net.memberSet.actualMemberSet.MasterMemberSet __m_MemberSet;
    
    /**
    * Property ThisMember
    *
    * Once a Member id has been assigned to this Member, this property provides
    * the Member object; previous to assignment, this property evaluates to
    * null.
    */
    
    // Default constructor
    public PacketProcessor()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PacketProcessor(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        _addChild(new _package.component.util.daemon.QueueProcessor$Queue("Queue", this, true), "Queue");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new PacketProcessor();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/daemon/queueProcessor/PacketProcessor".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "Member"
    /**
    * Getter for property Member.<p>
    * Indexed property of Cluster Member objects based on the MemberSet
    * property.
    */
    public _package.component.net.member.ClusterMember getMember(int i)
        {
        // import Component.Net.Member.ClusterMember;
        
        return (ClusterMember) getMemberSet().getMember(i);
        }
    
    // Accessor for the property "MemberId"
    /**
    * Getter for property MemberId.<p>
    * Once a Member id has been assigned to this Member, this property provides
    * that Member id; previous to assignment, this property evaluates to zero.
    */
    public int getMemberId()
        {
        // import Component.Net.Member;
        
        Member member = getThisMember();
        return member == null ? 0 : member.getId();  
        }
    
    // Accessor for the property "MemberSet"
    /**
    * Getter for property MemberSet.<p>
    * The master Member set of information about each Member.
    */
    public _package.component.net.memberSet.actualMemberSet.MasterMemberSet getMemberSet()
        {
        return __m_MemberSet;
        }
    
    // Accessor for the property "ThisMember"
    /**
    * Getter for property ThisMember.<p>
    * Once a Member id has been assigned to this Member, this property provides
    * the Member object; previous to assignment, this property evaluates to
    * null.
    */
    public _package.component.net.member.ClusterMember getThisMember()
        {
        // import Component.Net.Member.ClusterMember;
        
        return (ClusterMember) getMemberSet().getThisMember();
        }
    
    // Accessor for the property "MemberSet"
    /**
    * Setter for property MemberSet.<p>
    * The master Member set of information about each Member.
    */
    public void setMemberSet(_package.component.net.memberSet.actualMemberSet.MasterMemberSet set)
        {
        _assert(set != null);
        _assert(getMemberSet() == null);
        
        __m_MemberSet = (set);
        }
    
    // Declared at the super level
    /**
    * Starts the daemon thread associated with this component. If the thread is
    * already starting or has started, invoking this method has no effect.
    * 
    * Synchronization is used here to verify that the start of the thread
    * occurs; the lock is obtained before the thread is started, and the daemon
    * thread notifies back that it has started from the run() method.
    */
    public synchronized void start()
        {
        if (getMemberSet() == null)
            {
            throw new IllegalStateException("MemberSet is required!");
            }
        
        super.start();
        }
    }
