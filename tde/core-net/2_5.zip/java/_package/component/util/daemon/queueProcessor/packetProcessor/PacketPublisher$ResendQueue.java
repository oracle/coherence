/* Class
*     _package.component.util.daemon.queueProcessor.packetProcessor.PacketPublisher$ResendQueue
*/

package _package.component.util.daemon.queueProcessor.packetProcessor;

import _package.component.net.Message;
import _package.component.net.Packet;
import _package.component.net.packet.MessagePacket;
import _package.component.util.WindowedArray;
import java.util.List;

/**
* 
* The PacketPublisher's ResendQueue child is used to implement
* guaranteed-delivery; Packets are placed in the Queue so that they are
* automatically resent if they are not first acknowledged.
*/
public class PacketPublisher$ResendQueue
        extends    _package.component.util.Queue
    {
    // Fields declarations
    
    /**
    * Property MessageOutgoing
    *
    * The "windowed array" of outgoing Messages; cleaned up by the resend Queue
    * if a Packet is removed from the front  of the Queue and it has been fully
    * acknowledged.
    */
    
    /**
    * Property ResendMillis
    *
    * The minimum number of milliseconds that a Packet will remain queued in
    * the ResendQueue before being removed from the front of the Queue to be
    * resent.
    * 
    * (This property is designable.)
    */
    private int __m_ResendMillis;
    
    /**
    * Property TimeoutMillis
    *
    * The maximum number of milliseconds that a Packet will be resent before it
    * is assumed that the remaining unacknowledging Members have died.
    * 
    * (This property is designable.)
    */
    private int __m_TimeoutMillis;
    
    /**
    * Property WaitMillis
    *
    * (calculated) The number of milliseconds that the current thread should
    * rest (Object.wait) for the next Packet to be ready to come off the front
    * of the resend Queue.
    */
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Iterator", PacketPublisher$ResendQueue$Iterator.get_CLASS());
        }
    
    // Default constructor
    public PacketPublisher$ResendQueue()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PacketPublisher$ResendQueue(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setResendMillis(400);
            setTimeoutMillis(20000);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new PacketPublisher$ResendQueue();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/daemon/queueProcessor/packetProcessor/PacketPublisher$ResendQueue".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Declared at the super level
    /**
    * Appends the specified element to the end of this queue.
    * 
    * Queues may place limitations on what elements may be added to this Queue.
    *  In particular, some Queues will impose restrictions on the type of
    * elements that may be added. Queue implementations should clearly specify
    * in their documentation any restrictions on what elements may be added.
    * 
    * @param oElement element to be appended to this Queue
    * 
    * @return true (as per the general contract of the Collection.add method)
    * 
    * @throws ClassCastException if the class of the specified element prevents
    * it from being added to this Queue
    */
    public synchronized boolean add(Object oElement)
        {
        // import Component.Net.Packet.MessagePacket;
        
        MessagePacket packet      = (MessagePacket) oElement;
        long          lSentMillis = packet.getSentMillis();
        
        // reschedule send
        packet.setResendScheduled(lSentMillis + getResendMillis());
        
        // schedule timeout
        if (packet.getResendTimeout() == 0L)
            {
            packet.setResendTimeout(lSentMillis + getTimeoutMillis());
            }
        
        return super.add(packet);
        }
    
    // Accessor for the property "MessageOutgoing"
    /**
    * Getter for property MessageOutgoing.<p>
    * The "windowed array" of outgoing Messages; cleaned up by the resend Queue
    * if a Packet is removed from the front  of the Queue and it has been fully
    * acknowledged.
    */
    public _package.component.util.WindowedArray getMessageOutgoing()
        {
        return (($Module) get_Module()).getMessageOutgoing();
        }
    
    // Accessor for the property "ResendMillis"
    /**
    * Getter for property ResendMillis.<p>
    * The minimum number of milliseconds that a Packet will remain queued in
    * the ResendQueue before being removed from the front of the Queue to be
    * resent.
    * 
    * (This property is designable.)
    */
    public int getResendMillis()
        {
        return __m_ResendMillis;
        }
    
    // Accessor for the property "TimeoutMillis"
    /**
    * Getter for property TimeoutMillis.<p>
    * The maximum number of milliseconds that a Packet will be resent before it
    * is assumed that the remaining unacknowledging Members have died.
    * 
    * (This property is designable.)
    */
    public int getTimeoutMillis()
        {
        return __m_TimeoutMillis;
        }
    
    // Accessor for the property "WaitMillis"
    /**
    * Getter for property WaitMillis.<p>
    * (calculated) The number of milliseconds that the current thread should
    * rest (Object.wait) for the next Packet to be ready to come off the front
    * of the resend Queue.
    */
    public synchronized long getWaitMillis()
        {
        // import Component.Net.Packet.MessagePacket;
        // import java.util.List;
        
        List list = getElementList();
        if (list.isEmpty())
            {
            // wait forever (nothing in the list)
            return 0L;
            }
        else
            {
            long lTime = System.currentTimeMillis();
            long lNext = ((MessagePacket) list.get(0)).getResendScheduled();
            return Math.max(1L, lNext - lTime);
            }
        }
    
    // Declared at the super level
    /**
    * Waits for and removes the first element from the front of this Queue.
    * 
    * If the Queue is empty, this method will block until an element is in the
    * Queue. The unblocking equivalent of this method is "removeNoWait".
    * 
    * @return the first element in the front of this Queue
    * 
    * @see #removeNoWait
    */
    public synchronized Object remove()
        {
        // retry queue should be used only by the PacketPublisher thread
        throw new UnsupportedOperationException();
        }
    
    // Declared at the super level
    /**
    * Removes and returns the first element from the front of this Queue. If
    * the Queue is empty, no element is returned.
    * 
    * The blocking equivalent of this method is "remove".
    * 
    * @return the first element in the front of this Queue or null if the Queue
    * is empty
    * 
    * @see #remove
    */
    public synchronized Object removeNoWait()
        {
        // import Component.Net.Message;
        // import Component.Net.Packet;
        // import Component.Net.Packet.MessagePacket;
        // import Component.Util.WindowedArray;
        // import java.util.List;
        
        List list  = getElementList();
        long lTime = 0L;
        while (!list.isEmpty())
            {
            if (lTime == 0L)
                {
                lTime = System.currentTimeMillis();
                }
        
            MessagePacket packet = (MessagePacket) list.get(0);
            if (packet.isResendSkip())
                {
                // packet was already resent because of a Request
                // Packet being processed; skip this resend
                Object oRemoved = list.remove(0);
                _assert(packet == oRemoved);
                packet.setResendSkip(false);
                add(packet);
                }
            else if (packet.getResendScheduled() <= lTime)
                {
                Object oRemoved = list.remove(0);
                _assert(packet == oRemoved);
        
                CheckResend: if (packet.isResendNecessary())
                    {
                    if (packet.getResendScheduled() > packet.getResendTimeout())
                        {
                        // the remaining Members may be dead
                        (($Module) get_Module()).onUndeliverablePacket(packet);
                        if (!packet.isResendNecessary())
                            {
                            break CheckResend;
                            }
                        }
        
                    return packet;
                    }
        
                // this Packet does not need to be resent; remove
                // it from its Message and potentially remove the
                // Message altogether
                WindowedArray waMsg = getMessageOutgoing();
                synchronized (waMsg)
                    {
                    long    lMsgId = packet.getFromMessageId();
                    Message msg    = (Message) waMsg.get(lMsgId);
                    if (msg == null)
                        {
                        if (lMsgId < waMsg.getFirstIndex() - 1024 || lMsgId > waMsg.getLastIndex())
                            {
                            // red alert
                            _trace("Removing orphan packet:\n" + packet
                                    + "\nOugoing Message Array:\n" + waMsg, 1);
                            }
                        else
                            {
                            _trace("Removing orphan packet: " + lMsgId + "/"
                                    + packet.getMessagePartIndex(), 2);
                            }
        
                        // make sure it is REMOVED and not just null
                        waMsg.remove(lMsgId);
                        }
                    else
                        {
                        msg.setPacket(packet.getMessagePartIndex(), null);
                        if (msg.getNullPacketCount() == msg.getMessagePartCount())
                            {
                            waMsg.remove(lMsgId);
        
                            // if sent notification was requested, queue the
                            // message in the sending Service's queue
                            if (msg.isNotifySent())
                                {
                                msg.getService().onMessageReceipt(msg);
                                }
                            }
                        }
                    }
                }
            else
                {
                return null;
                }
            }
        
        return null;
        }
    
    // Accessor for the property "ResendMillis"
    /**
    * Setter for property ResendMillis.<p>
    * The minimum number of milliseconds that a Packet will remain queued in
    * the ResendQueue before being removed from the front of the Queue to be
    * resent.
    * 
    * (This property is designable.)
    */
    public void setResendMillis(int cMillis)
        {
        __m_ResendMillis = (Math.max(1, cMillis));
        }
    
    // Accessor for the property "TimeoutMillis"
    /**
    * Setter for property TimeoutMillis.<p>
    * The maximum number of milliseconds that a Packet will be resent before it
    * is assumed that the remaining unacknowledging Members have died.
    * 
    * (This property is designable.)
    */
    public void setTimeoutMillis(int cMillis)
        {
        __m_TimeoutMillis = (Math.max(1, cMillis));
        }
    }
