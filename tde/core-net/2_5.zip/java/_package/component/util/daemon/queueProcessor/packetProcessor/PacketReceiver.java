/* Class
*     _package.component.util.daemon.queueProcessor.packetProcessor.PacketReceiver
*/

package _package.component.util.daemon.queueProcessor.packetProcessor;

import _package.component.net.Member;
import _package.component.net.Message;
import _package.component.net.Packet;
import _package.component.net.member.ClusterMember;
import _package.component.net.packet.MessagePacket;
import _package.component.net.packet.messagePacket.Broadcast;
import _package.component.net.packet.messagePacket.Directed;
import _package.component.net.packet.messagePacket.Sequel;
import _package.component.net.packet.notifyPacket.Ack;
import _package.component.net.packet.notifyPacket.Request;
import _package.component.util.Queue;
import _package.component.util.WindowedArray;
import _package.component.util.daemon.queueProcessor.Service;
import com.tangosol.util.FilterEnumerator;
import com.tangosol.util.LongArray;
import com.tangosol.util.NullFilter;
import com.tangosol.util.SimpleLongArray;
import java.util.Iterator;

/**
* 
* --
* 
* A client of PacketReceiver must additionally configure:
* - SendQueue property
* - MessageOutgoing property
* 
* Once the Member mini-id is assigned to this Member, the onJoined event must
* be triggered.
* 
* The following properties need to be updated as other Cluster-enabled Services
* are added to this Member:
* - Service property
*/
public class PacketReceiver
        extends    _package.component.util.daemon.queueProcessor.PacketProcessor
    {
    // Fields declarations
    
    /**
    * Property MaxAckNotifyCount
    *
    */
    private transient int __m_MaxAckNotifyCount;
    
    /**
    * Property MaximumPacketLength
    *
    * The absolute maximum number of bytes that can be placed into an outgoing
    * Packet. Used here to figure out how many ACK could be coalessed together.
    * 
    * @see ClusterConfig
    */
    private int __m_MaximumPacketLength;
    
    /**
    * Property MessageOutgoing
    *
    * @see PacketDispatcher#MessageOutgoing
    */
    private _package.component.util.WindowedArray __m_MessageOutgoing;
    
    /**
    * Property MessageQueue
    *
    * Stores the Message Queue for each Service.
    */
    
    /**
    * Property SendQueue
    *
    * The outgoing Packet Queue of the PacketPublisher.
    */
    private _package.component.util.Queue __m_SendQueue;
    
    /**
    * Property Service
    *
    * Indexed property of Services that are running on this Member. The Service
    * is used to instantiate Message objects from incoming Packet information.
    */
    private _package.component.util.daemon.queueProcessor.Service[] __m_Service;
    
    /**
    * Property StatsCpu
    *
    * Statistics: total time spent while receiving packets.
    */
    private transient long __m_StatsCpu;
    
    /**
    * Property StatsReceived
    *
    * Statistics: total number of received packets.
    */
    private transient long __m_StatsReceived;
    
    /**
    * Property StatsRepeated
    *
    * Statistics: number of repeated packets (recieved more then once)
    */
    private transient long __m_StatsRepeated;
    
    /**
    * Property StatsReset
    *
    * Statistics: Date/time value that the stats have been reset.
    */
    private transient long __m_StatsReset;
    
    /**
    * Property ThisMemberSet
    *
    * A cached set of one Member -- this Member. Used to fake the "to"
    * MemberSet for each incoming Message that is addressed to this Member.
    * (Note that the other "to" information is discarded in the case of
    * Messages sent to multiple Members.)
    */
    private PacketReceiver$ThisMemberSet __m_ThisMemberSet;
    
    /**
    * Property UseRequestPacket
    *
    * If true, the Receiver will use Request Packets to negatively acknowledge
    * missing packets.
    */
    private boolean __m_UseRequestPacket;
    
    // Default constructor
    public PacketReceiver()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PacketReceiver(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setUseRequestPacket(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new _package.component.util.daemon.QueueProcessor$Queue("Queue", this, true), "Queue");
        _addChild(new PacketReceiver$ThisMemberSet("ThisMemberSet", this, true), "ThisMemberSet");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new PacketReceiver();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/daemon/queueProcessor/packetProcessor/PacketReceiver".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    protected void checkReadyMessages(_package.component.net.member.ClusterMember member)
        {
        // import Component.Net.Member.ClusterMember;
        // import Component.Net.Message;
        // import Component.Util.WindowedArray;
        // import com.tangosol.util.LongArray;
        
        // check for completed Messages from the Member
        WindowedArray waMsg   = member.getMessageIncoming();
        long          lMsgId  = waMsg.getFirstIndex();
        Message       msg     = (Message) waMsg.get(lMsgId);
        LongArray     laPile  = member.getMessagePile();
        while (msg != null && msg.getNullPacketCount() == 0)
            {
            // remove the Message from the Message window array
            // and the "pile" and update the global Message
            // counter kept for the "from" Member so that
            // repeated Sequel Packets for already-processed
            // Messages will be discarded
            waMsg.remove(lMsgId);
        
            long lFromMsgId = msg.getFromMessageId();
            if (msg.getMessagePartCount() > 1)
                {
                laPile.remove(lFromMsgId);
                }
            member.setMessageIncomingCount(lFromMsgId);
        
            // process Message
            onMessage(msg);
        
            // proceed to next Message in the window
            msg = (Message) waMsg.get(++lMsgId);
            }
        }
    
    protected void confirm(_package.component.net.packet.MessagePacket packet)
        {
        // import Component.Net.Member.ClusterMember;
        // import Component.Net.Packet.NotifyPacket.Ack;
        // import Component.Util.Queue;
        
        int           nFromId    = packet.getFromId();
        ClusterMember memberFrom = (ClusterMember) getMemberSet().getMember(nFromId);
        if (memberFrom != null)
            {
            Queue queue = getSendQueue();
            synchronized (queue)
                {
                Ack packetAck = memberFrom.getPacketAck();
                if (packetAck == null ||
                    packetAck.getNotifyCount() >= getMaxAckNotifyCount())
                    {
                    packetAck = new Ack();
                    packetAck.setFromId(getMemberId());
                    packetAck.setToId(nFromId);
                    queue.add(packetAck);
                    // at this point the following holds true
                    // memberFrom.getPacketAck() == packetAck
                    }
                packetAck.addPacket(packet);
                }
            }
        }
    
    public String formatStats()
        {
        long   cCpu      = getStatsCpu();
        long   cTotal    = System.currentTimeMillis() - getStartTimestamp();
        long   lReceived = getStatsReceived();
        long   lRepeated = getStatsRepeated();
        double dCpu      = cTotal == 0L ? 0.0 : ((double) cCpu)/((double) cTotal);
        double dSuccess  = lReceived == 0L ? 1.0 : 1.0 - ((double) lRepeated)/((double) lReceived);
        
        return "Cpu=" + cCpu + "ms (" + (float) dCpu + "%)"
               + ", PacketsReceived=" + lReceived
               + ", PacketsRepeated=" + lRepeated
               + ", SuccessRate="     + (float) dSuccess
               ;
        }
    
    // Accessor for the property "MaxAckNotifyCount"
    /**
    * Getter for property MaxAckNotifyCount.<p>
    */
    public int getMaxAckNotifyCount()
        {
        return __m_MaxAckNotifyCount;
        }
    
    // Accessor for the property "MaximumPacketLength"
    /**
    * Getter for property MaximumPacketLength.<p>
    * The absolute maximum number of bytes that can be placed into an outgoing
    * Packet. Used here to figure out how many ACK could be coalessed together.
    * 
    * @see ClusterConfig
    */
    public int getMaximumPacketLength()
        {
        return __m_MaximumPacketLength;
        }
    
    // Accessor for the property "MessageOutgoing"
    /**
    * Getter for property MessageOutgoing.<p>
    * @see PacketDispatcher#MessageOutgoing
    */
    public _package.component.util.WindowedArray getMessageOutgoing()
        {
        return __m_MessageOutgoing;
        }
    
    // Accessor for the property "MessageQueue"
    /**
    * Getter for property MessageQueue.<p>
    * Stores the Message Queue for each Service.
    */
    public _package.component.util.Queue getMessageQueue(int i)
        {
        // import Component.Util.Daemon.QueueProcessor.Service;
        
        Service service = getService(i);
        return service == null ? null : service.getQueue();
        }
    
    // Accessor for the property "SendQueue"
    /**
    * Getter for property SendQueue.<p>
    * The outgoing Packet Queue of the PacketPublisher.
    */
    public _package.component.util.Queue getSendQueue()
        {
        return __m_SendQueue;
        }
    
    // Accessor for the property "Service"
    /**
    * Getter for property Service.<p>
    * Indexed property of Services that are running on this Member. The Service
    * is used to instantiate Message objects from incoming Packet information.
    */
    protected _package.component.util.daemon.queueProcessor.Service[] getService()
        {
        return __m_Service;
        }
    
    // Accessor for the property "Service"
    /**
    * Getter for property Service.<p>
    * Indexed property of Services that are running on this Member. The Service
    * is used to instantiate Message objects from incoming Packet information.
    */
    public _package.component.util.daemon.queueProcessor.Service getService(int i)
        {
        // import Component.Util.Daemon.QueueProcessor.Service;
        
        Service[] aService = getService();
        return aService != null && i < aService.length ? aService[i] : null;
        }
    
    // Accessor for the property "StatsCpu"
    /**
    * Getter for property StatsCpu.<p>
    * Statistics: total time spent while receiving packets.
    */
    public long getStatsCpu()
        {
        return __m_StatsCpu;
        }
    
    // Accessor for the property "StatsReceived"
    /**
    * Getter for property StatsReceived.<p>
    * Statistics: total number of received packets.
    */
    public long getStatsReceived()
        {
        return __m_StatsReceived;
        }
    
    // Accessor for the property "StatsRepeated"
    /**
    * Getter for property StatsRepeated.<p>
    * Statistics: number of repeated packets (recieved more then once)
    */
    public long getStatsRepeated()
        {
        return __m_StatsRepeated;
        }
    
    // Accessor for the property "StatsReset"
    /**
    * Getter for property StatsReset.<p>
    * Statistics: Date/time value that the stats have been reset.
    */
    public long getStatsReset()
        {
        return __m_StatsReset;
        }
    
    // Accessor for the property "ThisMemberSet"
    /**
    * Getter for property ThisMemberSet.<p>
    * A cached set of one Member -- this Member. Used to fake the "to"
    * MemberSet for each incoming Message that is addressed to this Member.
    * (Note that the other "to" information is discarded in the case of
    * Messages sent to multiple Members.)
    */
    public PacketReceiver$ThisMemberSet getThisMemberSet()
        {
        return __m_ThisMemberSet;
        }
    
    /**
    * Instantiate a new Message for the specified packet. If the corresponding
    * service has terminated, make a "serviceless" packet to be discarded
    * later.
    * 
    * @param packet  the packet
    * 
    * @return  a newly instantiated message (must not be null)
    */
    protected _package.component.net.Message instantiateMessage(_package.component.net.packet.MessagePacket packet)
        {
        // import Component.Net.Message;
        // import Component.Util.Daemon.QueueProcessor.Service;
        
        Message msg;
        int     nType   = packet.getMessageType();
        Service service = getService(packet.getServiceId());
        
        if (service == null)
            {
            // There is no Service for incoming packet;
            // we have to create a "serviceless" message to collect all the
            // Sequel packages and discard the message later at onMessage()
            msg = new Message();
            }
        else
            {
            // make message
            msg = service.instantiateMessage(nType);
            if (msg == null)
                {
                throw new IllegalStateException("Failed to instantiate Message Type="
                    + nType + " for Service=" + service.getServiceName());
                }
            }
        
        // configure message
        msg.setIncoming(true);
        msg.setMessageType(nType);
        msg.setFromMember(getMember(packet.getFromId()));
        msg.setToMemberSet(getThisMemberSet());
        msg.setMessagePartCount(packet.getMessagePartCount());
        msg.setPacket(0, packet);
        
        return msg;
        }
    
    // Accessor for the property "UseRequestPacket"
    /**
    * Getter for property UseRequestPacket.<p>
    * If true, the Receiver will use Request Packets to negatively acknowledge
    * missing packets.
    */
    public boolean isUseRequestPacket()
        {
        return __m_UseRequestPacket;
        }
    
    // Declared at the super level
    /**
    * Event notification called once the daemon's thread starts and before the
    * daemon thread goes into the "wait - perform" loop. Unlike the
    * <code>onInit()</code> event, this method executes on the daemon's thread.
    * 
    * Note1: this method is called while the caller's thread is still waiting
    * for a notification to  "unblock" itself.
    * Note2: any exception thrown by this method will terminate the thread
    * immediately
    */
    protected void onEnter()
        {
        super.onEnter();
        
        resetStats();
        }
    
    public void onJoined()
        {
        // import Component.Net.Member.ClusterMember;
        
        $ThisMemberSet setMember = getThisMemberSet();
        if (setMember == null)
            {
            setMember = ($ThisMemberSet) _findName("ThisMemberSet");
            _assert(setMember != null);
        
            ClusterMember member = getThisMember();
            _assert(member != null);
            _assert(member.getId() != 0);
        
            setMember.add(member);
            setThisMemberSet(setMember);
            }
        }
    
    public void onMessage(_package.component.net.Message msg)
        {
        // import Component.Util.Daemon.QueueProcessor.Service;
        
        // discard a message that came after the service has been stopped
        Service service = msg.getService();
        if (service != null)
            {
            service.getQueue().add(msg);
            }
        }
    
    // Declared at the super level
    /**
    * Event notification to perform a regular daemon activity. To get it
    * called, another thread has to set Notification to true:
    * <code>daemon.setNotification(true);</code>
    * 
    * @see #onWait
    */
    protected void onNotify()
        {
        // import Component.Net.Packet;
        
        long lStart = System.currentTimeMillis();
        
        while (!isExiting())
            {
            Packet packet = (Packet) getQueue().removeNoWait();
            if (packet == null)
                {
                break;
                }
            else
                {
                onPacket(packet);
                }
            }
        
        setStatsCpu(getStatsCpu() + (System.currentTimeMillis() - lStart));
        }
    
    protected void onPacket(_package.component.net.Packet packet)
        {
        // import Component.Net.Message;
        // import Component.Net.Packet;
        // import Component.Net.Packet.MessagePacket;
        // import Component.Net.Packet.MessagePacket.Broadcast;
        // import Component.Net.Packet.MessagePacket.Directed;
        // import Component.Net.Packet.MessagePacket.Sequel;
        // import Component.Net.Packet.NotifyPacket.Ack;
        // import Component.Net.Packet.NotifyPacket.Request;
        // import Component.Util.WindowedArray;
        
        setStatsReceived(getStatsReceived() + 1);
        
        // acknowledge the Packet
        if (packet.isConfirmationRequired())
            {
            confirm((MessagePacket) packet);
            }
        
        int nType = packet.getPacketType();
        switch (nType)
            {
            case Packet.TYPE_BROADCAST:
                onPacketBroadcast((Broadcast) packet);
                break;
        
            case Packet.TYPE_DIRECTED_ONE:
            case Packet.TYPE_DIRECTED_FEW:
            case Packet.TYPE_DIRECTED_MANY:
                onPacketDirected((Directed) packet);
                break;
        
            case Packet.TYPE_SEQUEL_ONE:
            case Packet.TYPE_SEQUEL_FEW:
            case Packet.TYPE_SEQUEL_MANY:
                onPacketSequel((Sequel) packet);
                break;
        
            case Packet.TYPE_REQUEST:
                onPacketRequest((Request) packet);
                break;
        
            case Packet.TYPE_ACK:
                onPacketAck((Ack) packet);
                break;
        
            default:
                throw new IllegalArgumentException("unknown packet type: " + nType);
            }
        }
    
    protected void onPacketAck(_package.component.net.packet.notifyPacket.Ack packet)
        {
        // import Component.Net.Member;
        // import Component.Net.Message;
        // import Component.Net.Packet;
        // import Component.Net.Packet.MessagePacket;
        // import Component.Util.WindowedArray;
        
        Member member = getMemberSet().getMember(packet.getFromId());
        if (member != null)
            {
            WindowedArray waMsg    = getMessageOutgoing();
            long         lMsgFirst = waMsg.getFirstIndex();
        
            for (int i = 0, c = packet.getNotifyCount(); i < c; ++i)
                {
                // turn the 3-byte msg id into the real (long) msg id
                long lMsgId = Packet.translateTrint(packet.getMessageId(i), lMsgFirst);
        
                // find the Message
                Message msg = (Message) waMsg.get(lMsgId);
                if (msg != null)
                    {
                    // find the Packet
                    int           nMsgPart  = packet.getMessagePartIndex(i);
                    MessagePacket packetMsg = msg.getPacket(nMsgPart);
                    if (packetMsg != null)
                        {
                        // the Member that sends an Ack Packet is removed from
                        // the "to" portion of the corresponding Packet
                        packetMsg.registerAck(member);
                        }
                    }
                }
            }
        }
    
    protected void onPacketBroadcast(_package.component.net.packet.messagePacket.Broadcast packet)
        {
        // import Component.Net.Message;
        
        Message msg = instantiateMessage(packet);
        
        onMessage(msg);
        }
    
    protected void onPacketDirected(_package.component.net.packet.messagePacket.Directed packet)
        {
        // import Component.Net.Member.ClusterMember;
        // import Component.Net.Message;
        // import Component.Net.Packet;
        // import Component.Net.Packet.MessagePacket.Sequel;
        // import Component.Util.WindowedArray;
        // import com.tangosol.util.FilterEnumerator;
        // import com.tangosol.util.LongArray;
        // import com.tangosol.util.NullFilter;
        // import java.util.Iterator;
        
        ClusterMember member = getMember(packet.getFromId());
        if (member != null)
            {
            // the array of incoming Messages from the Member that sent the packet
            WindowedArray waMsg = member.getMessageIncoming();
        
            // the point-to-point Message id assigned to the Message that the
            // Directed Packet is the "header" for (ie. first or only part of)
            long lMsgFirst = waMsg.getFirstIndex();
            long lToMsgId  = Packet.translateTrint(packet.getToMessageId(), lMsgFirst);
            if (lToMsgId >= lMsgFirst && waMsg.get(lToMsgId) == null)
                {
                // the Message has not yet been processed and it does not
                // exist; instantiate it and add it to the array
                Message msg = instantiateMessage(packet);
                waMsg.set(lToMsgId, msg);
        
                // check to see if any parts of the Message are in the pile;
                // the "pile" is a Map keyed by Message id (type Long) with
                // the corresponding value being a List of Sequel Packets
                LongArray laPile     = member.getMessagePile();
                long      lFromMsgId = Packet.translateTrint(
                        (int) packet.getFromMessageId(),
                        member.getMessageIncomingCount());
                msg.setFromMessageId(lFromMsgId);
                if (msg.getMessagePartCount() > 1)
                    {
                    // grab any Packets already in the sequel pile
                    if (!laPile.isEmpty())
                        {
                        LongArray laSequel = (LongArray) laPile.get(lFromMsgId);
                        if (laSequel != null)
                            {
                            for (Iterator iter = laSequel.iterator(); iter.hasNext(); )
                                {
                                Sequel packetSequel = (Sequel) iter.next();
                                msg.setPacket(packetSequel.getMessagePartIndex(),
                                        packetSequel);
                                }
                            }
                        }
        
                    // put the Message into the Map so subsequent
                    // sequel Packets can "find their way home"
                    laPile.set(lFromMsgId, msg);
                    }
        
                // check for completed Messages in the array
                if (lToMsgId == lMsgFirst)
                    {
                    checkReadyMessages(member);
                    }
                else if (isUseRequestPacket())
                    {
                    /* TODO:
        
                    long    lMsgReq = lToMsgId - 1;
                    Message msgReq  = (Message) waMsg.get(lMsgReq);
                    if (msgReq != null && msgReq.getPacket(
                            msgReq.getMessagePartCount() - 1) == null)
                        {
                        long = msgReq.getFromMsgId
                        // request any packets missing immediately before
                        // this one
                        while (msgReq.getNullPacketCount() == msgReq.getMessagePartCount()
                                 && lMsgReq > lMsgFirst)
                            {
                            msgReq = (Message) waMsg.get(--lMsgReq);
                            }
        
                        // request all missing packets
                        int nFromId = packet.getFromId();
                        while (lMsgReq < lToMsgId)
                            {
                            // request the trailing missing packets
                            msgReq = (Message) waMsg.get(lMsgReq);
                            
                            int nPacket  = 0;
                            int cPackets = msgReq.getMessagePartCount();
                            if (msgReq.getNullPacketCount() != cPackets)
                                {
                                nPacket = cPackets - 1;
                                while (nPacket > 0
                                     && msgReq.getPacket(nPacket) == null)
                                    {
                                    --nPacket;
                                    }
                                }
        
                            while (nPacket < cPackets)
                                {
                                request(nFromId, lMsgReq, nPacket);
                                ++nPacket;
                                }
                                                
                            ++lMsgReq;
                            }
                        }
        
                    also:
                    - use getMaxRequestNotifyCount() in "request()"
                    */
                    }
                }
            else
                {
                setStatsRepeated(getStatsRepeated() + 1);
                }
            }
        }
    
    protected void onPacketRequest(_package.component.net.packet.notifyPacket.Request packet)
        {
        // import Component.Net.Member;
        // import Component.Net.Message;
        // import Component.Net.Packet;
        // import Component.Net.Packet.MessagePacket;
        // import Component.Util.Queue;
        // import Component.Util.WindowedArray;
        
        Member member = getMemberSet().getMember(packet.getFromId());
        if (member != null)
            {
            WindowedArray waMsg    = getMessageOutgoing();
            long         lMsgFirst = waMsg.getFirstIndex();
            for (int i = 0, c = packet.getNotifyCount(); i < c; ++i)
                {
                // turn the 3-byte msg id into the real (long) msg id
                long lMsgId = Packet.translateTrint(packet.getMessageId(i), lMsgFirst);
        
                // find the Message
                Message msg = (Message) waMsg.get(lMsgId);
                if (msg != null)
                    {
                    // find the Packet
                    int nMsgPart = packet.getMessagePartIndex(i);
                    MessagePacket packetMsg = msg.getPacket(nMsgPart);
                    // only process the Request if the Packet is still
                    // available (i.e. hasn't been completely acknowledged)
                    if (packetMsg != null)
                        {
                        // only process the Request if the Packet is
                        // not currently being resent due to another
                        // Request Packet
                        if (!packetMsg.isResendRequestInProgress())
                            {
                            packetMsg.setResendRequestInProgress(true);
                            packetMsg.setResendSkip(true);
                            getQueue().add(packetMsg);
                            }
                        }
                    }
                }
            }
        }
    
    protected void onPacketSequel(_package.component.net.packet.messagePacket.Sequel packet)
        {
        // import Component.Net.Member.ClusterMember;
        // import Component.Net.Message;
        // import Component.Net.Packet;
        // import Component.Net.Packet.MessagePacket.Directed;
        // import Component.Util.WindowedArray;
        // import com.tangosol.util.LongArray;
        // import com.tangosol.util.SimpleLongArray;
        
        ClusterMember member = getMember(packet.getFromId());
        if (member != null)
            {
            // the "pile" of Packets/Messages from the Member
            LongArray laPile     = member.getMessagePile();
            long      lLastMsgId = member.getMessageIncomingCount();
            long      lFromMsgId = Packet.translateTrint(
                                    (int) packet.getFromMessageId(), lLastMsgId);
            boolean   fRepeated = false;
        
            if (lFromMsgId > lLastMsgId)
                {
                int    iPart = packet.getMessagePartIndex();
                Object oVal  = laPile.get(lFromMsgId);
        
                if (oVal instanceof Message)
                    {
                    // the Pile contains the Message; add Packet to Message
                    Message msg = (Message) oVal;
                    if (msg.getPacket(iPart) == null)
                        {
                        msg.setPacket(iPart, packet);
        
                        // the array of incoming Messages from the Member that sent the packet
                        WindowedArray waMsg = member.getMessageIncoming();
        
                        // it is possible that this Sequel Packet was the last
                        // Packet to complete a Message
                        if (msg == waMsg.get(waMsg.getFirstIndex()))
                            {
                            checkReadyMessages(member);
                            }
                        }
                    else
                        {
                        fRepeated = true;
                        }
                    }
                else
                    {
                    // the Pile contains a List of Sequel Packets; the
                    // Message does not exist yet because the Directed
                    // Packet that heads the Message has not yet been
                    // received
                    LongArray laSequel = (LongArray) oVal;
                    if (laSequel == null)
                        {
                        // instantiate long-array of sequel packets
                        laSequel = new SimpleLongArray();
        
                        // store the long-array of sequel packets
                        // under the only message id that we have,
                        // which is the message id as known by the
                        // sender (not this member's message id,
                        // which will come in the directed packet
                        // from which the message will be created)
                        laPile.set(lFromMsgId, laSequel);
                        }
                    else
                        {
                        fRepeated = (laSequel.get(iPart) != null);
                        }
        
                    if (!fRepeated)
                        {                
                        // store the sequel packet with any others for this
                        // message that arrived before the directed packet
                        laSequel.set(iPart, packet);
                        }
                    }
                }
            else
                {
                fRepeated = true;
                }
        
            if (fRepeated)
                {
                setStatsRepeated(getStatsRepeated() + 1);
                }
            }
        }
    
    protected void request(int nFromId, long lMsg, int nPacket)
        {
        // import Component.Net.Member.ClusterMember;
        // import Component.Net.Packet.NotifyPacket.Request;
        // import Component.Util.Queue;
        
        ClusterMember memberFrom = (ClusterMember) getMemberSet().getMember(nFromId);
        if (memberFrom != null)
            {
            Queue queue = getSendQueue();
            synchronized (queue)
                {
                Request packetReq = memberFrom.getPacketRequest();
                if (packetReq == null || packetReq.getNotifyCount() >= getMaxAckNotifyCount())
                    {
                    packetReq = new Request();
                    packetReq.setFromId(getMemberId());
                    packetReq.setToId(nFromId);
                    queue.add(packetReq);
                    // at this point the following holds true
                    // memberFrom.getPacketRequest() == packetReq
                    }
                packetReq.addPacket(packetReq.makeTrint(lMsg), nPacket);
                }
            }
        }
    
    /**
    * Reset the statistics.
    */
    public void resetStats()
        {
        setStatsReceived(0L);
        setStatsRepeated(0L);
        setStatsCpu     (0L);
        setStatsReset   (System.currentTimeMillis());
        }
    
    // Accessor for the property "MaxAckNotifyCount"
    /**
    * Setter for property MaxAckNotifyCount.<p>
    */
    protected void setMaxAckNotifyCount(int nCount)
        {
        __m_MaxAckNotifyCount = nCount;
        }
    
    // Accessor for the property "MaximumPacketLength"
    /**
    * Setter for property MaximumPacketLength.<p>
    * The absolute maximum number of bytes that can be placed into an outgoing
    * Packet. Used here to figure out how many ACK could be coalessed together.
    * 
    * @see ClusterConfig
    */
    public void setMaximumPacketLength(int cbMax)
        {
        // import Component.Net.Packet.NotifyPacket.Ack;
        
        _assert(getMaximumPacketLength() == 0,
            "MaximumPacketLength is not resettable");
        
        __m_MaximumPacketLength = (cbMax);
        
        setMaxAckNotifyCount((cbMax - Ack.LENGTH_FIXED) / Ack.LENGTH_VARIABLE);
        }
    
    // Accessor for the property "MessageOutgoing"
    /**
    * Setter for property MessageOutgoing.<p>
    * @see PacketDispatcher#MessageOutgoing
    */
    public void setMessageOutgoing(_package.component.util.WindowedArray pMessageOutgoing)
        {
        __m_MessageOutgoing = pMessageOutgoing;
        }
    
    // Accessor for the property "SendQueue"
    /**
    * Setter for property SendQueue.<p>
    * The outgoing Packet Queue of the PacketPublisher.
    */
    public void setSendQueue(_package.component.util.Queue queue)
        {
        _assert(queue != null);
        _assert(getSendQueue() == null);
        
        __m_SendQueue = (queue);
        }
    
    // Accessor for the property "Service"
    /**
    * Setter for property Service.<p>
    * Indexed property of Services that are running on this Member. The Service
    * is used to instantiate Message objects from incoming Packet information.
    */
    protected void setService(_package.component.util.daemon.queueProcessor.Service[] aService)
        {
        __m_Service = aService;
        }
    
    // Accessor for the property "Service"
    /**
    * Setter for property Service.<p>
    * Indexed property of Services that are running on this Member. The Service
    * is used to instantiate Message objects from incoming Packet information.
    */
    public void setService(int i, _package.component.util.daemon.queueProcessor.Service service)
        {
        // import Component.Util.Daemon.QueueProcessor.Service;
        
        Service[] aService = getService();
        
        if (aService == null || i >= aService.length)
            {
            // resize, making the array bigger than necessary (avoid resizes)
            int       cNew        = Math.max(i + (i >>> 1), i + 4);
            Service[] aServiceNew = new Service[cNew];
        
            // copy original data
            if (aService != null)
                {
                System.arraycopy(aService, 0, aServiceNew, 0, aService.length);
                }
        
            setService(aService = aServiceNew);
            }
        
        aService[i] = service;
        }
    
    // Accessor for the property "StatsCpu"
    /**
    * Setter for property StatsCpu.<p>
    * Statistics: total time spent while receiving packets.
    */
    protected void setStatsCpu(long cMillis)
        {
        __m_StatsCpu = cMillis;
        }
    
    // Accessor for the property "StatsReceived"
    /**
    * Setter for property StatsReceived.<p>
    * Statistics: total number of received packets.
    */
    protected void setStatsReceived(long cPackets)
        {
        __m_StatsReceived = cPackets;
        }
    
    // Accessor for the property "StatsRepeated"
    /**
    * Setter for property StatsRepeated.<p>
    * Statistics: number of repeated packets (recieved more then once)
    */
    protected void setStatsRepeated(long cPackets)
        {
        __m_StatsRepeated = cPackets;
        }
    
    // Accessor for the property "StatsReset"
    /**
    * Setter for property StatsReset.<p>
    * Statistics: Date/time value that the stats have been reset.
    */
    protected void setStatsReset(long lMillis)
        {
        __m_StatsReset = lMillis;
        }
    
    // Accessor for the property "ThisMemberSet"
    /**
    * Setter for property ThisMemberSet.<p>
    * A cached set of one Member -- this Member. Used to fake the "to"
    * MemberSet for each incoming Message that is addressed to this Member.
    * (Note that the other "to" information is discarded in the case of
    * Messages sent to multiple Members.)
    */
    protected void setThisMemberSet(PacketReceiver$ThisMemberSet setMember)
        {
        __m_ThisMemberSet = setMember;
        }
    
    // Accessor for the property "UseRequestPacket"
    /**
    * Setter for property UseRequestPacket.<p>
    * If true, the Receiver will use Request Packets to negatively acknowledge
    * missing packets.
    */
    public void setUseRequestPacket(boolean pUseRequestPacket)
        {
        __m_UseRequestPacket = pUseRequestPacket;
        }
    
    // Declared at the super level
    /**
    * Starts the daemon thread associated with this component. If the thread is
    * already starting or has started, invoking this method has no effect.
    * 
    * Synchronization is used here to verify that the start of the thread
    * occurs; the lock is obtained before the thread is started, and the daemon
    * thread notifies back that it has started from the run() method.
    */
    public synchronized void start()
        {
        if (getSendQueue() == null)
            {
            throw new IllegalStateException("SendQueue is required!");
            }
        
        if (getMessageOutgoing() == null)
            {
            throw new IllegalStateException("MessageOutgoing is required!");
            }
        
        super.start();
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_Name() + ':' + formatStats();
        }
    }
