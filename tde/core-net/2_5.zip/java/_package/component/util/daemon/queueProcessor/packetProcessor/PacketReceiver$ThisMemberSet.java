/* Class
*     _package.component.util.daemon.queueProcessor.packetProcessor.PacketReceiver$ThisMemberSet
*/

package _package.component.util.daemon.queueProcessor.packetProcessor;

import _package.component.net.member.ClusterMember;

/**
* 
* ThisMemberSet is a MemberSet of one member: the "this" Member.
*/
public class PacketReceiver$ThisMemberSet
        extends    _package.component.net.memberSet.ActualMemberSet
    {
    // Fields declarations
    
    /**
    * Property ThisMember
    *
    * (calculated) Determines the "this" Member object.
    */
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Iterator", PacketReceiver$ThisMemberSet$Iterator.get_CLASS());
        }
    
    // Default constructor
    public PacketReceiver$ThisMemberSet()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PacketReceiver$ThisMemberSet(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new PacketReceiver$ThisMemberSet();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/daemon/queueProcessor/packetProcessor/PacketReceiver$ThisMemberSet".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Declared at the super level
    public synchronized boolean add(Object o)
        {
        if (o == getThisMember())
            {
            return super.add(o);
            }
        
        throw new UnsupportedOperationException();
        }
    
    // Declared at the super level
    public synchronized boolean addAll(java.util.Collection collection)
        {
        throw new UnsupportedOperationException();
        }
    
    // Declared at the super level
    public synchronized void clear()
        {
        throw new UnsupportedOperationException();
        }
    
    // Accessor for the property "ThisMember"
    /**
    * Getter for property ThisMember.<p>
    * (calculated) Determines the "this" Member object.
    */
    public _package.component.net.member.ClusterMember getThisMember()
        {
        // import Component.Net.Member.ClusterMember;
        
        return (($Module) get_Module()).getThisMember();
        }
    
    // Declared at the super level
    public synchronized boolean isEmpty()
        {
        return false;
        }
    
    // Declared at the super level
    public synchronized boolean remove(Object o)
        {
        throw new UnsupportedOperationException();
        }
    
    // Declared at the super level
    public synchronized boolean removeAll(java.util.Collection collection)
        {
        throw new UnsupportedOperationException();
        }
    
    // Declared at the super level
    public synchronized boolean retainAll(java.util.Collection collection)
        {
        throw new UnsupportedOperationException();
        }
    
    // Declared at the super level
    public synchronized int size()
        {
        return 1;
        }
    }
