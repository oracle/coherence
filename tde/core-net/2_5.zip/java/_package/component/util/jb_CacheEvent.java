/* Class
*      jb_CacheEvent
*
* automatically generated "Feed" which
* a) extends an external bean:
*      com.tangosol.util.MapEvent
* b) delegates to the peer component:
*      Component.Util.CacheEvent
*/

package _package.component.util;

public class jb_CacheEvent
        extends    com.tangosol.util.MapEvent
        implements com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected CacheEvent __peer;
    
    private static CacheEvent __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            CacheEvent peer = (CacheEvent)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // parameterized constructor
    public jb_CacheEvent(com.tangosol.util.ObservableMap map, int nId, Object oKey, Object oValueOld, Object oValueNew)
        {
        this(map, nId, oKey, oValueOld, oValueNew, CacheEvent.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_CacheEvent(com.tangosol.util.ObservableMap map, int nId, Object oKey, Object oValueOld, Object oValueNew, Class clzPeer)
        {
        this(map, nId, oKey, oValueOld, oValueNew, __createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_CacheEvent(com.tangosol.util.ObservableMap map, int nId, Object oKey, Object oValueOld, Object oValueNew, CacheEvent peer, boolean fInit)
        {
        super(map, nId, oKey, oValueOld, oValueNew);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private CacheEvent __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (CacheEvent) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_CacheEvent(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    public void dispatch(com.tangosol.util.Listeners listeners)
        {
        CacheEvent peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.dispatch(listeners);
        }
    void super$dispatch(com.tangosol.util.Listeners listeners)
        {
        super.dispatch(listeners);
        }
    public int getId()
        {
        CacheEvent peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getId();
        }
    int super$getId()
        {
        return super.getId();
        }
    public Object getKey()
        {
        CacheEvent peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getKey();
        }
    Object super$getKey()
        {
        return super.getKey();
        }
    public Object getNewValue()
        {
        CacheEvent peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getNewValue();
        }
    Object super$getNewValue()
        {
        return super.getNewValue();
        }
    public Object getOldValue()
        {
        CacheEvent peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getOldValue();
        }
    Object super$getOldValue()
        {
        return super.getOldValue();
        }
    public Object getSource()
        {
        CacheEvent peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getSource();
        }
    Object super$getSource()
        {
        return super.getSource();
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
