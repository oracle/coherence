/* Class
*     _package.component.util.CacheEvent
*/

package _package.component.util;

import com.tangosol.net.NamedCache;
import com.tangosol.util.Listeners;
import com.tangosol.util.MapEvent;
import com.tangosol.util.MapListener;
import com.tangosol.util.MapListenerSupport$SynchronousListener; // as SyncListener
import com.tangosol.util.MapListenerSupport; // as Support

/**
* Runnable MapEvent.
*/
public class CacheEvent
        extends    _package.component.Util
        implements java.lang.Runnable
    {
    // Fields declarations
    
    /**
    * Property Listeners
    *
    * Optional Listeners object containing MapListener objects.
    */
    private com.tangosol.util.Listeners __m_Listeners;
    
    /**
    * Property ListenerSupport
    *
    * Optional MapListenerSupport object containing MapListener objects.
    */
    private com.tangosol.util.MapListenerSupport __m_ListenerSupport;
    
    /**
    * Property MapEvent
    *
    * The actual MapEvent to fire.
    */
    private com.tangosol.util.MapEvent __m_MapEvent;
    
    /**
    * Property MapListener
    *
    * Optional MapListener object.
    */
    private com.tangosol.util.MapListener __m_MapListener;
    
    // Default constructor
    public CacheEvent()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CacheEvent(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CacheEvent();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/CacheEvent".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Dispatch the specified MapEvent to all Synchronous listeners and add to
    * the specified Queue for deferred execution for standard ones.
    */
    public static void dispatchSafe(com.tangosol.util.MapEvent event, com.tangosol.util.Listeners listeners, Queue queue)
        {
        // import com.tangosol.util.MapListener;
        // import com.tangosol.util.MapListenerSupport$SynchronousListener as SyncListener;
        
        if (listeners != null)
            {
            Object[] aListener = listeners.listeners();
            for (int i = 0, c = aListener.length; i < c; i++)
                {
                MapListener listener = (MapListener) aListener[i];
                if (listener instanceof SyncListener)
                    {
                    try
                        {
                        event.dispatch(listener);
                        }
                    catch (Throwable e)
                        {
                        _trace("An exception occured while dispatching synchronous event:" + event, 1);
                        _trace(e);
                        _trace("(The exception has been logged and execution is continuing.)", 1);
                        }
                    }
                else
                    {
                    queue.add(instantiate(event, listener));
                    }
                }
            }
        }
    
    // Accessor for the property "Listeners"
    /**
    * Getter for property Listeners.<p>
    * Optional Listeners object containing MapListener objects.
    */
    public com.tangosol.util.Listeners getListeners()
        {
        return __m_Listeners;
        }
    
    // Accessor for the property "ListenerSupport"
    /**
    * Getter for property ListenerSupport.<p>
    * Optional MapListenerSupport object containing MapListener objects.
    */
    public com.tangosol.util.MapListenerSupport getListenerSupport()
        {
        return __m_ListenerSupport;
        }
    
    // Accessor for the property "MapEvent"
    /**
    * Getter for property MapEvent.<p>
    * The actual MapEvent to fire.
    */
    public com.tangosol.util.MapEvent getMapEvent()
        {
        return __m_MapEvent;
        }
    
    // Accessor for the property "MapListener"
    /**
    * Getter for property MapListener.<p>
    * Optional MapListener object.
    */
    public com.tangosol.util.MapListener getMapListener()
        {
        return __m_MapListener;
        }
    
    public static CacheEvent instantiate(com.tangosol.util.MapEvent event, com.tangosol.util.Listeners listeners)
        {
        _assert(event != null && listeners != null);
        
        CacheEvent task = new CacheEvent();
        task.setMapEvent(event);
        task.setListeners(listeners);
        return task;
        }
    
    public static CacheEvent instantiate(com.tangosol.util.MapEvent event, com.tangosol.util.MapListener listener)
        {
        _assert(event != null && listener != null);
        
        CacheEvent task = new CacheEvent();
        task.setMapEvent(event);
        task.setMapListener(listener);
        return task;
        }
    
    public static CacheEvent instantiate(com.tangosol.util.MapEvent event, com.tangosol.util.MapListenerSupport support)
        {
        _assert(event != null && support != null);
        
        CacheEvent task = new CacheEvent();
        task.setMapEvent(event);
        task.setListenerSupport(support);
        return task;
        }
    
    // From interface: java.lang.Runnable
    public void run()
        {
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.util.Listeners;
        // import com.tangosol.util.MapEvent;
        // import com.tangosol.util.MapListener;
        // import com.tangosol.util.MapListenerSupport as Support;
        
        MapEvent   event = getMapEvent();
        NamedCache cache = (NamedCache) event.getSource();
        
        if (cache.isActive())
            {
            Support support = getListenerSupport();
            if (support == null)
                {
                Listeners listeners = getListeners();
                if (listeners == null)
                    {
                    event.dispatch(getMapListener());
                    }
                else
                    {
                    event.dispatch(listeners, true);
                    }
                }
            else
                {
                support.fireEvent(event, true);
                }
            }
        }
    
    // Accessor for the property "Listeners"
    /**
    * Setter for property Listeners.<p>
    * Optional Listeners object containing MapListener objects.
    */
    protected void setListeners(com.tangosol.util.Listeners listeners)
        {
        __m_Listeners = listeners;
        }
    
    // Accessor for the property "ListenerSupport"
    /**
    * Setter for property ListenerSupport.<p>
    * Optional MapListenerSupport object containing MapListener objects.
    */
    protected void setListenerSupport(com.tangosol.util.MapListenerSupport support)
        {
        __m_ListenerSupport = support;
        }
    
    // Accessor for the property "MapEvent"
    /**
    * Setter for property MapEvent.<p>
    * The actual MapEvent to fire.
    */
    protected void setMapEvent(com.tangosol.util.MapEvent event)
        {
        __m_MapEvent = event;
        }
    
    // Accessor for the property "MapListener"
    /**
    * Setter for property MapListener.<p>
    * Optional MapListener object.
    */
    protected void setMapListener(com.tangosol.util.MapListener listener)
        {
        __m_MapListener = listener;
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_Name() + ": " + getMapEvent();
        }
    }
