/* Class
*     _package.component.util.SafeCluster
*/

package _package.component.util;

import _package.component.net.Security;
import _package.component.util.LocalCache;
import _package.component.util.SafeService;
import _package.component.util.safeService.SafeCacheService;
import _package.component.util.safeService.SafeInvocationService;
import _package.component.util.safeService.safeCacheService.SafeDistributedCacheService;
import com.tangosol.net.CacheService;
import com.tangosol.net.Cluster;
import com.tangosol.net.DistributedCacheService;
import com.tangosol.net.InvocationService;
import com.tangosol.net.Service;
import com.tangosol.util.Base;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
* Cluster wrapper that never dies, unless explicitely commanded.
* SafeCluster has to be configured and started prior to the first use. 
*/
/*
* Integrates
*     com.tangosol.net.Cluster
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class SafeCluster
        extends    _package.component.Util
        implements com.tangosol.net.Cluster
    {
    // Fields declarations
    
    /**
    * Property Cluster
    *
    * The actual (wrapped) cluster.
    */
    private transient com.tangosol.net.Cluster __m_Cluster;
    
    /**
    * Property Config
    *
    * The configuration data
    */
    private com.tangosol.run.xml.XmlElement __m_Config;
    
    /**
    * Property ContextClassLoader
    *
    * The context ClassLoader for this cluster.
    */
    private ClassLoader __m_ContextClassLoader;
    
    /**
    * Property LocalServices
    *
    * A set of local services.
    */
    private java.util.Set __m_LocalServices;
    
    /**
    * Property Restart
    *
    * Specifies whether or not the underlying cluster has to be automatically
    * restarted.
    */
    private boolean __m_Restart;
    
    /**
    * Property RunningCluster
    *
    * Calculated property returning a running cluster. 
    * 
    * The only reason we have "getRunningCluster" in addition to
    * "ensureRunningCluster" is that RunningCluster property is used by the
    * integrator.
    */
    
    /**
    * Property ServiceMap
    *
    */
    private java.util.Map __m_ServiceMap;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("ShutdownHook", SafeCluster$ShutdownHook.get_CLASS());
        }
    
    // Default constructor
    public SafeCluster()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public SafeCluster(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setLocalServices(new com.tangosol.util.LiteSet());
            setServiceMap(new com.tangosol.util.SafeHashMap());
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new SafeCluster();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/SafeCluster".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    //++ com.tangosol.net.Cluster integration
    // Access optimization
    // properties integration
    // methods integration
    public java.util.Set getMemberSet()
        {
        return getRunningCluster().getMemberSet();
        }
    public com.tangosol.net.ServiceInfo getServiceInfo(String sName)
        {
        return getRunningCluster().getServiceInfo(sName);
        }
    public java.util.Enumeration getServiceNames()
        {
        return getRunningCluster().getServiceNames();
        }
    //-- com.tangosol.net.Cluster integration
    
    protected void cleanup()
        {
        setCluster(null);
        getServiceMap().clear();
        getLocalServices().clear();
        }
    
    // From interface: com.tangosol.net.Cluster
    public void configure(com.tangosol.run.xml.XmlElement xmlConfig)
        {
        setConfig(xmlConfig);

        }
    
    public com.tangosol.net.Service ensureLocalService(String sName, String sType)
        {
        // import Component.Util.LocalCache;
        // import java.util.Set;
        
        LocalCache serviceLocal = new LocalCache();
        serviceLocal.setServiceName(sName);
        serviceLocal.setCluster(this);
        
        Set setLocal = getLocalServices();
        if (setLocal.isEmpty())
            {
            try
                {
                Runtime.getRuntime().addShutdownHook(
                    new Thread(($ShutdownHook) _newChild("ShutdownHook")));
                }
            catch (Throwable e) {}
            }
        
        setLocal.add(serviceLocal);
        
        return serviceLocal;
        }
    
    public com.tangosol.net.Cluster ensureRunningCluster()
        {
        return getRunningCluster();
        }
    
    protected SafeService ensureSafeService(String sName, String sType)
        {
        // import Component.Util.SafeService;
        // import com.tangosol.net.CacheService;
        // import com.tangosol.net.Service;
        // import java.util.Map;
        
        Map         mapService  = getServiceMap();
        SafeService serviceSafe = (SafeService) mapService.get(sName);
        if (serviceSafe == null)
            {
            synchronized (mapService)
                {
                serviceSafe = (SafeService) mapService.get(sName);
                if (serviceSafe == null)
                    {
                    Service service = sType.equals(CacheService.TYPE_LOCAL) ?
                        ensureLocalService(sName, sType) :
                        getRunningCluster().ensureService(sName, sType);
        
                    serviceSafe = instantiateSafeService(service);
        
                    serviceSafe.setSafeCluster(this);
                    serviceSafe.setServiceName(sName);
                    serviceSafe.setServiceType(sType);
                    serviceSafe.setService(service);
                    serviceSafe.setContextClassLoader(getContextClassLoader());
        
                    mapService.put(sName, serviceSafe);
                    }
                }
            }
        
        return serviceSafe;
        }
    
    // From interface: com.tangosol.net.Cluster
    public com.tangosol.net.Service ensureService(String sName, String sType)
        {
        // import Component.Net.Security;
        // import Component.Util.SafeService;
        
        Security.checkPermission(getCluster(), sName, null, "join");
        
        SafeService serviceSafe = (SafeService) getServiceMap().get(sName);
        if (serviceSafe == null)
            {
            serviceSafe = ensureSafeService(sName, sType);
            }
        
        if (!serviceSafe.getServiceType().equals(sType))
            {
            throw new IllegalArgumentException("Requested service type \"" + sType +
                "\", but the existing service has type \"" + serviceSafe.getServiceType() + '"');
            }
        
        return serviceSafe;
        }
    
    // Accessor for the property "Cluster"
    /**
    * Getter for property Cluster.<p>
    * The actual (wrapped) cluster.
    */
    public com.tangosol.net.Cluster getCluster()
        {
        return __m_Cluster;
        }
    
    // Accessor for the property "Config"
    /**
    * Getter for property Config.<p>
    * The configuration data
    */
    public com.tangosol.run.xml.XmlElement getConfig()
        {
        return __m_Config;
        }
    
    // From interface: com.tangosol.net.Cluster
    // Accessor for the property "ContextClassLoader"
    /**
    * Getter for property ContextClassLoader.<p>
    * The context ClassLoader for this cluster.
    */
    public ClassLoader getContextClassLoader()
        {
        // import com.tangosol.util.Base;
        
        ClassLoader loader = __m_ContextClassLoader;
        if (loader == null)
            {
            loader = Base.getContextClassLoader(this);
            }
        return loader;
        }
    
    // From interface: com.tangosol.net.Cluster
    public com.tangosol.net.Member getLocalMember()
        {
        try
            {
            return getCluster().getLocalMember();
            }
        catch (NullPointerException e)
            {
            return null;
            }
        }
    
    // Accessor for the property "LocalServices"
    /**
    * Getter for property LocalServices.<p>
    * A set of local services.
    */
    protected java.util.Set getLocalServices()
        {
        return __m_LocalServices;
        }
    
    // Accessor for the property "RunningCluster"
    /**
    * Getter for property RunningCluster.<p>
    * Calculated property returning a running cluster. 
    * 
    * The only reason we have "getRunningCluster" in addition to
    * "ensureRunningCluster" is that RunningCluster property is used by the
    * integrator.
    */
    protected com.tangosol.net.Cluster getRunningCluster()
        {
        // import com.tangosol.net.Cluster;
        
        Cluster cluster = getCluster();
        if (cluster == null || !cluster.isRunning())
            {
            synchronized (this)
                {
                cluster = getCluster();
                if (cluster == null || !cluster.isRunning())
                    {
                    if (isRestart())
                        {
                        // create or restart the actual cluster
                        if (cluster != null)
                            {
                            setCluster(cluster = null); // release memory
                            _trace("Restarting cluster", 3);
                            }
        
                        setCluster(cluster = restartCluster());
                        }
                    else
                        {
                        throw new IllegalStateException(
                            "SafeCluster has been explicitly stopped or has not been started");
                        }
                    }
                }
            }
        return cluster;
        }
    
    // From interface: com.tangosol.net.Cluster
    public com.tangosol.net.Service getService(String sName)
        {
        // import Component.Net.Security;
        // import Component.Util.SafeService;
        // import com.tangosol.net.CacheService;
        // import com.tangosol.net.Service;
        // import java.util.Map;
        
        Security.checkPermission(getCluster(), sName, null, "join");
        
        Map         mapService  = getServiceMap();
        SafeService serviceSafe = (SafeService) mapService.get(sName);
        if (serviceSafe == null)
            {
            synchronized (mapService)
                {
                serviceSafe = (SafeService) mapService.get(sName);
                if (serviceSafe == null)
                    {
                    Service service = getRunningCluster().getService(sName);
                    if (service != null)
                        {
                        serviceSafe = instantiateSafeService(service);
        
                        serviceSafe.setSafeCluster(this);
                        serviceSafe.setServiceName(sName);
                        serviceSafe.setServiceType(service.getInfo().getServiceType());
                        serviceSafe.setService(service);
                        serviceSafe.setContextClassLoader(getContextClassLoader());
        
                        mapService.put(sName, serviceSafe);
                        }
                    }
                }
            }
        
        return serviceSafe;
        }
    
    // Accessor for the property "ServiceMap"
    /**
    * Getter for property ServiceMap.<p>
    */
    protected java.util.Map getServiceMap()
        {
        return __m_ServiceMap;
        }
    
    // From interface: com.tangosol.net.Cluster
    public long getTimeMillis()
        {
        try
            {
            return getCluster().getTimeMillis();
            }
        catch (NullPointerException e)
            {
            return 0l;
            }
        }
    
    /**
    * Instantiate an instance of SafeService for a given service.
    */
    protected SafeService instantiateSafeService(com.tangosol.net.Service service)
        {
        // import Component.Util.SafeService;
        // import Component.Util.SafeService.SafeCacheService;
        // import Component.Util.SafeService.SafeCacheService.SafeDistributedCacheService;
        // import Component.Util.SafeService.SafeInvocationService;
        // import com.tangosol.net.DistributedCacheService;
        // import com.tangosol.net.CacheService;
        // import com.tangosol.net.InvocationService;
        
        return service instanceof CacheService ?
                (
                service instanceof DistributedCacheService ? new SafeDistributedCacheService()
                                                           : new SafeCacheService()
                )
             : service instanceof InvocationService ? new SafeInvocationService()
                                                    : new SafeService();
        }
    
    // Accessor for the property "Restart"
    /**
    * Getter for property Restart.<p>
    * Specifies whether or not the underlying cluster has to be automatically
    * restarted.
    */
    public boolean isRestart()
        {
        return __m_Restart;
        }
    
    // From interface: com.tangosol.net.Cluster
    public boolean isRunning()
        {
        // import com.tangosol.net.Cluster;
        
        Cluster cluster = getCluster();
        return cluster != null && cluster.isRunning();
        }
    
    protected com.tangosol.net.Cluster restartCluster()
        {
        // import com.tangosol.net.Cluster;
        
        Cluster cluster = new Component.Net.Cluster();
        
        startCluster(cluster);
        
        return cluster;
        }
    
    // Accessor for the property "Cluster"
    /**
    * Setter for property Cluster.<p>
    * The actual (wrapped) cluster.
    */
    protected void setCluster(com.tangosol.net.Cluster cluster)
        {
        __m_Cluster = cluster;
        }
    
    // Accessor for the property "Config"
    /**
    * Setter for property Config.<p>
    * The configuration data
    */
    public void setConfig(com.tangosol.run.xml.XmlElement xmlConfig)
        {
        __m_Config = xmlConfig;
        }
    
    // From interface: com.tangosol.net.Cluster
    // Accessor for the property "ContextClassLoader"
    /**
    * Setter for property ContextClassLoader.<p>
    * The context ClassLoader for this cluster.
    */
    public void setContextClassLoader(ClassLoader loader)
        {
        __m_ContextClassLoader = loader;
        }
    
    // Accessor for the property "LocalServices"
    /**
    * Setter for property LocalServices.<p>
    * A set of local services.
    */
    protected void setLocalServices(java.util.Set set)
        {
        __m_LocalServices = set;
        }
    
    // Accessor for the property "Restart"
    /**
    * Setter for property Restart.<p>
    * Specifies whether or not the underlying cluster has to be automatically
    * restarted.
    */
    public void setRestart(boolean fRestart)
        {
        __m_Restart = fRestart;
        }
    
    // Accessor for the property "ServiceMap"
    /**
    * Setter for property ServiceMap.<p>
    */
    protected void setServiceMap(java.util.Map map)
        {
        __m_ServiceMap = map;
        }
    
    // From interface: com.tangosol.net.Cluster
    public synchronized void shutdown()
        {
        // import com.tangosol.net.Cluster;
        
        setRestart(false);
        
        Cluster cluster = getCluster();
        if (cluster != null)
            {
            synchronized (cluster)
                {
                if (cluster.isRunning())
                    {
                    cluster.shutdown();
                    }
                }
            }
        shutdownLocalServices();
        cleanup();
        }
    
    public void shutdownLocalServices()
        {
        // import com.tangosol.net.Service;
        // import java.util.Iterator;
        
        for (Iterator iter = getLocalServices().iterator(); iter.hasNext();)
            {
            ((Service) iter.next()).shutdown();
            }
        }
    
    // From interface: com.tangosol.net.Cluster
    public synchronized void start()
        {
        setRestart(true);
        ensureRunningCluster();
        }
    
    protected void startCluster(com.tangosol.net.Cluster cluster)
        {
        cluster.configure(getConfig());
        cluster.start();
        }
    
    // From interface: com.tangosol.net.Cluster
    public synchronized void stop()
        {
        // import com.tangosol.net.Cluster;
        
        setRestart(false);
        
        Cluster cluster = getCluster();
        if (cluster != null)
            {
            synchronized (cluster)
                {
                if (cluster.isRunning())
                    {
                    cluster.stop();
                    }
                }
            }
        shutdownLocalServices();
        cleanup();
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_Name() + ": " + getCluster();
        }
    }
