/* Class
*     _package.component.util.deltaMap.transactionMap.Optimistic
*/

package _package.component.util.deltaMap.transactionMap;

import com.tangosol.util.ChainedEnumerator;
import com.tangosol.util.ConcurrentMap;
import com.tangosol.util.TransactionMap$Validator; // as Validator
import java.util.Collections;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public abstract class Optimistic
        extends    _package.component.util.deltaMap.TransactionMap
    {
    // Fields declarations
    
    // Initializing constructor
    public Optimistic(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/deltaMap/transactionMap/Optimistic".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Enlist a specified resource into a transaction.
    * 
    * @param oKey the resource key
    * @param fWrite if true, the resource should be elisted for read and write;
    * otherwise for read only
    * 
    * @throws ConcurrenModificationException if the resource cannot be enlisted
    * 
    */
    protected void enlist(Object oKey, boolean fWrite)
        {
        // import com.tangosol.util.TransactionMap$Validator as Validator;
        
        if (fWrite && !isModified(oKey))
            {
            Validator validator = getValidator();
            if (validator != null)
                {
                validator.enlist(this, oKey);
                }
            }
        
        super.enlist(oKey, fWrite);
        }
    
    // Declared at the super level
    /**
    * Enlist all map resources into a transaction.
    * 
    * @param fWrite if true, resources should be elisted for read and write;
    * otherwise for read only
    * 
    * @throws ConcurrenModificationException if some of the resources cannot be
    * enlisted
    */
    protected void enlistAll(boolean fWrite)
        {
        // import com.tangosol.util.TransactionMap$Validator as Validator;
        // import java.util.Iterator;
        // import java.util.Map;
        
        if (!isFullyRead())
            {
            Validator validator = getValidator();
        
            if (validator != null)
                {
                Map mapOrig = getOriginalMap();
                for (Iterator iter = mapOrig.keySet().iterator(); iter.hasNext();)
                    {
                    enlist(iter.next(), fWrite);
                    }
                }
            }
        
        super.enlistAll(fWrite);
        }
    
    // Declared at the super level
    public void prepare()
        {
        // import com.tangosol.util.ChainedEnumerator;
        // import com.tangosol.util.ConcurrentMap;
        // import com.tangosol.util.TransactionMap$Validator as Validator;
        // import java.util.Collections;
        // import java.util.ConcurrentModificationException;
        // import java.util.Iterator;
        // import java.util.Set;
        
        super.prepare();
        
        ConcurrentMap mapBase    = getBaseMap();
        Set           setLock    = getBaseLockSet();
        Set           setInsert  = getInsertKeySet();
        Set           setUpdate  = getUpdateKeySet();
        Set           setDelete  = getDeleteKeySet();
        Set           setRead    = getReadKeySet();
        Set           setFanthom = Collections.EMPTY_SET;
        Object        oKeyFailed = null;
        
        Iterator iter = new ChainedEnumerator(new Iterator[]
            {
            setInsert.iterator(),
            setUpdate.iterator(),
            setDelete.iterator(),
            setRead  .iterator(),
            });
        
        while (iter.hasNext())
            {
            Object oKey = iter.next();
        
            if (!setLock.contains(oKey))
                {
                if (mapBase.lock(oKey, getLockWaitMillis()))
                    {
                    setLock.add(oKey);
                    }
                else
                    {
                    oKeyFailed = oKey;
                    break;
                    }
                }
            }
        
        if (oKeyFailed != null)
            {
            rollback();
            throw new ConcurrentModificationException("Failed to lock during prepare: key=" + oKeyFailed);
            }
        
        Validator validator = getValidator();
        if (validator != null)
            {
            try
                {
                validator.validate(this, setInsert, setUpdate, setDelete, setRead, setFanthom);
                }
            catch (RuntimeException e)
                {
                rollback();
                throw e;
                }
            }
        }
    }
