/* Class
*     _package.component.util.safeService.SafeCacheService
*/

package _package.component.util.safeService;

import _package.component.net.Security;
import _package.component.util.SafeNamedCache;
import com.tangosol.net.BackingMapManager;
import com.tangosol.net.CacheFactory$WrapperManager; // as WrapperManager
import com.tangosol.net.CacheService;
import com.tangosol.net.NamedCache;
import com.tangosol.util.LiteMap;
import java.util.Map;

/*
* Integrates
*     com.tangosol.net.CacheService
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class SafeCacheService
        extends    _package.component.util.SafeService
        implements com.tangosol.net.CacheService
    {
    // Fields declarations
    
    /**
    * Property BackingMapManager
    *
    */
    private transient com.tangosol.net.BackingMapManager __m_BackingMapManager;
    
    /**
    * Property CacheService
    *
    * The actual (wrapped) CacheService.
    */
    
    /**
    * Property LocalCacheFactory
    *
    * @deprecated
    */
    private transient com.tangosol.net.CacheFactory$LocalCacheFactory __m_LocalCacheFactory;
    
    /**
    * Property NamedCacheMap
    *
    * Map keyed by cache name with a corresponding value being a map (keyed by
    * class loader with a corresponding value being a NamedCache reference).
    */
    private transient java.util.Map __m_NamedCacheMap;
    
    /**
    * Property RunningCacheService
    *
    * Calculated property returning a running cache service.
    * 
    * The only reason we have "getRunningCacheService" in addition to
    * "ensureRunningCacheService" is that RunningCacheService property is used
    * by the integrator.
    */
    
    // Default constructor
    public SafeCacheService()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public SafeCacheService(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setNamedCacheMap(new com.tangosol.util.SafeHashMap());
            setSafeServiceState(0);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new SafeCacheService();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/safeService/SafeCacheService".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ com.tangosol.net.CacheService integration
    // Access optimization
    // properties integration
    // methods integration
    private com.tangosol.net.NamedCache ensureCache$Router(String sName, ClassLoader loader)
        {
        return getRunningCacheService().ensureCache(sName, loader);
        }
    public com.tangosol.net.NamedCache ensureCache(String sName, ClassLoader loader)
        {
        // import Component.Net.Security;
        // import Component.Util.SafeNamedCache;
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.util.LiteMap;
        // import java.util.Map;
        
        if (sName == null || sName.length() == 0)
            {
            sName = "Default";
            }
        
        if (loader == null)
            {
            loader = getContextClassLoader();
            }
        
        Security.checkPermission(getSafeCluster().getCluster(), getServiceName(), sName, "join");
        
        Map mapByName   = getNamedCacheMap();
        Map mapByLoader = (Map) mapByName.get(sName);
        
        if (mapByLoader == null)
            {
            synchronized (mapByName)
                {
                mapByLoader = (Map) mapByName.get(sName);
        
                if (mapByLoader == null)
                    {
                    mapByLoader = new LiteMap();
                    mapByName.put(sName, mapByLoader);
                    }
                }
            }
        
        SafeNamedCache cacheSafe = (SafeNamedCache) mapByLoader.get(loader);
        if (cacheSafe == null)
            {
            synchronized (mapByLoader)
                {
                cacheSafe = (SafeNamedCache) mapByLoader.get(loader);
                if (cacheSafe == null)
                    {
                    NamedCache cache = ensureCache$Router(sName, loader);
        
                    cacheSafe = new SafeNamedCache();
        
                    cacheSafe.setSafeCacheService(this);
                    cacheSafe.setCacheName(sName);
                    cacheSafe.setClassLoader(loader);
                    cacheSafe.setNamedCache(cache);
        
                    mapByLoader.put(loader, cacheSafe);
                    }
                }
            }
        
        return cacheSafe;
        }
    public java.util.Enumeration getCacheNames()
        {
        return getRunningCacheService().getCacheNames();
        }
    //-- com.tangosol.net.CacheService integration
    
    // Declared at the super level
    protected void cleanup()
        {
        super.cleanup();
        
        getNamedCacheMap().clear();
        }
    
    // From interface: com.tangosol.net.CacheService
    public void destroyCache(com.tangosol.net.NamedCache cache)
        {
        // import Component.Net.Security;
        // import Component.Util.SafeNamedCache;
        // import com.tangosol.net.CacheService;
        // import com.tangosol.net.NamedCache;
        
        Security.checkPermission(getSafeCluster().getCluster(),
            getServiceName(), cache.getCacheName(), "destroy");
        
        SafeNamedCache cacheSafe = (SafeNamedCache) cache;
        
        removeCacheReference(cacheSafe);
        
        CacheService service = getCacheService();
        try
            {
            NamedCache cacheWrapped = cacheSafe.getNamedCache();
            if (cacheWrapped == null)
                {
                throw new IllegalStateException("Cache is already released");
                }
            else
                {
                service.destroyCache(cacheWrapped);
                }
            }
        catch (RuntimeException e)
            {
            if (service != null && service.isRunning())
                {
                throw e;
                }
            }
        }
    
    public com.tangosol.net.CacheService ensureRunningCacheService()
        {
        return getRunningCacheService();
        }
    
    // From interface: com.tangosol.net.CacheService
    // Accessor for the property "BackingMapManager"
    /**
    * Getter for property BackingMapManager.<p>
    */
    public com.tangosol.net.BackingMapManager getBackingMapManager()
        {
        return __m_BackingMapManager;
        }
    
    // Accessor for the property "CacheService"
    /**
    * Getter for property CacheService.<p>
    * The actual (wrapped) CacheService.
    */
    public com.tangosol.net.CacheService getCacheService()
        {
        // import com.tangosol.net.CacheService;
        
        return (CacheService) getService();
        }
    
    // From interface: com.tangosol.net.CacheService
    // Accessor for the property "LocalCacheFactory"
    /**
    * Getter for property LocalCacheFactory.<p>
    * @deprecated
    */
    public com.tangosol.net.CacheFactory$LocalCacheFactory getLocalCacheFactory()
        {
        // import com.tangosol.net.BackingMapManager;
        // import com.tangosol.net.CacheFactory$WrapperManager as WrapperManager;
        
        BackingMapManager manager = getBackingMapManager();
        
        return manager instanceof WrapperManager ?
            ((WrapperManager) manager).getLocalCacheFactory() : null;
        }
    
    // Accessor for the property "NamedCacheMap"
    /**
    * Getter for property NamedCacheMap.<p>
    * Map keyed by cache name with a corresponding value being a map (keyed by
    * class loader with a corresponding value being a NamedCache reference).
    */
    public java.util.Map getNamedCacheMap()
        {
        return __m_NamedCacheMap;
        }
    
    // Accessor for the property "RunningCacheService"
    /**
    * Getter for property RunningCacheService.<p>
    * Calculated property returning a running cache service.
    * 
    * The only reason we have "getRunningCacheService" in addition to
    * "ensureRunningCacheService" is that RunningCacheService property is used
    * by the integrator.
    */
    protected com.tangosol.net.CacheService getRunningCacheService()
        {
        // import com.tangosol.net.CacheService;
        
        return (CacheService) getRunningService();
        }
    
    // From interface: com.tangosol.net.CacheService
    public void releaseCache(com.tangosol.net.NamedCache cache)
        {
        // import Component.Util.SafeNamedCache;
        // import com.tangosol.net.CacheService;
        // import com.tangosol.net.NamedCache;
        
        SafeNamedCache cacheSafe = (SafeNamedCache) cache;
        
        removeCacheReference(cacheSafe);
        
        CacheService service = getCacheService();
        try
            {
            NamedCache cacheWrapped = cacheSafe.getNamedCache();
            if (cacheWrapped != null)
                {
                service.releaseCache(cacheWrapped);
                }
            }
        catch (RuntimeException e)
            {
            if (service != null && service.isRunning())
                {
                throw e;
                }
            }
        }
    
    protected void removeCacheReference(_package.component.util.SafeNamedCache cacheSafe)
        {
        // import java.util.Map;
        
        cacheSafe.setReleased(true);
        
        String sName       = cacheSafe.getCacheName();
        Map    mapByName   = getNamedCacheMap();
        Map    mapByLoader = (Map) mapByName.get(sName);
        
        if (mapByLoader != null)
            {
            synchronized (mapByLoader)
                {
                mapByLoader.remove(cacheSafe.getClassLoader());
        
                if (mapByLoader.isEmpty())
                    {
                    mapByName.remove(sName);
                    }
                }
            }
        }
    
    // From interface: com.tangosol.net.CacheService
    // Accessor for the property "BackingMapManager"
    /**
    * Setter for property BackingMapManager.<p>
    */
    public synchronized void setBackingMapManager(com.tangosol.net.BackingMapManager manager)
        {
        __m_BackingMapManager = manager;
        }
    
    // From interface: com.tangosol.net.CacheService
    // Accessor for the property "LocalCacheFactory"
    /**
    * Setter for property LocalCacheFactory.<p>
    * @deprecated
    */
    public synchronized void setLocalCacheFactory(com.tangosol.net.CacheFactory$LocalCacheFactory factory)
        {
        // import com.tangosol.net.BackingMapManager;
        // import com.tangosol.net.CacheFactory$WrapperManager as WrapperManager;
        
        setBackingMapManager(new WrapperManager(factory));
        }
    
    // Accessor for the property "NamedCacheMap"
    /**
    * Setter for property NamedCacheMap.<p>
    * Map keyed by cache name with a corresponding value being a map (keyed by
    * class loader with a corresponding value being a NamedCache reference).
    */
    protected void setNamedCacheMap(java.util.Map map)
        {
        __m_NamedCacheMap = map;
        }
    
    // Declared at the super level
    protected void startService(com.tangosol.net.Service service)
        {
        // import com.tangosol.net.CacheService;
        
        ((CacheService) service).setBackingMapManager(getBackingMapManager());
        
        super.startService(service);
        }
    }
