/* Class
*     _package.component.util.CacheHandler$Validator
*/

package _package.component.util;

import _package.component.net.Lease;
import com.tangosol.util.Base;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Map;

/**
* The default Validator that uses the Lease version to resolve the  update
* conflicts [in the case of optimistic concurrency].
* 
* Deprecated since Coherence 2.3
*/
public class CacheHandler$Validator
        extends    TransactionValidator
    {
    // Fields declarations
    
    /**
    * Property LeaseMap
    *
    * Map holding the Lease objects for resources enlisted into a transaction
    */
    private transient com.tangosol.util.SafeHashMap __m_LeaseMap;
    
    // Default constructor
    public CacheHandler$Validator()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CacheHandler$Validator(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setLeaseMap(new com.tangosol.util.SafeHashMap());
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CacheHandler$Validator();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/CacheHandler$Validator".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    public void enlist(com.tangosol.util.TransactionMap map, Object oKey)
        {
        // import Component.Net.Lease;
        
        $Module handler = ($Module) get_Parent();
        _assert(handler == map.getBaseMap());
        
        Lease lease = handler.getLease(oKey);
        getLeaseMap().put(oKey, lease == null ? null : lease.clone());
        
        super.enlist(map, oKey);
        }
    
    // Accessor for the property "LeaseMap"
    /**
    * Getter for property LeaseMap.<p>
    * Map holding the Lease objects for resources enlisted into a transaction
    */
    public com.tangosol.util.SafeHashMap getLeaseMap()
        {
        return __m_LeaseMap;
        }
    
    // Accessor for the property "LeaseMap"
    /**
    * Setter for property LeaseMap.<p>
    * Map holding the Lease objects for resources enlisted into a transaction
    */
    public void setLeaseMap(com.tangosol.util.SafeHashMap pLeaseMap)
        {
        __m_LeaseMap = pLeaseMap;
        }
    
    // Declared at the super level
    public void validate(com.tangosol.util.TransactionMap map, java.util.Set setInsert, java.util.Set setUpdate, java.util.Set setDelete, java.util.Set setRead, java.util.Set setFanthom)
            throws java.util.ConcurrentModificationException
        {
        // import java.util.ConcurrentModificationException;
        
        super.validate(map, setInsert, setUpdate, setDelete, setRead, setFanthom);
        
        $Module handler = ($Module) get_Parent();
        _assert(handler == map.getBaseMap());
        
        // inserts -- there should be no value
        validateInsert(map, setInsert);
        
        // updates -- the versions should be the same
        validateVersion(map, setUpdate);
        
        // deletes -- the versions should be the same
        validateVersion(map, setDelete);
        
        // reads -- the values should be the same
        validateValue(map, setRead);
        
        // fanthoms -- should be empty
        
        boolean fFail = false;
        String  sMsg  = "";
        if (!setInsert.isEmpty())
            {
            sMsg  += "\ninserts=" + setInsert;
            fFail  = true;
            }
        if (!setUpdate.isEmpty())
            {
            sMsg  += "\nupdates=" + setUpdate;
            fFail  = true;
            }
        if (!setDelete.isEmpty())
            {
            sMsg  += "\ndeletes=" + setDelete;
            fFail  = true;
            }
        if (!setRead.isEmpty())
            {
            sMsg  += "\nreads=" + setRead;
            fFail  = true;
            }
        if (!setFanthom.isEmpty())
            {
            sMsg  += "\nfanthoms=" + setFanthom;
            fFail  = true;
            }
        
        if (fFail)
            {
            throw new ConcurrentModificationException("validation failed: " + sMsg);
            }
        }
    
    protected void validateInsert(com.tangosol.util.TransactionMap map, java.util.Set set)
        {
        // import com.tangosol.util.Base;
        // import java.util.Iterator;
        // import java.util.Map;
        
        Map mapBase = map.getBaseMap();
        
        for (Iterator iter = set.iterator(); iter.hasNext();)
            {
            Object oKey = iter.next();
        
            if (!mapBase.containsKey(oKey))
                {
                iter.remove();
                }
            }
        }
    
    protected void validateValue(com.tangosol.util.TransactionMap map, java.util.Set set)
        {
        // import com.tangosol.util.Base;
        // import java.util.Iterator;
        // import java.util.Map;
        
        Map mapBase = map.getBaseMap();
        
        for (Iterator iter = set.iterator(); iter.hasNext();)
            {
            Object oKey     = iter.next();
            Object oValBase = mapBase.get(oKey);
            Object oValCurr = map.get(oKey);
        
            if (Base.equals(oValBase, oValCurr))
                {
                iter.remove();
                }
            }
        }
    
    protected void validateVersion(com.tangosol.util.TransactionMap map, java.util.Set set)
        {
        // import Component.Net.Lease;
        // import java.util.Iterator;
        // import java.util.Map;
        
        $Module handler  = ($Module) get_Parent();
        Map     mapLease = getLeaseMap();
        
        for (Iterator iter = set.iterator(); iter.hasNext();)
            {
            Object oKey      = iter.next();
            Lease  leaseOrig = (Lease) mapLease.get(oKey);
            Lease  leaseCurr = handler.getLease(oKey);
        
            if (leaseOrig != null && leaseCurr != null &&
                leaseOrig.getResourceVersion() == leaseCurr.getResourceVersion())
                {
                iter.remove();
                }
            }
        }
    }
