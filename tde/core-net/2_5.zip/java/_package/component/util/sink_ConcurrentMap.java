/* Class
*      sink_ConcurrentMap
*
* automatically generated "Sink" which
* represents a footprint of the class
*      com.tangosol.util.WrapperConcurrentMap
* when used as a component callback by 
*      Component.Util.ConcurrentMap
*/

package _package.component.util;

public class sink_ConcurrentMap
       extends com.tangosol.run.component.CallbackSink
    {
    private jb_ConcurrentMap __peer;
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_ConcurrentMap()
        {
        }
    
    // this (protected) constructor is used by the feed
    protected sink_ConcurrentMap(jb_ConcurrentMap feed)
        {
        super();
        __peer = feed;
        }
    
    // Retrieves the feed object for this sink
    public Object get_Feed()
        {
        return __peer;
        }
    
    // methods integrated and/or remoted
    public void addMapListener(com.tangosol.util.MapListener listener)
        {
        __peer.super$addMapListener(listener);
        }
    public void addMapListener(com.tangosol.util.MapListener listener, com.tangosol.util.Filter filter, boolean fLite)
        {
        __peer.super$addMapListener(listener, filter, fLite);
        }
    public void addMapListener(com.tangosol.util.MapListener listener, Object oKey, boolean fLite)
        {
        __peer.super$addMapListener(listener, oKey, fLite);
        }
    public void clear()
        {
        __peer.super$clear();
        }
    public boolean containsKey(Object oKey)
        {
        return __peer.super$containsKey(oKey);
        }
    public boolean containsValue(Object oValue)
        {
        return __peer.super$containsValue(oValue);
        }
    public java.util.Set entrySet()
        {
        return __peer.super$entrySet();
        }
    public Object get(Object oKey)
        {
        return __peer.super$get(oKey);
        }
    public java.util.Map getMap()
        {
        return __peer.super$getMap();
        }
    public java.util.Set keySet()
        {
        return __peer.super$keySet();
        }
    public boolean lock(Object oKey)
        {
        return __peer.super$lock(oKey);
        }
    public boolean lock(Object oKey, long cWait)
        {
        return __peer.super$lock(oKey, cWait);
        }
    public Object put(Object oKey, Object oValue)
        {
        return __peer.super$put(oKey, oValue);
        }
    public void putAll(java.util.Map map)
        {
        __peer.super$putAll(map);
        }
    public Object remove(Object oKey)
        {
        return __peer.super$remove(oKey);
        }
    public void removeMapListener(com.tangosol.util.MapListener listener)
        {
        __peer.super$removeMapListener(listener);
        }
    public void removeMapListener(com.tangosol.util.MapListener listener, com.tangosol.util.Filter filter)
        {
        __peer.super$removeMapListener(listener, filter);
        }
    public void removeMapListener(com.tangosol.util.MapListener listener, Object oKey)
        {
        __peer.super$removeMapListener(listener, oKey);
        }
    public int size()
        {
        return __peer.super$size();
        }
    public boolean unlock(Object oKey)
        {
        return __peer.super$unlock(oKey);
        }
    public java.util.Collection values()
        {
        return __peer.super$values();
        }
    }
