/* Class
*      sink_CacheEvent
*
* automatically generated "Sink" which
* represents a footprint of the class
*      com.tangosol.util.MapEvent
* when used as a component callback by 
*      Component.Util.CacheEvent
*/

package _package.component.util;

public class sink_CacheEvent
       extends com.tangosol.run.component.CallbackSink
    {
    private jb_CacheEvent __peer;
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_CacheEvent()
        {
        }
    
    // this (protected) constructor is used by the feed
    protected sink_CacheEvent(jb_CacheEvent feed)
        {
        super();
        __peer = feed;
        }
    
    // Retrieves the feed object for this sink
    public Object get_Feed()
        {
        return __peer;
        }
    
    // methods integrated and/or remoted
    public void dispatch(com.tangosol.util.Listeners listeners)
        {
        __peer.super$dispatch(listeners);
        }
    public int getId()
        {
        return __peer.super$getId();
        }
    public Object getKey()
        {
        return __peer.super$getKey();
        }
    public Object getNewValue()
        {
        return __peer.super$getNewValue();
        }
    public Object getOldValue()
        {
        return __peer.super$getOldValue();
        }
    public Object getSource()
        {
        return __peer.super$getSource();
        }
    }
