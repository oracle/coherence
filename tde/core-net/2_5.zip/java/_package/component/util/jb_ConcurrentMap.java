/* Class
*      jb_ConcurrentMap
*
* automatically generated "Feed" which
* a) extends an external bean:
*      com.tangosol.util.WrapperConcurrentMap
* b) delegates to the peer component:
*      Component.Util.ConcurrentMap
*/

package _package.component.util;

public class jb_ConcurrentMap
        extends    com.tangosol.util.WrapperConcurrentMap
        implements com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected ConcurrentMap __peer;
    
    private static ConcurrentMap __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            ConcurrentMap peer = (ConcurrentMap)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // parameterized constructor
    public jb_ConcurrentMap(java.util.Map map)
        {
        this(map, ConcurrentMap.get_CLASS());
        }
    
    // parameterized constructor
    public jb_ConcurrentMap(java.util.Map map, boolean fEnforceLocking, long cWaitMillis)
        {
        this(map, fEnforceLocking, cWaitMillis, ConcurrentMap.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_ConcurrentMap(java.util.Map map, Class clzPeer)
        {
        this(map, __createPeer(clzPeer), true);
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_ConcurrentMap(java.util.Map map, boolean fEnforceLocking, long cWaitMillis, Class clzPeer)
        {
        this(map, fEnforceLocking, cWaitMillis, __createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_ConcurrentMap(java.util.Map map, ConcurrentMap peer, boolean fInit)
        {
        super(map);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_ConcurrentMap(java.util.Map map, boolean fEnforceLocking, long cWaitMillis, ConcurrentMap peer, boolean fInit)
        {
        super(map, fEnforceLocking, cWaitMillis);
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private ConcurrentMap __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (ConcurrentMap) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_ConcurrentMap(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    public void addMapListener(com.tangosol.util.MapListener listener)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMapListener(listener);
        }
    void super$addMapListener(com.tangosol.util.MapListener listener)
        {
        super.addMapListener(listener);
        }
    public void addMapListener(com.tangosol.util.MapListener listener, com.tangosol.util.Filter filter, boolean fLite)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMapListener(listener, filter, fLite);
        }
    void super$addMapListener(com.tangosol.util.MapListener listener, com.tangosol.util.Filter filter, boolean fLite)
        {
        super.addMapListener(listener, filter, fLite);
        }
    public void addMapListener(com.tangosol.util.MapListener listener, Object oKey, boolean fLite)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.addMapListener(listener, oKey, fLite);
        }
    void super$addMapListener(com.tangosol.util.MapListener listener, Object oKey, boolean fLite)
        {
        super.addMapListener(listener, oKey, fLite);
        }
    public void clear()
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.clear();
        }
    void super$clear()
        {
        super.clear();
        }
    public boolean containsKey(Object oKey)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.containsKey(oKey);
        }
    boolean super$containsKey(Object oKey)
        {
        return super.containsKey(oKey);
        }
    public boolean containsValue(Object oValue)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.containsValue(oValue);
        }
    boolean super$containsValue(Object oValue)
        {
        return super.containsValue(oValue);
        }
    public java.util.Set entrySet()
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.entrySet();
        }
    java.util.Set super$entrySet()
        {
        return super.entrySet();
        }
    public Object get(Object oKey)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.get(oKey);
        }
    Object super$get(Object oKey)
        {
        return super.get(oKey);
        }
    public java.util.Map getMap()
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getActualMap();
        }
    java.util.Map super$getMap()
        {
        return super.getMap();
        }
    public java.util.Set keySet()
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.keySet();
        }
    java.util.Set super$keySet()
        {
        return super.keySet();
        }
    public boolean lock(Object oKey)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.lock(oKey);
        }
    boolean super$lock(Object oKey)
        {
        return super.lock(oKey);
        }
    public boolean lock(Object oKey, long cWait)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.lock(oKey, cWait);
        }
    boolean super$lock(Object oKey, long cWait)
        {
        return super.lock(oKey, cWait);
        }
    public Object put(Object oKey, Object oValue)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.put(oKey, oValue);
        }
    Object super$put(Object oKey, Object oValue)
        {
        return super.put(oKey, oValue);
        }
    public void putAll(java.util.Map map)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.putAll(map);
        }
    void super$putAll(java.util.Map map)
        {
        super.putAll(map);
        }
    public Object remove(Object oKey)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.remove(oKey);
        }
    Object super$remove(Object oKey)
        {
        return super.remove(oKey);
        }
    public void removeMapListener(com.tangosol.util.MapListener listener)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMapListener(listener);
        }
    void super$removeMapListener(com.tangosol.util.MapListener listener)
        {
        super.removeMapListener(listener);
        }
    public void removeMapListener(com.tangosol.util.MapListener listener, com.tangosol.util.Filter filter)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMapListener(listener, filter);
        }
    void super$removeMapListener(com.tangosol.util.MapListener listener, com.tangosol.util.Filter filter)
        {
        super.removeMapListener(listener, filter);
        }
    public void removeMapListener(com.tangosol.util.MapListener listener, Object oKey)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        peer.removeMapListener(listener, oKey);
        }
    void super$removeMapListener(com.tangosol.util.MapListener listener, Object oKey)
        {
        super.removeMapListener(listener, oKey);
        }
    public int size()
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.size();
        }
    int super$size()
        {
        return super.size();
        }
    public boolean unlock(Object oKey)
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.unlock(oKey);
        }
    boolean super$unlock(Object oKey)
        {
        return super.unlock(oKey);
        }
    public java.util.Collection values()
        {
        ConcurrentMap peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.values();
        }
    java.util.Collection super$values()
        {
        return super.values();
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
