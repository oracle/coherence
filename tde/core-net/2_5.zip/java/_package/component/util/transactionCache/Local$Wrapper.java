/* Class
*     _package.component.util.transactionCache.Local$Wrapper
*/

package _package.component.util.transactionCache;

import com.tangosol.util.Binary;
import com.tangosol.util.ClassHelper;
import com.tangosol.util.Converter;
import com.tangosol.util.ConverterCollections;
import com.tangosol.util.ExternalizableHelper;
import com.tangosol.util.NullImplementation;
import java.math.BigDecimal;
import java.math.BigInteger;

/**
* A wrapper for the base NamedCache that clones the values retrieved by the
* "get" operation.
* 
* @see $Module#ImmutableValues property
*/
public class Local$Wrapper
        extends    _package.component.util.collections.wrapperMap.WrapperNamedCache
        implements com.tangosol.util.Converter
    {
    // Fields declarations
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("EntrySet", Local$Wrapper$EntrySet.get_CLASS());
        __mapChildren.put("KeySet", Local$Wrapper$KeySet.get_CLASS());
        __mapChildren.put("Values", Local$Wrapper$Values.get_CLASS());
        }
    
    // Default constructor
    public Local$Wrapper()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Local$Wrapper(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Local$Wrapper();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/transactionCache/Local$Wrapper".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // From interface: com.tangosol.util.Converter
    public Object convert(Object o)
        {
        return ensureClone(o);
        }
    
    public static Object ensureClone(Object o)
        {
        // import com.tangosol.util.ClassHelper;
        // import com.tangosol.util.Binary;
        // import com.tangosol.util.ExternalizableHelper;
        // import java.math.BigDecimal;
        // import java.math.BigInteger;
        
        boolean fImmutable = false;
        
        if (o instanceof Number)
            {
            fImmutable =
                   o instanceof Byte
                || o instanceof Short
                || o instanceof Integer
                || o instanceof Long
                || o instanceof Float
                || o instanceof Double
                || o instanceof BigDecimal
                || o instanceof BigInteger;
            }
        else
            {
            fImmutable =
                   o instanceof String
                || o instanceof Binary
                || o instanceof Boolean
                || o instanceof Character;
            }
        
        if (fImmutable || o == null)
            {
            return o;
            }
        
        if (o instanceof Cloneable)
            {
            try
                {
                return ClassHelper.invoke(o, "clone", ClassHelper.VOID);
                }
            catch (Throwable e) {}
            }
        
        ClassLoader loader = o.getClass().getClassLoader();
        return ExternalizableHelper.fromBinary(ExternalizableHelper.toBinary(o), loader);
        }
    
    // Declared at the super level
    public Object get(Object oKey)
        {
        return ensureClone(super.get(oKey));
        }
    
    // Declared at the super level
    public java.util.Map getAll(java.util.Collection colKeys)
        {
        // import com.tangosol.util.Converter;
        // import com.tangosol.util.ConverterCollections;
        // import com.tangosol.util.NullImplementation;
        
        Converter convNull  = NullImplementation.getConverter();
        Converter convClone = this;
        
        return ConverterCollections.getMap(super.getAll(colKeys),
            convNull, convNull, convClone, convNull);
        }
    }
