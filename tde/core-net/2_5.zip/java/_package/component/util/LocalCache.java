/* Class
*     _package.component.util.LocalCache
*/

package _package.component.util;

import com.tangosol.net.BackingMapManager;
import com.tangosol.net.BackingMapManager; // as Manager
import com.tangosol.util.IteratorEnumerator;
import com.tangosol.util.NullImplementation;
import com.tangosol.util.SafeHashMap;
import java.util.Iterator;
import java.util.Map$Entry; // as Entry
import java.util.Map;

/**
* Coherence Local implementation.
* 
* TODO: BackingMapManager contract
*/
public class LocalCache
        extends    _package.component.Util
        implements com.tangosol.net.CacheService,
                   com.tangosol.net.ServiceInfo
    {
    // Fields declarations
    
    /**
    * Property BackingMapContext
    *
    * The BackingMapContext (lazily created) is used by the BackingMapManager
    * (if provided).
    */
    private transient LocalCache$BackingMapContext __m_BackingMapContext;
    
    /**
    * Property BackingMapManager
    *
    * Interface that provides the backing map storage implementations for the
    * cache.
    */
    private transient com.tangosol.net.BackingMapManager __m_BackingMapManager;
    
    /**
    * Property CacheHandlerMap
    *
    */
    private transient java.util.Map __m_CacheHandlerMap;
    
    /**
    * Property Cluster
    *
    */
    private transient com.tangosol.net.Cluster __m_Cluster;
    
    /**
    * Property ContextClassLoader
    *
    */
    private ClassLoader __m_ContextClassLoader;
    
    /**
    * Property LocalCacheFactory
    *
    * deprecated
    */
    private transient com.tangosol.net.CacheFactory$LocalCacheFactory __m_LocalCacheFactory;
    
    /**
    * Property LockingEnforced
    *
    * If true the locking is enforced for put, remove and clear operations;
    * otherwise a client is responsible for calling lock and unlock explicitly.
    * Configured by "lock-enforce" element.
    * 
    * @see configure;
    */
    private boolean __m_LockingEnforced;
    
    /**
    * Property LockWaitMillis
    *
    * If locking enforcement is required then this parameter speicifes the
    * number of milliseconds to continue trying to obtain a lock; -1 blocks the
    * calling thread until the lock could be obtained. Configured by
    * "lock-wait" element.
    * 
    * @see configure
    */
    private long __m_LockWaitMillis;
    
    /**
    * Property Running
    *
    */
    private transient boolean __m_Running;
    
    /**
    * Property ServiceName
    *
    */
    private String __m_ServiceName;
    
    /**
    * Property ServiceType
    *
    */
    private String __m_ServiceType;
    
    /**
    * Property ServiceVersion
    *
    */
    private String __m_ServiceVersion;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("BackingMapContext", LocalCache$BackingMapContext.get_CLASS());
        __mapChildren.put("CacheHandler", LocalCache$CacheHandler.get_CLASS());
        }
    
    // Default constructor
    public LocalCache()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public LocalCache(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setCacheHandlerMap(new com.tangosol.util.SafeHashMap());
            setLockingEnforced(false);
            setLockWaitMillis(0L);
            setServiceType("LocalCache");
            setServiceVersion("2.2");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new LocalCache();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/LocalCache".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // From interface: com.tangosol.net.CacheService
    public void addMemberListener(com.tangosol.net.MemberListener listener)
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.net.CacheService
    public void configure(com.tangosol.run.xml.XmlElement xml)
        {
        if (xml != null)
            {
            // TODO: document in the coherence.dtd
            setLockingEnforced(xml.getSafeElement("lock-enforce").getBoolean());
            setLockWaitMillis(xml.getSafeElement("lock-wait").getLong());
            }
        }
    
    // From interface: com.tangosol.net.CacheService
    public void destroyCache(com.tangosol.net.NamedCache map)
        {
        $CacheHandler handler = ($CacheHandler) map;
        
        getCacheHandlerMap().remove(handler.getCacheName());
        
        handler.invalidate();
        }
    
    // From interface: com.tangosol.net.CacheService
    public synchronized com.tangosol.net.NamedCache ensureCache(String sName, ClassLoader loader)
        {
        // import com.tangosol.net.BackingMapManager as Manager;
        // import com.tangosol.util.SafeHashMap;
        // import java.util.Map;
        
        Map mapCache = getCacheHandlerMap();
        
        if (sName == null || sName.length() == 0)
            {
            sName = "Default";
            }
        
        $CacheHandler handler  = ($CacheHandler) mapCache.get(sName);
        if (handler == null)
            {
            Manager manager = getBackingMapManager();
            Map     map     = manager == null ?
                new SafeHashMap() : manager.instantiateBackingMap(sName);
        
            if (map == null)
                {
                throw new RuntimeException(
                    "BackingMapManager returned \"null\" for map " + sName);
                }
        
            handler = ($CacheHandler) _newChild("CacheHandler");
            handler._initFeed(map, isLockingEnforced(), getLockWaitMillis());
            handler.setCacheName(sName);
        
            mapCache.put(sName, handler);
            }
        return handler;
        }
    
    // Accessor for the property "BackingMapContext"
    /**
    * Getter for property BackingMapContext.<p>
    * The BackingMapContext (lazily created) is used by the BackingMapManager
    * (if provided).
    */
    public LocalCache$BackingMapContext getBackingMapContext()
        {
        $BackingMapContext context = __m_BackingMapContext;
        if (context == null)
            {
            synchronized (this)
                {
                context = __m_BackingMapContext;
                if (context == null)
                    {
                    context = ($BackingMapContext) _newChild("BackingMapContext");
                    setBackingMapContext(context);
                    }
                }
            }
        return context;
        }
    
    // From interface: com.tangosol.net.CacheService
    // Accessor for the property "BackingMapManager"
    /**
    * Getter for property BackingMapManager.<p>
    * Interface that provides the backing map storage implementations for the
    * cache.
    */
    public com.tangosol.net.BackingMapManager getBackingMapManager()
        {
        return __m_BackingMapManager;
        }
    
    // Accessor for the property "CacheHandlerMap"
    /**
    * Getter for property CacheHandlerMap.<p>
    */
    public java.util.Map getCacheHandlerMap()
        {
        return __m_CacheHandlerMap;
        }
    
    // From interface: com.tangosol.net.CacheService
    public java.util.Enumeration getCacheNames()
        {
        // import com.tangosol.util.IteratorEnumerator;
        
        return new IteratorEnumerator(getCacheHandlerMap().keySet().iterator());
        }
    
    // From interface: com.tangosol.net.CacheService
    // Accessor for the property "Cluster"
    /**
    * Getter for property Cluster.<p>
    */
    public com.tangosol.net.Cluster getCluster()
        {
        return __m_Cluster;
        }
    
    // From interface: com.tangosol.net.CacheService
    // Accessor for the property "ContextClassLoader"
    /**
    * Getter for property ContextClassLoader.<p>
    */
    public ClassLoader getContextClassLoader()
        {
        return __m_ContextClassLoader;
        }
    
    // From interface: com.tangosol.net.CacheService
    public com.tangosol.net.ServiceInfo getInfo()
        {
        return this;
        }
    
    // From interface: com.tangosol.net.CacheService
    // Accessor for the property "LocalCacheFactory"
    /**
    * Getter for property LocalCacheFactory.<p>
    * deprecated
    */
    public com.tangosol.net.CacheFactory$LocalCacheFactory getLocalCacheFactory()
        {
        return __m_LocalCacheFactory;
        }
    
    // Accessor for the property "LockWaitMillis"
    /**
    * Getter for property LockWaitMillis.<p>
    * If locking enforcement is required then this parameter speicifes the
    * number of milliseconds to continue trying to obtain a lock; -1 blocks the
    * calling thread until the lock could be obtained. Configured by
    * "lock-wait" element.
    * 
    * @see configure
    */
    public long getLockWaitMillis()
        {
        return __m_LockWaitMillis;
        }
    
    // From interface: com.tangosol.net.ServiceInfo
    public com.tangosol.net.Member getOldestMember()
        {
        return null;
        }
    
    // From interface: com.tangosol.net.ServiceInfo
    public com.tangosol.net.Member getServiceMember(int nId)
        {
        return null;
        }
    
    // From interface: com.tangosol.net.ServiceInfo
    public java.util.Set getServiceMembers()
        {
        // import com.tangosol.util.NullImplementation;
        
        return NullImplementation.getSet();
        }
    
    // From interface: com.tangosol.net.ServiceInfo
    // Accessor for the property "ServiceName"
    /**
    * Getter for property ServiceName.<p>
    */
    public String getServiceName()
        {
        return __m_ServiceName;
        }
    
    // From interface: com.tangosol.net.ServiceInfo
    // Accessor for the property "ServiceType"
    /**
    * Getter for property ServiceType.<p>
    */
    public String getServiceType()
        {
        return __m_ServiceType;
        }
    
    // Accessor for the property "ServiceVersion"
    /**
    * Getter for property ServiceVersion.<p>
    */
    public String getServiceVersion()
        {
        return __m_ServiceVersion;
        }
    
    // From interface: com.tangosol.net.ServiceInfo
    // Accessor for the property "ServiceVersion"
    /**
    * Getter for property ServiceVersion.<p>
    */
    public String getServiceVersion(com.tangosol.net.Member member)
        {
        return getServiceVersion();
        }
    
    // Accessor for the property "LockingEnforced"
    /**
    * Getter for property LockingEnforced.<p>
    * If true the locking is enforced for put, remove and clear operations;
    * otherwise a client is responsible for calling lock and unlock explicitly.
    * Configured by "lock-enforce" element.
    * 
    * @see configure;
    */
    public boolean isLockingEnforced()
        {
        return __m_LockingEnforced;
        }
    
    // From interface: com.tangosol.net.CacheService
    // Accessor for the property "Running"
    /**
    * Getter for property Running.<p>
    */
    public boolean isRunning()
        {
        return __m_Running;
        }
    
    // From interface: com.tangosol.net.CacheService
    public void releaseCache(com.tangosol.net.NamedCache map)
        {
        destroyCache(map);
        }
    
    // From interface: com.tangosol.net.CacheService
    public void removeMemberListener(com.tangosol.net.MemberListener listener)
        {
        }
    
    // Accessor for the property "BackingMapContext"
    /**
    * Setter for property BackingMapContext.<p>
    * The BackingMapContext (lazily created) is used by the BackingMapManager
    * (if provided).
    */
    protected void setBackingMapContext(LocalCache$BackingMapContext ctx)
        {
        __m_BackingMapContext = ctx;
        }
    
    // From interface: com.tangosol.net.CacheService
    // Accessor for the property "BackingMapManager"
    /**
    * Setter for property BackingMapManager.<p>
    * Interface that provides the backing map storage implementations for the
    * cache.
    */
    public void setBackingMapManager(com.tangosol.net.BackingMapManager manager)
        {
        if (isRunning())
            {
            throw new IllegalStateException("Service is already running");
            }
        
        __m_BackingMapManager = (manager);
        }
    
    // Accessor for the property "CacheHandlerMap"
    /**
    * Setter for property CacheHandlerMap.<p>
    */
    protected void setCacheHandlerMap(java.util.Map map)
        {
        __m_CacheHandlerMap = map;
        }
    
    // Accessor for the property "Cluster"
    /**
    * Setter for property Cluster.<p>
    */
    public void setCluster(com.tangosol.net.Cluster cluster)
        {
        __m_Cluster = cluster;
        }
    
    // From interface: com.tangosol.net.CacheService
    // Accessor for the property "ContextClassLoader"
    /**
    * Setter for property ContextClassLoader.<p>
    */
    public void setContextClassLoader(ClassLoader loader)
        {
        __m_ContextClassLoader = loader;
        }
    
    // From interface: com.tangosol.net.CacheService
    // Accessor for the property "LocalCacheFactory"
    /**
    * Setter for property LocalCacheFactory.<p>
    * deprecated
    */
    public void setLocalCacheFactory(com.tangosol.net.CacheFactory$LocalCacheFactory factory)
        {
        __m_LocalCacheFactory = factory;
        }
    
    // Accessor for the property "LockingEnforced"
    /**
    * Setter for property LockingEnforced.<p>
    * If true the locking is enforced for put, remove and clear operations;
    * otherwise a client is responsible for calling lock and unlock explicitly.
    * Configured by "lock-enforce" element.
    * 
    * @see configure;
    */
    public void setLockingEnforced(boolean fEnforced)
        {
        __m_LockingEnforced = fEnforced;
        }
    
    // Accessor for the property "LockWaitMillis"
    /**
    * Setter for property LockWaitMillis.<p>
    * If locking enforcement is required then this parameter speicifes the
    * number of milliseconds to continue trying to obtain a lock; -1 blocks the
    * calling thread until the lock could be obtained. Configured by
    * "lock-wait" element.
    * 
    * @see configure
    */
    public void setLockWaitMillis(long cWaitMillis)
        {
        __m_LockWaitMillis = cWaitMillis;
        }
    
    // Accessor for the property "Running"
    /**
    * Setter for property Running.<p>
    */
    protected void setRunning(boolean fRunning)
        {
        __m_Running = fRunning;
        }
    
    // Accessor for the property "ServiceName"
    /**
    * Setter for property ServiceName.<p>
    */
    public void setServiceName(String sName)
        {
        __m_ServiceName = sName;
        }
    
    // Accessor for the property "ServiceType"
    /**
    * Setter for property ServiceType.<p>
    */
    protected void setServiceType(String sType)
        {
        __m_ServiceType = sType;
        }
    
    // Accessor for the property "ServiceVersion"
    /**
    * Setter for property ServiceVersion.<p>
    */
    protected void setServiceVersion(String sVersion)
        {
        __m_ServiceVersion = sVersion;
        }
    
    // From interface: com.tangosol.net.CacheService
    public void shutdown()
        {
        stop();
        }
    
    // From interface: com.tangosol.net.CacheService
    public synchronized void start()
        {
        // import com.tangosol.net.BackingMapManager;
        
        setRunning(true);
        
        // per BackingMapManager contract: call init()
        BackingMapManager manager = getBackingMapManager();
        if (manager != null)
            {
            $BackingMapContext ctx = getBackingMapContext();
            ctx.setManager(manager);
        
            manager.init(ctx);
            }
        }
    
    // From interface: com.tangosol.net.CacheService
    public synchronized void stop()
        {
        // import java.util.Iterator;
        // import java.util.Map;
        // import java.util.Map$Entry as Entry;
        
        if (isRunning())
            {
            Map mapHandler = getCacheHandlerMap();
            for (Iterator iter = mapHandler.entrySet().iterator(); iter.hasNext();)
                {
                Entry entry = (Entry) iter.next();
        
                $CacheHandler handler = ($CacheHandler) entry.getValue();
                handler.invalidate();
                iter.remove();
                }
            setRunning(false);
            }
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_Name() + '{' + getServiceName() + '}';
        }
    }
