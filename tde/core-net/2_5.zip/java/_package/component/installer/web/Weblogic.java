/* Class
*     _package.component.installer.web.Weblogic
*/

package _package.component.installer.web;

import com.tangosol.engarde.ApplicationEntry;
import com.tangosol.engarde.ApplicationReader;
import com.tangosol.run.xml.SimpleParser;
import com.tangosol.run.xml.XmlDocument;
import com.tangosol.run.xml.XmlElement;

/**
* 
* +++++++++++++++++++++++++++++
* 
* Weblogic specific web application module.
*/
public class Weblogic
        extends    _package.component.installer.Web
    {
    // Fields declarations
    
    /**
    * Property JspPackage
    *
    * Specifies the package name into which all JSP pages are compiled.
    * 
    * Default is "jsp_servlet/".
    */
    private String __m_JspPackage;
    
    /**
    * Property ModuleDescriptorWL
    *
    * Parsed Weblogic specific web module descriptor (weblogic.xml)
    */
    private transient com.tangosol.run.xml.XmlElement __m_ModuleDescriptorWL;
    
    // Default constructor
    public Weblogic()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Weblogic(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(1.0F);
            setJspPackage("jsp_servlet/");
            setModuleDescriptorName("WEB-INF/web.xml");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Weblogic();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/installer/web/Weblogic".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Accessor for the property "JspPackage"
    /**
    * Getter for property JspPackage.<p>
    * Specifies the package name into which all JSP pages are compiled.
    * 
    * Default is "jsp_servlet/".
    */
    public String getJspPackage()
        {
        // import com.tangosol.run.xml.XmlElement;
        
        XmlElement xmlWL     = getModuleDescriptorWL();
        XmlElement xmlPrefix = xmlWL.findElement("jsp-descriptor/packagePrefix");
        
        return xmlPrefix == null ? __m_JspPackage : xmlPrefix.getString() + '/';
        }
    
    // Accessor for the property "ModuleDescriptorWL"
    /**
    * Getter for property ModuleDescriptorWL.<p>
    * Parsed Weblogic specific web module descriptor (weblogic.xml)
    */
    public com.tangosol.run.xml.XmlElement getModuleDescriptorWL()
        {
        return __m_ModuleDescriptorWL;
        }
    
    // Declared at the super level
    /**
    * Initialize the Installer.
    * 
    * @exception IOException thrown if an error occurs preventing the
    * Installer's initialization
    */
    protected void initialize()
            throws java.io.IOException
        {
        // import com.tangosol.engarde.ApplicationEntry;
        // import com.tangosol.engarde.ApplicationReader;
        // import com.tangosol.run.xml.SimpleParser;
        // import com.tangosol.run.xml.XmlDocument;
        
        super.initialize();
        
        ApplicationReader reader = getSourceStorage();
        ApplicationEntry  entry  = reader.getEntry("WEB-INF/weblogic.xml");
        
        _assert(entry != null, "Missing decriptor WEB-INF/weblogic.xml in " + reader);
        
        XmlDocument xml = new SimpleParser().parseXml(reader.getInputStream(entry));
        
        setModuleDescriptorWL(xml);
        }
    
    // Accessor for the property "JspPackage"
    /**
    * Setter for property JspPackage.<p>
    * Specifies the package name into which all JSP pages are compiled.
    * 
    * Default is "jsp_servlet/".
    */
    protected void setJspPackage(String sPackage)
        {
        __m_JspPackage = sPackage;
        }
    
    // Accessor for the property "ModuleDescriptorWL"
    /**
    * Setter for property ModuleDescriptorWL.<p>
    * Parsed Weblogic specific web module descriptor (weblogic.xml)
    */
    protected void setModuleDescriptorWL(com.tangosol.run.xml.XmlElement xml)
        {
        __m_ModuleDescriptorWL = xml;
        }
    }
