/* Class
*     _package.component.installer.Enterprise
*/

package _package.component.installer;

import _package.component.Installer;
import _package.component.installer.Ejb;
import _package.component.installer.Web;
import com.tangosol.engarde.ApplicationReader;
import com.tangosol.engarde.JarStorage;
import com.tangosol.run.xml.XmlElement;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

/**
* ++++++++++++++++++++++++++++++
* 
* Enterprise installer processes a J2EE application module (.ear).
*/
public class Enterprise
        extends    _package.component.Installer
    {
    // Fields declarations
    
    // Default constructor
    public Enterprise()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Enterprise(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setModuleDescriptorName("META-INF/application.xml");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant ClassRoot
    protected String getClassRoot()
        {
        return "";
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Enterprise();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/installer/Enterprise".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Close all resources used by the Installer.
    */
    public void close()
        {
        // import Component.Installer;
        // import java.util.Enumeration;
        
        // if this customizer contains any other customizers
        // close them all as well
        for (Enumeration enum = _enumChildren(); enum.hasMoreElements();)
            {
            Object child = enum.nextElement();
        
            if (child instanceof Installer)
                {
                ((Installer) child).close();
                }
            }
        
        super.close();
        }
    
    // Declared at the super level
    /**
    * Copy the resource represented by the specified entry form the
    * SourceStrorage into the TargetStorage.
    * 
    * @return true iff the entry represents a a module that is copied entirely
    * in one step, so the enclosed etries processing should be skipped
    */
    protected boolean copyResource(com.tangosol.engarde.ApplicationEntry entry)
            throws java.io.IOException
        {
        // import Component.Installer;
        // import com.tangosol.run.xml.XmlElement;
        
        String    sModuleUri  = entry.getName();
        String    sModuleName = sModuleUri.replace('.', '~');
        Installer module      = (Installer) _findChild(sModuleName);
        
        if (module != null)
            {
            XmlElement xmlWebInstall = getWebDescriptor();
            if (xmlWebInstall != null)
                {
                module.installWeb(xmlWebInstall, null);
        
                replaceResource(entry, module.getTarget());
        
                return true;
                }
            }
        
        return super.copyResource(entry);
        }
    
    // Declared at the super level
    /**
    * A static factory method that creates an instance of the Installer
    * component that is suitable for inspecting and modifying the content of
    * the specified application. A caller must call close() method to release
    * all resources held by the Installer. 
    * 
    * The fileSource parameter represents a directory where application binary
    * can be found or an application specific configuration descriptor itself.
    * 
    * The following scenarious are considered for the fileSource parameter.
    * <ul>
    * <li>a directory that contains an "extracted" J2EE application
    * <li>a directory that contains an application server specific descriptor.
    * <li>a .jar or .ear file that contains a J2EE application 
    * <li>an application-server specific application descriptor file
    * </ul>
    * 
    * @param fileSource File object representing the location of the
    * application
    * @param sServerInfo a String representing additional information about
    * targeted application server
    * 
    * @exception IOException thrown if an error occurs preventing the
    * Customizer's instantiation
    * 
    * @see ServerInfo property
    */
    public static _package.component.Installer getInstaller(com.tangosol.engarde.ApplicationReader reader, String sServerInfo)
            throws java.io.IOException
        {
        Enterprise installer = new Enterprise();
        installer.setSourceStorage(reader);
        installer.setServerInfo(sServerInfo);
        
        installer.initialize();
        
        return installer;
        }
    
    // Declared at the super level
    /**
    * Initialize the Installer.
    * 
    * @exception IOException thrown if an error occurs preventing the
    * Installer's initialization
    */
    protected void initialize()
            throws java.io.IOException
        {
        // import Component.Installer;
        // import Component.Installer.Ejb;
        // import Component.Installer.Web;
        // import com.tangosol.engarde.ApplicationReader;
        // import com.tangosol.engarde.JarStorage;
        // import com.tangosol.run.xml.XmlElement;
        // import java.io.IOException;
        // import java.util.Iterator;
        // import java.util.List;
        
        super.initialize();
        
        ApplicationReader reader = getSourceStorage();
        boolean           fJar   = reader instanceof JarStorage;
        
        // for now we assume:
        // xmlJ2eeApp.getDtdUri().equals(
        //  "http://java.sun.com/j2ee/dtds/application_1_x.dtd");
        // where x is either '2' or '3'
        
        XmlElement xmlJ2eeApp = getModuleDescriptor();
        for (Iterator iterModule = xmlJ2eeApp.getElements("module"); iterModule.hasNext();)
            {
            XmlElement xmlModule = (XmlElement) iterModule.next();
        
            for (Iterator iter = xmlModule.getElementList().iterator(); iter.hasNext();)
                {
                XmlElement xmlType = (XmlElement) iter.next();
        
                String    sModuleUri;
                Installer module;
        
                if (
                    xmlType.getName().equals("web"))
                    {
                    sModuleUri = xmlType.getSafeElement("web-uri").getString();
        
                    ApplicationReader readerModule = reader.extractApplication(sModuleUri);
                    if (readerModule == null)
                        {
                        throw new IOException("Cannot locate web module:\n" + xmlType);
                        }    
                    module = (Web) Web.getInstaller(readerModule, getServerInfo());
                    module.setDeleteSourceOnClose(fJar);
                    module.setDeleteTargetOnClose(true);
                    }
                else if (
                    xmlType.getName().equals("ejb"))
                    {
                    sModuleUri = xmlType.getString();
        
                    ApplicationReader readerModule =
                        reader.extractApplication(sModuleUri);
                    if (readerModule == null)
                        {
                        throw new IOException("Cannot locate ejb module:\n" + xmlType);
                        }
                    module = (Ejb) Ejb.getInstaller(readerModule, getServerInfo());
                    module.setDeleteSourceOnClose(fJar);
                    module.setDeleteTargetOnClose(true);
                    }
                else // "connector", "java", "alt-dd"
                    {
                    continue;
                    }
        
                if (sModuleUri.length() == 0)
                    {
                    throw new IOException("Invalid module uri:\n" + xmlType);
                    }
        
                String sModuleName = sModuleUri.replace('.', '~');
                _addChild(module, sModuleName);
                }
            }
        }
    
    // Declared at the super level
    /**
    * Getter for property TopApplication.<p>
    * Calculate property that specifies whether this installer represents the
    * top level application.
    * 
    * For example, there could be a top level Web installer representing a
    * stand-alone Web application or an Enterprise installer containing a Web
    * installer.
    */
    public boolean isTopApplication()
        {
        // Enterprise application is always a "top level"
        return true;
        }
    }
