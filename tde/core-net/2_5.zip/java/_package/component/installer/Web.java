/* Class
*     _package.component.installer.Web
*/

package _package.component.installer;

import _package.component.installer.Web;
import com.tangosol.engarde.ApplicationEntry;
import com.tangosol.engarde.ApplicationReader;
import com.tangosol.engarde.ApplicationWriter;
import com.tangosol.run.xml.SimpleDocument;
import com.tangosol.run.xml.SimpleElement;
import com.tangosol.run.xml.SimpleParser;
import com.tangosol.run.xml.XmlDocument;
import com.tangosol.run.xml.XmlElement;
import com.tangosol.run.xml.XmlHelper;
import com.tangosol.util.Base;
import com.tangosol.util.ChainedEnumerator;
import com.tangosol.util.StringTable;
import java.io.File;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

/**
* ++++++++++++++++++++++++++++++
* 
* Web installer processes a web application module (.war).
*/
public class Web
        extends    _package.component.Installer
    {
    // Fields declarations
    
    /**
    * Property COHERENCE_CONFIG_FILE
    *
    * Name of the resource containing the descriptor shipped as 
    * tangosol-coherence-override.xml
    */
    public static final String COHERENCE_CONFIG_FILE = "/web-install/coherence-config.xml";
    
    /**
    * Property SESSION_CONFIG_FILE
    *
    * Name of the resource containing the session cache config descriptor.
    */
    public static final String SESSION_CONFIG_FILE = "/web-install/session-cache-config.xml";
    
    /**
    * Property SESSION_FILE
    *
    * Name of the resource containing the Coherence session library.
    */
    public static final String SESSION_FILE = "/web-install/coherence-web.jar";
    
    /**
    * Property WEB_APP_CONFIG_FILE
    *
    * Name of the resource with default collection of context parameters for
    * web.xml descriptor.
    */
    public static final String WEB_APP_CONFIG_FILE = "/web-install/web-app-config.xml";
    
    // Default constructor
    public Web()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Web(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(1.0F);
            setModuleDescriptorName("WEB-INF/web.xml");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant ClassRoot
    protected String getClassRoot()
        {
        return "WEB-INF/classes/";
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Web();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/installer/Web".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Copy the resource represented by the specified entry form the
    * SourceStrorage into the TargetStorage.
    * 
    * @return true iff the entry represents a a module that is copied entirely
    * in one step, so the enclosed etries processing should be skipped
    */
    protected boolean copyResource(com.tangosol.engarde.ApplicationEntry entry)
            throws java.io.IOException
        {
        // import com.tangosol.engarde.ApplicationEntry;
        // import com.tangosol.run.xml.XmlElement;
        
        if (entry.getName().equals(getModuleDescriptorName()))
            {
            installWebAppDescriptor(entry);
            return false;
            }
        else
            {
            return super.copyResource(entry);
            }
        }
    
    // Declared at the super level
    /**
    * Make the final changes to the target application.
    */
    protected void finalizeInstall()
            throws java.io.IOException
        {
        // import com.tangosol.engarde.ApplicationWriter;
        // import com.tangosol.run.xml.XmlElement;
        // import java.io.File;
        
        ApplicationWriter writer = getTargetStorage();
        
        replaceResource(
            writer.createEntry("WEB-INF/lib/coherence-web.jar"),
            getClass().getResourceAsStream(SESSION_FILE), -1);
        replaceResource(
            writer.createEntry("WEB-INF/classes/session-cache-config.xml"),
            getClass().getResourceAsStream(SESSION_CONFIG_FILE), -1);
        
        XmlElement xmlParams = getWebDescriptor().getSafeElement("web-parameters");
        XmlElement xmlDeploy = findUniqueElement(xmlParams,
            "context-param", "param-name", "coherence-cluster-owned");
        if (xmlDeploy != null && xmlDeploy.getSafeElement("param-value").getBoolean())
            {
            // deploy coherence.jar and tangosol.jar within the application "WAR" file
            File fileCoherence = new File(findHome(), "coherence.jar");
            File fileTangosol  = new File(findHome(), "tangosol.jar");
            
            if (fileCoherence.isFile() && fileTangosol.isFile())
                {
                replaceResource(
                    writer.createEntry("WEB-INF/lib/coherence.jar"), fileCoherence);
                replaceResource(
                    writer.createEntry("WEB-INF/lib/tangosol.jar"),  fileTangosol);
                }
            else
                {
                getErrorList().addError(
                    "Cannot locate coherence.jar and tangosol.jar;\n" +
                    "The 'coherence-cluster-owned' setting will be ignored.");
                }
            }
        
        super.finalizeInstall();
        }
    
    // Declared at the super level
    /**
    * A static factory method that creates an instance of the Installer
    * component that is suitable for inspecting and modifying the content of
    * the specified application. A caller must call close() method to release
    * all resources held by the Installer. 
    * 
    * The fileSource parameter represents a directory where application binary
    * can be found or an application specific configuration descriptor itself.
    * 
    * The following scenarious are considered for the fileSource parameter.
    * <ul>
    * <li>a directory that contains an "extracted" J2EE application
    * <li>a directory that contains an application server specific descriptor.
    * <li>a .jar or .ear file that contains a J2EE application 
    * <li>an application-server specific application descriptor file
    * </ul>
    * 
    * @param fileSource File object representing the location of the
    * application
    * @param sServerInfo a String representing additional information about
    * targeted application server
    * 
    * @exception IOException thrown if an error occurs preventing the
    * Customizer's instantiation
    * 
    * @see ServerInfo property
    */
    public static _package.component.Installer getInstaller(com.tangosol.engarde.ApplicationReader reader, String sServerInfo)
            throws java.io.IOException
        {
        // import Component.Installer.Web;
        
        Web installer;
        
        if (reader.getEntry("WEB-INF/weblogic.xml") != null)
            {
            installer   = new Web.Weblogic();
            sServerInfo = "Weblogic/";
            }
        else
            {
            installer = new Web();
            }
        
        installer.setSourceStorage(reader);
        installer.setServerInfo(sServerInfo);
        installer.initialize();
        
        return installer;
        }
    
    // Declared at the super level
    /**
    * Inspect the content of the applications represented by the Source
    * property producing XML descriptor according to "coherence-web.xsd" and
    * adding it to the specified XML element. 
    * 
    * @param xml  the XmlElement that this method has to add information to;
    * 
    * @exception IOException thrown if an error occurs preventing the
    * application's content inspection
    */
    protected void inspectWeb()
            throws java.io.IOException
        {
        // import com.tangosol.engarde.ApplicationEntry;
        // import com.tangosol.engarde.ApplicationReader;
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.run.xml.XmlHelper;
        // import java.util.Enumeration;
        // import java.util.Iterator;
        
        super.inspectWeb();
        
        XmlElement xmlInstall = getWebDescriptor();
        _assert(xmlInstall != null);
        
        // for now we assume:
        // xmlWebApp.getDtdUri().equals(
        //  "http://java.sun.com/j2ee/dtds/web-app_2_x.dtd");
        // where x is either '2' or '3'
        
        XmlElement xmlWebApp = getModuleDescriptor();
        _assert(xmlWebApp != null);
        
        // add the "well known" JSPs
        for (Iterator iter = xmlWebApp.getElements("servlet"); iter.hasNext();)
            {
            XmlElement xmlJ2eeServlet = (XmlElement) iter.next();
        
            // web servlet could be a java class or a jsp
            String sServlet = xmlJ2eeServlet.getSafeElement("servlet-name").getString();
            if (xmlJ2eeServlet.getElement("servlet-class") == null)
                {
                String sName = xmlJ2eeServlet.getSafeElement("jsp-file").getString();
        
                while (sName.charAt(0) == '/')
                    {
                    sName = sName.substring(1);
                    }
        
                XmlElement xmlJsp = ensureUniqueElement(xmlInstall, "jsp", "name", sName);
                getResourceMap().put(sName, xmlJsp);
                }
            }
        
        // add the "well known" TLDs
        for (Iterator iter = xmlWebApp.getElements("taglib"); iter.hasNext();)
            {
            XmlElement xmlJ2eeTld = (XmlElement) iter.next();
        
            String     sName   = xmlJ2eeTld.getSafeElement("taglib-location").getString();
            XmlElement xmlTld = ensureUniqueElement(xmlInstall, "tld", "name", sName);
        
            while (sName.charAt(0) == '/')
                {
                sName = sName.substring(1);
                }
            getResourceMap().put(sName, xmlTld);
            }
        
        // iterate through all the resources looking for JSPs and TLDs
        for (Enumeration enum = getSourceStorage().entries(); enum.hasMoreElements();)
            {
            ApplicationEntry entry = (ApplicationEntry) enum.nextElement();
        
            String sName = entry.getName();
            int    cch   = sName.length();
            if (cch >= 4)
                {
                String sSuffix = sName.substring(cch - 4).toLowerCase();
                if (sSuffix.equals(".jsp"))
                    {
                    ensureUniqueElement(xmlInstall, "jsp", "name", sName);
                    getResourceMap().remove(sName);
                    }
                else if
                   (sSuffix.equals(".tld"))
                    {
                    ensureUniqueElement(xmlInstall, "tld", "name", sName);
                    getResourceMap().remove(sName);
                    }
                }
            }
        
        // add web-config parameters
        inspectWebAppParameters();
        }
    
    /**
    * Create web-app section of the coherence-web.xml
    * 
    * @exception IOException thrown if an error occurs preventing the
    * application's content inspection
    */
    protected void inspectWebAppParameters()
            throws java.io.IOException
        {
        // import com.tangosol.run.xml.SimpleParser;
        // import com.tangosol.run.xml.XmlHelper;
        // import com.tangosol.run.xml.XmlElement;
        // import java.util.Iterator;
        
        XmlElement xmlInstall       = getWebDescriptor();
        XmlElement xmlInstallParams = xmlInstall.getElement("web-parameters");
        if (xmlInstallParams == null)
            {
            xmlInstallParams = xmlInstall.addElement("web-parameters");
        
            XmlElement xmlWebParams =
                new SimpleParser().parseXml(getClass().getResourceAsStream(WEB_APP_CONFIG_FILE));
        
            XmlHelper.addElements(xmlInstallParams, xmlWebParams.getElements("context-param"));
            XmlHelper.addElements(xmlInstallParams, xmlWebParams.getElements("listener"));
            }
        }
    
    // Declared at the super level
    /**
    * Modify the specifed JSP source according to the information in the
    * specified XmlElement.
    */
    protected String installJsp(String sJsp, com.tangosol.run.xml.XmlElement xmlJsp)
        {
        // import com.tangosol.util.Base;
        
        String sJspName = xmlJsp.getSafeElement("name").getString();
        
        // we have to make sure that all the variable are unique within the
        // scope of the application to prevent a situation when
        // one jsp is included into another using an include directive:
        //  <%@ include file="..."%>
        // which could cause "variable already defined" compilation error;
        
        char[]       ach = sJspName.toCharArray();
        StringBuffer sb  = new StringBuffer("_");
        for (int i = 0, c = ach.length; i < c; i++)
            {
            char ch = ach[i];
            sb.append(Character.isJavaIdentifierStart(ch) ? ch : '_');
            }
        String sVariableScope = sb.toString();
        
        String sPrefix = getJspPrefix();
        String sSuffix = getJspSuffix();
        
        sPrefix = Base.replace(sPrefix, "%1", sVariableScope);
        sSuffix = Base.replace(sSuffix, "%1", sVariableScope);
        
        return sPrefix + sJsp + sSuffix;
        }
    
    /**
    * Modify the module descriptor entry (web.xml).
    */
    protected void installWebAppDescriptor(com.tangosol.engarde.ApplicationEntry entry)
            throws java.io.IOException
        {
        // import com.tangosol.engarde.ApplicationEntry;
        // import com.tangosol.run.xml.SimpleDocument;
        // import com.tangosol.run.xml.SimpleElement;
        // import com.tangosol.run.xml.XmlHelper;
        // import com.tangosol.run.xml.XmlDocument;
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.util.ChainedEnumerator;
        // import java.util.Iterator;
        // import java.util.List;
        
        final String CTX_INIT_FILTER  = "coherence-filter-class";
        final String CTX_INIT_SERVLET = "coherence-servlet-class";
        
        XmlElement  xmlInstall = getWebDescriptor();
        XmlDocument xmlOrg     = getModuleDescriptor();
        
        // for now we assume:
        // xmlOrg.getDtdUri().equals(
        //  "http://java.sun.com/j2ee/dtds/web-app_2_x.dtd");
        // where x is either '2' or '3'
        
        XmlDocument xmlNew = new SimpleDocument(xmlOrg.getName(),
                xmlOrg.getDtdUri(), xmlOrg.getDtdName());
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("icon"));
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("display-name"));
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("description"));
        
        // note: skip the "distributable" element; we do not want the container
        //       to think that the appliation is distributed
        
        // add Coherence configuration parameters
        XmlElement xmlInstalParams = xmlInstall.getSafeElement("web-parameters");
        XmlHelper.addElements(xmlNew, new ChainedEnumerator(
            xmlOrg.getElements("context-param"),
            xmlInstalParams.getElements("context-param")));
        
        // wrap each filter with a Coherence filter
        for (Iterator iter = xmlOrg.getElements("filter"); iter.hasNext();)
            {
            XmlElement xmlFilter = (XmlElement) iter.next();
        
            XmlElement xmlClass  = xmlFilter.getElement("filter-class");
            XmlElement xmlParam  = xmlFilter.addElement("init-param");
            xmlParam.addElement("param-name").setString(CTX_INIT_FILTER);
            xmlParam.addElement("param-value").setString(xmlClass.getString());
            xmlClass.setString("com.tangosol.coherence.servlet.api23.FilterWrapper");
        
            xmlNew.getElementList().add(xmlFilter);
            }
        
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("filter-mapping"));
        
        // if there are any application listeners collect and remove them so the
        // container does not invoke them;
        // the extracted application listeners will be added to the Coherence listeners
        // configuration section so the Coherence listeners know to delegate to them
        boolean  fListeners    = false;
        Iterator iterListeners = xmlOrg.getElements("listener");
        if (iterListeners.hasNext())
            {
            StringBuffer sbListeners = new StringBuffer();
            do
                {
                XmlElement xmlListener = (XmlElement) iterListeners.next();
                XmlElement xmlClass    = xmlListener.getElement("listener-class");
                if (xmlClass == null
                        || xmlClass.getString() == null
                        || xmlClass.getString().trim().length() == 0)
                    {
                    getErrorList().addWarning("web.xml is missing the \"listener-class\" element"
                            + " inside a \"listener\" element");
                    }
                else
                    {
                    fListeners = true;
                    sbListeners.append(',')
                               .append(xmlClass.getString().trim());
                    }
                }
            while (iterListeners.hasNext());
        
            XmlElement xmlOrgListeners = ensureUniqueElement(xmlNew,
                "context-param", "param-name", "coherence-eventlisteners");
            if (fListeners)
                {
                xmlOrgListeners.ensureElement("param-value").setString(sbListeners.substring(1));
                }
            }
        
        // install the Coherence listeners;
        // if the "required" attribute is "false", add the corresponding listener
        // only if there are application specific (original) listeners;
        // if the "required" attribute is "true", add the corresponding listener regardless;
        // this behavior allows to work around the WebSphere bug that triggers
        // ServletContextAttribute events BEFORE the ServletContext is fully initialized
        for (Iterator iter = xmlInstalParams.getElements("listener"); iter.hasNext();)
            {
            XmlElement xmlListener = (XmlElement) iter.next();
            if (fListeners || xmlListener.getSafeElement("required").getBoolean())
                {
                XmlHelper.removeElement(xmlListener, "required");
                xmlNew.getElementList().add(xmlListener);
                }
            }
        
        // wrap each servlet with a Coherence servlet
        for (Iterator iter = xmlOrg.getElements("servlet"); iter.hasNext();)
            {
            XmlElement xmlServlet = (XmlElement) iter.next();
        
            XmlElement xmlClass = xmlServlet.getElement("servlet-class");
            if (xmlClass != null)
                {
                XmlElement xmlParam  = new SimpleElement("init-param");
                xmlParam.addElement("param-name").setString(CTX_INIT_SERVLET);
                xmlParam.addElement("param-value").setString(xmlClass.getString());
        
                // TODO one of four for http vs. not, single-threaded versus not
                xmlClass.setString("com.tangosol.coherence.servlet.api22.ServletWrapper");
        
                // insert the new param into the servlet declaration
                List list = xmlServlet.getElementList();
                int  iPos = list.size();
                while (iPos > 0)
                    {
                    XmlElement xmlSub = (XmlElement) list.get(iPos - 1);
                    String     sName  = xmlSub.getName();
                    if (sName.equals("load-on-startup") ||
                        sName.equals("run-as") ||
                        sName.equals("security-role-ref"))
                        {
                        --iPos;
                        }
                    else
                        {
                        break;
                        }
                    }
                list.add(iPos, xmlParam);
                }
            xmlNew.getElementList().add(xmlServlet);
            }
        
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("servlet-mapping"));
        
        // copy the session timeout configuration information to the
        // Coherence configuration section
        XmlElement xmlConfig = xmlOrg.getElement("session-config");
        if (xmlConfig != null)
            {
            xmlConfig = xmlConfig.getElement("session-timeout");
            if (xmlConfig != null)
                {
                for (Iterator iter = xmlNew.getElements("context-param"); iter.hasNext(); )
                    {
                    XmlElement xmlParam = (XmlElement) iter.next();
                    XmlElement xmlName  = xmlParam.getSafeElement("param-name");
                    if (xmlName.getString().equals("coherence-session-expire-seconds"))
                        {
                        xmlParam.ensureElement("param-value").setInt(xmlConfig.getInt() * 60);
                        break;
                        }
                    }
                }
        
            XmlHelper.addElements(xmlNew, xmlOrg.getElements("session-config"));
            }
        
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("mime-mapping"));
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("welcome-file-list"));
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("error-page"));
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("taglib"));
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("resource-env-ref"));
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("resource-ref"));
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("security-constraint"));
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("login-config"));
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("security-role"));
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("env-entry"));
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("ejb-ref"));
        XmlHelper.addElements(xmlNew, xmlOrg.getElements("ejb-local-ref"));
        
        replaceResource(entry, xmlNew.toString().getBytes());
        }
    
    // Declared at the super level
    /**
    * Prepare the lists of web resources in need of modifications.
    */
    protected void prepareWebResources()
            throws java.io.IOException
        {
        // import com.tangosol.engarde.ApplicationEntry;
        // import com.tangosol.engarde.ApplicationReader;
        // import com.tangosol.run.xml.SimpleParser;
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.util.StringTable;
        // import java.util.Iterator;
        
        super.prepareWebResources();
        
        XmlElement  xmlInstall  = getWebDescriptor();
        StringTable tblResource = getResourceMap();
        
        // jsps
            {
            for (Iterator iter = xmlInstall.getElements("jsp"); iter.hasNext();)
                {
                XmlElement xmlJsp = (XmlElement) iter.next();
                String     sName  = xmlJsp.getElement("name").getString();
        
                tblResource.put(sName, xmlJsp);
                }
            }
        
        // tlds
            {
            ApplicationReader reader = getSourceStorage();
            for (Iterator iter = xmlInstall.getElements("tld"); iter.hasNext();)
                {
                XmlElement xmlTld = (XmlElement) iter.next();
                String     sName  = xmlTld.getElement("name").getString();
        
                ApplicationEntry entry = reader.getEntry(sName);
                if (entry == null)
                    {
                    continue;
                    }
        
                XmlElement xmlJ2eeTld =
                    new SimpleParser().parseXml(reader.getInputStream(entry));
                if (!xmlJ2eeTld.getSafeElement("listener/listener-class").isEmpty())
                    {
                    for (Iterator iterList = xmlJ2eeTld.getElements("listener"); iterList.hasNext();)
                        {
                        XmlElement xmlListener = (XmlElement) iterList.next();
                        xmlTld.getElementList().add(xmlListener);
                        }
                    tblResource.put(sName, xmlTld);
                    }
                }
            }
        }
    }
