/* Class
*     _package.component.installer.Ejb
*/

package _package.component.installer;

import _package.component.installer.Ejb;

/**
* ++++++++++++++++++++++++++++++
* 
* Ejb installer processes an ejb-jar module of a J2EE application.
*/
public class Ejb
        extends    _package.component.Installer
    {
    // Fields declarations
    
    // Default constructor
    public Ejb()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Ejb(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            set_Order(2.0F);
            setModuleDescriptorName("META-INF/ejb-jar.xml");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant ClassRoot
    protected String getClassRoot()
        {
        return "";
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Ejb();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/installer/Ejb".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * A static factory method that creates an instance of the Installer
    * component that is suitable for inspecting and modifying the content of
    * the specified application. A caller must call close() method to release
    * all resources held by the Installer. 
    * 
    * The fileSource parameter represents a directory where application binary
    * can be found or an application specific configuration descriptor itself.
    * 
    * The following scenarious are considered for the fileSource parameter.
    * <ul>
    * <li>a directory that contains an "extracted" J2EE application
    * <li>a directory that contains an application server specific descriptor.
    * <li>a .jar or .ear file that contains a J2EE application 
    * <li>an application-server specific application descriptor file
    * </ul>
    * 
    * @param fileSource File object representing the location of the
    * application
    * @param sServerInfo a String representing additional information about
    * targeted application server
    * 
    * @exception IOException thrown if an error occurs preventing the
    * Customizer's instantiation
    * 
    * @see ServerInfo property
    */
    public static _package.component.Installer getInstaller(com.tangosol.engarde.ApplicationReader reader, String sServerInfo)
            throws java.io.IOException
        {
        // import Component.Installer.Ejb;
        
        Ejb installer = new Ejb();
        
        installer.setSourceStorage(reader);
        installer.setServerInfo(sServerInfo);
        installer.initialize();
        
        return installer;
        }
    }
