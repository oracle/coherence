/* Class
*     _package.component.application.console.Coherence$DebugCacheFactory
*/

package _package.component.application.console;

import com.tangosol.util.Cache;
import com.tangosol.util.ObservableHashMap;
import java.util.Map;

public class Coherence$DebugCacheFactory
        extends    _package.component.Util
        implements com.tangosol.net.CacheFactory$LocalCacheFactory
    {
    // Fields declarations
    
    /**
    * Property CacheExpiry
    *
    */
    private int __m_CacheExpiry;
    
    /**
    * Property CacheSize
    *
    */
    private int __m_CacheSize;
    
    // Default constructor
    public Coherence$DebugCacheFactory()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Coherence$DebugCacheFactory(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setCacheExpiry(3600000);
            setCacheSize(100);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Coherence$DebugCacheFactory();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/application/console/Coherence$DebugCacheFactory".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Accessor for the property "CacheExpiry"
    /**
    * Getter for property CacheExpiry.<p>
    */
    public int getCacheExpiry()
        {
        return __m_CacheExpiry;
        }
    
    // Accessor for the property "CacheSize"
    /**
    * Getter for property CacheSize.<p>
    */
    public int getCacheSize()
        {
        return __m_CacheSize;
        }
    
    // From interface: com.tangosol.net.CacheFactory$LocalCacheFactory
    public java.util.Map instantiateLocalCache(String sName)
        {
        // import com.tangosol.util.Cache;
        // import com.tangosol.util.ObservableHashMap;
        // import java.util.Map;
        
        int nSize   = getCacheSize();
        int nExpiry = getCacheExpiry();
        return nSize > 0 ? (Map) new Cache(nSize, nExpiry) : (Map) new ObservableHashMap();

        }
    
    // Accessor for the property "CacheExpiry"
    /**
    * Setter for property CacheExpiry.<p>
    */
    public void setCacheExpiry(int nExpiry)
        {
        __m_CacheExpiry = nExpiry;
        }
    
    // Accessor for the property "CacheSize"
    /**
    * Setter for property CacheSize.<p>
    */
    public void setCacheSize(int nSize)
        {
        __m_CacheSize = nSize;
        }
    }
