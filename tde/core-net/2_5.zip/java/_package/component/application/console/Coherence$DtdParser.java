/* Class
*     _package.component.application.console.Coherence$DtdParser
*/

package _package.component.application.console;

import _package.component.net.member.ClusterMember;
import _package.component.util.daemon.queueProcessor.Service;
import com.tangosol.license.LicensedObject$LicenseData; // as LicenseData
import com.tangosol.net.Cluster;
import com.tangosol.net.Member;
import java.io.InputStream;
import java.io.InputStreamReader; // as Reader
import java.net.URL;
import java.util.Iterator;

public class Coherence$DtdParser
        extends    _package.component.util.Daemon
    {
    // Fields declarations
    
    /**
    * Property Service
    *
    * The service that requested the dtd.
    */
    private transient com.tangosol.net.Service __m_Service;
    
    // Default constructor
    public Coherence$DtdParser()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Coherence$DtdParser(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setPriority(1);
            setWaitMillis(1000L);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Coherence$DtdParser();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/application/console/Coherence$DtdParser".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Accessor for the property "Service"
    /**
    * Getter for property Service.<p>
    * The service that requested the dtd.
    */
    public com.tangosol.net.Service getService()
        {
        return __m_Service;
        }
    
    // Declared at the super level
    /**
    * Event notification to perform a regular daemon activity. To get it
    * called, another thread has to set Notification to true:
    * <code>daemon.setNotification(true);</code>
    * 
    * @see #onWait
    */
    protected void onNotify()
        {
        // import Component.Net.Member.ClusterMember;
        // import Component.Util.Daemon.QueueProcessor.Service;
        // import com.tangosol.license.LicensedObject$LicenseData as LicenseData;
        // import com.tangosol.net.Cluster;
        // import com.tangosol.net.Member;
        // import java.io.InputStream;
        // import java.io.InputStreamReader as Reader;
        // import java.net.URL;
        // import java.util.Iterator;
        
        InputStream stream = null;
        try
            {
            if (Boolean.getBoolean("tangosol.coherence.localdtd"))
                {
                return;
                }
        
            Cluster cluster      = getService().getCluster();
            Service service      = (Service) cluster.getService("Cluster");
            Member  memberThis   = cluster.getLocalMember();
            int     nMachineThis = memberThis.getMachineId();
            int     cCpuThis     = ((ClusterMember) memberThis).getCpuCount();
        
            for (Iterator iter = service.getServiceMemberSet().iterator(); iter.hasNext();)
                {
                Member member = (Member) iter.next();
                if (member != memberThis && member.getMachineId() == nMachineThis)
                    {
                    // another member on this machine has already received the DTD
                    return;
                    }
                }
        
            int      nType = 0;
            int      cCpus = 0;
            Object[] aoLic = (Object[]) service.get_Feed();
            for (int i = 0, c = aoLic.length; i < c; i++)
                {
                nType  = ((LicenseData) aoLic[i]).nLicenseType;
                cCpus += ((LicenseData) aoLic[i]).cCpus;
                }
            StringBuffer sbUrl = new StringBuffer($Module.getCoherenceUrl());
            sbUrl.append("?lt=").append(nType).append(cCpus)
                 .append("&cc=").append(cCpuThis);
            stream = new URL(sbUrl.toString()).openConnection().getInputStream();
        
            Reader reader = new Reader(stream);
            char[] ach    = new char[909]; // full header
        
            // replace with an Xml-like structure for DTD
            reader.read(ach);
            $Module.setCoherenceDtd(new String(ach));
            }
        catch (Throwable e)
            {
            }
        finally
            {
            setExiting(true);
            try
                {
                if (stream != null)
                    {
                    stream.close();
                    }
                }
            catch (Throwable e) {}
            }
        }
    
    // Accessor for the property "Service"
    /**
    * Setter for property Service.<p>
    * The service that requested the dtd.
    */
    public void setService(com.tangosol.net.Service service)
        {
        __m_Service = service;
        }
    }
