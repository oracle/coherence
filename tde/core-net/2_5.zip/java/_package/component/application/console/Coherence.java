/* Class
*     _package.component.application.console.Coherence
*/

package _package.component.application.console;

import _package.component.net.Security;
import _package.component.util.SafeNamedCache;
import _package.component.util.TransactionCache;
import com.tangosol.dev.component.ComponentClassLoader;
import com.tangosol.dev.component.NullStorage;
import com.tangosol.net.BackingMapManager;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.CacheService;
import com.tangosol.net.Cluster;
import com.tangosol.net.ConfigurableCacheFactory;
import com.tangosol.net.DefaultBackingMapManager;
import com.tangosol.net.DefaultCacheServer;
import com.tangosol.net.DefaultConfigurableCacheFactory;
import com.tangosol.net.InvocationService;
import com.tangosol.net.Member;
import com.tangosol.net.MemberListener;
import com.tangosol.net.NamedCache;
import com.tangosol.net.Service;
import com.tangosol.net.ServiceInfo;
import com.tangosol.net.cache.WrapperNamedCache;
import com.tangosol.run.xml.SimpleDocument;
import com.tangosol.run.xml.SimpleElement;
import com.tangosol.run.xml.SimpleParser;
import com.tangosol.run.xml.XmlDocument;
import com.tangosol.run.xml.XmlElement;
import com.tangosol.run.xml.XmlHelper;
import com.tangosol.run.xml.XmlValue;
import com.tangosol.util.Base;
import com.tangosol.util.Cache;
import com.tangosol.util.ClassHelper;
import com.tangosol.util.ConcurrentMap;
import com.tangosol.util.ExternalizableHelper;
import com.tangosol.util.Filter;
import com.tangosol.util.ImmutableArrayList;
import com.tangosol.util.MapListener;
import com.tangosol.util.MapListenerSupport$WrapperSynchronousListener; // as SyncListener
import com.tangosol.util.NullImplementation;
import com.tangosol.util.ObservableMap;
import com.tangosol.util.TransactionMap;
import com.tangosol.util.ValueExtractor; // as Extractor
import com.tangosol.util.WrapperException;
import com.tangosol.util.comparator.ChainedComparator;
import com.tangosol.util.comparator.InverseComparator;
import com.tangosol.util.comparator.SafeComparator;
import com.tangosol.util.extractor.ChainedExtractor;
import com.tangosol.util.extractor.ReflectionExtractor;
import com.tangosol.util.filter.LimitFilter;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.security.AccessControlException;
import java.security.PrivilegedAction;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map$Entry; // as Entry
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;

/**
* This component servces as a build target as well as a unit test for the
* Coherence API.
* 
* @see com.tangosol.net.CacheFactory
*/
public class Coherence
        extends    _package.component.application.Console
    {
    // Fields declarations
    
    /**
    * Property Cluster
    *
    * The Cluster instance.
    */
    private static transient com.tangosol.net.Cluster __s_Cluster;
    
    /**
    * Property CoherenceDtd
    *
    * The public version of coherence.dtd.
    * 
    * @see #DtdParser
    */
    private static String __s_CoherenceDtd;
    
    /**
    * Property CoherenceUrl
    *
    * The URL to the version specific coherence.dtd file.
    * 
    * @see #loadConfiguration
    */
    private static String __s_CoherenceUrl;
    
    /**
    * Property DefaultLoggingFormat
    *
    */
    
    /**
    * Property DefaultLoggingLevel
    *
    */
    
    /**
    * Property DefaultLoggingLimit
    *
    */
    
    /**
    * Property DefaultLoggingStream
    *
    */
    
    /**
    * Property FILE_CFG_COHERENCE
    *
    * File location for initial configuration information.
    * 
    * Note that the forward slash is prescribed by the JAR format and does not
    * violate the 100% Pure Java standard.
    */
    public static final String FILE_CFG_COHERENCE = "/tangosol-coherence.xml";
    
    /**
    * Property Filters
    *
    * Filters keyed by their names. Used in filter and list commands.
    */
    private transient java.util.Map __m_Filters;
    
    /**
    * Property Logger
    *
    * The low priority logging daemon.
    */
    
    /**
    * Property Map
    *
    * Map assosiated with currently tested service
    */
    private transient com.tangosol.net.NamedCache __m_Map;
    
    /**
    * Property MapValid
    *
    * Verifies whether the current map is valid.
    */
    
    /**
    * Property Prompt
    *
    * Commad prompt assosiated with currently tested service and map
    */
    private transient String __m_Prompt;
    
    /**
    * Property Service
    *
    * Service that is currently being tested
    */
    private transient com.tangosol.net.CacheService __m_Service;
    
    /**
    * Property ServiceConfigMap
    *
    * Map containing the service configuration element per service type
    * (including pseudo-types like $Logger, etc.).
    * 
    * @see #loadConfiguration
    */
    private static java.util.Map __s_ServiceConfigMap;
    
    /**
    * Property SEVERITY
    *
    */
    public static final Integer[] SEVERITY;
    
    /**
    * Property Stop
    *
    * Specifies wether to stop the command tool.
    */
    private transient boolean __m_Stop;
    
    /**
    * Property TITLE
    *
    */
    public static final String TITLE = "Tangosol Coherence";
    
    /**
    * Property VERSION
    *
    */
    public static final String VERSION = "2.5/290";
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        try
            {
            Integer[] a0 = new Integer[10];
                {
                a0[0] = new java.lang.Integer(0);
                a0[1] = new java.lang.Integer(1);
                a0[2] = new java.lang.Integer(2);
                a0[3] = new java.lang.Integer(3);
                a0[4] = new java.lang.Integer(4);
                a0[5] = new java.lang.Integer(5);
                a0[6] = new java.lang.Integer(6);
                a0[7] = new java.lang.Integer(7);
                a0[8] = new java.lang.Integer(8);
                a0[9] = new java.lang.Integer(9);
                }
            SEVERITY = a0;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // state initialization: static properties
        try
            {
            setServiceConfigMap(new java.util.HashMap());
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("CacheItem", Coherence$CacheItem.get_CLASS());
        __mapChildren.put("DtdParser", Coherence$DtdParser.get_CLASS());
        __mapChildren.put("Worker", Coherence$Worker.get_CLASS());
        }
    
    // Default constructor
    public Coherence()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Coherence(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // singleton initialization
        if (__singleton != null)
            {
            throw new IllegalStateException("A singleton for \"Coherence\" has already been set");
            }
        __singleton = this;
        
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        _addChild(new Coherence$Logger("Logger", this, true), "Logger");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant DefaultLoggingFormat
    public String getDefaultLoggingFormat()
        {
        return "{date} Tangosol Coherence {version} &lt;{level}&gt; (thread={thread}): {text}";
        }
    
    // Getter for virtual constant DefaultLoggingLevel
    public int getDefaultLoggingLevel()
        {
        return 9;
        }
    
    // Getter for virtual constant DefaultLoggingLimit
    public int getDefaultLoggingLimit()
        {
        return 0;
        }
    
    // Getter for virtual constant DefaultLoggingStream
    public String getDefaultLoggingStream()
        {
        return "stderr";
        }
    
    //++ getter for static property _Instance
    /**
    * Instantiate an Application component or return the previously
    * instantiated singleton.
    * 
    * The implementation of the get_Instance accessor on the Application
    * component is more complex than that of most other singleton components. 
    * First, it must be able to determine what application to instantiate. 
    * Secondly, it works with the _Reference property of the root component to
    * maintain a reference to the resulting application component until the
    * very last component instance is garbage-collected.
    * 
    * 1)  The _Reference property is static and located on the root component.
    * 2)  The accessor and mutator for the _Reference property are protected
    * and thus the property value can be obtained or modified by any component.
    *  (Specifically, it is set initially by Component.<init>, obtained by
    * Application.get_Instance, and set by Application.onInit.)
    * 3)  Component.<init> (the constructor of the root component) sets the
    * _Reference property to the instance of the component being constructed if
    * and only if the _Reference property is null; this guarantees that a
    * reference to the very first component to be instantiated is initially
    * stored in the _Reference property.
    * 4)  When an application component is instantiated, the Application.onInit
    * method stores a reference to that application in the _Reference property;
    * this ensures that a reference to the application will exist as long as
    * any component instance exists (because the root component class will not
    * be garbage-collectable until all component instances are determined to be
    * garbage-collectable and until all of its sub-classes are determined to be
    * garbage-collectable).  Since Application is a singleton, it is not
    * possible for a second instance of Application to exist, so once an
    * Application component has been instantiated, the _Reference property's
    * value will refer to that application until the root component class is
    * garbage-collected.
    * 5)  When Application.get_Instance() is invoked, if no singleton
    * application (Application.__singleton) has been created, then
    * Application.get_Instance is responsible for instantiating an application,
    * which will result in _Reference being set to the application instance (by
    * way of Application.onInit).
    * 
    * The implementation of Application.get_Instance is expected to take the
    * the following steps in order to instantiate the correct application
    * component:
    * 1) If the value of the _Reference property is non-null, it cannot be an
    * instance of Component.Application, because the __init method of an
    * Application component would have set the Application.__singleton field to
    * reference itself.  Application thus assumes that a non-null _Reference
    * value refers to the first component to be instantiated, and invokes the
    * _makeApplication instance method of that component.  If the return value
    * from _makeApplication is non-null, then it is returned by
    * Application.get_Instance.
    * 2)  Application.get_Instance is now in a catch-22.  No instance of
    * Component.Application exists, which means that the entry point (the
    * initially instantiated) component was not an application component, and
    * the component that was the entry point has denied knowledge of what
    * application should be instantiated.  At this point, the
    * Application.get_Instance method must determine the name of the
    * application component to instantiate without any help.  So it drops back
    * and punts.  First, it checks for an environment setting, then it checks
    * for a properties file setting, and if either one exists, then it
    * instantiates the component specified by that setting and returns it.
    * 3)  Finally, without so much as a clue telling Application.get_Instance
    * what to instantiate, it instantiates the default application context.
    * 
    * Note that in any of the above scenarios, by the time the value is
    * returned by Application.get_Instance, the value of the _Reference
    * property would have been set to the application instance by
    * Application.onInit, thus fulfilling the goal of holding a reference to
    * the application.
    * 
    * Any other case in which a reference must be maintained should be done by
    * having the application hold that reference.  In other words, as long as
    * the application doesn't go away, any reference that it holds won't go
    * away either.
    * 
    * @see Component#_Reference
    */
    public static _package.Component get_Instance()
        {
        _package.Component singleton = __singleton;
        
        if (singleton == null)
            {
            singleton = new Coherence();
            }
        else if (!(singleton instanceof Coherence))
            {
            throw new IllegalStateException("A singleton for \"Coherence\" has already been set to a different type");
            }
        return singleton;
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/application/console/Coherence".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    protected java.util.Set applyFilter(String sFilter, boolean fKeysOnly, java.util.Comparator comparator, int nPage)
        {
        // import com.tangosol.util.Base;
        // import com.tangosol.util.Filter;
        // import com.tangosol.util.filter.LimitFilter;
        // import java.util.Date;
        // import java.util.Set;
        
        try
            {
            Filter filter   = (Filter) getFilters().get(sFilter);
            Set    setEntry = null;
        
            if (filter instanceof LimitFilter)
                {
                LimitFilter filterLimit = (LimitFilter) filter;
                if (nPage >= 0)
                    {
                    filterLimit.setPage(nPage);
                    }
        
                filterLimit.setComparator(comparator); // see LimitFilter.toString()
                }
        
            if (fKeysOnly)
                {
                setEntry = getMap().keySet(filter);
                }
            else if (comparator != null)
                {
                setEntry = getMap().entrySet(filter, comparator);
                }
            else
                {
                setEntry = getMap().entrySet(filter);
                }
        
            if (filter instanceof LimitFilter && nPage < 0)
                {
                LimitFilter filterLimit = (LimitFilter) filter;
                if (setEntry.size() < filterLimit.getPageSize())
                    {
                    filterLimit.setPage(0);
                    }
                else
                    {
                    filterLimit.nextPage();
                    }
                }
            return setEntry;
            }
        catch (Exception e)
            {
            throw Base.ensureRuntimeException(e);
            }
        }
    
    protected Object convertArgument(String sParam)
        {
        // import com.tangosol.net.Member;
        // import com.tangosol.util.Base;
        // import com.tangosol.util.ClassHelper;
        // import com.tangosol.util.ImmutableArrayList;
        // import java.util.Date;
        
        int ofStart = sParam.indexOf('{'); // }
        if (ofStart == 0)
            {
            if (sParam.equals("{cluster}"))
                {
                return getCluster();
                }
            if (sParam.equals("{date}"))
                {
                return new Date(getCluster().getTimeMillis());
                }
            if (sParam.equals("{map}"))
                {
                return getMap();
                }
            if (sParam.equals("{Member}"))
                {
                return getCluster().getLocalMember();
                }
            if (sParam.equals("{random}"))
                {
                return new Integer((int) (Integer.MAX_VALUE*Math.random()));
                }
            if (sParam.equals("{result}"))
                {
                return ((ThreadLocal) get_Sink()).get();
                }
            if (sParam.equals("{service}"))
                {
                return getService();
                }
            if (sParam.equals("{time}"))
                {
                return new Long(getCluster().getTimeMillis());
                }
        
            if (sParam.indexOf(',') > 0)
                {
                // comma delimited Set, List or Collection
                String   sValue  = sParam.substring(1, sParam.length() - 1);
                Object[] aoValue = sValue.length() == 0 ? ClassHelper.VOID :
                    convertArguments(Base.parseDelimitedString(sValue, ','));
                return new ImmutableArrayList(aoValue);
                }
            }
        
        if (ofStart >= 0)
            {
            String[][] aasReplace = null;
            try
                {
                long    dtTime = getCluster().getTimeMillis();
                Member  member = getCluster().getLocalMember();
                aasReplace = new String[][]
                    {
                    {"{date}",    String.valueOf(new Date(dtTime))},
                    {"{random}",  String.valueOf((int) (Integer.MAX_VALUE*Math.random()))},
                    {"{result}",  String.valueOf(((ThreadLocal) get_Sink()).get())},
                    {"{time}",    String.valueOf(dtTime)},
                    {"{Member}",  String.valueOf(member)},
                    {"{member}",  member == null ? "0" : String.valueOf(member.getId())},
                    };
                 }
            catch (Exception e) {}
        
            for (int iR = 0, cR = aasReplace == null ? 0 : aasReplace.length; iR < cR; iR++)
                {
                String[] asReplace = aasReplace[iR];
                sParam = Base.replace(sParam, asReplace[0], asReplace[1]);
                }
            int ofBegin = sParam.indexOf("{random:"); // "random:<max>}"
            if (ofBegin >= 0)
                {
                int ofEnd = sParam.indexOf('}', ofBegin);
                if (ofEnd > ofBegin)
                    {
                    String sMax  = sParam.substring(ofBegin + "{random:".length(), ofEnd);
                    int    iMax  = sMax.length() == 0 ?
                        Integer.MAX_VALUE : Integer.parseInt(sMax);
                    sParam = Base.replace(sParam,
                        sParam.substring(ofBegin, ofEnd + 1),
                        String.valueOf((int) (iMax*Math.random())));
                    }
                }
            }
        
        if (sParam.startsWith("["))
            {
            if (sParam.equals("[null]"))
                {
                return null;
                }
            if (sParam.equals("[true]"))
                {
                return Boolean.TRUE;
                }
            if (sParam.equals("[false]"))
                {
                return Boolean.FALSE;
                }
            if (sParam.endsWith("]"))
                {
                // comma delimited array
                String   sValue  = sParam.substring(1, sParam.length() - 1);
                return sValue.length() == 0 ? ClassHelper.VOID :
                    convertArguments(Base.parseDelimitedString(sValue, ','));
                }
            }
        else if (sParam.endsWith("L") || sParam.endsWith("l"))
            {
            try
                {
                return Long.valueOf(sParam.substring(0, sParam.length() - 1));
                }
            catch (NumberFormatException e) {}
            }
        else if (sParam.endsWith("F") || sParam.endsWith("f"))
            {
            try
                {
                return Float.valueOf(sParam.substring(0, sParam.length() - 1));
                }
            catch (NumberFormatException e) {}
            }
        else if (sParam.endsWith("D") || sParam.endsWith("d"))
            {
            try
                {
                return Double.valueOf(sParam.substring(0, sParam.length() - 1));
                }
            catch (NumberFormatException e) {}
            }
        else
            {
            try
                {
                return Integer.valueOf(sParam);
                }
            catch (NumberFormatException e) {}
            }
        return sParam;
        }
    
    public Object[] convertArguments(String[] asParam)
        {
        int      cParams = asParam == null ? 0 : asParam.length;
        Object[] aoParam = new Object[cParams];
        for (int i = 0; i < cParams; i++)
            {
            String sParam = asParam[i];
            Object oParam = convertArgument(sParam);
        
            aoParam[i] = oParam;
            if (oParam != sParam)
                {
                asParam[i] = String.valueOf(oParam); 
                }
            }
        
        return aoParam;
        }
    
    // Declared at the super level
    /**
    * Prints out the specified message according to the Application context. 
    * Derived applications should provide an appropriate implementation for
    * this method if the output should not be sent to the standard output and
    * error output.  For example, if an application wanted to log output, this
    * would be the method to override.
    * 
    * @param message  the text message to display
    * @param severity  0 for informational, ascending for more serious output
    * (the default implementation assumes anything not 0 is an error and should
    * be printed to the system error stream)
    */
    public void debugOutput(String message, int severity)
        {
        // import com.tangosol.net.Cluster;
        // import java.sql.Timestamp;
        
        $Logger logger = ensureLogger();
        if (severity <= logger.getLevel())
            {
            Integer ISev;
            try
                {
                ISev = SEVERITY[severity];
                }
            catch (Exception e)
                {
                ISev = new Integer(severity);
                }
        
            Integer IMember;
            try
                {
                IMember = new Integer(getCluster().getLocalMember().getId());
                }
            catch (Exception e)
                {
                IMember = new Integer(0);
                }
        
            Object[] loginfo = new Object[]
                {
                new Timestamp(System.currentTimeMillis()),
                message,
                ISev,
                Thread.currentThread(),
                IMember,
                };
        
            logger.getQueue().add(loginfo);
            }
        }
    
    protected void doBackup(String[] asParam, boolean fSilent)
        {
        // import com.tangosol.util.ExternalizableHelper;
        // import java.io.BufferedOutputStream;
        // import java.io.DataOutputStream;
        // import java.io.File;
        // import java.io.FileOutputStream;
        // import java.io.IOException;
        // import java.util.Map;
        
        if (asParam.length == 0)
            {
            _trace("File name is expected");
            return;
            }
        
        Map map = getMap();
        
        try
            {
            File             file       = new File(asParam[0]);
            FileOutputStream streamFile = new FileOutputStream(file);
            DataOutputStream streamData = new DataOutputStream(
                new BufferedOutputStream(streamFile, 32*1024));
        
            ExternalizableHelper.writeMap(streamData, map);
        
            streamData.close();
            streamFile.close();
        
            if (!fSilent)
                {
                _trace(map.size() + " entries written to " + file.getAbsolutePath() +
                    " (" + file.length() + " bytes)");
                }
            }
        catch (IOException e)
            {
            _trace("Failed to backup: " + e);
            }
        }
    
    protected void doBulkPut(String[] asParam, boolean fSilent)
        {
        // import java.util.Date;
        // import java.util.HashMap;
        // import java.util.Map;
        // import java.util.Random;
        
        if (!isMapValid())
            {
            return;
            }
        
        int cIters = 1000;
        int cbData = 1000;
        int iFirst = 1;
        try
            {
            cIters = Integer.parseInt(asParam[0]);
            cbData = Integer.parseInt(asParam[1]);
            iFirst = Integer.parseInt(asParam[2]);
            }
        catch (Exception e)
            {
            _trace("Assuming iterations=" + cIters + ", size=" + cbData + ", first=" + iFirst);
            }
        boolean fAll = asParam.length > 3 && "all".equals(asParam[3]);
        
        if (cIters < 0)
            {
            cIters = -cIters;
            iFirst -= cIters - 1;
            }
        
        if (!fSilent)
            {
            _trace(new Date() + ": adding " + cIters +
                " items (starting with #" + iFirst + ") each " + cbData + " bytes ...");
            }
        
        int nOrigin = 0;
        try
            {
            nOrigin = getService().getCluster().getLocalMember().getId();
            }
        catch (NullPointerException e) {} // local cache has no LocalMember
        
        Random random = new Random();
        Map    mapAll = fAll ? new HashMap() : (Map) getMap();
        long   lBegin = System.currentTimeMillis();
        for (int i = iFirst, iLast = iFirst + cIters; i < iLast; ++i)
            {
            if (cbData > 0)
                {
                byte[] ab = new byte[cbData];
                ab[0] = (byte) random.nextInt();
                mapAll.put(new Integer(i), ab);
                }
            else
                {
                $CacheItem item = new $CacheItem();
                item.setIndex(i);
                item.setOrigin(nOrigin);
        
                Object oKey = cbData < 0 ? (Object) item : new Integer(i);
                mapAll.put(oKey, item);
                }
            }
        if (fAll)
            {
            getMap().putAll(mapAll);
            }
        long lElapsed = System.currentTimeMillis() - lBegin;
        if (!fSilent)
            {
            _trace(new Date() + ": done putting (" + lElapsed + "ms)");
            }

        }
    
    protected void doBulkRemove(String[] asParam, boolean fSilent)
        {
        // import java.util.Date;
        // import java.util.HashSet;
        // import java.util.Set;
        
        if (!isMapValid())
            {
            return;
            }
        
        int cIters = 1000;
        int iFirst = 1;
        try
            {
            cIters = Integer.parseInt(asParam[0]);
            iFirst = Integer.parseInt(asParam[1]);
            }
        catch (Exception e)
            {
            _trace("Assuming iterations=" + cIters + ", first=" + iFirst);
            }
        boolean fAll = asParam.length > 2 && "all".equals(asParam[2]);
        
        if (cIters < 0)
            {
            cIters = -cIters;
            iFirst -= cIters - 1;
            }
        
        if (!fSilent)
            {
            _trace(new Date() + ": removing " + cIters +
                " items (starting with #" + iFirst + ")");
            }
        
        boolean fResult = false;
        Set     setAll  = fAll ? new HashSet() : getMap().keySet();
        long    lBegin  = System.currentTimeMillis();
        for (int i = iFirst, iLast = iFirst + cIters; i < iLast; ++i)
            {
            Object oKey = new Integer(i);
            if (fAll)
                {
                setAll.add(oKey);
                }
            else
                {
                fResult |= setAll.remove(oKey);
                }
            }
        if (fAll)
            {
            fResult = getMap().keySet().removeAll(setAll);
            }
        long lElapsed = System.currentTimeMillis() - lBegin;
        if (!fSilent)
            {
            _trace(new Date() + ": done removing; " +
                   "result=" + fResult + " (" + lElapsed + "ms)");
            }
        }
    
    protected void doCache(String[] asParam, boolean fSilent)
        {
        // import com.tangosol.net.CacheFactory;
        // import com.tangosol.net.ConfigurableCacheFactory;
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.util.ClassHelper;
        // import com.tangosol.util.NullImplementation;
        
        ConfigurableCacheFactory factory = CacheFactory.getConfigurableCacheFactory();
        
        String      sName   = asParam[0];
        boolean     fUnique = asParam.length > 1 && asParam[1].equals("unique");
        boolean     fBinary = asParam.length > 1 && asParam[1].equals("binary");
        ClassLoader loader  = fUnique ? getUniqueClassLoader() :
                              fBinary ? NullImplementation.getClassLoader() :
                                        getClass().getClassLoader();
        NamedCache  cache   = CacheFactory.getCache(sName, loader);
        
        setPrompt(cache.getCacheName());
        setService(cache.getCacheService());
        setMap(cache);
        
        if (!fSilent)
            {
            try
                {
                String sScheme = (String) ClassHelper.invoke(factory,
                    "findSchemeMapping", new Object[] {sName});
                Object xmlCfg  = ClassHelper.invoke(factory,
                    "resolveScheme", new Object[]{sScheme});
                _trace(String.valueOf(xmlCfg));
                }
            catch (Exception e) {}
            }
        }
    
    protected void doCacheFactory(String[] asParam, boolean fSilent)
        {
        // import com.tangosol.net.CacheFactory;
        // import com.tangosol.net.ConfigurableCacheFactory;
        // import com.tangosol.net.DefaultCacheServer;
        // import com.tangosol.net.DefaultConfigurableCacheFactory;
        
        int cParams = asParam.length;
        if (cParams > 0)
            {
            ConfigurableCacheFactory factory =
                new DefaultConfigurableCacheFactory(asParam[0]);
            CacheFactory.setConfigurableCacheFactory(factory);
        
            if (cParams > 1 && asParam[1].equals("start"))
                {
                DefaultCacheServer.start(factory);
                }
            }
        
        if (!fSilent)
            {
            _trace(CacheFactory.getConfigurableCacheFactory().
                getConfig().getSafeElement("caching-scheme-mapping").toString());
            }
        }
    
    protected void doFilter(Object[] aoParam)
        {
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.util.Base;
        // import com.tangosol.util.ClassHelper;
        // import com.tangosol.util.Filter;
        // import com.tangosol.util.ImmutableArrayList;
        // import java.lang.reflect.InvocationTargetException;
        // import java.util.Map;
        
        NamedCache map = getMap();
        
        Map      mapFilter     = getFilters();
        int      cParams       = aoParam.length;
        String   sFilterName   = (String) aoParam[0];
        String   sFilterType   = (String) aoParam[1];
        Object[] aoFilterParam = new Object[cParams - 2];
        
        try
            {    
            if (sFilterType.equals("In"))
                {
                aoFilterParam[0] = aoParam[2]; // sMethod
        
                String sFilter = aoParam[3].toString();
                Filter filter  = (Filter) mapFilter.get(sFilter);
                if (filter == null)
                    {
                    String[] asValue = Base.parseDelimitedString(sFilter, ',');
                    Object[] aoValue = convertArguments(asValue);
                    // comma delimited array
                    aoFilterParam[1] = new ImmutableArrayList(aoValue);
                    }
                else
                    {
                    aoFilterParam[1] = map.keySet(filter);
                    }
                }
            else
                {
                for (int i = 2; i < cParams; i++)
                    {
                    Filter  filter = (Filter) mapFilter.get(aoParam[i]);
                    aoFilterParam[i - 2] = filter == null ? aoParam[i] : filter;
                    }
                }
        
            Class clzFilter = Class.forName("com.tangosol.util.filter." +
                sFilterType + "Filter");
            Filter filter = (Filter) ClassHelper.newInstance(clzFilter, aoFilterParam);
            mapFilter.put(sFilterName, filter);
        
            _trace(String.valueOf(filter));
            }
        catch (Throwable e)
            {
            if (e instanceof InvocationTargetException)
                {
                e = ((InvocationTargetException) e).getTargetException();
                }
            _trace("Invalid filter format: " + e);
            }
        }
    
    protected Object doFunction(String sFunction, Object[] aoParam, boolean fSilent)
        {
        Object  oTarget    = null;
        boolean fSetTarget = true;
        
        if (sFunction.startsWith("&&") || sFunction.startsWith("&!"))
            {
            fSetTarget = sFunction.startsWith("&&");
            sFunction  = sFunction.substring(2);
            oTarget    = ((ThreadLocal) get_Sink()).get();
            }
        else if (sFunction.startsWith("&/")) // "&/com/tangosol/net/CacheFactory.log"
            {
            try
                {
                String sClass = sFunction.substring(2);
                int    ofClz  = sClass.indexOf('.');
        
                sFunction = sClass.substring(ofClz + 1);
                sClass    = sClass.substring(0, ofClz).replace('/', '.');
                try
                    {
                    oTarget = Class.forName(sClass);
                    }
                catch (ClassNotFoundException e)
                    {
                    oTarget = Class.forName("java.lang." + sClass);
                    }
                }
            catch (Exception e)
                {
                _trace("Invalid format: " + e);
                return e;
                }
            }
        else if (sFunction.startsWith("&{"))
            {
            int ofTarget = sFunction.indexOf("}.");
            if (ofTarget > 0)
                {
                oTarget   = convertArgument(sFunction.substring(1, ofTarget + 1));
                sFunction = sFunction.substring(ofTarget + 2);
                }
            }
        else
            {
            sFunction = sFunction.substring(1);
            oTarget   = getMap();
            if (oTarget == null)
                {
                oTarget = getCluster();
                }
            }
        oTarget = processFunction(oTarget, sFunction, fSilent, aoParam);
        
        if (fSetTarget)
            {
            ((ThreadLocal) get_Sink()).set(oTarget);
            }
        
        return oTarget;
        }
    
    protected void doInvoke(String sService, String[] asParam, boolean fSilent)
        {
        // import com.tangosol.net.InvocationService;
        // import com.tangosol.net.Member;
        // import java.util.Iterator;
        // import java.util.Map;
        // import java.util.Set;
        // import java.util.TreeMap;
        
        // <command> ["all" | "other" | "senior" | <id>] [("async" | "sync")]
        
        InvocationService srvc = getInvocationService(sService);
        
        int cParams = asParam.length;
        if (cParams == 0)
            {
            return;
            }
        
        String  sCommand = asParam[0];
        String  sTarget  = cParams >= 2 ?  asParam[1] : "all";
        boolean fAsync   = cParams >= 3 && asParam[2].startsWith("a");
        
        $CacheItem task = new $CacheItem();
        task.setInvokeCommand(sCommand);
        
        Set setMember = null;
        if (!sTarget.equals("all"))
            {
            setMember = srvc.getInfo().getServiceMembers();
            if (sTarget.equals("other"))
                {
                setMember.remove(getCluster().getLocalMember());
                }
            else if (sTarget.equals("senior"))
                {
                setMember.clear();
                setMember.add(srvc.getInfo().getOldestMember());
                }
            else
                {
                setMember.clear();
                Set setAll = srvc.getInfo().getServiceMembers();
                try
                    {
                    int nMember = Integer.parseInt(sTarget);
                    for (Iterator iter = setAll.iterator(); iter.hasNext();)
                        {
                        Member member = (Member) iter.next();
                        if (member.getId() == nMember)
                            {
                            setMember.add(member);
                            break;
                            }
                        }
                    }
                catch (NumberFormatException e)
                    {
                    _trace("Unknown target: " + sTarget);
                    return;
                    }
                }
            }
        
        if (fAsync)
            {
            srvc.execute(task, setMember, ($Worker) _newChild("Worker"));
            }
        else
            {
            Map mapResult = srvc.query(task, setMember);
            if (!fSilent)
                {
                if (mapResult.isEmpty())
                    {
                    _trace("No results");
                    }
                else
                    {
                    mapResult = new TreeMap(mapResult); // sort by member id
                    for (Iterator iter = mapResult.keySet().iterator(); iter.hasNext();)
                        {
                        Member member  = (Member) iter.next();
                        Object oResult = mapResult.get(member);
                        _trace("Member " + member.getId() + ", Result=" +
                            (oResult instanceof Throwable ?
                                oResult + "\n" + getStackTrace((Throwable) oResult) :
                                String.valueOf(oResult)));
                        }
                    }
                }
            }
        }
    
    protected void doJmx(String[] asParam)
        {
        // import com.tangosol.util.ClassHelper;
        
        int cParams = asParam.length; 
        int nPort   = 8082;
        try
            {
            if (cParams > 0)
                {
                nPort = Integer.parseInt(asParam[0]);
                }
            }
        catch (NumberFormatException e) {}
        
        boolean fStart = cParams <= 1 || !asParam[1].equals("stop");
        String  sName  = "Adapter" + nPort;
        if (fStart)
            {
            // HttpAdapter adapter = new HttpAdapter();
            // adapter.start(nPort, getCluster());
            Component adapter = _newInstance("Component.Net.HttpAdapter");
            try
                {
                ClassHelper.invoke(adapter, "start",
                    new Object[] {new Integer(nPort), getCluster()});
                }
            catch (Exception e) {}
        
            _addChild(adapter, sName);
            try
                {
                Runtime.getRuntime().exec("explorer.exe http://localhost:" + nPort);
                }
            catch (Exception e) {}
            _trace("HttpAdapter is installed at http://localhost:" + nPort);
            }
        else
            {
            Component adapter = _findChild(sName);
            if (adapter != null)
                {
                // adapter.stop();
                try
                    {
                    ClassHelper.invoke(adapter, "stop", ClassHelper.VOID);
                    }
                catch (Exception e) {}
        
                _removeChild(adapter);
                }
            }
        }
    
    protected void doList(String[] asParam, boolean fSilent)
        {
        // import com.tangosol.util.Base;
        // import com.tangosol.util.comparator.ChainedComparator;
        // import com.tangosol.util.comparator.InverseComparator;
        // import com.tangosol.util.extractor.ReflectionExtractor as Extractor;
        // import java.util.Comparator;
        // import java.util.Iterator;
        // import java.util.Map;
        // import java.util.Map$Entry as Entry;
        // import java.util.Set;
        
        // list <filter-name> [[[<method>[,<method>]*] desc] page]
        
        Set setEntry;
        Map map     = getMap();
        int cParams = asParam.length;
        if (cParams > 0)
            {
            String sName = asParam[0];
            if (getFilters().containsKey(sName))
                {
                Comparator comparator = null;
                int        nPage      = -1;
                if (cParams > 1)
                    {
                    String[] asMethod = Base.parseDelimitedString(asParam[1], ',');
                    int      cMethods = asMethod.length;
                    if (cMethods > 1)
                        {
                        Comparator[] acomp = new Comparator[cMethods];
                        for (int i = 0; i < cMethods; i++)
                            {
                            acomp[i] = new Extractor(asMethod[i]);
                            }
                        comparator = new ChainedComparator(acomp);
                        }
                    else if (!asMethod[0].equals("[null]"))
                        {
                        comparator = new Extractor(asMethod[0]);
                        }
                    if (cParams > 2 && asParam[2].startsWith("desc"))
                        {
                        comparator = new InverseComparator(comparator);
                        }
                    if (cParams > 3)
                        {
                        nPage = Integer.parseInt(asParam[3]);
                        }
                    }
                setEntry = applyFilter(sName, false, comparator, nPage);
                }
            else
                {
                map = getService().ensureCache(sName, null);
                setEntry = map.entrySet();
                }
            }
        else
            {
            setEntry = map.entrySet();
            }
        
        int cSize  = setEntry.size();
        int cLimit = Math.min(cSize, 50);
        int c      = 0;
        for (Iterator iter = setEntry.iterator(); iter.hasNext();)
            {
            Entry entry = (Entry) iter.next();
        
            if (c++ < cLimit && !fSilent) // we want to "get" them all regardless
                {
                _trace(entry.getKey() + " = " + entry.getValue());
                }
            }
        if (cLimit < cSize && !fSilent)
            {
            _trace("Only " + cLimit + " out of total " + cSize + " items were printed");
            }
        if (c != cSize)
            {
            _trace("Iterator returned " + c + " items");
            }
        }
    
    protected void doListen(String sSource, boolean fStop, com.tangosol.util.Filter filter, Object oKey, boolean fLite)
        {
        // import com.tangosol.net.BackingMapManager;
        // import com.tangosol.net.MemberListener;
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.net.CacheService;
        // import com.tangosol.util.ClassHelper;
        // import com.tangosol.util.MapListener;
        // import com.tangosol.util.MapListenerSupport$WrapperSynchronousListener as SyncListener;
        // import com.tangosol.util.ObservableMap;
        // import java.util.Map;
        
        // resolve which map: assume cluster map
        NamedCache    map       = getMap();
        CacheService  service   = map.getCacheService();
        ObservableMap mapListen = map;
        
        if (sSource.equals("local"))
            {
            BackingMapManager mgr = service.getBackingMapManager();
            if (mgr == null)
                {
                _trace("Service " + service.getInfo().getServiceName() +
                       " does not have BackingMapManager;" +
                       " use coherence-cache-config.xml and 'cache' command to create a cache");
                return;
                }
        
            String sCacheName = map.getCacheName();
            try
                {
                mapListen = (ObservableMap) ClassHelper.invoke(mgr, "getBackingMap",
                                    new Object[] {sCacheName});
                }
            catch (ClassCastException e)
                {
                _trace("Local storage for cache: " + sCacheName + " is not observable;" +
                       " use coherence-cache-config.xml to configure");
                return;
                }
            catch (Exception e)
                {
                _trace("Service " + service.getInfo().getServiceName() +
                       " uses unsupported BackingMapManager: " + mgr.getClass().getName());
                return;
                }
            
            if (mapListen == null)
                {
                _trace("Local storage for cache: " + sCacheName + " is missing");
                }
            }
        
        $Worker worker = ($Worker) _findChild("Worker!Listener");
        if (fStop)
            {
            if (worker == null)
                {
                _trace("No listener to stop");
                }
            else if (sSource.equals("members"))
                {
                service.removeMemberListener(worker);
                }
            else if (sSource.equals("master"))
                {
                service.getCluster().
                    ensureService("Cluster", "Cluster").removeMemberListener(worker);
                }
            else
                {
                MapListener listener = worker;
                if (sSource.endsWith("-sync"))
                    {
                    listener = new SyncListener(listener);
                    }
                if (oKey == null)
                    {
                    mapListen.removeMapListener(listener, filter);
                    }
                else
                    {
                    mapListen.removeMapListener(listener, oKey);
                    }
                }
            }
        else
            {
            if (worker == null)
                {
                worker = new $Worker();
                _addChild(worker, "Worker!Listener");
                }
            if (sSource.equals("members"))
                {
                service.addMemberListener(worker);
                }
            else if (sSource.equals("master"))
                {
                service.getCluster().
                    ensureService("Cluster", "Cluster").addMemberListener(worker);
                }
            else
                {
                MapListener listener = worker;
                if (sSource.endsWith("-sync"))
                    {
                    listener = new SyncListener(listener);
                    }
                if (oKey == null)
                    {
                    mapListen.addMapListener(listener, filter, fLite);
                    }
                else
                    {
                    mapListen.addMapListener(listener, oKey, fLite);
                    }
                }
            }
        }
    
    protected void doLog(Object[] aoParam, boolean fSilent)
        {
        // import com.tangosol.util.Base;
        
        int    cParams = aoParam.length;
        String sMsg    = null;
        int    cchMsg  = 50;
        if (cParams >= 1)
            {
            if (aoParam[0] instanceof Number)
                {
                cchMsg = ((Number) aoParam[0]).intValue();
                cchMsg = Math.max(1, cchMsg);
                }
            else
                {
                sMsg   = String.valueOf(aoParam[0]);
                cchMsg = sMsg.length();
                }
            }
        if (sMsg == null)
            {
            sMsg = Base.dup('*', cchMsg);
            }
        
        int cIters = 1;
        if (cParams >= 2 && aoParam[1] instanceof Number)
            {
            cIters = ((Number) aoParam[1]).intValue();
            }
        cIters = Math.max(1, cIters);
        
        int nLevel = 3;
        if (cParams >= 3 && aoParam[2] instanceof Number)
            {
            nLevel = ((Number) aoParam[2]).intValue();
            }
        
        if (!fSilent)
            {
            _trace("Logging " + cIters + " messages of " + cchMsg + " characters at level " + nLevel + ":");
            }
        
        if (cIters == 1)
            {
            _trace(sMsg, nLevel);
            }
        else
            {
            for (int i = 1; i <= cIters; ++i)
                {
                _trace(i + ":" + sMsg, nLevel);
                }
            }
        }
    
    protected void doMap(String[] asParam, boolean fSilent)
        {
        // import Component.Util.Daemon.QueueProcessor.Service;
        // import Component.Util.SafeNamedCache;
        // import com.tangosol.net.CacheService;
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.net.cache.WrapperNamedCache;
        // import com.tangosol.util.ObservableMap;
        
        CacheService service = getService();
        
        // format of the CacheName argument is:
        // [<ServiceType>[!<ServiceName>]:]<CacheName>
        
        int    cParams       = asParam.length;
        String sCacheName    = cParams == 0 ? "Default" : asParam[0];
        String sPrefix       = "";
        String sServiceType  = service == null ? "ReplicatedCache" : service.getInfo().getServiceType();
        String sServiceName  = service == null ? sServiceType      : service.getInfo().getServiceName();
        
        // parse the CacheName arg
        int ofServiceType = sCacheName.indexOf(':');
        if (ofServiceType >= 0)
            {
            sServiceType = sCacheName.substring(0, ofServiceType);
            sCacheName   = sCacheName.substring(ofServiceType + 1);
        
            if (sCacheName.length() == 0)
                {
                sCacheName = null;
                }
        
            int ofServiceName = sServiceType.indexOf('!');
            if (ofServiceName > 0)
                {
                sServiceName = sServiceType.substring(ofServiceName + 1);
                sServiceType = sServiceType.substring(0, ofServiceName);
                }
        
            if (!sServiceType.endsWith("Cache"))
                {
                sServiceType = sServiceType + "Cache";
                if (ofServiceName < 0)
                    {
                    sServiceName = sServiceType;
                    }
                }
            }
        
        String sInternal = null;
        if (sCacheName != null && sCacheName.startsWith("@"))
            {
            sInternal  = sCacheName;
            sCacheName = "Default";
            }
        
        if (
            sServiceType.equals("ReplicatedCache"))
            {
            service = getReplicatedCache(sServiceName);
            sPrefix = "Replicated!";
            }
        else if (
            sServiceType.equals("OptimisticCache"))
            {
            service = getOptimisticCache(sServiceName);
            sPrefix = "Optimistic!";
            }
        else if (
            sServiceType.equals("DistributedCache"))
            {
            service = getDistributedCache(sServiceName);
            sPrefix = "Distributed!";
            }
        else if (
            sServiceType.equals("SimpleCache"))
            {
            service = getSimpleCache(sCacheName);
            sPrefix = "Simple!";
            }
        else if (
            sServiceType.equals("LocalCache"))
            {
            service = getLocalCache(sServiceName);
            sPrefix = "Local!";
            }
        else
            {
            service = (CacheService) ensureCluster().ensureService(sServiceName, sServiceType);
            if (!service.isRunning())
                {
                service.configure(getServiceConfig(sServiceType));
                service.start();
                }
            sPrefix = sServiceName + '!';
            }
        
        boolean     fUnique = cParams > 1 && asParam[1].equals("unique");
        ClassLoader loader  = fUnique ? getUniqueClassLoader() : getClass().getClassLoader();
        NamedCache  cache   = service.ensureCache(sCacheName, loader);
        
        if (sInternal != null)
            {
            while (cache instanceof SafeNamedCache)
                {
                cache = ((SafeNamedCache) cache).getNamedCache();
                }
            service = cache.getCacheService();
        
            ObservableMap map = null;
            if (sInternal.equals("@service"))
                {
                map = ((Service) service).getServiceConfigMap();
                }
            else if (sInternal.startsWith("@member"))
                {
                int nMember = ((Service) service).getThisMember().getId();
                try
                    {
                    nMember = Integer.parseInt(sInternal.substring("@member".length()));
                    }
                catch (Exception e) {}
                map = ((Service) service).getServiceMemberSet().getMemberConfigMap(nMember);
                }
            if (map == null)
                {
                _trace("No such map: " + sInternal);
                return;
                }
        
            cache   = new WrapperNamedCache(map, sInternal, service);
            sPrefix = "";
            }
        
        if (!fSilent)
            {
            _trace("\n" + service.getCluster().getLocalMember());
            _trace(String.valueOf(service));
            setPrompt(sPrefix + cache.getCacheName());
            }
        
        setService(service);
        setMap(cache);
        }
    
    protected void doRepeat(String sCmd, int cIter, boolean fForce)
            throws java.lang.InterruptedException
        {
        // import java.util.ArrayList;
        // import java.util.List;
        
        List list   = new ArrayList();
        int  cch    = sCmd.length();
        int  ofPrev = 0;
        while (ofPrev < cch)
            {
            int ofNext;
            if (sCmd.charAt(ofPrev) == '{')
                {
                ofPrev++;
                ofNext = sCmd.lastIndexOf('}');
                }
            else
                {
                ofNext = sCmd.indexOf(';', ofPrev);
                }
        
            if (ofNext < 0)
                {
                list.add(sCmd.substring(ofPrev));
                break;
                }
            else
                {
                list.add(sCmd.substring(ofPrev, ofNext));
                ofPrev = ofNext + 1;
                }
            }
        
        int      cCmds = list.size();
        String[] asCmd = (String[]) list.toArray(new String[cCmds]);
        
        for (int i = 0; i < cIter; i++)
            {
            ((ThreadLocal) get_Sink()).set(new Integer(i));
            for (int j = 0; j < cCmds; j++)
                {
                sCmd = asCmd[j].trim();
                if (sCmd.length() > 0)
                    {
                    Object oResult = processCommand(sCmd);
                    if (oResult instanceof Throwable)
                        {
                        if (fForce)
                            {
                            // continue next iteration
                            break;
                            }
                        else
                            {
                            // get out
                            cIter = i;
                            }
                        }
                    }
                }
            }
        }
    
    protected void doRestore(String[] asParam, boolean fSilent)
        {
        // import com.tangosol.util.ExternalizableHelper;
        // import java.io.BufferedInputStream;
        // import java.io.DataInputStream;
        // import java.io.File;
        // import java.io.FileInputStream;
        // import java.io.IOException;
        // import java.util.HashMap;
        // import java.util.Map;
        
        if (asParam.length == 0)
            {
            _trace("File name is expected");
            return;
            }
        
        Map map = getMap();
        
        try
            {
            ClassLoader     loader     = getClass().getClassLoader();
            File            file       = new File(asParam[0]);
            FileInputStream streamFile = new FileInputStream(file);
            DataInputStream streamData = new DataInputStream(
                new BufferedInputStream(streamFile, 32*1024));
        
            int cBlock = Integer.MAX_VALUE;
            if (asParam.length > 1)
                {
                try
                    {
                    cBlock = Integer.parseInt(asParam[1]);
                    _assert(cBlock > 0);
                    }
                catch (Exception e)
                    {
                    _trace("Invalid block size");
                    return;
                    }
                }
            int cEntries = ExternalizableHelper.readMap(streamData, map, cBlock, loader);
        
            if (!fSilent)
                {
                _trace(cEntries + " entries restored from " + file.getAbsolutePath());
                }
        
            streamData.close();
            streamFile.close();
            }
        catch (IOException e)
            {
            _trace("Failed to restore: " + e);
            }
        }
    
    protected void doScan(String[] asParam)
        {
        // import java.util.Map;
        
        int iFirst = 1;
        int cIters = 1000;
        try
            {
            iFirst = Integer.parseInt(asParam[0]);
            cIters = Integer.parseInt(asParam[1]);
            }
        catch (NumberFormatException e)
            {
            _trace("Assuming first=" + iFirst + ", iterations=" + cIters);
            }
        
        Map map       = getMap();
        int iGapStart = 0;
        int iGapEnd   = 0;
        for (int i = iFirst, iLast = iFirst + cIters; i < iLast; ++i)
            {
            if (!map.containsKey(new Integer(i)))
                {
                iGapStart = i;
                iGapEnd   = i;
                while (++i < iLast && !map.containsKey(new Integer(i)))
                    {
                    iGapEnd = i;
                    }
                if (iGapStart == iGapEnd)
                    {
                    _trace("\nMissing item: " + iGapStart);
                    }
                else
                    {
                    _trace("\nMissing items: " + iGapStart + " .. " + iGapEnd);
                    }
                }
            if (i > iGapStart + 1000 && i % 1000 == 0)
                {
                System.out.print("\b\b\b\b\b\b\b" + i);
                System.out.flush();
                }
            }
        }
    
    protected Object doSecure(String[] asParam, boolean fSilent)
            throws java.lang.InterruptedException
        {
        // import Component.Net.Security;
        // import com.tangosol.util.ClassHelper;
        // import com.tangosol.util.WrapperException;
        // import java.lang.reflect.InvocationTargetException;
        // import java.security.AccessControlException;
        // import java.security.PrivilegedAction;
        
        // <name> <password> <command>
        
        int cParams = asParam.length;
        if (cParams < 3)
            {
            return null;
            }
        
        String sName = asParam[0];
        char[] acPwd = asParam[1].toCharArray();
        String sCmd  = asParam[2];
        
        for (int i = 3; i < cParams; i++)
            {
            sCmd += ' ' + asParam[i];
            }
        
        boolean fImpersonate = false;
        if (sName.startsWith("hack_"))
            {
            fImpersonate = true;
            sName = sName.substring("hack_".length());
            }
        
        // avoid JDK 1.4 compile time dependency
        Object           handler;
        PrivilegedAction action;
        Object           subject;
        try
            {
            Class clz = Class.forName("com.tangosol.net.security.SimpleHandler");
            handler = ClassHelper.newInstance(clz, new Object[] {sName, acPwd});
        
            // this.processCommand(sCmd);
            action  = Security.createPrivilegedAction(
                getClass().getMethod("processCommand", new Class[] {String.class}),
                this, new Object[] {sCmd});
        
            // allow for debugging without packaging
            if (getClass().getName().startsWith("_package"))
                {
                subject = Security.login(handler);
                }
            else
                {
                subject = ClassHelper.invokeStatic(
                    Class.forName("com.tangosol.net.security.Security"),
                    "login", new Object[] {handler});
                }
            }
        catch (Throwable e)
            {
            if (e instanceof InvocationTargetException)
                {
                e = ((InvocationTargetException) e).getTargetException();
                }
            _trace(e);
            return null;
            }
        
        if (fImpersonate)
            {
            subject = Security.getInstance().impersonate(subject, sName, asParam[0]);
            }
        
        try
            {
            if (getClass().getName().startsWith("_package"))
                {
                return Security.runAs(subject, action);
                }
            else
                {
                return ClassHelper.invokeStatic(
                    Class.forName("com.tangosol.net.security.Security"),
                    "runAs", new Object[] {subject, action});
                }
            }
        catch (Throwable e)
            {
            Throwable eOrig = e;
            while (true)
                {
                if (e instanceof WrapperException)
                    {
                    e = ((WrapperException) e).getOriginalException();
                    }
                else if (e instanceof InvocationTargetException)
                    {
                    e = eOrig = ((InvocationTargetException) e).getTargetException();
                    }
                else
                    {
                    break;
                    }
                }
            if (e instanceof AccessControlException)
                {
                _trace("Permission rejected: " +
                    ((AccessControlException) e).getPermission(), 1);
                }
            _trace(eOrig);
            return null;
            }
        }
    
    protected void doTransaction(String sFunction, String[] asParam)
        {
        // import com.tangosol.util.TransactionMap;
        
        if (sFunction.equals("begin"))
            {
            String sConcur    = asParam[0]; // O[ptimistic] or P[essimistic]
            String sIsolation = asParam[1]; // C[ommited], R[epeatable] or S[erialized]
            int nTimeout      = 20;
            try
                {
                nTimeout = Integer.parseInt(asParam[2]);
                }
            catch (Exception e) {}
        
            int nConcur;
            switch (sConcur.charAt(0))
                {
                case 'O':
                case 'o':
                    nConcur = TransactionMap.CONCUR_OPTIMISTIC;
                    break;
                default:
                    nConcur = TransactionMap.CONCUR_PESSIMISTIC;
                    break;
                    }
        
            int nIsolation;
            switch (sIsolation.charAt(0))
                {
                case 'C':
                case 'c':
                    nIsolation = TransactionMap.TRANSACTION_GET_COMMITTED;
                    break;
                case 'R':
                case 'r':
                    nIsolation = TransactionMap.TRANSACTION_REPEATABLE_GET;
                    break;
                default:
                    nIsolation = TransactionMap.TRANSACTION_SERIALIZABLE;
                    break;
                }
            txStart(nConcur, nIsolation, nTimeout);
            }
        else if (
            sFunction.equals("commit"))
            {
            try
                {
                ((TransactionMap) getMap()).prepare();
                ((TransactionMap) getMap()).commit();
                }
            finally
                {
                txEnd();
                }
            }
        else if (
            sFunction.equals("rollback"))
            {
            ((TransactionMap) getMap()).rollback();
            txEnd();
            }
        }
    
    protected synchronized com.tangosol.net.Cluster ensureCluster()
        {
        // import com.tangosol.net.Cluster;
        
        Cluster cluster = getCluster();
        if (!cluster.isRunning())
            {
            cluster.configure(getServiceConfig("Cluster"));
            cluster.start();
            }
        return cluster;
        }
    
    protected Coherence$Logger ensureLogger()
        {
        $Logger logger = getLogger();
        if (!logger.isStarted())
            {
            logger.configure(getServiceConfig("$Logger"));
            logger.start();
            }
        return logger;
        }
    
    // Declared at the super level
    /**
    * Getter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public Object get_Sink()
        {
        Object oSink = super.get_Sink();
        if (oSink == null)
            {
            synchronized (this)
                {
                oSink = super.get_Sink();
                if (oSink == null)
                    {
                    set_Sink(oSink = new ThreadLocal());
                    }
                }
            }
        return oSink;
        }
    
    // Accessor for the property "Cluster"
    /**
    * Getter for property Cluster.<p>
    * The Cluster instance.
    */
    public static synchronized com.tangosol.net.Cluster getCluster()
        {
        // import com.tangosol.net.Cluster;
        
        Cluster cluster = __s_Cluster;
        if (cluster == null)
            {
            // cluster = new Component.Net.Cluster();
            cluster = new Component.Util.SafeCluster();
            setCluster(cluster);
            }
        return cluster;
        }
    
    // Accessor for the property "CoherenceDtd"
    /**
    * Getter for property CoherenceDtd.<p>
    * The public version of coherence.dtd.
    * 
    * @see #DtdParser
    */
    public static String getCoherenceDtd()
        {
        return __s_CoherenceDtd;
        }
    
    // Accessor for the property "CoherenceUrl"
    /**
    * Getter for property CoherenceUrl.<p>
    * The URL to the version specific coherence.dtd file.
    * 
    * @see #loadConfiguration
    */
    public static String getCoherenceUrl()
        {
        return __s_CoherenceUrl;
        }
    
    /**
    * For performance measuring only
    */
    protected synchronized com.tangosol.net.CacheService getDistributedCache(String sServiceName)
        {
        // import com.tangosol.net.Cluster;
        // import com.tangosol.net.CacheFactory;
        // import com.tangosol.net.CacheService;
        
        // allow for debugging without packaging
        if (getClass().getName().startsWith("_package"))
            {
            Cluster cluster = ensureCluster();
            synchronized (cluster)
                {
                CacheService service = (CacheService) cluster.
                    ensureService(sServiceName, CacheService.TYPE_DISTRIBUTED);
        
                if (!service.isRunning())
                    {
                    service.configure(getServiceConfig(CacheService.TYPE_DISTRIBUTED));
                    service.start();
                    }
                return service;
                }
            }
        else
            {
            return CacheFactory.getDistributedCacheService(sServiceName);
            }
        }
    
    // Accessor for the property "Filters"
    /**
    * Getter for property Filters.<p>
    * Filters keyed by their names. Used in filter and list commands.
    */
    public java.util.Map getFilters()
        {
        // import java.util.HashMap;
        // import java.util.Map;
        
        Map mapFilter = __m_Filters;
        if (mapFilter == null)
            {
            setFilters(mapFilter = new HashMap());
            }
        return mapFilter;
        }
    
    /**
    * For performance measuring only
    */
    protected synchronized com.tangosol.net.InvocationService getInvocationService(String sServiceName)
        {
        // import com.tangosol.net.Cluster;
        // import com.tangosol.net.CacheFactory;
        // import com.tangosol.net.InvocationService;
        
        // allow for debugging without packaging
        if (getClass().getName().startsWith("_package"))
            {
            Cluster cluster = ensureCluster();
            synchronized (cluster)
                {
                InvocationService service = (InvocationService)
                    cluster.ensureService(sServiceName, InvocationService.TYPE_DEFAULT);
        
                if (!service.isRunning())
                    {
                    service.configure(getServiceConfig(InvocationService.TYPE_DEFAULT));
                    service.start();
                    }
                return service;
                }
            }
        else
            {
            return CacheFactory.getInvocationService(sServiceName);
            }
        }
    
    /**
    * Local cache testing
    */
    protected synchronized com.tangosol.net.CacheService getLocalCache(String sServiceName)
        {
        // import com.tangosol.net.Cluster;
        // import com.tangosol.net.CacheFactory;
        // import com.tangosol.net.CacheService;
        
        // allow for debugging without packaging
        if (getClass().getName().startsWith("_package"))
            {
            Cluster cluster = getCluster();
            synchronized (cluster)
                {
                CacheService service = (CacheService) cluster.
                    ensureService(sServiceName, CacheService.TYPE_LOCAL);
        
                if (!service.isRunning())
                    {
                    service.configure(getServiceConfig(CacheService.TYPE_LOCAL));
                    service.start();
                    }
                return service;
                }
            }
        else
            {
            return CacheFactory.getLocalCacheService(sServiceName);
            }
        }
    
    /**
    * @see CacheFactory#getLocalTransaction
    */
    public static com.tangosol.util.TransactionMap getLocalTransaction(com.tangosol.net.NamedCache cache)
        {
        // import Component.Util.TransactionCache;
        
        TransactionCache mapTx = new TransactionCache.Local();
        
        mapTx.initialize(cache);
        
        return mapTx;
        }
    
    // Accessor for the property "Logger"
    /**
    * Getter for property Logger.<p>
    * The low priority logging daemon.
    */
    protected Coherence$Logger getLogger()
        {
        return ($Logger) _findChild("Logger");
        }
    
    // Accessor for the property "Map"
    /**
    * Getter for property Map.<p>
    * Map assosiated with currently tested service
    */
    public com.tangosol.net.NamedCache getMap()
        {
        return __m_Map;
        }
    
    /**
    * Optimistic cache testing
    */
    protected synchronized com.tangosol.net.CacheService getOptimisticCache(String sServiceName)
        {
        // import com.tangosol.net.Cluster;
        // import com.tangosol.net.CacheFactory;
        // import com.tangosol.net.CacheService;
        // import com.tangosol.net.DefaultBackingMapManager;
        
        // allow for debugging without packaging
        if (getClass().getName().startsWith("_package"))
            {
            Cluster cluster = ensureCluster();
            synchronized (cluster)
                {
                CacheService service = (CacheService) cluster.
                    ensureService(sServiceName, CacheService.TYPE_OPTIMISTIC);
        
                if (!service.isRunning())
                    {
                    DefaultBackingMapManager manager = new DefaultBackingMapManager();
                    manager.setDefaultConfig(getServiceConfig("$LocalFactory"));
                    
                    service.configure(getServiceConfig(CacheService.TYPE_OPTIMISTIC));
                    service.setBackingMapManager(manager);
                    service.start();
                    }
                return service;
                }
            }
        else
            {
            return CacheFactory.getOptimisticCacheService(sServiceName);
            }
        }
    
    // Accessor for the property "Prompt"
    /**
    * Getter for property Prompt.<p>
    * Commad prompt assosiated with currently tested service and map
    */
    public String getPrompt()
        {
        return __m_Prompt;
        }
    
    /**
    * For performance measuring only
    */
    protected synchronized com.tangosol.net.CacheService getReplicatedCache(String sServiceName)
        {
        // import com.tangosol.net.Cluster;
        // import com.tangosol.net.CacheFactory;
        // import com.tangosol.net.CacheService;
        
        // allow for debugging without packaging
        if (getClass().getName().startsWith("_package"))
            {
            Cluster cluster = ensureCluster();
            synchronized (cluster)
                {
                CacheService service = (CacheService) cluster.
                    ensureService(sServiceName, CacheService.TYPE_REPLICATED);
        
                if (!service.isRunning())
                    {
                    service.configure(getServiceConfig(CacheService.TYPE_REPLICATED));
                    service.start();
                    }
                return service;
                }
            }
        else
            {
            return CacheFactory.getReplicatedCacheService(sServiceName);
            }
        }
    
    // Accessor for the property "Service"
    /**
    * Getter for property Service.<p>
    * Service that is currently being tested
    */
    public com.tangosol.net.CacheService getService()
        {
        return __m_Service;
        }
    
    public static com.tangosol.run.xml.XmlElement getServiceConfig(String sServiceType)
        {
        // import com.tangosol.run.xml.XmlElement;
        // import java.util.Map;
        
        Map mapConfig = getServiceConfigMap();
        if (mapConfig.isEmpty())
            {
            synchronized (mapConfig)
                {
                if (mapConfig.isEmpty())
                    {
                    loadConfiguration();
                    }
                }
            }
        
        XmlElement xml = (XmlElement) mapConfig.get(sServiceType);
        return xml == null ? null : (XmlElement) xml.clone();
        }
    
    // Accessor for the property "ServiceConfigMap"
    /**
    * Getter for property ServiceConfigMap.<p>
    * Map containing the service configuration element per service type
    * (including pseudo-types like $Logger, etc.).
    * 
    * @see #loadConfiguration
    */
    protected static java.util.Map getServiceConfigMap()
        {
        return __s_ServiceConfigMap;
        }
    
    /**
    * For performance measuring only
    */
    protected synchronized com.tangosol.net.CacheService getSimpleCache(String sServiceName)
        {
        // import com.tangosol.net.Cluster;
        // import com.tangosol.net.CacheFactory;
        // import com.tangosol.net.CacheService;
        
        sServiceName = sServiceName == null || sServiceName.length() == 0 ?
            "Default" : sServiceName;
        
        Cluster cluster;
        
        // allow for debugging without packaging
        if (getClass().getName().startsWith("_package"))
            {
            cluster = ensureCluster();
            }
        else
            {
            cluster = CacheFactory.ensureCluster();
            }
        
        CacheService service =
            (CacheService) cluster.ensureService(sServiceName, "SimpleCache");
        
        if (!service.isRunning())
            {
            service.configure(getServiceConfig("SimpleCache"));
            service.start();
            }
        
        return service;
        }
    
    /**
    * Creates a unique class loader for testing ClassLoader specific issues.
    */
    protected ClassLoader getUniqueClassLoader()
        {
        // import com.tangosol.dev.component.ComponentClassLoader;
        // import com.tangosol.dev.component.NullStorage;
        
        return new ComponentClassLoader(getClass().getClassLoader(), new NullStorage());
        }
    
    // Accessor for the property "MapValid"
    /**
    * Getter for property MapValid.<p>
    * Verifies whether the current map is valid.
    */
    protected boolean isMapValid()
        {
        if (getMap() == null)
            {
            _trace("Please specify the current map using \"cache\" or \"map\" command");
            return false;
            }
        return true;
        }
    
    // Accessor for the property "Stop"
    /**
    * Getter for property Stop.<p>
    * Specifies wether to stop the command tool.
    */
    public boolean isStop()
        {
        return __m_Stop;
        }
    
    protected static void loadConfiguration()
        {
        // import com.tangosol.run.xml.SimpleElement;
        // import com.tangosol.run.xml.SimpleParser;
        // import com.tangosol.run.xml.XmlDocument;
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.run.xml.XmlHelper;
        // import com.tangosol.util.WrapperException;
        // import java.io.InputStream;
        // import java.io.IOException;
        // import java.util.Iterator;
        // import java.util.Map;
        
        XmlDocument xmlCoherence;
        
        // instantiate the Coherence singleton (necessary for logging)
        get_Instance();
        
        Map mapConfig = getServiceConfigMap();
        try
            {
            // load the configuration from preset location
            InputStream stream = get_Class().getResourceAsStream(FILE_CFG_COHERENCE);
            if (stream == null)
                {
                System.err.println(TITLE + ": Configuration file is missing: \"" +
                    FILE_CFG_COHERENCE + "\" -- using default settings.");
        
                mapConfig.put("Cluster",              new SimpleElement("cluster-config"));
                mapConfig.put("$Logger",              new SimpleElement("logging-config"));
                mapConfig.put("$ConfigurableFactory", new SimpleElement("configurable-cache-factory-config"));
                mapConfig.put("$LocalFactory",        new SimpleElement("local-cache-factory-config"));
                mapConfig.put("$Security",            new SimpleElement("security-config"));
                return;
                }
            else
                {
                xmlCoherence = new SimpleParser().parseXml(stream, "ISO-8859-1");
                }
            }
        catch (IOException e)
            {
            throw new WrapperException(e);
            }
        
        String sDtdUri = xmlCoherence.getDtdUri();
        if (sDtdUri == null)
            {
            System.err.println(TITLE + ": DOCTYPE element is missing: \"" + FILE_CFG_COHERENCE +
                "\" -- some functionality may not work properly.");
            }
        setCoherenceUrl(sDtdUri);
        
        System.out.println('\n' + TITLE + " Version " + VERSION + '\n');
        
        // consider checking the DTD version and compare with the current one
        
        // adjust configurations from soft-coded system property names
        XmlHelper.replaceSystemProperties(xmlCoherence, "system-property");
        
        // adjust configuration from the xml-overrides
        loadOverrides(xmlCoherence);
        
        XmlElement xmlCluster    = xmlCoherence.getSafeElement("cluster-config");
        XmlElement xmlLogging    = xmlCoherence.getSafeElement("logging-config");
        XmlElement xmlFactory    = xmlCoherence.getSafeElement("configurable-cache-factory-config");
        XmlElement xmlFactoryOld = xmlCoherence.getSafeElement("local-cache-factory-config");
        XmlElement xmlSecurity   = xmlCoherence.getSafeElement("security-config");
        
        mapConfig.put("Cluster",              xmlCluster.clone());
        mapConfig.put("$Logger",              xmlLogging.clone());
        mapConfig.put("$ConfigurableFactory", xmlFactory.clone());
        mapConfig.put("$LocalFactory",        xmlFactoryOld.clone());
        mapConfig.put("$Security",            xmlSecurity.clone());
        
        // service-specific parameters
        for (Iterator iter = xmlCoherence.getSafeElement("cluster-config/services")
                .getElements("service"); iter.hasNext(); )
            {
            XmlElement xmlSvc   = (XmlElement) iter.next();
            String     sSvcType = xmlSvc.getSafeElement("service-type").getString("service");
        
            // transform generic param structure into service-specific XML
            XmlElement xmlParams = new SimpleElement(sSvcType);
            XmlHelper.transformInitParams(xmlParams, xmlSvc.getSafeElement("init-params"));
        
            mapConfig.put(sSvcType, xmlParams);
            }
        }
    
    /**
    * If the specified XmlElement allows to override some values by the
    * xml-override elemenrs, overload the elements.
    */
    protected static void loadOverrides(com.tangosol.run.xml.XmlElement xml)
        {
        // import com.tangosol.run.xml.SimpleParser;
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.run.xml.XmlValue;
        // import com.tangosol.run.xml.XmlHelper;
        // import com.tangosol.util.WrapperException;
        // import java.io.InputStream;
        // import java.io.IOException;
        // import java.util.Iterator;
        
        final String ATTR_NAME = "xml-override";
        XmlValue attr = xml.getAttribute(ATTR_NAME);
        if (attr != null)
            {
            // remove the attribute
            xml.setAttribute(ATTR_NAME, null);
        
            // find the element's override
            String sResource = attr.getString();
            try
                {
                InputStream stream = get_Class().getResourceAsStream(sResource);
                if (stream != null)
                    {
                    XmlElement xmlOverride = new SimpleParser().parseXml(stream, "ISO-8859-1");
        
                    if (xmlOverride.getName().equals(xml.getName()))
                        {
                        // it's important to resolve system properties and
                        // load overrides recursivly BEFORE calling the
                        // overrideElement() which could be affected by the attributes
                        XmlHelper.replaceSystemProperties(xmlOverride, "system-property");
                        loadOverrides(xmlOverride);
        
                        XmlHelper.overrideElement(xml, xmlOverride);
                        }
                    else
                        {
                        System.err.println(TITLE + ": Root name mismatch in the document: "
                            + sResource + "; " + "expected name: \"" + xml.getName() + '"');
                        }
                    }
                }
            catch (IOException e)
                {
                System.err.println(TITLE + ": Failed to parse the element override: "
                    + sResource + "; " + e);
                }
            catch (Exception e)
                {
                System.err.println(TITLE + ": Failed to apply the element override: "
                    + sResource + "; " + e);
                }
            }
        
        // do the same for each contained element
        for (Iterator iter = xml.getElementList().iterator(); iter.hasNext();)
            {
            loadOverrides((XmlElement) iter.next());
            }
        }
    
    // Declared at the super level
    /**
    * This method is the entry point for executable Java applications.
    * 
    * Certain types of Java applications are started by the JVM invoking the
    * main() method of the entry point class.  The Application component
    * assists in building these types of applications by providing a default
    * implementation for the main() method.  Unfortunately, main() is not
    * virtual (it must be static) so an application must either override main()
    * or provide configuration information so that the default main()
    * implementation can determine the identity of the entry point class.  For
    * example, the following is a script that an application
    * (Component.Application.Console.HelloWorld) could use to ensure that the
    * HelloWorld application is instantiated:
    * 
    *     // instantiate HelloWorld
    *     get_Instance();
    *     // use the default main() implementation provided by
    * Component.Application
    *     super.main(asArgs);
    * 
    * To avoid creating the script on HelloWorld.main(), and if the application
    * were jar'd, the META-INF directory in the .jar file would contain the
    * following:
    * 
    *     # -- contents of META-INF/MANIFEST.MF
    *     Main-Class:_package.Component.Application.Console.HelloWorld
    * 
    *     # -- contents of META-INF/application.properties --
    *     app=Console.HelloWorld
    * 
    * The application identity could alternatively be provided on the command
    * line, for example if the application has not been jar'd:
    * 
    *     java _package.Component.Application.Console.HelloWorld
    * -app=Console.HelloWorld
    * 
    * The default implementation (Application.main) stores the arguments for
    * later use in the indexed Argument property, instantiates the application
    * (if an instance does not already exist), and invokes the run() method of
    * the application instance.  It is expected that application implementors
    * will provide an implementation for run() and not for main().
    * 
    * Note that "_package." is a place-holder for a deployer-specified package
    * name, for example "com.mycompany.myapplication".  The Packaging Wizard
    * allows the deployer to specify the package into which the application
    * will be deployed.  The above examples would have to be changed
    * accordingly.
    * 
    * @param asArgs  an array of string arguments
    * 
    * @see #get_Instance
    */
    public static void main(String[] asArgs)
        {
        setArgument(asArgs);
        
        ((Coherence) get_Instance()).run();
        }
    
    public static String[] parseArguments(String sArguments)
        {
        // import java.util.ArrayList;
        // import java.util.List;
        
        if (sArguments.length() == 0)
            {
            return new String[0];
            }
        
        char[]  ach     = sArguments.toCharArray();
        int     cch     = ach.length;
        boolean fEsc    = false;
        boolean fQuote  = false;
        char    chQuote = 0;
        List    list    = new ArrayList();
        StringBuffer sb = new StringBuffer();
        for (int ofCur = 0; ofCur < cch; ++ofCur)
            {
            char ch = ach[ofCur];
        
            if (fEsc)
                {
                switch (ch)
                    {
                    // escapables
                    case '\'':
                        sb.append('\'');
                        break;
                    case '\"':
                        sb.append('\"');
                        break;
                    case '\\':
                        sb.append('\\');
                        break;
                    case 'b':
                        sb.append('\b');
                        break;
                    case 'f':
                        sb.append('\f');
                        break;
                    case 'n':
                        sb.append('\n');
                        break;
                    case 'r':
                        sb.append('\r');
                        break;
                    case 't':
                        sb.append('\t');
                        break;
        
                    // special! allow space to be escaped (instead
                    // of quoting params)
                    case ' ':
                        sb.append(' ');
                        break;
        
                    default:
                        // oops ... it wasn't an escape
                        sb.append('\\')
                          .append(ch);
                        break;
                    }
                fEsc = false;
                }
            else
                {
                switch (ch)
                    {
                    case '\'':
                    case '\"':
                        if (fQuote)
                            {
                            if (ch == chQuote)
                                {
                                fQuote = false;
                                }
                            else
                                {
                                sb.append(ch);
                                }
                            }
                        else
                            {
                            fQuote  = true;
                            chQuote = ch;
                            }
                        break;
        
                    case ' ':
                        if (fQuote)
                            {
                            sb.append(' ');
                            }
                        else if (sb.length() > 0)
                            {
                            list.add(sb.toString());
                            sb.setLength(0);
                            }
                        break;
        
                    case '\\':
                        fEsc = true;
                        break;
        
                    default:
                        sb.append(ch);
                        break;
                    }
                }
            }
        
        if (fQuote)
            {
            throw new IllegalArgumentException("Unmatched quote ("
                + chQuote + ") in command.");
            }
        
        if (sb.length() > 0)
            {
            list.add(sb.toString());
            }
        
        return (String[]) list.toArray(new String[list.size()]);
        }
    
    /**
    * Load the public coherence.dtd for later use.
    */
    public static synchronized void prepareDtd(com.tangosol.net.Service service)
        {
        // import com.tangosol.run.xml.SimpleDocument;
        
        if (getCoherenceDtd() == null)
            {
            setCoherenceDtd("");
        
            $DtdParser parser = new $DtdParser();
            parser.setService(service);
            parser.start();
            }
        }
    
    public Object processCommand(String sCmd)
            throws java.lang.InterruptedException
        {
        // import com.tangosol.net.CacheService;
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.net.Service;
        // import com.tangosol.net.ServiceInfo;
        // import com.tangosol.util.Cache;
        // import com.tangosol.util.ClassHelper;
        // import com.tangosol.util.Filter;
        // import com.tangosol.util.comparator.SafeComparator;
        // import com.tangosol.util.ValueExtractor as Extractor;
        // import com.tangosol.util.extractor.ChainedExtractor;
        // import com.tangosol.util.extractor.ReflectionExtractor;
        // import java.util.Date;
        // import java.util.Enumeration;
        // import java.util.Iterator;
        // import java.util.Map;
        // import java.util.Set;
        
        CacheService service = getService();
        NamedCache   map     = getMap();
        Object       oResult = null;
        String       sFunction;
        
        boolean fSilent = false;
        if (sCmd.charAt(0) == '@')
            {
            fSilent = true;
            sCmd    = sCmd.substring(1);
            }
        
        int ofFunction = sCmd.indexOf(' ');
        if (ofFunction < 0)
            {
            sFunction = sCmd;
            sCmd      = "";
            }
        else
            {
            sFunction = sCmd.substring(0, ofFunction);
            sCmd      = sCmd.substring(ofFunction + 1).trim();
            }
        
        if (sFunction.startsWith("#")) // #N or ##N
            {
            String  sIter  = sFunction.substring(1);
            boolean fForce = false; // ignore exceptions
            if (sIter.startsWith("#"))
                {
                sIter  = sIter.substring(1);
                fForce = true;
                }
        
            try
                {
                int cIter = Integer.parseInt(sIter);
                doRepeat(sCmd, cIter, fForce);
                }
            catch (NumberFormatException e)
                {
                _trace("invalid counter: " + sIter);
                }
            return null;
            }
        
        String[] asParam = parseArguments(sCmd);
        Object[] aoParam = convertArguments(asParam);
        int      cParams = asParam.length;
        
        if (sFunction.startsWith("&"))
            {
            oResult = doFunction(sFunction, aoParam, fSilent);
            }
        else if (
            sFunction.equals("lock") ||
            sFunction.equals("unlock"))
            {
            if (isMapValid())
                {
                oResult = doFunction('&' + sFunction, aoParam, fSilent);
                }
            }
        else if (
            sFunction.equals("bye"))
            {
            getCluster().shutdown();
            setStop(true);
            }
        else if (
            sFunction.equals("help"))
            {
            _trace("The commands are:");
            _trace("  backup <path>");
            _trace("  bulkput <# of iterations> <block size> <start key> [all]");
            _trace("  bulkremove <# of iterations> <start key> [all]");
            _trace("  bye");
            _trace("  cachefactory [<path>]");
            _trace("  cache <name>");
            _trace("  clear");
            _trace("  destroy");
            _trace("  get <key>");
            _trace("  hash");
            _trace("  help");
            _trace("  filter <name> <type> [(<accessor> <value>) | [paramValue]+]");
            _trace("  inc <key> [<increment>]");
            _trace("  invoke <command> [('all' | 'other' | 'senior' | <id>) [('async' | 'sync')]]");
            _trace("  index <accessor> [add | remove]");
            _trace("  kill");
            _trace("  list [<map name> | <filter name> [<accessor> [asc | desc]]]");
            _trace("  listen [('start' | 'stop') [('cluster' | 'local' | 'members')]]");
            _trace("  lock <key>");
            _trace("  log (<size> | <message>) [<iterations> [<level>]]");
            _trace("  map [[('Optimistic' | 'Replicated' | 'Distributed') [! <service-name>] ':'] <name>");
            _trace("  maps");
            _trace("  memory");
            _trace("  profile <command>");
            _trace("  put <key> <value>");
            _trace("  release");
            _trace("  remove <key>");
            _trace("  restore <path>");
            _trace("  runAs <name> <password> <command>");
            _trace("  service");
            _trace("  services");
            _trace("  size [<filter name>]");
            _trace("  stats [reset]");
            _trace("  unlock <key>");
            _trace("  waitkey <start key> <stop key>");
            _trace("  who | cluster");
            _trace("  whoami | service");
            _trace("  #<repeat count> <command>");
            _trace("  &<functionName> [paramValue]*");
            }
        else if (
            sFunction.equals("backup"))
            {
            doBackup(asParam, fSilent);
            }
        else if (
            sFunction.equals("bulkput"))
            {
            doBulkPut(asParam, fSilent);
            }
        else if (
            sFunction.equals("bulkremove"))
            {
            doBulkRemove(asParam, fSilent);
            }
        else if (
            sFunction.equals("cachefactory"))
            {
            doCacheFactory(asParam, fSilent);
            }
        else if (
            sFunction.equals("cache"))
            {
            if (cParams > 0)
                {
                doCache(asParam, fSilent);
                }
            else
                {
                _trace(String.valueOf(map));
                }
            }
        else if (
            sFunction.equals("clear"))
            {
            if (isMapValid())
                {
                map.clear();
                }
            }
        else if (
            sFunction.equals("cluster") || sFunction.equals("who"))
            {
            _trace(String.valueOf(getCluster()));
            }
        else if (
            sFunction.equals("destroy"))
            {
            if (isMapValid())
                {
                map.destroy();
                }
            }
        else if (
            sFunction.equals("filter"))
            {
            if (isMapValid())
                {
                doFilter(aoParam);
                }
            }
        else if (
            sFunction.equals("get"))
            {
            if (isMapValid() && cParams >= 1)
                {
                oResult = map.get(aoParam[0]);
                ((ThreadLocal) get_Sink()).set(oResult);
        
                if (!fSilent)
                    {
                    _trace(toString(oResult));
                    }
                }
            }
        else if (
            sFunction.equals("hash"))
            {
            if (!isMapValid())
                {
                return null;
                }
            int iHash = 0;
            for (Iterator iter = map.keySet().iterator(); iter.hasNext();)
                {
                Object oKey = iter.next();
                Object oVal = map.get(oKey);
                
                if (oVal instanceof byte[])
                    {
                    byte[] ab = (byte[]) oVal;
                    for (int i = 0, c = ab.length; i < c; i++)
                        {
                        iHash += ab[i];
                        }
                    }
                else if (oVal != null)
                    {
                    iHash += oVal.hashCode();
                    }
                }
            _trace("hash=" + iHash);
            }
        else if (
            sFunction.equals("inc")) // key [inc ["optimistic"]]
            {
            if (!isMapValid())
                {
                return null;
                }
            Object  oKey  = aoParam[0];
            int     cInc  = 1;
            boolean fLock;
            try
                {
                cInc = Integer.parseInt(asParam[1]);
                }
            catch (Exception e) {}
            fLock = cParams <= 2 || !asParam[2].startsWith("o");
        
            if (fLock)
                {
                map.lock(oKey, -1);
                }
            Object oVal = map.get(oKey);
            int    nVal = 0;
            try
                {
                nVal = Integer.parseInt(String.valueOf(oVal));
                }
            catch (Exception e) {}
        
            Object oValue = new Integer(nVal + cInc);
            map.put(oKey, oValue);
            if (!fSilent)
                {
                _trace("incremented " + oKey + " from " + oVal + " to " + oValue);
                }
            if (fLock)
                {
                map.unlock(oKey);
                }
            ((ThreadLocal) get_Sink()).set(oValue);
            }
        else if (
            sFunction.equals("index")) // <accessor> [add | remove]");
            {
            if (!isMapValid())
                {
                return null;
                }
            String    sMethod   = asParam[0];
            boolean   fRemove   = cParams > 1 && asParam[1].equals("remove");
            Extractor extractor = sMethod.indexOf('.') < 0 ? (Extractor) 
                new ReflectionExtractor(sMethod) : new ChainedExtractor(sMethod);
        
            if (fRemove)
                {
                map.removeIndex(extractor);
                }
            else
                {
                map.addIndex(extractor, true, new SafeComparator(null));
                }
            }
        else if (
            sFunction.startsWith("invoke")) // invoke[:<service name>] <command>
                                            //     ["all" | "other" | "senior" | <id>]
                                            //     [("async" | "sync")]
            {
            int    ofName = sFunction.indexOf(':');
            String sName  = ofName < 0 ? "Invocation" : sFunction.substring(ofName + 1);
        
            doInvoke(sName, asParam, fSilent);
            }
        else if (
            sFunction.equals("jmx")) // [port] ["start" | "stop"]
            {
            doJmx(asParam);
            }
        else if (
            sFunction.equals("kill"))
            {
            if (cParams > 0 && asParam[0].equals("all"))
                {
                getCluster().shutdown();
                setCluster(null);
                }
            else
                {
                if (service == null)
                    {
                    getCluster().shutdown();
                    }
                else
                    {
                    service.shutdown();
                    }
                }
            setService(null);
            setMap(null);
            setPrompt("?");
            }
        else if (
            sFunction.equals("list")) // <filter-name> [[[<method>[,<method>]*] desc] page]
            {
            if (isMapValid())
                {
                doList(asParam, fSilent);
                }
            }
        else if (
            sFunction.equals("listen")) // [start | stop] [cluster | members | master | local]
                                        // [filter | key] [lite]
            {
            boolean fStop   = cParams >= 1 && asParam[0].equals("stop");
            String  sSource = cParams >= 2 ? asParam[1] : "cluster";
            Object  oKey    = null; 
            Filter  filter  = null;
            boolean fLite   = false;
            if (cParams >= 3)
                {
                filter = (Filter) getFilters().get(asParam[2]);
                if (filter == null)
                    {
                    oKey = aoParam[2];
                    }
                }
            if (cParams >= 4)
                {
                fLite = asParam[3].equals("lite");
                }
            doListen(sSource, fStop, filter, oKey, fLite);
            }
        else if (
            sFunction.equals("log"))
            {
            doLog(aoParam, fSilent);
            }
        else if (
            sFunction.equals("map"))
            {
            if (cParams > 0)
                {
                doMap(asParam, fSilent);
                }
            else
                {
                _trace(String.valueOf(map));
                }
            }
        else if (
            sFunction.equals("maps"))
            {
            for (Enumeration enumS = ensureCluster().getServiceNames(); enumS.hasMoreElements();)
                {
                String  sName = (String) enumS.nextElement();
                Service srv   = getCluster().getService(sName);
                if (srv instanceof CacheService && srv.isRunning())
                    {
                    CacheService rc = (CacheService) srv;
                    for (Enumeration enumC = rc.getCacheNames(); enumC.hasMoreElements();)
                        {
                        _trace(srv.getInfo().getServiceName() + ":" + enumC.nextElement());
                        }
                    }
                }
            }
        else if (
            sFunction.equals("memory"))
            {
            Runtime rt = Runtime.getRuntime();
            rt.gc();
        
            long lTotal = rt.totalMemory();
            long lFree  = rt.freeMemory();
            _trace("total=" + lTotal/1000 + "K (" + lTotal + ")");
            _trace("free =" + lFree/1000  + "K (" + lFree + ")");
            try
                {
                Long LMax = (Long) ClassHelper.invoke(rt, "maxMemory", ClassHelper.VOID);
                _trace("max  =" + LMax.longValue()/1000  + "K (" + LMax + ")");
                }
            catch (Throwable e) {}
            oResult = new Long(lFree);
            }
        else if (
            sFunction.equals("new")) // new <class> [<params>]*
            {
            if (cParams > 0)
                {
               try
                    {
                    Class clz = Class.forName(asParam[0]);
        
                    if (cParams > 1)
                        {
                        Object[] ao = new Object[cParams - 1];
                        System.arraycopy(aoParam, 1, ao, 0, cParams - 1);
                        oResult = ClassHelper.newInstance(clz, ao);
                        }
                    else
                        {
                        oResult = clz.newInstance();
                        }
                    }
                catch (Exception e)
                    {
                    _trace(e);
                    }
                }
            if (!fSilent)
                {
                _trace(toString(oResult));
                }
            ((ThreadLocal) get_Sink()).set(oResult);
            }
        else if (
            sFunction.equals("profile"))
            {
            long lBegin = System.currentTimeMillis();
            processCommand(sCmd);
            long lElapsed = System.currentTimeMillis() - lBegin;
            _trace("Elapsed " + lElapsed + "ms");
            }
        else if (
            sFunction.equals("put"))
            {
            if (isMapValid() && cParams >= 2)
                {
                oResult = map.put(aoParam[0], aoParam[1]);
                if (!fSilent)
                    {
                    _trace(toString(oResult));
                    }
                }
            }
        else if (
            sFunction.equals("release"))
            {
            if (isMapValid())
                {
                map.release();
                }
            }
        else if (
            sFunction.equals("remove"))
            {
            if (isMapValid() && cParams >= 1)
                {
                oResult = map.remove(aoParam[0]);
                ((ThreadLocal) get_Sink()).set(oResult);
                if (!fSilent)
                    {
                    _trace(toString(oResult));
                    }
                }
            }
        else if (
            sFunction.equals("restore"))
            {
            doRestore(asParam, fSilent);
            }
        else if (
            sFunction.equalsIgnoreCase("runAs"))
            {
            oResult = doSecure(asParam, fSilent);
            }
        else if (
            sFunction.equals("scan"))
            {
            if (isMapValid())
                {
                doScan(asParam);
                }
            }
        else if (
            sFunction.equals("service") || sFunction.equals("whoami"))
            {
            if (service == null)
                {
                processCommand("who");
                }
            else
                {
                _trace(String.valueOf(service));
                _trace(String.valueOf(service.getInfo().getServiceMembers()));
                }
            }
        else if (
            sFunction.equals("services"))
            {
            for (Enumeration enum = ensureCluster().getServiceNames(); enum.hasMoreElements();)
                {
                String      sName = (String) enum.nextElement();
                ServiceInfo info  = getCluster().getServiceInfo(sName);
                if (info != null)
                    {
                    _trace(info.toString());
                    }
                }
            }
        else if (
            sFunction.equals("sleep"))
            {
            long lMillis = 1L;
            try
                {
                lMillis = Long.parseLong(asParam[0]);
                }
            catch (NumberFormatException e) {}
        
            Object oKey = null;
            if (cParams > 1)
                {
                if (!isMapValid())
                    {
                    return null;
                    }
                oKey = aoParam[1];
                }
        
            try
                {
                long lStart = System.currentTimeMillis();
                if (oKey != null)
                    {
                    map.lock(oKey, -1L);
                    }
                Thread.sleep(lMillis);
        
                if (!fSilent)
                    {
                    _trace("Elapsed " + (System.currentTimeMillis() - lStart) + "ms");
                    }
                }
            catch (InterruptedException e)
                {
                _trace("Sleep was interrupted; setting the interrupt flag...");
                Thread.currentThread().interrupt();
                }
            finally
                {
                if (oKey != null)
                    {
                    map.unlock(oKey);
                    }
                }
            }
        else if (sFunction.equals("size")) // [[<filter-name>] page]
            {
            if (!isMapValid())
                {
                return null;
                }
            Set setEntry;
            if (cParams > 0)
                {
                String sName = asParam[0];
                if (getFilters().containsKey(sName))
                    {
                    int nPage = -1;
                    if (cParams > 1)
                        {
                        nPage = Integer.parseInt(asParam[1]);
                        }
                    setEntry = applyFilter(sName, true, null, nPage);
                    }
                else
                    {
                    map = getService().ensureCache(sName, null);
                    setEntry = map.entrySet();
                    }
                }
            else
                {
                setEntry = map.entrySet();
                }
            int cSize = setEntry.size();
            if (!fSilent)
                {
                _trace(String.valueOf(cSize));
                }
            oResult = new Integer(cSize);
            }
        else if (
            sFunction.equals("stats")) // [cluster | service] [reset]
            {
            boolean fCluster = true;
            boolean fReset   = false;
            int     iNext    = 0;
            if (cParams > iNext && asParam[iNext].equals("service"))
                {
                fCluster = false;
                iNext++;
                }
            if (cParams > iNext && asParam[iNext].equals("reset"))
                {
                fReset = true;
                }
        
            String sSilent = fSilent ? "@" : "";
            if (fCluster)
                {
                String sTarget = getMap() == null ? "&" : "&getCacheService.getService.";
                if (fReset)
                    {
                    processCommand('@' + sTarget + "getCluster.resetStats");
                    }
                oResult = processCommand(sSilent + sTarget + "getCluster.formatStats");
                }
            else if (isMapValid())
                {
                if (fReset)
                    {
                    processCommand("@&getCacheService.getService.resetStats");
                    }
                oResult = processCommand(sSilent + "&getCacheService.getService.formatStats");
                }
            }
        else if (
            sFunction.equals("sum"))
            {
            if (!isMapValid())
                {
                return null;
                }
            long cSum  = 0;
            int  cNums = 0;
            int  cNots = 0;
            for (Iterator iter = map.values().iterator(); iter.hasNext();)
                {
                Object oVal = iter.next();
                if (oVal instanceof Number)
                    {
                    ++cNums;
                    cSum += ((Number) oVal).longValue();
                    }
                else
                    {
                    ++cNots;
                    }
                }
            if (!fSilent)
                {
                _trace("sum=" + cSum + " (" + cNums + " values were numbers, "
                        + cNots + " were not)");
                }
            oResult = new Long(cSum);
            }
        else if (
            sFunction.equals("waitkey"))
            {
            if (!isMapValid())
                {
                return null;
                }
            Object oKeyStart = aoParam[0];
            Object oKeyStop  = aoParam[1];
        
            _trace("waiting for key: " + oKeyStart);
            while (!map.containsKey(oKeyStart))
                {
                Thread.currentThread().sleep(10);
                }
        
            _trace("waiting for key: " + oKeyStop);
            long lBegin = System.currentTimeMillis();
            while (!map.containsKey(oKeyStop))
                {
                Thread.currentThread().sleep(10);
                }
            long lElapsed = System.currentTimeMillis() - lBegin;
            _trace(new Date() + ": done (" + lElapsed + "ms)");
            }
        else if (
            sFunction.equals("worker")) // [<number> | <command>]
            {
            String  sName  = null;
            $Worker worker = null;
        
            try
                {
                sName = "Worker!" + Integer.parseInt(asParam[0]);
                worker = ($Worker) _findChild(sName);
                if (worker == null)
                    {
                    _trace(sName + " has been terminated.");
                    return null;
                    }
                else if (!fSilent)
                    {
                    _trace(worker.toString());
                    }
                }
            catch (RuntimeException e) {}
        
            if (worker == null)
                {
                for (int i = 0; i < 1000; i++)
                    {
                    sName  = "Worker!" + i;
                    worker = ($Worker) _findChild(sName);
                    if (worker == null)
                        {
                        if (cParams > 0)
                            {
                            break;
                            }
                        }
                    else if (cParams == 0)
                        {
                        _trace(worker.toString());
                        }
                    }
                if (cParams > 0)
                    {
                    worker = new $Worker();
                    _addChild(worker, sName);
                    worker.setThreadName(sName);
                    worker.getQueue().add(sCmd);
                    worker.start();
                    }
                }
            ((ThreadLocal) get_Sink()).set(
                worker == null ? (Object) $Worker.getWorkerGroup() : worker);
            }
        else if (
            sFunction.equals("begin")  ||
            sFunction.equals("commit") ||
            sFunction.equals("rollback"))
            {
            if (isMapValid())
                {
                doTransaction(sFunction, asParam);
                }
            }
        else
            {
            _trace("Unknown command: \"" + sFunction + '"' +
                "\nPrint \"help\" for command list");
            }
        
        return oResult;
        }
    
    public static Object processFunction(Object target, String sFunction, boolean fSilent, Object[] aoParam)
        {
        // import com.tangosol.util.ClassHelper;
        // import com.tangosol.util.ConcurrentMap;
        // import java.lang.reflect.Array;
        // import java.lang.reflect.InvocationTargetException;
        // import java.util.Iterator;
        // import java.util.Enumeration;
        
        boolean fLast = false;
        try
            {
            do
                {
                String sMethod = sFunction;
                int ofNext = sFunction.indexOf('.');
                if (ofNext == -1)
                    {
                    ofNext = sFunction.length();
                    fLast  = true;
                    }
                else
                    {
                    sMethod   = sFunction.substring(0, ofNext);
                    sFunction = sFunction.substring(ofNext + 1);
                    }
        
                int nIx  = -1;
                int ofIx = sMethod.indexOf('[');
                if (ofIx != -1)
                    {
                    nIx = Integer.parseInt(
                        sMethod.substring(ofIx + 1, sMethod.indexOf(']')));
                    sMethod = sMethod.substring(0, ofIx);
                    }
        
                if (sMethod.endsWith("lock"))
                    {
                    if (aoParam.length > 0 && "*".equals(aoParam[0]))
                        {
                        aoParam[0] = ConcurrentMap.LOCK_ALL;
                        }
                    }
        
                boolean fTryStatic   = target instanceof Class;
                boolean fTryInstance = !fTryStatic;
                if (fTryStatic)
                    {
                    try
                        {
                        // _trace("1) Calling " + ((Class) target).getName() + "#" + sMethod +
                        //    "(" + (fLast ? toString(aoParam) : "") + ")");
                        target = ClassHelper.invokeStatic((Class) target, sMethod,
                            fLast ? aoParam : ClassHelper.VOID);
                        }
                    catch (Throwable e)
                        {
                        fTryInstance = true;
                        }
                    }
                
                if (fTryInstance)
                    {
                    // _trace("2) Calling " + target.getClass().getName() + "#" + sMethod +
                    //    "(" + (fLast ? toString(aoParam) : "") + ")");
                    try
                        {
                        target = ClassHelper.invoke(target, sMethod,
                            fLast ? aoParam : ClassHelper.VOID);
                        }
                    catch (IllegalAccessException eAccess)
                        {
                    tryInterface:
                        for (Class clzTarget = target.getClass(); eAccess != null;
                                   clzTarget = clzTarget.getSuperclass())
                            {
                            if (clzTarget == null)
                                {
                                throw eAccess;
                                }
        
                            Class[] aIface = clzTarget.getInterfaces();
                            for (int i = 0, c = aIface.length; i < c; i++)
                                {
                                // _trace("3) Calling " + aIface[i].getName() + "#" + sMethod +
                                //    "(" + (fLast ? toString(aoParam) : "") + ")");
                                try
                                    {
                                    target = ClassHelper.invoke(aIface[i], target, sMethod,
                                        fLast ? aoParam : ClassHelper.VOID);
                                    break tryInterface;
                                    }
                                catch (IllegalAccessException e) {}
                                }
                            }
                        }
                    }
        
                if (nIx >= 0)
                    {
                    target = Array.get(target, nIx);
                    }
        
                if (fLast)
                    {
                    if (!fSilent)
                        {
                        _trace(toString(target));
                        }
                    }
                else if (target == null)
                    {
                    if (!fSilent)
                        {
                        _trace("Exception: " + sMethod + " returned null");
                        }
                    break;
                    }
                }
            while (!fLast);
            }
        catch (InvocationTargetException e)
            {
            Throwable t = ((InvocationTargetException) e).getTargetException();
            _trace(t);
            target = t;
            }
        catch (NullPointerException e)
            {
            _trace(e);
            target = e;
            }
        catch (Throwable e)
            {
            _trace(e.toString(), 1);
            target = e;
            }
        return target;
        }
    
    // Declared at the super level
    public void run()
        {
        // import java.io.InputStreamReader;
        // import java.io.Reader;
        
        super.run();
        
        String   sCmd  = "";
        String[] asArg = getArgument();
        if (asArg.length > 0)
            {
            if (asArg[0].startsWith("@"))
                {
                sCmd = asArg[0].substring(1);
                }
            else
                {
                sCmd = "map " + asArg[0];
                }
            for (int i = 1, c = asArg.length; i < c; i++)
                {
                sCmd += ' ' + asArg[i];
                }
            }
        else
            {
            _trace(ensureCluster().toString());
            }
        setPrompt("?");
        
        Reader  reader = new InputStreamReader(System.in);
        $Logger logger = ensureLogger();
        while (true)
            {
            if (sCmd.length() > 0)
                {
                try
                    {
                    // let the OutputDeamon a chance to proceed
                    processCommand(sCmd);
                    }
                catch (Throwable e)
                    {
                    _trace(e);
                    }
                }
        
            if (isStop())
                {
                return;
                }
        
            try
                {
                Thread.currentThread().sleep(50);
                logger.setCommandPrompt(true);
        
                char[] ach = new char[256];
                int    cch = reader.read(ach);
        
                logger.setCommandPrompt(false);
                logger.setPendingLineFeed(false);
        
                sCmd = cch <= 2 ? "" : new String(ach).trim();
                }
            catch (Exception e)
                {
                reader = new InputStreamReader(System.in);
                sCmd = "";
                }
            }
        }
    
    // Accessor for the property "Cluster"
    /**
    * Setter for property Cluster.<p>
    * The Cluster instance.
    */
    public static void setCluster(com.tangosol.net.Cluster cluster)
        {
        if (cluster == null)
            {
            // this is a shutdown call
            ((Coherence) get_Instance()).getLogger().shutdown();
            }
        
        __s_Cluster = (cluster);
        }
    
    // Accessor for the property "CoherenceDtd"
    /**
    * Setter for property CoherenceDtd.<p>
    * The public version of coherence.dtd.
    * 
    * @see #DtdParser
    */
    public static void setCoherenceDtd(String xml)
        {
        __s_CoherenceDtd = xml;
        }
    
    // Accessor for the property "CoherenceUrl"
    /**
    * Setter for property CoherenceUrl.<p>
    * The URL to the version specific coherence.dtd file.
    * 
    * @see #loadConfiguration
    */
    protected static void setCoherenceUrl(String sUrl)
        {
        __s_CoherenceUrl = sUrl;
        }
    
    // Accessor for the property "Filters"
    /**
    * Setter for property Filters.<p>
    * Filters keyed by their names. Used in filter and list commands.
    */
    protected void setFilters(java.util.Map map)
        {
        __m_Filters = map;
        }
    
    // Accessor for the property "Map"
    /**
    * Setter for property Map.<p>
    * Map assosiated with currently tested service
    */
    protected void setMap(com.tangosol.net.NamedCache map)
        {
        __m_Map = map;
        }
    
    // Accessor for the property "Prompt"
    /**
    * Setter for property Prompt.<p>
    * Commad prompt assosiated with currently tested service and map
    */
    protected void setPrompt(String sPrompt)
        {
        __m_Prompt = sPrompt;
        }
    
    // Accessor for the property "Service"
    /**
    * Setter for property Service.<p>
    * Service that is currently being tested
    */
    protected void setService(com.tangosol.net.CacheService service)
        {
        __m_Service = service;
        }
    
    // Accessor for the property "ServiceConfigMap"
    /**
    * Setter for property ServiceConfigMap.<p>
    * Map containing the service configuration element per service type
    * (including pseudo-types like $Logger, etc.).
    * 
    * @see #loadConfiguration
    */
    protected static void setServiceConfigMap(java.util.Map map)
        {
        __s_ServiceConfigMap = map;
        }
    
    // Accessor for the property "Stop"
    /**
    * Setter for property Stop.<p>
    * Specifies wether to stop the command tool.
    */
    protected void setStop(boolean fStop)
        {
        __m_Stop = fStop;
        }
    
    public static String toString(Object oResult)
        {
        // import com.tangosol.util.Base;
        // import java.lang.reflect.Array;
        // import java.util.Iterator;
        // import java.util.Enumeration;
        
        final int    MAX_TRACE = 50;
        final String BEGIN     = " {\n ";
        final String NEXT      = "\n ";
        final String END       = "\n }";
        
        Class clzArrayType = oResult == null ? null : oResult.getClass().getComponentType();
        if (clzArrayType == null)
            {
            if (oResult instanceof Iterator)
                {
                StringBuffer sb = new StringBuffer();
                sb.append(oResult.getClass().getName());
        
                Iterator iter = (Iterator) oResult;
                if (iter.hasNext())
                    {
                    sb.append(BEGIN);
        
                    for (int i = 0; iter.hasNext() && i < MAX_TRACE; i++)
                        {
                        sb.append(toString(iter.next()));
                        if (iter.hasNext())
                            {
                            sb.append(NEXT);
                            }
                        }
                    if (iter.hasNext())
                        {
                        sb.append("...");
                        }
                    sb.append(END);
                    }
                return sb.toString();
                }
            else if (oResult instanceof Enumeration)
                {
                StringBuffer sb = new StringBuffer();
                sb.append(oResult.getClass().getName())
                  .append(BEGIN);
                Enumeration enum = (Enumeration) oResult;
                for (int i = 0 ; enum.hasMoreElements() && i < MAX_TRACE; i++)
                    {
                    sb.append(toString(enum.nextElement()));
                    if (enum.hasMoreElements())
                        {
                        sb.append(NEXT);
                        }
                    }
                if (enum.hasMoreElements())
                    {
                    sb.append("...");
                    }
                sb.append(END);
                return sb.toString();
                }
            else if (oResult instanceof Class)
                {
                return Base.toString((Class) oResult);
                }
            else
                {
                return String.valueOf(oResult);
                }
            }
        else
            {
            int c = Array.getLength(oResult);
            StringBuffer sb = new StringBuffer();
        
            sb.append(clzArrayType.getName())
              .append('[')
              .append(c)
              .append(']');
        
            if (c > 0)
                {
                sb.append(BEGIN);
        
                int cTrace = Math.min(c, MAX_TRACE);
                for (int i = 0; i < cTrace; i++)
                    {
                    if (i > 0)
                        {
                        sb.append(NEXT);
                        }
                    sb.append(toString(Array.get(oResult, i)));
                    }
            
                if (c > cTrace)
                    {
                    sb.append(", ...");
                    }
                sb.append(END);
                }
            return sb.toString();
            }

        }
    
    protected void txEnd()
        {
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.util.TransactionMap;
        
        NamedCache map = getMap();
        if (map instanceof TransactionMap)
            {
            NamedCache cache = (NamedCache) ((TransactionMap) map).getBaseMap();
            setMap(cache);
            setPrompt(getPrompt().substring(3));
            }
        }
    
    protected void txStart(int nConcur, int nIsolation, int nTimeout)
        {
        // import com.tangosol.net.CacheFactory;
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.util.TransactionMap;
        
        NamedCache     map = getMap();
        TransactionMap mapTx;
        if (map instanceof TransactionMap)
            {
            mapTx = (TransactionMap) map;
            }
        else
            {
            // allow for debugging without packaging
            if (getClass().getName().startsWith("_package"))
                {
                mapTx = getLocalTransaction(map);
                }
            else
                {
                mapTx = CacheFactory.getLocalTransaction(map);
                }
        
            mapTx.setConcurrency(nConcur);
            mapTx.setTransactionIsolation(nIsolation);
            mapTx.setTransactionTimeout(nTimeout);
        
            setMap((NamedCache) mapTx);
            setPrompt("Tx-" + getPrompt());
            }
        
        mapTx.begin();
        }
    }
