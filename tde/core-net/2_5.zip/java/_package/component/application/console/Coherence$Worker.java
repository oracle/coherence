/* Class
*     _package.component.application.console.Coherence$Worker
*/

package _package.component.application.console;

import com.tangosol.net.NamedCache;
import com.tangosol.net.Service;
import com.tangosol.util.WrapperException;
import java.util.Date;
import java.util.Map;

public class Coherence$Worker
        extends    _package.component.util.daemon.QueueProcessor
        implements com.tangosol.net.InvocationObserver,
                   com.tangosol.net.MemberListener,
                   com.tangosol.util.MapListener
    {
    // Fields declarations
    
    /**
    * Property WorkerGroup
    *
    */
    private static transient ThreadGroup __s_WorkerGroup;
    
    // Default constructor
    public Coherence$Worker()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Coherence$Worker(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        _addChild(new Coherence$Worker$Queue("Queue", this, true), "Queue");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Coherence$Worker();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/application/console/Coherence$Worker".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // From interface: com.tangosol.util.MapListener
    public void entryDeleted(com.tangosol.util.MapEvent e)
        {
        process(e);
        }
    
    // From interface: com.tangosol.util.MapListener
    public void entryInserted(com.tangosol.util.MapEvent e)
        {
        process(e);
        }
    
    // From interface: com.tangosol.util.MapListener
    public void entryUpdated(com.tangosol.util.MapEvent e)
        {
        process(e);
        }
    
    // Accessor for the property "WorkerGroup"
    /**
    * Getter for property WorkerGroup.<p>
    */
    public static synchronized ThreadGroup getWorkerGroup()
        {
        ThreadGroup group = __s_WorkerGroup;
        if (group == null || group.isDestroyed())
            {
            group = new ThreadGroup("Worker");
            setWorkerGroup(group);
            }
        return group;
        }
    
    // From interface: com.tangosol.net.InvocationObserver
    public void invocationCompleted()
        {
        _trace("Received \"invocationCompleted\" notification", 3);

        }
    
    // From interface: com.tangosol.net.InvocationObserver
    public void memberCompleted(com.tangosol.net.Member member, Object oResult)
        {
        _trace("Received \"memberCompleted\" notification for " + member +
               "\nresult=" + oResult, 3);
        }
    
    // From interface: com.tangosol.net.InvocationObserver
    public void memberFailed(com.tangosol.net.Member member, Throwable eFailure)
        {
        _trace("Received \"memberFailed\" notification for " + member +
               "\nexception=" + eFailure, 3);
        }
    
    // From interface: com.tangosol.net.MemberListener
    public void memberJoined(com.tangosol.net.MemberEvent e)
        {
        process(e);
        }
    
    // From interface: com.tangosol.net.MemberListener
    public void memberLeaving(com.tangosol.net.MemberEvent e)
        {
        process(e);
        }
    
    // From interface: com.tangosol.net.InvocationObserver
    public void memberLeft(com.tangosol.net.Member member)
        {
        _trace("Received \"memberLeft\" notification for " + member, 3);
        }
    
    // From interface: com.tangosol.net.MemberListener
    public void memberLeft(com.tangosol.net.MemberEvent e)
        {
        process(e);
        }
    
    // Declared at the super level
    /**
    * Event notification called right before the daemon thread terminates. This
    * method is guaranteed to be called only once and on the daemon's thread.
    */
    protected void onExit()
        {
        super.onExit();
        
        get_Parent()._removeChild(this);
        }
    
    // Declared at the super level
    /**
    * Event notification to perform a regular daemon activity. To get it
    * called, another thread has to set Notification to true:
    * <code>daemon.setNotification(true);</code>
    * 
    * @see #onWait
    */
    protected void onNotify()
        {
        super.onNotify();
        
        String sCmd = (String) getQueue().remove();
        try
            {
            $Module app = ($Module) get_Module();
            app.processCommand(sCmd);
            if (app.isStop())
                {
                System.exit(0);
                }
            }
        catch (InterruptedException e)
            {
            _trace("Thread " + getThreadName() + " has been interrupted", 3);
            }
        finally
            {
            setExiting(true);
            }
        }
    
    protected void process(com.tangosol.net.MemberEvent evtMember)
        {
        // import com.tangosol.net.Service;
        
        Service service = (Service) evtMember.getSource();
        
        _trace("Received event for " + service + '\n' + evtMember, 3);
        }
    
    protected void process(com.tangosol.util.MapEvent evtMap)
        {
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.util.WrapperException;
        // import java.util.Map;
        
        Map    map   = (Map) evtMap.getSource();
        String sName = "Map=" + map.getClass().getName();
        if (map instanceof NamedCache)
            {
            sName = "Cache=" + ((NamedCache) map).getCacheName();
            }
        
        _trace("Received event for " + sName + '\n' + evtMap, 3);
        
        Object oKey = evtMap.getKey();
        if ("exception".equals(oKey))
            {
            throw new RuntimeException("Test exception");
            }
        
        if ("stack".equals(oKey))
            {
            _trace(get_StackTrace(), 3);
            }
        
        if ("command".equals(oKey))
            {
            Object oValue = evtMap.getNewValue();
            if (oValue instanceof String)
                {
                try
                    {
                    String sCommand = (String) oValue;
                    (($Module) get_Module()).processCommand(sCommand.replace(',', ';'));
                    }
                catch (InterruptedException e)
                    {
                    Thread.currentThread().interrupt();
                    throw new WrapperException(e);
                    }
                }
            }
        }
    
    // Accessor for the property "WorkerGroup"
    /**
    * Setter for property WorkerGroup.<p>
    */
    public static void setWorkerGroup(ThreadGroup group)
        {
        __s_WorkerGroup = group;
        }
    
    // Declared at the super level
    /**
    * Starts the daemon thread associated with this component. If the thread is
    * already starting or has started, invoking this method has no effect.
    * 
    * Synchronization is used here to verify that the start of the thread
    * occurs; the lock is obtained before the thread is started, and the daemon
    * thread notifies back that it has started from the run() method.
    */
    public synchronized void start()
        {
        setThreadGroup(getWorkerGroup());
        
        super.start();
        }
    
    // Declared at the super level
    public String toString()
        {
        // import java.util.Date;
        
        return get_Name() + (isStarted() ?
            " started at " + new Date(getStartTimestamp()) : " not running");
        }
    }
