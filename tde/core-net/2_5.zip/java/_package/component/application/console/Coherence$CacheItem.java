/* Class
*     _package.component.application.console.Coherence$CacheItem
*/

package _package.component.application.console;

import com.tangosol.util.Base;
import java.io.Serializable;

public class Coherence$CacheItem
        extends    _package.component.Data
        implements com.tangosol.net.Invocable,
                   com.tangosol.util.Versionable
    {
    // Fields declarations
    
    /**
    * Property Index
    *
    */
    private int __m_Index;
    
    /**
    * Property InvokeCommand
    *
    * Used only for Invocation requests.
    */
    private String __m_InvokeCommand;
    
    /**
    * Property Local
    *
    * Transient value!
    */
    private transient boolean __m_Local;
    
    /**
    * Property Origin
    *
    */
    private int __m_Origin;
    
    /**
    * Property Result
    *
    * Invocation result
    */
    private transient Object __m_Result;
    
    /**
    * Property Service
    *
    * Invocation service
    */
    private transient com.tangosol.net.InvocationService __m_Service;
    
    /**
    * Property VersionIndicator
    *
    */
    private Comparable __m_VersionIndicator;
    
    // Default constructor
    public Coherence$CacheItem()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Coherence$CacheItem(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setLocal(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Coherence$CacheItem();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/application/console/Coherence$CacheItem".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    /**
    * Compares this object with the specified object for order.  Returns a
    * negative integer, zero, or a positive integer as this object is less
    * than, equal to, or greater than the specified object.
    * 
    * @param o  the Object to be compared.
    * @return  a negative integer, zero, or a positive integer as this object
    * is less than, equal to, or greater than the specified object.
    * 
    * @throws ClassCastException if the specified object's type prevents it
    * from being compared to this Object.
    */
    public int compareTo(Object o)
        {
        $CacheItem that = ($CacheItem) o;
        
        return this.getIndex() < that.getIndex() ? -1 :
               this.getIndex() > that.getIndex() ? +1 : 0;
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof $CacheItem)
            {
            $CacheItem that = ($CacheItem) obj;
            return this.getIndex()  == that.getIndex() &&
                   this.getOrigin() == that.getOrigin();
            }
        return false;
        }
    
    // Accessor for the property "Index"
    /**
    * Getter for property Index.<p>
    */
    public int getIndex()
        {
        return __m_Index;
        }
    
    // Accessor for the property "InvokeCommand"
    /**
    * Getter for property InvokeCommand.<p>
    * Used only for Invocation requests.
    */
    public String getInvokeCommand()
        {
        return __m_InvokeCommand;
        }
    
    // Accessor for the property "Origin"
    /**
    * Getter for property Origin.<p>
    */
    public int getOrigin()
        {
        return __m_Origin;
        }
    
    // From interface: com.tangosol.net.Invocable
    // Accessor for the property "Result"
    /**
    * Getter for property Result.<p>
    * Invocation result
    */
    public Object getResult()
        {
        return __m_Result;
        }
    
    // Accessor for the property "Service"
    /**
    * Getter for property Service.<p>
    * Invocation service
    */
    public com.tangosol.net.InvocationService getService()
        {
        return __m_Service;
        }
    
    // From interface: com.tangosol.util.Versionable
    // Accessor for the property "VersionIndicator"
    /**
    * Getter for property VersionIndicator.<p>
    */
    public synchronized Comparable getVersionIndicator()
        {
        Comparable version = __m_VersionIndicator;
        if (version == null)
            {
            version = new Long(0L);
            setVersionIndicator(version);
            }
        return version;
        }
    
    // Declared at the super level
    public int hashCode()
        {
        return getIndex() + getOrigin();
        }
    
    // From interface: com.tangosol.util.Versionable
    public synchronized void incrementVersion()
        {
        setVersionIndicator(
            new Long(((Long) getVersionIndicator()).longValue() + 1L));
        }
    
    // From interface: com.tangosol.net.Invocable
    public void init(com.tangosol.net.InvocationService service)
        {
        setService(service);
        }
    
    // Accessor for the property "Local"
    /**
    * Getter for property Local.<p>
    * Transient value!
    */
    public boolean isLocal()
        {
        return __m_Local;
        }
    
    // From interface: com.tangosol.net.Invocable
    public void run()
        {
        // import com.tangosol.util.Base;
        // import java.io.Serializable;
        
        String sCommand = getInvokeCommand();
        if ("exception".equals(sCommand))
            {
            throw new RuntimeException("Test exception");
            }
        
        sCommand = Base.replace(sCommand, "{target}",
            String.valueOf(getService().getCluster().getLocalMember().getId()));
        
        try
            {
            $Module app     = ($Module) $Module.get_Instance();
            Object  oResult = app.processCommand(sCommand);
            setResult(
                oResult == null || oResult instanceof Serializable ?
                    oResult : oResult.getClass().getName());
            }
        catch (InterruptedException e) {}
        catch (Throwable e)
            {
            setResult(e);
            }
        }
    
    // Accessor for the property "Index"
    /**
    * Setter for property Index.<p>
    */
    public void setIndex(int i)
        {
        __m_Index = i;
        }
    
    // Accessor for the property "InvokeCommand"
    /**
    * Setter for property InvokeCommand.<p>
    * Used only for Invocation requests.
    */
    public void setInvokeCommand(String oKey)
        {
        __m_InvokeCommand = oKey;
        }
    
    // Accessor for the property "Local"
    /**
    * Setter for property Local.<p>
    * Transient value!
    */
    public void setLocal(boolean fLocal)
        {
        __m_Local = fLocal;
        }
    
    // Accessor for the property "Origin"
    /**
    * Setter for property Origin.<p>
    */
    public void setOrigin(int i)
        {
        __m_Origin = i;
        }
    
    // Accessor for the property "Result"
    /**
    * Setter for property Result.<p>
    * Invocation result
    */
    protected void setResult(Object oResult)
        {
        __m_Result = oResult;
        }
    
    // Accessor for the property "Service"
    /**
    * Setter for property Service.<p>
    * Invocation service
    */
    protected void setService(com.tangosol.net.InvocationService service)
        {
        __m_Service = service;
        }
    
    // Accessor for the property "VersionIndicator"
    /**
    * Setter for property VersionIndicator.<p>
    */
    protected void setVersionIndicator(Comparable lVersion)
        {
        __m_VersionIndicator = lVersion;
        }
    
    // Declared at the super level
    public String toString()
        {
        return "CacheItem{Index=" + getIndex() +
               ", Origin="  + getOrigin() +
               ", Local="   + isLocal()   +
               ", Version=" + getVersionIndicator() +
               '}';
        }
    }
