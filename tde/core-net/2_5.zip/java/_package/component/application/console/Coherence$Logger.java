/* Class
*     _package.component.application.console.Coherence$Logger
*/

package _package.component.application.console;

import _package.component.util.FileHelper;
import com.tangosol.util.Base;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.sql.Timestamp;

public class Coherence$Logger
        extends    _package.component.util.daemon.QueueProcessor
    {
    // Fields declarations
    
    /**
    * Property CommandPrompt
    *
    */
    private boolean __m_CommandPrompt;
    
    /**
    * Property DefaultWaitMillis
    *
    */
    
    /**
    * Property LastPromptTime
    *
    */
    private long __m_LastPromptTime;
    
    /**
    * Property Level
    *
    */
    private int __m_Level;
    
    /**
    * Property LEVELTEXT
    *
    */
    public static final String[] LEVELTEXT;
    
    /**
    * Property MaxLength
    *
    */
    private int __m_MaxLength;
    
    /**
    * Property PendingLineFeed
    *
    */
    private boolean __m_PendingLineFeed;
    
    /**
    * Property PendingPrompt
    *
    */
    private boolean __m_PendingPrompt;
    
    /**
    * Property Stream
    *
    */
    private java.io.PrintStream __m_Stream;
    
    /**
    * Property Template
    *
    */
    private String __m_Template;
    
    // Static initializer
    static
        {
        try
            {
            String[] a0 = new String[10];
                {
                a0[0] = "Debug";
                a0[1] = "Error";
                a0[2] = "Warning";
                a0[3] = "Info";
                a0[4] = "D4";
                a0[5] = "D5";
                a0[6] = "D6";
                a0[7] = "D7";
                a0[8] = "D8";
                a0[9] = "D9";
                }
            LEVELTEXT = a0;
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    // Default constructor
    public Coherence$Logger()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Coherence$Logger(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setPriority(3);
            setThreadName("CoherenceLogger");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new Coherence$Logger$Queue("Queue", this, true), "Queue");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant DefaultWaitMillis
    public long getDefaultWaitMillis()
        {
        return 500L;
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Coherence$Logger();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/application/console/Coherence$Logger".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    public void configure(com.tangosol.run.xml.XmlElement xml)
        {
        // import Component.Util.FileHelper;
        // import java.io.File;
        // import java.io.FileOutputStream;
        // import java.io.IOException;
        // import java.io.PrintStream;
        
        $Module app = ($Module) get_Module();
        
        // extract logging options
        int    nLevel   = xml.getSafeElement("severity-level") .getInt   (app.getDefaultLoggingLevel());
        String sFormat  = xml.getSafeElement("message-format") .getString(app.getDefaultLoggingFormat());
        String sStream  = xml.getSafeElement("destination")    .getString(app.getDefaultLoggingStream());
        int    cchLimit = xml.getSafeElement("character-limit").getInt   (app.getDefaultLoggingLimit());
        
        if (sFormat.length() == 0)
            {
            sFormat = app.getDefaultLoggingFormat();
            }
        if (sStream.length() == 0)
            {
            sStream = app.getDefaultLoggingStream();
            }
        if (cchLimit <= 0)
            {
            cchLimit = Integer.MAX_VALUE;
            }
        
        PrintStream stream = null;
        if ("stdout".equalsIgnoreCase(sStream))
            {
            stream = System.out;
            }
        else if ("stderr".equalsIgnoreCase(sStream))
            {
            stream = System.err;
            }
        else
            {
            if (sStream != null)
                {
                try
                    {
                    File file = new File(sStream);
                    if (FileHelper.isFullyAccessible(file))
                        {
                        stream = new PrintStream(new FileOutputStream(file));
                        }
                    else
                        {
                        System.err.println("\n" + $Module.TITLE + ": Log file \"" + file +
                            "\" is locked by another process; using default settings.\n");
                        }
                    }
                catch (Exception e) {}
                }
            if (stream == null)
                {
                stream = "stdout".equalsIgnoreCase(app.getDefaultLoggingStream()) ?
                    System.out : System.err;
                }
            }
        
        setLevel(nLevel);
        setTemplate(sFormat);
        setStream(stream);
        setMaxLength(cchLimit);
        }
    
    protected String formatTimestamp(java.sql.Timestamp ts)
        {
        String s = ts.toString();
        if (s.length() < 23)
            {
            s = (s + "000").substring(0, 23);
            }
        return s;
        }
    
    // Accessor for the property "LastPromptTime"
    /**
    * Getter for property LastPromptTime.<p>
    */
    public long getLastPromptTime()
        {
        return __m_LastPromptTime;
        }
    
    // Accessor for the property "Level"
    /**
    * Getter for property Level.<p>
    */
    public int getLevel()
        {
        return __m_Level;
        }
    
    // Accessor for the property "MaxLength"
    /**
    * Getter for property MaxLength.<p>
    */
    public int getMaxLength()
        {
        return __m_MaxLength;
        }
    
    // Accessor for the property "Stream"
    /**
    * Getter for property Stream.<p>
    */
    public java.io.PrintStream getStream()
        {
        return __m_Stream;
        }
    
    // Accessor for the property "Template"
    /**
    * Getter for property Template.<p>
    */
    public String getTemplate()
        {
        return __m_Template;
        }
    
    // Accessor for the property "CommandPrompt"
    /**
    * Getter for property CommandPrompt.<p>
    */
    public boolean isCommandPrompt()
        {
        return __m_CommandPrompt;
        }
    
    // Accessor for the property "PendingLineFeed"
    /**
    * Getter for property PendingLineFeed.<p>
    */
    public boolean isPendingLineFeed()
        {
        return __m_PendingLineFeed;
        }
    
    // Accessor for the property "PendingPrompt"
    /**
    * Getter for property PendingPrompt.<p>
    */
    public boolean isPendingPrompt()
        {
        return __m_PendingPrompt;
        }
    
    // Declared at the super level
    /**
    * This event occurs when an exception is thrown from onEnter, onWait,
    * onNotify and onExit.
    * 
    * If the exception should terminate the daemon, call stop(). The default
    * implementation prints debugging information and terminates the daemon.
    * 
    * @param e  the Throwable object (a RuntimeException or an Error)
    * 
    * @throws RuntimeException may be thrown; will terminate the daemon
    * @throws Error may be thrown; will terminate the daemon
    */
    protected void onException(Throwable e)
        {
        // log and continue
        System.err.println($Module.TITLE + ".Logger: " + e);
        e.printStackTrace(System.err);
        }
    
    // Declared at the super level
    /**
    * Event notification called right before the daemon thread terminates. This
    * method is guaranteed to be called only once and on the daemon's thread.
    */
    protected void onExit()
        {
        // import java.io.PrintStream;
        
        PrintStream stream = getStream();
        if (stream != System.out && stream != System.err)
            {
            stream.close();
            }
        
        super.onExit();
        }
    
    // Declared at the super level
    /**
    * Event notification to perform a regular daemon activity. To get it
    * called, another thread has to set Notification to true:
    * <code>daemon.setNotification(true);</code>
    * 
    * @see #onWait
    */
    protected void onNotify()
        {
        // import com.tangosol.util.Base;
        // import java.io.PrintStream;
        // import java.sql.Timestamp;
        
        try
            {
            final int    MAX_CHUNK      = 4096;
            final int    MAX_TOTAL      = getMaxLength();
            int          cchTotal       = 0;
            boolean      fTruncate      = false;
            int          cTruncate      = 0;
            int          cTruncateLines = 0;
            int          cchTruncate    = 0;
            String       sTemplate      = getTemplate();
            PrintStream  stream         = getStream();
            StringBuffer sb             = new StringBuffer();
            boolean      fDone          = false;
            do
                {
                Object[] loginfo = (Object[]) getQueue().removeNoWait();
        
                // check for end of queue; if any messages have been discarded,
                // report on the number and size
                if (loginfo == null)
                    {
                    if (fTruncate && cTruncate > 0)
                        {
                        loginfo = new Object[]
                            {
                            new Timestamp(System.currentTimeMillis()),
                            "Asynchronous logging character limit exceeded; "
                                + " discarding " + cTruncate + " log messages "
                                + "(lines=" + cTruncateLines
                                + ", chars=" + cchTruncate + ")",
                            new Integer(2),
                            Thread.currentThread(),
                            new Integer(0),
                            };
                        fDone = true;
                        }
                    else
                        {
                        break;
                        }
                    }
        
                if (loginfo.length == 0)
                    {
                    // zero length log info serves as a shutdown marker
                    setExiting(true);
                    return;
                    }
        
                Timestamp ts      = (Timestamp) loginfo[0];
                String    sMsg    = (String)    loginfo[1];
                int       nLevel  = ((Integer)  loginfo[2]).intValue();
                Thread    thread  = (Thread)    loginfo[3];
                int       nMember = ((Integer)  loginfo[4]).intValue();
        
                if (sMsg == null)
                    {
                    sMsg = "";
                    }
        
                cchTotal += sMsg.length();
                if (fTruncate && !fDone)
                    {
                    cTruncate      += 1;
                    cTruncateLines += Base.parseDelimitedString(sMsg, '\n').length;
                    cchTruncate    += sMsg.length();
                    }
                else
                    {
                    if (cchTotal > MAX_TOTAL)
                        {
                        fTruncate = true;
                        }
        
                    String sText;
                    if (nLevel <= 0)
                        {
                        sText = sMsg;
                        }
                    else
                        {
                        String sLevel = "?";
                        try
                            {
                            sLevel = LEVELTEXT[nLevel];
                            }
                        catch (Exception e) {}
        
                        sText = Base.replace(sTemplate, "{date}", formatTimestamp(ts));
                        sText = Base.replace(sText, "{version}", Coherence.VERSION);
                        sText = Base.replace(sText, "{level}",   sLevel);
                        sText = Base.replace(sText, "{thread}", thread == null ? "n/a" : thread.getName());
                        sText = Base.replace(sText, "{member}", nMember == 0 ? "n/a" : String.valueOf(nMember));
                        sText = Base.replace(sText, "{text}", sMsg);
                        }
        
                    if (isPendingLinefeed())
                        {
                        stream.println();
                        setPendingLinefeed(false);
                        setPendingPrompt(isCommandPrompt());
                        }
        
                    if (sb.length() > MAX_CHUNK)
                        {
                        synchronized (stream)
                            {
                            stream.println(sb.toString());
                            setPendingPrompt(isCommandPrompt());
                            }
                        sb.setLength(0);
                        }
        
                    if (sb.length() > 0)
                        {
                        sb.append('\n');
                        }
        
                    sb.append(sText);
                    }
                }
            while (!fDone);
        
            if (sb.length() > 0)
                {
                synchronized (stream)
                    {
                    stream.println(sb.toString());
                    setPendingPrompt(isCommandPrompt());
                    }
                }
            stream.flush();
            }
        catch (OutOfMemoryError e)
            {
            System.err.println($Module.TITLE + ".Logger: Out of memory while printing");
            }
        
        if (isPendingPrompt())
            {
            long lCurrent = System.currentTimeMillis();
            if (lCurrent > getLastPromptTime() + getWaitMillis())
                {
                PrintStream out = System.out;
                synchronized (out)
                    {
                    out.print("\nMap (" + (($Module) get_Module()).getPrompt() + "): ");
                    out.flush();
                    }
                setPendingPrompt(false);
                setPendingLineFeed(true);
                setLastPromptTime(lCurrent);
                }
            }
        }
    
    // Accessor for the property "CommandPrompt"
    /**
    * Setter for property CommandPrompt.<p>
    */
    public void setCommandPrompt(boolean fPrompt)
        {
        __m_CommandPrompt = (fPrompt);
        setPendingPrompt(fPrompt);
        setLastPromptTime(0L);
        setWaitMillis(fPrompt ? getDefaultWaitMillis() : 0L);
        setNotification(true);
        }
    
    // Accessor for the property "LastPromptTime"
    /**
    * Setter for property LastPromptTime.<p>
    */
    protected void setLastPromptTime(long lDatetime)
        {
        __m_LastPromptTime = lDatetime;
        }
    
    // Accessor for the property "Level"
    /**
    * Setter for property Level.<p>
    */
    public void setLevel(int nLevel)
        {
        __m_Level = nLevel;
        }
    
    // Accessor for the property "MaxLength"
    /**
    * Setter for property MaxLength.<p>
    */
    public void setMaxLength(int cbLimit)
        {
        __m_MaxLength = cbLimit;
        }
    
    // Accessor for the property "PendingLineFeed"
    /**
    * Setter for property PendingLineFeed.<p>
    */
    public void setPendingLineFeed(boolean fPending)
        {
        __m_PendingLineFeed = fPending;
        }
    
    // Accessor for the property "PendingPrompt"
    /**
    * Setter for property PendingPrompt.<p>
    */
    public void setPendingPrompt(boolean fPending)
        {
        __m_PendingPrompt = fPending;
        }
    
    // Accessor for the property "Stream"
    /**
    * Setter for property Stream.<p>
    */
    protected void setStream(java.io.PrintStream stream)
        {
        __m_Stream = stream;
        }
    
    // Accessor for the property "Template"
    /**
    * Setter for property Template.<p>
    */
    public void setTemplate(String sFormat)
        {
        __m_Template = sFormat;
        }
    
    /**
    * Stop the logger after processing all pending messages.
    */
    public void shutdown()
        {
        // zero length log info serves as a shutdown marker
        getQueue().add(new Object[0]);
        }
    }
