/* Class
*     _package.component.Installer
*/

package _package.component;

import _package.component.installer.Ejb;
import _package.component.installer.Enterprise;
import _package.component.installer.Web;
import com.tangosol.dev.assembler.ClassFile;
import com.tangosol.engarde.ApplicationEntry;
import com.tangosol.engarde.ApplicationEntry; // as Entry
import com.tangosol.engarde.ApplicationReader;
import com.tangosol.engarde.ApplicationReader; // as Reader
import com.tangosol.engarde.ApplicationWriter;
import com.tangosol.engarde.DirectoryStorage;
import com.tangosol.engarde.JarStorage;
import com.tangosol.run.xml.SimpleDocument;
import com.tangosol.run.xml.SimpleParser;
import com.tangosol.run.xml.XmlDocument;
import com.tangosol.run.xml.XmlElement;
import com.tangosol.run.xml.XmlHelper;
import com.tangosol.util.Base;
import com.tangosol.util.CacheCollator;
import com.tangosol.util.ErrorList;
import com.tangosol.util.StringTable;
import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.Collator;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Locale;
import java.util.StringTokenizer;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
* Installer components parse the content of an enterprise application
* information producing the XML descriptor conforming to the
* "coherence-web.xsd" and make changes to application resources based on the
* information collected during the inspection phase and (optionally) edited by
* a user.
* 
* Usual event flow consists of the following steps:
* <ol>
* <li>gettting an instance of the Installer, which is done using the static
* factory method getInstaller()
* <li>calling the inspect() method to collect the information about the
* resources that are "modifiable"
* <li>calling the install() method to customize the content of the application
* <li>closing the customizer to release all the used resources
* </ol>
*/
public abstract class Installer
        extends    _package.Component
    {
    // Fields declarations
    
    /**
    * Property ClassRoot
    *
    * The root path for the module classes. The value is
    * "WEB-INF/classes/" for Web modules and empty string for Ejb modules
    */
    
    /**
    * Property DeleteSourceOnClose
    *
    * Specifies whether or not the module source is temporary and should be
    * deleted on close.
    */
    private transient boolean __m_DeleteSourceOnClose;
    
    /**
    * Property DeleteTargetOnClose
    *
    * Specifies whether or not the module target is temporary and should be
    * deleted on close.
    */
    private transient boolean __m_DeleteTargetOnClose;
    
    /**
    * Property ErrorList
    *
    * The ErrorList object to log error information to.
    */
    private transient com.tangosol.util.ErrorList __m_ErrorList;
    
    /**
    * Property InstalledWeb
    *
    * Checks whether the Coherence*web has already been installed into the
    * application represented by this installer.
    */
    
    /**
    * Property JSP_PREFIX_FILE
    *
    * Name of the resource that contains the jsp prefix -- the text that should
    * be prepended to every processed jsp.
    */
    public static final String JSP_PREFIX_FILE = "/web-install/jsp-prefix.jsp";
    
    /**
    * Property JSP_SUFFIX_FILE
    *
    * Name of the resource that contains the jsp suffix -- the text that should
    * be appended to every processed jsp.
    */
    public static final String JSP_SUFFIX_FILE = "/web-install/jsp-suffix.jsp";
    
    /**
    * Property JspPrefix
    *
    * The text that should be appended to every processed jsp.
    */
    private static transient String __s_JspPrefix;
    
    /**
    * Property JspSuffix
    *
    * The text that should be prepended to every processed jsp.
    */
    private static transient String __s_JspSuffix;
    
    /**
    * Property Manifest
    *
    * Helper (calculated) property returning the manifest to be added into the
    * secured application. Default implementation extracts the manifest from
    * the SourceStorage.
    */
    
    /**
    * Property ModuleDescriptor
    *
    * Parsed module descriptor (application.xml, web.xml, or ejb-jar.xml)
    */
    private transient com.tangosol.run.xml.XmlDocument __m_ModuleDescriptor;
    
    /**
    * Property ModuleDescriptorName
    *
    * Name of a module descriptor (application.xml, web.xml, or ejb-jar.xml)
    */
    private String __m_ModuleDescriptorName;
    
    /**
    * Property ResourceFilter
    *
    * Before each application resource (a class, a method or a document) gets
    * registered into the resulting Xml document, the Resource filter gets a
    * chance to accept or reject the resource. Each resource will be
    * represented by an XmlElement and therefore could even be modified by the
    * filter
    * 
    * @see #inspect
    * 
    * Note: CURRENTLY NOT USED
    */
    private transient com.tangosol.util.Filter __m_ResourceFilter;
    
    /**
    * Property ResourceMap
    *
    * Specifies a StringTable object that has a resource name (URI) as a key
    * and the corresponding XML element ("jsp", "tld", etc.) of
    * "coherence-web.xsd" conforming XML document as a value.
    */
    private transient com.tangosol.util.StringTable __m_ResourceMap;
    
    /**
    * Property ServerInfo
    *
    * An additional information describing targeted deployment server.
    * 
    * Format: TBD.
    */
    private String __m_ServerInfo;
    
    /**
    * Property Source
    *
    * File object representing the location of the application to be inspected
    * and modified by this Installer.
    */
    private transient java.io.File __m_Source;
    
    /**
    * Property SourceStorage
    *
    * ApplicationReader object holding on the persistent storage of this
    * application source module.
    */
    private transient com.tangosol.engarde.ApplicationReader __m_SourceStorage;
    
    /**
    * Property Target
    *
    * File object representing the location of the resulting application
    * modified by this Installer.
    */
    private transient java.io.File __m_Target;
    
    /**
    * Property TargetStorage
    *
    * ApplicationWriter object representing on the persistent storage of the
    * "installed into" target module.
    */
    private transient com.tangosol.engarde.ApplicationWriter __m_TargetStorage;
    
    /**
    * Property TopApplication
    *
    * Calculate property that specifies whether this installer represents the
    * top level application.
    * 
    * For example, there could be a top level Web installer representing a
    * stand-alone Web application or an Enterprise installer containing a Web
    * installer.
    */
    
    /**
    * Property TouchTimestamp
    *
    * Specifies the timestamp that modified entries have to be marked with.  If
    * this value is set to zero,  the timestamps of the modified entries will
    * be preserved. If the value is -1; the server's current time should be
    * used ((the timestamp of the  modified application - a.k.a. Target).
    * 
    * @see #prepareTarget()
    * @see #replaceResource()
    */
    private transient long __m_TouchTimestamp;
    
    /**
    * Property WebDescriptor
    *
    * Specifies an XmlElement representing coherence-web descriptor (conforming
    * to "coherence-web.xsd").
    */
    private transient com.tangosol.run.xml.XmlElement __m_WebDescriptor;
    
    // Initializing constructor
    public Installer(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant ClassRoot
    protected String getClassRoot()
        {
        return null;
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/Installer".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * Close all resources used by the Installer.
    */
    public void close()
        {
        // import java.io.IOException;
        // import java.io.File;
        // import com.tangosol.engarde.ApplicationReader;
        // import com.tangosol.engarde.ApplicationWriter;
        
        super.close();
        
        ApplicationReader reader = getSourceStorage();
        if (reader != null)
            {
            reader.close();
            setSourceStorage(null);
            }
        
        ApplicationWriter writer = getTargetStorage();
        if (writer != null)
            {
            writer.close();
            setTargetStorage(null);
            }
        
        if (isDeleteSourceOnClose())
            {
            File fileSource = getSource();
            if (fileSource != null)
                {
                fileSource.delete();
                }
            }
        
        if (isDeleteTargetOnClose())
            {
            File fileTarget = getTarget();
            if (fileTarget != null)
                {
                fileTarget.delete();
                }
            }
        }
    
    /**
    * Copy the resource represented by the specified entry form the
    * SourceStrorage into the TargetStorage.
    * 
    * @return true iff the entry represents a a module that is copied entirely
    * in one step, so the enclosed etries processing should be skipped
    */
    protected boolean copyResource(com.tangosol.engarde.ApplicationEntry entry)
            throws java.io.IOException
        {
        // import com.tangosol.engarde.ApplicationEntry;
        // import com.tangosol.engarde.ApplicationReader;
        // import com.tangosol.engarde.ApplicationWriter;
        
        ApplicationReader reader = getSourceStorage();
        ApplicationWriter writer = getTargetStorage();
        
        ApplicationEntry eSrc = entry;
        ApplicationEntry eDst = writer.createEntry(eSrc);
        
        transferEntryData(reader.getInputStream(eSrc), writer);
        
        return false;
        }
    
    /**
    * Helper method that finds an element that is a child of the specified
    * XmlElement with the specified path having an "key" element with the
    * specified name and value. If the element doesn't exists it will be
    * created. For example, given the XML:
    * 
    *  <root>
    *     <item>
    *         <name>Dog</name>
    *     </item>
    *     <item>
    *         <name>Cat</name>
    *     </item>
    *  </root>
    * 
    * the following call:
    * 
    *     ensureElement(xml, "item", "name", "Cat")
    * 
    * would return an XmlElement representing the second item in the XML,
    * and the following call:
    * 
    *     ensureElement(xml, "item", "name", "Bird")
    * 
    * would make the XmlElement look like:
    * 
    *  <root>
    *     <item>
    *         <name>Dog</name>
    *     </item>
    *     <item>
    *         <name>Cat</name>
    *     </item>
    *     <item>
    *         <name>Bird</name>
    *     </item>
    *  </root>
    * 
    * and return the third item in the XML.
    */
    public static com.tangosol.run.xml.XmlElement ensureUniqueElement(com.tangosol.run.xml.XmlElement xmlEl, String sPath, String sKeyName, String sKeyValue)
        {
        // import com.tangosol.run.xml.XmlHelper;
        // import com.tangosol.run.xml.XmlElement;
        
        XmlElement xml = XmlHelper.findElement(xmlEl, sPath + "/" + sKeyName, sKeyValue);
        if (xml == null)
            {
            xml = xmlEl.addElement(sPath);
            xml.addElement(sKeyName).setString(sKeyValue);
            }
        else
            {
            xml = xml.getParent();
            }
        return xml;
        }
    
    // Declared at the super level
    protected void finalize()
            throws java.lang.Throwable
        {
        close();
        
        super.finalize();
        }
    
    /**
    * Finalizes the application inspection by validating the content of the
    * produced XML and stripping out all the temporary information
    */
    public void finalizeInspectWeb()
            throws java.io.IOException
        {
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.util.StringTable;
        // import java.util.Enumeration;
        
        // during the inspection, the Jsp and Tld maps may contain
        // the resources that were deferred for some reason
        // (mainly when the actual resource could not be loaded)
        
        StringTable tblResource = getResourceMap();
        
        if (!tblResource.isEmpty())
            {
            for (Enumeration enum = tblResource.elements(); enum.hasMoreElements();)
                {
                XmlElement xmlResource = (XmlElement) enum.nextElement();
        
                String sType = xmlResource.getName();
                String sName = xmlResource.getElement("name").getString();
                getErrorList().addWarning("The " + sType + " \"" + sName +
                    "\" is defined externally and cannot be modified");
                xmlResource.getParent().getElementList().remove(xmlResource);
                }
            tblResource.clear();
            }
        }
    
    /**
    * Make the final changes to the target application.
    */
    protected void finalizeInstall()
            throws java.io.IOException
        {
        // import com.tangosol.run.xml.XmlElement;
        // import java.util.jar.JarEntry;
        
        // for a persistent module we will stamp the application storage
        // with an appropriate XML document
        if (isTopApplication())
            {
            XmlElement xmlWebInstall = getWebDescriptor();
            if (xmlWebInstall != null)
                {
                replaceResource(getTargetStorage().createEntry("META-INF/coherence-web.xml"),
                    xmlWebInstall.toString().getBytes());
                }
            }
        
        getTargetStorage().close();
        setTargetStorage(null);
        }
    
    /**
    * Find the location of the tangosol coherence home directory.
    */
    public static java.io.File findHome()
        {
        // import java.io.File;
        // import java.util.StringTokenizer;
        
        String sClassPath = System.getProperty("java.class.path", "");
        
        for (StringTokenizer tokens = new StringTokenizer(sClassPath, File.pathSeparator);
                tokens.hasMoreTokens();)
            {
            String sPath = tokens.nextToken();
        
            File file = new File(sPath);
            if (file.isFile() && sPath.endsWith("webInstaller.jar"))
                {
                return file.getAbsoluteFile().getParentFile();
                }
            }
        return new File(".").getAbsoluteFile().getParentFile();
        }
    
    /**
    * Helper method that finds an element that is a child of the specified
    * XmlElement with the specified path having a "key" element with the
    * specified name and value. For example, given the XML:
    * 
    *  <root>
    *     <item>
    *         <name>Dog</name>
    *     </item>
    *     <item>
    *         <name>Cat</name>
    *     </item>
    *  </root>
    * 
    * the following call:
    * 
    *     findUniqueElement(xml, "item", "name", "Cat")
    * 
    * would return an XmlElement representing the second item in the XML.
    */
    public static com.tangosol.run.xml.XmlElement findUniqueElement(com.tangosol.run.xml.XmlElement xmlEl, String sPath, String sKeyName, String sKeyValue)
        {
        // import com.tangosol.run.xml.XmlHelper;
        // import com.tangosol.run.xml.XmlElement;
        
        XmlElement xml = XmlHelper.findElement(xmlEl, sPath + "/" + sKeyName, sKeyValue);
        return xml == null ? null : xml.getParent();
        }
    
    // Accessor for the property "ErrorList"
    /**
    * Getter for property ErrorList.<p>
    * The ErrorList object to log error information to.
    */
    public com.tangosol.util.ErrorList getErrorList()
        {
        // import com.tangosol.util.ErrorList;
        
        if (isTopApplication())
            {
            ErrorList errlist = __m_ErrorList;
            if (errlist == null)
                {
                setErrorList(errlist = new ErrorList());
                }
            return errlist;
            }
        else
            {
            return ((Installer) get_Parent()).getErrorList();
            }
        }
    
    /**
    * A static factory method that creates an instance of the Installer
    * component that is suitable for inspecting and modifying the content of
    * the specified application. A caller must call close() method to release
    * all resources held by the Installer. 
    * 
    * The fileSource parameter represents a directory where application binary
    * can be found or an application specific configuration descriptor itself.
    * 
    * The following scenarious are considered for the fileSource parameter.
    * <ul>
    * <li>a directory that contains an "extracted" J2EE application
    * <li>a directory that contains an application server specific descriptor.
    * <li>a .jar or .ear file that contains a J2EE application 
    * <li>an application-server specific application descriptor file
    * </ul>
    * 
    * @param fileSource File object representing the location of the
    * application
    * @param sServerInfo a String representing additional information about
    * targeted application server
    * 
    * @exception IOException thrown if an error occurs preventing the
    * Customizer's instantiation
    * 
    * @see ServerInfo property
    */
    public static Installer getInstaller(com.tangosol.engarde.ApplicationReader reader, String sServerInfo)
            throws java.io.IOException
        {
        // import Component.Installer.Ejb;
        // import Component.Installer.Enterprise;
        // import Component.Installer.Web;
        
        Installer installer;
        boolean   fSuccess = false;
        try
            {
            if (reader.getEntry("META-INF/application.xml") != null)
                {
                installer = Enterprise.getInstaller(reader, sServerInfo);
                }
            else if (
                reader.getEntry("WEB-INF/web.xml") != null)
                {
                installer = Web.getInstaller(reader, sServerInfo);
                }
            else if (
                reader.getEntry("META-INF/ejb-jar.xml") != null)
                {
                installer = Ejb.getInstaller(reader, sServerInfo);
                }
            else
                {
                throw new UnsupportedOperationException(
                    "Unsupported application format: " + reader);
                }
            fSuccess = true;
            }
        finally
            {
            if (!fSuccess)
                {
                reader.close();
                }
            }
        
        return installer;
        }
    
    /**
    * A static factory method that creates an instance of the Installer
    * component that is suitable for inspecting and modifying the content of
    * the specified application. A caller must call close() method to release
    * all resources held by the Installer. 
    * 
    * The fileSource parameter represents a directory where application binary
    * can be found or an application specific configuration descriptor itself.
    * 
    * The following scenarious are considered for the fileSource parameter.
    * <ul>
    * <li>a directory that contains an "extracted" J2EE application
    * <li>a directory that contains an application server specific descriptor.
    * <li>a .jar or .ear file that contains a J2EE application 
    * <li>an application-server specific application descriptor file
    * </ul>
    * 
    * @param fileSource File object representing the location of the
    * application
    * @param sServerInfo a String representing additional information about
    * targeted application server
    * 
    * @exception IOException thrown if an error occurs preventing the
    * Customizer's instantiation
    * 
    * @see ServerInfo property
    */
    public static Installer getInstaller(java.io.File fileSource, String sServerInfo)
            throws java.io.IOException
        {
        // import com.tangosol.engarde.ApplicationReader;
        // import com.tangosol.engarde.DirectoryStorage;
        // import com.tangosol.engarde.JarStorage;
        
        import java.io.IOException;
        import java.util.jar.JarFile;
        
        if (!fileSource.exists())
            {
            throw new IOException("Non-existent application path: " + fileSource);
            }
        
        fileSource = fileSource.getCanonicalFile();
        
        if (sServerInfo == null || sServerInfo.length() == 0)
            {
            sServerInfo = "Generic/2.3";
            }
        
        ApplicationReader reader;
        if (fileSource.isDirectory())
            {
            // directory based J2EE application (unzipped archive)
            reader = new DirectoryStorage(fileSource, DirectoryStorage.ACCESS_READ);
            }
        else
            {
            // J2EE archive
        
            JarFile jar;
            try
                {
                jar = new JarFile(fileSource);
                }
            catch (IOException e)
                {
                throw new IOException("Unsupported application format: " +
                    fileSource + " " + e.getMessage());
                }
            reader = new JarStorage(jar);
            }
        
        return getInstaller(reader, sServerInfo);
        }
    
    // Accessor for the property "JspPrefix"
    /**
    * Getter for property JspPrefix.<p>
    * The text that should be appended to every processed jsp.
    */
    public static String getJspPrefix()
        {
        // import com.tangosol.util.Base;
        
        String sPrefix = __s_JspPrefix;
        if (sPrefix == null)
            {
            try
                {
                byte[] abPrefix = Base.read(get_Class().getResourceAsStream(JSP_PREFIX_FILE));
        
                setJspPrefix(sPrefix = new String(abPrefix));
                }
            catch (Exception e)
                {
                throw Base.ensureRuntimeException(e, "Failed to load: " + JSP_PREFIX_FILE);
                }
            }
        return sPrefix;

        }
    
    // Accessor for the property "JspSuffix"
    /**
    * Getter for property JspSuffix.<p>
    * The text that should be prepended to every processed jsp.
    */
    public static String getJspSuffix()
        {
        // import com.tangosol.util.Base;
        
        String sSuffix = __s_JspSuffix;
        if (sSuffix == null)
            {
            try
                {
                byte[] abSuffix = Base.read(get_Class().getResourceAsStream(JSP_SUFFIX_FILE));
        
                setJspSuffix(sSuffix = new String(abSuffix));
                }
            catch (Exception e)
                {
                throw Base.ensureRuntimeException(e, "Failed to load: " + JSP_SUFFIX_FILE);
                }
            }
        return sSuffix;
        }
    
    // Accessor for the property "Manifest"
    /**
    * Getter for property Manifest.<p>
    * Helper (calculated) property returning the manifest to be added into the
    * secured application. Default implementation extracts the manifest from
    * the SourceStorage.
    */
    public java.util.jar.Manifest getManifest()
            throws java.io.IOException
        {
        // import com.tangosol.engarde.ApplicationReader;
        // import com.tangosol.engarde.JarStorage;
        
        ApplicationReader reader = getSourceStorage();
        return reader instanceof JarStorage ?
            ((JarStorage) reader).getJar().getManifest() : null;
        }
    
    // Accessor for the property "ModuleDescriptor"
    /**
    * Getter for property ModuleDescriptor.<p>
    * Parsed module descriptor (application.xml, web.xml, or ejb-jar.xml)
    */
    public com.tangosol.run.xml.XmlDocument getModuleDescriptor()
        {
        return __m_ModuleDescriptor;
        }
    
    // Accessor for the property "ModuleDescriptorName"
    /**
    * Getter for property ModuleDescriptorName.<p>
    * Name of a module descriptor (application.xml, web.xml, or ejb-jar.xml)
    */
    public String getModuleDescriptorName()
        {
        return __m_ModuleDescriptorName;
        }
    
    // Accessor for the property "ResourceFilter"
    /**
    * Getter for property ResourceFilter.<p>
    * Before each application resource (a class, a method or a document) gets
    * registered into the resulting Xml document, the Resource filter gets a
    * chance to accept or reject the resource. Each resource will be
    * represented by an XmlElement and therefore could even be modified by the
    * filter
    * 
    * @see #inspect
    * 
    * Note: CURRENTLY NOT USED
    */
    public com.tangosol.util.Filter getResourceFilter()
        {
        return __m_ResourceFilter;
        }
    
    // Accessor for the property "ResourceMap"
    /**
    * Getter for property ResourceMap.<p>
    * Specifies a StringTable object that has a resource name (URI) as a key
    * and the corresponding XML element ("jsp", "tld", etc.) of
    * "coherence-web.xsd" conforming XML document as a value.
    */
    public com.tangosol.util.StringTable getResourceMap()
        {
        // import com.tangosol.util.StringTable;
        // import com.tangosol.util.CacheCollator;
        // import java.text.Collator;
        // import java.util.Locale;
        
        if (isTopApplication())
            {
            StringTable tbl = __m_ResourceMap;
            if (tbl == null)
                {
                // use case insensitive table for resource names
        
                Collator collatorInsens = Collator.getInstance(Locale.ENGLISH);
                // use SECONDARY strength rather then PRIMARY 
                // since the PRIMARY strength collator ignores the white space
                // so strings "abc", "ab c" and "a b    c" are considered equal
                collatorInsens.setStrength(Collator.SECONDARY);
            
                tbl = new StringTable(new CacheCollator(collatorInsens));
                setResourceMap(tbl);
                }
            return tbl;
            }
        else
            {
            return ((Installer) get_Parent()).getResourceMap();
            }
        }
    
    // Accessor for the property "ServerInfo"
    /**
    * Getter for property ServerInfo.<p>
    * An additional information describing targeted deployment server.
    * 
    * Format: TBD.
    */
    public String getServerInfo()
        {
        return __m_ServerInfo;
        }
    
    // Accessor for the property "Source"
    /**
    * Getter for property Source.<p>
    * File object representing the location of the application to be inspected
    * and modified by this Installer.
    */
    public java.io.File getSource()
        {
        return __m_Source;
        }
    
    // Accessor for the property "SourceStorage"
    /**
    * Getter for property SourceStorage.<p>
    * ApplicationReader object holding on the persistent storage of this
    * application source module.
    */
    public com.tangosol.engarde.ApplicationReader getSourceStorage()
        {
        return __m_SourceStorage;
        }
    
    // Accessor for the property "Target"
    /**
    * Getter for property Target.<p>
    * File object representing the location of the resulting application
    * modified by this Installer.
    */
    public java.io.File getTarget()
        {
        return __m_Target;
        }
    
    // Accessor for the property "TargetStorage"
    /**
    * Getter for property TargetStorage.<p>
    * ApplicationWriter object representing on the persistent storage of the
    * "installed into" target module.
    */
    public com.tangosol.engarde.ApplicationWriter getTargetStorage()
        {
        return __m_TargetStorage;
        }
    
    // Accessor for the property "TouchTimestamp"
    /**
    * Getter for property TouchTimestamp.<p>
    * Specifies the timestamp that modified entries have to be marked with.  If
    * this value is set to zero,  the timestamps of the modified entries will
    * be preserved. If the value is -1; the server's current time should be
    * used ((the timestamp of the  modified application - a.k.a. Target).
    * 
    * @see #prepareTarget()
    * @see #replaceResource()
    */
    public long getTouchTimestamp()
        {
        return isTopApplication() ?
            __m_TouchTimestamp : ((Installer) get_Parent()).getTouchTimestamp();
        }
    
    // Accessor for the property "WebDescriptor"
    /**
    * Getter for property WebDescriptor.<p>
    * Specifies an XmlElement representing coherence-web descriptor (conforming
    * to "coherence-web.xsd").
    */
    public com.tangosol.run.xml.XmlElement getWebDescriptor()
        {
        return isTopApplication() ?
            __m_WebDescriptor : ((Installer) get_Parent()).getWebDescriptor();
        }
    
    /**
    * Initialize the Installer.
    * 
    * @exception IOException thrown if an error occurs preventing the
    * Installer's initialization
    */
    protected void initialize()
            throws java.io.IOException
        {
        // import com.tangosol.engarde.ApplicationEntry;
        // import com.tangosol.engarde.ApplicationReader;
        // import com.tangosol.engarde.DirectoryStorage;
        // import com.tangosol.engarde.JarStorage;
        // import com.tangosol.run.xml.SimpleParser;
        // import com.tangosol.run.xml.XmlDocument;
        // import java.io.File;
        
        ApplicationReader reader = getSourceStorage();
        _assert(reader != null);
        
        if (getSource() == null)
            {
            if (reader instanceof DirectoryStorage)
                {
                setSource(((DirectoryStorage) reader).getRoot());
                }
            else if (reader instanceof JarStorage)
                {
                setSource(new File(((JarStorage) reader).getJar().getName()));
                }
            }
        
        ApplicationEntry entry = reader.getEntry(getModuleDescriptorName());
        if (entry != null)
            {
            XmlDocument xml = new SimpleParser().parseXml(reader.getInputStream(entry));
        
            setModuleDescriptor(xml);
            }
        }
    
    /**
    * Inspect the content of the applications represented by the Source
    * property producing XML descriptor according to "coherence-web.xsd" and
    * adding it to the specified XML element. 
    * 
    * @param xml  the XmlElement that this method has to add information to;
    * 
    * @exception IOException thrown if an error occurs preventing the
    * application's content inspection
    */
    protected void inspectWeb()
            throws java.io.IOException
        {
        // import java.util.Enumeration;
        
        // if this customizer contains any other customizers
        // include the inspection information from them as well
        for (Enumeration enum = _enumChildrenInOrder(); enum.hasMoreElements();)
            {
            Object child = enum.nextElement();
        
            if (child instanceof Installer)
                {
                ((Installer) child).inspectWeb();
                }
            }
        }
    
    /**
    * Inspect the content of the applications represented by the Source
    * property producing XML descriptor according to "coherence-web.xsd" and
    * adding it to the specified XML element.  If the ResourceFilter property
    * is set, an XmlElement representing each application resource will be
    * submitted to the filter giving it a chance to accept or reject the
    * resource.
    * 
    * @param xmlWeb  the XmlElement that this method has to add information to;
    * if null is passed, this method is responsible for creation of a new
    * XmlElement
    * 
    * @return an XmlElement containing the information collected during the
    * inspection phase. If a mutable XmlElement is passed as a parameter, the
    * same object is guaranteed to be returned by this method
    * 
    * @exception IOException thrown if an error occurs preventing the
    * application's content inspection
    */
    public com.tangosol.run.xml.XmlElement inspectWeb(com.tangosol.run.xml.XmlElement xmlWeb)
            throws java.io.IOException
        {
        // import com.tangosol.run.xml.SimpleDocument;
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.util.Base;
        // import java.util.Enumeration;
        // import java.util.Iterator;
        
        _assert(isTopApplication());
        
        if (xmlWeb == null)
            {
            setWebDescriptor(
                xmlWeb = new SimpleDocument("coherence-web"));
            }
        else
            {
            // remove some old info
            for (Iterator iter = xmlWeb.getElements("tld"); iter.hasNext();)
                {
                iter.next();
                iter.remove();
                }
            for (Iterator iter = xmlWeb.getElements("jsp"); iter.hasNext();)
                {
                iter.next();
                iter.remove();
                }
            setWebDescriptor(xmlWeb);
            }
        
        if (isTopApplication())
            {
            // XML name space
            xmlWeb.addAttribute("xmlns").setString("urn:tangosol:coherence:web");
        
            // <application>
            XmlElement xmlApp = xmlWeb.ensureElement("application");
            xmlApp.ensureElement("server").setString(getServerInfo());
            xmlApp.ensureElement("path").setString(getSource().getAbsolutePath());
        
            XmlElement xmlDescr = getModuleDescriptor().ensureElement("description");
            if (xmlDescr.isEmpty())
                {
                xmlDescr.setString(
                    getModuleDescriptor().getSafeElement("description").getString());
                }
        
            // <coherence>
            XmlElement xmlCoherence = xmlWeb.getElement("coherence");
            if (xmlCoherence == null)
                {
                xmlCoherence = xmlWeb.addElement("coherence");
        
                XmlElement xmlHome     = xmlCoherence.ensureElement("home");
                XmlElement xmlCfg      = xmlCoherence.ensureElement("config-file");
                XmlElement xmlCacheCfg = xmlCoherence.ensureElement("cache-config-file");
        
                xmlHome.setString(findHome().getAbsolutePath());
                }
            }
        
        inspectWeb();
        finalizeInspectWeb();
        
        return xmlWeb;
        }
    
    /**
    * Modify the specifed JSP source according to the information in the
    * specified XmlElement.
    */
    protected String installJsp(String sJsp, com.tangosol.run.xml.XmlElement xmlJsp)
        {
        throw new UnsupportedOperationException("Cannot install JSP by this module: " + this);
        }
    
    /**
    * Dynamic resource is a class that is not written by an application
    * provider, but generated at deployment time (i.e. jsp compiler or EJB
    * compiler) or at run time. Usually identities of dynamic resources are
    * pretty much server specific. For example, WebLogic compiles JSPs into a
    * class named "jsp_servlet._<jsp-name>".
    * 
    * A class represented by the specified entry may or may not be a dynamic
    * resource. If it is, it will be modified accordingly; otherwise it will 
    * just be copied over to the Target
    * 
    * @param clsf ClassFile object representing a Java class
    * 
    * @return ClassFile object containing modified dynamic resource; or null if
    * no action is taken
    */
    protected com.tangosol.dev.assembler.ClassFile installPotentiallyDynamicResource(com.tangosol.dev.assembler.ClassFile clsf)
        {
        return null;
        }
    
    /**
    * Dynamic resource is a class that is not written by an application
    * provider, but generated at deployment time (i.e. jsp compiler or EJB
    * compiler) or even run time. Usually identities of dynamic resources are
    * pretty much server specific. For example, WebLogic compiles JSPs into a
    * class named "jsp_servlet._<jsp-name>".
    * 
    * A class represented by the specified entry may or may not be a dynamic
    * resource. If it is, it will be modified accordingly; otherwise it will 
    * just be copied over to the TargetStorage
    * 
    * @param entryClass entry representing a Java class in the SourceStorage
    */
    protected void installPotentiallyDynamicResource(com.tangosol.engarde.ApplicationEntry entryClass)
            throws java.io.IOException
        {
        // import com.tangosol.dev.assembler.ClassFile;
        // import com.tangosol.util.Base;
        
        byte[]    ab   = Base.read(getSourceStorage().getInputStream(entryClass));
        ClassFile clsf = new ClassFile(ab);
        
        clsf = installPotentiallyDynamicResource(clsf);
        
        if (clsf == null)
            {
            copyResource(entryClass);
            }
        else
            {
            replaceResource(entryClass, clsf.getBytes());
            }
        }
    
    /**
    * Modify the specifed resource according to the information in the
    * specified XmlElement
    */
    protected byte[] installResource(byte[] abResource, com.tangosol.run.xml.XmlElement xmlResource)
        {
        String sType = xmlResource.getName();
        
        if (
            sType.equals("jsp"))
            {
            String sJsp = new String(abResource);
            return installJsp(sJsp, xmlResource).getBytes();
            }
        else
            {
            throw new IllegalStateException("Unknown resource type: " + sType);
            }
        }
    
    /**
    * Modify a resource represented by the specified entry according to the
    * information in the specified XmlElement
    */
    protected void installResource(com.tangosol.engarde.ApplicationEntry entryResource, com.tangosol.run.xml.XmlElement xmlResource)
            throws java.io.IOException
        {
        // import com.tangosol.util.Base;
        
        byte[] abResource = Base.read(getSourceStorage().getInputStream(entryResource));
        
        try
            {
            abResource = installResource(abResource, xmlResource);
            }
        catch (RuntimeException e)
            {
            getErrorList().addError("Error: " + e +
                " occured while modifying resource: " + xmlResource);
            _trace(e);
            }
        
        replaceResource(entryResource, abResource);
        }
    
    /**
    * Add and modify all necessary resources of the application according to
    * the information in the specified XML descriptor (conforming to
    * "coherence-web.xsd").
    * 
    * Note: an application that has already been modified cannot be "insatlled
    * into" again.
    * 
    * @param xmlWebInstall  the XmlElement that contains the information
    * collected during the inspection phase and that has to be used to make the
    * necessary modifications to the application resources
    * @param fileTarget the java.io.File object representing the location of
    * the modified (secured) application; if null is passed, the temporary
    * location will be used
    * @param errlist  the ErrorList object to log error information to
    * 
    * @exception IOException thrown if an error occurs preventing modification
    * of the application resources
    */
    public void installWeb(com.tangosol.run.xml.XmlElement xmlWebInstall, java.io.File fileTarget)
            throws java.io.IOException
        {
        // import com.tangosol.util.ErrorList;
        
        _assert(!isInstalledWeb(), "Already installed");
        
        if (isTopApplication())
            {
            setWebDescriptor(xmlWebInstall);
            }
        
        prepareTarget(fileTarget);
        
        prepareWebResources();
        
        installWebResources();
        
        finalizeInstall();
        }
    
    /**
    * Add and modify the web resources.
    */
    protected void installWebResources()
            throws java.io.IOException
        {
        // import com.tangosol.engarde.ApplicationEntry as Entry;
        // import com.tangosol.engarde.ApplicationReader as Reader;
        // import com.tangosol.run.xml.XmlElement;
        // import com.tangosol.util.StringTable;
        // import java.util.Enumeration;
        // import java.util.jar.JarFile;
        
        String      sClassRoot  = getClassRoot();
        int         nRootLen    = sClassRoot == null ? 0 : sClassRoot.length();
        Reader      reader      = getSourceStorage();
        StringTable tblResource = getResourceMap();
        
        // a Jat file manifest is already copied at "prepareTarget"
        boolean fCheckMf = getSource().isFile();
        
        _trace((isTopApplication() ? "\n" : "  " ) + "*** " + this, 3);
        
        String sModuleName = null;
        
        for (Enumeration enum = reader.entries(); enum.hasMoreElements();)
            {
            Entry entry = (Entry) enum.nextElement();
        
            String sName = entry.getName();
            if (fCheckMf && sName.equalsIgnoreCase(JarFile.MANIFEST_NAME))
                {
                fCheckMf = false;
                continue;
                }
        
            if (sModuleName != null && sName.startsWith(sModuleName))
                {
                // skip the module entries that have been processed in bulk
                continue;
                }
        
            XmlElement xmlResource = (XmlElement) tblResource.get(sName);
            if (xmlResource == null)
                {
                // no modifications, just copy over
                if (copyResource(entry))
                    {
                    // this entry represents the entire module (directory);
                    // skip the enclosed files and directories
                    sModuleName = sName;
                    }
                else
                    {
                    sModuleName = null;
                    }
                }
            else
                {
                installResource(entry, xmlResource);
                }
            }
        }
    
    // Accessor for the property "DeleteSourceOnClose"
    /**
    * Getter for property DeleteSourceOnClose.<p>
    * Specifies whether or not the module source is temporary and should be
    * deleted on close.
    */
    public boolean isDeleteSourceOnClose()
        {
        return __m_DeleteSourceOnClose;
        }
    
    // Accessor for the property "DeleteTargetOnClose"
    /**
    * Getter for property DeleteTargetOnClose.<p>
    * Specifies whether or not the module target is temporary and should be
    * deleted on close.
    */
    public boolean isDeleteTargetOnClose()
        {
        return __m_DeleteTargetOnClose;
        }
    
    // Accessor for the property "InstalledWeb"
    /**
    * Getter for property InstalledWeb.<p>
    * Checks whether the Coherence*web has already been installed into the
    * application represented by this installer.
    */
    public boolean isInstalledWeb()
        {
        // import com.tangosol.engarde.ApplicationReader;
        
        ApplicationReader reader = getSourceStorage();
        return reader != null && reader.getEntry("META-INF/coherence-web.xml") != null;
        }
    
    // Accessor for the property "TopApplication"
    /**
    * Getter for property TopApplication.<p>
    * Calculate property that specifies whether this installer represents the
    * top level application.
    * 
    * For example, there could be a top level Web installer representing a
    * stand-alone Web application or an Enterprise installer containing a Web
    * installer.
    */
    public boolean isTopApplication()
        {
        return get_Parent() == null;
        }
    
    /**
    * Prepare the target application storage at the specified location
    * 
    * @param fileTarget the java.io.File object representing the location of
    * the modified (secured) application; if null is passed, the temporary
    * location will be used
    */
    protected void prepareTarget(java.io.File fileTarget)
            throws java.io.IOException
        {
        // import com.tangosol.engarde.ApplicationWriter;
        // import com.tangosol.engarde.DirectoryStorage;
        // import com.tangosol.engarde.JarStorage;
        // import java.io.File;
        // import java.io.IOException;
        
        File fileSource = getSource();
        _assert(fileSource != null && fileSource.exists());
        
        if (fileTarget == null)
            {
            File fileParent;
        
            if (isTopApplication())
                {
                fileParent = fileSource.getParentFile();
                }
            else 
                {
                fileParent = ((Installer) get_Parent()).getTarget();
                if (!fileParent.isDirectory())
                    {
                    fileParent = fileParent.getParentFile();
                    }
                }
        
            fileTarget = File.createTempFile("chrw", ".tmp", fileParent);
            _assert(fileTarget != null);
            }
        setTarget(fileTarget);
        
        if (getTouchTimestamp() == -1)
            {
            setTouchTimestamp(fileTarget.lastModified());
            }
        
        ApplicationWriter writer;
        if (fileSource.isDirectory())
            {
            fileTarget.delete();
            if (!fileTarget.mkdir())
                {
                throw new IOException("Failure to create directory: " + fileTarget);
                }
            writer = new DirectoryStorage(fileTarget, DirectoryStorage.ACCESS_WRITE);
            }
        else
            {
            writer = new JarStorage(fileTarget, getManifest());
            }
        setTargetStorage(writer);
        }
    
    /**
    * Prepare the lists of web resources in need of modifications.
    */
    protected void prepareWebResources()
            throws java.io.IOException
        {
        }
    
    /**
    * Replace the resource represented by the specified entry in the
    * SourceStorage with the specified data in the TargetStorage.
    */
    protected void replaceResource(com.tangosol.engarde.ApplicationEntry entry, byte[] abData)
            throws java.io.IOException
        {
        // import com.tangosol.engarde.ApplicationEntry;
        // import com.tangosol.engarde.ApplicationWriter;
        // import java.io.ByteArrayInputStream;
        
        _assert(abData != null, "Missing data for " + entry);
        
        ApplicationWriter writer = getTargetStorage();
        
        ApplicationEntry eSrc = entry;
        ApplicationEntry eDst = writer.createEntry(eSrc.getName());
        
        long lTime = getTouchTimestamp();
        
        eDst.setTime(lTime == 0 ? eSrc.getTime() : lTime);
        eDst.setSize(abData.length);
        
        _trace((isTopApplication() ? "" : "  " ) + "Installing " + entry.getName(), 3);
        
        transferEntryData(new ByteArrayInputStream(abData), writer);
        }
    
    /**
    * Replace the resource represented by the specified entry in the
    * SourceStorage with the content of the specified file in the TargetStorage.
    */
    protected void replaceResource(com.tangosol.engarde.ApplicationEntry entry, java.io.File file)
            throws java.io.IOException
        {
        // import java.io.File;
        // import java.io.FileInputStream;
        // import java.io.IOException;
        
        _assert(file.exists(), "Missing file for " + entry);
        
        if (file.isFile())
            {
            replaceResource(entry, new FileInputStream(file), file.length());
            }
        else
            {
            File fileNew = new File(file.getParentFile(), entry.getName());
            if (!file.renameTo(fileNew))
                {
                throw new IOException(
                    "Failed to rename directory: " + file.getAbsoluteFile() +
                    " to " + fileNew.getAbsoluteFile());
                }
            }
        }
    
    /**
    * Replace the resource represented by the specified entry in the
    * SourceStorage with the content of the specified InputStream in the
    * TargetStorage.
    */
    protected void replaceResource(com.tangosol.engarde.ApplicationEntry entry, java.io.InputStream stream, long cbSize)
            throws java.io.IOException
        {
        // import com.tangosol.engarde.ApplicationEntry;
        // import com.tangosol.engarde.ApplicationWriter;
        // import java.io.FileInputStream;
        
        _assert(stream != null, "Missing resource for " + entry);
        
        ApplicationWriter writer = getTargetStorage();
        
        ApplicationEntry eSrc = entry;
        ApplicationEntry eDst = writer.createEntry(eSrc.getName());
        
        long lTime = getTouchTimestamp();
        
        eDst.setTime(lTime == 0 ? eSrc.getTime() : lTime);
        if (cbSize >= 0)
            {
            eDst.setSize(cbSize);
            }
        
        _trace((isTopApplication() ? "" : "  " ) + "Installing " + entry.getName(), 3);
        
        transferEntryData(stream, writer);
        }
    
    // Accessor for the property "DeleteSourceOnClose"
    /**
    * Setter for property DeleteSourceOnClose.<p>
    * Specifies whether or not the module source is temporary and should be
    * deleted on close.
    */
    public void setDeleteSourceOnClose(boolean fDelete)
        {
        __m_DeleteSourceOnClose = fDelete;
        }
    
    // Accessor for the property "DeleteTargetOnClose"
    /**
    * Setter for property DeleteTargetOnClose.<p>
    * Specifies whether or not the module target is temporary and should be
    * deleted on close.
    */
    public void setDeleteTargetOnClose(boolean fDelete)
        {
        __m_DeleteTargetOnClose = fDelete;
        }
    
    // Accessor for the property "ErrorList"
    /**
    * Setter for property ErrorList.<p>
    * The ErrorList object to log error information to.
    */
    public void setErrorList(com.tangosol.util.ErrorList errlist)
        {
        _assert(isTopApplication());
        
        __m_ErrorList = (errlist);
        }
    
    // Accessor for the property "JspPrefix"
    /**
    * Setter for property JspPrefix.<p>
    * The text that should be appended to every processed jsp.
    */
    protected static void setJspPrefix(String sPrefix)
        {
        __s_JspPrefix = sPrefix;
        }
    
    // Accessor for the property "JspSuffix"
    /**
    * Setter for property JspSuffix.<p>
    * The text that should be prepended to every processed jsp.
    */
    protected static void setJspSuffix(String sPrefix)
        {
        __s_JspSuffix = sPrefix;
        }
    
    // Accessor for the property "ModuleDescriptor"
    /**
    * Setter for property ModuleDescriptor.<p>
    * Parsed module descriptor (application.xml, web.xml, or ejb-jar.xml)
    */
    protected void setModuleDescriptor(com.tangosol.run.xml.XmlDocument xml)
        {
        __m_ModuleDescriptor = xml;
        }
    
    // Accessor for the property "ModuleDescriptorName"
    /**
    * Setter for property ModuleDescriptorName.<p>
    * Name of a module descriptor (application.xml, web.xml, or ejb-jar.xml)
    */
    protected void setModuleDescriptorName(String sName)
        {
        __m_ModuleDescriptorName = sName;
        }
    
    // Accessor for the property "ResourceFilter"
    /**
    * Setter for property ResourceFilter.<p>
    * Before each application resource (a class, a method or a document) gets
    * registered into the resulting Xml document, the Resource filter gets a
    * chance to accept or reject the resource. Each resource will be
    * represented by an XmlElement and therefore could even be modified by the
    * filter
    * 
    * @see #inspect
    * 
    * Note: CURRENTLY NOT USED
    */
    public void setResourceFilter(com.tangosol.util.Filter filter)
        {
        __m_ResourceFilter = filter;
        }
    
    // Accessor for the property "ResourceMap"
    /**
    * Setter for property ResourceMap.<p>
    * Specifies a StringTable object that has a resource name (URI) as a key
    * and the corresponding XML element ("jsp", "tld", etc.) of
    * "coherence-web.xsd" conforming XML document as a value.
    */
    protected void setResourceMap(com.tangosol.util.StringTable map)
        {
        __m_ResourceMap = map;
        }
    
    // Accessor for the property "ServerInfo"
    /**
    * Setter for property ServerInfo.<p>
    * An additional information describing targeted deployment server.
    * 
    * Format: TBD.
    */
    protected void setServerInfo(String sServerInfo)
        {
        if (isTopApplication())
            {
            __m_ServerInfo = (sServerInfo);
            }
        else
            {
            ((Installer) get_Parent()).setServerInfo(sServerInfo);
            }
        }
    
    // Accessor for the property "Source"
    /**
    * Setter for property Source.<p>
    * File object representing the location of the application to be inspected
    * and modified by this Installer.
    */
    protected void setSource(java.io.File file)
        {
        __m_Source = file;
        }
    
    // Accessor for the property "SourceStorage"
    /**
    * Setter for property SourceStorage.<p>
    * ApplicationReader object holding on the persistent storage of this
    * application source module.
    */
    protected void setSourceStorage(com.tangosol.engarde.ApplicationReader reader)
        {
        __m_SourceStorage = reader;
        }
    
    // Accessor for the property "Target"
    /**
    * Setter for property Target.<p>
    * File object representing the location of the resulting application
    * modified by this Installer.
    */
    protected void setTarget(java.io.File file)
        {
        __m_Target = file;
        }
    
    // Accessor for the property "TargetStorage"
    /**
    * Setter for property TargetStorage.<p>
    * ApplicationWriter object representing on the persistent storage of the
    * "installed into" target module.
    */
    protected void setTargetStorage(com.tangosol.engarde.ApplicationWriter writer)
        {
        __m_TargetStorage = writer;
        }
    
    // Accessor for the property "TouchTimestamp"
    /**
    * Setter for property TouchTimestamp.<p>
    * Specifies the timestamp that modified entries have to be marked with.  If
    * this value is set to zero,  the timestamps of the modified entries will
    * be preserved. If the value is -1; the server's current time should be
    * used ((the timestamp of the  modified application - a.k.a. Target).
    * 
    * @see #prepareTarget()
    * @see #replaceResource()
    */
    public void setTouchTimestamp(long lTime)
        {
        _assert(isTopApplication());
        
        __m_TouchTimestamp = (lTime);
        }
    
    // Accessor for the property "WebDescriptor"
    /**
    * Setter for property WebDescriptor.<p>
    * Specifies an XmlElement representing coherence-web descriptor (conforming
    * to "coherence-web.xsd").
    */
    protected void setWebDescriptor(com.tangosol.run.xml.XmlElement xml)
        {
        _assert(xml.getName().equals("coherence-web"));
        _assert(isTopApplication());
        
        __m_WebDescriptor = (xml);
        }
    
    // Declared at the super level
    public String toString()
        {
        StringBuffer sb = new StringBuffer();
        
        sb.append("Module ")
          .append(get_Name().replace('~', '.'))
          .append(" (source=")
          .append(getSource())
          // .append(", target=")
          // .append(getTarget())
          .append(')');
        
        return sb.toString();
        }
    
    protected long transferEntryData(java.io.InputStream streamIn, com.tangosol.engarde.ApplicationWriter writer)
            throws java.io.IOException
        {
        // import java.io.EOFException;
        
        int    BLOCK  = 4096;
        byte[] ab     = new byte[BLOCK];
        long   cbSize = 0L;
        
        while (true)
            {
            try
                {
                int cb = streamIn.read(ab, 0, BLOCK);
                if (cb < 0)
                    {
                    break;
                    }
        
                writer.writeEntryData(ab, 0, cb);
                cbSize += cb;
                }
            catch (EOFException e)
                {
                break;
                }
            }
        
        if (cbSize == 0)
            {
            // force the entry creation
            writer.writeEntryData(ab, 0, 0);
            }
        
        streamIn.close();
        writer.closeEntry();
        
        return cbSize;
        }
    }
