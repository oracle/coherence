/* Class
*     _package.component.connector.ResourceAdapter
*/

package _package.component.connector;

import java.io.PrintWriter;
import java.util.Iterator;

/**
* This component is a factory of both ManagedConnection and EIS-specific
* connection factory instances. Default implementation assumes existence of the
* following static children components:
* <ul>
* <li>ConnectionFactory
* <li>ManagedConnection
* <li>DefaultConnectionManager
* </ul>
* 
* @see javax.resource.spi.ManagedConnectionFactory
*/
public abstract class ResourceAdapter
        extends    _package.component.Connector
        implements javax.resource.spi.ManagedConnectionFactory
    {
    // Fields declarations
    
    /**
    * Property LogWriter
    *
    */
    private transient java.io.PrintWriter __m_LogWriter;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("ConnectionFactory", ResourceAdapter$ConnectionFactory.get_CLASS());
        __mapChildren.put("DefaultConnectionManager", ResourceAdapter$DefaultConnectionManager.get_CLASS());
        __mapChildren.put("ManagedConnection", ResourceAdapter$ManagedConnection.get_CLASS());
        }
    
    // Initializing constructor
    public ResourceAdapter(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/ResourceAdapter".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // From interface: javax.resource.spi.ManagedConnectionFactory
    /**
    * Creates a connection factory instance. The connection factory instance
    * gets initialized with a default ConnectionManager provided by the
    * resource adapter.
    * 
    * @return a specific connection factory instance or
    * javax.resource.cci.ConnectionFactory instance
    * 
    * @exception javax.resource.ResourceException generic exception
    * @exception javax.resource.spi.ResourceAdapterInternalException  resource
    * adapter related error condition
    */
    public Object createConnectionFactory()
            throws javax.resource.ResourceException
        {
        // this method is used in a non-managed application scenario
        return createConnectionFactory(null);
        }
    
    // From interface: javax.resource.spi.ManagedConnectionFactory
    /**
    * Creates a Connection Factory instance. The Connection Factory instance
    * gets initialized with the passed ConnectionManager. In the managed
    * scenario, ConnectionManager is provided by the application server.
    * 
    * @param cxManager ConnectionManager to be associated with created
    * connection factory instance
    * 
    * @return a specific connection factory instance or
    * javax.resource.cci.ConnectionFactory instance
    * 
    * @exception javax.resource.ResourceException generic exception
    * @exception javax.resource.spi.ResourceAdapterInternalException  resource
    * adapter related error condition
    */
    public Object createConnectionFactory(javax.resource.spi.ConnectionManager cxManager)
            throws javax.resource.ResourceException
        {
        $ConnectionFactory cxFactory = ($ConnectionFactory) _newChild("ConnectionFactory");
        
        cxFactory.setConnectionManager(cxManager);
        
        return cxFactory;
        }
    
    // From interface: javax.resource.spi.ManagedConnectionFactory
    /**
    * ManagedConnectionFactory uses the security information and additional
    * ConnectionRequestInfo (which is specific to ResourceAdapter and opaque to
    * application server) to create this new connection.
    * 
    * @param  subject Caller's security information
    * @param  cxRequestInfo Additional resource adapter specific connection
    * request information
    */
    public javax.resource.spi.ManagedConnection createManagedConnection(javax.security.auth.Subject subject, javax.resource.spi.ConnectionRequestInfo cxRequestInfo)
            throws javax.resource.ResourceException
        {
        $ManagedConnection connection = ($ManagedConnection) _newChild("ManagedConnection");
        
        connection.authenticate(subject, cxRequestInfo);
        
        return connection;
        }
    
    // From interface: javax.resource.spi.ManagedConnectionFactory
    // Accessor for the property "LogWriter"
    /**
    * Getter for property LogWriter.<p>
    */
    public java.io.PrintWriter getLogWriter()
        {
        return __m_LogWriter;
        }
    
    public void log(String sMsg)
        {
        // import java.io.PrintWriter;
        
        boolean fDebug = true;
        
        sMsg = Thread.currentThread() + ": " + sMsg;
        
        PrintWriter pw = getLogWriter();
        if (pw != null)
            {
            pw.println(sMsg);
            }
        else if (fDebug)
            {
            System.out.println(sMsg);
            }
        }
    
    // From interface: javax.resource.spi.ManagedConnectionFactory
    /**
    * Returns a matched connection from the candidate set of connections. 
    * 
    * ManagedConnectionFactory uses the security info (as in Subject) and
    * information provided through ConnectionRequestInfo and additional
    * Resource Adapter specific criteria to do matching. Note that criteria
    * used for matching is specific to a resource adapter and is not prescribed
    * by the Connector specification.
    * 
    * This method returns a ManagedConnection instance that is the best match
    * for handling the connection allocation request.
    * 
    * @param setConnection  candidate connection set
    * @param subject  caller's security information
    * @param cxRequestInfo  additional resource adapter specific connection
    * request information
    * 
    * @return ManagedConnection if resource adapter finds an acceptable match;
    * null otherwise
    */
    public javax.resource.spi.ManagedConnection matchManagedConnections(java.util.Set setConnection, javax.security.auth.Subject subject, javax.resource.spi.ConnectionRequestInfo info)
            throws javax.resource.ResourceException
        {
        // import java.util.Iterator;
        
        for (Iterator iter = setConnection.iterator(); iter.hasNext();)
            {
            Object o = iter.next();
        
            if (o instanceof $ManagedConnection)
                {
                $ManagedConnection connection = ($ManagedConnection) o;
                if (connection.matches(subject, info))
                    {
                    return connection;
                    }
                }
            }
        
        return null;
        }
    
    // From interface: javax.resource.spi.ManagedConnectionFactory
    // Accessor for the property "LogWriter"
    /**
    * Setter for property LogWriter.<p>
    */
    public void setLogWriter(java.io.PrintWriter out)
        {
        __m_LogWriter = out;
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_Name() + "@" + hashCode();
        }
    }
