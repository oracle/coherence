/* Class
*     _package.component.connector.ResourceAdapter$ManagedConnection
*/

package _package.component.connector;

import com.tangosol.util.Base;
import com.tangosol.util.Listeners;
import java.io.PrintWriter;
import java.util.EventListener;
import javax.resource.ResourceException;
import javax.resource.spi.ConnectionEvent;
import javax.resource.spi.ConnectionEventListener;
import javax.resource.spi.ConnectionRequestInfo;
import javax.resource.spi.LocalTransaction;
import javax.resource.spi.ManagedConnectionMetaData;
import javax.security.auth.Subject;
import javax.transaction.xa.XAResource;

/**
* ManagedConnection represents a physical connection to
* an underlying EIS (Chapter 5.5.4 of JCA 1.0 specification)
*/
public abstract class ResourceAdapter$ManagedConnection
        extends    _package.component.Connector
        implements javax.resource.spi.ManagedConnection
    {
    // Fields declarations
    
    /**
    * Property Closed
    *
    */
    private transient boolean __m_Closed;
    
    /**
    * Property ConnectionInfo
    *
    * Placeholder for a RequestInfo object associated with this MC
    */
    private transient javax.resource.spi.ConnectionRequestInfo __m_ConnectionInfo;
    
    /**
    * Property ConnectionListeners
    *
    */
    private transient com.tangosol.util.Listeners __m_ConnectionListeners;
    
    /**
    * Property LogWriter
    *
    */
    private transient java.io.PrintWriter __m_LogWriter;
    
    /**
    * Property Subject
    *
    * Placeholder for a Subject object associated with this MC
    */
    private transient javax.security.auth.Subject __m_Subject;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("LocalTransaction", ResourceAdapter$ManagedConnection$LocalTransaction.get_CLASS());
        __mapChildren.put("XAResource", ResourceAdapter$ManagedConnection$XAResource.get_CLASS());
        }
    
    // Initializing constructor
    public ResourceAdapter$ManagedConnection(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/ResourceAdapter$ManagedConnection".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // From interface: javax.resource.spi.ManagedConnection
    public void addConnectionEventListener(javax.resource.spi.ConnectionEventListener l)
        {
        // import com.tangosol.util.Listeners;
        // import javax.resource.spi.ConnectionEventListener;
        
        if (l == null)
            {
            return;
            }
        Listeners listeners = getConnectionListeners();
        if (listeners == null)
            {
            setConnectionListeners(listeners = new Listeners());
            }
        listeners.add(l);
        }
    
    // From interface: javax.resource.spi.ManagedConnection
    public void associateConnection(Object connection)
            throws javax.resource.ResourceException
        {
        }
    
    /**
    * Check the connection subject and info.
    * 
    * @see ResourceAdapter#createManagedConnection
    */
    public void authenticate(javax.security.auth.Subject subject, javax.resource.spi.ConnectionRequestInfo cxInfo)
            throws javax.resource.ResourceException
        {
        // import javax.security.auth.Subject;
        // import javax.resource.spi.ConnectionRequestInfo;
        // import javax.resource.ResourceException;
        
        setSubject(subject);
        setConnectionInfo(cxInfo);
        }
    
    protected void checkStatus()
        {
        if (isClosed())
            {
            throw new IllegalStateException(get_Name() + " is closed");
            }
        }
    
    // From interface: javax.resource.spi.ManagedConnection
    public void cleanup()
            throws javax.resource.ResourceException
        {
        checkStatus();
        }
    
    // From interface: javax.resource.spi.ManagedConnection
    public void destroy()
            throws javax.resource.ResourceException
        {
        setClosed(true);
        }
    
    public void fireConnectionEvent(int nEventType)
        {
        fireConnectionEvent(nEventType, null, null);
        }
    
    public void fireConnectionEvent(int nEventType, Exception exception)
        {
        fireConnectionEvent(nEventType, exception, null);
        }
    
    public void fireConnectionEvent(int nEventType, Exception exception, Object oConnectionHandle)
        {
        // import com.tangosol.util.Listeners;
        // import java.util.EventListener;
        // import javax.resource.spi.ConnectionEvent;
        // import javax.resource.spi.ConnectionEventListener;
        
        Listeners listeners = getConnectionListeners();
        if (listeners != null)
            {
            ConnectionEvent ce = exception == null ?
                new ConnectionEvent(this, nEventType) :
                new ConnectionEvent(this, nEventType, exception);
        
            if (oConnectionHandle != null)
                {
                ce.setConnectionHandle(oConnectionHandle);
                }
        
            EventListener[] targets = listeners.listeners();
            for (int i = targets.length; --i >= 0;)
                {
                ConnectionEventListener target = (ConnectionEventListener) targets[i];
        
                switch (nEventType)
                    {
                    case ConnectionEvent.CONNECTION_CLOSED:
                        target.connectionClosed(ce);
                        break;
                    case ConnectionEvent.LOCAL_TRANSACTION_STARTED:
                        target.localTransactionStarted(ce);
                        break;
                    case ConnectionEvent.LOCAL_TRANSACTION_COMMITTED:
                        target.localTransactionCommitted(ce);
                        break;
                    case ConnectionEvent.LOCAL_TRANSACTION_ROLLEDBACK:
                        target.localTransactionRolledback(ce);
                        break;
                    case ConnectionEvent.CONNECTION_ERROR_OCCURRED:
                        target.connectionErrorOccurred(ce);
                        break;
                    default:
                        throw new IllegalArgumentException("Illegal eventType: " +
                            nEventType);
                   }
                }
            }
        }
    
    // From interface: javax.resource.spi.ManagedConnection
    public Object getConnection(javax.security.auth.Subject subject, javax.resource.spi.ConnectionRequestInfo cxInfo)
            throws javax.resource.ResourceException
        {
        return null;
        }
    
    // Accessor for the property "ConnectionInfo"
    /**
    * Getter for property ConnectionInfo.<p>
    * Placeholder for a RequestInfo object associated with this MC
    */
    public javax.resource.spi.ConnectionRequestInfo getConnectionInfo()
        {
        return __m_ConnectionInfo;
        }
    
    // Accessor for the property "ConnectionListeners"
    /**
    * Getter for property ConnectionListeners.<p>
    */
    protected com.tangosol.util.Listeners getConnectionListeners()
        {
        return __m_ConnectionListeners;
        }
    
    // From interface: javax.resource.spi.ManagedConnection
    public javax.resource.spi.LocalTransaction getLocalTransaction()
            throws javax.resource.ResourceException
        {
        // import javax.resource.spi.LocalTransaction;
        // import javax.resource.ResourceException;
        
        checkStatus();
        
        return (LocalTransaction) _newChild("LocalTransaction");
        }
    
    // From interface: javax.resource.spi.ManagedConnection
    // Accessor for the property "LogWriter"
    /**
    * Getter for property LogWriter.<p>
    */
    public java.io.PrintWriter getLogWriter()
        {
        return __m_LogWriter;
        }
    
    // From interface: javax.resource.spi.ManagedConnection
    public javax.resource.spi.ManagedConnectionMetaData getMetaData()
        {
        // import javax.resource.spi.ManagedConnectionMetaData;
        
        checkStatus();
        
        return (ManagedConnectionMetaData) _findChild("ManagedConnectionMetaData");
        }
    
    // Accessor for the property "Subject"
    /**
    * Getter for property Subject.<p>
    * Placeholder for a Subject object associated with this MC
    */
    public javax.security.auth.Subject getSubject()
        {
        return __m_Subject;
        }
    
    // From interface: javax.resource.spi.ManagedConnection
    public javax.transaction.xa.XAResource getXAResource()
            throws javax.resource.ResourceException
        {
        // import javax.transaction.xa.XAResource;
        // import javax.resource.ResourceException;
        
        checkStatus();
        
        return (XAResource) _newChild("XAResource");
        }
    
    // Accessor for the property "Closed"
    /**
    * Getter for property Closed.<p>
    */
    public boolean isClosed()
        {
        return __m_Closed;
        }
    
    public void log(String sMsg)
        {
        // import java.io.PrintWriter;
        
        PrintWriter pw = getLogWriter();
        if (pw != null)
            {
            pw.println(sMsg);
            }
        else
            {
            (($Module) get_Module()).log(sMsg);
            }
        }
    
    /**
    * Checks whether or not this connection object matches to the specified
    * security info (subject) and connection request information (info)
    */
    public boolean matches(javax.security.auth.Subject subject, javax.resource.spi.ConnectionRequestInfo cxInfo)
        {
        // import com.tangosol.util.Base;
        // import javax.security.auth.Subject;
        // import javax.resource.spi.ConnectionRequestInfo;
        
        return Base.equals(subject, getSubject()) &&
               Base.equals(cxInfo,  getConnectionInfo());
        }
    
    // From interface: javax.resource.spi.ManagedConnection
    public void removeConnectionEventListener(javax.resource.spi.ConnectionEventListener l)
        {
        // import com.tangosol.util.Listeners;
        // import javax.resource.spi.ConnectionEventListener;
        
        Listeners listeners = getConnectionListeners();
        if (listeners != null)
            {
            listeners.remove(l);
        
            if (listeners.listeners().length == 0)
                {
                setConnectionListeners(null);
                }
            }
        }
    
    // Accessor for the property "Closed"
    /**
    * Setter for property Closed.<p>
    */
    protected void setClosed(boolean fClosed)
        {
        __m_Closed = fClosed;
        }
    
    // Accessor for the property "ConnectionInfo"
    /**
    * Setter for property ConnectionInfo.<p>
    * Placeholder for a RequestInfo object associated with this MC
    */
    public void setConnectionInfo(javax.resource.spi.ConnectionRequestInfo pConnectionInfo)
        {
        __m_ConnectionInfo = pConnectionInfo;
        }
    
    // Accessor for the property "ConnectionListeners"
    /**
    * Setter for property ConnectionListeners.<p>
    */
    protected void setConnectionListeners(com.tangosol.util.Listeners liisteners)
        {
        __m_ConnectionListeners = liisteners;
        }
    
    // From interface: javax.resource.spi.ManagedConnection
    // Accessor for the property "LogWriter"
    /**
    * Setter for property LogWriter.<p>
    */
    public void setLogWriter(java.io.PrintWriter out)
        {
        __m_LogWriter = out;
        }
    
    // Accessor for the property "Subject"
    /**
    * Setter for property Subject.<p>
    * Placeholder for a Subject object associated with this MC
    */
    public void setSubject(javax.security.auth.Subject subject)
        {
        __m_Subject = subject;
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_Name() + "@" + hashCode() + ": cxInfo=" + getConnectionInfo();
        }
    }
