/* Class
*     _package.component.connector.ResourceAdapter$DefaultConnectionManager
*/

package _package.component.connector;

import javax.resource.spi.ManagedConnection;

/**
* The default ConnectionManager implementation for the non-managed scenario. It
* provieds a hook for a resource adapter to pass a connection request to an
* application server.
*/
public class ResourceAdapter$DefaultConnectionManager
        extends    _package.component.Connector
        implements javax.resource.spi.ConnectionManager
    {
    // Fields declarations
    
    // Default constructor
    public ResourceAdapter$DefaultConnectionManager()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ResourceAdapter$DefaultConnectionManager(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ResourceAdapter$DefaultConnectionManager();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/ResourceAdapter$DefaultConnectionManager".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // From interface: javax.resource.spi.ConnectionManager
    /**
    * This method gets called by the resource adapter's connection factory
    * instance. This lets connection factory instance (provided by the resource
    * adapter) pass a connection request to the ConnectionManager instance.
    */
    public Object allocateConnection(javax.resource.spi.ManagedConnectionFactory mcf, javax.resource.spi.ConnectionRequestInfo info)
            throws javax.resource.ResourceException
        {
        // import javax.resource.spi.ManagedConnection;
        
        ManagedConnection connection = mcf.createManagedConnection(null, info);
        
        return connection.getConnection(null, info);

        }
    }
