/* Class
*     _package.component.connector.ResourceAdapter$ConnectionFactory
*/

package _package.component.connector;

import javax.resource.spi.ConnectionManager;
import javax.resource.spi.ManagedConnectionFactory;

public class ResourceAdapter$ConnectionFactory
        extends    _package.component.Connector
    {
    // Fields declarations
    
    /**
    * Property ConnectionManager
    *
    * ConnectionManager associated with this connection factory instance.  In
    * the managed scenario, ConnectionManager is provided by an application
    * server.  It provides a hook for a resource adapter to pass a connection
    * request to an application server.
    * 
    * @see ResourceAdapter#createConnectionFactory(ConnectionManager)
    */
    private javax.resource.spi.ConnectionManager __m_ConnectionManager;
    
    /**
    * Property ManagedConnectionFactory
    *
    * ManagedConnectionFactory that created this connection factory instance.
    * 
    * @see ResourceAdapter#createConnectionFactory()
    */
    
    // Default constructor
    public ResourceAdapter$ConnectionFactory()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ResourceAdapter$ConnectionFactory(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ResourceAdapter$ConnectionFactory();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/ResourceAdapter$ConnectionFactory".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Accessor for the property "ConnectionManager"
    /**
    * Getter for property ConnectionManager.<p>
    * ConnectionManager associated with this connection factory instance.  In
    * the managed scenario, ConnectionManager is provided by an application
    * server.  It provides a hook for a resource adapter to pass a connection
    * request to an application server.
    * 
    * @see ResourceAdapter#createConnectionFactory(ConnectionManager)
    */
    public javax.resource.spi.ConnectionManager getConnectionManager()
        {
        // import javax.resource.spi.ConnectionManager;
        
        ConnectionManager cm = __m_ConnectionManager;
        if (cm == null)
            {
            cm = ($DefaultConnectionManager) get_Parent()._newChild("DefaultConnectionManager");
            setConnectionManager(cm);
            }
        return cm;
        }
    
    // Accessor for the property "ManagedConnectionFactory"
    /**
    * Getter for property ManagedConnectionFactory.<p>
    * ManagedConnectionFactory that created this connection factory instance.
    * 
    * @see ResourceAdapter#createConnectionFactory()
    */
    public javax.resource.spi.ManagedConnectionFactory getManagedConnectionFactory()
        {
        // import javax.resource.spi.ManagedConnectionFactory;
        
        return (ManagedConnectionFactory) get_Parent();
        }
    
    // Accessor for the property "ConnectionManager"
    /**
    * Setter for property ConnectionManager.<p>
    * ConnectionManager associated with this connection factory instance.  In
    * the managed scenario, ConnectionManager is provided by an application
    * server.  It provides a hook for a resource adapter to pass a connection
    * request to an application server.
    * 
    * @see ResourceAdapter#createConnectionFactory(ConnectionManager)
    */
    public void setConnectionManager(javax.resource.spi.ConnectionManager manager)
        {
        __m_ConnectionManager = manager;
        }
    }
