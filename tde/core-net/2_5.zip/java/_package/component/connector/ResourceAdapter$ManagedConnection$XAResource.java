/* Class
*     _package.component.connector.ResourceAdapter$ManagedConnection$XAResource
*/

package _package.component.connector;

import javax.resource.spi.ManagedConnection;

public abstract class ResourceAdapter$ManagedConnection$XAResource
        extends    _package.component.Connector
        implements javax.transaction.xa.XAResource
    {
    // Fields declarations
    
    /**
    * Property ManagedConnection
    *
    */
    
    /**
    * Property Timeout
    *
    */
    private int __m_Timeout;
    
    // Initializing constructor
    public ResourceAdapter$ManagedConnection$XAResource(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/ResourceAdapter$ManagedConnection$XAResource".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent();
        }
    
    // From interface: javax.transaction.xa.XAResource
    public void commit(javax.transaction.xa.Xid xid, boolean fOnePhase)
            throws javax.transaction.xa.XAException
        {
        }
    
    // From interface: javax.transaction.xa.XAResource
    public void end(javax.transaction.xa.Xid xid, int iFlags)
            throws javax.transaction.xa.XAException
        {
        }
    
    // From interface: javax.transaction.xa.XAResource
    public void forget(javax.transaction.xa.Xid xid)
            throws javax.transaction.xa.XAException
        {
        }
    
    // Accessor for the property "ManagedConnection"
    /**
    * Getter for property ManagedConnection.<p>
    */
    public ResourceAdapter$ManagedConnection getManagedConnection()
        {
        // import javax.resource.spi.ManagedConnection;
        
        return ($ManagedConnection) get_Parent();
        }
    
    // Accessor for the property "Timeout"
    /**
    * Getter for property Timeout.<p>
    */
    public int getTimeout()
        {
        return __m_Timeout;
        }
    
    // From interface: javax.transaction.xa.XAResource
    public int getTransactionTimeout()
            throws javax.transaction.xa.XAException
        {
        return getTimeout();
        }
    
    // From interface: javax.transaction.xa.XAResource
    public boolean isSameRM(javax.transaction.xa.XAResource resource)
            throws javax.transaction.xa.XAException
        {
        return this == resource;
        }
    
    // From interface: javax.transaction.xa.XAResource
    public int prepare(javax.transaction.xa.Xid xid)
            throws javax.transaction.xa.XAException
        {
        return 0;
        }
    
    // From interface: javax.transaction.xa.XAResource
    public javax.transaction.xa.Xid[] recover(int iFlags)
            throws javax.transaction.xa.XAException
        {
        return null;
        }
    
    // From interface: javax.transaction.xa.XAResource
    public void rollback(javax.transaction.xa.Xid xid)
            throws javax.transaction.xa.XAException
        {
        }
    
    // Accessor for the property "Timeout"
    /**
    * Setter for property Timeout.<p>
    */
    public void setTimeout(int pTimeout)
        {
        __m_Timeout = pTimeout;
        }
    
    // From interface: javax.transaction.xa.XAResource
    public boolean setTransactionTimeout(int nSeconds)
            throws javax.transaction.xa.XAException
        {
        setTimeout(nSeconds);
        return true;
        }
    
    // From interface: javax.transaction.xa.XAResource
    public void start(javax.transaction.xa.Xid xid, int iFlags)
            throws javax.transaction.xa.XAException
        {
        }
    }
