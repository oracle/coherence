/* Class
*     _package.component.connector.ResourceAdapter$ManagedConnection$LocalTransaction
*/

package _package.component.connector;

import javax.resource.spi.ManagedConnection;

public abstract class ResourceAdapter$ManagedConnection$LocalTransaction
        extends    _package.component.Connector
        implements javax.resource.spi.LocalTransaction
    {
    // Fields declarations
    
    /**
    * Property ManagedConnection
    *
    */
    
    // Initializing constructor
    public ResourceAdapter$ManagedConnection$LocalTransaction(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/ResourceAdapter$ManagedConnection$LocalTransaction".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent();
        }
    
    // From interface: javax.resource.spi.LocalTransaction
    public void begin()
            throws javax.resource.ResourceException
        {
        }
    
    // From interface: javax.resource.spi.LocalTransaction
    public void commit()
            throws javax.resource.ResourceException
        {
        }
    
    // Accessor for the property "ManagedConnection"
    /**
    * Getter for property ManagedConnection.<p>
    */
    public ResourceAdapter$ManagedConnection getManagedConnection()
        {
        // import javax.resource.spi.ManagedConnection;
        
        return ($ManagedConnection) get_Parent();
        }
    
    // From interface: javax.resource.spi.LocalTransaction
    public void rollback()
            throws javax.resource.ResourceException
        {
        }
    }
