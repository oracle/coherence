/* Class
*     _package.component.connector.resourceAdapter.cciAdapter.CacheAdapter$ManagedConnection$LocalTransaction
*/

package _package.component.connector.resourceAdapter.cciAdapter;

import com.tangosol.util.TransactionMap;
import java.util.Iterator;
import java.util.Map$Entry;
import java.util.Map;
import javax.resource.spi.LocalTransactionException;

public class CacheAdapter$ManagedConnection$LocalTransaction
        extends    _package.component.connector.resourceAdapter.CciAdapter$ManagedConnection$LocalTransaction
    {
    // Fields declarations
    
    /**
    * Property TxMaps
    *
    * Map of TransactionMap objects enlisted in this transaction keyed by their
    * names.
    */
    private transient java.util.Map __m_TxMaps;
    
    // Default constructor
    public CacheAdapter$ManagedConnection$LocalTransaction()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CacheAdapter$ManagedConnection$LocalTransaction(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setTxMaps(new java.util.HashMap());
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CacheAdapter$ManagedConnection$LocalTransaction();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/resourceAdapter/cciAdapter/CacheAdapter$ManagedConnection$LocalTransaction".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent();
        }
    
    // Declared at the super level
    public void commit()
            throws javax.resource.ResourceException
        {
        // import com.tangosol.util.TransactionMap;
        // import java.util.Iterator;
        // import java.util.Map;
        // import javax.resource.spi.LocalTransactionException;
        
        Map map = getTxMaps();
        try
            {
            // everything is happenning on the same thread
            // so we are guaranteed that the two iterators
            // yield the same results
        
            for (Iterator iter = map.values().iterator(); iter.hasNext();)
                {
                TransactionMap mapTx = (TransactionMap) iter.next();
        
                mapTx.prepare();
                }
        
            for (Iterator iter = map.keySet().iterator(); iter.hasNext();)
                {
                Object         oKey  = iter.next();
                TransactionMap mapTx = (TransactionMap) map.get(oKey);
        
                mapTx.commit();
        
                iter.remove(); // delist the transactional map
                }
            }
        catch (RuntimeException e)
            {
            (($ManagedConnection) getManagedConnection()).
                log("]===> commit failed:\n" + getStackTrace(e));
        
            rollback();
        
            LocalTransactionException lte = new LocalTransactionException(e.toString());
            lte.setLinkedException(e);
            throw lte;
            }
        
        super.commit();
        }
    
    /**
    * Enlist the specified named cache into this LocalTransaction under a given
    * name
    */
    public void enlist(com.tangosol.util.TransactionMap mapTx, String sName)
        {
        getTxMaps().put(sName, mapTx);
        mapTx.begin();
        }
    
    /**
    * Return a TransactionMap enlisted under a given name
    */
    public com.tangosol.util.TransactionMap getEnlistedMap(String sName)
        {
        // import com.tangosol.util.TransactionMap;
        
        return (TransactionMap) getTxMaps().get(sName);
        }
    
    // Accessor for the property "TxMaps"
    /**
    * Getter for property TxMaps.<p>
    * Map of TransactionMap objects enlisted in this transaction keyed by their
    * names.
    */
    protected java.util.Map getTxMaps()
        {
        return __m_TxMaps;
        }
    
    // Declared at the super level
    public void rollback()
            throws javax.resource.ResourceException
        {
        // import com.tangosol.util.TransactionMap;
        // import java.util.Iterator;
        // import java.util.Map;
        // import java.util.Map$Entry;
        
        Map map = getTxMaps();
        
        for (Iterator iter = map.keySet().iterator(); iter.hasNext();)
            {
            Object         oKey  = iter.next();
            TransactionMap mapTx = (TransactionMap) map.get(oKey);
        
            try
                {
                mapTx.rollback();
                }
            catch (Exception e)
                {
                // rollback should never fail
                e.printStackTrace(System.err);
                }
            finally
                {
                iter.remove();
                }
            }
        
        super.rollback();
        }
    
    // Accessor for the property "TxMaps"
    /**
    * Setter for property TxMaps.<p>
    * Map of TransactionMap objects enlisted in this transaction keyed by their
    * names.
    */
    protected void setTxMaps(java.util.Map map)
        {
        __m_TxMaps = map;
        }
    }
