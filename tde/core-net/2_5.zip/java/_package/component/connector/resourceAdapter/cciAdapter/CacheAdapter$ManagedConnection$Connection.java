/* Class
*     _package.component.connector.resourceAdapter.cciAdapter.CacheAdapter$ManagedConnection$Connection
*/

package _package.component.connector.resourceAdapter.cciAdapter;

import com.tangosol.net.CacheService;

public class CacheAdapter$ManagedConnection$Connection
        extends    _package.component.connector.resourceAdapter.CciAdapter$ManagedConnection$Connection
    {
    // Fields declarations
    
    /**
    * Property CacheService
    *
    * CacheService assosiated with this Connection.
    */
    private transient com.tangosol.net.CacheService __m_CacheService;
    
    /**
    * Property Concurrency
    *
    * The default concurrency value used to create transactional caches.
    */
    private transient int __m_Concurrency;
    
    /**
    * Property Isolation
    *
    * The default transaction isolation value used to create transactional
    * caches.
    */
    private transient int __m_Isolation;
    
    /**
    * Property Timeout
    *
    * The default transaction timeout value used to create transactional caches.
    */
    private transient int __m_Timeout;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Interaction", CacheAdapter$ManagedConnection$Connection$Interaction.get_CLASS());
        __mapChildren.put("UserTransaction", _package.component.connector.resourceAdapter.CciAdapter$ManagedConnection$Connection$UserTransaction.get_CLASS());
        }
    
    // Default constructor
    public CacheAdapter$ManagedConnection$Connection()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CacheAdapter$ManagedConnection$Connection(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        _addChild(new _package.component.connector.resourceAdapter.CciAdapter$ManagedConnection$Connection$ConnectionMetaData("ConnectionMetaData", this, true), "ConnectionMetaData");
        _addChild(new _package.component.connector.resourceAdapter.CciAdapter$ManagedConnection$Connection$ResultSetInfo("ResultSetInfo", this, true), "ResultSetInfo");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CacheAdapter$ManagedConnection$Connection();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/resourceAdapter/cciAdapter/CacheAdapter$ManagedConnection$Connection".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent();
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Declared at the super level
    public void close()
            throws javax.resource.ResourceException
        {
        super.close();
        
        setCacheService(null);
        }
    
    // Accessor for the property "CacheService"
    /**
    * Getter for property CacheService.<p>
    * CacheService assosiated with this Connection.
    */
    public com.tangosol.net.CacheService getCacheService()
        {
        return __m_CacheService;
        }
    
    // Accessor for the property "Concurrency"
    /**
    * Getter for property Concurrency.<p>
    * The default concurrency value used to create transactional caches.
    */
    public int getConcurrency()
        {
        return __m_Concurrency;
        }
    
    // Accessor for the property "Isolation"
    /**
    * Getter for property Isolation.<p>
    * The default transaction isolation value used to create transactional
    * caches.
    */
    public int getIsolation()
        {
        return __m_Isolation;
        }
    
    // Accessor for the property "Timeout"
    /**
    * Getter for property Timeout.<p>
    * The default transaction timeout value used to create transactional caches.
    */
    public int getTimeout()
        {
        return __m_Timeout;
        }
    
    // Accessor for the property "CacheService"
    /**
    * Setter for property CacheService.<p>
    * CacheService assosiated with this Connection.
    */
    public void setCacheService(com.tangosol.net.CacheService service)
        {
        __m_CacheService = service;
        }
    
    // Accessor for the property "Concurrency"
    /**
    * Setter for property Concurrency.<p>
    * The default concurrency value used to create transactional caches.
    */
    public void setConcurrency(int nConcurrency)
        {
        __m_Concurrency = nConcurrency;
        }
    
    // Accessor for the property "Isolation"
    /**
    * Setter for property Isolation.<p>
    * The default transaction isolation value used to create transactional
    * caches.
    */
    public void setIsolation(int nIsolation)
        {
        __m_Isolation = nIsolation;
        }
    
    // Accessor for the property "Timeout"
    /**
    * Setter for property Timeout.<p>
    * The default transaction timeout value used to create transactional caches.
    */
    public void setTimeout(int pTimeout)
        {
        __m_Timeout = pTimeout;
        }
    
    // Declared at the super level
    public String toString()
        {
        // import com.tangosol.net.CacheService;
        
        CacheService service = getCacheService();
        
        return super.toString() + ": CacheService{"
            + (service == null ? "none" :
                "name="   + service.getInfo().getServiceName() +
                ", type=" + service.getInfo().getServiceType())
            + '}';
        }
    }
