/* Class
*     _package.component.connector.resourceAdapter.cciAdapter.CacheAdapter
*/

package _package.component.connector.resourceAdapter.cciAdapter;

/*
* Integrates
*     com.tangosol.license.CoherenceEnterprise
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class CacheAdapter
        extends    _package.component.connector.resourceAdapter.CciAdapter
    {
    // Fields declarations
    private static com.tangosol.util.ListMap __mapChildren;
    
    // fields used by the integration model:
    private sink_CacheAdapter __sink;
    private com.tangosol.license.CoherenceEnterprise __feed;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("ConnectionFactory", CacheAdapter$ConnectionFactory.get_CLASS());
        __mapChildren.put("DefaultConnectionManager", _package.component.connector.ResourceAdapter$DefaultConnectionManager.get_CLASS());
        __mapChildren.put("ManagedConnection", CacheAdapter$ManagedConnection.get_CLASS());
        }
    
    // Default constructor
    public CacheAdapter()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CacheAdapter(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        _addChild(new CacheAdapter$AdapterMetaData("AdapterMetaData", this, true), "AdapterMetaData");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        if (get_Sink() == null)
            {
            jb_CacheAdapter.__tloPeer.setObject(this);
            new jb_CacheAdapter(this, false); // this sets the Sink which sets the Feed
            }
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CacheAdapter();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/resourceAdapter/cciAdapter/CacheAdapter".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    //++ com.tangosol.license.CoherenceEnterprise integration
    // Access optimization
    /**
    * Setter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Sink(Object pSink)
        {
        __sink = (sink_CacheAdapter) pSink;
        super.set_Sink(pSink);
        }
    /**
    * Setter for property _Feed.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Feed(Object pFeed)
        {
        __feed = (com.tangosol.license.CoherenceEnterprise) pFeed;
        super.set_Feed(pFeed);
        }
    // properties integration
    // methods integration
    public String getLicenseString()
        {
        return __sink.toString();
        }
    //-- com.tangosol.license.CoherenceEnterprise integration
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // Application server creates a ConnectionFactory by calling createConnectionFactory(...)
        // which creates a ConnectionFactory as a child component.
        // However,  WL 6.1 uses RMI (and therefore serialization) to pass that ConnectionFactory
        // instance around.
        
        super.onInit();
        
        if (!is_Deserialized())
            {
            log("\n" + getMetaData() + "\n");
            }
        
        // Integratee com.tangosol.license.CoherenceEnterprise
        // is not serializable
        set_Feed(null);
        set_Sink(null);
        }
    }
