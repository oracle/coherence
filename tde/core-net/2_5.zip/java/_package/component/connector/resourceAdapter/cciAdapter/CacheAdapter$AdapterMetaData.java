/* Class
*     _package.component.connector.resourceAdapter.cciAdapter.CacheAdapter$AdapterMetaData
*/

package _package.component.connector.resourceAdapter.cciAdapter;

public class CacheAdapter$AdapterMetaData
        extends    _package.component.connector.resourceAdapter.CciAdapter$AdapterMetaData
    {
    // Fields declarations
    
    // Default constructor
    public CacheAdapter$AdapterMetaData()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CacheAdapter$AdapterMetaData(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAdapterName("CoherenceTx");
            setAdapterShortDescription("Resource adapter for Tangosol Coherence(tm) clustered cache");
            setAdapterVendorName("Tangosol Inc.");
            setAdapterVersion("2.5 (build 36)");
            String[] a0 = new String[1];
                {
                a0[0] = "com.tangosol.run.xml.XmlSerializable";
                }
            setInteractionSpecsSupported(a0);
            setSpecVersion("1.0");
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant SupportsExecuteWithInputAndOutputRecord
    public boolean isSupportsExecuteWithInputAndOutputRecord()
        {
        return false;
        }
    
    // Getter for virtual constant SupportsExecuteWithInputRecordOnly
    public boolean isSupportsExecuteWithInputRecordOnly()
        {
        return true;
        }
    
    // Getter for virtual constant SupportsLocalTransactionDemarcation
    public boolean isSupportsLocalTransactionDemarcation()
        {
        return true;
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CacheAdapter$AdapterMetaData();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/resourceAdapter/cciAdapter/CacheAdapter$AdapterMetaData".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    }
