/* Class
*     _package.component.connector.resourceAdapter.CciAdapter$ManagedConnection
*/

package _package.component.connector.resourceAdapter;

import com.tangosol.util.SimpleEnumerator;
import java.util.Iterator;
import javax.resource.ResourceException;
import javax.resource.cci.Connection;
import javax.resource.spi.ConnectionRequestInfo;
import javax.resource.spi.LocalTransaction;
import javax.resource.spi.LocalTransactionException;
import javax.security.auth.Subject;

public abstract class CciAdapter$ManagedConnection
        extends    _package.component.connector.ResourceAdapter$ManagedConnection
    {
    // Fields declarations
    
    /**
    * Property ConnectionSet
    *
    */
    private transient java.util.Set __m_ConnectionSet;
    
    /**
    * Property CurrentTransaction
    *
    * ThreadLocal object holding a LocalTransaction associated with current
    * thread.
    */
    private transient ThreadLocal __m_CurrentTransaction;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Connection", CciAdapter$ManagedConnection$Connection.get_CLASS());
        __mapChildren.put("LocalTransaction", CciAdapter$ManagedConnection$LocalTransaction.get_CLASS());
        __mapChildren.put("XAResource", _package.component.connector.ResourceAdapter$ManagedConnection$XAResource.get_CLASS());
        }
    
    // Initializing constructor
    public CciAdapter$ManagedConnection(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/resourceAdapter/CciAdapter$ManagedConnection".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Declared at the super level
    public void associateConnection(Object connection)
            throws javax.resource.ResourceException
        {
        checkStatus();
        
        if (connection instanceof $Connection)
            {
            $Connection con = ($Connection) connection;
            con.associate(this);
            }
        else
            {
            throw new IllegalStateException("Invalid connection object: " + connection);
            }
        }
    
    // Declared at the super level
    public void cleanup()
            throws javax.resource.ResourceException
        {
        unregisterAllConnections();
        }
    
    // Declared at the super level
    public void destroy()
            throws javax.resource.ResourceException
        {
        unregisterAllConnections();
        }
    
    // Declared at the super level
    public Object getConnection(javax.security.auth.Subject subject, javax.resource.spi.ConnectionRequestInfo cxInfo)
            throws javax.resource.ResourceException
        {
        // import javax.security.auth.Subject;
        // import javax.resource.cci.Connection;
        // import javax.resource.spi.ConnectionRequestInfo;
        // import javax.resource.ResourceException;
        
        checkStatus();
        
        verifyAuthentication(subject, cxInfo);
        
        $Connection con = ($Connection) _newChild("Connection");
        registerConnection(con);
        
        return con;
        }
    
    // Accessor for the property "ConnectionSet"
    /**
    * Getter for property ConnectionSet.<p>
    */
    protected java.util.Set getConnectionSet()
        {
        return __m_ConnectionSet;
        }
    
    // Accessor for the property "CurrentTransaction"
    /**
    * Getter for property CurrentTransaction.<p>
    * ThreadLocal object holding a LocalTransaction associated with current
    * thread.
    */
    public ThreadLocal getCurrentTransaction()
        {
        return __m_CurrentTransaction;
        }
    
    // Declared at the super level
    public javax.resource.spi.LocalTransaction getLocalTransaction()
            throws javax.resource.ResourceException
        {
        // import javax.resource.spi.LocalTransaction;
        
        LocalTransaction txCurrent = (LocalTransaction) getCurrentTransaction().get();
        return txCurrent == null ? super.getLocalTransaction() : txCurrent;
        }
    
    // Declared at the super level
    /**
    * Checks whether or not this connection object matches to the specified
    * security info (subject) and connection request information (info)
    */
    public synchronized boolean matches(javax.security.auth.Subject subject, javax.resource.spi.ConnectionRequestInfo cxInfo)
        {
        // import javax.security.auth.Subject;
        // import javax.resource.spi.ConnectionRequestInfo;
        
        // Section 5.5.4 of JCA 1.0 specification states:
        // "To avoid any unexpected matching behavior, the application server
        // should not pass a ManagedConnection instance with existing connection
        // handles to the matchManagedConnections method as part of a candidate set"
        
        return getConnectionSet().isEmpty() ? super.matches(subject, cxInfo) : false;
        }
    
    public synchronized void registerConnection(javax.resource.cci.Connection con)
        {
        if (con instanceof $Connection)
            {
            (($Connection) con).setManagedConnection(this);
            }
        
        getConnectionSet().add(con);
        }
    
    /**
    * Register the transaction assosiated with the calling thread
    */
    public void registerTransaction(javax.resource.spi.LocalTransaction tx)
            throws javax.resource.ResourceException
        {
        // import javax.resource.spi.LocalTransaction;
        // import javax.resource.spi.LocalTransactionException;
        
        ThreadLocal      tlo       = getCurrentTransaction();
        LocalTransaction txCurrent = (LocalTransaction) tlo.get();
        
        if (txCurrent == null)
            {
            tlo.set(tx);
            }
        else if (tx != txCurrent)
            {
            throw new LocalTransactionException(
                "Register called with invalid transaction context: " + tx +
                "; current context: " + txCurrent);
            }
        }
    
    // Accessor for the property "ConnectionSet"
    /**
    * Setter for property ConnectionSet.<p>
    */
    protected void setConnectionSet(java.util.Set set)
        {
        __m_ConnectionSet = set;
        }
    
    // Accessor for the property "CurrentTransaction"
    /**
    * Setter for property CurrentTransaction.<p>
    * ThreadLocal object holding a LocalTransaction associated with current
    * thread.
    */
    protected void setCurrentTransaction(ThreadLocal tlo)
        {
        __m_CurrentTransaction = tlo;
        }
    
    protected void unregisterAllConnections()
        {
        // import com.tangosol.util.SimpleEnumerator;
        // import java.util.Iterator;
        // import javax.resource.cci.Connection;
        // import javax.resource.spi.LocalTransaction;
        
        ThreadLocal      tlo = getCurrentTransaction();
        LocalTransaction tx  = (LocalTransaction) tlo.get();
        
        if (tx != null)
            {
            log("]===> LocalTransaction is not completed: " + tx);
            tlo.set(null);
            }
        
        for (Iterator iter = new SimpleEnumerator(
                getConnectionSet().toArray()); iter.hasNext();)
            {
            unregisterConnection((Connection) iter.next());
            }
        }
    
    public synchronized void unregisterConnection(javax.resource.cci.Connection con)
        {
        getConnectionSet().remove(con);
        
        if (con instanceof $Connection)
            {
            (($Connection) con).setManagedConnection(null);
            }
        }
    
    /**
    * Register the transaction assosiated with the calling thread
    */
    public void unregisterTransaction(javax.resource.spi.LocalTransaction tx)
            throws javax.resource.ResourceException
        {
        // import javax.resource.spi.LocalTransaction;
        // import javax.resource.spi.LocalTransactionException;
        
        ThreadLocal      tlo       = getCurrentTransaction();
        LocalTransaction txCurrent = (LocalTransaction) tlo.get();
        if (txCurrent == tx)
            {
            tlo.set(null);
            }
        else if (txCurrent != null)
            {
            tlo.set(null);
            throw new LocalTransactionException(
                "Unregister called with invalid transaction context: " + tx +
                "; current context: " + txCurrent);
            }
        }
    
    /**
    * Verify the connection subject and info against this MC subject and info.
    * 
    * @see #getConnection
    */
    public void verifyAuthentication(javax.security.auth.Subject subject, javax.resource.spi.ConnectionRequestInfo cxInfo)
            throws javax.resource.ResourceException
        {
        }
    }
