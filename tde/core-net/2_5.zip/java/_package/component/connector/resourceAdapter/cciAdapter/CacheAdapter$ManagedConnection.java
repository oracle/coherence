/* Class
*     _package.component.connector.resourceAdapter.cciAdapter.CacheAdapter$ManagedConnection
*/

package _package.component.connector.resourceAdapter.cciAdapter;

import _package.component.connector.connectionInfo.CacheInfo;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.CacheService;
import com.tangosol.net.Cluster;
import javax.resource.NotSupportedException;
import javax.resource.ResourceException;
import javax.security.auth.Subject;

public class CacheAdapter$ManagedConnection
        extends    _package.component.connector.resourceAdapter.CciAdapter$ManagedConnection
    {
    // Fields declarations
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Connection", CacheAdapter$ManagedConnection$Connection.get_CLASS());
        __mapChildren.put("LocalTransaction", CacheAdapter$ManagedConnection$LocalTransaction.get_CLASS());
        }
    
    // Default constructor
    public CacheAdapter$ManagedConnection()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CacheAdapter$ManagedConnection(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setClosed(false);
            setConnectionSet(new java.util.HashSet());
            setCurrentTransaction(new java.lang.ThreadLocal());
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new CacheAdapter$ManagedConnection$ManagedConnectionMetaData("ManagedConnectionMetaData", this, true), "ManagedConnectionMetaData");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CacheAdapter$ManagedConnection();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/resourceAdapter/cciAdapter/CacheAdapter$ManagedConnection".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Declared at the super level
    /**
    * Check the connection subject and info.
    * 
    * @see ResourceAdapter#createManagedConnection
    */
    public void authenticate(javax.security.auth.Subject subject, javax.resource.spi.ConnectionRequestInfo cxInfo)
            throws javax.resource.ResourceException
        {
        // anything goes
        
        super.authenticate(subject, cxInfo);
        }
    
    // Declared at the super level
    public Object getConnection(javax.security.auth.Subject subject, javax.resource.spi.ConnectionRequestInfo cxInfo)
            throws javax.resource.ResourceException
        {
        // import Component.Connector.ConnectionInfo.CacheInfo;
        // import com.tangosol.net.CacheFactory;
        // import com.tangosol.net.CacheService;
        // import com.tangosol.net.Cluster;
        // import javax.security.auth.Subject;
        // import javax.resource.ResourceException;
        
        try
            {
            String sServiceName;
            String sServiceType;
            int    nConcur;
            int    nIsolation;
            int    nTimeout;
        
            if (cxInfo instanceof CacheInfo)
                {
                CacheInfo info = (CacheInfo) cxInfo;
                
                sServiceName = info.getServiceName();
                sServiceType = info.getServiceType();
                nConcur      = info.getConcurrency();
                nIsolation   = info.getIsolation();
                nTimeout     = info.getTimeout();
                }
            else
                {
                throw new IllegalArgumentException("Invalid ConnectionInfo: " + cxInfo);
                }
        
            Cluster      cluster = CacheFactory.ensureCluster();
            CacheService service = null;
        
            if (sServiceName == null && sServiceType == null)
                {
                // service agnostic; using ConfigurableCacheFactory
                }
            else
                {
                try
                    {
                    service = (CacheService) cluster.getService(sServiceName);
                    }
                catch (ClassCastException e)
                    {
                    throw new IllegalArgumentException("Not a CacheService: " +
                        sServiceName);
                    }
        
                if (service == null)
                    {
                    if (CacheService.TYPE_REPLICATED.equals(sServiceType))
                        {
                        service = CacheFactory.getReplicatedCacheService(sServiceName);
                        }
                    else if (CacheService.TYPE_DISTRIBUTED.equals(sServiceType))
                        {
                        service = CacheFactory.getDistributedCacheService(sServiceName);
                        }
        
                    if (service == null)
                        {
                        throw new IllegalArgumentException("Failed to find service: " +
                            sServiceName);
                        }
                    }
                else if (!service.getInfo().getServiceType().equals(sServiceType))
                    {
                    throw new IllegalArgumentException("Requested service type \"" +
                        sServiceType + "\", but the existing service has type \""  +
                        service.getInfo().getServiceType() + '"');
                    }
                }
        
            $Connection connect = ($Connection) super.getConnection(subject, cxInfo);
        
            connect.setCacheService(service);
            connect.setConcurrency(nConcur);
            connect.setIsolation(nIsolation);
            connect.setTimeout(nTimeout);
        
            return connect;
            }
        catch (Exception e)
            {
            log(e.toString());
            throw ensureResourceException(e);
            }
        }
    
    // Declared at the super level
    public javax.transaction.xa.XAResource getXAResource()
            throws javax.resource.ResourceException
        {
        // import javax.resource.NotSupportedException;
        
        throw new NotSupportedException(getMetaData().getEISProductName());
        }
    
    // Declared at the super level
    /**
    * Setter for property CurrentTransaction.<p>
    * ThreadLocal object holding a LocalTransaction associated with current
    * thread.
    */
    public void setCurrentTransaction(ThreadLocal tlo)
        {
        super.setCurrentTransaction(tlo);
        }
    
    // Declared at the super level
    /**
    * Verify the connection subject and info against this MC subject and info.
    * 
    * @see #getConnection
    */
    public void verifyAuthentication(javax.security.auth.Subject subject, javax.resource.spi.ConnectionRequestInfo cxInfo)
            throws javax.resource.ResourceException
        {
        // anything goes
        
        super.verifyAuthentication(subject, cxInfo);
        }
    }
