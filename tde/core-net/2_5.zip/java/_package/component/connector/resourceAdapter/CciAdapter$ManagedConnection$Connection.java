/* Class
*     _package.component.connector.resourceAdapter.CciAdapter$ManagedConnection$Connection
*/

package _package.component.connector.resourceAdapter;

import javax.resource.ResourceException;
import javax.resource.cci.ConnectionMetaData;
import javax.resource.cci.Interaction;
import javax.resource.cci.LocalTransaction;
import javax.resource.cci.ResultSetInfo;
import javax.resource.spi.ConnectionEvent;

public class CciAdapter$ManagedConnection$Connection
        extends    _package.component.Connector
        implements javax.resource.cci.Connection
    {
    // Fields declarations
    
    /**
    * Property ManagedConnection
    *
    */
    private CciAdapter$ManagedConnection __m_ManagedConnection;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Interaction", CciAdapter$ManagedConnection$Connection$Interaction.get_CLASS());
        __mapChildren.put("UserTransaction", CciAdapter$ManagedConnection$Connection$UserTransaction.get_CLASS());
        }
    
    // Default constructor
    public CciAdapter$ManagedConnection$Connection()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CciAdapter$ManagedConnection$Connection(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        _addChild(new CciAdapter$ManagedConnection$Connection$ConnectionMetaData("ConnectionMetaData", this, true), "ConnectionMetaData");
        _addChild(new CciAdapter$ManagedConnection$Connection$ResultSetInfo("ResultSetInfo", this, true), "ResultSetInfo");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CciAdapter$ManagedConnection$Connection();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/resourceAdapter/CciAdapter$ManagedConnection$Connection".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent();
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    public void associate(CciAdapter$ManagedConnection mc)
        {
        checkValid();
        
        // dissociate connection with current managed connection
        getManagedConnection().unregisterConnection(this);
        
        // associate connection with new managed connection
        mc.registerConnection(this);
        }
    
    protected void checkValid()
        {
        if (getManagedConnection() == null)
            {
            throw new IllegalStateException(get_Name() + " is invalid");
            }

        }
    
    // From interface: javax.resource.cci.Connection
    public void close()
            throws javax.resource.ResourceException
        {
        // import javax.resource.spi.ConnectionEvent;
        
        $ManagedConnection mc = getManagedConnection();
        if (mc != null)
            {
            mc.fireConnectionEvent(ConnectionEvent.CONNECTION_CLOSED, null, this);
            mc.unregisterConnection(this);
            }
        }
    
    // From interface: javax.resource.cci.Connection
    public javax.resource.cci.Interaction createInteraction()
            throws javax.resource.ResourceException
        {
        // import javax.resource.cci.Interaction;
        // import javax.resource.ResourceException;
        
        return (Interaction) _newChild("Interaction");
        }
    
    // From interface: javax.resource.cci.Connection
    public javax.resource.cci.LocalTransaction getLocalTransaction()
            throws javax.resource.ResourceException
        {
        // import javax.resource.cci.LocalTransaction;
        // import javax.resource.ResourceException;
        
        $UserTransaction tx = ($UserTransaction) _newChild("Transaction");
        
        tx.setManagedConnection(getManagedConnection());
        
        return tx;
        }
    
    // Accessor for the property "ManagedConnection"
    /**
    * Getter for property ManagedConnection.<p>
    */
    public CciAdapter$ManagedConnection getManagedConnection()
        {
        return __m_ManagedConnection;
        }
    
    // From interface: javax.resource.cci.Connection
    public javax.resource.cci.ConnectionMetaData getMetaData()
        {
        // import javax.resource.cci.ConnectionMetaData;
        // import javax.resource.ResourceException;
        
        return (ConnectionMetaData) _findChild("ConnectionMetaData");
        }
    
    // From interface: javax.resource.cci.Connection
    public javax.resource.cci.ResultSetInfo getResultSetInfo()
            throws javax.resource.ResourceException
        {
        // import javax.resource.cci.ResultSetInfo;
        // import javax.resource.ResourceException;
        
        return (ResultSetInfo) _findChild("ResultSetInfo");
        }
    
    // Accessor for the property "ManagedConnection"
    /**
    * Setter for property ManagedConnection.<p>
    */
    public void setManagedConnection(CciAdapter$ManagedConnection mc)
        {
        __m_ManagedConnection = mc;
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_Name() + "@" + hashCode();
        }
    }
