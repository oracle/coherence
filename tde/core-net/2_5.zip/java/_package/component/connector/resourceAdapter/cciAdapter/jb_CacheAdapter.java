/* Class
*      jb_CacheAdapter
*
* automatically generated "Feed" which
* a) extends an external bean:
*      com.tangosol.license.CoherenceEnterprise
* b) delegates to the peer component:
*      Component.Connector.ResourceAdapter.CciAdapter.CacheAdapter
*/

package _package.component.connector.resourceAdapter.cciAdapter;

public class jb_CacheAdapter
        extends    com.tangosol.license.CoherenceEnterprise
        implements com.tangosol.run.component.ComponentPeer
    {
    // thread local storage for component peer during
    // the integratee and component peer initialization
    static com.tangosol.util.ThreadLocalObject __tloPeer;
    static
        {
        __tloPeer = new com.tangosol.util.ThreadLocalObject();
        }
    
    // component peer (integrator) accessible from sub-classes
    protected CacheAdapter __peer;
    
    private static CacheAdapter __createPeer(Class clzPeer)
        {
        try
            {
            // create uninitialized component peer
            CacheAdapter peer = (CacheAdapter)
                com.tangosol.util.ClassHelper.newInstance
                    (clzPeer, new Object[] {null, null, Boolean.FALSE});
            
            // set-up the storage and return
            __tloPeer.setObject(peer);
            return peer;
            }
        catch (Exception e)
            {
            // catch everything and re-throw as a runtime exception
            throw new com.tangosol.run.component.IntegrationException(e.getMessage());
            }
        }
    
    // default (JavaBean) constructor
    public jb_CacheAdapter()
        {
        this(CacheAdapter.get_CLASS());
        }
    
    // the following constructor is used only by derived beans
    // to create the corresponding component peer and hook it up
    protected jb_CacheAdapter(Class clzPeer)
        {
        this(__createPeer(clzPeer), true);
        }
    
    // this (package private) constructor is used by both:
    // the component peer to hook up (fInit set to false)
    // and default Javabean constructor (fInit set to true)
    jb_CacheAdapter(CacheAdapter peer, boolean fInit)
        {
        super();
        
        if (__retrievePeer() != peer)
            {
            throw new com.tangosol.run.component.IntegrationException("Invalid peer component");
            }
        if (fInit)
            {
            peer.__init();
            }
        }
    
    private CacheAdapter __retrievePeer()
        {
        if (__peer == null)
            {
            // first call -- the peer must be in the thread local storage
            __peer = (CacheAdapter) __tloPeer.getObject();
            
            // clean-up the storage
            __tloPeer.setObject(null);
            
            // create the sink and notify the component peer
            __peer.set_Sink(new sink_CacheAdapter(this));
            }
        return __peer;
        }
    
    // methods integration and/or remoted
    public String toString()
        {
        CacheAdapter peer = __peer;
        if (peer == null) peer = __retrievePeer();
        return peer.getLicenseString();
        }
    String super$toString()
        {
        return super.toString();
        }
    
    // interface com.tangosol.run.component.ComponentPeer
    public Object get_ComponentPeer()
        {
        return __retrievePeer();
        }
    }
