/* Class
*     _package.component.connector.resourceAdapter.CciAdapter$ConnectionFactory
*/

package _package.component.connector.resourceAdapter;

import javax.resource.ResourceException;
import javax.resource.cci.Connection;
import javax.resource.cci.ConnectionSpec;
import javax.resource.cci.RecordFactory;
import javax.resource.cci.ResourceAdapterMetaData;
import javax.resource.spi.ConnectionManager;
import javax.resource.spi.ConnectionRequestInfo;
import javax.resource.spi.ManagedConnectionFactory;

public abstract class CciAdapter$ConnectionFactory
        extends    _package.component.connector.ResourceAdapter$ConnectionFactory
        implements javax.resource.cci.ConnectionFactory
    {
    // Fields declarations
    
    /**
    * Property Reference
    *
    */
    private javax.naming.Reference __m_Reference;
    
    // Initializing constructor
    public CciAdapter$ConnectionFactory(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/resourceAdapter/CciAdapter$ConnectionFactory".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // From interface: javax.resource.cci.ConnectionFactory
    public javax.resource.cci.Connection getConnection()
            throws javax.resource.ResourceException
        {
        return getConnection(null);
        }
    
    // From interface: javax.resource.cci.ConnectionFactory
    public javax.resource.cci.Connection getConnection(javax.resource.cci.ConnectionSpec properties)
            throws javax.resource.ResourceException
        {
        // import javax.resource.cci.Connection;
        // import javax.resource.spi.ConnectionManager;
        // import javax.resource.spi.ConnectionRequestInfo;
        // import javax.resource.cci.ConnectionSpec;
        // import javax.resource.spi.ManagedConnectionFactory;
        // import javax.resource.ResourceException;
        
        ManagedConnectionFactory mcf  = getManagedConnectionFactory();
        ConnectionRequestInfo    info = translateConnectionSpec(properties);
        ConnectionManager        mgr  = getConnectionManager();
        Object                   conn = mgr.allocateConnection(mcf, info);
        
        if (conn instanceof Connection)
            {
            return (Connection) conn;
            }
        
        // WL 6.1 may return a proxy class "$Proxy75" causing the ClassCastException
        throw new ResourceException(
            "allocateConnection() returned an invalid class: " + conn.getClass().getName() +
            "\nConnectionManager=" + mgr +
            "\nManagedConnectionFactory=" + mcf +
            "\nConnectionRequestInfo=" + info +
            "\nconnection=" + conn);
        }
    
    // From interface: javax.resource.cci.ConnectionFactory
    public javax.resource.cci.ResourceAdapterMetaData getMetaData()
        {
        // import javax.resource.cci.ResourceAdapterMetaData;
        
        $Module adapter = ($Module) get_Module();
        return (ResourceAdapterMetaData) adapter.getMetaData();

        }
    
    // From interface: javax.resource.cci.ConnectionFactory
    public javax.resource.cci.RecordFactory getRecordFactory()
            throws javax.resource.ResourceException
        {
        // import javax.resource.cci.RecordFactory;
        // import javax.resource.ResourceException;
        
        return ($RecordFactory) _findChild("RecordFactory");

        }
    
    // From interface: javax.resource.cci.ConnectionFactory
    // Accessor for the property "Reference"
    /**
    * Getter for property Reference.<p>
    */
    public javax.naming.Reference getReference()
            throws javax.naming.NamingException
        {
        return __m_Reference;
        }
    
    // From interface: javax.resource.cci.ConnectionFactory
    // Accessor for the property "Reference"
    /**
    * Setter for property Reference.<p>
    */
    public void setReference(javax.naming.Reference reference)
        {
        __m_Reference = reference;
        }
    
    public javax.resource.spi.ConnectionRequestInfo translateConnectionSpec(javax.resource.cci.ConnectionSpec properties)
        {
        return null;
        }
    }
