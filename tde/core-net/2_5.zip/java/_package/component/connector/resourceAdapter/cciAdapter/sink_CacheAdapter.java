/* Class
*      sink_CacheAdapter
*
* automatically generated "Sink" which
* represents a footprint of the class
*      com.tangosol.license.CoherenceEnterprise
* when used as a component callback by 
*      Component.Connector.ResourceAdapter.CciAdapter.CacheAdapter
*/

package _package.component.connector.resourceAdapter.cciAdapter;

public class sink_CacheAdapter
       extends com.tangosol.run.component.CallbackSink
    {
    private jb_CacheAdapter __peer;
    
    // this default (protected) constructor is used by sinks that extend this one
    protected sink_CacheAdapter()
        {
        }
    
    // this (protected) constructor is used by the feed
    protected sink_CacheAdapter(jb_CacheAdapter feed)
        {
        super();
        __peer = feed;
        }
    
    // Retrieves the feed object for this sink
    public Object get_Feed()
        {
        return __peer;
        }
    
    // methods integrated and/or remoted
    public String toString()
        {
        return __peer.super$toString();
        }
    }
