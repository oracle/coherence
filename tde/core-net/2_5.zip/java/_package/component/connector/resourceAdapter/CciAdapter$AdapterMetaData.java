/* Class
*     _package.component.connector.resourceAdapter.CciAdapter$AdapterMetaData
*/

package _package.component.connector.resourceAdapter;

public class CciAdapter$AdapterMetaData
        extends    _package.component.Data
        implements javax.resource.cci.ResourceAdapterMetaData
    {
    // Fields declarations
    
    /**
    * Property AdapterName
    *
    */
    private String __m_AdapterName;
    
    /**
    * Property AdapterShortDescription
    *
    */
    private String __m_AdapterShortDescription;
    
    /**
    * Property AdapterVendorName
    *
    */
    private String __m_AdapterVendorName;
    
    /**
    * Property AdapterVersion
    *
    */
    private String __m_AdapterVersion;
    
    /**
    * Property InteractionSpecsSupported
    *
    */
    private String[] __m_InteractionSpecsSupported;
    
    /**
    * Property SpecVersion
    *
    */
    private String __m_SpecVersion;
    
    /**
    * Property SupportsExecuteWithInputAndOutputRecord
    *
    */
    
    /**
    * Property SupportsExecuteWithInputRecordOnly
    *
    */
    
    /**
    * Property SupportsLocalTransactionDemarcation
    *
    */
    
    // Default constructor
    public CciAdapter$AdapterMetaData()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CciAdapter$AdapterMetaData(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant SupportsExecuteWithInputAndOutputRecord
    public boolean isSupportsExecuteWithInputAndOutputRecord()
        {
        return false;
        }
    
    // Getter for virtual constant SupportsExecuteWithInputRecordOnly
    public boolean isSupportsExecuteWithInputRecordOnly()
        {
        return false;
        }
    
    // Getter for virtual constant SupportsLocalTransactionDemarcation
    public boolean isSupportsLocalTransactionDemarcation()
        {
        return false;
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CciAdapter$AdapterMetaData();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/resourceAdapter/CciAdapter$AdapterMetaData".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof $AdapterMetaData)
            {
            $AdapterMetaData that = ($AdapterMetaData) obj;
        
            return this == that
                || this.getAdapterName()   .equals(that.getAdapterName())
                && this.getAdapterVersion().equals(that.getAdapterVersion());
            }
        return false;
        }
    
    // From interface: javax.resource.cci.ResourceAdapterMetaData
    // Accessor for the property "AdapterName"
    /**
    * Getter for property AdapterName.<p>
    */
    public String getAdapterName()
        {
        return __m_AdapterName;
        }
    
    // From interface: javax.resource.cci.ResourceAdapterMetaData
    // Accessor for the property "AdapterShortDescription"
    /**
    * Getter for property AdapterShortDescription.<p>
    */
    public String getAdapterShortDescription()
        {
        return __m_AdapterShortDescription;
        }
    
    // From interface: javax.resource.cci.ResourceAdapterMetaData
    // Accessor for the property "AdapterVendorName"
    /**
    * Getter for property AdapterVendorName.<p>
    */
    public String getAdapterVendorName()
        {
        return __m_AdapterVendorName;
        }
    
    // From interface: javax.resource.cci.ResourceAdapterMetaData
    // Accessor for the property "AdapterVersion"
    /**
    * Getter for property AdapterVersion.<p>
    */
    public String getAdapterVersion()
        {
        return __m_AdapterVersion;
        }
    
    // From interface: javax.resource.cci.ResourceAdapterMetaData
    // Accessor for the property "InteractionSpecsSupported"
    /**
    * Getter for property InteractionSpecsSupported.<p>
    */
    public String[] getInteractionSpecsSupported()
        {
        return __m_InteractionSpecsSupported;
        }
    
    // Accessor for the property "InteractionSpecsSupported"
    /**
    * Getter for property InteractionSpecsSupported.<p>
    */
    public String getInteractionSpecsSupported(int pIndex)
        {
        return getInteractionSpecsSupported()[pIndex];
        }
    
    // From interface: javax.resource.cci.ResourceAdapterMetaData
    // Accessor for the property "SpecVersion"
    /**
    * Getter for property SpecVersion.<p>
    */
    public String getSpecVersion()
        {
        return __m_SpecVersion;
        }
    
    // Declared at the super level
    public int hashCode()
        {
        return getAdapterName().hashCode() + getAdapterVersion().hashCode();
        }
    
    // Accessor for the property "AdapterName"
    /**
    * Setter for property AdapterName.<p>
    */
    public void setAdapterName(String pAdapterName)
        {
        __m_AdapterName = pAdapterName;
        }
    
    // Accessor for the property "AdapterShortDescription"
    /**
    * Setter for property AdapterShortDescription.<p>
    */
    public void setAdapterShortDescription(String pAdapterShortDescription)
        {
        __m_AdapterShortDescription = pAdapterShortDescription;
        }
    
    // Accessor for the property "AdapterVendorName"
    /**
    * Setter for property AdapterVendorName.<p>
    */
    public void setAdapterVendorName(String pAdapterVendorName)
        {
        __m_AdapterVendorName = pAdapterVendorName;
        }
    
    // Accessor for the property "AdapterVersion"
    /**
    * Setter for property AdapterVersion.<p>
    */
    public void setAdapterVersion(String pAdapterVersion)
        {
        __m_AdapterVersion = pAdapterVersion;
        }
    
    // Accessor for the property "InteractionSpecsSupported"
    /**
    * Setter for property InteractionSpecsSupported.<p>
    */
    public void setInteractionSpecsSupported(String[] pInteractionSpecsSupported)
        {
        __m_InteractionSpecsSupported = pInteractionSpecsSupported;
        }
    
    // Accessor for the property "InteractionSpecsSupported"
    /**
    * Setter for property InteractionSpecsSupported.<p>
    */
    public void setInteractionSpecsSupported(int pIndex, String pInteractionSpecsSupported)
        {
        getInteractionSpecsSupported()[pIndex] = pInteractionSpecsSupported;
        }
    
    // Accessor for the property "SpecVersion"
    /**
    * Setter for property SpecVersion.<p>
    */
    public void setSpecVersion(String pSpecVersion)
        {
        __m_SpecVersion = pSpecVersion;
        }
    
    // From interface: javax.resource.cci.ResourceAdapterMetaData
    public boolean supportsExecuteWithInputAndOutputRecord()
        {
        return isSupportsExecuteWithInputAndOutputRecord();
        }
    
    // From interface: javax.resource.cci.ResourceAdapterMetaData
    public boolean supportsExecuteWithInputRecordOnly()
        {
        return isSupportsExecuteWithInputRecordOnly();
        }
    
    // From interface: javax.resource.cci.ResourceAdapterMetaData
    public boolean supportsLocalTransactionDemarcation()
        {
        return isSupportsLocalTransactionDemarcation();
        }
    
    // Declared at the super level
    public String toString()
        {
        StringBuffer sb = new StringBuffer();
        
        sb.append("ResourceAdapter=")
          .append(getAdapterName())
          .append(" (")
          .append(getAdapterShortDescription())
          .append("), version=")
          .append(getAdapterVersion())
          .append(", vendor=")
          .append(getAdapterVendorName())
          ;
        
        return sb.toString();
        }
    }
