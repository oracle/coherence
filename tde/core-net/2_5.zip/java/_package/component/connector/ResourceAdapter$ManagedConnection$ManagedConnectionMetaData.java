/* Class
*     _package.component.connector.ResourceAdapter$ManagedConnection$ManagedConnectionMetaData
*/

package _package.component.connector;

import _package.component.connector.ConnectionInfo;
import javax.resource.ResourceException;
import javax.resource.spi.ConnectionRequestInfo;

public class ResourceAdapter$ManagedConnection$ManagedConnectionMetaData
        extends    _package.component.Data
        implements javax.resource.spi.ManagedConnectionMetaData
    {
    // Fields declarations
    
    /**
    * Property EISProductName
    *
    */
    private String __m_EISProductName;
    
    /**
    * Property EISProductVersion
    *
    */
    private String __m_EISProductVersion;
    
    /**
    * Property MaxConnections
    *
    */
    private int __m_MaxConnections;
    
    /**
    * Property UserName
    *
    */
    
    // Default constructor
    public ResourceAdapter$ManagedConnection$ManagedConnectionMetaData()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ResourceAdapter$ManagedConnection$ManagedConnectionMetaData(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ResourceAdapter$ManagedConnection$ManagedConnectionMetaData();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/ResourceAdapter$ManagedConnection$ManagedConnectionMetaData".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent().get_Parent();
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof $ManagedConnectionMetaData)
            {
            $ManagedConnectionMetaData that = ($ManagedConnectionMetaData) obj;
            
            return getEISProductName()   .equals(that.getEISProductName()) &&
                   getEISProductVersion().equals(that.getEISProductVersion());
            }
        return false;
        }
    
    // From interface: javax.resource.spi.ManagedConnectionMetaData
    // Accessor for the property "EISProductName"
    /**
    * Getter for property EISProductName.<p>
    */
    public String getEISProductName()
        {
        return __m_EISProductName;
        }
    
    // From interface: javax.resource.spi.ManagedConnectionMetaData
    // Accessor for the property "EISProductVersion"
    /**
    * Getter for property EISProductVersion.<p>
    */
    public String getEISProductVersion()
        {
        return __m_EISProductVersion;
        }
    
    // From interface: javax.resource.spi.ManagedConnectionMetaData
    // Accessor for the property "MaxConnections"
    /**
    * Getter for property MaxConnections.<p>
    */
    public int getMaxConnections()
            throws javax.resource.ResourceException
        {
        return __m_MaxConnections;
        }
    
    // From interface: javax.resource.spi.ManagedConnectionMetaData
    // Accessor for the property "UserName"
    /**
    * Getter for property UserName.<p>
    */
    public String getUserName()
            throws javax.resource.ResourceException
        {
        // import Component.Connector.ConnectionInfo;
        // import javax.resource.spi.ConnectionRequestInfo;
        // import javax.resource.ResourceException;
        
        $ManagedConnection mc = ($ManagedConnection) get_Parent();
        
        if (mc.isClosed())
            {
            throw new ResourceException("ManagedConnection has been destroyed");
            }
        
        ConnectionRequestInfo cxInfo = mc.getConnectionInfo();
        return cxInfo instanceof ConnectionInfo ?
            ((ConnectionInfo) cxInfo).getUserName() : null;
        
        

        }
    
    // Declared at the super level
    public int hashCode()
        {
        return getEISProductName().hashCode() + getEISProductVersion().hashCode();
        }
    
    // Accessor for the property "EISProductName"
    /**
    * Setter for property EISProductName.<p>
    */
    public void setEISProductName(String pEISProductName)
        {
        __m_EISProductName = pEISProductName;
        }
    
    // Accessor for the property "EISProductVersion"
    /**
    * Setter for property EISProductVersion.<p>
    */
    public void setEISProductVersion(String pEISProductVersion)
        {
        __m_EISProductVersion = pEISProductVersion;
        }
    
    // Accessor for the property "MaxConnections"
    /**
    * Setter for property MaxConnections.<p>
    */
    public void setMaxConnections(int pMaxConnections)
        {
        __m_MaxConnections = pMaxConnections;
        }
    }
