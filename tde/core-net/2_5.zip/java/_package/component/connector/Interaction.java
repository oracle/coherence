/* Class
*     _package.component.connector.Interaction
*/

package _package.component.connector;

import javax.resource.NotSupportedException;
import javax.resource.ResourceException;
import javax.resource.cci.ResourceWarning;

public class Interaction
        extends    _package.component.Connector
        implements javax.resource.cci.Interaction
    {
    // Fields declarations
    
    /**
    * Property Connection
    *
    */
    
    /**
    * Property Warnings
    *
    */
    private transient javax.resource.cci.ResourceWarning __m_Warnings;
    
    // Default constructor
    public Interaction()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Interaction(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Interaction();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/connector/Interaction".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: javax.resource.cci.Interaction
    public void clearWarnings()
            throws javax.resource.ResourceException
        {
        setWarnings(null);
        }
    
    // From interface: javax.resource.cci.Interaction
    public void close()
            throws javax.resource.ResourceException
        {
        }
    
    // From interface: javax.resource.cci.Interaction
    public javax.resource.cci.Record execute(javax.resource.cci.InteractionSpec ispec, javax.resource.cci.Record input)
            throws javax.resource.ResourceException
        {
        // import javax.resource.NotSupportedException;
        
        throw new NotSupportedException("execute(ispec=" + ispec + ", input=" + input + ')');
        }
    
    // From interface: javax.resource.cci.Interaction
    public boolean execute(javax.resource.cci.InteractionSpec ispec, javax.resource.cci.Record input, javax.resource.cci.Record output)
            throws javax.resource.ResourceException
        {
        // import javax.resource.NotSupportedException;
        
        throw new NotSupportedException("execute(ispec=" + ispec + ", input=" + input +
            ", output=" + output + ')');
        }
    
    // From interface: javax.resource.cci.Interaction
    // Accessor for the property "Connection"
    /**
    * Getter for property Connection.<p>
    */
    public javax.resource.cci.Connection getConnection()
        {
        return null;
        }
    
    // From interface: javax.resource.cci.Interaction
    // Accessor for the property "Warnings"
    /**
    * Getter for property Warnings.<p>
    */
    public javax.resource.cci.ResourceWarning getWarnings()
            throws javax.resource.ResourceException
        {
        return __m_Warnings;
        }
    
    // Accessor for the property "Warnings"
    /**
    * Setter for property Warnings.<p>
    */
    public void setWarnings(javax.resource.cci.ResourceWarning warning)
        {
        // import javax.resource.cci.ResourceWarning;
        // import javax.resource.ResourceException;
        
        if (warning != null)
            {
            try
                {
                ResourceWarning warningOrig = getWarnings();
                if (warningOrig != null)
                    {
                    warningOrig.setLinkedWarning(warning);
                    return;
                    }
                }
            catch (ResourceException e) {}
            }
        
        __m_Warnings = (warning);

        }
    }
