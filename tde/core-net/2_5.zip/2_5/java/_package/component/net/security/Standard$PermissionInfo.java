/* Class
*     _package.component.net.security.Standard$PermissionInfo
*/

package _package.component.net.security;

import com.tangosol.util.ExternalizableHelper;
import com.tangosol.util.NullImplementation;
import java.security.SignedObject;
import java.util.HashSet;
import java.util.Set;
import javax.security.auth.Subject;

/**
* Serializable permission request/response info.
*/
public class Standard$PermissionInfo
        extends    _package.component.Util
        implements java.io.Externalizable
    {
    // Fields declarations
    
    /**
    * Property Permission
    *
    * Transient (not encrypted) ClusterPermission object.
    */
    private transient com.tangosol.net.ClusterPermission __m_Permission;
    
    /**
    * Property ServiceName
    *
    * Not encrypted service name.
    */
    private String __m_ServiceName;
    
    /**
    * Property SignedPermission
    *
    * Encrypted ClusterPermission object.
    */
    private java.security.SignedObject __m_SignedPermission;
    
    /**
    * Property Subject
    *
    * The encryptor subject.
    */
    private javax.security.auth.Subject __m_Subject;
    
    // Default constructor
    public Standard$PermissionInfo()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Standard$PermissionInfo(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Standard$PermissionInfo();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/security/Standard$PermissionInfo".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Accessor for the property "Permission"
    /**
    * Getter for property Permission.<p>
    * Transient (not encrypted) ClusterPermission object.
    */
    public com.tangosol.net.ClusterPermission getPermission()
        {
        return __m_Permission;
        }
    
    // Accessor for the property "ServiceName"
    /**
    * Getter for property ServiceName.<p>
    * Not encrypted service name.
    */
    public String getServiceName()
        {
        return __m_ServiceName;
        }
    
    // Accessor for the property "SignedPermission"
    /**
    * Getter for property SignedPermission.<p>
    * Encrypted ClusterPermission object.
    */
    public java.security.SignedObject getSignedPermission()
        {
        return __m_SignedPermission;
        }
    
    // Accessor for the property "Subject"
    /**
    * Getter for property Subject.<p>
    * The encryptor subject.
    */
    public javax.security.auth.Subject getSubject()
        {
        return __m_Subject;
        }
    
    // From interface: java.io.Externalizable
    public void readExternal(java.io.ObjectInput in)
            throws java.io.IOException,
                   java.lang.ClassNotFoundException
        {
        // import com.tangosol.util.ExternalizableHelper;
        // import com.tangosol.util.NullImplementation;
        // import java.security.SignedObject;
        // import java.util.HashSet;
        // import java.util.Set;
        // import javax.security.auth.Subject;
        
        setServiceName(in.readUTF());
        setSignedPermission((SignedObject) in.readObject());
        
        if (in.readBoolean())
            {
            Set setPrincipals  = new HashSet();
            Set setCredentials = new HashSet();
        
            ExternalizableHelper.readCollection(in, setPrincipals, null);
            ExternalizableHelper.readCollection(in, setCredentials, null);
        
            setSubject(new Subject(true, setPrincipals, setCredentials, NullImplementation.getSet()));
            }
        }
    
    // Accessor for the property "Permission"
    /**
    * Setter for property Permission.<p>
    * Transient (not encrypted) ClusterPermission object.
    */
    public void setPermission(com.tangosol.net.ClusterPermission permission)
        {
        __m_Permission = permission;
        }
    
    // Accessor for the property "ServiceName"
    /**
    * Setter for property ServiceName.<p>
    * Not encrypted service name.
    */
    public void setServiceName(String sName)
        {
        __m_ServiceName = sName;
        }
    
    // Accessor for the property "SignedPermission"
    /**
    * Setter for property SignedPermission.<p>
    * Encrypted ClusterPermission object.
    */
    public void setSignedPermission(java.security.SignedObject so)
        {
        __m_SignedPermission = so;
        }
    
    // Accessor for the property "Subject"
    /**
    * Setter for property Subject.<p>
    * The encryptor subject.
    */
    public void setSubject(javax.security.auth.Subject set)
        {
        __m_Subject = set;
        }
    
    // From interface: java.io.Externalizable
    public void writeExternal(java.io.ObjectOutput out)
            throws java.io.IOException
        {
        // import com.tangosol.util.ExternalizableHelper;
        // import javax.security.auth.Subject;
        
        // The reason to implement the Externalizable interface is to
        // offset the fact the Subject's standard serialization drops
        // the public credentials and serializes the "read-only" flag
        
        out.writeUTF(getServiceName());
        out.writeObject(getSignedPermission());
        
        Subject subject = getSubject();
        if (subject == null)
            {
            out.writeBoolean(false);
            }
        else
            {
            out.writeBoolean(true);
            ExternalizableHelper.writeCollection(out, subject.getPrincipals());
            ExternalizableHelper.writeCollection(out, subject.getPublicCredentials());
            }
        }
    }
