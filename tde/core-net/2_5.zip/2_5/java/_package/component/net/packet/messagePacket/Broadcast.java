/* Class
*     _package.component.net.packet.messagePacket.Broadcast
*/

package _package.component.net.packet.messagePacket;

import com.tangosol.util.Base;
import java.sql.Time;

public class Broadcast
        extends    _package.component.net.packet.MessagePacket
    {
    // Fields declarations
    
    // Default constructor
    public Broadcast()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Broadcast(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setMessagePartCount(1);
            setMessagePartIndex(0);
            setPacketType(232718546);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    // Getter for virtual constant OutgoingBroadcast
    public boolean isOutgoingBroadcast()
        {
        return true;
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Broadcast();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/packet/messagePacket/Broadcast".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Getter for property Description.<p>
    * Human-readable description of attributes added to the sub-class of
    * Packet; used by toString for debugging purposes.
    */
    public String getDescription()
        {
        // import com.tangosol.util.Base;
        // import java.sql.Time;
        
        StringBuffer sb = new StringBuffer();
        
        sb.append("MessageType=")
          .append(getMessageType())
          .append(", MessagePartCount=")
          .append(getMessagePartCount())
          .append(", MessagePartIndex=")
          .append(getMessagePartIndex())
          .append(", Body=");
        
        byte[] ab = getBody();
        if (ab == null)
            {
            sb.append("null");
            }
        else
            {
            sb.append(Base.toHexEscape(ab))
              .append(", Body.length=")
              .append(ab.length);
            }
        
        return sb.toString();
        }
    
    // Declared at the super level
    /**
    * Read the Packet (not counting the Packet type id) from a Stream.
    * 
    * Note: The read method is not responsible for configuring the "To" portion
    * of the packet.
    * 
    * @param stream  the DataInputStream to read from
    * @param nMemberId  this Member's id if known, otherwise zero
    */
    public void read(java.io.DataInputStream stream, int nMemberId)
            throws java.io.IOException
        {
        setFromId(stream.readUnsignedShort());
        setMessageType(stream.readShort());
        readBody(stream);
        }
    
    // Declared at the super level
    /**
    * Write the Packet to a Stream.
    * 
    * @param stream  the DataOutputStream to write to
    * @param nMemberId  if non-zero, it indicates that the Packet should be
    * addressed only to one member
    */
    public void write(java.io.DataOutputStream stream, _package.component.net.MemberSet setTo)
            throws java.io.IOException
        {
        stream.writeInt(TYPE_BROADCAST);
        stream.writeShort(getFromId());
        stream.writeShort(getMessageType());
        writeBody(stream);
        }
    }
