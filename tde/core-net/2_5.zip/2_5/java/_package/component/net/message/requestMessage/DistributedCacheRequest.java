/* Class
*     _package.component.net.message.requestMessage.DistributedCacheRequest
*/

package _package.component.net.message.requestMessage;

import _package.component.util.DaemonPool;
import com.tangosol.util.ExternalizableHelper;

public class DistributedCacheRequest
        extends    _package.component.net.message.RequestMessage
        implements java.lang.Runnable
    {
    // Fields declarations
    
    /**
    * Property CacheId
    *
    * The Id of the cache this request is for.
    */
    private long __m_CacheId;
    
    /**
    * Property Exception
    *
    * An IOException that occured during the read() and had to be deferred to
    * be processed during onReceived() ans possibly reported back to the client
    * (requestor).
    */
    private transient java.io.IOException __m_Exception;
    
    // Default constructor
    public DistributedCacheRequest()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public DistributedCacheRequest(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        _addChild(new DistributedCacheRequest$Poll("Poll", this, true), "Poll");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new DistributedCacheRequest();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/message/requestMessage/DistributedCacheRequest".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Instantiate a copy of this message. This is quite different from the
    * standard "clone" since only the "transmittable" portion of the message
    * (and none of the internal) state should be cloned.
    */
    public _package.component.net.Message cloneMessage()
        {
        $Module msg = ($Module) super.cloneMessage();
        
        msg.setCacheId(getCacheId());
        
        return msg;
        }
    
    // Accessor for the property "CacheId"
    /**
    * Getter for property CacheId.<p>
    * The Id of the cache this request is for.
    */
    public long getCacheId()
        {
        return __m_CacheId;
        }
    
    // Accessor for the property "Exception"
    /**
    * Getter for property Exception.<p>
    * An IOException that occured during the read() and had to be deferred to
    * be processed during onReceived() ans possibly reported back to the client
    * (requestor).
    */
    public java.io.IOException getException()
        {
        return __m_Exception;
        }
    
    // Declared at the super level
    /**
    * This is the event that is executed when a Message is received.
    * <p>
    * It is the main processing event of the Message called by the
    * <code>Service.onMessage()</code> event. With regards to the use of
    * Message components within clustered Services, Services are designed by
    * dragging Message components into them as static children. These Messages
    * are the components that a Service can send to other running instances of
    * the same Service within a cluster. When the onReceived event is invoked
    * by a Service, it means that the Message has been received; the code in
    * the onReceived event is therefore the Message specific logic for
    * processing a received Message. For example, when onReceived is invoked on
    * a Message named FindData, the onReceived event should do the work to
    * "find the data", because it is being invoked by the Service that received
    * the "find the data" Message.
    */
    public void onReceived()
        {
        // import Component.Util.DaemonPool;
        
        super.onReceived();
        
        DaemonPool pool = getService().getDaemonPool();
        if (pool.isStarted())
            {
            pool.add(this);
            }
        else
            {
            run();
            }
        }
    
    // Declared at the super level
    public void read(java.io.DataInputStream stream)
            throws java.io.IOException
        {
        // import com.tangosol.util.ExternalizableHelper;
        
        setCacheId(ExternalizableHelper.readLong(stream));
        }
    
    // From interface: java.lang.Runnable
    public void run()
        {
        throw new UnsupportedOperationException();
        }
    
    // Accessor for the property "CacheId"
    /**
    * Setter for property CacheId.<p>
    * The Id of the cache this request is for.
    */
    public void setCacheId(long lCacheId)
        {
        __m_CacheId = lCacheId;
        }
    
    // Accessor for the property "Exception"
    /**
    * Setter for property Exception.<p>
    * An IOException that occured during the read() and had to be deferred to
    * be processed during onReceived() ans possibly reported back to the client
    * (requestor).
    */
    public void setException(java.io.IOException exception)
        {
        __m_Exception = exception;
        }
    
    // Declared at the super level
    public void write(java.io.DataOutputStream stream)
            throws java.io.IOException
        {
        // import com.tangosol.util.ExternalizableHelper;
        
        ExternalizableHelper.writeLong(stream, getCacheId());
        }
    }
