/* Class
*     _package.component.net.message.RequestMessage
*/

package _package.component.net.message;

import _package.component.net.Packet;
import _package.component.net.Poll;
import com.tangosol.util.Base;
import java.util.Iterator;
import java.util.Map;

/**
* <p>
* A RequestMessage extends the generic Message and adds the capability to poll
* one or more Members for responses. In the simplest case, the RequestMessage
* with one destination Member implements the request/response model.
*/
public class RequestMessage
        extends    _package.component.net.Message
    {
    // Fields declarations
    
    /**
    * Property FromPollId
    *
    * The PollId that this Message is a request for.
    */
    private long __m_FromPollId;
    
    /**
    * Property RequestPoll
    *
    * This is the Poll that the RequestMessage creates to collect responses.
    */
    private _package.component.net.Poll __m_RequestPoll;
    
    // Default constructor
    public RequestMessage()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public RequestMessage(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new RequestMessage();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/message/RequestMessage".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Add a child component with the specified name to this component.
    * 
    * @param child  a component to add ti this component as a child
    * @param name  a [unique] name to identify this child. If the name is not
    * specified (null is passed) then a unique child name will be automatically
    * assigned
    * 
    * Note: this method fires onAdd() notification only if the parent (this
    * component) has already been fully constructed.
    * Note2: component containment/aggregation produces children initialization
    * code (see __init()) that is executed while the parent is not flagged as
    * _Constructed yet
    */
    public void _addChild(_package.Component child, String name)
        {
        // import Component.Net.Poll;
        
        super._addChild(child, name);
        
        if (child instanceof Poll && getRequestPoll() == null)
            {
            setRequestPoll((Poll) child);
            }

        }
    
    public _package.component.net.Poll ensureRequestPoll()
        {
        // import Component.Net.Poll;
        
        Poll poll = getRequestPoll();
        
        if (poll == null)
            {
            setRequestPoll(poll = instantiatePoll());
            }
        
        return poll;
        }
    
    // Accessor for the property "FromPollId"
    /**
    * Getter for property FromPollId.<p>
    * The PollId that this Message is a request for.
    */
    public long getFromPollId()
        {
        return __m_FromPollId;
        }
    
    // Accessor for the property "RequestPoll"
    /**
    * Getter for property RequestPoll.<p>
    * This is the Poll that the RequestMessage creates to collect responses.
    */
    public _package.component.net.Poll getRequestPoll()
        {
        return __m_RequestPoll;
        }
    
    protected _package.component.net.Poll instantiatePoll()
        {
        // import Component.Net.Poll;
        // import com.tangosol.util.Base;
        // import java.util.Map;
        // import java.util.Iterator;
        
        Map map = get_ChildClasses();
        if (map != null)
            {
            Class clz = (Class) map.get("Poll");
            if (clz == null)
                {
                Class clzPoll = Poll.get_Class();
                for (Iterator iter = map.values().iterator(); iter.hasNext(); )
                    {
                    Class clzChild = (Class) iter.next();
                    if (clzPoll.isAssignableFrom(clzChild))
                        {
                        clz = clzChild;
                        break;
                        }
                    }
                }
            if (clz != null)
                {
                try
                    {
                    return (Poll) clz.newInstance();
                    }
                catch (Exception e)
                    {
                    throw Base.ensureRuntimeException(e);
                    }
                }
            }
        
        return new Poll();
        }
    
    // Declared at the super level
    public void readInternal(java.io.DataInputStream stream)
            throws java.io.IOException
        {
        // import Component.Net.Packet;
        
        super.readInternal(stream);
        
        // note: ensure that the Poll id is non-zero by or-ing with
        // a value beyond the trint range
        int nPollId = Packet.readUnsignedTrint(stream);
        setFromPollId(0x1000000 | nPollId);

        }
    
    // Accessor for the property "FromPollId"
    /**
    * Setter for property FromPollId.<p>
    * The PollId that this Message is a request for.
    */
    public void setFromPollId(long pFromPollId)
        {
        __m_FromPollId = pFromPollId;
        }
    
    // Accessor for the property "RequestPoll"
    /**
    * Setter for property RequestPoll.<p>
    * This is the Poll that the RequestMessage creates to collect responses.
    */
    protected void setRequestPoll(_package.component.net.Poll poll)
        {
        __m_RequestPoll = poll;
        }
    
    // Declared at the super level
    public void writeInternal(java.io.DataOutputStream stream)
            throws java.io.IOException
        {
        // import Component.Net.Packet;
        
        super.writeInternal(stream);
        
        long lPollId = getFromPollId();
        _assert(lPollId != 0l);
        Packet.writeTrint(stream, lPollId);
        }
    }
