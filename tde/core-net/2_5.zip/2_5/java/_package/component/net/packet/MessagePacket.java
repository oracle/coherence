/* Class
*     _package.component.net.packet.MessagePacket
*/

package _package.component.net.packet;

import _package.component.net.MemberSet;

public abstract class MessagePacket
        extends    _package.component.net.Packet
    {
    // Fields declarations
    
    /**
    * Property Body
    *
    * The Message body data carried by this packet.
    */
    private byte[] __m_Body;
    
    /**
    * Property FromMessageId
    *
    * A Directed or Sequel Packet represents a whole or a part of a Message.
    * Each sender maintains a global sequential number that every outgoing
    * Message is marked with (except for Broadcast Messages). This property
    * represents the sender specific Message id for this packet or zero if the
    * Message id is not applicable. On the sender, this is the full id. On the
    * receiver, it's just a trint.
    */
    private long __m_FromMessageId;
    
    /**
    * Property MessagePartCount
    *
    * Specifies the number of Packet components that compose the Message to
    * which this Packet belongs.
    * Broadcast:  1 (Broadcast does not support Sequel Packets)
    * Directed:  1 or greater (the first will be a Directed Packet, all others
    * will be Sequel Packets)
    * Sequel:  Always more than one (otherwise no need for a Sequel Packet)
    * 
    * Note that incoming Sequel cannot determine this property until it is part
    * of a Message (i.e. until Message property is set)
    */
    private int __m_MessagePartCount;
    
    /**
    * Property MessagePartIndex
    *
    * Specifies an zero-based index of this Packet within the multi-Packet
    * Message. The value is only applicable (i.e. non-zero) for Sequel Packets.
    */
    private int __m_MessagePartIndex;
    
    /**
    * Property MessageType
    *
    * Specifies the type of the Message that will be constructed from this
    * Packet. Only Directed (and thus Sequel) and Broadcast Packets form
    * Message objects.
    */
    private int __m_MessageType;
    
    /**
    * Property ResendNecessary
    *
    * ResendNecessary evaluates to true until the MessagePacket has been
    * acknowledged by all of the recipients (or those recipients have left the
    * cluster).
    */
    
    /**
    * Property ResendRequestInProgress
    *
    * This property is reserved for use by the PacketReceiver and
    * PacketPublisher. The ResendRequestInProgress is set when the Packet is
    * re-queued in the send Queue by the processing of a Request Packet. It is
    * reset after the Packet is re-sent from the send Queue.
    * 
    * @see PacketPublisher#onPacket
    */
    private boolean __m_ResendRequestInProgress;
    
    /**
    * Property ResendScheduled
    *
    * This property is reserved for use by the PacketPublisher. The
    * ResendScheduled value is the date/time (in millis) at which the Packet
    * (ConfirmationRequired=true) will be resent if a confirmation for the
    * Packet has not been received.
    */
    private long __m_ResendScheduled;
    
    /**
    * Property ResendSkip
    *
    * This property is reserved for use by the PacketReceiver and
    * PacketPublisher. The ResendSkip is set when the Packet is re-queued in
    * the send Queue by the processing of a Request Packet. It is reset when
    * the Packet is removed from the front of the resend Queue.
    * 
    * @see PacketPublisher$ResendQueue#removeNoWait
    */
    private boolean __m_ResendSkip;
    
    /**
    * Property ResendTimeout
    *
    * This property is reserved for use by the PacketPublisher. The
    * ResendTimeout value is the date/time (in millis) at which the Packet
    * (ConfirmationRequired=true) will stop being resent even if a confirmation
    * for the Packet has not been received, and the Members that have not
    * acknowledged the Packet will be assumed to be dead.
    */
    private long __m_ResendTimeout;
    
    /**
    * Property ServiceId
    *
    * Specifies the Service to which the assembled Message will go (or from
    * which the Message that was disassembled into this Packet came).
    */
    private int __m_ServiceId;
    
    /**
    * Property ToMemberSet
    *
    * Used for outgoing Packets only. Set of Members still to deliver to. Use
    * of ToMemberSet and ToId properties are either/or (exclusive).
    */
    private _package.component.net.memberSet.DependentMemberSet __m_ToMemberSet;
    
    // Initializing constructor
    public MessagePacket(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/packet/MessagePacket".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    /**
    * @see Directed#selectType
    * @see Sequel#selectType
    */
    public static int calcBodyLength(_package.component.net.MemberSet setMember, int cbPref, int cbMax)
        {
        // check if a Broadcast Packet is required
        if (setMember == null)
            {
            // broadcast must fit into one packet, so ignore the "preferred"
            // size and just use the max size minus the broadcast packet
            // overhead (see doc for TYPE_BROADCAST)
            return cbMax - 10;
            }
        
        // check if a "single" Direct Packet can be used
        int cMembers  = setMember.size();
        if (cMembers == 1)
            {
            // (see doc for TYPE_DIRECTED_ONE)
            return cbPref - 23;
            }
        
        // calculate the minimum overhead for the specified number of
        // Members (see doc for TYPE_DIRECTED_FEW and TYPE_DIRECTED_MANY)
        int cbFew  = 19 + 5 * cMembers;
        int cbMany = 21 + 3 * cMembers + 4 * (setMember.getLastId() / 32 + 1);
        
        int cbOverhead = cbFew < cbMany && cMembers <= 255 ? cbFew : cbMany;
        _assert(cbOverhead < cbMax);
        
        return Math.min(Math.max(cbOverhead << 2, cbPref), cbMax) - cbOverhead;
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        // two Packets are considered equal if they have the same from
        // Member id, from Message id, and MessagePartIndex
        if (obj instanceof MessagePacket)
            {
            MessagePacket that = (MessagePacket) obj;
            return this.getFromId()           == that.getFromId()
                && this.getFromMessageId()    == that.getFromMessageId()
                && this.getMessagePartIndex() == that.getMessagePartIndex();
            }
        return false;
        }
    
    // Accessor for the property "Body"
    /**
    * Getter for property Body.<p>
    * The Message body data carried by this packet.
    */
    public byte[] getBody()
        {
        return __m_Body;
        }
    
    // Accessor for the property "FromMessageId"
    /**
    * Getter for property FromMessageId.<p>
    * A Directed or Sequel Packet represents a whole or a part of a Message.
    * Each sender maintains a global sequential number that every outgoing
    * Message is marked with (except for Broadcast Messages). This property
    * represents the sender specific Message id for this packet or zero if the
    * Message id is not applicable. On the sender, this is the full id. On the
    * receiver, it's just a trint.
    */
    public long getFromMessageId()
        {
        return __m_FromMessageId;
        }
    
    // Accessor for the property "MessagePartCount"
    /**
    * Getter for property MessagePartCount.<p>
    * Specifies the number of Packet components that compose the Message to
    * which this Packet belongs.
    * Broadcast:  1 (Broadcast does not support Sequel Packets)
    * Directed:  1 or greater (the first will be a Directed Packet, all others
    * will be Sequel Packets)
    * Sequel:  Always more than one (otherwise no need for a Sequel Packet)
    * 
    * Note that incoming Sequel cannot determine this property until it is part
    * of a Message (i.e. until Message property is set)
    */
    public int getMessagePartCount()
        {
        return __m_MessagePartCount;
        }
    
    // Accessor for the property "MessagePartIndex"
    /**
    * Getter for property MessagePartIndex.<p>
    * Specifies an zero-based index of this Packet within the multi-Packet
    * Message. The value is only applicable (i.e. non-zero) for Sequel Packets.
    */
    public int getMessagePartIndex()
        {
        return __m_MessagePartIndex;
        }
    
    // Accessor for the property "MessageType"
    /**
    * Getter for property MessageType.<p>
    * Specifies the type of the Message that will be constructed from this
    * Packet. Only Directed (and thus Sequel) and Broadcast Packets form
    * Message objects.
    */
    public int getMessageType()
        {
        return __m_MessageType;
        }
    
    // Accessor for the property "ResendScheduled"
    /**
    * Getter for property ResendScheduled.<p>
    * This property is reserved for use by the PacketPublisher. The
    * ResendScheduled value is the date/time (in millis) at which the Packet
    * (ConfirmationRequired=true) will be resent if a confirmation for the
    * Packet has not been received.
    */
    public long getResendScheduled()
        {
        return __m_ResendScheduled;
        }
    
    // Accessor for the property "ResendTimeout"
    /**
    * Getter for property ResendTimeout.<p>
    * This property is reserved for use by the PacketPublisher. The
    * ResendTimeout value is the date/time (in millis) at which the Packet
    * (ConfirmationRequired=true) will stop being resent even if a confirmation
    * for the Packet has not been received, and the Members that have not
    * acknowledged the Packet will be assumed to be dead.
    */
    public long getResendTimeout()
        {
        return __m_ResendTimeout;
        }
    
    // Accessor for the property "ServiceId"
    /**
    * Getter for property ServiceId.<p>
    * Specifies the Service to which the assembled Message will go (or from
    * which the Message that was disassembled into this Packet came).
    */
    public int getServiceId()
        {
        return __m_ServiceId;
        }
    
    // Accessor for the property "ToMemberSet"
    /**
    * Getter for property ToMemberSet.<p>
    * Used for outgoing Packets only. Set of Members still to deliver to. Use
    * of ToMemberSet and ToId properties are either/or (exclusive).
    */
    public _package.component.net.memberSet.DependentMemberSet getToMemberSet()
        {
        return __m_ToMemberSet;
        }
    
    // Declared at the super level
    public int hashCode()
        {
        return getFromId()
             ^ ((int) getFromMessageId())
             ^ getMessagePartIndex();
        }
    
    // Declared at the super level
    /**
    * Getter for property OutgoingMultipoint.<p>
    * True if the Packet may have multiple Members to which it is addressed.
    * (Note: False for Broadcast, which is not addressed.)
    * 
    * This property is only true for Message Packets that have a ToMemberSet.
    * 
    * Should be used only if Outgoing is set.
    */
    public boolean isOutgoingMultipoint()
        {
        return getToMemberSet() != null;
        }
    
    // Accessor for the property "ResendNecessary"
    /**
    * Getter for property ResendNecessary.<p>
    * ResendNecessary evaluates to true until the MessagePacket has been
    * acknowledged by all of the recipients (or those recipients have left the
    * cluster).
    */
    public boolean isResendNecessary()
        {
        // import Component.Net.MemberSet;
        
        if (getToId() != 0)
            {
            return true;
            }
        
        MemberSet set = getToMemberSet();
        return set != null && !set.isEmpty();
        }
    
    // Accessor for the property "ResendRequestInProgress"
    /**
    * Getter for property ResendRequestInProgress.<p>
    * This property is reserved for use by the PacketReceiver and
    * PacketPublisher. The ResendRequestInProgress is set when the Packet is
    * re-queued in the send Queue by the processing of a Request Packet. It is
    * reset after the Packet is re-sent from the send Queue.
    * 
    * @see PacketPublisher#onPacket
    */
    public boolean isResendRequestInProgress()
        {
        return __m_ResendRequestInProgress;
        }
    
    // Accessor for the property "ResendSkip"
    /**
    * Getter for property ResendSkip.<p>
    * This property is reserved for use by the PacketReceiver and
    * PacketPublisher. The ResendSkip is set when the Packet is re-queued in
    * the send Queue by the processing of a Request Packet. It is reset when
    * the Packet is removed from the front of the resend Queue.
    * 
    * @see PacketPublisher$ResendQueue#removeNoWait
    */
    public boolean isResendSkip()
        {
        return __m_ResendSkip;
        }
    
    /**
    * Read the Packet (not counting the Packet type id) from a Stream.
    * 
    * Note: The read method is not responsible for configuring the "To" portion
    * of the packet.
    * 
    * @param stream  the DataInputStream to read from
    * @param nMemberId  this Member's id if known, otherwise zero
    */
    public void readBody(java.io.DataInputStream stream)
            throws java.io.IOException
        {
        int    cb = stream.readUnsignedShort();
        byte[] ab = new byte[cb];
        
        stream.readFully(ab);
        setBody(ab);
        }
    
    public void registerAck(_package.component.net.Member memberFrom)
        {
        // import Component.Net.MemberSet;
        
        _assert(isOutgoing());
        
        MemberSet set = getToMemberSet();
        if (set == null)
            {
            int nToId   = getToId();
            int nFromId = memberFrom.getId();
            if (nToId != 0)
                {
                _assert(nFromId == nToId);
                setToId(0);
                }
            }
        else
            {
            set.remove(memberFrom);
            }
        }
    
    public int selectType(_package.component.net.MemberSet memberSet)
        {
        return 0;
        }
    
    // Accessor for the property "Body"
    /**
    * Setter for property Body.<p>
    * The Message body data carried by this packet.
    */
    public void setBody(byte[] ab)
        {
        __m_Body = ab;
        }
    
    // Accessor for the property "FromMessageId"
    /**
    * Setter for property FromMessageId.<p>
    * A Directed or Sequel Packet represents a whole or a part of a Message.
    * Each sender maintains a global sequential number that every outgoing
    * Message is marked with (except for Broadcast Messages). This property
    * represents the sender specific Message id for this packet or zero if the
    * Message id is not applicable. On the sender, this is the full id. On the
    * receiver, it's just a trint.
    */
    public void setFromMessageId(long nId)
        {
        __m_FromMessageId = nId;
        }
    
    // Accessor for the property "MessagePartCount"
    /**
    * Setter for property MessagePartCount.<p>
    * Specifies the number of Packet components that compose the Message to
    * which this Packet belongs.
    * Broadcast:  1 (Broadcast does not support Sequel Packets)
    * Directed:  1 or greater (the first will be a Directed Packet, all others
    * will be Sequel Packets)
    * Sequel:  Always more than one (otherwise no need for a Sequel Packet)
    * 
    * Note that incoming Sequel cannot determine this property until it is part
    * of a Message (i.e. until Message property is set)
    */
    public void setMessagePartCount(int cParts)
        {
        __m_MessagePartCount = cParts;
        }
    
    // Accessor for the property "MessagePartIndex"
    /**
    * Setter for property MessagePartIndex.<p>
    * Specifies an zero-based index of this Packet within the multi-Packet
    * Message. The value is only applicable (i.e. non-zero) for Sequel Packets.
    */
    public void setMessagePartIndex(int i)
        {
        __m_MessagePartIndex = i;
        }
    
    // Accessor for the property "MessageType"
    /**
    * Setter for property MessageType.<p>
    * Specifies the type of the Message that will be constructed from this
    * Packet. Only Directed (and thus Sequel) and Broadcast Packets form
    * Message objects.
    */
    public void setMessageType(int nType)
        {
        __m_MessageType = nType;
        }
    
    // Accessor for the property "ResendRequestInProgress"
    /**
    * Setter for property ResendRequestInProgress.<p>
    * This property is reserved for use by the PacketReceiver and
    * PacketPublisher. The ResendRequestInProgress is set when the Packet is
    * re-queued in the send Queue by the processing of a Request Packet. It is
    * reset after the Packet is re-sent from the send Queue.
    * 
    * @see PacketPublisher#onPacket
    */
    public void setResendRequestInProgress(boolean fResending)
        {
        __m_ResendRequestInProgress = fResending;
        }
    
    // Accessor for the property "ResendScheduled"
    /**
    * Setter for property ResendScheduled.<p>
    * This property is reserved for use by the PacketPublisher. The
    * ResendScheduled value is the date/time (in millis) at which the Packet
    * (ConfirmationRequired=true) will be resent if a confirmation for the
    * Packet has not been received.
    */
    public void setResendScheduled(long cMillis)
        {
        __m_ResendScheduled = cMillis;
        }
    
    // Accessor for the property "ResendSkip"
    /**
    * Setter for property ResendSkip.<p>
    * This property is reserved for use by the PacketReceiver and
    * PacketPublisher. The ResendSkip is set when the Packet is re-queued in
    * the send Queue by the processing of a Request Packet. It is reset when
    * the Packet is removed from the front of the resend Queue.
    * 
    * @see PacketPublisher$ResendQueue#removeNoWait
    */
    public void setResendSkip(boolean fSkip)
        {
        __m_ResendSkip = fSkip;
        }
    
    // Accessor for the property "ResendTimeout"
    /**
    * Setter for property ResendTimeout.<p>
    * This property is reserved for use by the PacketPublisher. The
    * ResendTimeout value is the date/time (in millis) at which the Packet
    * (ConfirmationRequired=true) will stop being resent even if a confirmation
    * for the Packet has not been received, and the Members that have not
    * acknowledged the Packet will be assumed to be dead.
    */
    public void setResendTimeout(long pResendTimeout)
        {
        __m_ResendTimeout = pResendTimeout;
        }
    
    // Accessor for the property "ServiceId"
    /**
    * Setter for property ServiceId.<p>
    * Specifies the Service to which the assembled Message will go (or from
    * which the Message that was disassembled into this Packet came).
    */
    public void setServiceId(int nId)
        {
        __m_ServiceId = nId;
        }
    
    // Accessor for the property "ToMemberSet"
    /**
    * Setter for property ToMemberSet.<p>
    * Used for outgoing Packets only. Set of Members still to deliver to. Use
    * of ToMemberSet and ToId properties are either/or (exclusive).
    */
    public void setToMemberSet(_package.component.net.memberSet.DependentMemberSet setMember)
        {
        __m_ToMemberSet = setMember;
        }
    
    /**
    * Write the Packet to a Stream.
    * 
    * @param stream  the DataOutputStream to write to
    * @param nMemberId  if non-zero, it indicates that the Packet should be
    * addressed only to one member
    */
    public void writeBody(java.io.DataOutputStream stream)
            throws java.io.IOException
        {
        byte[] ab = getBody();
        int    cb = ab.length;
        
        stream.writeShort(cb);
        stream.write(ab);
        }
    }
