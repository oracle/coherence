/* Class
*     _package.component.net.Security$RefAction
*/

package _package.component.net;

import _package.component.application.console.Coherence;
import com.tangosol.util.Base;

/**
* Reflection based PrivilegedAction
*/
public class Security$RefAction
        extends    _package.component.Util
        implements java.security.PrivilegedAction
    {
    // Fields declarations
    
    /**
    * Property Arguments
    *
    */
    private transient Object[] __m_Arguments;
    
    /**
    * Property Method
    *
    */
    private transient java.lang.reflect.Method __m_Method;
    
    /**
    * Property Target
    *
    */
    private transient Object __m_Target;
    
    // Default constructor
    public Security$RefAction()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Security$RefAction(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Security$RefAction();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/Security$RefAction".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Accessor for the property "Arguments"
    /**
    * Getter for property Arguments.<p>
    */
    public Object[] getArguments()
        {
        return __m_Arguments;
        }
    
    // Accessor for the property "Method"
    /**
    * Getter for property Method.<p>
    */
    public java.lang.reflect.Method getMethod()
        {
        return __m_Method;
        }
    
    // Accessor for the property "Target"
    /**
    * Getter for property Target.<p>
    */
    public Object getTarget()
        {
        return __m_Target;
        }
    
    // From interface: java.security.PrivilegedAction
    public Object run()
        {
        // import com.tangosol.util.Base;
        
        try
            {
            return getMethod().invoke(getTarget(), getArguments());
            }
        catch (Exception e)
            {
            throw Base.ensureRuntimeException(e, toString());
            }
        }
    
    // Accessor for the property "Arguments"
    /**
    * Setter for property Arguments.<p>
    */
    public void setArguments(Object[] method)
        {
        __m_Arguments = method;
        }
    
    // Accessor for the property "Method"
    /**
    * Setter for property Method.<p>
    */
    public void setMethod(java.lang.reflect.Method method)
        {
        __m_Method = method;
        }
    
    // Accessor for the property "Target"
    /**
    * Setter for property Target.<p>
    */
    public void setTarget(Object method)
        {
        __m_Target = method;
        }
    
    // Declared at the super level
    public String toString()
        {
        // import Component.Application.Console.Coherence;
        
        return "RefAction{Method=" + getMethod().getName() + ", Target=" + getTarget() +
               ", Args=" + Coherence.toString(getArguments()) + '}';
        }
    }
