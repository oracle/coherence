/* Class
*     _package.component.net.socket.UdpSocket
*/

package _package.component.net.socket;

import com.tangosol.util.WrapperException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.BindException;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public abstract class UdpSocket
        extends    _package.component.net.Socket
    {
    // Fields declarations
    
    /**
    * Property BufferReceived
    *
    * Maximum number of packets to ask the OS to buffer when receiving.
    */
    private int __m_BufferReceived;
    
    /**
    * Property BufferSent
    *
    * Maximum number of packets to ask the OS to buffer when sending.
    */
    private int __m_BufferSent;
    
    /**
    * Property CountReceived
    *
    * The count of received packets.
    */
    private int __m_CountReceived;
    
    /**
    * Property CountSent
    *
    * The count of sent packets.
    */
    private int __m_CountSent;
    
    /**
    * Property DatagramSocket
    *
    * The actual socket.
    */
    private java.net.DatagramSocket __m_DatagramSocket;
    
    /**
    * Property LastReceiveMillis
    *
    * This property is set to the current time when the last packet was
    * received.
    * 
    * @see #receive
    */
    private long __m_LastReceiveMillis;
    
    /**
    * Property LastSendMillis
    *
    * This property is set to the current time when the last packet was sent.
    * 
    * @see #send
    */
    private long __m_LastSendMillis;
    
    /**
    * Property PacketLength
    *
    * This property controls both SendBufferSize and ReceiveBufferSize settings
    * of the underlying java.net.DatagramSocket.
    * 
    * @see java.net.DatagramSocket#setReceiveBufferSize
    * @see java.net.DatagramSocket#setSendBufferSize
    */
    private int __m_PacketLength;
    
    // Initializing constructor
    public UdpSocket(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/socket/UdpSocket".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    public void close()
        {
        // import java.net.DatagramSocket;
        
        synchronized (getLock())
            {
            if (getState() != STATE_CLOSED)
                {
                DatagramSocket socket = getDatagramSocket();
                if (socket != null)
                    {
                    try
                        {
                        socket.close();
                        }
                    catch (Exception e)
                        {
                        // ignore exception on close; assume the socket is
                        // closed since there is nothing else that can be
                        // done to close it
                        }
                    setDatagramSocket(null);
                    }
        
                setState(STATE_CLOSED);
                }
            }
        }
    
    // Accessor for the property "BufferReceived"
    /**
    * Getter for property BufferReceived.<p>
    * Maximum number of packets to ask the OS to buffer when receiving.
    */
    public int getBufferReceived()
        {
        return __m_BufferReceived;
        }
    
    // Accessor for the property "BufferSent"
    /**
    * Getter for property BufferSent.<p>
    * Maximum number of packets to ask the OS to buffer when sending.
    */
    public int getBufferSent()
        {
        return __m_BufferSent;
        }
    
    // Accessor for the property "CountReceived"
    /**
    * Getter for property CountReceived.<p>
    * The count of received packets.
    */
    public int getCountReceived()
        {
        return __m_CountReceived;
        }
    
    // Accessor for the property "CountSent"
    /**
    * Getter for property CountSent.<p>
    * The count of sent packets.
    */
    public int getCountSent()
        {
        return __m_CountSent;
        }
    
    // Accessor for the property "DatagramSocket"
    /**
    * Getter for property DatagramSocket.<p>
    * The actual socket.
    */
    public java.net.DatagramSocket getDatagramSocket()
        {
        return __m_DatagramSocket;
        }
    
    // Accessor for the property "LastReceiveMillis"
    /**
    * Getter for property LastReceiveMillis.<p>
    * This property is set to the current time when the last packet was
    * received.
    * 
    * @see #receive
    */
    public long getLastReceiveMillis()
        {
        return __m_LastReceiveMillis;
        }
    
    // Accessor for the property "LastSendMillis"
    /**
    * Getter for property LastSendMillis.<p>
    * This property is set to the current time when the last packet was sent.
    * 
    * @see #send
    */
    public long getLastSendMillis()
        {
        return __m_LastSendMillis;
        }
    
    // Accessor for the property "PacketLength"
    /**
    * Getter for property PacketLength.<p>
    * This property controls both SendBufferSize and ReceiveBufferSize settings
    * of the underlying java.net.DatagramSocket.
    * 
    * @see java.net.DatagramSocket#setReceiveBufferSize
    * @see java.net.DatagramSocket#setSendBufferSize
    */
    public int getPacketLength()
        {
        return __m_PacketLength;
        }
    
    /**
    * Set up the specified java.net.DatagramSocket.
    */
    protected void initializeDatagramSocket(java.net.DatagramSocket socket)
        {
        // import com.tangosol.util.WrapperException;
        // import java.net.SocketException;
        
        try
            {
            int cbPacket = getPacketLength();
            _assert(cbPacket > 0, "UdpSocket.open: "
                + "PacketLength property is required and must be greater than zero");
        
            socket.setSendBufferSize(cbPacket * getBufferSent());
            socket.setReceiveBufferSize(cbPacket * getBufferReceived());
            validateBufferSize(socket.getSendBufferSize(),
                socket.getReceiveBufferSize(), cbPacket);
        
            int cMillis = getSoTimeout();
            _assert(cMillis >= 0, "UdpSocket.open: "
                + "SoTimeout property must be greater than or equal to zero");
        
            socket.setSoTimeout(cMillis);
            validateSoTimeout(socket.getSoTimeout(), cMillis);
            }
        catch (SocketException e)
            {
            throw new WrapperException(e);
            }
        }
    
    /**
    * Instantiate an underlying java.net.DatagramSocket.
    */
    protected java.net.DatagramSocket instantiateDatagramSocket()
            throws java.io.IOException
        {
        // import java.net.BindException;
        // import java.net.DatagramSocket;
        // import java.net.InetAddress;
        
        InetAddress addr  = getInetAddress();
        int         nPort = getPort();
        
        _assert(addr != null, "UdpSocket.open: "
            + "InetAddress is required");
        _assert(nPort > 0 && nPort <= 65535, "UdpSocket.open: "
            + "Port out of range (" + nPort + ")");
        
        int cAttempts = (isPortAutoSelect() && getState() == STATE_INITIAL) ? 256 : 1;
        int nPortOrig = nPort;
        
        while (true)
            {
            try
                {
                DatagramSocket socket = new DatagramSocket(nPort, addr);
                if (nPort != nPortOrig)
                    {
                    setPort(nPort);
                    }
                return socket;
                }
            catch (BindException e)
                {
                if (--cAttempts == 0)
                    {
                    throw e;
                    }
                nPort++;
                }
            }
        }
    
    /**
    * 
    * @param eException  the causal exception
    * @param lSocketActionMillis  the time that the exception occurred (or the
    * enclosing operation began or was in progress)
    */
    protected void onReceiveException(java.io.IOException eException, long lSocketActionMillis)
        {
        onException(eException, lSocketActionMillis);
        }
    
    /**
    * 
    * @param eException  the causal exception
    * @param lSocketActionMillis  the time that the exception occurred (or the
    * enclosing operation began or was in progress)
    */
    protected void onSendException(java.io.IOException eException, long lSocketActionMillis)
        {
        onException(eException, lSocketActionMillis);
        }
    
    // Declared at the super level
    public void open()
            throws java.io.IOException
        {
        // import java.net.DatagramSocket;
        
        synchronized (getLock())
            {
            if (getState() != STATE_OPEN)
                {
                DatagramSocket socket = instantiateDatagramSocket();
                try
                    {
                    initializeDatagramSocket(socket);
        
                    setDatagramSocket(socket);
                    setLastOpenMillis(System.currentTimeMillis());
                    }
                catch (RuntimeException e)
                    {
                    try
                        {
                        socket.close();
                        }
                    catch (Exception eIgnore) {}
                    setDatagramSocket(null);
                    throw e;
                    }
        
                setState(STATE_OPEN);
                }
            }
        }
    
    public void receive(_package.component.net.UdpPacket packet)
        {
        // import java.io.InterruptedIOException;
        // import java.io.IOException;
        // import java.net.DatagramSocket;
        
        while (true)
            {
            long        lCurrent = System.currentTimeMillis();
            IOException eIO      = null;
            boolean     fSuccess = true;
            try
                {
                DatagramSocket socket = getDatagramSocket();
                if (socket == null)
                    {
                    fSuccess = false;
                    }
                else
                    {
                    int cbAvail = packet.getBufferLength() - packet.getOffset();
                    int cbMax   = getPacketLength();
        
                    packet.setLength(Math.min(cbAvail, cbMax));
                    socket.receive(packet.getDatagramPacket());
                    }
                }
            catch (InterruptedIOException e)
                {
                onInterruptedIOException(e, lCurrent);
                return;
                }
            catch (IOException e)
                {
                fSuccess = false;
                eIO = e;
                }
        
            if (fSuccess)
                {
                setLastReceiveMillis(lCurrent);
                setCountReceived(getCountReceived() + 1);
                return;
                }
        
            synchronized (getLock())
                {
                switch (getState())
                    {
                    case STATE_OPEN:
                        // re-open the socket or take other action
                        onReceiveException(eIO, lCurrent);
                        break;
                    default:
                        throw new IllegalStateException("UdpSocket.receive: " +
                            "Exception " + eIO + "; State= " + formatStateName(getState()));
                    }
                }
            }
        }
    
    public void send(_package.component.net.UdpPacket packet)
        {
        // import java.io.IOException;
        // import java.net.DatagramSocket;
        
        while (true)
            {
            long        lCurrent = System.currentTimeMillis();
            IOException eIO      = null;
            boolean     fSuccess = true;
            try
                {
                DatagramSocket socket = getDatagramSocket();
                if (socket == null)
                    {
                    fSuccess = false;
                    }
                else
                    {
                    socket.send(packet.getDatagramPacket());
                    }
                }
            catch (IOException e)
                {
                fSuccess = false;
                eIO = e;
                }
        
            if (fSuccess)
                {
                setLastSendMillis(lCurrent);
                setCountSent(getCountSent() + 1);
                return;
                }
        
            synchronized (getLock())
                {
                switch (getState())
                    {
                    case STATE_OPEN:
                        // re-open the socket or take other action
                        onSendException(eIO, lCurrent);
                        break;
                    default:
                        throw new IllegalStateException("UdpSocket.send: " +
                            "Exception " + eIO + "; State= " + formatStateName(getState()));
                    }
                }
            }
        }
    
    // Accessor for the property "BufferReceived"
    /**
    * Setter for property BufferReceived.<p>
    * Maximum number of packets to ask the OS to buffer when receiving.
    */
    public void setBufferReceived(int cPackets)
        {
        synchronized (getLock())
            {
            _assert(getState() != STATE_OPEN,
                "BufferReceived cannot be modified once the socket is open");
        
            __m_BufferReceived = (cPackets);
            }
        }
    
    // Accessor for the property "BufferSent"
    /**
    * Setter for property BufferSent.<p>
    * Maximum number of packets to ask the OS to buffer when sending.
    */
    public void setBufferSent(int cPackets)
        {
        synchronized (getLock())
            {
            _assert(getState() != STATE_OPEN,
                "BufferSent cannot be modified once the socket is open");
        
            __m_BufferSent = (cPackets);
            }
        }
    
    // Accessor for the property "CountReceived"
    /**
    * Setter for property CountReceived.<p>
    * The count of received packets.
    */
    protected void setCountReceived(int cReceived)
        {
        __m_CountReceived = cReceived;
        }
    
    // Accessor for the property "CountSent"
    /**
    * Setter for property CountSent.<p>
    * The count of sent packets.
    */
    protected void setCountSent(int cSent)
        {
        __m_CountSent = cSent;
        }
    
    // Accessor for the property "DatagramSocket"
    /**
    * Setter for property DatagramSocket.<p>
    * The actual socket.
    */
    protected void setDatagramSocket(java.net.DatagramSocket socket)
        {
        __m_DatagramSocket = socket;
        }
    
    // Accessor for the property "LastReceiveMillis"
    /**
    * Setter for property LastReceiveMillis.<p>
    * This property is set to the current time when the last packet was
    * received.
    * 
    * @see #receive
    */
    protected void setLastReceiveMillis(long lMillis)
        {
        __m_LastReceiveMillis = lMillis;
        }
    
    // Accessor for the property "LastSendMillis"
    /**
    * Setter for property LastSendMillis.<p>
    * This property is set to the current time when the last packet was sent.
    * 
    * @see #send
    */
    protected void setLastSendMillis(long lMillis)
        {
        __m_LastSendMillis = lMillis;
        }
    
    // Accessor for the property "PacketLength"
    /**
    * Setter for property PacketLength.<p>
    * This property controls both SendBufferSize and ReceiveBufferSize settings
    * of the underlying java.net.DatagramSocket.
    * 
    * @see java.net.DatagramSocket#setReceiveBufferSize
    * @see java.net.DatagramSocket#setSendBufferSize
    */
    public void setPacketLength(int cb)
        {
        synchronized (getLock())
            {
            _assert(getState() != STATE_OPEN,
                "PacketLength cannot be modified once the socket is open");
        
            __m_PacketLength = (cb);
            }
        }
    
    // Declared at the super level
    /**
    * Setter for property SoTimeout.<p>
    * Enable/disable SO_TIMEOUT with the specified timeout, in milliseconds.
    * With this value set to a non-zero timeout, a call to read(), receive() or
    * accept() for TcpSocket,  UdpSocket or TcpSecketAccepter will block for
    * only this amount of time. If the timeout expires, an 
    * java.io.InterruptedIOException is raised and onInterruptedIOException
    * event is called, though the Socket is still valid. The option must be
    * enabled prior to entering the blocking operation to have effect. The
    * timeout value must be > 0. A timeout of zero is interpreted as an
    * infinite timeout.
    */
    public void setSoTimeout(int cMillis)
        {
        // import com.tangosol.util.WrapperException;
        // import java.net.DatagramSocket;
        // import java.net.SocketException;
        
        synchronized (getLock())
            {
            _assert(cMillis >= 0);
        
            if (getState() == STATE_OPEN)
                {
                DatagramSocket socket = getDatagramSocket();
                try
                    {
                    socket.setSoTimeout(cMillis);
        
                    validateSoTimeout(socket.getSoTimeout(), cMillis);
                    }
                catch (SocketException e)
                    {
                    throw new WrapperException(e);
                    }
                }
        
            super.setSoTimeout(cMillis);
            }
        }
    }
