/* Class
*     _package.component.net.memberSet.DependentMemberSet
*/

package _package.component.net.memberSet;

import _package.component.net.Member;
import _package.component.net.MemberSet;
import _package.component.net.Packet;
import java.lang.reflect.Array;
import java.util.Iterator;

/**
* 
* Requires BaseSet to be configured before use.
*/
public class DependentMemberSet
        extends    _package.component.net.MemberSet
    {
    // Fields declarations
    
    /**
    * Property BaseSet
    *
    * The underlying MemberSet upon which this MemberSet is based. This
    * MemberSet is a sub-set of the base MemberSet.
    */
    private _package.component.net.MemberSet __m_BaseSet;
    
    /**
    * Property DestinationMessageId
    *
    * (Ambient.) An array, indexed by Member mini-id, of point-to-point Message
    * ids. This property is used by Messages and Directed Packets to map
    * destination Members to their corresponding Message id that they identify
    * incoming Message Packets with.
    */
    private int[] __m_DestinationMessageId;
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Iterator", _package.component.net.MemberSet$Iterator.get_CLASS());
        }
    
    // Default constructor
    public DependentMemberSet()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public DependentMemberSet(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new DependentMemberSet();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/net/memberSet/DependentMemberSet".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    /**
    * Adds all of the BaseSet's Members to this MemberSet.
    */
    public synchronized boolean addAll()
        {
        return addAll(getBaseSet());
        }
    
    // Declared at the super level
    public synchronized boolean contains(int nId)
        {
        return super.contains(nId) && getBaseSet().contains(nId);
        }
    
    // Declared at the super level
    public synchronized boolean contains(Object o)
        {
        return super.contains(o) && getBaseSet().contains(o);
        }
    
    // Declared at the super level
    public synchronized boolean containsAll(java.util.Collection collection)
        {
        sync();
        return super.containsAll(collection);
        }
    
    // Accessor for the property "BaseSet"
    /**
    * Getter for property BaseSet.<p>
    * The underlying MemberSet upon which this MemberSet is based. This
    * MemberSet is a sub-set of the base MemberSet.
    */
    public _package.component.net.MemberSet getBaseSet()
        {
        return __m_BaseSet;
        }
    
    // Accessor for the property "DestinationMessageId"
    /**
    * Getter for property DestinationMessageId.<p>
    * (Ambient.) An array, indexed by Member mini-id, of point-to-point Message
    * ids. This property is used by Messages and Directed Packets to map
    * destination Members to their corresponding Message id that they identify
    * incoming Message Packets with.
    */
    protected int[] getDestinationMessageId()
        {
        return __m_DestinationMessageId;
        }
    
    // Accessor for the property "DestinationMessageId"
    /**
    * Getter for property DestinationMessageId.<p>
    * (Ambient.) An array, indexed by Member mini-id, of point-to-point Message
    * ids. This property is used by Messages and Directed Packets to map
    * destination Members to their corresponding Message id that they identify
    * incoming Message Packets with.
    */
    public int getDestinationMessageId(int i)
        {
        int[] an = getDestinationMessageId();
        return an != null && i < an.length ? an[i] : 0;
        }
    
    // Declared at the super level
    /**
    * Getter for property Member.<p>
    * Members, indexed by Member mini-id. May not be supported if the MemberSet
    * does not hold on the Members that are in the MemberSet.
    */
    public _package.component.net.Member getMember(int i)
        {
        return getBaseSet().getMember(i);
        }
    
    // Declared at the super level
    public synchronized boolean isEmpty()
        {
        if (getBaseSet().isEmpty())
            {
            clear();
            return true;
            }
        
        sync();
        return super.isEmpty();
        }
    
    // Accessor for the property "BaseSet"
    /**
    * Setter for property BaseSet.<p>
    * The underlying MemberSet upon which this MemberSet is based. This
    * MemberSet is a sub-set of the base MemberSet.
    */
    public void setBaseSet(_package.component.net.MemberSet set)
        {
        _assert(getBaseSet() == null && set != null);
        __m_BaseSet = (set);
        }
    
    // Accessor for the property "DestinationMessageId"
    /**
    * Setter for property DestinationMessageId.<p>
    * (Ambient.) An array, indexed by Member mini-id, of point-to-point Message
    * ids. This property is used by Messages and Directed Packets to map
    * destination Members to their corresponding Message id that they identify
    * incoming Message Packets with.
    */
    protected void setDestinationMessageId(int[] an)
        {
        __m_DestinationMessageId = an;
        }
    
    // Accessor for the property "DestinationMessageId"
    /**
    * Setter for property DestinationMessageId.<p>
    * (Ambient.) An array, indexed by Member mini-id, of point-to-point Message
    * ids. This property is used by Messages and Directed Packets to map
    * destination Members to their corresponding Message id that they identify
    * incoming Message Packets with.
    */
    public void setDestinationMessageId(int i, int nId)
        {
        int[] an = getDestinationMessageId();
        
        if (an == null || i >= an.length)
            {
            // resize, making the array bigger than necessary (avoid resizes)
            int   cNew  = Math.max(i + (i >>> 1), i + 4);
            int[] anNew = new int[cNew];
        
            // copy original data
            if (an != null)
                {
                System.arraycopy(an, 0, anNew, 0, an.length);
                }
        
            setDestinationMessageId(an = anNew);
            }
        
        an[i] = nId;
        }
    
    // Declared at the super level
    public synchronized int size()
        {
        sync();
        return super.size();
        }
    
    /**
    * Updates this MemberSet's information such that it is a subset of the
    * BaseSet.
    */
    public void sync()
        {
        retainAll(getBaseSet());
        }
    
    // Declared at the super level
    public synchronized Object[] toArray(Object[] ao)
        {
        // import Component.Net.Member;
        // import Component.Net.MemberSet;
        // import java.lang.reflect.Array;
        // import java.util.Iterator;
        
        MemberSet setBase = getBaseSet();
        synchronized (setBase)
            {
            // create the array to store the set contents
            int c = size();
            if (ao == null)
                {
                ao = new Member[c];
                }
            else if (ao.length < c)
                {
                // if it is not big enough, a new array of the same runtime
                // type is allocated
                ao = (Object[]) Array.newInstance(ao.getClass().getComponentType(), c);
                }
            else if (ao.length > c)
                {
                // if the collection fits in the specified array with room to
                // spare, the element in the array immediately following the
                // end of the collection is set to null
                ao[c] = null;
                }
        
            // go through all the base members and accumulate those
            // that are also contained by this set
            int of = 0;
            for (Iterator iter = setBase.iterator(); iter.hasNext(); )
                {
                Member member = (Member) iter.next();
                if (contains(member))
                    {
                    ao[of++] = member;
                    }
                }
        
            return ao;
            }
        }
    
    /**
    * Write a destination Message id for the several Members contained in the
    * passed MemberSet to the specified stream.
    * 
    * @param stream  the stream to write to
    * @param setTo  the MemberSet that contains several Members that this
    * MemberSet contains the destination Message ids for
    */
    public void writeFewToMessageId(java.io.DataOutputStream stream, _package.component.net.MemberSet setTo)
            throws java.io.IOException
        {
        // import Component.Net.Packet;
        
        int cMembers = setTo.size();
        _assert(cMembers <= 255);
        // [implicit] stream.writeByte(cMembers);
        
        if (cMembers > 0)
            {
            for (int i = 0, c = setTo.getBitSetCount(); i < c && cMembers > 0; ++i)
                {
                int n = setTo.getBitSet(i);
                if (n != 0)
                    {
                    int nBase = i << 5;
                    for (int of = 1, nMask = 1; of <= 32; ++of, nMask <<= 1)
                        {
                        if ((n & nMask) != 0)
                            {
                            int nMemberId  = nBase + of;
                            int nMessageTo = getDestinationMessageId(nMemberId);
                            // this assertion is only for short-test debugging;
                            // the trint value in production will roll over to
                            // zero eventually (~16 million messages)
                            // _assert(nMessageTo != 0);
                            Packet.writeTrint(stream, nMessageTo);
                            --cMembers;
                            }
                        }
                    }
                }
            }
        }
    
    /**
    * Write a destination Message ids for the Members contained in the passed
    * MemberSet as a length-encoded array of trints to the specified stream.
    * 
    * @param stream  the stream to write to
    * @param setTo  the MemberSet that contains the Members that this MemberSet
    * contains the destination Message ids for
    */
    public void writeManyToMessageId(java.io.DataOutputStream stream, _package.component.net.MemberSet setTo)
            throws java.io.IOException
        {
        // import Component.Net.Packet;
        
        int cMembers = setTo.size();
        stream.writeShort(cMembers);
        
        if (cMembers > 0)
            {
            for (int i = 0, c = setTo.getBitSetCount(); i < c && cMembers > 0; ++i)
                {
                int n = setTo.getBitSet(i);
                if (n != 0)
                    {
                    int nBase = i << 5;
                    for (int of = 1, nMask = 1; of <= 32; ++of, nMask <<= 1)
                        {
                        if ((n & nMask) != 0)
                            {
                            int nMemberId  = nBase + of;
                            int nMessageTo = getDestinationMessageId(nMemberId);
                            // this assertion is only for short-test debugging;
                            // the trint value in production will roll over to
                            // zero eventually (~16 million messages)
                            // _assert(nMessageTo != 0);
                            Packet.writeTrint(stream, nMessageTo);
                            --cMembers;
                            }
                        }
                    }
                }
            }
        }
    
    /**
    * Write a destination Message id for the one Member contained in the passed
    * MemberSet to the specified stream.
    * 
    * @param stream  the stream to write to
    * @param setTo  the MemberSet that contains the one Member that this
    * MemberSet contains the destination Message id for
    */
    public void writeOneToMessageId(java.io.DataOutputStream stream, _package.component.net.MemberSet setTo)
            throws java.io.IOException
        {
        // import Component.Net.Packet;
        
        int nMemberTo = setTo.getFirstId();
        _assert(nMemberTo != 0);
        int nMessageTo = getDestinationMessageId(nMemberTo);
        // this assertion is only for short-test debugging;
        // the trint value in production will roll over to
        // zero eventually (~16 million messages)
        // _assert(nMessageTo != 0);
        
        Packet.writeTrint(stream, nMessageTo);

        }
    }
