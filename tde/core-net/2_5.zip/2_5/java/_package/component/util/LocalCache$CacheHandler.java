/* Class
*     _package.component.util.LocalCache$CacheHandler
*/

package _package.component.util;

import com.tangosol.net.BackingMapManager;
import com.tangosol.net.cache.CacheMap;
import com.tangosol.util.Filter;
import com.tangosol.util.ImmutableArrayList;
import com.tangosol.util.MapListenerSupport; // as Support
import com.tangosol.util.comparator.EntryComparator;
import com.tangosol.util.comparator.SafeComparator;
import com.tangosol.util.filter.EntryFilter;
import com.tangosol.util.filter.LimitFilter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map$Entry; // as Entry
import java.util.Map;
import java.util.Set;

public class LocalCache$CacheHandler
        extends    ConcurrentMap
        implements com.tangosol.net.NamedCache,
                   com.tangosol.util.MapListener
    {
    // Fields declarations
    
    /**
    * Property CacheName
    *
    */
    private String __m_CacheName;
    
    /**
    * Property CacheService
    *
    */
    
    /**
    * Property ListenerSupport
    *
    */
    private transient com.tangosol.util.MapListenerSupport __m_ListenerSupport;
    
    // Default constructor
    public LocalCache$CacheHandler()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public LocalCache$CacheHandler(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setListenerSupport(new com.tangosol.util.MapListenerSupport());
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new LocalCache$CacheHandler();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/LocalCache$CacheHandler".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void addIndex(com.tangosol.util.ValueExtractor extractor, boolean fOrdered, java.util.Comparator comparator)
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Declared at the super level
    public void addMapListener(com.tangosol.util.MapListener listener)
        {
        // import com.tangosol.util.Filter;
        
        addMapListener(listener, (Filter) null, false);
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Declared at the super level
    public void addMapListener(com.tangosol.util.MapListener listener, com.tangosol.util.Filter filter, boolean fLite)
        {
        // import com.tangosol.util.Filter;
        // import com.tangosol.util.MapListenerSupport as Support;
        
        if (listener == this)
            {
            super.addMapListener(this, filter, fLite);
            }
        else if (listener != null)
            {
            Support support = getListenerSupport();
            synchronized (support)
                {
                boolean fWasEmpty = support.isEmpty(filter);
                boolean fWasLite  = fWasEmpty || !support.containsStandardListeners(filter);
        
                if (fWasEmpty || (fWasLite && !fLite))
                    {
                    addMapListener(this, filter, fLite);
                    }
        
                support.addListener(listener, filter, fLite);
                }
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Declared at the super level
    public void addMapListener(com.tangosol.util.MapListener listener, Object oKey, boolean fLite)
        {
        // import com.tangosol.util.Filter;
        // import com.tangosol.util.MapListenerSupport as Support;
        
        if (listener == this)
            {
            super.addMapListener(this, oKey, fLite);
            }
        else if (listener != null)
            {
            Support support = getListenerSupport();
            synchronized (support)
                {
                boolean fWasEmpty = support.isEmpty(oKey);
                boolean fWasLite  = fWasEmpty || !support.containsStandardListeners(oKey);
        
                if (fWasEmpty || (fWasLite && !fLite))
                    {
                    addMapListener(this, oKey, fLite);
                    }
        
                support.addListener(listener, oKey, fLite);
                }
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void destroy()
        {
        getCacheService().destroyCache(this);
        }
    
    // From interface: com.tangosol.util.MapListener
    public void entryDeleted(com.tangosol.util.MapEvent evt)
        {
        translateMapEvent(evt);
        }
    
    // From interface: com.tangosol.util.MapListener
    public void entryInserted(com.tangosol.util.MapEvent evt)
        {
        translateMapEvent(evt);
        }
    
    // From interface: com.tangosol.net.NamedCache
    public java.util.Set entrySet(com.tangosol.util.Filter filter)
        {
        // import com.tangosol.util.filter.EntryFilter;
        // import com.tangosol.util.filter.LimitFilter;
        // import java.util.HashSet;
        // import java.util.Iterator;
        // import java.util.Map$Entry as Entry;
        // import java.util.Set;
        
        if (filter == null)
            {
            return entrySet();
            }
        
        Set set = new HashSet();
        for (Iterator iter = entrySet().iterator(); iter.hasNext();)
            {
            Entry entry = (Entry) iter.next();
        
            if (filter instanceof EntryFilter
                    ? ((EntryFilter) filter).evaluateEntry(entry)
                    : filter.evaluate(entry.getValue()))
                {
                set.add(entry);
                }
            }
        
        if (filter instanceof LimitFilter)
            {
            LimitFilter filterLimit = (LimitFilter) filter;
            filterLimit.setComparator(null);
            return filterLimit.extractPage(set);
            }
        else
            {
            return set;
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    public java.util.Set entrySet(com.tangosol.util.Filter filter, java.util.Comparator comparator)
        {
        // import com.tangosol.util.ImmutableArrayList;
        // import com.tangosol.util.comparator.EntryComparator;
        // import com.tangosol.util.comparator.SafeComparator;
        // import com.tangosol.util.filter.EntryFilter;
        // import com.tangosol.util.filter.LimitFilter;
        // import java.util.Arrays;
        // import java.util.Comparator;
        // import java.util.Set;
        
        LimitFilter filterLimit = null;
        if (filter instanceof LimitFilter)
            {
            filterLimit = (LimitFilter) filter;
            filter      = filterLimit.getFilter();
        
            filterLimit.setComparator(
                comparator == null ? SafeComparator.INSTANCE : comparator);
            }
        
        Set      setEntry = entrySet(filter);
        Object[] aEntry   = setEntry.toArray();
        
        Comparator compEntry = new EntryComparator(comparator);
        Arrays.sort(aEntry, compEntry);
        
        Set set = new ImmutableArrayList(aEntry);
        
        if (filterLimit != null)
            {
            filterLimit.setComparator(compEntry);
        
            set = filterLimit.extractPage(set);
        
            filterLimit.setComparator(comparator); // for debug output only
            }
        
        return set;
        }
    
    // From interface: com.tangosol.util.MapListener
    public void entryUpdated(com.tangosol.util.MapEvent evt)
        {
        translateMapEvent(evt);
        }
    
    // From interface: com.tangosol.net.NamedCache
    public java.util.Map getAll(java.util.Collection colKeys)
        {
        // import com.tangosol.net.cache.CacheMap;
        // import java.util.HashMap;
        // import java.util.Iterator;
        // import java.util.Map;
        
        Map map = getActualMap();
        if (map instanceof CacheMap)
            {
            return ((CacheMap) map).getAll(colKeys);
            }
        else
            {
            Map mapResult = new HashMap(colKeys.size()); 
            for (Iterator iter = colKeys.iterator(); iter.hasNext(); )
                {
                Object oKey = iter.next();
                Object oVal = get(oKey);
                if (oVal != null || containsKey(oKey))
                    {
                    mapResult.put(oKey, oVal);
                    }
                }
            return mapResult;
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Accessor for the property "CacheName"
    /**
    * Getter for property CacheName.<p>
    */
    public String getCacheName()
        {
        return __m_CacheName;
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Accessor for the property "CacheService"
    /**
    * Getter for property CacheService.<p>
    */
    public com.tangosol.net.CacheService getCacheService()
        {
        return ($Module) get_Module();
        }
    
    // Accessor for the property "ListenerSupport"
    /**
    * Getter for property ListenerSupport.<p>
    */
    public com.tangosol.util.MapListenerSupport getListenerSupport()
        {
        return __m_ListenerSupport;
        }
    
    public void invalidate()
        {
        // import com.tangosol.net.BackingMapManager;
        // import com.tangosol.util.Filter;
        // import com.tangosol.util.MapListenerSupport as Support;
        // import java.util.Iterator;
        
        Support support = getListenerSupport();
        synchronized (support)
            {
            if (!support.isEmpty())
                {
                for (Iterator iter = support.getFilterSet().iterator(); iter.hasNext();)
                    {
                    removeMapListener(this, (Filter) iter.next());
                    }
                for (Iterator iter = support.getKeySet().iterator(); iter.hasNext();)
                    {
                    removeMapListener(this, (Object) iter.next());
                    }
                support.clear();
                }
            }
        
        BackingMapManager manager = getCacheService().getBackingMapManager();
        if (manager != null)
            {
            manager.releaseBackingMap(getCacheName(), getActualMap());
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    public boolean isActive()
        {
        return (($Module) get_Module()).getCacheHandlerMap().get(getCacheName()) == this;
        }
    
    // From interface: com.tangosol.net.NamedCache
    public java.util.Set keySet(com.tangosol.util.Filter filter)
        {
        // import com.tangosol.util.filter.EntryFilter;
        // import com.tangosol.util.filter.LimitFilter;
        // import java.util.HashSet;
        // import java.util.Iterator;
        // import java.util.Map$Entry as Entry;
        // import java.util.Set;
        
        if (filter == null)
            {
            return keySet();
            }
        
        Set set = new HashSet();
        for (Iterator iter = entrySet().iterator(); iter.hasNext();)
            {
            Entry entry = (Entry) iter.next();
        
            if (filter instanceof EntryFilter
                    ? ((EntryFilter) filter).evaluateEntry(entry)
                    : filter.evaluate(entry.getValue()))
                {
                set.add(entry.getKey());
                }
            }
        
        if (filter instanceof LimitFilter)
            {
            LimitFilter filterLimit = (LimitFilter) filter;
            filterLimit.setComparator(null);
            return filterLimit.extractPage(set);
            }
        else
            {
            return set;
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    public Object put(Object oKey, Object oValue, long cMillis)
        {
        // import com.tangosol.net.cache.CacheMap;
        // import java.util.Map;
        
        Map map = getActualMap();
        if (map instanceof CacheMap)
            {
            return ((CacheMap) map).put(oKey, oValue, cMillis);
            }
        else if (cMillis <= 0)
            {
            return put(oKey, oValue);
            }
        else
            {
            throw new UnsupportedOperationException(
                "Class \"" + map.getClass().getName() +
                "\" does not implement CacheMap interface");
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void release()
        {
        getCacheService().releaseCache(this);
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void removeIndex(com.tangosol.util.ValueExtractor extractor)
        {
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Declared at the super level
    public void removeMapListener(com.tangosol.util.MapListener listener)
        {
        // import com.tangosol.util.Filter;
        
        removeMapListener(listener, (Filter) null);
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Declared at the super level
    public void removeMapListener(com.tangosol.util.MapListener listener, com.tangosol.util.Filter filter)
        {
        // import com.tangosol.util.Filter;
        // import com.tangosol.util.MapListenerSupport as Support;
        
        if (listener == this)
            {
            super.removeMapListener(this, filter);
            }
        else
            {
            Support support = getListenerSupport();
            synchronized (support)
                {
                boolean fWasStandard = support.containsStandardListeners(filter);
        
                support.removeListener(listener, filter);
        
                if (support.isEmpty(filter))
                    {
                    removeMapListener(this, filter);
                    }
                else
                    {
                    if (fWasStandard && !support.containsStandardListeners(filter))
                        {
                        // replace standard with lite
                        removeMapListener(this, filter);
                        addMapListener(this, filter, true);
                        }
                    }
                }
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Declared at the super level
    public void removeMapListener(com.tangosol.util.MapListener listener, Object oKey)
        {
        // import com.tangosol.util.MapListenerSupport as Support;
        
        if (listener == this)
            {
            super.removeMapListener(this, oKey);
            }
        else
            {
            Support support = getListenerSupport();
            synchronized (support)
                {
                boolean fWasStandard = support.containsStandardListeners(oKey);
        
                support.removeListener(listener, oKey);
        
                if (support.isEmpty(oKey))
                    {
                    removeMapListener(this, oKey);
                    }
                else
                    {
                    if (fWasStandard && !support.containsStandardListeners(oKey))
                        {
                        // replace standard with lite
                        removeMapListener(this, oKey);
                        addMapListener(this, oKey, true);
                        }
                    }
                }
            }
        }
    
    // Accessor for the property "CacheName"
    /**
    * Setter for property CacheName.<p>
    */
    public void setCacheName(String sName)
        {
        __m_CacheName = sName;
        }
    
    // Accessor for the property "ListenerSupport"
    /**
    * Setter for property ListenerSupport.<p>
    */
    protected void setListenerSupport(com.tangosol.util.MapListenerSupport support)
        {
        __m_ListenerSupport = support;
        }
    
    // Declared at the super level
    public String toString()
        {
        StringBuffer sb = new StringBuffer();
        
        sb.append(get_Name())
          .append("{Name=")
          .append(getCacheName())
          .append(", ServiceName=")
          .append(getCacheService().getInfo().getServiceName())
          .append('}');
        
        return sb.toString();
        }
    
    protected void translateMapEvent(com.tangosol.util.MapEvent evt)
        {
        // import com.tangosol.util.MapListenerSupport as Support;
        
        // ensure lazy event data access
        evt = Support.convertEvent(evt, this, null, null);
        getListenerSupport().fireEvent(evt, true);
        }
    }
