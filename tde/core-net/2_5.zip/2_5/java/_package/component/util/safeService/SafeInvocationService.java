/* Class
*     _package.component.util.safeService.SafeInvocationService
*/

package _package.component.util.safeService;

/*
* Integrates
*     com.tangosol.net.InvocationService
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class SafeInvocationService
        extends    _package.component.util.SafeService
        implements com.tangosol.net.InvocationService
    {
    // Fields declarations
    
    // Default constructor
    public SafeInvocationService()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public SafeInvocationService(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setSafeServiceState(0);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new SafeInvocationService();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/safeService/SafeInvocationService".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ com.tangosol.net.InvocationService integration
    // Access optimization
    // properties integration
    // methods integration
    public void execute(com.tangosol.net.Invocable task, java.util.Set setMembers, com.tangosol.net.InvocationObserver observer)
        {
        ((com.tangosol.net.InvocationService) getRunningService()).execute(task, setMembers, observer);
        }
    public java.util.Map query(com.tangosol.net.Invocable task, java.util.Set setMembers)
        {
        return ((com.tangosol.net.InvocationService) getRunningService()).query(task, setMembers);
        }
    //-- com.tangosol.net.InvocationService integration
    }
