/* Class
*     _package.component.util.daemon.queueProcessor.packetProcessor.PacketPublisher$Queue
*/

package _package.component.util.daemon.queueProcessor.packetProcessor;

import _package.component.net.Packet;
import _package.component.net.packet.MessagePacket;
import java.util.List;

public class PacketPublisher$Queue
        extends    _package.component.util.daemon.QueueProcessor$Queue
    {
    // Fields declarations
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Iterator", _package.component.util.daemon.QueueProcessor$Queue$Iterator.get_CLASS());
        }
    
    // Default constructor
    public PacketPublisher$Queue()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PacketPublisher$Queue(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new PacketPublisher$Queue();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/daemon/queueProcessor/packetProcessor/PacketPublisher$Queue".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Declared at the super level
    /**
    * Appends the specified element to the end of this queue.
    * 
    * Queues may place limitations on what elements may be added to this Queue.
    *  In particular, some Queues will impose restrictions on the type of
    * elements that may be added. Queue implementations should clearly specify
    * in their documentation any restrictions on what elements may be added.
    * 
    * @param oElement element to be appended to this Queue
    * 
    * @return true (as per the general contract of the Collection.add method)
    * 
    * @throws ClassCastException if the class of the specified element prevents
    * it from being added to this Queue
    */
    public synchronized boolean add(Object oElement)
        {
        // import Component.Net.Packet;
        // import Component.Net.Packet.MessagePacket;
        // import java.util.List;
        
        Packet packet = (Packet) oElement;
        
        // move service 0 Messages to front of queue
        boolean fMod  = false;
        int     nType = packet.getPacketType();
        switch (nType)
            {
            case Packet.TYPE_BROADCAST:
            case Packet.TYPE_DIRECTED_ONE:
            case Packet.TYPE_DIRECTED_FEW:
            case Packet.TYPE_DIRECTED_MANY:
            case Packet.TYPE_SEQUEL_ONE:
            case Packet.TYPE_SEQUEL_FEW:
            case Packet.TYPE_SEQUEL_MANY:
                // Message Packets for Service 0 go at the front of the
                // queue
                if (((MessagePacket) packet).getServiceId() == 0)
                    {
                    List list = getElementList();
                    for (int i = 0, c = list.size(); i < c; ++i)
                        {
                        Object oCur = (Packet) list.get(i);
                        if (!(oCur instanceof MessagePacket
                                && ((MessagePacket) oCur).getServiceId() == 0))
                            {
                            list.add(i, packet);
                            notifyAll();
                            fMod = true;
                            break;
                            }
                        }
                    }
                break;
                
            case Packet.TYPE_REQUEST:
                // TODO
                throw new UnsupportedOperationException();
        
            case Packet.TYPE_ACK:
                return (($Module) get_Module()).getAckQueue().add(oElement);
        
            default:
                throw new IllegalStateException("unknown packet type: "
                    + packet.getPacketType());
            }
        
        // otherwise append to queue
        if (!fMod)
            {
            fMod = super.add(packet);
            }
        
        return fMod;
        }
    }
