/* Class
*     _package.component.util.SafeService
*/

package _package.component.util;

import com.tangosol.net.CacheService;
import com.tangosol.net.MemberEvent;
import com.tangosol.net.Service;
import com.tangosol.util.Base;
import com.tangosol.util.Listeners;

/*
* Integrates
*     com.tangosol.net.Service
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class SafeService
        extends    _package.component.Util
        implements com.tangosol.net.MemberListener,
                   com.tangosol.net.Service
    {
    // Fields declarations
    
    /**
    * Property Config
    *
    * The configuration data
    */
    private transient com.tangosol.run.xml.XmlElement __m_Config;
    
    /**
    * Property ContextClassLoader
    *
    * The context ClassLoader for this service.
    */
    private ClassLoader __m_ContextClassLoader;
    
    /**
    * Property MemberListeners
    *
    */
    private com.tangosol.util.Listeners __m_MemberListeners;
    
    /**
    * Property RunningService
    *
    * Calculated property returning a running service.
    * 
    * The only reason we have "getRunningService" in addition to
    * "ensureRunningService" is that RunningService property is used by the
    * integrator.
    */
    
    /**
    * Property SafeCluster
    *
    * The SafeCluster this SafeService belongs to.
    * 
    * @see SafeCluster#getSafeService
    */
    private transient SafeCluster __m_SafeCluster;
    
    /**
    * Property SafeServiceState
    *
    * The state of the SafeService; one of the SERVICE_ enums.
    */
    private int __m_SafeServiceState;
    
    /**
    * Property Service
    *
    * The actual (wrapped) Service.
    */
    private transient com.tangosol.net.Service __m_Service;
    
    /**
    * Property SERVICE_INITIAL
    *
    * The SafeService has been created but has not been started yet.
    */
    public static final int SERVICE_INITIAL = 0;
    
    /**
    * Property SERVICE_STARTED
    *
    * The SafeService has been started.
    */
    public static final int SERVICE_STARTED = 1;
    
    /**
    * Property SERVICE_STOPPED
    *
    * The SafeService has beed explicitely stopped
    */
    public static final int SERVICE_STOPPED = 2;
    
    /**
    * Property ServiceName
    *
    * Service name
    * @see SafeCluster#ensureService
    */
    private String __m_ServiceName;
    
    /**
    * Property ServiceType
    *
    * Service type
    * @see SafeCluster#ensureService
    */
    private String __m_ServiceType;
    
    // Default constructor
    public SafeService()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public SafeService(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setSafeServiceState(0);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        
        // state initialization: private properties
        try
            {
            __m_MemberListeners = new com.tangosol.util.Listeners();
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new SafeService();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/SafeService".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ com.tangosol.net.Service integration
    // Access optimization
    // properties integration
    // methods integration
    public com.tangosol.net.ServiceInfo getInfo()
        {
        return getRunningService().getInfo();
        }
    //-- com.tangosol.net.Service integration
    
    // From interface: com.tangosol.net.Service
    public synchronized void addMemberListener(com.tangosol.net.MemberListener l)
        {
        // import com.tangosol.net.Service;
        // import com.tangosol.util.Listeners;
        
        Listeners listeners = getMemberListeners();
        boolean   fWasEmpty = listeners.isEmpty();
        
        listeners.add(l);
        
        if (fWasEmpty && !listeners.isEmpty())
            {
            Service service = getService();
            if (service != null && service.isRunning())
                {
                service.addMemberListener(this);
                }
            }
        }
    
    protected void cleanup()
        {
        setService(null);
        setContextClassLoader(null);
        getMemberListeners().removeAll();
        }
    
    // From interface: com.tangosol.net.Service
    public void configure(com.tangosol.run.xml.XmlElement xmlConfig)
        {
        setConfig(xmlConfig);
        }
    
    public com.tangosol.net.Service ensureRunningService()
        {
        return getRunningService();
        }
    
    // From interface: com.tangosol.net.Service
    public com.tangosol.net.Cluster getCluster()
        {
        return getSafeCluster();
        }
    
    // Accessor for the property "Config"
    /**
    * Getter for property Config.<p>
    * The configuration data
    */
    public com.tangosol.run.xml.XmlElement getConfig()
        {
        return __m_Config;
        }
    
    // From interface: com.tangosol.net.Service
    // Accessor for the property "ContextClassLoader"
    /**
    * Getter for property ContextClassLoader.<p>
    * The context ClassLoader for this service.
    */
    public ClassLoader getContextClassLoader()
        {
        // import com.tangosol.util.Base;
        
        ClassLoader loader = __m_ContextClassLoader;
        if (loader == null)
            {
            loader = Base.getContextClassLoader(this);
            }
        return loader;
        }
    
    // Accessor for the property "MemberListeners"
    /**
    * Getter for property MemberListeners.<p>
    */
    protected com.tangosol.util.Listeners getMemberListeners()
        {
        return __m_MemberListeners;
        }
    
    // Accessor for the property "RunningService"
    /**
    * Getter for property RunningService.<p>
    * Calculated property returning a running service.
    * 
    * The only reason we have "getRunningService" in addition to
    * "ensureRunningService" is that RunningService property is used by the
    * integrator.
    */
    protected com.tangosol.net.Service getRunningService()
        {
        // import com.tangosol.net.MemberEvent;
        // import com.tangosol.net.Service;
        // import com.tangosol.util.Listeners;
        
        Service service = getService();
        if (service == null || !service.isRunning())
            {
            synchronized (this)
                {
                service = getService();
                switch (getSafeServiceState())
                    {
                    case SERVICE_INITIAL:
                        if (service == null)
                            {
                            setService(service = restartService());
                            }
                        else
                            {
                            startService(service);
                            }
                        break;
        
                    case SERVICE_STARTED:
                        if (service == null || !service.isRunning())
                            {
                            Listeners listeners = getMemberListeners();
                            if (!listeners.isEmpty())
                                {
                                MemberEvent evt = new MemberEvent(this, MemberEvent.MEMBER_LEFT,
                                    getSafeCluster().getLocalMember());
                                evt.dispatch(listeners);
                                }
                            setService(service = null); // release memory before restarting
        
                            // restart the actual service
                            _trace("Restarting Service: " + getServiceName(), 3);
        
                            setService(service = restartService());
                            if (!listeners.isEmpty())
                                {
                                MemberEvent evt = new MemberEvent(this, MemberEvent.MEMBER_JOINED,
                                    getSafeCluster().getLocalMember());
                                evt.dispatch(listeners);
                                }
                            }
                        break;
        
                    case SERVICE_STOPPED:
                        throw new IllegalStateException("SafeService was explicitly stopped");
                    }
                }
            }
        return service;
        }
    
    // Accessor for the property "SafeCluster"
    /**
    * Getter for property SafeCluster.<p>
    * The SafeCluster this SafeService belongs to.
    * 
    * @see SafeCluster#getSafeService
    */
    public SafeCluster getSafeCluster()
        {
        return __m_SafeCluster;
        }
    
    // Accessor for the property "SafeServiceState"
    /**
    * Getter for property SafeServiceState.<p>
    * The state of the SafeService; one of the SERVICE_ enums.
    */
    public int getSafeServiceState()
        {
        return __m_SafeServiceState;
        }
    
    // Accessor for the property "Service"
    /**
    * Getter for property Service.<p>
    * The actual (wrapped) Service.
    */
    public com.tangosol.net.Service getService()
        {
        return __m_Service;
        }
    
    // Accessor for the property "ServiceName"
    /**
    * Getter for property ServiceName.<p>
    * Service name
    * @see SafeCluster#ensureService
    */
    public String getServiceName()
        {
        return __m_ServiceName;
        }
    
    // Accessor for the property "ServiceType"
    /**
    * Getter for property ServiceType.<p>
    * Service type
    * @see SafeCluster#ensureService
    */
    public String getServiceType()
        {
        return __m_ServiceType;
        }
    
    // From interface: com.tangosol.net.Service
    public boolean isRunning()
        {
        // import com.tangosol.net.Service;
        
        Service service = getService();
        return service != null && getService().isRunning();
        }
    
    // From interface: com.tangosol.net.MemberListener
    public void memberJoined(com.tangosol.net.MemberEvent evt)
        {
        translateEvent(evt);
        }
    
    // From interface: com.tangosol.net.MemberListener
    public void memberLeaving(com.tangosol.net.MemberEvent evt)
        {
        translateEvent(evt);
        }
    
    // From interface: com.tangosol.net.MemberListener
    public void memberLeft(com.tangosol.net.MemberEvent evt)
        {
        translateEvent(evt);
        }
    
    // From interface: com.tangosol.net.Service
    public synchronized void removeMemberListener(com.tangosol.net.MemberListener l)
        {
        // import com.tangosol.net.Service;
        // import com.tangosol.util.Listeners;
        
        Listeners listeners = getMemberListeners();
        if (!listeners.isEmpty())
            {
            listeners.remove(l);
            if (listeners.isEmpty())
                {
                Service service = getService();
                if (service != null && service.isRunning())
                    {
                    service.removeMemberListener(this);
                    }
                }
            }
        }
    
    protected com.tangosol.net.Service restartService()
        {
        // import com.tangosol.net.CacheService;
        // import com.tangosol.net.Service;
        
        String  sServiceName = getServiceName();
        String  sServiceType = getServiceType();
        Service service;
        
        if (sServiceType.equals(CacheService.TYPE_LOCAL))
            {
            service = getSafeCluster().
                ensureLocalService(sServiceName, sServiceType);
            }
        else
            {
            service = getSafeCluster().ensureRunningCluster().
                ensureService(sServiceName, sServiceType);
            }
        startService(service);
        
        return service;
        }
    
    // Accessor for the property "Config"
    /**
    * Setter for property Config.<p>
    * The configuration data
    */
    public void setConfig(com.tangosol.run.xml.XmlElement xmlConfig)
        {
        __m_Config = xmlConfig;
        }
    
    // From interface: com.tangosol.net.Service
    // Accessor for the property "ContextClassLoader"
    /**
    * Setter for property ContextClassLoader.<p>
    * The context ClassLoader for this service.
    */
    public void setContextClassLoader(ClassLoader loader)
        {
        // import com.tangosol.net.Service;
        
        __m_ContextClassLoader = (loader);
        
        Service service = getService();
        if (service != null)
            {
            service.setContextClassLoader(loader);
            }
        }
    
    // Accessor for the property "MemberListeners"
    /**
    * Setter for property MemberListeners.<p>
    */
    private void setMemberListeners(com.tangosol.util.Listeners listeners)
        {
        __m_MemberListeners = listeners;
        }
    
    // Accessor for the property "SafeCluster"
    /**
    * Setter for property SafeCluster.<p>
    * The SafeCluster this SafeService belongs to.
    * 
    * @see SafeCluster#getSafeService
    */
    public void setSafeCluster(SafeCluster cluster)
        {
        __m_SafeCluster = cluster;
        }
    
    // Accessor for the property "SafeServiceState"
    /**
    * Setter for property SafeServiceState.<p>
    * The state of the SafeService; one of the SERVICE_ enums.
    */
    protected void setSafeServiceState(int nState)
        {
        __m_SafeServiceState = nState;
        }
    
    // Accessor for the property "Service"
    /**
    * Setter for property Service.<p>
    * The actual (wrapped) Service.
    */
    public void setService(com.tangosol.net.Service service)
        {
        __m_Service = service;
        }
    
    // Accessor for the property "ServiceName"
    /**
    * Setter for property ServiceName.<p>
    * Service name
    * @see SafeCluster#ensureService
    */
    public void setServiceName(String sName)
        {
        __m_ServiceName = sName;
        }
    
    // Accessor for the property "ServiceType"
    /**
    * Setter for property ServiceType.<p>
    * Service type
    * @see SafeCluster#ensureService
    */
    public void setServiceType(String sType)
        {
        __m_ServiceType = sType;
        }
    
    // From interface: com.tangosol.net.Service
    public synchronized void shutdown()
        {
        // import com.tangosol.net.Service;
        
        if (getSafeServiceState() != SERVICE_STOPPED)
            {
            Service service = getService();
            if (service != null)
                {
                synchronized (service)
                    {
                    if (service.isRunning())
                        {
                        service.shutdown();
                        }
                    }
                }
            cleanup();
            setSafeServiceState(SERVICE_STOPPED);
            }
        }
    
    // From interface: com.tangosol.net.Service
    public synchronized void start()
        {
        if (getSafeServiceState() == SERVICE_STOPPED)
            {
            // allow restart after explicit stop
            setSafeServiceState(SERVICE_INITIAL);
            }
        
        try
            {
            ensureRunningService();
            }
        finally
            {
            // SERVICE_STARTED indicates that "start" was called
            setSafeServiceState(SERVICE_STARTED);
            }
        }
    
    protected void startService(com.tangosol.net.Service service)
        {
        // import com.tangosol.util.Listeners;
        
        service.setContextClassLoader(getContextClassLoader());
        service.configure(getConfig());
        
        Listeners listeners = getMemberListeners();
        if (!listeners.isEmpty())
            {
            service.addMemberListener(this);
            }
        
        service.start();
        }
    
    // From interface: com.tangosol.net.Service
    public synchronized void stop()
        {
        // import com.tangosol.net.Service;
        
        if (getSafeServiceState() != SERVICE_STOPPED)
            {
            Service service = getService();
            if (service != null)
                {
                synchronized (service)
                    {
                    if (service.isRunning())
                        {
                        service.stop();
                        }
                    }
                }
            cleanup();
            setSafeServiceState(SERVICE_STOPPED);
            }
        }
    
    // Declared at the super level
    public String toString()
        {
        // import com.tangosol.net.Service;
        
        Service service = getService();
        return get_Name() + ": " +
            (service == null ? "STOPPED" : service.toString());
        }
    
    protected void translateEvent(com.tangosol.net.MemberEvent evt)
        {
        // import com.tangosol.net.MemberEvent;
        // import com.tangosol.net.Service;
        // import com.tangosol.util.Listeners;
        
        // allow for post-mortem events
        Service service = getService();
        if (service == evt.getSource() || service == null)
            {
            Listeners listeners = getMemberListeners();
            if (!listeners.isEmpty())
                {
                MemberEvent evtSafe = new MemberEvent(this, evt.getId(), evt.getMember());
                evtSafe.dispatch(listeners);
                }
            }
        }
    }
