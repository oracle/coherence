/* Class
*     _package.component.util.safeService.safeCacheService.SafeDistributedCacheService
*/

package _package.component.util.safeService.safeCacheService;

/*
* Integrates
*     com.tangosol.net.DistributedCacheService
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class SafeDistributedCacheService
        extends    _package.component.util.safeService.SafeCacheService
        implements com.tangosol.net.DistributedCacheService
    {
    // Fields declarations
    
    /**
    * Property BackupCount
    *
    */
    
    /**
    * Property LocalStorageEnabled
    *
    */
    
    /**
    * Property PartitionCount
    *
    */
    
    /**
    * Property StorageEnabledMembers
    *
    */
    
    // Default constructor
    public SafeDistributedCacheService()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public SafeDistributedCacheService(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setNamedCacheMap(new com.tangosol.util.SafeHashMap());
            setSafeServiceState(0);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new SafeDistributedCacheService();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/safeService/safeCacheService/SafeDistributedCacheService".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ com.tangosol.net.DistributedCacheService integration
    // Access optimization
    // properties integration
    // methods integration
    /**
    * Getter for property BackupCount.<p>
    */
    public int getBackupCount()
        {
        return ((com.tangosol.net.DistributedCacheService) getRunningCacheService()).getBackupCount();
        }
    public com.tangosol.net.Member getKeyOwner(Object oKey)
        {
        return ((com.tangosol.net.DistributedCacheService) getRunningCacheService()).getKeyOwner(oKey);
        }
    /**
    * Getter for property PartitionCount.<p>
    */
    public int getPartitionCount()
        {
        return ((com.tangosol.net.DistributedCacheService) getRunningCacheService()).getPartitionCount();
        }
    /**
    * Getter for property StorageEnabledMembers.<p>
    */
    public java.util.Set getStorageEnabledMembers()
        {
        return ((com.tangosol.net.DistributedCacheService) getRunningCacheService()).getStorageEnabledMembers();
        }
    /**
    * Getter for property LocalStorageEnabled.<p>
    */
    public boolean isLocalStorageEnabled()
        {
        return ((com.tangosol.net.DistributedCacheService) getRunningCacheService()).isLocalStorageEnabled();
        }
    //-- com.tangosol.net.DistributedCacheService integration
    }
