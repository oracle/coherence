/* Class
*     _package.component.util.ConcurrentMap
*/

package _package.component.util;

import _package.component.util.collections.wrapperSet.EntrySet;
import _package.component.util.collections.wrapperSet.KeySet;

/**
* Simple implementation of ConcurrentMap (and ObservableMap). This component is
* a trivial integration of com.tangosol.util.WrapperConcurrentMap.
* 
* Note: the ConcurrentMap has to be instantiated using _initFeed(Map)
* constructor.
* 
* Known subclasses LocalCache$CacheHandler.
*/
/*
* Integrates
*     com.tangosol.util.WrapperConcurrentMap
*     using Component.Dev.Compiler.Integrator.AbstractBean.JavaBean
*/
public class ConcurrentMap
        extends    _package.component.Util
        implements com.tangosol.util.ConcurrentMap,
                   com.tangosol.util.ObservableMap
    {
    // Fields declarations
    
    /**
    * Property ActualMap
    *
    * The actual map.
    * <b>Note: direct modifications of the returned map may cause an
    * unpredictable behavior of the ConcurrentMap.</b>
    */
    
    // fields used by the integration model:
    private sink_ConcurrentMap __sink;
    private com.tangosol.util.WrapperConcurrentMap __feed;
    
    // Default constructor
    public ConcurrentMap()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public ConcurrentMap(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new ConcurrentMap();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/ConcurrentMap".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ com.tangosol.util.WrapperConcurrentMap integration
    // Access optimization
    /**
    * Setter for property _Sink.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Sink(Object pSink)
        {
        __sink = (sink_ConcurrentMap) pSink;
        super.set_Sink(pSink);
        }
    /**
    * Setter for property _Feed.<p>
    * Property used by Component Intergation. This property is not meant to be
    * designed directly.
    */
    public void set_Feed(Object pFeed)
        {
        __feed = (com.tangosol.util.WrapperConcurrentMap) pFeed;
        super.set_Feed(pFeed);
        }
    private void _initFeed$AutoGen(java.util.Map map)
        {
        jb_ConcurrentMap.__tloPeer.setObject(this);
        new jb_ConcurrentMap(map, this, false); // this sets the Sink which sets the Feed
        __init();
        }
    /**
    * Integratee constructor
    */
    public void _initFeed(java.util.Map map)
        {
        _initFeed$AutoGen(map);
        }
    private void _initFeed$AutoGen(java.util.Map map, boolean fEnforceLocking, long cWaitMillis)
        {
        jb_ConcurrentMap.__tloPeer.setObject(this);
        new jb_ConcurrentMap(map, fEnforceLocking, cWaitMillis, this, false); // this sets the Sink which sets the Feed
        __init();
        }
    /**
    * Integratee constructor
    */
    public void _initFeed(java.util.Map map, boolean fEnforceLocking, long cWaitMillis)
        {
        _initFeed$AutoGen(map, fEnforceLocking, cWaitMillis);
        }
    // properties integration
    // methods integration
    public void addMapListener(com.tangosol.util.MapListener listener)
        {
        __sink.addMapListener(listener);
        }
    public void addMapListener(com.tangosol.util.MapListener listener, com.tangosol.util.Filter filter, boolean fLite)
        {
        __sink.addMapListener(listener, filter, fLite);
        }
    public void addMapListener(com.tangosol.util.MapListener listener, Object oKey, boolean fLite)
        {
        __sink.addMapListener(listener, oKey, fLite);
        }
    public void clear()
        {
        __sink.clear();
        }
    public boolean containsKey(Object oKey)
        {
        return __sink.containsKey(oKey);
        }
    public boolean containsValue(Object oValue)
        {
        return __sink.containsValue(oValue);
        }
    private java.util.Set entrySet$Router()
        {
        return __sink.entrySet();
        }
    public java.util.Set entrySet()
        {
        // import Component.Util.Collections.WrapperSet.EntrySet;
        
        return EntrySet.instantiate(entrySet$Router(), this);

        }
    public Object get(Object oKey)
        {
        return __sink.get(oKey);
        }
    /**
    * Getter for property ActualMap.<p>
    * The actual map.
    * <b>Note: direct modifications of the returned map may cause an
    * unpredictable behavior of the ConcurrentMap.</b>
    */
    public java.util.Map getActualMap()
        {
        return __sink.getMap();
        }
    private java.util.Set keySet$Router()
        {
        return __sink.keySet();
        }
    public java.util.Set keySet()
        {
        // import Component.Util.Collections.WrapperSet.KeySet;
        
        return KeySet.instantiate(keySet$Router(), this);

        }
    public boolean lock(Object oKey)
        {
        return __sink.lock(oKey);
        }
    public boolean lock(Object oKey, long cWait)
        {
        return __sink.lock(oKey, cWait);
        }
    public Object put(Object oKey, Object oValue)
        {
        return __sink.put(oKey, oValue);
        }
    public void putAll(java.util.Map map)
        {
        __sink.putAll(map);
        }
    public Object remove(Object oKey)
        {
        return __sink.remove(oKey);
        }
    public void removeMapListener(com.tangosol.util.MapListener listener)
        {
        __sink.removeMapListener(listener);
        }
    public void removeMapListener(com.tangosol.util.MapListener listener, com.tangosol.util.Filter filter)
        {
        __sink.removeMapListener(listener, filter);
        }
    public void removeMapListener(com.tangosol.util.MapListener listener, Object oKey)
        {
        __sink.removeMapListener(listener, oKey);
        }
    public int size()
        {
        return __sink.size();
        }
    public boolean unlock(Object oKey)
        {
        return __sink.unlock(oKey);
        }
    public java.util.Collection values()
        {
        return __sink.values();
        }
    //-- com.tangosol.util.WrapperConcurrentMap integration
    
    // From interface: com.tangosol.util.ConcurrentMap
    // From interface: com.tangosol.util.ObservableMap
    public boolean isEmpty()
        {
        return false;
        }
    
    // Declared at the super level
    public String toString()
        {
        return getActualMap().toString();
        }
    }
