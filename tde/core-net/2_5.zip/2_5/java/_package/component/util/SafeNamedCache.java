/* Class
*     _package.component.util.SafeNamedCache
*/

package _package.component.util;

import com.tangosol.net.Cluster;
import com.tangosol.net.NamedCache;
import com.tangosol.net.Service;
import com.tangosol.util.Filter;
import com.tangosol.util.MapListenerSupport$SynchronousListener; // as SyncListener
import com.tangosol.util.MapListenerSupport; // as Support
import java.util.Iterator;

/*
* Integrates
*     com.tangosol.net.NamedCache
*     using Component.Dev.Compiler.Integrator.Wrapper
*/
public class SafeNamedCache
        extends    _package.component.Util
        implements com.tangosol.net.NamedCache,
                   com.tangosol.util.MapListener
    {
    // Fields declarations
    
    /**
    * Property CacheName
    *
    */
    private transient String __m_CacheName;
    
    /**
    * Property ClassLoader
    *
    */
    private transient ClassLoader __m_ClassLoader;
    
    /**
    * Property ListenerSupport
    *
    */
    private transient com.tangosol.util.MapListenerSupport __m_ListenerSupport;
    
    /**
    * Property NamedCache
    *
    * Actual (wrapped) NamedCache
    */
    private com.tangosol.net.NamedCache __m_NamedCache;
    
    /**
    * Property Released
    *
    * Specifies whether or not the underlying NamedCache has been explicitly
    * released.
    */
    private boolean __m_Released;
    
    /**
    * Property RunningNamedCache
    *
    * Calculated property returning a running NamedCache.
    * 
    * The only reason we have "getRunningNamedCache" in addition to
    * "ensureRunningNamedCache" is that RunningNamedCache property is used by
    * the integrator.
    */
    
    /**
    * Property SafeCacheService
    *
    */
    private _package.component.util.safeService.SafeCacheService __m_SafeCacheService;
    
    // Default constructor
    public SafeNamedCache()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public SafeNamedCache(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setListenerSupport(new com.tangosol.util.MapListenerSupport());
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new SafeNamedCache();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/SafeNamedCache".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ com.tangosol.net.NamedCache integration
    // Access optimization
    // properties integration
    // methods integration
    public void addIndex(com.tangosol.util.ValueExtractor extractor, boolean fOrdered, java.util.Comparator comparator)
        {
        getRunningNamedCache().addIndex(extractor, fOrdered, comparator);
        }
    public void clear()
        {
        getRunningNamedCache().clear();
        }
    public boolean containsKey(Object oKey)
        {
        return getRunningNamedCache().containsKey(oKey);
        }
    public boolean containsValue(Object oValue)
        {
        return getRunningNamedCache().containsValue(oValue);
        }
    public java.util.Set entrySet()
        {
        return getRunningNamedCache().entrySet();
        }
    public java.util.Set entrySet(com.tangosol.util.Filter filter)
        {
        return getRunningNamedCache().entrySet(filter);
        }
    public java.util.Set entrySet(com.tangosol.util.Filter filter, java.util.Comparator comparator)
        {
        return getRunningNamedCache().entrySet(filter, comparator);
        }
    public Object get(Object oKey)
        {
        return getRunningNamedCache().get(oKey);
        }
    public java.util.Map getAll(java.util.Collection col)
        {
        return getRunningNamedCache().getAll(col);
        }
    private boolean isActive$Router()
        {
        return getRunningNamedCache().isActive();
        }
    public boolean isActive()
        {
        try
            {
            return getNamedCache().isActive();
            }
        catch (RuntimeException e)
            {
            return false;
            }
        }
    public boolean isEmpty()
        {
        return getRunningNamedCache().isEmpty();
        }
    public java.util.Set keySet()
        {
        return getRunningNamedCache().keySet();
        }
    public java.util.Set keySet(com.tangosol.util.Filter filter)
        {
        return getRunningNamedCache().keySet(filter);
        }
    public boolean lock(Object oKey)
        {
        return getRunningNamedCache().lock(oKey);
        }
    public boolean lock(Object oKey, long cMillis)
        {
        return getRunningNamedCache().lock(oKey, cMillis);
        }
    public Object put(Object oKey, Object oValue)
        {
        return getRunningNamedCache().put(oKey, oValue);
        }
    public Object put(Object oKey, Object oValue, long cMillis)
        {
        return getRunningNamedCache().put(oKey, oValue, cMillis);
        }
    public void putAll(java.util.Map map)
        {
        getRunningNamedCache().putAll(map);
        }
    public Object remove(Object oKey)
        {
        return getRunningNamedCache().remove(oKey);
        }
    public void removeIndex(com.tangosol.util.ValueExtractor extractor)
        {
        getRunningNamedCache().removeIndex(extractor);
        }
    public int size()
        {
        return getRunningNamedCache().size();
        }
    public boolean unlock(Object oKey)
        {
        return getRunningNamedCache().unlock(oKey);
        }
    public java.util.Collection values()
        {
        return getRunningNamedCache().values();
        }
    //-- com.tangosol.net.NamedCache integration
    
    // From interface: com.tangosol.net.NamedCache
    public void addMapListener(com.tangosol.util.MapListener listener)
        {
        // import com.tangosol.util.Filter;
        
        addMapListener(listener, (Filter) null, false);
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void addMapListener(com.tangosol.util.MapListener listener, com.tangosol.util.Filter filter, boolean fLite)
        {
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.util.Filter;
        // import com.tangosol.util.MapListenerSupport as Support;
        // import com.tangosol.util.MapListenerSupport$SynchronousListener as SyncListener;
        
        if (listener == this)
            {
            NamedCache cache = getNamedCache();
            try
                {
                cache.addMapListener(listener, filter, fLite);
                }
            catch (RuntimeException e)
                {
                if (cache != null && cache.isActive() &&
                        cache.getCacheService().isRunning())
                    {
                    throw e;
                    }
                // NamedCache has been invalidated
                }
            }
        else if (listener instanceof SyncListener)
            {
            getRunningNamedCache().addMapListener(listener, filter, fLite);
            }
        else if (listener != null)
            {
            Support support = getListenerSupport();
            synchronized (support)
                {
                boolean fWasEmpty = support.isEmpty(filter);
                boolean fWasLite  = fWasEmpty || !support.containsStandardListeners(filter);
        
                if (fWasEmpty || (fWasLite && !fLite))
                    {
                    addMapListener(this, filter, fLite);
                    }
        
                support.addListener(listener, filter, fLite);
                }
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void addMapListener(com.tangosol.util.MapListener listener, Object oKey, boolean fLite)
        {
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.util.Filter;
        // import com.tangosol.util.MapListenerSupport as Support;
        // import com.tangosol.util.MapListenerSupport$SynchronousListener as SyncListener;
        
        if (listener == this)
            {
            NamedCache cache = getNamedCache();
            try
                {
                cache.addMapListener(listener, oKey, fLite);
                }
            catch (RuntimeException e)
                {
                if (cache != null && cache.isActive() &&
                        cache.getCacheService().isRunning())
                    {
                    throw e;
                    }
                // NamedCache has been invalidated
                }
            }
        else if (listener instanceof SyncListener)
            {
            getRunningNamedCache().addMapListener(listener, oKey, fLite);
            }
        else if (listener != null)
            {
            Support support = getListenerSupport();
            synchronized (support)
                {
                boolean fWasEmpty = support.isEmpty(oKey);
                boolean fWasLite  = fWasEmpty || !support.containsStandardListeners(oKey);
        
                if (fWasEmpty || (fWasLite && !fLite))
                    {
                    addMapListener(this, oKey, fLite);
                    }
        
                support.addListener(listener, oKey, fLite);
                }
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    public synchronized void destroy()
        {
        setReleased(true);
        releaseListeners();
        getSafeCacheService().destroyCache(this);
        setNamedCache(null);
        }
    
    public com.tangosol.net.NamedCache ensureRunningNamedCache()
        {
        return getRunningNamedCache();
        }
    
    // From interface: com.tangosol.util.MapListener
    public void entryDeleted(com.tangosol.util.MapEvent evt)
        {
        translateMapEvent(evt);
        }
    
    // From interface: com.tangosol.util.MapListener
    public void entryInserted(com.tangosol.util.MapEvent evt)
        {
        translateMapEvent(evt);
        }
    
    // From interface: com.tangosol.util.MapListener
    public void entryUpdated(com.tangosol.util.MapEvent evt)
        {
        translateMapEvent(evt);
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof SafeNamedCache)
            {
            return getRunningNamedCache().equals(((SafeNamedCache) obj).getRunningNamedCache());
            }
        return false;
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Accessor for the property "CacheName"
    /**
    * Getter for property CacheName.<p>
    */
    public String getCacheName()
        {
        return __m_CacheName;
        }
    
    // From interface: com.tangosol.net.NamedCache
    public com.tangosol.net.CacheService getCacheService()
        {
        return getSafeCacheService();

        }
    
    // Accessor for the property "ClassLoader"
    /**
    * Getter for property ClassLoader.<p>
    */
    public ClassLoader getClassLoader()
        {
        return __m_ClassLoader;
        }
    
    // Accessor for the property "ListenerSupport"
    /**
    * Getter for property ListenerSupport.<p>
    */
    public com.tangosol.util.MapListenerSupport getListenerSupport()
        {
        return __m_ListenerSupport;
        }
    
    // Accessor for the property "NamedCache"
    /**
    * Getter for property NamedCache.<p>
    * Actual (wrapped) NamedCache
    */
    public com.tangosol.net.NamedCache getNamedCache()
        {
        return __m_NamedCache;
        }
    
    // Accessor for the property "RunningNamedCache"
    /**
    * Getter for property RunningNamedCache.<p>
    * Calculated property returning a running NamedCache.
    * 
    * The only reason we have "getRunningNamedCache" in addition to
    * "ensureRunningNamedCache" is that RunningNamedCache property is used by
    * the integrator.
    */
    protected com.tangosol.net.NamedCache getRunningNamedCache()
        {
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.net.Cluster;
        // import com.tangosol.net.Service;
        
        NamedCache cache   = getNamedCache();
        Service    service = cache == null ? null : cache.getCacheService();
        if (service == null || !service.isRunning())
            {
            synchronized (this)
                {
                cache   = getNamedCache();
                service = cache == null ? null : cache.getCacheService();
                if (service == null || !service.isRunning())
                    {
                    if (isReleased())
                        {
                        throw new IllegalStateException("SafeNamedCache was explicitly released");
                        }
                    else
                        {
                        // restart the actual named cache
                        if (cache != null)
                            {
                            setNamedCache(null);
                            _trace("Restarting NamedCache: " + getCacheName(), 3);
                            }
                        setNamedCache(cache = restartNamedCache());
                        }
                    }
                }
            }
        return cache;
        }
    
    // Accessor for the property "SafeCacheService"
    /**
    * Getter for property SafeCacheService.<p>
    */
    public _package.component.util.safeService.SafeCacheService getSafeCacheService()
        {
        return __m_SafeCacheService;
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Declared at the super level
    public int hashCode()
        {
        return getRunningNamedCache().hashCode();
        }
    
    // Accessor for the property "Released"
    /**
    * Getter for property Released.<p>
    * Specifies whether or not the underlying NamedCache has been explicitly
    * released.
    */
    public boolean isReleased()
        {
        return __m_Released;
        }
    
    // From interface: com.tangosol.net.NamedCache
    public synchronized void release()
        {
        setReleased(true);
        releaseListeners();
        getSafeCacheService().releaseCache(this);
        setNamedCache(null);
        }
    
    protected void releaseListeners()
        {
        // import com.tangosol.util.Filter;
        // import com.tangosol.util.MapListenerSupport as Support;
        // import java.util.Iterator;
        
        Support support = getListenerSupport();
        synchronized (support)
            {
            if (!support.isEmpty())
                {
                for (Iterator iter = support.getFilterSet().iterator(); iter.hasNext();)
                    {
                    removeMapListener(this, (Filter) iter.next());
                    }
                for (Iterator iter = support.getKeySet().iterator(); iter.hasNext();)
                    {
                    removeMapListener(this, (Object) iter.next());
                    }
                }
            support.clear();
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void removeMapListener(com.tangosol.util.MapListener listener)
        {
        // import com.tangosol.util.Filter;
        
        removeMapListener(listener, (Filter) null);
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void removeMapListener(com.tangosol.util.MapListener listener, com.tangosol.util.Filter filter)
        {
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.util.Filter;
        // import com.tangosol.util.MapListenerSupport as Support;
        // import com.tangosol.util.MapListenerSupport$SynchronousListener as SyncListener;
        
        if (listener == this || listener instanceof SyncListener)
            {
            NamedCache cache = getNamedCache();
            try
                {
                cache.removeMapListener(listener, filter);
                }
            catch (RuntimeException e)
                {
                if (cache != null && cache.isActive() &&
                        cache.getCacheService().isRunning())
                    {
                    throw e;
                    }
                // NamedCache has been invalidated
                }
            }
        else if (listener != null)
            {
            Support support = getListenerSupport();
            synchronized (support)
                {
                boolean fWasStandard = support.containsStandardListeners(filter);
        
                support.removeListener(listener, filter);
        
                if (support.isEmpty(filter))
                    {
                    removeMapListener(this, filter);
                    }
                else
                    {
                    if (fWasStandard && !support.containsStandardListeners(filter))
                        {
                        // replace standard with lite
                        removeMapListener(this, filter);
                        addMapListener(this, filter, true);
                        }
                    }
                }
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void removeMapListener(com.tangosol.util.MapListener listener, Object oKey)
        {
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.util.Filter;
        // import com.tangosol.util.MapListenerSupport as Support;
        // import com.tangosol.util.MapListenerSupport$SynchronousListener as SyncListener;
        
        if (listener == this || listener instanceof SyncListener)
            {
            NamedCache cache = getNamedCache();
            try
                {
                cache.removeMapListener(listener, oKey);
                }
            catch (RuntimeException e)
                {
                if (cache != null && cache.isActive() &&
                        cache.getCacheService().isRunning())
                    {
                    throw e;
                    }
                // NamedCache has been invalidated
                }
            }
        else if (listener != null)
            {
            Support support = getListenerSupport();
            synchronized (support)
                {
                boolean fWasStandard = support.containsStandardListeners(oKey);
        
                support.removeListener(listener, oKey);
        
                if (support.isEmpty(oKey))
                    {
                    removeMapListener(this, oKey);
                    }
                else
                    {
                    if (fWasStandard && !support.containsStandardListeners(oKey))
                        {
                        // replace standard with lite
                        removeMapListener(this, oKey);
                        addMapListener(this, oKey, true);
                        }
                    }
                }
            }
        }
    
    protected com.tangosol.net.NamedCache restartNamedCache()
        {
        // import com.tangosol.net.NamedCache;
        // import com.tangosol.util.Filter;
        // import com.tangosol.util.MapListenerSupport as Support;
        // import java.util.Iterator;
        
        NamedCache cache = getSafeCacheService().ensureRunningCacheService().
                ensureCache(getCacheName(), getClassLoader());
        
        Support support = getListenerSupport();
        synchronized (support)
            {
            if (!support.isEmpty())
                {
                for (Iterator iter = support.getFilterSet().iterator(); iter.hasNext();)
                    {
                    Filter filter = (Filter) iter.next();
        
                    cache.addMapListener(this, filter,
                        !support.containsStandardListeners(filter));
                    }
                for (Iterator iter = support.getKeySet().iterator(); iter.hasNext();)
                    {
                    Object oKey = iter.next();
        
                    cache.addMapListener(this, oKey,
                        !support.containsStandardListeners(oKey));
                    }
                }
            }
        
        return cache;
        }
    
    // Accessor for the property "CacheName"
    /**
    * Setter for property CacheName.<p>
    */
    public void setCacheName(String sName)
        {
        __m_CacheName = sName;
        }
    
    // Accessor for the property "ClassLoader"
    /**
    * Setter for property ClassLoader.<p>
    */
    public void setClassLoader(ClassLoader loader)
        {
        __m_ClassLoader = loader;
        }
    
    // Accessor for the property "ListenerSupport"
    /**
    * Setter for property ListenerSupport.<p>
    */
    protected void setListenerSupport(com.tangosol.util.MapListenerSupport support)
        {
        __m_ListenerSupport = support;
        }
    
    // Accessor for the property "NamedCache"
    /**
    * Setter for property NamedCache.<p>
    * Actual (wrapped) NamedCache
    */
    public void setNamedCache(com.tangosol.net.NamedCache cache)
        {
        __m_NamedCache = cache;
        }
    
    // Accessor for the property "Released"
    /**
    * Setter for property Released.<p>
    * Specifies whether or not the underlying NamedCache has been explicitly
    * released.
    */
    public synchronized void setReleased(boolean fRelease)
        {
        __m_Released = fRelease;
        }
    
    // Accessor for the property "SafeCacheService"
    /**
    * Setter for property SafeCacheService.<p>
    */
    public void setSafeCacheService(_package.component.util.safeService.SafeCacheService service)
        {
        __m_SafeCacheService = service;
        }
    
    // Declared at the super level
    public String toString()
        {
        return get_Name() + ": " + getNamedCache();
        }
    
    protected void translateMapEvent(com.tangosol.util.MapEvent evt)
        {
        // import com.tangosol.util.MapListenerSupport as Support;
        
        if (evt.getSource() == getNamedCache())
            {
            // ensure lazy event data access
            evt = Support.convertEvent(evt, this, null, null);
            getListenerSupport().fireEvent(evt, true);
            }
        }
    }
