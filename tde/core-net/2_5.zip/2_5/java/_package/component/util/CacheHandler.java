/* Class
*     _package.component.util.CacheHandler
*/

package _package.component.util;

import _package.component.net.Lease;
import _package.component.net.message.LeaseMessage;
import _package.component.util.CacheEvent;
import _package.component.util.daemon.queueProcessor.Service;
import _package.component.util.daemon.queueProcessor.service.ReplicatedCache;
import com.tangosol.net.BackingMapManager;
import com.tangosol.net.BackingMapManager; // as Manager
import com.tangosol.net.ClusterException;
import com.tangosol.net.cache.CacheMap;
import com.tangosol.net.cache.LocalCache;
import com.tangosol.net.cache.OverflowMap;
import com.tangosol.run.component.EventDeathException;
import com.tangosol.run.xml.SimpleElement;
import com.tangosol.util.Base;
import com.tangosol.util.Binary;
import com.tangosol.util.Converter;
import com.tangosol.util.ConverterCollections;
import com.tangosol.util.Filter;
import com.tangosol.util.ImmutableArrayList;
import com.tangosol.util.Listeners;
import com.tangosol.util.MapEvent;
import com.tangosol.util.MapListener;
import com.tangosol.util.MapListenerSupport; // as Support
import com.tangosol.util.NullImplementation;
import com.tangosol.util.ObservableHashMap;
import com.tangosol.util.ObservableMap;
import com.tangosol.util.SafeHashMap;
import com.tangosol.util.SimpleEnumerator;
import com.tangosol.util.WrapperException;
import com.tangosol.util.comparator.EntryComparator;
import com.tangosol.util.comparator.SafeComparator;
import com.tangosol.util.filter.EntryFilter;
import com.tangosol.util.filter.LimitFilter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map$Entry; // as Entry
import java.util.Map;
import java.util.Set;

/**
* CacheHandler represents a named Cache handled by the ReplicatedCache service.
* During creation each handler is assigned an index that could be used to
* obtain this handler out of the indexed property "CacheHandler" maintained by
* the ReplicatedCache service. For the same index there could be a list of
* handlers that differ only by the value of ClassLoader property. The
* NextHandler property is used to maintain this list.
*/
public class CacheHandler
        extends    _package.component.Util
        implements com.tangosol.net.NamedCache,
                   com.tangosol.run.xml.XmlSerializable,
                   com.tangosol.util.ConcurrentMap,
                   com.tangosol.util.Converter,
                   com.tangosol.util.ObservableMap
    {
    // Fields declarations
    
    /**
    * Property Active
    *
    * Calculated property specifiying whether or not this handler is currently
    * active (has a valid ClassLoader)
    */
    
    /**
    * Property BackingMapListener
    *
    * BackingMap listener. Used only if a custom backing map manager uses an
    * ObservableMap to implement the local storage.
    */
    private transient com.tangosol.util.MapListener __m_BackingMapListener;
    
    /**
    * Property CacheIndex
    *
    * This index of this handler in the indexed CacheHandler property
    * maintained by the cache service.
    * 
    * @see ReplicatedCache#instantiateCacheHandler
    */
    private int __m_CacheIndex;
    
    /**
    * Property CacheName
    *
    * This name of the cache that is managed by this handler. It could only be
    * null if the cached resources started coming from another member, but the
    * Catalog has not been updated yet. It could only be empty (length == 0)
    * for the Catalog Cache handler.
    * 
    * @see ReplicatedCache#instantiateCacheHandler
    */
    private String __m_CacheName;
    
    /**
    * Property CacheService
    *
    */
    
    /**
    * Property ClassLoader
    *
    * ClassLoader that should be used by ResourceMessages to deserialize
    * resources that are managed by this handler. The only situations when the
    * ClassLoader could be null are:
    * <ul>
    * <li>the cache has already been replicated by the service, but no client
    * is yet connected to this map
    * <li>the client has called the "release" on the last copy of the cache
    * handler with a given name
    * </ul>
    * 
    * @see #getCachedResource
    */
    private transient ClassLoader __m_ClassLoader;
    
    /**
    * Property ConverterFromInternal
    *
    * A converter that takes service specific "transmittable" serializable
    * objects and converts them via deserialization (etc.) to the objects
    * expected by clients of the cache.
    */
    private transient com.tangosol.util.Converter __m_ConverterFromInternal;
    
    /**
    * Property ConverterToInternal
    *
    * A converter that takes ClassLoader dependent objects and converts them
    * via serialization into Binary objects.
    */
    private transient com.tangosol.util.Converter __m_ConverterToInternal;
    
    /**
    * Property IgnoreKey
    *
    * The key of a resource in the local storage that is currently being
    * processed by the service and therefore should be ignored by the
    * BackingMapListener.
    */
    private transient Object __m_IgnoreKey;
    
    /**
    * Property LeaseKeys
    *
    * Calculated property returning the Enumeration of <i>issued</i> lease keys.
    */
    
    /**
    * Property LeaseMap
    *
    * This Map assosiates resource keys with the corresponding Lease objects
    * for each leased resource. Its key set is a subset of the ResourceMap key
    * set.
    */
    private transient java.util.Map __m_LeaseMap;
    
    /**
    * Property ListenerSupport
    *
    * Registered listeners to the MapEvent notifications.
    */
    private transient com.tangosol.util.MapListenerSupport __m_ListenerSupport;
    
    /**
    * Property MAX_MAP_RETRIES
    *
    */
    public static final int MAX_MAP_RETRIES = 32;
    
    /**
    * Property NextHandler
    *
    * Reference to another handler with exact same proprties as this one except
    * the ClassLoader property
    */
    private transient CacheHandler __m_NextHandler;
    
    /**
    * Property ResourceKeys
    *
    * Calculated property returning the Enumeration of resource keys.
    */
    
    /**
    * Property ResourceMap
    *
    * This Map holds the resources assosiated with the Leases held in the
    * LeaseMap.
    */
    private transient java.util.Map __m_ResourceMap;
    
    /**
    * Property Service
    *
    */
    
    /**
    * Property StandardLeaseMillis
    *
    * The duration of a standard Lease in milliseconds for the resources
    * controlled by this CacheHandler.
    */
    private long __m_StandardLeaseMillis;
    
    /**
    * Property UseEventDaemon
    *
    * If true, all map events will be dispatched on the MapEventQueue thread;
    * otherwise on the service thread itself
    */
    private boolean __m_UseEventDaemon;
    
    /**
    * Property Valid
    *
    * Returns false iff this CacheHandler has been explicitely invalidated
    * (destroyed).
    */
    private boolean __m_Valid;
    
    /**
    * Property Validator
    *
    * Returns a new instance of default implementation of Validator interface.
    * 
    * @deprecated since Coherence 2.3
    */
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("BackingMapListener", CacheHandler$BackingMapListener.get_CLASS());
        __mapChildren.put("EntrySet", CacheHandler$EntrySet.get_CLASS());
        __mapChildren.put("KeySet", CacheHandler$KeySet.get_CLASS());
        __mapChildren.put("Validator", CacheHandler$Validator.get_CLASS());
        }
    
    // Default constructor
    public CacheHandler()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CacheHandler(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setCacheIndex(-1);
            setIgnoreKey(new java.lang.Object());
            setStandardLeaseMillis(20000L);
            setUseEventDaemon(true);
            setValid(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new CacheHandler();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/CacheHandler".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void addIndex(com.tangosol.util.ValueExtractor extractor, boolean fOrdered, java.util.Comparator comparator)
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ObservableMap
    public void addMapListener(com.tangosol.util.MapListener listener)
        {
        // import com.tangosol.util.Filter;
        
        addMapListener(listener, (Filter) null, false);
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ObservableMap
    public synchronized void addMapListener(com.tangosol.util.MapListener listener, com.tangosol.util.Filter filter, boolean fLite)
        {
        // import com.tangosol.util.MapListenerSupport as Support;
        
        _assert(listener != null);
        
        Support support = getListenerSupport();
        if (support == null)
            {
            setListenerSupport(support = new Support());
            }
        
        support.addListener(listener, filter, fLite);
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ObservableMap
    public synchronized void addMapListener(com.tangosol.util.MapListener listener, Object oKey, boolean fLite)
        {
        // import com.tangosol.util.MapListenerSupport as Support;
        
        _assert(listener != null);
        
        Support support = getListenerSupport();
        if (support == null)
            {
            setListenerSupport(support = new Support());
            }
        
        support.addListener(listener, oKey, fLite);
        }
    
    /**
    * Check the validity of this cache handler -- in other words wheter or not
    * this map is accessible by a client.
    * 
    * @exception IllegalStateException is thrown if the handler is not
    * currently active or the underlying service is not running
    */
    protected void checkAccess()
        {
        if (Thread.currentThread() != getService().getThread())
            {
            if (getClassLoader() == null)
                {
                throw new IllegalStateException("Map has been invalidated:\n" + this);
                }
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    // From interface: com.tangosol.util.ObservableMap
    public void clear()
        {
        // import java.util.Enumeration;
        
        for (Enumeration enum = getResourceKeys(); enum.hasMoreElements();)
            {
            Object oKey = enum.nextElement();
        
            remove(oKey, false);
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    // From interface: com.tangosol.util.ObservableMap
    public boolean containsKey(Object oKey)
        {
        checkAccess();
        
        return getResourceMap().containsKey(oKey);
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    // From interface: com.tangosol.util.ObservableMap
    public boolean containsValue(Object oValue)
        {
        checkAccess();
        
        return getResourceMap().containsValue(oValue);
        }
    
    // From interface: com.tangosol.util.Converter
    /**
    * Key-to-value conversion used by to create effective "value()" collection.
    * 
    * @see #values()
    */
    public Object convert(Object o)
        {
        return getCachedResource(o);
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void destroy()
        {
        getCacheService().destroyCache(this);
        }
    
    /**
    * Obtain a Lease for the specified resource. If the Lease doesn't exist a
    * new Lease object will be created
    * 
    * @param oKey  the resource key
    * 
    * @return  the Lease object for the specified resource
    * 
    * Note: the lease object should not be modified directly by a client.
    */
    public _package.component.net.Lease ensureLease(Object oKey)
        {
        // import Component.Net.Lease;
        // import java.util.Map;
        
        Lease lease = getLease(oKey);
        
        if (lease == null)
            {
            Map mapLease = getLeaseMap();
            synchronized (mapLease)
                {
                lease = getLease(oKey);
                if (lease == null)
                    {
                    lease = Lease.instantiate(getCacheIndex(), oKey, getService());
                    mapLease.put(oKey, lease);
                    }
                }
            }
        
        return lease;
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    // From interface: com.tangosol.util.ObservableMap
    public java.util.Set entrySet()
        {
        checkAccess();
        
        $EntrySet set = ($EntrySet) _newChild("EntrySet");
        set.setMap(this);
        set.setSet(getResourceMap().entrySet());
        
        return set;
        }
    
    // From interface: com.tangosol.net.NamedCache
    public java.util.Set entrySet(com.tangosol.util.Filter filter)
        {
        // import com.tangosol.util.filter.EntryFilter;
        // import com.tangosol.util.filter.LimitFilter;
        // import java.util.HashSet;
        // import java.util.Iterator;
        // import java.util.Map$Entry as Entry;
        // import java.util.Set;
        
        if (filter == null)
            {
            return entrySet();
            }
        
        Set set = new HashSet();
        for (Iterator iter = entrySet().iterator(); iter.hasNext();)
            {
            Entry entry = (Entry) iter.next();
        
            if (filter instanceof EntryFilter
                    ? ((EntryFilter) filter).evaluateEntry(entry)
                    : filter.evaluate(entry.getValue()))
                {
                set.add(entry);
                }
            }
        
        if (filter instanceof LimitFilter)
            {
            LimitFilter filterLimit = (LimitFilter) filter;
            filterLimit.setComparator(null);
            return filterLimit.extractPage(set);
            }
        else
            {
            return set;
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    public java.util.Set entrySet(com.tangosol.util.Filter filter, java.util.Comparator comparator)
        {
        // import com.tangosol.util.ImmutableArrayList;
        // import com.tangosol.util.comparator.EntryComparator;
        // import com.tangosol.util.comparator.SafeComparator;
        // import com.tangosol.util.filter.EntryFilter;
        // import com.tangosol.util.filter.LimitFilter;
        // import java.util.Arrays;
        // import java.util.Comparator;
        // import java.util.Set;
        
        LimitFilter filterLimit = null;
        if (filter instanceof LimitFilter)
            {
            filterLimit = (LimitFilter) filter;
            filter      = filterLimit.getFilter();
        
            filterLimit.setComparator(
                comparator == null ? SafeComparator.INSTANCE : comparator);
            }
        
        Set      setEntry = entrySet(filter);
        Object[] aEntry   = setEntry.toArray();
        
        Comparator compEntry = new EntryComparator(comparator);
        Arrays.sort(aEntry, compEntry);
        
        Set set = new ImmutableArrayList(aEntry);
        
        if (filterLimit != null)
            {
            filterLimit.setComparator(compEntry);
        
            set = filterLimit.extractPage(set);
        
            filterLimit.setComparator(comparator); // for debug output only
            }
        
        return set;
        }
    
    // From interface: com.tangosol.run.xml.XmlSerializable
    public void fromXml(com.tangosol.run.xml.XmlElement xml)
        {
        _assert(xml.getName().equals(get_Name()));
        
        setCacheName          (xml.getElement("CacheName")          .getString());
        setCacheIndex         (xml.getElement("CacheIndex")         .getInt());
        setStandardLeaseMillis(xml.getElement("StandardLeaseMillis").getLong());

        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    // From interface: com.tangosol.util.ObservableMap
    public Object get(Object oKey)
        {
        return getCachedResource(oKey);
        }
    
    // From interface: com.tangosol.net.NamedCache
    public java.util.Map getAll(java.util.Collection colKeys)
        {
        // import java.util.HashMap;
        // import java.util.Iterator;
        // import java.util.Map;
        
        Map mapResult = new HashMap(colKeys.size()); 
        for (Iterator iter = colKeys.iterator(); iter.hasNext(); )
            {
            Object oKey = iter.next();
            Object oVal = get(oKey);
            if (oVal != null || containsKey(oKey))
                {
                mapResult.put(oKey, oVal);
                }
            }
        return mapResult;
        }
    
    // Accessor for the property "BackingMapListener"
    /**
    * Getter for property BackingMapListener.<p>
    * BackingMap listener. Used only if a custom backing map manager uses an
    * ObservableMap to implement the local storage.
    */
    protected com.tangosol.util.MapListener getBackingMapListener()
        {
        return __m_BackingMapListener;
        }
    
    /**
    * Return a (possibly) dirty instance of the resource value.
    * 
    * @see #getLockedResource
    */
    public Object getCachedResource(Object oKey)
        {
        // import Component.Net.Lease;
        // import com.tangosol.util.Binary;
        // import com.tangosol.util.WrapperException;
        // import java.util.Map;
        
        checkAccess();
        
        boolean fNew        = false;
        Map     mapResource = getResourceMap();
        Lease   lease       = getLease(oKey);
        if (lease == null)
            {
            // non-existant or orphaned resource
            lease = ensureLease(oKey);
            fNew  = true;
            }
        
        ClassLoader loaderResource;
        Object      oResource;
        synchronized (lease)
            {
            oResource      = mapResource.get(oKey);
            loaderResource = lease.getClassLoader();
            if (fNew && oResource == null && !mapResource.containsKey(oKey))
                {
                terminateLease(oKey);
                return null;
                }
            }
        
        ClassLoader loaderCache = getClassLoader();
        if (loaderResource != null && loaderResource != loaderCache)
            {
            oResource = releaseClassLoader(lease);
            }
        
        if (oResource instanceof Binary)
            {
            Binary binValue = (Binary) oResource;
            try
                {
                oResource = getConverterFromInternal().convert(binValue);
                }
            catch (WrapperException e)
                {
                throw new WrapperException(e.getOriginalException(),
                    "CacheName=" + getCacheName() + ", Key=" + oKey);
                }
        
            synchronized (lease)
                {
                // make sure the resource has not changed since we got it
                if (binValue == mapResource.get(oKey))
                    {
                    lease.setClassLoader(loaderCache);
                    lease.setResourceSize(binValue.length());
        
                    mapResource.put(oKey, oResource);
                    }
                }
            }
        
        return oResource;
        }
    
    // Accessor for the property "CacheIndex"
    /**
    * Getter for property CacheIndex.<p>
    * This index of this handler in the indexed CacheHandler property
    * maintained by the cache service.
    * 
    * @see ReplicatedCache#instantiateCacheHandler
    */
    public int getCacheIndex()
        {
        return __m_CacheIndex;
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Accessor for the property "CacheName"
    /**
    * Getter for property CacheName.<p>
    * This name of the cache that is managed by this handler. It could only be
    * null if the cached resources started coming from another member, but the
    * Catalog has not been updated yet. It could only be empty (length == 0)
    * for the Catalog Cache handler.
    * 
    * @see ReplicatedCache#instantiateCacheHandler
    */
    public String getCacheName()
        {
        return __m_CacheName;
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Accessor for the property "CacheService"
    /**
    * Getter for property CacheService.<p>
    */
    public com.tangosol.net.CacheService getCacheService()
        {
        return getService();
        }
    
    // Accessor for the property "ClassLoader"
    /**
    * Getter for property ClassLoader.<p>
    * ClassLoader that should be used by ResourceMessages to deserialize
    * resources that are managed by this handler. The only situations when the
    * ClassLoader could be null are:
    * <ul>
    * <li>the cache has already been replicated by the service, but no client
    * is yet connected to this map
    * <li>the client has called the "release" on the last copy of the cache
    * handler with a given name
    * </ul>
    * 
    * @see #getCachedResource
    */
    public ClassLoader getClassLoader()
        {
        return __m_ClassLoader;
        }
    
    // Accessor for the property "ConverterFromInternal"
    /**
    * Getter for property ConverterFromInternal.<p>
    * A converter that takes service specific "transmittable" serializable
    * objects and converts them via deserialization (etc.) to the objects
    * expected by clients of the cache.
    */
    protected com.tangosol.util.Converter getConverterFromInternal()
        {
        // import com.tangosol.util.Converter;
        // import com.tangosol.util.NullImplementation;
        
        Converter conv = __m_ConverterFromInternal;
        if (conv == null)
            {
            synchronized (this)
                {
                conv = __m_ConverterFromInternal;
                if (conv == null)
                    {
                    ClassLoader loader = getClassLoader();
                    conv = loader == NullImplementation.getClassLoader()
                        ? NullImplementation.getConverter()
                        : getService().instantiateConverterFromInternal(loader);
                    setConverterFromInternal(conv);
                    }
                }
            }
        return conv;
        }
    
    // Accessor for the property "ConverterToInternal"
    /**
    * Getter for property ConverterToInternal.<p>
    * A converter that takes ClassLoader dependent objects and converts them
    * via serialization into Binary objects.
    */
    protected com.tangosol.util.Converter getConverterToInternal()
        {
        // import com.tangosol.util.Converter;
        // import com.tangosol.util.NullImplementation;
        
        Converter conv = __m_ConverterToInternal;
        if (conv == null)
            {
            synchronized (this)
                {
                conv = __m_ConverterToInternal;
                if (conv == null)
                    {
                    ClassLoader loader = getClassLoader();
                    conv = loader == NullImplementation.getClassLoader()
                        ? NullImplementation.getConverter()
                        : getService().instantiateConverterToInternal();
                    setConverterToInternal(conv);
                    }
                }
            }
        return conv;
        }
    
    // Accessor for the property "IgnoreKey"
    /**
    * Getter for property IgnoreKey.<p>
    * The key of a resource in the local storage that is currently being
    * processed by the service and therefore should be ignored by the
    * BackingMapListener.
    */
    public Object getIgnoreKey()
        {
        return __m_IgnoreKey;
        }
    
    /**
    * Get a current Lease for the specified resource.
    * 
    * @param oKey  the resource key
    * 
    * @return  the Lease object for the specified resource; null if no Lease is
    * known to exist for this resource
    * 
    * Note: the lease object should not be modified directly by a client.
    */
    public _package.component.net.Lease getLease(Object oKey)
        {
        // import Component.Net.Lease;
        
        return (Lease) getLeaseMap().get(oKey);
        }
    
    // Accessor for the property "LeaseKeys"
    /**
    * Getter for property LeaseKeys.<p>
    * Calculated property returning the Enumeration of <i>issued</i> lease keys.
    */
    public java.util.Enumeration getLeaseKeys()
        {
        // import com.tangosol.util.SimpleEnumerator;
        
        return new SimpleEnumerator(getLeaseMap().keySet().toArray());
        }
    
    // Accessor for the property "LeaseMap"
    /**
    * Getter for property LeaseMap.<p>
    * This Map assosiates resource keys with the corresponding Lease objects
    * for each leased resource. Its key set is a subset of the ResourceMap key
    * set.
    */
    public java.util.Map getLeaseMap()
        {
        return __m_LeaseMap;
        }
    
    // Accessor for the property "ListenerSupport"
    /**
    * Getter for property ListenerSupport.<p>
    * Registered listeners to the MapEvent notifications.
    */
    public com.tangosol.util.MapListenerSupport getListenerSupport()
        {
        return __m_ListenerSupport;
        }
    
    /**
    * Obtain a locked resource with the specified name. This method returns a
    * <i>Locked</i> resource or an exception is thrown. This method blocks the
    * calling thread until the Lease can be locked. If the object did not exist
    * previously, null will be returned after the Lease is obtained. If the
    * lease has already been locked, it will be renewed. This method should
    * only be called on a client's thread.
    * 
    * @param oKey  the requested resource key
    * 
    * @return the requested resource or null if the resource does not exist.
    * 
    * @see #getCachedResource
    */
    public Object getLockedResource(Object oKey)
        {
        // import com.tangosol.net.ClusterException;
        
        checkAccess();
        
        if (getService().lockResource(this, oKey, getStandardLeaseMillis(), -1))
            {
            return getCachedResource(oKey);
            }
        else
            {
            throw new IllegalStateException();
            }
        }
    
    // Accessor for the property "NextHandler"
    /**
    * Getter for property NextHandler.<p>
    * Reference to another handler with exact same proprties as this one except
    * the ClassLoader property
    */
    public CacheHandler getNextHandler()
        {
        return __m_NextHandler;
        }
    
    // Accessor for the property "ResourceKeys"
    /**
    * Getter for property ResourceKeys.<p>
    * Calculated property returning the Enumeration of resource keys.
    */
    public java.util.Enumeration getResourceKeys()
        {
        // import com.tangosol.util.SimpleEnumerator;
        
        return new SimpleEnumerator(getResourceMap().keySet().toArray());
        }
    
    // Accessor for the property "ResourceMap"
    /**
    * Getter for property ResourceMap.<p>
    * This Map holds the resources assosiated with the Leases held in the
    * LeaseMap.
    */
    public java.util.Map getResourceMap()
        {
        return __m_ResourceMap;
        }
    
    // Accessor for the property "Service"
    /**
    * Getter for property Service.<p>
    */
    public _package.component.util.daemon.queueProcessor.service.ReplicatedCache getService()
        {
        // import Component.Util.Daemon.QueueProcessor.Service.ReplicatedCache;
        
        return (ReplicatedCache) get_Parent();

        }
    
    // Accessor for the property "StandardLeaseMillis"
    /**
    * Getter for property StandardLeaseMillis.<p>
    * The duration of a standard Lease in milliseconds for the resources
    * controlled by this CacheHandler.
    */
    public long getStandardLeaseMillis()
        {
        return __m_StandardLeaseMillis;
        }
    
    // Accessor for the property "Validator"
    /**
    * Getter for property Validator.<p>
    * Returns a new instance of default implementation of Validator interface.
    * 
    * @deprecated since Coherence 2.3
    */
    public com.tangosol.util.TransactionMap$Validator getValidator()
        {
        return ($Validator) _newChild("Validator");
        }
    
    private java.util.Map instantiateBackingMap(com.tangosol.net.BackingMapManager manager, String sName)
        {
        // import com.tangosol.util.ObservableMap;
        // import java.util.Map;
        
        Map map = null;
        try
            {
            map = manager.instantiateBackingMap(sName);
            if (map == null)
                {
                _trace("BackingMapManager " + manager.getClass().getName() +
                       ": returned \"null\" for a cache: " + sName, 1);
                }
            else if (!map.isEmpty())
                {
                // this could happen if the service restarted, and a custom manager
                // failed to clear the contents during releaseCache()
                map.clear();
                }
            }
        catch (RuntimeException e)
            {
            _trace("BackingMapManager " + manager.getClass().getName() +
                   ": failed to instantiate a cache: " + sName, 1);
            _trace(e);
            }
        
        if (map instanceof ObservableMap)
            {
            ((ObservableMap) map).addMapListener(instantiateBackingMapListener());
            }
        
        return map;
        }
    
    protected com.tangosol.util.MapListener instantiateBackingMapListener()
        {
        // import com.tangosol.util.MapListener;
        
        $BackingMapListener listener =
            ($BackingMapListener) _newChild("BackingMapListener");
        
        setBackingMapListener(listener);
        return listener;
        }
    
    public synchronized void invalidate()
        {
        // import com.tangosol.net.BackingMapManager;
        // import com.tangosol.util.Listeners;
        // import com.tangosol.util.MapListener;
        // import com.tangosol.util.ObservableMap;
        // import com.tangosol.util.SafeHashMap;
        // import java.util.Map;
        
        Map mapResource = getResourceMap();
        
        MapListener listener = getBackingMapListener();
        if (listener != null)
            {
            ((ObservableMap) mapResource).removeMapListener(listener);
            }
        
        BackingMapManager manager = getService().getBackingMapManager();
        if (manager != null)
            {
            String sName = getCacheName();
            if (sName != null)
                {
                try
                    {
                    manager.releaseBackingMap(sName, mapResource);
                    }
                catch (RuntimeException e)
                    {
                    _trace("BackingMapManager " + manager.getClass().getName() +
                           ": failed to release a cache: " + sName, 1);
                    _trace(e);
                    }
                }
            }
        
        
        setClassLoader(null);
        setListenerSupport(null);
        setConverterFromInternal(null);
        setConverterToInternal(null);
        
        getLeaseMap().clear();
        setResourceMap(new SafeHashMap());
        
        setValid(false);
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Accessor for the property "Active"
    /**
    * Getter for property Active.<p>
    * Calculated property specifiying whether or not this handler is currently
    * active (has a valid ClassLoader)
    */
    public boolean isActive()
        {
        return getClassLoader() != null;
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    // From interface: com.tangosol.util.ObservableMap
    public boolean isEmpty()
        {
        checkAccess();
        
        return getResourceMap().isEmpty();
        }
    
    // Accessor for the property "UseEventDaemon"
    /**
    * Getter for property UseEventDaemon.<p>
    * If true, all map events will be dispatched on the MapEventQueue thread;
    * otherwise on the service thread itself
    */
    public boolean isUseEventDaemon()
        {
        return __m_UseEventDaemon;
        }
    
    // Accessor for the property "Valid"
    /**
    * Getter for property Valid.<p>
    * Returns false iff this CacheHandler has been explicitely invalidated
    * (destroyed).
    */
    public boolean isValid()
        {
        return __m_Valid;
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    // From interface: com.tangosol.util.ObservableMap
    public java.util.Set keySet()
        {
        checkAccess();
        
        $KeySet set = ($KeySet) _newChild("KeySet");
        set.setMap(this);
        set.setSet(getResourceMap().keySet());
        
        return set;
        }
    
    // From interface: com.tangosol.net.NamedCache
    public java.util.Set keySet(com.tangosol.util.Filter filter)
        {
        // import com.tangosol.util.filter.EntryFilter;
        // import com.tangosol.util.filter.LimitFilter;
        // import java.util.HashSet;
        // import java.util.Iterator;
        // import java.util.Map$Entry as Entry;
        // import java.util.Set;
        
        if (filter == null)
            {
            return keySet();
            }
        
        Set set = new HashSet();
        for (Iterator iter = entrySet().iterator(); iter.hasNext();)
            {
            Entry entry = (Entry) iter.next();
        
            if (filter instanceof EntryFilter
                    ? ((EntryFilter) filter).evaluateEntry(entry)
                    : filter.evaluate(entry.getValue()))
                {
                set.add(entry.getKey());
                }
            }
        
        if (filter instanceof LimitFilter)
            {
            LimitFilter filterLimit = (LimitFilter) filter;
            filterLimit.setComparator(null);
            return filterLimit.extractPage(set);
            }
        else
            {
            return set;
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    public boolean lock(Object oKey)
        {
        checkAccess();
        
        return getService().lockResource(this, oKey, getStandardLeaseMillis(), 0);
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    public boolean lock(Object oKey, long cWait)
        {
        checkAccess();
        
        return getService().lockResource(this, oKey, getStandardLeaseMillis(), cWait);
        }
    
    /**
    * Farewell a service member.
    */
    public void onFarewell(_package.component.net.Member member)
        {
        // import Component.Net.Lease;
        // import java.util.Enumeration;
        
        for (Enumeration enum = getLeaseKeys(); enum.hasMoreElements();)
            {
            Object oKey  = enum.nextElement();
            Lease  lease = getLease(oKey);
        
            if (lease != null)
                {
                validateLease(lease);
                }
            }
        }
    
    // Declared at the super level
    /**
    * The "component has been initialized" method-notification (kind of
    * WM_NCCREATE event) called out of setConstructed() for the topmost
    * component and that in turn notifies all the children. <p>
    *     This notification gets called before the control returns back to this
    * component instantiator (using <code>new Component.X()</code> or
    * <code>_newInstance(sName)</code>) and on the same thread. In addition,
    * visual components have a "posted" notification <code>onInitUI</code> that
    * is called after (or at the same time as)  the control returns back to the
    * instatiator and possibly on a different thread.
    * 
    * @see Component.GUI.Control#onInitUI
    */
    public void onInit()
        {
        // import com.tangosol.net.cache.LocalCache;
        // import com.tangosol.net.cache.OverflowMap;
        // import com.tangosol.util.ObservableHashMap;
        // import com.tangosol.util.ObservableMap;
        // import com.tangosol.util.SafeHashMap;
        // import java.util.Map;
        
        super.onInit();
        
        if (getLeaseMap() == null)
            {
            Map mapLease;
        
            int nGraveyardSize = getService().getCacheConfig().getGraveyardSize();
            if (nGraveyardSize > 0)
                {
                ObservableMap mapFront = new ObservableHashMap();
                LocalCache    mapBack  = new LocalCache(nGraveyardSize, 0);
        
                mapBack.setEvictionType(LocalCache.EVICTION_POLICY_LRU);
        
                mapLease = new OverflowMap(mapFront, mapBack);
                }
            else
                {
                mapLease = new SafeHashMap();
                }
            setLeaseMap(mapLease);
            }
        }
    
    /**
    * Remove the specified lease. This method is called on the service thread
    * and should not be called externally.
    * 
    * @param lease  the Lease
    * 
    * @see ReplciatedCahce#onLeaseRemove
    */
    public void onLeaseRemove(_package.component.net.Lease lease)
        {
        // import Component.Net.Lease;
        // import Component.Util.CacheEvent;
        // import com.tangosol.run.component.EventDeathException;
        // import com.tangosol.util.MapEvent;
        // import com.tangosol.util.MapListenerSupport as Support;
        
        Object  oKey         = lease.getResourceKey();
        Lease   leaseCurrent = getLease(oKey);
        
        if (leaseCurrent == null)
            {
            // nothing to remove
            return;
            }
        
        int iCompare = leaseCurrent.compareTo(lease);
        if (iCompare >= 0)
            {
            _trace("Rejected remove: " + leaseCurrent + "\n by " + lease, 4);
            throw new EventDeathException();
            }
        
        MapEvent event   = null;
        Support  support = getListenerSupport();
        
        synchronized (leaseCurrent)
            {
            boolean fNotify = isActive() && support != null && containsKey(oKey);
            Object  oValueOld;
        
            setIgnoreKey(oKey);
                {
                // the value could still be a Binary
                oValueOld = getResourceMap().remove(oKey);
                }
            setIgnoreKey(this); // since 'null' is allowed, use something else
        
            if (fNotify)
                {
                event = new MapEvent(this, MapEvent.ENTRY_DELETED, oKey, oValueOld, null);
                }
        
            if (leaseCurrent.getStatus() == Lease.LEASE_AVAILABLE)
                {
                terminateLease(oKey);
                }
            }
        
        if (event != null)
            {
            // ensure lazy event data conversion
            event = Support.convertEvent(event, this, null, getConverterFromInternal());
        
            if (isUseEventDaemon())
                {
                getService().ensureEventDispatcher().getQueue().add(
                    CacheEvent.instantiate(event, support));
                }
            else
                {
                support.fireEvent(event, true);
                }
            }
        }
    
    /**
    * Update a current lease as directed by the specified lease. This method is
    * called on the service thread and should not be called externally.
    * 
    * @param lease  the Lease
    * @param fUpdateResource  if true, update the resource value; otherwise
    * Lease only
    * @param oValue  the resource value; may be null
    * 
    * Important note: the value is quite likely to be a "deferred" value
    * serialized into a DataInputStream. The actual value could be retrieved
    * from the handler using getCachedResource method
    * 
    * @see ReplicatedCahce#onLeaseUpdate
    */
    public void onLeaseUpdate(_package.component.net.Lease lease, boolean fUpdateResource, Object oValue, long cExpiryMillis)
        {
        // import Component.Net.Lease;
        // import Component.Util.CacheEvent;
        // import com.tangosol.net.cache.CacheMap;
        // import com.tangosol.run.component.EventDeathException;
        // import com.tangosol.util.MapEvent;
        // import com.tangosol.util.MapListenerSupport as Support;
        // import java.util.Map;
        
        Object oKey         = lease.getResourceKey();
        Lease  leaseCurrent = ensureLease(oKey);
        
        int iCompare = leaseCurrent.compareTo(lease);
        if (iCompare >= 0)
            {
            _trace("Rejected update: " + leaseCurrent + "\n by " + lease, 4);
            throw new EventDeathException();
            }
        
        MapEvent event   = null;
        Support  support = getListenerSupport();
        
        synchronized (leaseCurrent)
            {
            leaseCurrent.copyFrom(lease);
            leaseCurrent.setClassLoader(getClassLoader());
        
            Map mapResource = getResourceMap();
            if (fUpdateResource)
                {
                int nEventId = 0;
        
                if (isActive() && support != null)
                    {
                    nEventId = containsKey(oKey) ?
                        MapEvent.ENTRY_UPDATED : MapEvent.ENTRY_INSERTED;
                    }
        
                // both new and old values could still be Binary objects
                Object oValueOld;
                if (mapResource instanceof CacheMap)
                    {
                    oValueOld = ((CacheMap) mapResource).put(oKey, oValue, cExpiryMillis);
                    }
                else
                    {
                    if (cExpiryMillis > 0)
                        {
                        _trace("UnsupportedOperation: " + "class \"" +
                            mapResource.getClass().getName() +
                            "\" does not implement CacheMap interface", 1);
                        }
                    oValueOld = mapResource.put(oKey, oValue);
                    }
        
                if (nEventId > 0)
                    {
                    event = new MapEvent(this, nEventId, oKey, oValueOld, oValue);
                    }
                }
            else // lock, unlock
                {
                if (leaseCurrent.getStatus() == Lease.LEASE_AVAILABLE &&
                        !mapResource.containsKey(oKey))
                    {
                    // unlocked lease w/out resource -- expire
                    terminateLease(oKey);
                    }
                }
            }
        
        if (event != null)
            {
            // ensure lazy event data conversion
            event = Support.convertEvent(event, this, null, getConverterFromInternal());
        
            if (isUseEventDaemon())
                {
                CacheEvent.dispatchSafe(event, support.collectListeners(event),
                    getService().ensureEventDispatcher().getQueue());
                }
            else
                {
                support.fireEvent(event, true);
                }
            }
        }
    
    /**
    * Populate the cache using the specified message. This method is called on
    * the service thread and should not be called externally.
    */
    public void populateCache(_package.component.net.message.CacheMessage msg)
        {
        // import Component.Net.Lease;
        // import Component.Net.Message.LeaseMessage;
        // import Component.Util.Daemon.QueueProcessor.Service.ReplicatedCache;
        // import com.tangosol.util.Base;
        // import com.tangosol.util.Binary;
        // import java.io.ByteArrayInputStream;
        // import java.io.DataInputStream;
        // import java.io.IOException;
        // import java.util.Map;
        
        ReplicatedCache      service     = getService();
        int                  iCache      = getCacheIndex();
        Map                  mapResource = getResourceMap();
        int                  cLease      = msg.getLeaseCount();
        ByteArrayInputStream streamBytes = new ByteArrayInputStream(msg.getCacheData());
        DataInputStream      streamData  = new DataInputStream(streamBytes);
        
        for (int i = 0; i < cLease; i++)
            {
            try
                {
                Object oKey  = LeaseMessage.readObject(streamData, service.getContextClassLoader());
                Lease  lease = Lease.instantiate(iCache, oKey, service);
        
                lease.read(streamData);
        
                int cbResource = streamData.readInt();
                if (cbResource == -1)
                    {
                    onLeaseUpdate(lease, false, null, 0L);
                    }
                else
                    {
                    byte[] abResource = new byte[cbResource];
                    Base.read(streamData, abResource);
        
                    lease.setResourceSize(cbResource);
                    onLeaseUpdate(lease, true, new Binary(abResource), 0L);
                    }
                }
            catch (IOException e)
                {
                _trace("An exception (" + e +
                    ") occurred while populating cache: " + this, 1);
                _trace(e);
                break;
                }
            }
        }
    
    /**
    * Populate the specified message with the content of the cache. This method
    * is called on the service thread and should not be called externally.
    * 
    * @param msg the CacheMessage object to be filled with cache data
    * @param cbSize  prefered message size
    * @param enum  an Enumeration object that contains items remained to be
    * processed from the previous invocation
    * 
    * @return an Enumeration object that contains the remaining items; null if
    * all the resources in this cache have been processed
    */
    public java.util.Enumeration populateUpdateMessage(_package.component.net.message.CacheMessage msg, int cbSize, java.util.Enumeration enum)
        {
        // import Component.Net.Lease;
        // import Component.Net.Message.LeaseMessage;
        // import Component.Util.Daemon.QueueProcessor.Service.ReplicatedCache;
        // import com.tangosol.util.WrapperException;
        // import java.io.ByteArrayOutputStream;
        // import java.io.DataOutputStream;
        // import java.io.IOException;
        // import java.util.Enumeration;
        // import java.util.Map;
        
        ReplicatedCache       service     = getService();
        int                   nThisId     = service.getThisMember().getId();
        int                   nOldestId   = service.getServiceOldestMember().getId();
        Map                   mapResource = getResourceMap();
        ByteArrayOutputStream streamBytes = new ByteArrayOutputStream(1024);
        DataOutputStream      streamData  = new DataOutputStream(streamBytes);
        int                   cLease      = 0;
        
        if (enum == null)
            {
            enum = getLeaseKeys();
            }
        
        while (enum.hasMoreElements())
            {
            Object oKey  = enum.nextElement();
            Lease  lease = getLease(oKey);
        
            if (lease == null)
                {
                continue;
                }
        
            lease.validate();
        
            boolean fInclude = false;
            switch (lease.getStatus())
                {
                case Lease.LEASE_UNISSUED:
                    // the issuer is gone, the senior service member
                    // becomes the issuer (consider a buddy instead)
                    lease.setIssuerId(nOldestId);
                    // break through
                case Lease.LEASE_AVAILABLE:
                    fInclude = (lease.getIssuerId() == nThisId);
                    break;
                case Lease.LEASE_LOCKED:
                case Lease.LEASE_DIRTY:
                    fInclude = (lease.getHolderId() == nThisId);
                    break;
                default:
                    throw new IllegalStateException();
                }
        
            if (fInclude)
                {
                // inform the newcomer
                byte[] abLease;
                byte[] abResource = null;
                try
                    {
                    // serialize the lease
                        {
                        ByteArrayOutputStream resBytes = new ByteArrayOutputStream();
                        DataOutputStream      resData  = new DataOutputStream(resBytes);
        
                        LeaseMessage.writeObject(resData, oKey);
                        lease.write(resData);
        
                        abLease = resBytes.toByteArray();
                        }
        
                    // serialize the resource
                    if (mapResource.containsKey(oKey))
                        {
                        int                   cb       = lease.getResourceSize();
                        ByteArrayOutputStream resBytes = new ByteArrayOutputStream(cb <= 0 ? 256 : cb);
                        DataOutputStream      resData  = new DataOutputStream(resBytes);
        
                        LeaseMessage.writeObject(resData, mapResource.get(oKey));
                        abResource = resBytes.toByteArray();
                        } 
                    }
                catch (IOException e)
                    {
                    _trace("An exception (" + e +
                        ") occurred while serializing " + lease +
                        " for " + this, 1);
                    _trace(e);
                    continue;
                    }
        
                try
                    {
                    streamData.write(abLease);
        
                    if (abResource == null)
                        {
                        streamData.writeInt(-1);
                        }
                    else
                        {
                        streamData.writeInt(abResource.length);
                        streamData.write(abResource);
                        }
                    }
                catch (IOException e)
                    {
                    // should not happen
                    _trace("An exception (" + e +
                        ") occurred while streaming the message " + msg +
                        " for " + this, 1);
                    _trace(e);
        
                    // the stream could be corrupted -- no recourse
                    msg.setLeaseCount(0);
                    msg.setCacheData(new byte[0]);
                    return null;
                    }
        
                cLease++;
        
                if (streamData.size() > cbSize)
                    {
                    break;
                    }
                }
            }
        
        msg.setLeaseCount(cLease);
        msg.setCacheData(streamBytes.toByteArray());
        
        return enum.hasMoreElements() ? enum : null;
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    // From interface: com.tangosol.util.ObservableMap
    public Object put(Object oKey, Object oValue)
        {
        return put(oKey, oValue, 0L, true);
        }
    
    // From interface: com.tangosol.net.NamedCache
    public Object put(Object oKey, Object oValue, long cMillis)
        {
        return put(oKey, oValue, cMillis, true);
        }
    
    /**
    * @param fReturn  if true, the return value is required; otherwise it will
    * be ignored
    */
    public Object put(Object oKey, Object oValue, long cMillis, boolean fReturn)
        {
        // import com.tangosol.net.ClusterException;
        
        checkAccess();
        
        Exception exception = null;
        
        for (int i = 1, c = MAX_MAP_RETRIES; i <= c; ++i)
            {
            try
                {
                return getService().updateResource(
                    this, oKey, oValue, cMillis, false, fReturn);
                }
            catch (ClusterException e)
                {
                exception = e;
                }
        
            try
                {
                Thread.sleep(i << 4);
                }
            catch (InterruptedException e)
                {
                Thread.currentThread().interrupt();
                break;
                }
            }
        
        throw reportException(exception);
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    // From interface: com.tangosol.util.ObservableMap
    public void putAll(java.util.Map map)
        {
        // import java.util.Iterator;
        // import java.util.Map$Entry as Entry;
        
        for (Iterator iter = map.entrySet().iterator(); iter.hasNext();)
            {
            Entry entry = (Entry) iter.next();
        
            put(entry.getKey(), entry.getValue(), 0L, false);
            }

        }
    
    public Object putFinal(Object oKey, Object oValue, boolean fReturn)
            throws java.util.ConcurrentModificationException
        {
        // import com.tangosol.net.ClusterException;
        
        checkAccess();
        
        try
            {
            return getService().updateResource(
                this, oKey, oValue, 0L, true, fReturn);
            }
        catch (ClusterException e)
            {
            throw reportException(e);
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void release()
        {
        getCacheService().releaseCache(this);
        }
    
    /**
    * Release the class loader used by this handler.
    */
    public void releaseClassLoader()
        {
        // import Component.Net.Lease;
        // import Component.Util.Daemon.QueueProcessor.Service.ReplicatedCache;
        // import java.util.Enumeration;
        
        // serialize all the relevant resources to release the class loader
        ClassLoader loader = getClassLoader();
        if (loader != null)
            {
            // deactivate the handler before proceeding
            setClassLoader(null);
        
            ReplicatedCache service = getService();
            for (Enumeration enum = getLeaseKeys(); enum.hasMoreElements();)
                {
                Object oKey  = enum.nextElement();
                Lease  lease = getLease(oKey);
        
                if (lease != null)
                    {
                    if (service.getThreadStatus(lease) == Lease.LEASE_LOCKED)
                        {
                        service.unlockResource(this, oKey);
                        }
        
                    if (lease.getClassLoader() == loader)
                        {
                        releaseClassLoader(lease);
                        }
                    }
                }
            }
        }
    
    /**
    * Make sure that resource represented by the specified lease is stored in a
    * serialized form and does not depend on a class loader.
    * 
    * @see #getCachedResource
    */
    protected Object releaseClassLoader(_package.component.net.Lease lease)
        {
        // import com.tangosol.util.Binary;
        // import com.tangosol.util.WrapperException;
        
        synchronized (lease)
            {
            Object oKey   = lease.getResourceKey();
            Object oValue = getResourceMap().get(oKey);
            
            lease.setClassLoader(null);
        
            try
                {
                Object oInternal = getConverterToInternal().convert(oValue);
                if (oInternal != oValue)
                    {
                    getResourceMap().put(oKey, oValue = oInternal);
                    }
                }
            catch (WrapperException e)
                {
                throw new WrapperException(e.getOriginalException(),
                    "CacheName=" + getCacheName() + ", Key=" + oKey);
                }
        
            return oValue;
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    // From interface: com.tangosol.util.ObservableMap
    public Object remove(Object oKey)
        {
        return remove(oKey, true);
        }
    
    /**
    * @param fReturn  if true, the return value is required; otherwise it will
    * be ignored
    */
    public Object remove(Object oKey, boolean fReturn)
        {
        // import com.tangosol.net.ClusterException;
        
        checkAccess();
        
        Exception exception = null;
        
        for (int i = 1, c = MAX_MAP_RETRIES; i <= c; ++i)
            {
            try
                {
                return getService().removeResource(this, oKey, fReturn);
                }
            catch (ClusterException e)
                {
                exception = e;
                }
        
            try
                {
                Thread.sleep(i << 4);
                }
            catch (InterruptedException e)
                {
                Thread.currentThread().interrupt();
                break;
                }
            }
        
        throw reportException(exception);
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void removeIndex(com.tangosol.util.ValueExtractor extractor)
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ObservableMap
    public void removeMapListener(com.tangosol.util.MapListener listener)
        {
        // import com.tangosol.util.Filter;
        
        removeMapListener(listener, (Filter) null);
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ObservableMap
    public synchronized void removeMapListener(com.tangosol.util.MapListener listener, com.tangosol.util.Filter filter)
        {
        // import com.tangosol.util.MapListenerSupport as Support;
        
        _assert(listener != null);
        
        Support support = getListenerSupport();
        if (support != null)
            {
            support.removeListener(listener, filter);
            if (support.isEmpty())
                {
                setListenerSupport(null);
                }
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ObservableMap
    public synchronized void removeMapListener(com.tangosol.util.MapListener listener, Object oKey)
        {
        // import com.tangosol.util.MapListenerSupport as Support;
        
        _assert(listener != null);
        
        Support support = getListenerSupport();
        if (support != null)
            {
            support.removeListener(listener, oKey);
            if (support.isEmpty())
                {
                setListenerSupport(null);
                }
            }
        }
    
    /**
    * Report an exception thrown by the service.
    */
    protected RuntimeException reportException(Exception exception)
        {
        // import java.util.ConcurrentModificationException;
        
        return new ConcurrentModificationException(
            "Cache \"" + getCacheName() + "\": " + exception.getMessage());
        }
    
    // Accessor for the property "BackingMapListener"
    /**
    * Setter for property BackingMapListener.<p>
    * BackingMap listener. Used only if a custom backing map manager uses an
    * ObservableMap to implement the local storage.
    */
    protected void setBackingMapListener(com.tangosol.util.MapListener listener)
        {
        __m_BackingMapListener = listener;
        }
    
    // Accessor for the property "CacheIndex"
    /**
    * Setter for property CacheIndex.<p>
    * This index of this handler in the indexed CacheHandler property
    * maintained by the cache service.
    * 
    * @see ReplicatedCache#instantiateCacheHandler
    */
    public void setCacheIndex(int index)
        {
        if (is_Constructed())
            {
            int indexOld = getCacheIndex();
        
            if (indexOld != -1 && index != indexOld)
                {
                throw new IllegalStateException("Attempt to modify the CacheIndex: " +
                    this + " to " + index);
                }
            }
        __m_CacheIndex = (index);
        }
    
    // Accessor for the property "CacheName"
    /**
    * Setter for property CacheName.<p>
    * This name of the cache that is managed by this handler. It could only be
    * null if the cached resources started coming from another member, but the
    * Catalog has not been updated yet. It could only be empty (length == 0)
    * for the Catalog Cache handler.
    * 
    * @see ReplicatedCache#instantiateCacheHandler
    */
    public void setCacheName(String sName)
        {
        // import com.tangosol.net.BackingMapManager as Manager;
        // import com.tangosol.util.SafeHashMap;
        // import java.util.Map;
        
        if (is_Constructed())
            {
            String sNameOld = getCacheName();
            if (sNameOld != null && !sNameOld.equals(sName))
                {
                throw new IllegalStateException("Attempt to modify the CacheName: " +
                    this + " to " + sName);
                }
        
            Manager manager = getService().getBackingMapManager();
            Map     map     = getResourceMap();
            boolean fClone  = getNextHandler() != null;
        
            if (fClone)
                {
                _assert(map != null, "Resource map must be copied");
                }
            else if (map == null)
                {
                if (manager != null)
                    {
                    if (sName == null)
                        {
                        // temporary store replacement
                        // in the unlikely event that a cache entry has
                        // been reported prior to the cache being set
                        _trace("Creating a temporary map: " + getCacheIndex(), 5);
                        }
                    else
                        {
                        map = instantiateBackingMap(manager, sName);
                        }
                    }
                setResourceMap(map == null ? new SafeHashMap() : map);
                }
            else if (sName != null && sNameOld == null && manager != null)
                {
                // copy the entries from a temporary store
                Map mapActual = instantiateBackingMap(manager, sName);
                if (mapActual != null)
                    {
                    if (!map.isEmpty())
                        {
                        _trace("Transferring " + map.size() + " to: " + sName, 5);
                        mapActual.putAll(map);
                        }
                    setResourceMap(mapActual);
                    }
                }
            }
        
        __m_CacheName = (sName);
        }
    
    // Accessor for the property "ClassLoader"
    /**
    * Setter for property ClassLoader.<p>
    * ClassLoader that should be used by ResourceMessages to deserialize
    * resources that are managed by this handler. The only situations when the
    * ClassLoader could be null are:
    * <ul>
    * <li>the cache has already been replicated by the service, but no client
    * is yet connected to this map
    * <li>the client has called the "release" on the last copy of the cache
    * handler with a given name
    * </ul>
    * 
    * @see #getCachedResource
    */
    public synchronized void setClassLoader(ClassLoader loader)
        {
        __m_ClassLoader = (loader);
        
        // invalidate the "From" converter that uses ClassLoader
        setConverterFromInternal(null);
        }
    
    // Accessor for the property "ConverterFromInternal"
    /**
    * Setter for property ConverterFromInternal.<p>
    * A converter that takes service specific "transmittable" serializable
    * objects and converts them via deserialization (etc.) to the objects
    * expected by clients of the cache.
    */
    protected void setConverterFromInternal(com.tangosol.util.Converter conv)
        {
        __m_ConverterFromInternal = conv;
        }
    
    // Accessor for the property "ConverterToInternal"
    /**
    * Setter for property ConverterToInternal.<p>
    * A converter that takes ClassLoader dependent objects and converts them
    * via serialization into Binary objects.
    */
    protected void setConverterToInternal(com.tangosol.util.Converter pConverterToInternal)
        {
        __m_ConverterToInternal = pConverterToInternal;
        }
    
    // Accessor for the property "IgnoreKey"
    /**
    * Setter for property IgnoreKey.<p>
    * The key of a resource in the local storage that is currently being
    * processed by the service and therefore should be ignored by the
    * BackingMapListener.
    */
    protected void setIgnoreKey(Object oKey)
        {
        __m_IgnoreKey = oKey;
        }
    
    // Accessor for the property "LeaseMap"
    /**
    * Setter for property LeaseMap.<p>
    * This Map assosiates resource keys with the corresponding Lease objects
    * for each leased resource. Its key set is a subset of the ResourceMap key
    * set.
    */
    public void setLeaseMap(java.util.Map map)
        {
        __m_LeaseMap = map;
        }
    
    // Accessor for the property "ListenerSupport"
    /**
    * Setter for property ListenerSupport.<p>
    * Registered listeners to the MapEvent notifications.
    */
    protected void setListenerSupport(com.tangosol.util.MapListenerSupport support)
        {
        __m_ListenerSupport = support;
        }
    
    // Accessor for the property "NextHandler"
    /**
    * Setter for property NextHandler.<p>
    * Reference to another handler with exact same proprties as this one except
    * the ClassLoader property
    */
    public void setNextHandler(CacheHandler handler)
        {
        __m_NextHandler = handler;
        }
    
    // Accessor for the property "ResourceMap"
    /**
    * Setter for property ResourceMap.<p>
    * This Map holds the resources assosiated with the Leases held in the
    * LeaseMap.
    */
    public void setResourceMap(java.util.Map map)
        {
        __m_ResourceMap = map;
        }
    
    // Accessor for the property "StandardLeaseMillis"
    /**
    * Setter for property StandardLeaseMillis.<p>
    * The duration of a standard Lease in milliseconds for the resources
    * controlled by this CacheHandler.
    */
    public void setStandardLeaseMillis(long lMillis)
        {
        __m_StandardLeaseMillis = lMillis;
        }
    
    // Accessor for the property "UseEventDaemon"
    /**
    * Setter for property UseEventDaemon.<p>
    * If true, all map events will be dispatched on the MapEventQueue thread;
    * otherwise on the service thread itself
    */
    public void setUseEventDaemon(boolean pUseEventDaemon)
        {
        __m_UseEventDaemon = pUseEventDaemon;
        }
    
    // Accessor for the property "Valid"
    /**
    * Setter for property Valid.<p>
    * Returns false iff this CacheHandler has been explicitely invalidated
    * (destroyed).
    */
    protected void setValid(boolean fValid)
        {
        __m_Valid = fValid;
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    // From interface: com.tangosol.util.ObservableMap
    public int size()
        {
        checkAccess();
        
        return getResourceMap().size();
        }
    
    /**
    * Move the specified Lease to the graveyard.
    * 
    * @param oKey  the resource key
    */
    public void terminateLease(Object oKey)
        {
        // import com.tangosol.net.cache.OverflowMap;
        // import java.util.Map;
        
        Map mapLease = getLeaseMap();
        if (mapLease instanceof OverflowMap)
            {
            Map mapFront = ((OverflowMap) mapLease).getFrontMap();
            mapFront.remove(oKey);
            }
        else
            {
            mapLease.remove(oKey);
            }
        }
    
    // Declared at the super level
    public String toString()
        {
        StringBuffer sb = new StringBuffer();
        
        sb.append(get_Name())
          .append("{Name=")
          .append(getCacheName())
          .append(", Index=")
          .append(getCacheIndex())
          .append(", ServiceName=")
          .append(getService().getServiceName());
        
        if (isValid())
            {
            sb.append(", ClassLoader=")
              .append(getClassLoader());
            }
        else
            {
            sb.append(", INVALID");
            }
        sb.append('}');
        
        return sb.toString();
        }
    
    // From interface: com.tangosol.run.xml.XmlSerializable
    public com.tangosol.run.xml.XmlElement toXml()
        {
        // import com.tangosol.run.xml.SimpleElement;
        
        SimpleElement xml = new SimpleElement(get_Name());
        
        xml.addElement("CacheName")          .setString(getCacheName());
        xml.addElement("CacheIndex")         .setInt   (getCacheIndex());
        xml.addElement("StandardLeaseMillis").setLong  (getStandardLeaseMillis());
        
        return xml;
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    public boolean unlock(Object oKey)
        {
        checkAccess();
        
        return getService().unlockResource(this, oKey);
        }
    
    /**
    * Validate and possibly change the lease due to the membership change
    */
    protected void validateLease(_package.component.net.Lease lease)
        {
        // import Component.Net.Lease;
        // import Component.Util.Daemon.QueueProcessor.Service;
        
        Service service = getService();
        int     nThisId = service.getThisMember().getId();
        
        // check whether this lease has become an orphan
        lease.validate();
        
        switch (lease.getStatus())
            {
            case Lease.LEASE_UNISSUED:
                // the issuer is gone, the senior service member
                // becomes the issuer (consider a buddy instead)
                lease.setIssuerId(service.getServiceOldestMember().getId());
        
                // break through
            case Lease.LEASE_AVAILABLE:
                // if (lease.getIssuerId() == nThisId) // commented out 2.3b261
                    {
                    // we cannot use "handler.containsKey()" here
                    // since the handler may be not "active"
                    Object oKey = lease.getResourceKey();
                    if (!getResourceMap().containsKey(oKey))
                        {
                        // an unlocked lease without a resource - move to the graveyard
                        terminateLease(oKey);
                        }
                    }
                break;
        
            case Lease.LEASE_LOCKED:
            case Lease.LEASE_DIRTY:
                if (lease.getIssuerId() == 0)
                    {
                    // the issuer is gone;
                    // the holder becomes the issuer
                    lease.setIssuerId(lease.getHolderId());
                    }
                break;
        
            default:
                throw new IllegalStateException();
            }
        }
    
    // From interface: com.tangosol.net.NamedCache
    // From interface: com.tangosol.util.ConcurrentMap
    // From interface: com.tangosol.util.ObservableMap
    public java.util.Collection values()
        {
        // import com.tangosol.util.ConverterCollections;
        // import com.tangosol.util.NullImplementation;
        // import java.util.Collections;
        
        checkAccess();
        
        // the values could still be in serialized form
        // to minimize memory use let's lazily convert the keys into values
        // (see convert())
        return ConverterCollections.getCollection(getResourceMap().keySet(),
            this, NullImplementation.getConverter());
        }
    }
