/* Class
*     _package.component.util.daemon.queueProcessor.packetProcessor.PacketPublisher$RequestQueue
*/

package _package.component.util.daemon.queueProcessor.packetProcessor;

import _package.component.net.member.ClusterMember;
import _package.component.net.memberSet.actualMemberSet.MasterMemberSet;
import _package.component.net.packet.NotifyPacket;
import _package.component.net.packet.notifyPacket.Request;
import java.util.List;

/**
* 
* The PacketPublisher's RequestQueue child is used to queue Request Packets
* such that they can be slightly delayed to allow multiple negative
* acknowledgements to be bundled together.
*/
public class PacketPublisher$RequestQueue
        extends    _package.component.util.Queue
    {
    // Fields declarations
    
    /**
    * Property DelayMillis
    *
    * The minimum number of milliseconds that a Packet will remain queued in
    * the queue before being removed from the front of the queue.
    * 
    * (This property is designable.)
    */
    private int __m_DelayMillis;
    
    /**
    * Property WaitMillis
    *
    * (calculated) The number of milliseconds that the current thread should
    * rest (Object.wait) for the next Packet to be ready to come off the front
    * of the queue.
    */
    private static com.tangosol.util.ListMap __mapChildren;
    
    // Static initializer
    static
        {
        __initStatic();
        }
    
    // Default static initializer
    private static void __initStatic()
        {
        // register child classes
        __mapChildren = new com.tangosol.util.ListMap();
        __mapChildren.put("Iterator", PacketPublisher$RequestQueue$Iterator.get_CLASS());
        }
    
    // Default constructor
    public PacketPublisher$RequestQueue()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public PacketPublisher$RequestQueue(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setDelayMillis(10);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new PacketPublisher$RequestQueue();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/daemon/queueProcessor/packetProcessor/PacketPublisher$RequestQueue".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    //++ getter for autogen property _ChildClasses
    /**
    * This is an auto-generated method that returns the map of design time
    * [static] children.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    protected java.util.Map get_ChildClasses()
        {
        return __mapChildren;
        }
    
    // Declared at the super level
    /**
    * Appends the specified element to the end of this queue.
    * 
    * Queues may place limitations on what elements may be added to this Queue.
    *  In particular, some Queues will impose restrictions on the type of
    * elements that may be added. Queue implementations should clearly specify
    * in their documentation any restrictions on what elements may be added.
    * 
    * @param oElement element to be appended to this Queue
    * 
    * @return true (as per the general contract of the Collection.add method)
    * 
    * @throws ClassCastException if the class of the specified element prevents
    * it from being added to this Queue
    */
    public synchronized boolean add(Object oElement)
        {
        // import Component.Net.Member.ClusterMember;
        // import Component.Net.MemberSet.ActualMemberSet.MasterMemberSet;
        // import Component.Net.Packet.NotifyPacket.Request;
        
        boolean fWasEmpty = isEmpty();
        
        // schedule send
        Request packet = (Request) oElement;
        int cDelayMillis = getDelayMillis();
        if (cDelayMillis > 0)
            {
            packet.setScheduledMillis(System.currentTimeMillis() + cDelayMillis);
            }
        
        MasterMemberSet memberSet = (($Module) get_Module()).getMemberSet();
        ClusterMember   member    = (ClusterMember) memberSet.getMember(packet.getToId());
        if (member != null)
            {
            // allow other requests to the same Member to be placed
            // into this Packet by letting the Packet be found
            // easily from the Member
            member.setPacketRequest(packet);
            }
        
        // add the Packet to the queue
        super.add(packet);
        
        // if the queue was empty, then the publisher needs to wake
        // up so that it can determine how long it can sleep before
        // sending the request
        if (fWasEmpty)
            {
            // this should only have been called from a synchronized
            // method on the Publisher's Queue, so synchronization
            // is not necessary here
            (($Module) get_Module()).getQueue().notify();
            }
        
        return true;
        }
    
    // Accessor for the property "DelayMillis"
    /**
    * Getter for property DelayMillis.<p>
    * The minimum number of milliseconds that a Packet will remain queued in
    * the queue before being removed from the front of the queue.
    * 
    * (This property is designable.)
    */
    public int getDelayMillis()
        {
        return __m_DelayMillis;
        }
    
    // Accessor for the property "WaitMillis"
    /**
    * Getter for property WaitMillis.<p>
    * (calculated) The number of milliseconds that the current thread should
    * rest (Object.wait) for the next Packet to be ready to come off the front
    * of the queue.
    */
    public synchronized long getWaitMillis()
        {
        // import Component.Net.Packet.NotifyPacket;
        // import java.util.List;
        
        List list = getElementList();
        if (list.isEmpty())
            {
            // wait forever (nothing in the list)
            return 0L;
            }
        else
            {
            long lTime = System.currentTimeMillis();
            long lNext = ((NotifyPacket) list.get(0)).getScheduledMillis();
            return Math.max(1L, lNext - lTime);
            }
        }
    
    // Declared at the super level
    /**
    * Waits for and removes the first element from the front of this Queue.
    * 
    * If the Queue is empty, this method will block until an element is in the
    * Queue. The unblocking equivalent of this method is "removeNoWait".
    * 
    * @return the first element in the front of this Queue
    * 
    * @see #removeNoWait
    */
    public synchronized Object remove()
        {
        throw new UnsupportedOperationException();
        }
    
    // Declared at the super level
    /**
    * Removes and returns the first element from the front of this Queue. If
    * the Queue is empty, no element is returned.
    * 
    * The blocking equivalent of this method is "remove".
    * 
    * @return the first element in the front of this Queue or null if the Queue
    * is empty
    * 
    * @see #remove
    */
    public synchronized Object removeNoWait()
        {
        // import Component.Net.Member.ClusterMember;
        // import Component.Net.Packet.NotifyPacket.Request;
        // import java.util.List;
        
        List list  = getElementList();
        long lTime = 0L;
        while (!list.isEmpty())
            {
            if (lTime == 0L)
                {
                lTime = System.currentTimeMillis();
                }
        
            Request packet = (Request) list.get(0);
            if (packet.getScheduledMillis() <= lTime)
                {
                Object oRemoved = list.remove(0);
                _assert(packet == oRemoved);
        
                ClusterMember member = (ClusterMember) (($Module) get_Module()).
                        getMemberSet().getMember(packet.getToId());
                if (member != null)
                    {
                    if (packet == member.getPacketRequest())
                        {
                        member.setPacketRequest(null);
                        }
        
                    return packet;
                    }
                }
            else
                {
                break;
                }
            }
        
        return null;
        }
    
    // Accessor for the property "DelayMillis"
    /**
    * Setter for property DelayMillis.<p>
    * The minimum number of milliseconds that a Packet will remain queued in
    * the queue before being removed from the front of the queue.
    * 
    * (This property is designable.)
    */
    public void setDelayMillis(int cMillis)
        {
        __m_DelayMillis = (Math.max(1, cMillis));
        }
    }
