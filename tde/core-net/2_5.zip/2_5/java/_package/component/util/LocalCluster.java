/* Class
*     _package.component.util.LocalCluster
*/

package _package.component.util;

import _package.component.util.LocalCache;
import com.tangosol.net.ServiceInfo;
import com.tangosol.util.IteratorEnumerator;
import com.tangosol.util.NullImplementation;
import java.util.Map;

/**
* Coherence Local cluster
*/
public class LocalCluster
        extends    _package.component.Util
        implements com.tangosol.net.Cluster
    {
    // Fields declarations
    
    /**
    * Property ContextClassLoader
    *
    */
    private ClassLoader __m_ContextClassLoader;
    
    /**
    * Property Running
    *
    */
    private transient boolean __m_Running;
    
    /**
    * Property ServiceMap
    *
    */
    private transient com.tangosol.util.SafeHashMap __m_ServiceMap;
    
    // Default constructor
    public LocalCluster()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public LocalCluster(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setServiceMap(new com.tangosol.util.SafeHashMap());
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new LocalCluster$Member("Member", this, true), "Member");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new LocalCluster();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/LocalCluster".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // From interface: com.tangosol.net.Cluster
    public void configure(com.tangosol.run.xml.XmlElement xml)
        {
        }
    
    // From interface: com.tangosol.net.Cluster
    public synchronized com.tangosol.net.Service ensureService(String sName, String sType)
        {
        // import Component.Util.LocalCache;
        // import java.util.Map;
        
        Map        mapService = getServiceMap();
        LocalCache cache      = (LocalCache) mapService.get(sName);
        if (cache == null)
            {
            cache = new LocalCache();
        
            cache.setServiceName(sName);
            cache.setCluster(this);
            cache.setContextClassLoader(getContextClassLoader());
        
            mapService.put(sName, cache);
            }
        return cache;
        }
    
    // From interface: com.tangosol.net.Cluster
    // Accessor for the property "ContextClassLoader"
    /**
    * Getter for property ContextClassLoader.<p>
    */
    public ClassLoader getContextClassLoader()
        {
        return __m_ContextClassLoader;
        }
    
    // From interface: com.tangosol.net.Cluster
    public com.tangosol.net.Member getLocalMember()
        {
        return ($Member) _findName("Member");
        }
    
    // From interface: com.tangosol.net.Cluster
    public java.util.Set getMemberSet()
        {
        // import com.tangosol.util.NullImplementation;
        
        return NullImplementation.getSet();
        }
    
    // From interface: com.tangosol.net.Cluster
    public com.tangosol.net.Service getService(String sName)
        {
        return (LocalCache) getServiceMap().get(sName);
        }
    
    // From interface: com.tangosol.net.Cluster
    public com.tangosol.net.ServiceInfo getServiceInfo(String sName)
        {
        // import com.tangosol.net.ServiceInfo;
        
        return (ServiceInfo) getServiceMap().get(sName);
        }
    
    // Accessor for the property "ServiceMap"
    /**
    * Getter for property ServiceMap.<p>
    */
    protected com.tangosol.util.SafeHashMap getServiceMap()
        {
        return __m_ServiceMap;
        }
    
    // From interface: com.tangosol.net.Cluster
    public java.util.Enumeration getServiceNames()
        {
        // import com.tangosol.util.IteratorEnumerator;
        
        return new IteratorEnumerator(getServiceMap().keySet().iterator());
        }
    
    // From interface: com.tangosol.net.Cluster
    public long getTimeMillis()
        {
        return System.currentTimeMillis();
        }
    
    // From interface: com.tangosol.net.Cluster
    // Accessor for the property "Running"
    /**
    * Getter for property Running.<p>
    */
    public boolean isRunning()
        {
        return __m_Running;
        }
    
    // From interface: com.tangosol.net.Cluster
    // Accessor for the property "ContextClassLoader"
    /**
    * Setter for property ContextClassLoader.<p>
    */
    public void setContextClassLoader(ClassLoader loader)
        {
        __m_ContextClassLoader = loader;
        }
    
    // Accessor for the property "Running"
    /**
    * Setter for property Running.<p>
    */
    public void setRunning(boolean fRunning)
        {
        __m_Running = fRunning;
        }
    
    // Accessor for the property "ServiceMap"
    /**
    * Setter for property ServiceMap.<p>
    */
    protected void setServiceMap(com.tangosol.util.SafeHashMap map)
        {
        __m_ServiceMap = map;
        }
    
    // From interface: com.tangosol.net.Cluster
    public void shutdown()
        {
        stop();
        }
    
    // From interface: com.tangosol.net.Cluster
    public void start()
        {
        setRunning(true);
        }
    
    // From interface: com.tangosol.net.Cluster
    public void stop()
        {
        setRunning(false);
        }
    
    public void stopService(com.tangosol.net.Service service)
        {
        // import Component.Util.LocalCache;
        
        getServiceMap().remove(((LocalCache) service).getServiceName());

        }
    }
