/* Class
*     _package.component.util.deltaMap.transactionMap.Pessimistic
*/

package _package.component.util.deltaMap.transactionMap;

import com.tangosol.util.ConcurrentMap;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.Set;

public abstract class Pessimistic
        extends    _package.component.util.deltaMap.TransactionMap
    {
    // Fields declarations
    
    // Initializing constructor
    public Pessimistic(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/util/deltaMap/transactionMap/Pessimistic".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    // Declared at the super level
    /**
    * Enlist a specified resource into a transaction.
    * 
    * @param oKey the resource key
    * @param fWrite if true, the resource should be elisted for read and write;
    * otherwise for read only
    * 
    * @throws ConcurrenModificationException if the resource cannot be enlisted
    * 
    */
    protected void enlist(Object oKey, boolean fWrite)
        {
        // import java.util.ConcurrentModificationException;
        // import java.util.Set;
        
        // all writes require locking
        if (fWrite)
            {
            Set setLock = getBaseLockSet();
        
            if (!setLock.contains(oKey))
                {
                if (getBaseMap().lock(oKey, getLockWaitMillis()))
                    {
                    setLock.add(oKey);
                    }
                else
                    {
                    throw new ConcurrentModificationException("Failed to lock: key=" + oKey);
                    }
                }
            }

        }
    
    // Declared at the super level
    /**
    * Enlist all map resources into a transaction.
    * 
    * @param fWrite if true, resources should be elisted for read and write;
    * otherwise for read only
    * 
    * @throws ConcurrenModificationException if some of the resources cannot be
    * enlisted
    */
    protected void enlistAll(boolean fWrite)
        {
        // import com.tangosol.util.ConcurrentMap;
        // import java.util.ArrayList;
        // import java.util.ConcurrentModificationException;
        // import java.util.Iterator;
        // import java.util.Set;
        
        if (fWrite)
            {
            ConcurrentMap mapBase    = getBaseMap();
            Set           setLock    = getBaseLockSet();
            ArrayList     listLocked = new ArrayList();
            Object        oKeyFailed = null;
        
            for (Iterator iter = keySetImpl().iterator(); iter.hasNext();)
                {
                Object oKey = iter.next();
        
                if (!setLock.contains(oKey))
                    {
                    if (mapBase.lock(oKey, getLockWaitMillis()))
                        {
                        listLocked.add(oKey);
                        }
                    else
                        {
                        oKeyFailed = oKey;
                        break;
                        }
                    }
                }
        
            if (oKeyFailed != null)
                {
                for (Iterator iter = listLocked.iterator(); iter.hasNext();)
                    {
                    Object oKey = iter.next();
        
                    mapBase.unlock(oKey);
                    }
                throw new ConcurrentModificationException("Failed to lock: key=" + oKeyFailed);
                }
        
            setLock.addAll(listLocked);
            }
        }
    
    // Declared at the super level
    public void prepare()
        {
        // import com.tangosol.util.ConcurrentMap;
        // import java.util.ConcurrentModificationException;
        // import java.util.Iterator;
        // import java.util.Set;
        
        super.prepare();
        
        boolean fValidateLocks = true; // not necessary if locks are not expirable
        if (fValidateLocks)
            {
            ConcurrentMap mapBase = getBaseMap();
            Set           setLock = getBaseLockSet();
        
            for (Iterator iter = setLock.iterator(); iter.hasNext();)
                {
                Object oKey = iter.next();
        
                if (!mapBase.lock(oKey))
                    {
                    throw new ConcurrentModificationException("Lock has expired: key=" + oKey);
                    }
                }
            }
        }
    }
