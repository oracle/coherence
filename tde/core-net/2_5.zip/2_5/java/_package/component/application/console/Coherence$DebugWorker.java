/* Class
*     _package.component.application.console.Coherence$DebugWorker
*/

package _package.component.application.console;

import com.tangosol.net.NamedCache;
import com.tangosol.net.Service;
import java.util.Map;

public class Coherence$DebugWorker
        extends    _package.component.util.daemon.QueueProcessor
        implements com.tangosol.net.MemberListener,
                   com.tangosol.util.MapListener
    {
    // Fields declarations
    
    // Default constructor
    public Coherence$DebugWorker()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Coherence$DebugWorker(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setAutoStart(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // containment initialization: children
        _addChild(new Coherence$DebugWorker$Queue("Queue", this, true), "Queue");
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Coherence$DebugWorker();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/application/console/Coherence$DebugWorker".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // From interface: com.tangosol.util.MapListener
    public void entryDeleted(com.tangosol.util.MapEvent e)
        {
        process(e);
        }
    
    // From interface: com.tangosol.util.MapListener
    public void entryInserted(com.tangosol.util.MapEvent e)
        {
        process(e);
        }
    
    // From interface: com.tangosol.util.MapListener
    public void entryUpdated(com.tangosol.util.MapEvent e)
        {
        process(e);
        }
    
    // From interface: com.tangosol.net.MemberListener
    public void memberJoined(com.tangosol.net.MemberEvent e)
        {
        process(e);
        }
    
    // From interface: com.tangosol.net.MemberListener
    public void memberLeaving(com.tangosol.net.MemberEvent e)
        {
        process(e);
        }
    
    // From interface: com.tangosol.net.MemberListener
    public void memberLeft(com.tangosol.net.MemberEvent e)
        {
        process(e);
        }
    
    // Declared at the super level
    /**
    * Event notification to perform a regular daemon activity. To get it
    * called, another thread has to set Notification to true:
    * <code>daemon.setNotification(true);</code>
    * 
    * @see #onWait
    */
    protected void onNotify()
        {
        super.onNotify();
        
        String sCmd = (String) getQueue().remove();
        try
            {
            (($Module) get_Module()).processCommand(sCmd);
            }
        catch (InterruptedException e) {}
        
        setExiting(true);
        }
    
    protected void process(com.tangosol.net.MemberEvent evtMember)
        {
        // import com.tangosol.net.Service;
        
        Service service = (Service) evtMember.getSource();
        String  sName   = service.getInfo().getServiceName();
        
        _trace("\nEvent received on Thread=" + Thread.currentThread()
            + ", " + sName + '\n' + evtMember);

        }
    
    protected void process(com.tangosol.util.MapEvent evtMap)
        {
        // import com.tangosol.net.NamedCache;
        // import java.util.Map;
        
        Map    map   = (Map) evtMap.getSource();
        String sName = "Map=" + map.getClass().getName();
        if (map instanceof NamedCache)
            {
            sName = "Cache=" + ((NamedCache) map).getCacheName();
            }
        
        _trace("\nEvent received on Thread=" + Thread.currentThread()
            + ", " + sName + '\n' + evtMap);
        
        if ("Exception".equals(evtMap.getNewValue()))
            {
            throw new RuntimeException("Test exception");
            }
        }
    }
