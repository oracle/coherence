/* Class
*     _package.component.application.console.CoherenceWeb
*/

package _package.component.application.console;

import _package.component.Installer;
import com.tangosol.dev.tools.CommandLineTool;
import com.tangosol.run.xml.SimpleParser;
import com.tangosol.run.xml.XmlElement;
import com.tangosol.util.ErrorList;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.util.Map;

/**
* CoherenceWeb is a console application that installs the
* HttsSessionReplication functionality into a J2EE application by adding and
* modifying appropriate resources,
* 
* @see #usage
*/
public class CoherenceWeb
        extends    _package.component.application.Console
    {
    // Fields declarations
    
    /**
    * Property BACKUP_SUFFIX
    *
    * Suffix used by the backup.
    */
    public static final String BACKUP_SUFFIX = ".installer-backup";
    
    /**
    * Property FILE_CFG
    *
    */
    public static final String FILE_CFG = "coherence-web.xml";
    
    /**
    * Property TouchTimestamp
    *
    * Specifies the timestamp that customized (secured) entries have to be
    * marked with. If this value is set to zero (default),  the timestamps of
    * the customized entries will be preserved. If the value is -1; the
    * server's current time should be used (the timestamp of the secured
    * application target).
    * 
    * @see Customizer#TouchTimestamp property
    */
    private transient long __m_TouchTimestamp;
    
    /**
    * Property TraceLevel
    *
    * Specifies the trace cut-off level.
    * 
    * If this level is N then all messages coming with trace level greater then
    * N will be ignored.
    */
    private int __m_TraceLevel;
    
    /**
    * Property VERSION
    *
    */
    public static final String VERSION = "2.5 (build 18)";
    
    // Default constructor
    public CoherenceWeb()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public CoherenceWeb(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // singleton initialization
        if (__singleton != null)
            {
            throw new IllegalStateException("A singleton for \"CoherenceWeb\" has already been set");
            }
        __singleton = this;
        
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setTraceLevel(1);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Instantiate an Application component or return the previously
    * instantiated singleton.
    * 
    * The implementation of the get_Instance accessor on the Application
    * component is more complex than that of most other singleton components. 
    * First, it must be able to determine what application to instantiate. 
    * Secondly, it works with the _Reference property of the root component to
    * maintain a reference to the resulting application component until the
    * very last component instance is garbage-collected.
    * 
    * 1)  The _Reference property is static and located on the root component.
    * 2)  The accessor and mutator for the _Reference property are protected
    * and thus the property value can be obtained or modified by any component.
    *  (Specifically, it is set initially by Component.<init>, obtained by
    * Application.get_Instance, and set by Application.onInit.)
    * 3)  Component.<init> (the constructor of the root component) sets the
    * _Reference property to the instance of the component being constructed if
    * and only if the _Reference property is null; this guarantees that a
    * reference to the very first component to be instantiated is initially
    * stored in the _Reference property.
    * 4)  When an application component is instantiated, the Application.onInit
    * method stores a reference to that application in the _Reference property;
    * this ensures that a reference to the application will exist as long as
    * any component instance exists (because the root component class will not
    * be garbage-collectable until all component instances are determined to be
    * garbage-collectable and until all of its sub-classes are determined to be
    * garbage-collectable).  Since Application is a singleton, it is not
    * possible for a second instance of Application to exist, so once an
    * Application component has been instantiated, the _Reference property's
    * value will refer to that application until the root component class is
    * garbage-collected.
    * 5)  When Application.get_Instance() is invoked, if no singleton
    * application (Application.__singleton) has been created, then
    * Application.get_Instance is responsible for instantiating an application,
    * which will result in _Reference being set to the application instance (by
    * way of Application.onInit).
    * 
    * The implementation of Application.get_Instance is expected to take the
    * the following steps in order to instantiate the correct application
    * component:
    * 1) If the value of the _Reference property is non-null, it cannot be an
    * instance of Component.Application, because the __init method of an
    * Application component would have set the Application.__singleton field to
    * reference itself.  Application thus assumes that a non-null _Reference
    * value refers to the first component to be instantiated, and invokes the
    * _makeApplication instance method of that component.  If the return value
    * from _makeApplication is non-null, then it is returned by
    * Application.get_Instance.
    * 2)  Application.get_Instance is now in a catch-22.  No instance of
    * Component.Application exists, which means that the entry point (the
    * initially instantiated) component was not an application component, and
    * the component that was the entry point has denied knowledge of what
    * application should be instantiated.  At this point, the
    * Application.get_Instance method must determine the name of the
    * application component to instantiate without any help.  So it drops back
    * and punts.  First, it checks for an environment setting, then it checks
    * for a properties file setting, and if either one exists, then it
    * instantiates the component specified by that setting and returns it.
    * 3)  Finally, without so much as a clue telling Application.get_Instance
    * what to instantiate, it instantiates the default application context.
    * 
    * Note that in any of the above scenarios, by the time the value is
    * returned by Application.get_Instance, the value of the _Reference
    * property would have been set to the application instance by
    * Application.onInit, thus fulfilling the goal of holding a reference to
    * the application.
    * 
    * Any other case in which a reference must be maintained should be done by
    * having the application hold that reference.  In other words, as long as
    * the application doesn't go away, any reference that it holds won't go
    * away either.
    * 
    * @see Component#_Reference
    */
    public static _package.Component get_Instance()
        {
        _package.Component singleton = __singleton;
        
        if (singleton == null)
            {
            singleton = new CoherenceWeb();
            }
        else if (!(singleton instanceof CoherenceWeb))
            {
            throw new IllegalStateException("A singleton for \"CoherenceWeb\" has already been set to a different type");
            }
        return singleton;
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/application/console/CoherenceWeb".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this;
        }
    
    protected void backup(java.io.File file, java.io.File dirBackup)
            throws java.io.IOException
        {
        // import java.io.File;
        // import java.io.IOException;
        
        File fileBackup = dirBackup == null ?
             new File(file.getCanonicalPath() + BACKUP_SUFFIX) :
             new File(dirBackup, file.getName() + BACKUP_SUFFIX);
        
        if (fileBackup.exists())
            {
            throw new IOException("Backup already exists " + fileBackup);
            }
        
        if (file.renameTo(fileBackup))
            {
            _trace("The original application is saved as " + fileBackup);
            }
        else
            {
            throw new IOException("Failed to backup " + file + " into " + fileBackup);
            }
        }
    
    // Declared at the super level
    /**
    * Prints out the specified message according to the Application context. 
    * Derived applications should provide an appropriate implementation for
    * this method if the output should not be sent to the standard output and
    * error output.  For example, if an application wanted to log output, this
    * would be the method to override.
    * 
    * @param message  the text message to display
    * @param severity  0 for informational, ascending for more serious output
    * (the default implementation assumes anything not 0 is an error and should
    * be printed to the system error stream)
    */
    public void debugOutput(String message, int severity)
        {
        if (severity <= getTraceLevel())
            {
            super.debugOutput(message, severity == 1 ? 1 : 0);
            }
        }
    
    // Accessor for the property "TouchTimestamp"
    /**
    * Getter for property TouchTimestamp.<p>
    * Specifies the timestamp that customized (secured) entries have to be
    * marked with. If this value is set to zero (default),  the timestamps of
    * the customized entries will be preserved. If the value is -1; the
    * server's current time should be used (the timestamp of the secured
    * application target).
    * 
    * @see Customizer#TouchTimestamp property
    */
    public long getTouchTimestamp()
        {
        return __m_TouchTimestamp;
        }
    
    // Accessor for the property "TraceLevel"
    /**
    * Getter for property TraceLevel.<p>
    * Specifies the trace cut-off level.
    * 
    * If this level is N then all messages coming with trace level greater then
    * N will be ignored.
    */
    public int getTraceLevel()
        {
        return __m_TraceLevel;
        }
    
    /**
    * Inspectl the specified application.
    * 
    * @param xmlDescr the descriptor
    * @param errlist list of errors encountered during the operation
    */
    protected com.tangosol.run.xml.XmlElement inspect(java.io.File fileApp, com.tangosol.run.xml.XmlElement xmlDescr, String sServerType, com.tangosol.util.ErrorList errlist)
            throws java.io.IOException
        {
        // import Component.Installer;
        
        Installer installer = Installer.getInstaller(fileApp, sServerType);
        try
            {
            if (installer.isInstalledWeb())
                {
                errlist.addWarning("Coherence*web is already installed into: \""
                    + fileApp + '"');
                return xmlDescr;
                }
            else
                {
                installer.setErrorList(errlist);
        
                return installer.inspectWeb(xmlDescr);
                }
            }
        finally
            {
            installer.close();
            }
        }
    
    /**
    * Install the specified applications according to the specified descriptor
    * 
    * @param xmlWeb the coherence-web descriptor
    * @param dirBackup the backup dir
    * @param errlist list of errors encountered during the operation
    */
    protected void install(com.tangosol.run.xml.XmlElement xmlWeb, java.io.File dirBackup, com.tangosol.util.ErrorList errlist)
            throws java.io.IOException
        {
        // import Component.Installer;
        // import com.tangosol.run.xml.XmlElement;
        // import java.io.File;
        // import java.io.IOException;
        
        XmlElement xmlApp = xmlWeb.getSafeElement("application");
        
        String sAppName = xmlApp.getSafeElement("name").getString();
        String sAppPath = xmlApp.getSafeElement("path").getString();
        String sServer  = xmlApp.getSafeElement("server").getString();
        
        Installer installer = null;
        boolean   fSuccess  = true;
        try
            {
            installer = Installer.getInstaller(new File(sAppPath), sServer);
        
            if (installer.isInstalledWeb())
                {
                errlist.addWarning("Coherence*web is already installed into: \""
                    + sAppPath + '"');
                return;
                }
        
            installer.setErrorList(errlist);
            installer.setTouchTimestamp(getTouchTimestamp());
        
            installer.installWeb(xmlWeb, null);
        
            File fileSource = installer.getSource();
            File fileTarget = installer.getTarget();
        
            // close the installer to release file locks
            installer.close();
            installer = null;
        
            if (dirBackup != null)
                {
                backup(fileSource, dirBackup);
                }
            else
                {
                remove(fileSource);
                }
        
            if (!fileTarget.renameTo(fileSource))
                {
                throw new IOException("Failed to rename " +
                    fileTarget + " to " + fileSource);
                }
            _trace("Successfully installed: " + fileSource);
            }
        finally
            {
            if (installer != null)
                {
                File fileTarget = installer.getTarget();
        
                installer.close();
        
                if (!fSuccess && fileTarget != null && fileTarget.exists())
                    {
                    try
                        {
                        remove(fileTarget);
                        }
                    catch (IOException e) {}
                    }
                }
            }
        }
    
    // Declared at the super level
    /**
    * This method is the entry point for executable Java applications.
    * 
    * Certain types of Java applications are started by the JVM invoking the
    * main() method of the entry point class.  The Application component
    * assists in building these types of applications by providing a default
    * implementation for the main() method.  Unfortunately, main() is not
    * virtual (it must be static) so an application must either override main()
    * or provide configuration information so that the default main()
    * implementation can determine the identity of the entry point class.  For
    * example, the following is a script that an application
    * (Component.Application.Console.HelloWorld) could use to ensure that the
    * HelloWorld application is instantiated:
    * 
    *     // instantiate HelloWorld
    *     get_Instance();
    *     // use the default main() implementation provided by
    * Component.Application
    *     super.main(asArgs);
    * 
    * To avoid creating the script on HelloWorld.main(), and if the application
    * were jar'd, the META-INF directory in the .jar file would contain the
    * following:
    * 
    *     # -- contents of META-INF/MANIFEST.MF
    *     Main-Class:_package.Component.Application.Console.HelloWorld
    * 
    *     # -- contents of META-INF/application.properties --
    *     app=Console.HelloWorld
    * 
    * The application identity could alternatively be provided on the command
    * line, for example if the application has not been jar'd:
    * 
    *     java _package.Component.Application.Console.HelloWorld
    * -app=Console.HelloWorld
    * 
    * The default implementation (Application.main) stores the arguments for
    * later use in the indexed Argument property, instantiates the application
    * (if an instance does not already exist), and invokes the run() method of
    * the application instance.  It is expected that application implementors
    * will provide an implementation for run() and not for main().
    * 
    * Note that "_package." is a place-holder for a deployer-specified package
    * name, for example "com.mycompany.myapplication".  The Packaging Wizard
    * allows the deployer to specify the package into which the application
    * will be deployed.  The above examples would have to be changed
    * accordingly.
    * 
    * @param asArgs  an array of string arguments
    * 
    * @see #get_Instance
    */
    public static void main(String[] asArgs)
        {
        setArgument(asArgs);
        
        ((CoherenceWeb) get_Instance()).run();
        }
    
    protected void remove(java.io.File file)
            throws java.io.IOException
        {
        // import java.io.File;
        // import java.io.IOException;
        
        if (file.isDirectory())
            {
            File[] aFile = file.listFiles();
            if (aFile != null)
                {
                for (int i = 0, c = aFile.length; i < c; i++)
                    {
                    remove(aFile[i]);
                    }
                }
            }
        
        if (!file.delete())
            {
            throw new IOException("Failed to remove: " + file);
            }

        }
    
    protected void restore(java.io.File file, java.io.File dirBackup)
            throws java.io.IOException
        {
        // import java.io.File;
        // import java.io.IOException;
        
        File fileBackup = dirBackup == null ?
             new File(file.getCanonicalPath() + BACKUP_SUFFIX) :
             new File(dirBackup, file.getName() + BACKUP_SUFFIX);
        
        if (!fileBackup.exists())
            {
            throw new IOException("Backup is missing for " + file);
            }
        
        remove(file);
        
        if (fileBackup.renameTo(file))
            {
            _trace("Successfully restored application at: " + file);
            }
        else
            {
            throw new IOException("Failed to restore " + fileBackup + " to " + file);
            }
        }
    
    // Declared at the super level
    public void run()
        {
        // import Component.Installer;
        // import com.tangosol.dev.tools.CommandLineTool;
        // import com.tangosol.util.ErrorList;
        // import com.tangosol.run.xml.SimpleParser;
        // import com.tangosol.run.xml.XmlElement;
        // import java.io.File;
        // import java.io.FileReader;
        // import java.io.FileWriter;
        // import java.io.PrintWriter;
        // import java.text.DateFormat;
        // import java.util.Map;
        
        super.run();
        
        final String[] asCmd = new String[]
            {
            "inspect", "install", "uninstall",
            "server", "backup", "descriptor", 
            "touch", "nowarn", "version", "verbose",
            };
        
        String[] asArg = getArgument();
        if (asArg.length == 0)
            {
            usage(null);
            return;
            }
        
        Map map;
        try
            {
            map = CommandLineTool.parseArguments(asArg, asCmd, true);
            }
        catch (IllegalArgumentException e)
            {
            usage(e.getMessage());
            return;
            }
        
        String  sAppPath    = (String) map.get(new Integer(0));
        String  sBackup     = (String) map.get("backup");
        String  sDescrPath  = (String) map.get("descriptor");
        String  sServerType = (String) map.get("server");
        boolean fInspect    = map.containsKey("inspect");
        boolean fInstall    = map.containsKey("install");
        boolean fUninstall  = map.containsKey("uninstall");
        boolean fBrief      = map.containsKey("nowarn");
        boolean fVerbose    = map.containsKey("verbose");
        
        if (map.containsKey("version"))
            {
            showVersion(true);
            return;
            }
        else
            {
            if (fVerbose)
                {
                setTraceLevel(3);
                }
            showVersion(fVerbose);
            }
        
        if (sAppPath == null || sAppPath.length() == 0)
            {
            usage("Application path must be specified");
            return;
            }
        
        if (fInstall && fUninstall)
            {
            usage("Conflicting actions (-install, -uninstall)");
            return;
            }
        
        if (!fInspect && !fInstall && !fUninstall)
            {
            usage("At least one action (-inspect, -install, or -uninstall) must be specified");
            return;
            }
        
        File fileApp = new File(sAppPath);
        if (fileApp.exists())
            {
            fileApp = fileApp.getAbsoluteFile();
            }
        else
            {
            usage("Non existent application path: " + sAppPath);
            return;
            }
        
        File dirBackup = fileApp.getParentFile();
        if (sBackup != null && sBackup.length() > 0)
            {
            dirBackup = new File(sBackup);
            if (!dirBackup.exists())
                {
                dirBackup.mkdirs();
                }
            if (!dirBackup.isDirectory())
                {
                usage("Failure to create backup directory: " + dirBackup);
                return;
                }
            }
        
        if (map.containsKey("touch"))
            {
            long   lTime = -1;
            String sTime = (String) map.get("touch");
        
            if (sTime != null && sTime.length() > 0)
                {
                try
                    {
                    // date format is very touchy (spaces et all);
                    // it has to be EXACT, for example: "2/21/02 1:33 PM"
                    lTime = DateFormat.getInstance().parse(sTime).getTime();
                    }
                catch (Exception e)
                    {
                    _trace(e.toString() + " - using current date/time");
                    }
                }
            setTouchTimestamp(lTime);
            }
        
        File fileDescr;
        if (sDescrPath == null || sDescrPath.length() == 0)
            {
            fileDescr = new File(fileApp.getParent(), FILE_CFG);
            }
        else
            {
            fileDescr = new File(sDescrPath);
            if (fileDescr.isDirectory())
                {
                fileDescr = new File(fileDescr, FILE_CFG);
                }
            }
        
        XmlElement xmlDescr = null;
        ErrorList  errlist  = new ErrorList();
        try
            {
            if (fileDescr.exists())
                {
                FileReader reader = new FileReader(fileDescr);
                try
                    {
                    xmlDescr = new SimpleParser().parseXml(reader);
                    }
                finally
                    {
                    reader.close();
                    }
                }
        
            if (xmlDescr == null)
                {
                if (fInstall && !fInspect)
                    {
                    usage("Cannot install Coherence*web without inspecting.");
                    return;
                    }
                }
            else
                {
                if (fInspect)
                    {
                    xmlDescr = null;
                    }
                else
                    {
                    File fileInspect = new File(xmlDescr.getSafeElement("application/path").getString());
                    if (fileApp.isFile() && !fileApp.equals(fileInspect))
                        {
                        usage("Application name mismatch");
                        return;
                        }
                    fileApp = fileInspect;
                    }
                }
        
            if (fInspect)
                {
                xmlDescr = inspect(fileApp, xmlDescr, sServerType, errlist);
                if (xmlDescr == null)
                    {
                    fInstall   = false;
                    fUninstall = false;
                    }
                else
                    {
                    if (fileDescr.exists())
                        {
                        _trace("The existing " + fileDescr + " descriptor will be overwritten");
                        }
                    PrintWriter writer = new PrintWriter(new FileWriter(fileDescr));
                    xmlDescr.writeXml(writer, true);
                    writer.close();
                    }
                }
        
            if (fInstall)
                {
                install(xmlDescr, dirBackup, errlist);
                }
        
            if (fUninstall)
                {
                uninstall(xmlDescr, dirBackup, errlist);
                }
            }
        catch (Exception e)
            {
            errlist.addError("Error occured while processing \"" + sAppPath + "\"\n" + e);
            _trace(e);
            }
        finally
            {
            if (!errlist.isEmpty())
                {
                if (!fBrief || errlist.isSevere())
                    {
                    _trace(errlist.toString());
                    }
                }
            }
        }
    
    // Accessor for the property "TouchTimestamp"
    /**
    * Setter for property TouchTimestamp.<p>
    * Specifies the timestamp that customized (secured) entries have to be
    * marked with. If this value is set to zero (default),  the timestamps of
    * the customized entries will be preserved. If the value is -1; the
    * server's current time should be used (the timestamp of the secured
    * application target).
    * 
    * @see Customizer#TouchTimestamp property
    */
    protected void setTouchTimestamp(long ldt)
        {
        __m_TouchTimestamp = ldt;
        }
    
    // Accessor for the property "TraceLevel"
    /**
    * Setter for property TraceLevel.<p>
    * Specifies the trace cut-off level.
    * 
    * If this level is N then all messages coming with trace level greater then
    * N will be ignored.
    */
    protected void setTraceLevel(int fDebug)
        {
        __m_TraceLevel = fDebug;
        }
    
    /**
    * Print the version info
    * 
    * @param fVerbose if true, print the verbose  notification; otherwise the
    * brief one
    */
    protected void showVersion(boolean fFull)
        {
        if (fFull)
            {
            _trace("\nTangosol Coherence*web: version " + VERSION);
            }
        }
    
    /**
    * Uninstalll the specified applications according to the specified
    * descriptor.
    * 
    * @param xmlDescr the descriptor
    * @param errlist list of errors encountered during the operation
    */
    protected void uninstall(com.tangosol.run.xml.XmlElement xmlDescr, java.io.File dirBackup, com.tangosol.util.ErrorList errlist)
            throws java.io.IOException
        {
        // import com.tangosol.run.xml.XmlElement;
        // import java.io.File;
        
        XmlElement xmlApp = xmlDescr.getSafeElement("application");
        
        String sAppName = xmlApp.getSafeElement("name").getString();
        String sAppPath = xmlApp.getSafeElement("path").getString();
        
        restore(new File(sAppPath), dirBackup);
        }
    
    public void usage(String sMsg)
        {
        if (sMsg != null)
            {
            _trace("\n*** " + sMsg);
            }
        
        String sUsage =
            "\nUsage:\n" +
            "    java -jar webInstaller.jar <application-path> [-options] -operation\n" +
        
            "\nwhere options include:\n" +
            "   -backup:<backup path>            path to the backup directory \n" +
            "                                    (default: application's directory)\n" +
            "   -descriptor:<descriptor path>    path to the XML descriptor\n" +
            "                                    (default: " + FILE_CFG + ")\n" +
            "   -server:<server type>            (e.g. WL60, WAS40, 2.3)\n" +
            "   -touch [:'M/d/y h:mm a']         touch modified jsps and tlds\n" +
            "   -nowarn                          do not generated any warnings\n" +
            "   -verbose                         show verbose output\n" +
        
            "\nand operations include:\n" + 
            "   -inspect                         inspect the specified application path\n" +
            "                                    and create a descriptor\n" +
            "   -install                         install Coherence*web into the application\n" +
            "   -uninstall                       uninstall Coherence*web from the application\n" +
            "   -version                         show product version and exit\n" +
            "";
        
        _trace(sUsage);
        }
    }
