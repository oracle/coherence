/* Class
*     _package.component.application.console.Coherence$DebugCacheItem
*/

package _package.component.application.console;

public class Coherence$DebugCacheItem
        extends    _package.component.Data
    {
    // Fields declarations
    
    /**
    * Property Index
    *
    */
    private int __m_Index;
    
    /**
    * Property Local
    *
    * Transient value!
    */
    private transient boolean __m_Local;
    
    /**
    * Property Origin
    *
    */
    private int __m_Origin;
    
    // Default constructor
    public Coherence$DebugCacheItem()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Coherence$DebugCacheItem(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        // state initialization: public and protected properties
        try
            {
            setLocal(true);
            }
        catch (java.lang.Exception e)
            {
            // re-throw as a runtime exception
            throw new com.tangosol.util.WrapperException(e);
            }
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Coherence$DebugCacheItem();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/application/console/Coherence$DebugCacheItem".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // Declared at the super level
    /**
    * Compares this object with the specified object for order.  Returns a
    * negative integer, zero, or a positive integer as this object is less
    * than, equal to, or greater than the specified object.
    * 
    * @param o  the Object to be compared.
    * @return  a negative integer, zero, or a positive integer as this object
    * is less than, equal to, or greater than the specified object.
    * 
    * @throws ClassCastException if the specified object's type prevents it
    * from being compared to this Object.
    */
    public int compareTo(Object o)
        {
        $DebugCacheItem that = ($DebugCacheItem) o;
        
        return this.getIndex() < that.getIndex() ? -1 :
               this.getIndex() > that.getIndex() ? +1 : 0;
        }
    
    // Declared at the super level
    public boolean equals(Object obj)
        {
        if (obj instanceof $DebugCacheItem)
            {
            $DebugCacheItem that = ($DebugCacheItem) obj;
            return this.getIndex()  == that.getIndex() &&
                   this.getOrigin() == that.getOrigin();
            }
        return false;
        }
    
    // Accessor for the property "Index"
    /**
    * Getter for property Index.<p>
    */
    public int getIndex()
        {
        return __m_Index;
        }
    
    // Accessor for the property "Origin"
    /**
    * Getter for property Origin.<p>
    */
    public int getOrigin()
        {
        return __m_Origin;
        }
    
    // Declared at the super level
    public int hashCode()
        {
        return getIndex() + getOrigin();
        }
    
    // Accessor for the property "Local"
    /**
    * Getter for property Local.<p>
    * Transient value!
    */
    public boolean isLocal()
        {
        return __m_Local;
        }
    
    public void readExternal(java.io.ObjectInput stream)
            throws java.io.IOException
        {
        // not used
        setIndex(stream.readInt());
        setOrigin(stream.readInt());
        }
    
    // Accessor for the property "Index"
    /**
    * Setter for property Index.<p>
    */
    public void setIndex(int i)
        {
        __m_Index = i;
        }
    
    // Accessor for the property "Local"
    /**
    * Setter for property Local.<p>
    * Transient value!
    */
    public void setLocal(boolean pLocal)
        {
        __m_Local = pLocal;
        }
    
    // Accessor for the property "Origin"
    /**
    * Setter for property Origin.<p>
    */
    public void setOrigin(int i)
        {
        __m_Origin = i;
        }
    
    // Declared at the super level
    public String toString()
        {
        return "DebugCacheItem{Index=" + getIndex() +
               ", Origin=" + getOrigin() +
               ", Local="  + isLocal() +
               '}';
        }
    
    public void writeExternal(java.io.ObjectOutput stream)
            throws java.io.IOException
        {
        // not used
        stream.writeInt(getIndex());
        stream.writeInt(getOrigin());
        }
    }
