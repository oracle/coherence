/* Class
*     _package.component.application.console.Coherence$MapWrapper
*/

package _package.component.application.console;

import com.tangosol.util.ObservableMap;

public class Coherence$MapWrapper
        extends    _package.component.util.collections.WrapperMap
        implements com.tangosol.net.NamedCache
    {
    // Fields declarations
    
    /**
    * Property CacheName
    *
    */
    private String __m_CacheName;
    
    /**
    * Property CacheService
    *
    */
    private com.tangosol.net.CacheService __m_CacheService;
    
    // Default constructor
    public Coherence$MapWrapper()
        {
        this(null, null, true);
        }
    
    // Initializing constructor
    public Coherence$MapWrapper(String sName, _package.Component compParent, boolean fInit)
        {
        super(sName, compParent, false);
        
        if (fInit)
            {
            __init();
            }
        }
    
    // Main initializer
    public void __init()
        {
        // private initialization
        __initPrivate();
        
        
        // containment initialization: children
        
        // signal the end of the initialization
        set_Constructed(true);
        }
    
    // Private initializer
    protected void __initPrivate()
        {
        
        super.__initPrivate();
        }
    
    //++ getter for static property _Instance
    /**
    * Getter for property _Instance.<p>
    * Auto generated
    */
    public static _package.Component get_Instance()
        {
        return new Coherence$MapWrapper();
        }
    
    //++ getter for static property _CLASS
    /**
    * Getter for property _CLASS.<p>
    * Property with auto-generated accessor that returns the Class object for a
    * given component.
    */
    public static Class get_CLASS()
        {
        Class clz;
        try
            {
            clz = Class.forName("_package/component/application/console/Coherence$MapWrapper".replace('/', '.'));
            }
        catch (ClassNotFoundException e)
            {
            throw new NoClassDefFoundError(e.getMessage());
            }
        return clz;
        }
    
    //++ getter for autogen property _Module
    /**
    * This is an auto-generated method that returns the global [design time]
    * parent component.
    * 
    * Note: the class generator will ignore any custom implementation for this
    * behavior.
    */
    private final _package.Component get_Module()
        {
        return this.get_Parent();
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void addIndex(com.tangosol.util.ValueExtractor extractor, boolean fOrdered, java.util.Comparator comparator)
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void addMapListener(com.tangosol.util.MapListener listener)
        {
        // import com.tangosol.util.ObservableMap;
        
        ((ObservableMap) getMap()).addMapListener(listener);
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void destroy()
        {
        release();
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Declared at the super level
    public java.util.Set entrySet()
        {
        return getMap().entrySet();
        }
    
    // From interface: com.tangosol.net.NamedCache
    public java.util.Set entrySet(com.tangosol.util.Filter filter)
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.net.NamedCache
    public java.util.Set entrySet(com.tangosol.util.Filter filter, java.util.Comparator comparator)
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Accessor for the property "CacheName"
    /**
    * Getter for property CacheName.<p>
    */
    public String getCacheName()
        {
        return __m_CacheName;
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Accessor for the property "CacheService"
    /**
    * Getter for property CacheService.<p>
    */
    public com.tangosol.net.CacheService getCacheService()
        {
        return __m_CacheService;
        }
    
    // From interface: com.tangosol.net.NamedCache
    public boolean isActive()
        {
        return getMap() != null;
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Declared at the super level
    public java.util.Set keySet()
        {
        return getMap().keySet();
        }
    
    // From interface: com.tangosol.net.NamedCache
    public java.util.Set keySet(com.tangosol.util.Filter filter)
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.net.NamedCache
    public boolean lock(Object oKey)
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.net.NamedCache
    public boolean lock(Object oKey, long cMillis)
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void release()
        {
        setMap(null);
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void removeIndex(com.tangosol.util.ValueExtractor extractor)
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.net.NamedCache
    public void removeMapListener(com.tangosol.util.MapListener listener)
        {
        // import com.tangosol.util.ObservableMap;
        
        ((ObservableMap) getMap()).removeMapListener(listener);
        }
    
    // Accessor for the property "CacheName"
    /**
    * Setter for property CacheName.<p>
    */
    public void setCacheName(String sName)
        {
        __m_CacheName = sName;
        }
    
    // Accessor for the property "CacheService"
    /**
    * Setter for property CacheService.<p>
    */
    public void setCacheService(com.tangosol.net.CacheService service)
        {
        __m_CacheService = service;
        }
    
    // From interface: com.tangosol.net.NamedCache
    public boolean unlock(Object oKey)
        {
        throw new UnsupportedOperationException();
        }
    
    // From interface: com.tangosol.net.NamedCache
    // Declared at the super level
    public java.util.Collection values()
        {
        return getMap().values();
        }
    }
